# Bash Yerleşik Komutlarının Açıklaması

YÜKLENEBİLİR YERLEŞİKLER DİYE BİR KAVRAM VAR

Kendi ihtiyaçların doğrultusunda derlemiş olduğun araçları, kabuğun yerleşikleri içerisine dahil ederek verimli şekilde çalışmasını sağlayabilirsin. Bash kaynak kodunda /examples/loadable/ klasörü altında yüklenebilir yerleşik komut örnekleri vardır. Yeni sürümlerde bu örnekler değişebilir. Bash v2.0 dan beri bu özellik destekleniyor.

```bash
.../bash-4.0$ CC=whatever ./configure
.../bash-4.0$ make
.../bash-4.0$ exec ./bash
.../bash-4.0$ cd examples/loadables/
.../loadables$ make
.../loadables$ enable -f finfo finfo
.../loadables$ help finfo
```

Bu bölüm altında sıralı şekilde bash kabuğuyla birlikte gelen yerleşik araçların kullanımlarını açıklayalım.

Bash yerleşik komutlarının neler olduğunu öğrenmek için konsola `compgen -b` komutunu girmemiz yeterlidir. Burada kullanmış olduğumuz `compgen` komutu yani `compgen` aracı da aslında bash yerleşik araçlarından biridir. Görevi ise tab tuşuna basıldığında mevcut komutlara yönelik kısmi parametrelerin ve seçeneklerin tamamlanması için sistem üzerindeki araçlara ait bilgi sunmaktır. Yani daha sonra ayrıca ele alacağımız  `complete` aracıyla birlikte bash kabuğunun sahip olduğu tab tuşu ile otomatik tamamlama özelliğini mümkün kılar. Sırası geldiğinde tüm yerleşik komutları(araçları) açıklamış olacağız. O zaman bu aracın işlevini çok daha net anlayacaksınız.

Yerleşik yardımcı programlar, -n seçeneğiyle birlikte enable komutu kullanılarak devre dışı bırakılabilir.

enable -n kill komutu kill yerleşik komutunun mevcut kabuk üzerinde devredışı bırkılmasını sağlar.

[`.` (nokta) & `source` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/(nokta)%20&%20source%20Komutu%202b96d04193e74d948f52535cda24ed35.md)

[`:` (iki nokta üst üste) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/(iki%20nokta%20u%CC%88st%20u%CC%88ste)%20Komutu%2066beb891c83b49a7abe6dc5bbf4e7d35.md)

[[ ] (Köşeli Parantez) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/%5B%20%5D%20(Ko%CC%88s%CC%A7eli%20Parantez)%20Komutu%2030e8290d015e43ceac68ed86156369d5.md)

[`alias` ve `unalias` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/alias%20ve%20unalias%20Komutu%20b3ca081efda345ffaad971fd171ac39f.md)

[bg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/bg%20Komutu%2052ac547c4cbe4885853540df4f4f995d.md)

[bind Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/bind%20Komutu%205159e55584134bd4abaea11e9531042f.md)

[break Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/break%20Komutu%20c36050339db84cdc828144c95890ace2.md)

[builtin Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/builtin%20Komutu%2045c716dd06c8405c968cd19510cddadf.md)

[caller Komutu ! EKSİK !](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/caller%20Komutu%20!%20EKSI%CC%87K%20!%2042b74681b33a45479278140840ea7c28.md)

[cd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/cd%20Komutu%206fb8eb1caaeb4e0a8df99d53309cd303.md)

[command Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/command%20Komutu%20661a11d03aef4c3ca8d8f772c4561401.md)

[compgen Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/compgen%20Komutu%20d388432cfbdd4f53923ecc5172fd8cec.md)

[complete Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/complete%20Komutu%200d2dea463d954cd482e1d06aa202633a.md)

[compopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/compopt%20Komutu%20b9faf26a2e224f398a128f0573727e14.md)

[continue Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/continue%20Komutu%2056bcda9c94494eafb384f6b7022f4ab5.md)

[declare ve typeset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/declare%20ve%20typeset%20Komutu%201056f43117c94fb28a975ebab87beb2d.md)

[`pushd` `dirs` `popd` Komutları](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/pushd%20dirs%20popd%20Komutlar%C4%B1%20772e1464e6fe4556994ed13bf0fb4f8b.md)

[disown Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/disown%20Komutu%2041ca6bb7d8714610a18adc5d8f08f817.md)

[nohup Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/nohup%20Komutu%206505e8abbbca4793add548c0fb951481.md)

[echo Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/echo%20Komutu%20afce9e94952346958044c9aff6ca1bfc.md)

[enable Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/enable%20Komutu%2013eb6e84fce04871ab3c3ba6f96e72b9.md)

[eval Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/eval%20Komutu%2042d2ecab181a411e95e911c6a4fc5f62.md)

[exec Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/exec%20Komutu%2011587abbd26141f39e2858cd8dc84662.md)

[exit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/exit%20Komutu%2087aff501b79443dfa0af8d41f66f914d.md)

[export Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/export%20Komutu%20c7bcd58c00714c059fa8d0df7ab1d64c.md)

[false & true Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/false%20&%20true%20Komutu%20b8c7dd091a5c4f35b2d5072dcbf24fba.md)

[fc Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/fc%20Komutu%209953435536a14b14b83a923b72111e63.md)

[fg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/fg%20Komutu%206718305c5af148af9e23e3a7d0731f43.md)

[getopts Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/getopts%20Komutu%2016827f5da86b472b8b45645f8d8eca84.md)

[hash Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/hash%20Komutu%20e0ac6d99dfe945bbab5dc843fb762009.md)

[help Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/help%20Komutu%20a881235acbf84c01b7a961b60788d0d1.md)

[history Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/history%20Komutu%20e6adfae2b0ba47ea81d5d72cd1a9a611.md)

[jobs Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/jobs%20Komutu%20d53eae704d9c4938867f186df6f68379.md)

[kill Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/kill%20Komutu%20e3b6c4b3c5ea4d5eb3d2b039fa53608b.md)

[let Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/let%20Komutu%20dbb862e1e2734b4d807540a0a9099bd7.md)

[local Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/local%20Komutu%204251bb5ba19446208b1b44253debb3f7.md)

[logout Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/logout%20Komutu%203fddf7e6158e495b8c769c571733787f.md)

[mapfile ve readarray Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/mapfile%20ve%20readarray%20Komutu%2040a12a26b3514f67be02146248f87138.md)

[suspend Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/suspend%20Komutu%20ff12b7dbfa2a4a35b824dc382153a659.md)

[pwd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/pwd%20Komutu%2017ae8b13b4574a62888d1d79ddb8b26f.md)

[return Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/return%20Komutu%20e42b5e0439cf419d83cc571d5570389b.md)

[type Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/type%20Komutu%20461446cf123043e4a70e897fd4c34ec0.md)

[readonly Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/readonly%20Komutu%20ffa938b7f6cd49cb98092e4d7bb1da55.md)

[unset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/unset%20Komutu%2073d45291d032415da81021d5a1ada8dc.md)

[shopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/shopt%20Komutu%204f959695e31749528cdeccba0c0880ed.md)

[times Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/times%20Komutu%2065b8d2fdcc9e4c6c93bda5c8e060cde7.md)

[trap Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/trap%20Komutu%201c84d9283d0143c790b6369b670d338a.md)

[ulimit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/ulimit%20Komutu%209641bfb1da0342f1bd0e2901ffb2806a.md)

[umask Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/umask%20Komutu%20e07b5e05076542949fa94845667ea7d2.md)

[wait Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40/wait%20Komutu%20ec1eab2b952f44179eb9605b000840de.md)