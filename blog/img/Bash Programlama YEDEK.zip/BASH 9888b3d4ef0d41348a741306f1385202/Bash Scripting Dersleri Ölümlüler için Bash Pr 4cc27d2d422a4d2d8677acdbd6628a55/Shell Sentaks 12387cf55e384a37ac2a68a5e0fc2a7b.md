# Shell Sentaks

3.1.1 Kabuk Operasyonu

1. Girdisini bir dosyadan (bkz. [Kabuk Komut Dosyaları](https://www.gnu.org/software/bash/manual/html_node/Shell-Scripts.html)[Bash Çağırma](https://www.gnu.org/software/bash/manual/html_node/Invoking-Bash.html)
    
    ), argüman olarak sağlanan bir dizeden
    
    - c
    
    çağırma seçeneği (bkz.
    
    ) veya kullanıcının terminalinden.
    
2. Alıntıda açıklanan alıntı kurallarına uyarak girişi kelimelere ve işleçlere [ayırır](https://www.gnu.org/software/bash/manual/html_node/Quoting.html)`metacharacters`[Adlar](https://www.gnu.org/software/bash/manual/html_node/Aliases.html)
    
    . Bu belirteçler ile ayrılır
    
    . Takma ad genişletme bu adımla gerçekleştirilir (bkz. Diğer
    
    ).
    
3. Belirteçleri basit ve bileşik komutlara ayırır (bkz. [Kabuk Komutları](https://www.gnu.org/software/bash/manual/html_node/Shell-Commands.html)
    
    ).
    
4. Çeşitli kabuk genişletmelerini gerçekleştirir (bkz. [Kabuk Genişletmeleri](https://www.gnu.org/software/bash/manual/html_node/Shell-Expansions.html)[Dosya Adı Genişletme](https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html)
    
    ), genişletilmiş belirteçleri dosya adları listelerine (bkz.
    
    ) ve komutlar ve bağımsız değişkenlere böler .
    
5. Tüm gerekli yeniden yönlendirmeleri gerçekleştirir (bkz. [Yeniden Yönlendirmeler](https://www.gnu.org/software/bash/manual/html_node/Redirections.html)
    
    ) ve yeniden yönlendirme işleçlerini ve bunların işlenenlerini bağımsız değişken listesinden kaldırır.
    
6. Komutu yürütür (bkz . [Komutları Yürütme](https://www.gnu.org/software/bash/manual/html_node/Executing-Commands.html)
    
    ).
    
7. İsteğe bağlı olarak komutun tamamlanmasını bekler ve çıkış durumunu toplar (bkz. [Çıkış Durumu](https://www.gnu.org/software/bash/manual/html_node/Exit-Status.html)
    
    ).