# Basit Kabuk Özellikleri | GNU.ORG

[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[3.1 Bash Sentaks(syntax) Yapısı](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20ff17c999e406480bb8dd48cde60e4347/3%201%20Bash%20Sentaks(syntax)%20Yap%C4%B1s%C4%B1%20ddc90d46eeb94b00b49ef4ea6a9b3d79.md)

[3.2 Kabuk Komutları](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20ff17c999e406480bb8dd48cde60e4347/3%202%20Kabuk%20Komutlar%C4%B1%20cdb04179b6b04050a5d82abe28ecaa86.md)