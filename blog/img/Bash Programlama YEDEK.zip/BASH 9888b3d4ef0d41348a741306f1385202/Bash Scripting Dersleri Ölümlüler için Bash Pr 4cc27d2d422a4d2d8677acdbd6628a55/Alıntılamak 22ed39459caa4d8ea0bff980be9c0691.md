# Alıntılamak

[https://wiki.bash-hackers.org/syntax/quoting](https://wiki.bash-hackers.org/syntax/quoting)

Kabuk için özel anlam ifade eden çeşitli sembolleri ve karakterleri, özel anlamlarına genişletilmeden olduğu gibi kullanmak için alıntılama mekanizmalarını kullanabiliyoruz. 

Söz konusu alıntılama olduğunda üç tür alıntılama yönteminden bahsedebiliriz. Bunlar karakter bazında, zayıf ve güçlü alıntılama.

## Karakter Bazında Alıntılama | Kaçış Karakteri

Özel anlam ifade eden tek bir karakteri alıntılamak için karakterden önce ters taksim işaretini kullanıyoruz. Bu sayede istediğimiz spesifik karakter olduğu gibi alıntılanmış oluyor. Yani özel anlamına genişletilmiyor.

Aşağıdaki örneğe bakarak bu durumu teyit edebilirsiniz.

```bash
~ → echo "Ben $USER ve \$PWD konumundayım"
Ben root ve $PWD konumundayım
~ → echo "Ben $USER ve $PWD konumundayım"
Ben root ve /root konumundayım
```

Normalde dolar işareti ilgili değişkenin çağırılmasını sağlıyor. Ters taksim işareti sayesinde özel anlamının görmezden gelinmesini sağlayabiliyoruz.

## Zayıf Alıntı | Çift Tırnak Kullanımı

Zayıf alıntıda yani çift tırnak içerisine yazılmış olan **bazı ifadeler** bash üzerinde sahip oldukları anlamdan muaf tutulurlar. Yalnızca bazı özel karakterlerin alıntılanmasını sağladığı için çift tırnak ile yapılan alıntıya "zayıf alıntılama" da denebiliyor. Çift tırnak içerisinde, aşağıdaki yapılar özel anlamlarından muaf tutularak alıntılanabilir.

- Sözcük ayırmak için kullanılan boşluklar. - sözcük ayırma kısmına göz at
- Kullanılan tek tırnaklar.
- Desen eşleştirme karakterleri * {a..z} vb..
- Tilde genişletmesi
- Dosya Adı genişletmesi. {b*,c*,*est*}  t?.sh
- İşlem ikamesi

Örneğin değişkenler çift tırnak içinde genişletilirken, tilde genişletmesi yapılmadığını aşağıdaki çıktıları inceleyerek teyit edebilirsiniz.

Eğer çift tırnak içinde kaçış karakteri olan ters taksim işareti kullanılırsa;

Çift tırnak içerisinde genişletilen bir ifade ise o ifadenin özel anlamına genişletilmesini engeller. 

Eğer kaçış karakterinden sonra kullanılan ifade tırnak içinde özel anlamına genişletilen bir karakter değilse ters taksim işareti de olduğu gibi alıntılanır.

Kaçış karakterlerinin art arda kullanılması bir ters taksimin basılmasını da sağlar.

```bash
~ → echo "$PWD"
/root
~ → echo "\$PWD"
$PWD
~ → echo "\\$PWD"
\/root
~ → echo "\\abc"
\abc
~ → echo "\abc"
\abc
```

## Güçlü Alıntılama | Tek Tırnak

Bu alıntılama türünde tek tırnak içerisindeki hiç bir karakter özel olarak yorumlanmaz. Yani yazılı halleri ile oldukları gibi alıntılanırlar. Bash kabuğunda hangi özel anlama geldiklerinin bir önemi yoktur. 

```bash
~ → echo 'Ben $USER ~ !!'
Ben $USER ~ !!
```

## ANSI C Alıntılaması

Başında dolar işareti bulunan ve tek tırnak içerisinde yazılmış olan aşağıdaki ifadeler özel anlamlarına genişletilirler. Bu, özellikle bazı programlara, sed'e yeni bir satır iletmek gibi argüman olarak özel karakterler iletmek istediğinizde kullanışlıdır. Ortaya çıkan metin tek tırnaklıymış gibi değerlendirilir. Daha fazla genişleme olmaz.

[Untitled](Al%C4%B1nt%C4%B1lamak%2022ed39459caa4d8ea0bff980be9c0691/Untitled%20Database%20aedf520bdd7642d4a1f287f964eec107.md)

## Yerel Ayara Özgü Çeviri

Eğer dolar işaretinden sonra çift tırnak içerisinde bir ifade belirtildiyse bu ifade için var olan yerelleştirme uygulanır.

echo $"generating database..."

I18N anlamına gelir. Bu dizge için bir çeviri mevcutsa, verilen metin yerine kullanılır. Değilse veya yerel C / POSIX ise, dolar işareti basitçe yok sayılır, bu da normal çift tırnaklı bir dizeyle sonuçlanır.

I18N anlamına gelir. Bu dizge için bir çeviri mevcutsa, verilen metin yerine kullanılır. Değilse veya yerel C / POSIX ise, dolar işareti basitçe yok sayılır, bu da normal çift tırnaklı bir dizeyle sonuçlanır.

Kaçış Karakteri Tek bir karakterden özel anlam nasıl kaldırılır. 

Tek Tırnaklar Bir karakter dizisinin yorumlanması nasıl engellenir. 

Çift Tırnaklar Bir dizi karakterin yorumlanmasının çoğu nasıl engellenir. 

ANSI-C Alıntı Yapma ANSI-C dizileri alıntılanmış dizelerde nasıl genişletilir. 

Yerel Çeviri Dizeler farklı dillere nasıl çevrilir.

Örneğin bak bash kabuğunun Türkçe dil çevirisi: [https://translationproject.org/PO-files/tr/bash-5.1.tr.po](https://translationproject.org/PO-files/tr/bash-5.1.tr.po)

.po dosyası içerinde çevirilmiş ifadeler mevcut sistemdeki lokal dil ayarlarına göre ilgili dil dosyası üzerinden çevirinin yapılmasını sağlıyor.

## 3.1.2.1 Kaçış Karakteri

Tırnaksız şekilde kullanılmış olan test slash işareti, kendisinden sonra gelen karakterin gerçek değerini korur. Yalnızca yeni satıra geçme işlevi üzerinde etkili değildir. Bunun haricinde kabuk üzerinde özel anlam ifade eden karakterin olduğu gibi yazılı hallerinin kullanımına imkan tanır.

## 3.1.2.2 Tek Tırnak

Terk tırnak içerisine yazılan ifadelerin hepsi özel anlamları göz ardı edilerek yalnızca yazılı ifadeler olarak ele alınırlar. Hatta ters tırnak işareti bile bu yolla yazılı ifade olarak ele alınabilir.

## 3.1.2.3 Çift Tırnak

Çift tırnak içerisine alınmış kabuk üzerinde özel anlam ifade eden karakterler özel anlamlarını korumaya devam ederler. Çift tırnak grup halinde bu özel karakterin kullanılmasına imkan tanır.

## **3.1.2.4 ANSI-C Alıntısı**

Formdaki kelimeler özel olarak ele alınır. Kelime , ANSI C standardında belirtildiği gibi ters eğik çizgi kaçış karakterleri değiştirilerek *dizeye* genişler . Varsa ters eğik çizgi kaçış dizilerinin kodu şu şekilde çözülür: `$'*string*'`

**`\a`**uyarı (zil)**`\b`**geri tuşu**`\e\E`**bir çıkış karakteri (ANSI C değil)**`\f`**form besleme**`\n`**Yeni hat**`\r`**satırbaşı**`\t`**yatay sekme**`\v`**dikey sekme**`\\`**ters eğik çizgi**`\'`**tek alıntı**`\"`**çift tırnak**`\?`**soru işareti**`\*nnn*`**değeri sekizlik değer *nnn* olan sekiz bitlik karakter (bir ila üç sekizlik basamak)**`\x*HH*`**değeri onaltılık *HH* değeri olan sekiz bitlik karakter (bir veya iki onaltılık rakam)**`\u*HHHH*`**Değeri onaltılık *HHHH* değeri olan Unicode (ISO / IEC 10646) karakteri (bir ila dört onaltılık basamak)**`\U*HHHHHHHH*`**Değeri onaltılık *HHHHHHHH* (bir ila sekiz onaltılık basamak) olan Unicode (ISO / IEC 10646) karakteri**`\c*x*`**bir kontrol- *x* karakteri

Genişletilmiş sonuç sanki dolar işareti yokmuş gibi tek tırnaklıdır.

## **3.1.2.5** Yerel Ayara Özgü Çeviri

A double-quoted string preceded by a dollar sign (‘$’) will cause the string to be translated according to the current locale. The *gettext* infrastructure performs the message catalog lookup and translation, using the `LC_MESSAGES` and `TEXTDOMAIN` shell variables, as explained below. See the gettext documentation for additional details. If the current locale is `C` or `POSIX`, or if there are no translations available, the dollar sign is ignored. If the string is translated and replaced, the replacement is double-quoted.

Some systems use the message catalog selected by the `LC_MESSAGES` shell variable. Others create the name of the message catalog from the value of the `TEXTDOMAIN` shell variable, possibly adding a suffix of ‘.mo’. If you use the `TEXTDOMAIN` variable, you may need to set the `TEXTDOMAINDIR` variable to the location of the message catalog files. Still others use both variables in this fashion: `TEXTDOMAINDIR`/`LC_MESSAGES`/LC_MESSAGES/`TEXTDOMAIN`.mo.