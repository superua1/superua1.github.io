# 3- Değişkenler

# Değişkenler

Bu kısımda değişkenleri ele alacağız, peki ama nedir bu değişkenler ?

Kısaca değişkenler; bir isime(değişken ismi) karşılık olarak, içerisinde çeşitli verileri barındıran ve gerektiğinde değiştirilebilir olan veri tutucu yapılardır. Biz bir değişkene değer(veri) atayarak o değeri tekrar tekrar tanımlamak yerine tek bir değişken üzerinden istediğimiz zaman ulaşabiliyoruz. Eğer bu tanım yeterince açık gelmediyse sorun yok, konuyu örnekler ile ele aldıkça tam olarak ne demek istediğimi anlıyor olacaksınız.

Hemen basit bir örnek ile açıklamaya başlayalım;

Değişken tanımlarken öncelikle değişken adını girerek eşittir işaretini koyduktan sonra, değişkene atamak istediğimiz değeri tırnak işareti içerisine yazmamız gerekiyor.

Örneğin ben `sistem="linux"` şeklinde yazarsam, **sistem** isimli değişkene "**linux**" değerini atamış oluyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/1.png)

Değişkenin tanımlanıp tanımlanmadığını hemen konsol üzerinden çağırarak kontrol edelim. Tanımladığımız herhangi bir değişkeni çağırırken `echo $degisken` şeklinde komut girmemiz yeterli oluyor. Yani değişkenimizi dolar işareti '$' ile çağırmış oluyoruz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/2.png)

Bizim tanımladığımız değişken **sistem** isimli değişken olduğu için konsola `echo $sistem` komutunu girdiğimde, gördüğünüz gibi karşıma "**linux**" ifadesi basılmış oldu.

Bir örnek daha yapalım ve bu sefer değişkenimize, değer olarak sayı atayalım. Bunun için `rakamlar="12345"` ifadesini konsola giriyorum ve `echo $rakamlar` komutu ile atadığım değişkene ulaşıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/3.png)

İşte değişken tanımlamak bu kadar basit. Ancak yine de değişken tanımlarken dikkat etmemiz gereken önemli birkaç detay bulunuyor. Örneğin biraz önce rakamlar değişkenine girdiğimiz sayılar aslında sayısal değer ifade etmiyor. Yani bu sayılar aslında yalnızca "string" olarak geçen karakter dizesidir. Bu konudan anlatımın devamında zaten ayrıca bahsediyor olacağız. Şimdi dikkat etmemiz gereken detayları açıklayarak devam edelim.

## Değişken Tanımlanırken Dikkat Edilmesi Gerekenler

- Değişken isimleri tanımlarken **Türkçe karakter kullanmadan** alfanümerik(**A-Z, a-z,0-9**) karakter kullanmamız gerekiyor.

Örneğin içerisinde Türkçe karakter geçen, `çalı="bitki"` gibi bir değişken tanımlamak istersem, konsol bana çıktı olarak "**komut yok**" hatasını basıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/4.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/4.png)

Bu durumun nedeni, değişken tanımlarında Türkçe karakter kullanımının geçersiz olmasıdır. Bu kullanımın doğrusu Türkçe karakter içermeyen `cali="bitki"` şeklinde olabilir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/5.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/5.png)

- Türkçe karakter dışında, değişken ismi tanımlarken **alt tire işareti haricinde** herhangi bir sembol kullanımı da hataya yol açmaktadır.

Örneğin ben `yeni-yeni="yeni değer"` gibi bir değişken tanımlamaya kalkarsam , konsol bana çıktı olarak "**komut yok**" hatasını basacaktır.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/6.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/6.png)

Hata alma sebebimiz elbette değişken isminde geçen **tire**(kısa çizgi****) işaretidir.

Şimdi aynı örneği **alt tire** işareti ile tekrar deneyerek bu durumu teyit edelim. Bunun için konsola `yeni_yeni="yeni değer"` ifadesini yazıyorum ve tanımladığım değişkeni `echo $yeni_yeni` komutunu girerek sorguluyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/7.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/7.png)

Ve gördüğünüz gibi değişken başarılı şekilde tanımlanmış bulunuyor.

Tekrar belirtmiş olalım, hatalı bir kullanıma yol açmamak adına değişken tanımlarken **alt tire işareti haricinde hiç bir sembol kullanılmamalıdır**. Yani "**yeni+yeni", "yeni#yeni", "yeni@yeni"** ve benzeri tüm kullanımlar hatalıdır.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/8.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/8.png)

- Dikkat etmemiz gereken bir diğer husus ise tanımlanacak değişken isimlerinin **kesinlikle rakam ile başlamamasıdır**. Başlangıcı hariç, değişken isimlerinde rakam kullanılabilir.

Yani örneğin herhangi bir değişken tanımlarken "**1kitap"** hatalı bir kullanım iken "**kitap1"** ya da "**kit1ap"** doğru kullanıma örnektir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/9.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/9.png)

Rakam başta olmadığı sürece tüm kombinasyonlar rakam kullanımına uygundur.
("**k1itap", "ki2tap", "kit3ap", "kita44p", "kitap555"** vb.)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/10.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/10.png)

- Bir başka dikkat edilmesi gereken ayrıntı da; değişken isimlerinin **büyük küçük harf duyarlılığına** sahip olduğudur.

Örneğin tamamı büyük harflerden oluşan `TEST="ilk ifade"` şeklindeki bir tanım ile tamamı küçük harflerden oluşan `test="ikinci ifade"` tanımı, bash diline göre iki farklı değişkeni temsil eder. Hemen `echo` komutu yardımıyla bu durumu teyit edelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/11.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/11.png)

Gördüğünüz gibi aynı isime sahip olan biri küçük diğeri büyük harflerden oluşan iki değişken, sistem tarafından iki farklı değişken olarak algılanarak konsola ayrı ayrı çıktılar basmış oldu.

- Değişken tanımlarken **eşittir**(**=**) işaretinin **sağında ve solunda boşluk olmamasına** dikkat etmemiz gerekiyor. Aksi takdirde bash kabuğu bizim değişken tanımlamak istediğini anlayamadığından, kaçınılmaz olarak konsola "**komut yok**" şeklinde hata çıktısı basıyor.

**Aşağıdaki kullanımlar yanlış kullanımlara örnektir.**

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12.png)

Ayrıca değişkenlerin değerini belirtirken kullandığımız tırnak işaretleri, değerin birden fazla kelime bütünü içerdiği durumda sistem tarafından **değerin tamamının** doğru algılanabilmesi adına çok önemlidir. Yani örneğin ben `kalem="kırmızı"` ya da `kalem1=mavi` şeklinde değişken tanımlayabilirim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12-1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12-1.png)

Fakat değerin `kalem="kırmızı pilot"` gibi daha fazla öge içerdiği durumlarda mutlaka tırnak içerisinde yazılması gerekiyor. Bu durumu aşağıdaki çıktılara göz atarak teyit edebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12-2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/12-2.png)

Hatırlarsanız konu anlatımının başında değişken değerlerinin gerektiğinde değiştirilebileceğinden bahsetmiştik. Bu da eğer bizler herhangi bir kısıtlama getirmezsek, sürekli olarak değişkenlerin üzerine yeni değerler yazılabileceği anlamına geliyor. Bu durumu daha iyi anlamak adına `spor="tenis"` komutu ile **spor** isimli bir değişken tanımlayalım ve `echo $spor` komutu ile değişkenimizi çağıralım.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/13.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/13.png)

Gördüğünüz gibi bu şekilde **spor** isimli değişkeni ne zaman çağırsam karşıma **tenis** değeri basılmış oluyor. Ancak değişkenin değerini özellikle sabitlemediğimiz sürece, istenildiği zaman bu değer değiştirilebilir. Değişken değerini değiştirmek için aynı isimli değişkeni farklı bir değer ile tekrar tanımlamamız yeterli oluyor.

Hemen aynı değişkeni bu sefer **futbol** değeri ile tanımlayıp, bu durumu teyit edelim. Konsola `spor="futbol"` şeklinde yazıyorum ve `echo` komutu ile değişkenimin yeni değerini teyit ediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/14.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/14.png)

Gördüğünüz gibi önceleri **spor** değişkenini çağırdığımda karşıma **tenis** değeri basılıyorken, değişkenimizi tekrar tanımlamamız yani diğer bir deyişle üzerine yeni değer yazmamız sonucu, aldığımız çıktı **futbol** olarak değişmiş oldu.

İlerleyen kısmlarda değiştirilemez(sabit(readonly)) değişkenler tanımlama konusuna da ayrıca değiniyor olacağız. Ancak şimdilik, basit değişken tanımlama işlemleri ile yapılan tanımlamaların değiştirilebilir değerler aldığını lütfen unutmayın.

Değişkenler yeniden tanımlanabildiği için sistemin çalışmasında rol oynayan, varsayılan olarak tanımlanmış olan değişkenlerle aynı isimlere sahip yeni değişkenler oluşturmama konusunda da dikkatli olmamız gerekiyor. Eğer farkında olmadan sisteme ait değişkenleri yeniden tanımlarsanız, sistemin işleyişi ile ilgili pek çok soruna neden olabilirsiniz. Bu sebeple, tanımlayacağınız değişkenin daha önce kullanılıp kullanılmadığından tam olarak emin değilseniz, değişkeninizi tanımlamadan önce sistem üzerinde var olup olmadığını kontrol etmenizde fayda var.

Konsola `echo` yazıp `$` işareti koyduktan sonra <kbd>**Tab**</kbd> tuşuna basarak tanımlı tüm değişkenleri listeleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/15.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/15.png)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/16.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/16.png)

Bu sayede halihazırda sistemde tanımlı olan değişkenlere müdahale etmeden daha bilinçli şekilde yeni değişkenler tanımlayabilirsiniz.

Kimi zaman var olan değişken değerlerini silmeden, değişken değerine ekleme yapmak da isteyebiliriz. Örneğin tanımlamış olduğum `ben="taylan"` şeklindeki değişken değerine ekleme yapmak istersem, önceki değişkeni de yeni tanımlamaya dahil etmem yeterli oluyor.

```
ben="yeni değer" $ben
ben="yeni değer $ben"
```

Yukarıdaki kullanım, "**ben**" değişken değerinin başına "**yeni değer**" ifadesini eklemenin iki farklı yolunu gösteriyor. Bu şekilde yeni değerleri önceki değerlerin başına, sonuna, ortasına ya da istediğimiz herhangi bir kısmına ekleyebiliyoruz.

```
ben="$ben yeni değer" 
ben="yeni $ben değer"
```

# Sınıfına Göre Değişken Tanımlamak

Şimdiye kadar pek çok değişken tanımladık ancak tanımladığımız değişkenler herhangi bir sınıfta yer almıyordu. Buradaki sınıftan kastım, tanımladığımız değişkenin hangi türden veriyi içerisinde barındırabileceğinin belirli olmasıdır. Yani örneğin değişken sayısal bir değişken mi olacak, yoksa bir diziyi mi temsil edecek ya da değişkenimiz sabit değerli mi olacak henüz bunlardan bahsetmedik. 

Değişkenlerin belirli türlerde değer almasını sağlamak için `declare` ya da `typeset` komutlarından birini kullanabiliriz. Her iki komut da aynı işlevi görüyor. Aralarındaki tek fark `typeset` komutunun daha eski sürümlerden beri destekleniyor olup `declare` komutunun daha yeni olmasıdır. Eğer çok eski bash kabuğunda çalıştırılma ihtimali olan kabuk dosyaları oluşturuyorsanız, uyum sorunu yaşamamak için `typeset` komutunu tercih edebilirsiniz. Eski sürümlerde çalışmak gibi bir hedefiniz yoksa, `declare` komutunun bash programlama konusunda daha sık kullanıldığını bilmenizi isterim. Buradaki anlatımları `declare` komutu üzerinden ele alacağız fakat sizler `typeset` komutunu da kullanabilirsiniz. Aşağıdaki tablodan komutun sahip olduğu seçeneklere ve yerine getirebildiği işlevlerine göz atabilirsiniz.

### Temel Seçenekler

`-f` : Tanımlı olan fonksiyonları işlev tanımlarıyla birlikte bastırır.

`-F` : Tanımlı olan fonksiyon isimlerini bastırır.

`-g` : Fonksiyonlar içerisinde kullanıldığında, global değişken tanımlamayı sağlar.

`-p` : Argüman olarak verilmiş ifadelerin değerlerini ve özniteliklerini bastırır. 

Temel seçenekler haricinde, belirli özelliklerde değişkenler tanımlamak istersek, öznitelik seçenekleri ile istediğimiz türde değişken tanımlaması yapabiliriz. 

### Öznitelik Seçenekleri

`-a` : Dizi tanımlama işlevindedir. array(dizi) ifadesinin kısaltmasıdır.

`-A` : İlişkisel dizi tanımlama işlevindedir.

`-i` : Sayısal değişken tanımlama işlevindedir. integer(tam sayı) ifadesinin kısaltmasıdır.

`-l` : Değişken değerinde yer alan ifadelerin hepsinin küçük harflerle değişmesini sağlar.

`-u` : Değişken değerinde yer alan ifadelerin hepsinin büyük harflerle değişmesini sağlar.

`-n` : Argüman olarak verilen değeri referans değişkenin değeri olarak tanımlar.

`-r` : Sabit değişken atama işlevindedir. readonly(yalnızca okunabilir) ifadesinin kısaltmasıdır.

`-t` : Argüman olarak verilen değişkene "takip" özniteliği ekler.

`-x` : Değişkeni export(ihraç) ederek, alt kabuklara aktarma işlevindedir.

`declare` komutunu kullanıyorken; eğer değişkenlere özellik eklemek istiyorsak `-` "eksi" işaretini, şayet var olan özellikleri çıkarmak istiyorsak da `+` "artı" işaretini, eklemek ya da çıkarmak istediğimiz özelliğin kısaltmasını da belirterek kullanmamız gerekiyor. Artı ve eksi işaretlerinin kullanımı başlangıçta ters gibi gelse de kısa sürede kullanımına alışacaksınız. Şimdi örnekler üzerinden anlatımlara devam edelim.

## Sayısal Değişken Tanımlamak

Anlatımlara ilk olarak sayısal değişken tanımlama işlemi ile başlayalım.

Sayısal değişken tanımlamak için konsola `declare -i değişken="sayi_değeri"` şeklinde komutumuzu girmemiz gerekiyor.

Ben **9** değerine sahip **rakam** isimli bir sayısal değişken tanımlamak istediğim için konsola `declare -i rakam="9"` komutumu giriyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/17.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/17.png)

Böylelikle **rakam** isimli sayısal değişkenime **9** rakamını atamış oldum ve bu değişkenim ben aksini istemedikçe yalnızca sayısal ifadeler alan bir değişken olarak sınıflandırılmış oldu. Bu durumu teyit etmek için öncelikle değişkenimin sınıfını sorgulamak üzere `declare` komutunun "**p"** seçeneğini kullanarak `declare -p rakam` komutunu giriyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/18.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/18.png)

Sizlerin de gördüğü gibi konsol bana çıktı olarak `declare -i rakam="9"` şeklinde bir çıktı bastı. Bu çıktı ile değişkenimizin sayısal bir değişken olduğunu teyit etmiş olsak da kesin olarak emin olmak adına, değişkenimize sayısal değerlerin dışında herhangi bir değer atamaya çalışarak bu durumu netleştirelim.

Bunun için konsola `rakam="test"` komutumu girdikten sonra, değişkenimin durumunu sorgulamak üzere `declare -p rakam` komutunu kullanıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/19.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/19.png)

Gördüğünüz gibi çıktıda rakam değişkenimin değeri "**0**" olarak karşıma gelmiş oldu. Bunun nedeni değişkenime sonradan atamaya çalıştığım "**test**" ifadesinin sayısal bir karşılığının olmamasıdır.

Hatırlarsanız değişken tanımlama anlatımlarının başında **rakamlar** isimli değişkene **12345** ifadesini atamış ve bu değişkenimizi bastırmıştık. Şimdi aynı değişkeni atayıp değerini "**test**" ifadesi ile değiştirerek, sayısal değer alma özelliği olan değişkenler ile sıradan değişken arasındaki farkı görelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/20.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/20.png)

Gördüğünüz gibi sayısal özellik atamadığım değişkenin içeriğindeki sayısal veriler kolaylıkla değişmiş oldu. Böylelikle "sayısal değişken" ile "sıradan değişken" tanımlamanın farkını kıyaslayarak görmüş olduk.

Ancak tanımladığımız sayısal değişkenler her zaman sayısal değişken olarak kalmak zorunda da değil. Değişkenimizin sınıfını tekrar eski hale getirmek istersek ekleme işleminde kullandığımız ****eksi işareti yerine bu sefer artı işaretini kullanmamız yeterli oluyor. Yani ben **rakam** isimli sayısal değişkenimin, sayısal değişken tutma özelliğini kaldırmak istersem; konsola `declare +i rakam` şeklinde komut girmem yeterli oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/21.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/21.png)

Bu şekilde, `declare` komutunu kullanarak istediğimiz değişkene "sayısal değişken" özelliğini ekleyip çıkartabiliyoruz.

## Dizi Tanımlamak

Birden fazla değeri tek bir değişken içerisine toparlamak istediğimizde dizileri kullanabiliriz.

Dizi tanımlamak için `declare` komutunun `a` seçeneğini `declare -a dizi=(değer1 değer2 değer3)` şeklinde kullanmamız gerekiyor.

Ayrıca `declare` komutunu kullanmadan, dizide yer alacak ifadeleri parantez içine `dizi=(değer1 değer2 değer3 )` şeklinde alarak da dizi belirtebiliyoruz. Buradaki parantezler o değişkenin bir dizi olduğunu otomatik olarak belirtmiş oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/22.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/22.png)

Dizilerin kullanımına en basit örnek alışveriş listesi olarak verilebilir.

Örneğin ben **liste** isimli bir değişken tanımlayıp, bu değişkenin içerisine istediğim sayıda değer atayabilir ve atadığım değerleri tek tek çağırabilirim. Örnek olması için; konsola `liste=(su süt çay elma ekmek)` şeklinde komutumu girerek, **liste** isimli değişkene birden fazla değer atamış oluyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/23.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/23.png)

Böylelikle her bir değere **0 dan başlayarak** sırasıyla birer index numarası atanmış oldu. Yani örneğin "**su"** ifadesi ilk değer olduğu için "**0"** index numarasını almışken, 3. sıradaki "**çay"** değerinin index numarası "**2"** olmuş oldu.

Bizler de sıralı şekilde atanan bu index değerleri sayesinde istediğimiz değerleri diziden çağırabiliyoruz. Örneğin dizide yer alan ilk değeri çağırmak istersem, konsola `echo ${liste[0]}` komutunu girmem yeterli oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/24.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/24.png)

Gördüğünüz gibi "**0"** index numarası ile ilk değerimizi ekran bastırmış olduk.

Dizedeki değerleri bastırma işlemini aynı şekilde tüm değerlerimizi tek tek elde etmek için de kullanabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/25.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/25.png)

Eğer tüm değişkenleri tek seferde bastırmak istersek "yıldız" `*` ya da "at" `@` işaretlerinden birini kullanabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/26.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/26.png)

Ayrıca anlatım sırasında kullanmış olduğumuz süslü parantezler hakkında da kısaca açıklama yapmak istiyorum. Söz konusu değişkenler üzerinde işlem yapmak olduğunda süslü parantezler değişkenler üzerinde işlem yapmayı mümkün kılıyor. Süslü parantezlerin gerekli olup olmadığını anlamak üzere süslü parantez olmadan komut girmeyi deneyebilirsiniz.

Çıktılardan da görebileceğiniz gibi süslü parantez olmadığında değişkenler üzerinde harici işlem yapmamız mümkün olmuyor. Süslü parantezler değişkenin yapılacak işlem kapsamına alınmasını sağlıyor.

## İlişkisel Dizi Tanımlamak

İlişkisel diziler, bizim belirleyeceğimiz ifadeler ile ilişkili dizi elemanları tanımlamamıza olanak sağlarlar. Normalde her bir dizi elemanı yalnızca index numarası ile çağırılabilir. Fakat ilişkisel dizilerde, ilgili elaman ilişkili olduğu ifade ile çağırılır. Örnek üzerinden bu duruma açıklık getirmeye çalışalım.

Tanımlama işlemi için dizi elamanı ile eşleştirilecek ifadeyi köşeli parantez içerisinde belirtmemiz yeterli oluyor.

```bash
taylan@taylan:~$ declare -A dizi=( [ad]=ahmet [soyad]=yılmaz [yas]=25 [konum]=istanbul )
taylan@taylan:~$ echo ${dizi[ad]}
ahmet
taylan@taylan:~$ echo ${dizi[yas]}
25
taylan@taylan:~$ echo ${dizi[*]}
istanbul yılmaz ahmet 25
taylan@taylan:~$
```

Biz tek seferde tanımlama yaptık fakat dilersek tek tek de ilişkisel dizi tanımlamamız mümkündür. Tanımlamalarımızın ilişkisel olarak algılanması için öncelikle değişkeni `declare` komutu ile ilişkisel özniteliğe kavuşturuyoruz. Ardından istediğimiz değerleri tanımlamamız mümkün oluyor.

```bash
taylan@taylan:~$ declare -A yeni_dizi
taylan@taylan:~$ yeni_dizi[ilk]=deger
taylan@taylan:~$ yeni_dizi[ikinci]=deger2
taylan@taylan:~$ declare -p yeni_dizi 
declare -A yeni_dizi=([ilk]="deger" [ikinci]="deger2" )
taylan@taylan:~$ echo ${yeni_dizi[ilk]}
deger
taylan@taylan:~$
```

Eğer herhangi bir değişkeni `declare -A` komutuyla ilişkisel dizi olarak özellikle tanımlamazsak, ilgili değişken ilişkisel değerler almayacaktır.

```bash
taylan@taylan:~$ isimler[ilk]=hasan
taylan@taylan:~$ isimler[ikinci]=funda
taylan@taylan:~$ declare -p isimler 
declare -a isimler=([0]="funda")
taylan@taylan:~$ echo ${isimler[ilk]}
funda
taylan@taylan:~$ echo ${isimler[ikinci]}
funda
taylan@taylan:~$ echo ${isimler[*]}
funda
taylan@taylan:~$ isimler=( [ilk]=hasan [ikinci]=funda ) 
taylan@taylan:~$ declare -p isimler 
declare -a isimler=([0]="funda")
taylan@taylan:~$ echo ${isimler[*]}
funda
taylan@taylan:~$
```

Çıktıları incelediğimizde, değişken değerine ilişkisel dizi özniteliği tanımlanmadığı sürece standart bir değişken olarak ele alındığını teyit edebiliyoruz. 

Tüm bunlara ek olarak tıpkı ilişkisel dizilerde olduğu gibi aslında dilersek normal dizilerin index numarasını da özellikle belirtebiliriz. Normal şartlarda sizlerin de gözlemlediği gibi, dizi elemanları 0 dan başlayarak sıralı şekilde index numarasına sahip olur. Ancak bizler ilişkisel dizilerde olduğu gibi eğer index numaralarını dizi elemanları ile ilişkilendirirsek, ilgili elemanlar bizim tanımladığımız değerlere sahip olurlar. Denemek için standardın dışında 3 5 ve 7 index numaralı dizi elemanları tanımlayalım. Tanımlama işleminin ardından dizinin özelliklerini bastıralım.

```bash
taylan@taylan:~$ dizi=([3]="ilk eleman" [5]="ortanca eleman" [7]="son eleman")
taylan@taylan:~$ declare -p dizi
taylan@taylan:~$ declare -a dizi=([3]="ilk eleman" [5]="ortanca eleman" [7]="son eleman")
```

Çıktılardan da teyit edebileceğiniz gibi yeni dizi elemanları bizim belirttiğimiz index numaralına sahip. Bu özellik genelde dizi tanımlamak için değil, daha çok var olan dizi elemanlarını tek tek değiştirebilmek için kullanılıyor. Yani tüm diziyi yeniden tanımlamak yerine aşağıdaki şekilde belirteceğimiz index numarasındaki dizi elemanını doğrudan değiştirmemiz de mümkündür.

```bash
taylan@taylan:~$ declare -p dizi
taylan@taylan:~$ declare -a dizi=([3]="ilk eleman" [5]="ortanca eleman" [7]="son eleman")
taylan@taylan:~$ dizi[5]="ben yeni eleman"
taylan@taylan:~$ declare -p dizi
taylan@taylan:~$ declare -a dizi=([3]="ilk eleman" [5]="ben yeni eleman" [7]="son eleman")
```

Çıktıları incelediğimizde spesifik olarak index numarasını belirttiğimiz dizi elemanını değiştirmiş olduğumuzu teyit edebiliyoruz.

## Değişken Değerinin Küçük ve Büyük Karakterlere Dönüştürülmesi

Değişken tanımlandıktan sonra değişkene atanan değerlerin tamamının küçük veya büyük harflerden oluşmasını sağlamamız mümkündür. Küçük harflerden oluşması için ingilizce "lower" ifadesinin kısaltmasını yani `-l` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ declare -l metin
taylan@taylan:~$ metin="Ben Bir DENEME metniyim"
taylan@taylan:~$ echo $metin
ben bir deneme metniyim
```

Benzer şekilde daha sonra atanacak olan değişken değerinin tamamının büyük harflerden oluşması için ingilizce "upper" ifadesinin kısaltmasını yani `-u` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ declare -u metin 
taylan@taylan:~$ metin="Ben Bir DENEME metniyim"
taylan@taylan:~$ echo $metin
BEN BİR DENEME METNİYİM
```

Burada dikkat etmeniz gereken detay ilgili değişkenin küçük ya da büyük harflere dönüştürme özniteliğinin, henüz değişkene değer vermeden yapılmasıdır. Yani eğer mevcut değişkenin sahip olduğu bir değer varsa bu özellikleri değiştirmek, ilgili değişkenin sahip olduğu değeri değiştirmez. Aşağıdaki çıktıya bakarak bu durumu kendiniz de teyit edebilirsiniz.

```bash
taylan@taylan:~$ declare -p metin 
declare -u metin="BEN BİR DENEME METNİYİM"
taylan@taylan:~$ declare -l metin 
taylan@taylan:~$ echo $metin 
BEN BİR DENEME METNİYİM
taylan@taylan:~$ declare -p metin 
declare -l metin="BEN BİR DENEME METNİYİM"
```

## Mevcut Olan Değişken Değerini Korumak

Daha öncesinden ilgili değişkene bir değer tanımlandıysa bu değerin korunmasını, aksi halde bizim belirttiğimiz yeni değerin atanmasını isteyebiliriz. Bu sayede geçmişte tanımlanmış olan değişken değerlerine istemeden zarar vermemiş oluruz. 

Bu işlem için `VARIABLE=${USER_VAR:-default}` sentaksı kullanılır. Aşağıda bir örnek gösterilmiştir.

![https://miro.medium.com/proxy/1*_cacG4EyEjZrKc1pCDyzNw.png](https://miro.medium.com/proxy/1*_cacG4EyEjZrKc1pCDyzNw.png)

## Hata Ayıklama için Değişkenleri İşaretlemek

Eğer değişkenler özel olarak işaretlenmezse, değişkenlerin hata ayıklama aşamasında takip edilmesi mümkün olmaz. Bu özellik genelde ilgili değişkenin hataya yol açıp açmadığını teyit etmek için kullanılır. Bu kullanımı şimdi açıklasam bile henüz öğrenmediğimiz hata ayıklama yapısı sebebiyle anlaşılması güç olacaktır.  Bu konudan yeri geldiğinde ayrıca bahsediyor olacağız.

## Değişkenlere Referans Vermek | Değişkenleri Bağlamak

Mevcut değişkeni başka bir değişkene referans olarak gösterebiliriz. Bu sayede ilgili değişkenin değeri her iki değişken için de bağlantılı şekilde aynı olur. Daha iyi anlamak adına basit bir örnek yapalım.

```bash
taylan@taylan:~$ ref="ben referans"
taylan@taylan:~$ declare -n degisken=ref 
taylan@taylan:~$ echo $ref $degisken 
ben referans ben referans
taylan@taylan:~$ degisken="yeni değer"
taylan@taylan:~$ echo $ref $degisken 
yeni değer yeni değer
taylan@taylan:~$ ref="yeni referans"
taylan@taylan:~$ echo $ref $degisken 
yeni referans yeni referans
```

Görebildiğiniz gibi her iki değişkendeki değişiklikler de aynı anda birbirilerini etkiliyor. Aynı örneği referans göstermeden yani `-n` seçeneği olmadan deneyelim.

```bash
taylan@taylan:~$ ref="referans değeri"
taylan@taylan:~$ declare degisken=ref
taylan@taylan:~$ echo $ref $degisken 
referans değeri ref
taylan@taylan:~$ degisken="yeni değişken"
taylan@taylan:~$ echo $ref $degisken 
referans değeri yeni değişken
taylan@taylan:~$ ref="yeni referans"
taylan@taylan:~$ echo $ref $degisken 
yeni referans yeni değişken
taylan@taylan:~$
```

## Sabit Değişken Tanımlamak

Şimdi ise tanımladığımız değişken değerinin, değiştirilemez şekilde sabit kalmasını nasıl sağlarız bunu görelim. Bu işlem için `readonly` komutunu ya da `declare` komutunun `r` parametresini kullanabiliyoruz.

Örneğin ben **sabit** isimli bir değişkenin değerini sabitlemek üzere konsola `readonly sabit="sabit değer"` şeklinde komutumu giriyorum. Daha sonra atadığım sabit değişkenin özelliklerini bastırarak ve mevcut değerini değiştirmeye çalışarak, değerin gerçekten sabit olup olmadığını teyit etmeye çalışıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/31.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/31.png)

Ve gördüğünüz gibi **sabit** isimli değişkenimin özelliklerinde yer alan `r` ifadesi bu değişkenin değiştirilemez olduğunu açıkça belirtiyor. Ayrıca değeri sabit olduğu için içerisine yeni bir değer ataması da gerçekleştiremedik.

Bu kullanıma alternatif olarak biliyorsunuz ki sabit değer atama işlemini `readonly` komutu yerine, `declare` komutu ile de gerçekleştirebilirdik. Hemen bu şekilde de bir örnek yapmak adına konsola `declare -r sabit1="sabit değer 1"` şeklinde de komutumu girip değişkenimin özelliğini `p` parametresi ile teyit ediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/32.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/32.png)

Son olarak bu değerimi de değiştirmeye çalışarak değişkenimin sabit olup olmadığını teyit ediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/33.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/33.png)

Ve yine gördüğünüz gibi atadığımız değişken sabit olduğundan yeni bir değer atanamadı.

**Sabit değişken tanımlarken dikkat edilmesi gereken nokta, sabit değişkenlerin bir kez tanımlandıktan sonra kesinlikle silinip değiştirilemeyeceğidir**. Sabit değişken bir kez tanımlandıktan sonra sabit şekilde kalır.
Bu durumu teyit etmek için değişkenimizin sabitlik özelliğini `declare +r` komutu ile kaldırmayı deneyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/34.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/34.png)

Komutumuzu girdik ancak gördüğünüz gibi değişken sabit değere sahip olduğundan konsol bu işlemin mümkün olmadığını belirtiyor. Peki ama sabit değişkenler gerçekten sonsuza kadar tanımlandığı şekilde mi kalıyor ?

Aslında bu durum; yalnızca değişkenin tanımlandığı konsol ekranı için geçerli olduğundan, konsol kapatıldığında tanımlanan tüm değişkenlerle birlikte sabit değişkenlerin de sıfırlanmış oluyor. Bu durumun daha net anlamak için lütfen okumaya devam edin.

# Değişkenlerin export Edilmesi

Bu kısma kadar temel olarak değişkenleri nasıl tanımlayabileceğimizden ve tanımlama yaparken nelere dikkat etmemiz gerektiğinden bahsettik. Ancak henüz değinmediğimiz ve önemli olan başka bir konu da; değişkenlerin **export** edilmediği sürece yalnızca tanımlandıkları kabuk üzerinden çağrılabiliyor olduklarıdır.

Örneğin bir betik dosyasını çalıştırdığımızda mevcut **kabuk**(**shell**) bu işlem için **çatallama**(**fork**) yaparak bir **alt kabuk**(**subshell**) oluşturur ve betiği bu alt kabukta çalıştırır. Daha sonra görev tamamlanınca alt kabuk öldürülerek ana kabuğa dönülür. Böylelikle tek bir kabuk altında birden fazla alt kabuk oluşturularak aynı anda pek çok işlemin gerçekleştirilmesi mümkün kılınır.

Kabuğun çalışma yapısını daha iyi anlamak adına aşağıdaki örnek çalışma şablonuna göz atabilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/alt-kabuk.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/alt-kabuk.png)

Yani aslında, konsolu açtığımızda bize bir ana kabuk tahsis ediliyor. Daha sonra yaptığımız tüm işlemler için bu ana kabuğun altında, alt kabuklar oluşturularak çoklu işlemlerin gerçekleştirilebilmesine olanak sağlanıyor.

Örneğin ben iki adet konsol ekranı açıp; bir konsol üzerinde [betik.sh](http://betik.sh/) isimli dosyayı çalıştırmak, diğer konsol ekranında ise `whoami` komutunu çalıştırmak istediğimde, aslında arka planda gerçekleşen işlemler temel olarak aşağıdaki şekildedir.(Şema yanlış düzgününü ekle ama şema yapısını unutmaman için burada beklesin)

[https://drive.google.com/file/d/1qY9Dqu-zC9n07bYQALLHfvjps-eNop4Z](https://drive.google.com/file/d/1qY9Dqu-zC9n07bYQALLHfvjps-eNop4Z)

İşte kabuğun çalışma yapısı böyle olduğundan, bizler herhangi bir değişken tanımladığımızda bu değişkenin alt kabuklarda da tanınmasını istiyorsak mutlaka `export` komutu ile değişkenimizi alt kabuklara ulaştırmamız gerekiyor. Bu yaptığımız işlem diğer bir deyişle, mevcut kabukta geçerli olan değişkenlerin alt kabuklar için "çevresel değişkenlere" dönüştürülmesidir. Çevresel değişkenler konusunu ilerleyen kısımlarda ayrıca ele alacağız. Şimdilik sadece alt kabuk kavramını ve `export` işleminin önemini daha net anlamak adına basit bir test gerçekleştirelim.

Test için, çalışmakta olduğum kabuk üzerinde `degisken="yeni değer"` şeklinde bir değişken tanımlayıp konsola bastırıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/35.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/35.png)

Değişken tanımlarken kullanmakta olduğumuz aynı kabuk üzerinde değişkenimizi kolaylıkla bastırdık. Şimdi de aynı değişkeni betik dosyası içerisinden çağırarak bastırmayı deneyelim. Bu işlem için **[test.sh](http://test.sh/)** isimli bir betik dosyası oluşturuyorum. Oluşturduğum betik dosyası içerisine, betik dosyasının dışında tanımlamış olduğum değişkeni çağırmak üzere `echo $degisken` komutumu yazıyorum. Ayrıca betik dosyası içerisinde de `degisken1="deneme"` şeklinde yeni bir değişken tanımlayıp `echo $degisken1` komutu ile bu değişkenin çağrılmasını sağlıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/36.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/36.png)

Tanımlamaları yaptık şimdi de betik dosyamızı çalıştırarak sonuçları gözlemleyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/37.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/37.png)

Gördüğünüz gibi betik dosyası içerisinde tanımlamış olduğum **degisken1** basılırken, daha önce betik dosyası dışında konsol üzerinden tanımlamış olduğum **degisken** değeri basılmadı. Bunun nedeni başta da belirtiğim şekilde, tanımlanan değişkenlerin `export` edilmediği sürece yalnızca tanımlandıkları kabuk üzerinde çalışabiliyor olmasıdır.

Yapmış olduğumuz örnekte; betik dosyasını çalıştırdığımızda, bulunduğumuz kabuk altında hemen bir alt kabuk oluşturuldu ve betik dosyamız bu alt kabuk üzerinden çalıştırıldı. Dolayısı ile üst kabukta tanımlanmış olan değişken, alt kabuğa `export` edilmediği için alt kabuk tarafından tanınmadı ve doğal olarak değeri basılamadı.

Şimdi aynı işlemi değişkeni `export` ederek tekrarlayalım.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/38.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/38.png)

Gördüğünüz gibi değişkenimizi `export` ettikten sonra, alt kabukta çalıştırılan betik dosyası içerisinden de bu değişkeni sorunsuzca çağırabildik. Böylelikle `export` komutunun işlevini ve alt kabuk yapısının nasıl çalıştığını bizzat test ederek görmüş olduk. Ayrıca `export` komutu yerine aynı işlem için `declare` komutunun `x` parametresini `declare -x degisken` şeklinde de kullanabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/39.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/39.png)

Buradaki export işlemi mevcut kabukta tanımlanmış olan değişkeni, alt kabuklara da ileterek ilgili değişkeni alt kabuklar için ortam değişkeni(çevre değişkeni) haline getirmiş oluyor. Ayrıca hazır `export` komutundan bahsetmişken anlatımın devamında kısaca diğer özelliklerine de değinmiş olalım.

### Export Edilmiş Değişkenleri Listelemek

Eğer mevcut kabuktaki tüm dışa aktarılmış değişkenleri listelemek istersek yalnızca `export` komutunu ya da `export` komutu ile `-p` seçeneğini de kullanabiliriz.

Karşımıza gelmiş olan listedeki tüm değişkenler, mevcut kabukta ve mevcut kabuğun altında oluşturulacak yeni alt kabuklarda geçerli olan değişken değerlerini gösteriyor.

### Export İşlemini Sınırlandırmak

Alt kabuklara aktarılmış olan yani export edilerek alt kabuklar için çevresel değişken halini almış olan değişkenlerimizi, gerektiğinde belirli bir noktada alt kabuklara aktarılmayacak şekilde sınırlandırmamız da mümkündür. Bunun için `export` komutunun `n` seçeneğini ilgili değişkeni de belirterek kullanmanız yeterli.

Örneğin ben `araba="kırmızı"` şeklinde bir değişken tanımlıyorum ve bu değişkenimi alt kabuklardan da ulaşabilmek üzere export ediyorum. Değişkenimin alt kabuklardan da ulaşılabilir olduğunu teyit edebilmek adına konsola `bash` komutunu girerek bulunduğum kabuğun altında yeni bir kabuk oluşturulmasını sağlıyorum. Buradaki `bash` komutu mevcut kabuğumuzun altında yeni bir bash kabuk ortamı çalıştırmış oluyor.

```bash
taylan@taylan:~$ araba="kırmızı"
taylan@taylan:~$ bash
taylan@taylan:~$ echo $araba
kırmızı
taylan@taylan:~$
```

Geçiş yaptığımız alt kabuk üzerinde araba değişkenini çağırdığımızda karşıma "**kırmızı**" ifadesi basılmış oluyor. Yani bu da demek oluyor ki araba değişkenim alt kabuklardan da ulaşılabilecek şekilde export edilmiş yani diğer bir deyişle çevresel değişken halini almış bulunuyor. Eğer ben bu değişkenin artık bundan sonraki alt kabuklarda tanınmasını istemezsem, konsola `export -n araba` komutunu girmem yeterli. Böylelikle mevcut kabuğun altında oluşturulan hiç bir alt kabukta araba değişkeni tanınmıyor olacak. Hemen test etmek için yine `bash` komutu ile yeni bir alt kabuk ortamı oluşturalım.

```bash
taylan@taylan:~$ echo $araba
kırmızı
taylan@taylan:~$ export -n araba
taylan@taylan:~$ bash
taylan@taylan:~$ echo $araba
taylan@taylan:~$
```

Alt kabuğa geçiş yaptıktan sonra araba değişkenini çağırmayı denediğimizde, sizlerin de görebileceği gibi **araba** değişkeni tanımlanmamış gözüküyor. Bu durumun sebebi de bizlerin bir üst kabukta bu değişkenin alt kabuklar için çevresel olma özelliğini kaldırmış olmamızdır. İşte sizler de bu şekilde alt kabuklar için çevresel hale getirdiğiniz tüm değişkenlerinizi gerektiğinde yeni alt kabuklar için sınırlandırabilirsiniz.

<aside>
ℹ️ **Not:** Bu bölümün odak noktası "değişkenler" olduğu için `export` komutunun anlatımını burada noktalıyorum ancak burada son bulmuyor. Çünkü `export` komutu yalnızca değişkenlerin değil fonksiyon yapılarının da alt kabuklara aktarılmasını sağlıyor. Fonksiyonlardan bahsederken tekrar `export` komutunun fonksiyonlar ile ilgili olan özelliklere değiniyor olacağız. Aynı durum `declare` komutunun bazı temel seçenekleri için de aynen geçerli. Bu bölümde bahsetmediğimiz seçenekleri yeri geldiğinde ayrıca ele alıyor olacağız.

</aside>

## Değişkenlerin Sıfırlanması (unset)

Tanımladığımız değişkenleri sıfırlamak yani tanımsız hale getirmek istersek `unset` komutunu kullanabiliyoruz.
Şimdi örnek olması açısından farklı türden çeşitli değişkenleri sıfırlamayı deneyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-1.png)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-2.png)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/unset-3.png)

Gördüğünüz gibi sabit değişkenler hariç diğer tüm değişken türleri `unset` komutu sayesinde kolaylıkla sıfırlanabiliyor.

Sabit değişkeni sıfırlamak için sabit değişkenin tanımlandığı kabuğun kapatılması gerektiğini biliyorsunuz. Kabuk kapatıldığında yani öldürüldüğünde sabit değişken de mevcut kabukla beraber ölür. Bu sebeple sabit değişkenler hariç, tanımlamış olduğunuz tüm değişken türlerini `unset` komutu ile kabuğu kapatmadan sıfırlayabilirsiniz.

# Sistemde Tanımlı Ortam(Çevre) Değişkenleri

Kendi değişkenlerimizi nasıl tanımlayabileceğimizi öğrendik. Şimdi de sistemde tanımlı olan değişkenlerden bahsederek anlatımlara devam edelim.

Aslında bizlerin tanımladığı değişkenlerden farksızdırlar. Tek fark bu değişkenlerin sistemde yüklü bulunan uygulamaların sorunsuzca çalışması için önceden tanımlanmış olmalarıdır. Yani sistemin işleyişi için son derece önemlidirler ve varsayılan olarak tanımlıdırlar. Örneğin kullanıcı tarafından verilen komutlara cevaben, çalıştırılabilir dosyaların (yani, çalışmaya hazır programların) nerede aranması gerektiğini kabuğa belirten çevresel değişken **PATH'**dir. Bu değişken sayesinde kabuk, kullanıcının girdiği komutun çalıştırılabilir dosyalarının nerede aranması gerektiğini bilir. Bu ve bunun gibi, sistemin işleyebilmesi için kullanılan varsayılan olarak tanımlanmış pek çok ortam değişkeni vardır. Sistem tarafından tanımlanmış olan çevresel değişkenler, sistemin her açılışında otomatik olarak okunan dosyalar içerisinde yer aldığı için tüm alt kabuklar tarafından erişilebilmektedir. Hatırlarsanız `export` komutu ile alt kabukların ana kabukta tanımlanmış olan değişken değerlerine erişebilmesi mümkün kılınıyordu. İşte bu **export** yani değişkenlerin **çevresel** hale getirilme işlemi, sistem açılışında gerçekleştirildiği için bu şekilde tüm alt kabuklar tarafından ulaşılabilir oluyor. 

## Ortam Değişkenlerini Görüntülemek

Sistemimizde tanımlı ortam değişkenlerini öğrenmek istersek, `env` ya da `printenv` komutlarından birini kullanabiliriz.

**`env` :** Yalın halde kullanıldığında çalıştırıldığı kabuk ortamında bulunan çevresel değişkenleri, değerleri ile birlikte konsola basar. Ayrıca daha önce shebang kavramını açıklarken bahsettiğimiz şekilde, hedef çalışma ortamının bulunup çalıştırılmasını da sağlar. 

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/env.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/env.png)

**printenv :** `env` komutuna benzer şekilde, çalışmakta olduğu kabukta tanımlı bulunan bütün çevresel değişkenleri verir. `env` komutundan farklı olarak, `printenv` yalnızca değişken değerlerini basma görevindedir.(`env` komutunun çalışma ortamını bulup ilgili ortama geçiş yaptığını biliyorsunuz.)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/printenv.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/printenv.png)

Hazır listelenmişken temel ve sık kullanılan değişkenlerden birkaçını da kısaca açıklayacak olursak:

**SHELL:** Çalışmakta olan kabuk programının adını ve yerini verir.

**PATH:** Konsola komut girildiğinde, komut için gereken ilgili dosyaların aranacağı dizinler diğer bir adıyla yol.

**HOME:** Kullanıcının ev dizinini içeren değişkendir.

**TERM:** Komut satırı uygulamalarının hangi terminalde çalışacağını belirtir. Birçok çeşidi vardır ancak xterm pek çok dağıtımda yaygın şekilde karşımıza çıkar.

**SECONDS**: Mevcut komut dosyasının ne kadar süredir çalıştığını saniye cinsinden verir.
**RANDOM**: Rastgele sayılar üretir.

Sistem üzerinde tanımlı olan standart ortam değişkenleri, elbette sistemin yapısı yani kullanım amacına göre değişiklik gösterebilir. Bu sebeple tanımlı olan her değişkeni açıklamamız teknik olarak mümkün değildir. Yine de bu bölümün sonunda bash kabuğu tarafından tanımlanan ve kullanılan standart çevre değişkenlerinin açıklamaları listeli olarak bulunuyor. İhtiyaç halinde mevcut bulunan açıklamalardan yararlanabilirsiniz. 

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p.png)

Gördüğünüz üzere **PATH** değişkeni çıktı olarak **/usr/local/sbin: /usr/local/bin: /usr/sbin: /usr/bin: /sbin: /bin** değerini basmış oldu.

Path değişkeninde görevi yani çıktının bize demek istediği :

Konsoldan girilen herhangi bir komutun çalıştırılabilmesi için sırasıyla <kbd>/usr/local/sbin: /usr/local/bin: /usr/sbin: /usr/bin: /sbin: /bin</kbd> dizinlere bakılır. Eğer verilen komutun çalıştırılabilir dosyası bu dizinlerin içerisinde ise çalıştırılır, yoksa "komut yok" şeklinde hata çıktısı basılır. Çıktıda görülen iki nokta üst üste (<kbd>:</kbd>) işareti ile ayrılmış tüm dizinler PATH yoluna ekli olan dizinlerin dosya konumlarıdır. Örneğin `ls` komutu **/usr/bin/ls** konumunda yer aldığı için biz konsola `ls` komutunu girdiğimizde, konsol PATH yoluna bakıp `ls` komutunu bulup çalıştırıyor. Bu durumu gözlemlemek adına `ls` komutu yerine doğrudan `/usr/bin/ls` ifadesini konsola girmeyi de deneyebilirsiniz.

Hazır yeri gelmişken gelin **PATH** yoluna ekli olmayan bir programı bu yola ekleyip konsoldan vereceğimiz bir komutla direk olarak çalışmasını sağlayalım. Yani örneğin ben konsola gedit yazdığımda dosya konumu belirtmeme gerek kalmadan gedit programı otomatik olarak açılıyorsa, bu PATH yolu üzerinde tanımlı olmasındandır. Örnek olması açısında biz de daha önce yazmış olduğumuz **[selam.sh](http://selam.sh/)** isimli betik dosyamızı bu şekilde istenilen konumdan ismi ile çalıştırılabilir kılalım. Adım adım ilerleyelim;

Benim çalıştırmak istediğim dosya daha önce yazmış olduğum **[selam.sh](http://selam.sh/)** isimli betik dosyası.

Ben bu dosyanın konumundayken dosyayı `./selam.sh` komutu ile çalıştırabiliyorum ancak dosyanın bulunduğu dizin dışından herhangi bir konumdayken bu dosyamı doğrudan çalıştıramıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p1.png)

Yapmamız gereken şey, dosyamızın bulunduğu konumu **PATH** yoluna eklemek ya da dosyamızı **PATH** yolu üzerinde yer alan bir konuma taşımak olacak arkadaşlar. Bu sayede konsola `selam.sh` komutunu girdiğimizde **PATH** yolu taranacak ve dosyamız bu yol üzerindeki herhangi bir konumda ise bulunup çalıştırılacak. Her iki şekilde de bu durumu test edelim.

Öncelikle en mantıklı ve güvenli yol olduğu için dosyamı **PATH** yolu üzerinde bulunan bir konuma taşıyorum. Ve ardından dosyamı herhangi bir konumdayken yalnızca ismini belirterek çalıştırmayı deniyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p2.png)

Gördüğünüz gibi betik dosyam PATH yolu üzerinde bulunan bir konuma eklenince, bulunduğum konuma bakılmaksızın konsol üzerinden ismi girilerek çalıştırılabilir oldu.

Aynı şekilde dosyamızın bulunduğu konumu **PATH** yoluna ekleyerek de her yerden ulaşılabilir kılabiliriz. Ancak bu yöntem sistemin güvenliğini tehlikeye atabilecek kullanım hatalarına sebebiyet verebilir. Yani bu yöntemi pek önermiyor olsam da yine de gerektiğinde kullanabilmeniz için bahsedelim istiyorum.

Temelde yapacağımız işlem PATH değişken değerine, betik dosyamızın bulunduğu konumu eklemektir. PATH değişken değerini değiştirme işlemini, **/etc** dizini altında bulunan ve her oturum açılışında otomatik olarak okunan **profile** dosyası içerisine `PATH="path yoluna eklenecek dizin":$PATH` şeklinde yeni **PATH** yolunu belirtmeliyiz. Bu sayede sistem açılışında belirtmiş olduğumuz yeni PATH değeri de okunup sistem genelinde geçerli olacaktır.

Ben taşımış olduğum **[selam.sh](http://selam.sh/)** dosyasını eski konumuna taşıyarak, bu konumu yani root kullanıcısının ana dizinini **profile** dosyasına `PATH="/root/:$PATH"` şeklinde ekleyerek her yerden ulaşılabilir kılıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p3.png)

Yaptığımız değişikliklerin geçerli olabilmesi için oturumu kapatıp tekrar giriş yaptıktan sonra, değişikliğin geçerli olup olmadığını test etmek için **PATH** değişkenini bastırıp farklı konumlardan betik dosyamızı çalıştırmayı deneyebiliriz. Ayrıca oturumu kapatıp tekrar açmak istemezseniz `source /etc/profile` komutunu kullanarak yaptığınız değişikliğin sistem tarafından tanınmasını sağlayabilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p4.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/p4.png)

Ve en nihayetinde **PATH** değişkeni sayesinde betik dosyamızı her yerden çalıştırılabilir hale getirmiş olduk.

Neticede sizlerin de bizzat şahit olduğu gibi; sistem tarafından varsayılan olarak tanımlanmış olan değişkenler sistemin işleyişi için oldukça önemlidir.

Şimdiye kadar hem kendi tanımladığımız hem de sistemde varsayılan olarak tanımlı değişkenleri ele aldık. Şimdi de tanımlanan değişkenlerin kapsamlarını 3 kategori altında tek tek ele alalım;

- **kabuğa özel :** yalnızca açık olan mevcut kabuk üzerinde geçerli olan.
- **kullanıcıya özel:** yalnızca tek kullanıcı için geçerli olan ve o kullanıcının her oturum açtığında kullanabildiği.
- **sistem geneli :** sisteme öntanımlı olarak ayarlanmış sürekli kullanılabilir.

Gelin şimdi teker teker kullanımlarına değinelim.

### Mevcut Kabuğa Özel

**Yalnızca mevcut çalışmakta olan kabuğa özel olan ve mevcut kabuk kapandıktan sonra sıfırlanan ortam değişkenidir.** Zaten daha önce de bu durumda bahsetmiştik. Şimdi netleştirmek adına örnek üzerinden adım adım açıklayalım bu durumu:

Konsola `isim="taylan"` şeklinde bir değişken tanımlayıp, bu değişkeni bastırıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/53.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/53.png)

Daha sonra yeni bir konsol yani alt kabuk açarak **isim** değişkenini konsola bastırmayı deniyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/54.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/54.png)

Gördüğünüz gibi yeni açmış olduğum konsoldaki çıktı boş oldu. Bunun nedeni tanımladığım değişkenin, bu şekilde tanımlandığına yalnızca tanımlandığı kabuk üzerinden çağırılabileceğidir. Biz yeni bir konsol açtığımızda yeni bir alt kabuk oluşturulduğu için değişken alt kabukta tanınmadı. **Yani sizler de biliyorsunuz ki export edilerek alt kabuklara aktarılmayan tüm değişkenler, yalnızca üzerinde işlem yapılan kabuk için geçerli oluyor.**

Aynı durumu daha önce yaptığımız şekilde mevcut konsolda yeni bir alt kabuk başlatarak da gözlemleyebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/55.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/55.png)

Çıktılardan da anlaşılacağı üzere export edilmeyen değişkenler yalnızca bulundukları kabuk ortamında geçerli oluyor.

### Kullanıcıya (Oturuma) Özel

BASH, her oturum açtığımızda tüm ayarlarını ve davranışlarını kullanıcıya özel olan ve kullanıcının ana dizininde bulunan <kbd>.bashrc</kbd> isimli gizli bir dosyadan okuyor. Yani eğer bizler mevcut oturumumuzdaki değişkenler üzerinde kalıcı değişiklik yapmak istiyorsak; değişiklikleri <kbd>.bashrc</kbd> isimli dosyaya eklememiz gerekiyor. Bu sayede sistem, her oturum açtığımızda burada yer alan değişiklikleri otomatik olarak görüp sisteme tanımlayabilir.

Örnek olması açısında bu sefer de `soyisim="bildik"` değişkenini **yalnızca root kullanıcısına özel** olarak tanımlamayı ele alıyorum.

Öncelikle kullanıcı hesabımın ana dizininde bulunan <kbd>.bashrc</kbd> dosyasını açmak üzere <code>nano ~/.bashrc</code> komutunu giriyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/56.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/56.png)

Komutumuzu girdikten sonra karşımıza konsol ekranı içerisinde <kbd>.bashrc</kbd> dosyasının içeriği geliyor. Klavyedeki yön tuşlarını kullanarak en alt satıra inelim ve root kullanıcısına özel olarak tanımlamak istediğimiz değişkeni `export soyisim="bildik"` şeklinde girip, <kbd>Ctrl + X</kbd> tuş kombinasyonu ile yaptığımız değişikliği kaydedelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/57.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/57.png)

Artık böylelikle değişiklik yaptığımız bu root kullanıcı oturumunu ne zaman açarsak, tanımladığımız **soyisim** değişkeni geçerli olacak.

Ancak dosyada değişikliği yaptığımız anda değişken sisteme hemen tanımlanmıyor. Bunun nedeni <kbd>.bashrc</kbd> dosyasının oturum açılırken okunmasıdır. Yani yaptığımız değişikliklerin geçerli olabilmesi için oturumun kapatılıp tekrar açılması ya da alternatifi olan `source` komutunun `source .bashrc` şeklinde kullanılması gerekiyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/58.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/58.png)

Şimdi **root** kullanıcı hesabında ve başka bir kullanıcı hesabı olan **ali** kullanıcı hesabında **soyisim** değişkenini bastırmayı deneyelim.

Öncelikle **root** kullanıcı hesabında konsola `echo $soyisim` yazarak değişken değerimi bastırıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/59.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/59.png)

Hatta root kullanıcı hesabındayken birden fazla konsol üzerinden yani birden fazla alt kabuk üzerinden bile **soyisim** değişkenini çağırabiliyorum. Hatırlarsanız kabuğa özel olarak tanımladığımız değişkene yalnızca tanımlandığı kabuk üzerinden ulaşabiliyorken, kullanıcıya özel olarak tanımlanmış değişkene kullanıcı hesabında açtığımız tüm alt kabuklar üzerinden erişebiliyoruz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/60.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/60.png)

Şimdi de **ali** isimli kullanıcı hesabına geçerek `echo $soyisim` komutu ile değişkeni bastırmayı deneyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/61.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/61.png)

Gördüğünüz gibi **root** kullanıcısına özel olarak tanımladığımız **soyisim** değişkenine, **root** kullanıcısı dışında diğer kullanıcılar ulaşamıyor. Çünkü değişkenimizi root kullanıcı hesabına ait olan .bashrc dosyasına eklemiştik. Bu dosya içeriğine yalnızca root kullanıcısı erişebildiği için değişkeni de yalnızca root kullanıcısında oluşturulan alt kabuklar tanıyabiliyor.

### Sistem Genelinde

Eğer yaptığımız değişiklik bütün kullanıcı oturumlarında aynı şekilde geçerli olsun istiyorsak, değişkenin sistemde her oturum açıldığında okunan bir dosyada bulunması gerekiyor. Bu yüzden tanımlayacağımız değişkeni <kbd>/etc</kbd> dizini altında yer alan <kbd>bash.bashrc</kbd> dosyasına uygun şekilde eklemeliyiz.

Öncelikle dosyamızı açmak üzere konsola <code>nano /etc/bash.bashrc</code> komutunu girelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/62.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/62.png)

Bu kez de örnek olması için `lokasyon="istanbul"` değişkenini <kbd>bash.bashrc</kbd> dosyamıza ekleyip kaydedelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/63.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/63.png)

Sıra geldi değişikliklerin sistem tarafından tanınmasına. Yapılan değişikliğin sistem bütününde geçerli olabilmesi için daha önce de bahsi geçen `source` komutunu <kbd>bash.bashrc</kbd> dosyası için `source /etc/bash.bashrc` şeklinde kullanalım. Ayrıca aklınızda bulunsun `source` komutu yerine `.` nokta işaretini de kullanabilirsiniz. Yani değişikliğin sistem tarafından algılanması için `source /etc/bash.bashrc` komutu yerine `. /etc/bash.bashrc` komutunu da kullanabilirsiniz. Noktadan sonra boşluk olduğuna dikkat edin lütfen. Buradaki nokta işareti kendinden sonra gelen dosyanın sistem tarafından tekrar okunmasını sağlıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/64.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/64.png)

Ardından değişikliklerin geçerli olup olmadığını denemek için birden fazla kullanıcı hesabında **lokason** değişkenini bastırmayı deneyelim.

Öncelikle

**root**

kullanıcısı için test edelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/65.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/65.png)

Şimdi **ali** kullanıcısı üzerinden değişkenimizi bastırmayı deneyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/66.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/66.png)

Son olarak da **can** kullanıcısı üzerinden değişkenimizi çağıralım.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/67.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/67.png)

Çıktılarımızın hepsinde **lokasyon** değişkeninin değeri olarak **istanbul** ifadesini gördüğümüze göre, değişkenimizi sistem genelinde tanımlamayı başarmışız demektir. Yaptığımız bu değişiklik bütün kullanıcılar için yani sistem geneli için geçerlidir. Bu durumu başka bir hesap oluşturarak kendiniz de gözlemleyebilirsiniz. Değişikliğin tüm sistemde geçerli olmasının nedeni sistem başlangıcında oluşturulan üst kabukta bu değişkenin tanınıyor ve alt kabuklara aktarılıyor olmasıdır. Daha önce kabukların yapısından ve alt kabuk kavramından zaten bahsettiğimiz için burada gerçekleşen işlemlerin sebeplerini sizler de biliyorsunuz.

Gerektiğinde değişiklikleri geri almak isterseniz eklediğiniz ifadeyi ilgili dosyadan silin ve dosyanın sistem tarafından tekrar okunması için `source değiştirilen_dosya` ya da `. değiştirilen_dosya` komutlarından birini kullanın. Böylelikle bütün değişiklikler sıfırlanmış olacaktır.

# Değişken Değerlerin Farklı Şekillerde Bastırılması

Bu kısma kadar pek çok değişken tanımlayıp, bu değişkenlerin değerlerini `echo` komutu yardımıyla konsola bastırdık. Fakat her zaman, basılan bu değişken değerlerinin tamamına ihtiyacımız olmayabilir. İşte bu gibi durumlarda `echo` komutunun, çıktıları düzenleme işlevinden yararlanabiliyoruz. Şimdi sırasıyla `echo` komutu üzerinden çıktılarımızı nasıl düzenleyebileceğimizi görelim.

## Değişken Değerinin Uzunluğunu Öğrenmek

Eğer değişkenlerin sahip olduğu değerlerin karakter uzunluklarını öğrenmek istersek kare işareti başta olacak şekilde değişken ismini belitebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png)

Üstelik bu kullanım sadece diziler için değil standart ve sabit değişkenler için de geçerlidir. Sabit değişkenlerin ne olduğundan anlatımın devamında ayrıca bahsediyor olacağız.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png)

Eğer komutumuzda index numarası ile herhangi bir dizi elemanı belirtmezsek varsayılan olarak dizide yer alan ilk eleman işleme alınıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png)

Ayrıca dizi içerisinde kaç tane değişken olduğunu öğrenmek için de `#` simgesini ile birlikte index numarası kısmında `` simgesini kullanmamız yeterli.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png)

Yani anlayabileceğiniz gibi burada yer alan kare işareti mevcut değişken verisini saymakla mükellef.

## Değerin Bir Kısmını Bastırmak

Değişkene atanmış olan değerin belirli bir kısmını almak istersek, çıktı değeri olarak almak istediğimiz kadarlık kısmı **${degisken:başlangıç:uzunluk}** şeklinde belirtmemiz gerekiyor.

**Başlangıç :** Seçme işleminin başlanacağı yeri temsil eder. Boş bırakılırsa en baştan itibaren seçilir.

**Uzunluk :** Seçme işleminin ne kadar uzunlukta olacağını belirtir. Bu kısım boş bırakılırsa seçme işlemi otomatik olarak değerin sonuna kadar yapılır.

### Örnekler;

Kullanım farklarının daha kolay anlaşılabilmesi için tek bir örnek üzerinden ilerlemek üzere, **deneme** isimli değişkene "**123456789**" değerini atıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/40.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/40.png)

**" ${deneme::3} "** = değişken değerinin ilk 3 karakteri.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/41.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/41.png)

**" ${deneme:2} "** = değişken değerinin 2. karakterinden sonra hepsi.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/42.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/42.png)

**" ${deneme:2:4} "** = değişken değerinin 2. karakterinden sonraki 4 karakter.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/43.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/43.png)

## Değişken Değerlerini Silmek

Değişkenimizin basılacak olan değerini silmek için iki farklı kullanım metodu bulunuyor.

Bunlardan ilki, değerleri **başlangıçtan itibaren** silen **#** işareti, ikincisi ise tersi şekilde değeri **sondan itibaren** silen **%** işaretidir.

Bu işaretlerin birer kez kullanılmasıyla, hedef ile eşleşen yalnızca ilk kısım siliniyor. Eğer yalnızca ilk kısım değil de eşleşen tüm kısımlar silinsin istersek bu işaretleri iki kez kullanmamız gerekiyor. Durumu daha net anlamak adına lütfen okumaya devam edin.

Öncelikle tek bir referans örnek üzerinden ilerlemek üzere `silinecek=(sil silindi silinmişti)` şeklinde değişkenimizi tanımlayalım. Bu kısımda anlatımın daha kolay anlaşılabilmesi için dizi değişkenleri üzerinden ilerleyeceğiz ancak burada anlatılanların diğer değişken türleri için de geçerli olduğunu lütfen unutmayın.

**Baştan itibaren verilerin silinmesi;** Bu işlem için kare(**#**) işaretini kullanmamız gerekiyor.
**Sondan itibaren verilerin silinmesi;** Bu işlem için yüzde(**%**) işaretini kullanmamız gerekiyor.

### İlk Eşleşen İfadeye Kadar Olan Kısmın Silinmesi

### Baştan itibaren silmek için;

Örnekte tanımlamış olduğumuz değişken değerlerinin **başından** başlayarak **sadece ilk eşleştiği kısma kadar** olan ifadeleri silmek için;

Komutumuzu `${silinecek[@]#*silinecek_ifade}` şeklinde kullanıyoruz.

### Sondan itibaren silmek için;

Örnekte tanımlamış olduğumuz değişken değerlerinin **sondan** başlayarak **sadece ilk eşleştiği kısma kadar** olan ifadeleri silmek için;

Komutumuzu `${silinecek[@]%silinecek_ifade*}` şeklinde kullanıyoruz.

Örnek üzerinde kullanmış olduğumuz komutların içerisinde yer alan kısımları açıklayacak olursak;

Örneğimizi diziler üzerinden yürüttüğümüz için dizi elemanlarının kapsamını özellikle belirtmemiz gerekiyor.**[@]** şeklinde belirtilen kısım dizideki tüm elemanları kapsıyor.(Bu ifade yerine yıldız(asterix) `` işaretini de kullanabilirdik.)

Kullandığımız kare (**#**) ya da yüzde(**%**) işaretleri baştan veya sondan itibaren **yalnızca ilk eşleşen hedefe kadar olan kısmı** silme işlevinde.

Ayrıca silinecek ifadenin geri kalan kısmının otomatik olarak eşleşebilmesi için yıldız işaretini, duruma göre başta ya da sonda olacak şekilde kullanıyoruz.

**Kare işaretini** kullanırken, **değerin başından** itibaren arama yaptığımız için istediğimiz yani hedeflediğimiz değere ulaşana kadarki kısımda yer alan baştaki herhangi bir değeri temsil etmesi adına **yıldız karakterini başta** kullanıyoruz.

Benzer şekilde **yüzde işareti** ile **değerin sonundan** itibaren arama yaptığımız için istediğimiz yani hedeflediğimiz değere ulaşana kadarki kısımda yer alan herhangi bir değeri temsil edebilmesi için **yıldız karakterini sonda** kullanmamız gerekiyor.

Burada kullanılan yıldız karakterinin neden önemli olduğunu anlamak adına, yıldız karakteri olmadan aynı işlemi tekrar etmenizi öneririm.

### Eşleşen Tüm İfadelere Kadar Olan Kısmın Silinmesi

Eğer hedeflediğimiz karakterlerin geçtiği tüm kısımlar kapsam dahilinde olsun istersek kare ya da yüzde işaretlerini **iki kez** yazmamız gerekiyor. Durumu daha iyi anlamak adına bir kıyaslama yapalım.

Üzerinde işlem yapacağımız kelime "**silinmişti**" olsun.
Kelime içerisindeki hedefimiz de "**i**" karakteri olsun.

Kare ya da yüzde işareti tek sefer kullanıldığında, karşılaşılan ilk "**i**" ifadesinden sonra işlem duracak ve kelime içerisinde yer alan diğer "**i**" karakterleri dikkate alınmayacaktır. Bu durumu zaten daha önceki örneğimizde görmüştük.

Eğer kare ya da yüzde işaretini iki kez kullanırsak; kelime içerisinde geçen tüm hedef "**i**" karakterleri işleme alınacaktır.

İki kullanım arasındaki farkı, çıktıları kıyaslayarak rahatlıkla görebilirsiniz.

Ayrıca söz konusu dizi değişkenleri olunca; tüm ifadeleri tek seferde kapsamak yerine, özel olarak bir ifadeyi de hedefleyebileceğimizi biliyorsunuz.

Örneğin dizide yer alan 3. değerde yer alan **c** harflerine kadar olan kısmı silmek için komutumu `${silinecek[2]#*c}` şeklinde kullanabilirim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/47.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/47.png)

Eğer bu örneği anlamakta güçlük çektiyseniz, daha önce ele aldığımız dizi değişkenleri konusuna tekrar göz atmanız gerekecektir.

<hr>

Bu kısımdaki örneklerimizi dizi değişkenleri üzerinden yapmış olsak da aslında tüm değişken tipleri için uygulanabilir olduğunu unutmayın lütfen.

Hemen basit birkaç örnek üzerinden bu durumu da teyit etmiş olalım.

```
dizi=(sil silindi silinmişti)

standart="silinmişti"

readonly sabit="silinmişti"

echo  "Dizi çıktısı:"  ${dizi[*]#*i}

echo "Dizi çıktısı:" ${dizi[*]##*i}

echo "Dizi çıktısı:" ${dizi[*]%i*}

echo "Dizi çıktısı:" ${dizi[*]%%i*}

echo "Standart değişken çıktısı:" ${standart[*]#*i}

echo "Standart değişken çıktısı:" ${standart[*]##*i}

echo "Standart değişken çıktısı:" ${standart[*]%i*}

echo "Standart değişken çıktısı:" ${standart[*]%%i*}

echo "Sabit değişken çıktısı::" ${sabit[*]#*i}

echo "Sabit değişken çıktısı::" ${sabit[*]##*i}

echo "Sabit değişken çıktısı::" ${sabit[*]%i*}

echo "Sabit değişken çıktısı::" ${sabit[*]%%i*}

```

Bu kullanımları daha iyi anlamak adına lütfen kendiniz de buradaki örnekler haricinde bol bol alıştırma yapın. Pratik yaptıkça aslında kullanımın ne kadar kolay olduğunu sizler de bizzat deneyimlemiş olacaksınız.

## Değişken Değerinin Değiştirilmesi(Bul-Değiştir İşlemi)

Değişkenlerin konsola basılan değerlerini dilediğimiz başka değerler ile değiştirmek için iki farklı metot bulunuyor.

Örnek çalışma yürütebilmek adına, içerisinde birden fazla "**Linux**" ifadesinin geçtiği basit bir metin kullanıyor olacağız.

Eğer **yalnızca ilk eşleşmede** yer alan ifadeyi değiştirmek istersek komutumuzu **tek slash**(**/**) ile `${degisken/aranan/değiştirilecek}` şeklinde kullanmamız gerekiyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/49.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/49.png)

Şayet **eşleşmelerde yer alan tüm ifadeleri** değiştirmek istersek, **çift slash**(**//**) ile komutumuzu `${degisken//aranan/değiştirilecek}` şeklinde kullanmamız gerekiyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/50.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/50.png)

Çıktılarda yer alan ifadeleri kıyasladığınızda tek ve çift slash kullanım farkını çok daha net kavrayabilirsiniz. Ayrıca fark ettiyseniz daha önce de bahsettiğimiz **küçük büyük harf duyarlılığı bu kullanım için de geçerli** olduğundan, yalnızca aradığımız "**linux**" ifadesi bulunup "**çekirdek**" ifadesi ile değiştirilmiş oldu.

Bunun dışında değişiklik yapmak istediğiniz ifade, ille de bir kelime bütünü olmak zorunda değil. Dilersek yalnızca tek bir harfi dahi değiştirebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/51.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/51.png)

## Komutların Değişkenler Üzerinden Çalıştırılması

Eğer tanımladığımız değişkene doğrudan bir komutun çıktısını atamak istersek, ilgili komutu dolar işareti koyup parantez içerisine alarak belirtebiliriz.

Örneğin değişkenimi `ben=$(whoami)` şeklinde tanımlarsam, `ben` değişkeni her çağırıldığında`whoami` komutu çalıştırılarak sonucu ben isimli değişkeninin değeri olarak sunacaktır.

Şimdiye kadar birkaç farklı metot uygulayarak, orijinal değerleri istediğimiz şekilde manipüle edip tam ihtiyacımıza göre çıktılar elde ettik. **Ancak bu aldığımız çıktıların geçici değerler olduğunu ve orijinal değerlerde kalıcı değişikliğe yol açmadığını lütfen unutmayın.** Bizler buradaki işlemler ile yalnızca alacağımız çıktıları `echo` komutu üzerinden ihtiyacımıza göre şekillendirmiş olduk.

Değişkenleri uzun uzadıya ele aldık. Şimdi de değişkenlere benzer şekilde çalışan ancak kısmen daha kısıtlı kullanım alanı olan `alias` yani takma ad kavramını ele alarak değişkenler anlatımını sonlandırmış olalım.

## Komut Satırında Alias İşlemleri

`alias`, tek bir komuta ya da birden fazla komut bütününe kısayol atama ya da diğer bir deyişle takma ad atama işlevindeki yapıdır. Komutumuzun kullanımı aşağıdaki şekildedir.

`alias [takma-ad]="[komutlar]"`

Örneğin, paket yükleme işlemlerinde sıklıkla kullandığım `apt-get install` komutu yerine, daha kısa şekilde yazabileceğim **yukle** ifadesini bu işlem için takma ad olarak atayabilirim. Bu sayede kullanmakta olduğum kabuk kapatılana kadar **yukle** ifadesi `apt-get install` komutu yerine geçiyor olacak.

`alias yukle="apt-get install"`

Şayet tanımladığım takma adı silmek istersem de `unalias` komutu ile `unalias [olusturulan-alias]` şeklinde takma adı silebilirim.

`unalias yukle`

Oluşturulan bir `alias`yani takma isim silinmediği sürece, tanımlandığı kabuk üzerinde, üzerine atanan komutun işlevi yerine getirmeye devam eder. Kabuk kapatıldığında ise tıpkı değişkenlerde de olduğu gibi otomatik olarak tanımlanan tüm takma isimler(`alias`) silinir.

Ancak tanımladığımız `alias` 'ı kalıcı hale getirmek istersek; daha önce de yaptığımız şekilde sistemin ya da oturumun her açılışında otomatik olarak okunan dosyalarına bu tanımlamayı belirtmemiz gerekir. Yani **yalnızca sizin oturumunuzda** geçerli olacak bir `alias` tanımlamak isterseniz ana dizininizde bulunan <kbd>.bashrc</kbd> dosyasına, ya da **tüm sistemde** yani **tüm kullanıcılarda** geçerli olsun isterseniz de <kbd>etc</kbd> dizini altında bulunan <kbd>bash.bashrc</kbd> dosyasına ilgili takma adı ekleyip `source` komutu ile dosyayı konfigüre edebilirsiniz.
Ayrıca bash script oluştururken aynı komutların tekrar tekrar kullanıldığı durumlarda, betik dosyası içerisinde alias yani takma isim kullanımı bizleri kod tekrarından kurtaracaktır.

[Değişken Açıklamaları](3-%20Deg%CC%86is%CC%A7kenler%20166f5080ac4f460db4f856c87dfbd2ba/Deg%CC%86is%CC%A7ken%20Ac%CC%A7%C4%B1klamalar%C4%B1%201b5d1ff375544d7990e55d3d64845c11.md)

[](3-%20Deg%CC%86is%CC%A7kenler%20166f5080ac4f460db4f856c87dfbd2ba/Untitled%202b9638b6634243808122c290f128cdaf.md)