# Giriş

![Giris%CC%A7%2002bcdcd87b97424fb78fe82d5ac59f36/Untitled.png](Giris%CC%A7%2002bcdcd87b97424fb78fe82d5ac59f36/Untitled.png)

Bash script kavramının tam olarak anlaşılabilmesi için öncelikle bahsetmemiz gereken birkaç önemli kavram bulunuyor. Şimdi sırasıyla bu kavramları bir örnek üzerinden ele alalım.

Örneğin bulunduğum konumda yeni bir klasör oluşturmak istiyorum diyelim. Bu klasörü oluşturmak için iki farklı seçeneğim bulunuyor. Dosyayı oluşturmak için ya grafiksel arayüzü kullanacağım ya da komut girerek ilgili klasörün oluşturulmasını sağlayacağım. Her iki şekilde de benim yaptığım işlem, bilgisayara ne yapması gerektiğini izah etmek oluyor. Yani ben grafiksel arayüzden çeşitli tıklama işlemleri ile ya da konsoldan komut girerek bilgisayara iş buyurduğumda aslında arka planda, girilen işlem emri yorumlanarak donanıma iş yaptırmış oluyor. Ancak tüm hikaye bu kadar yalın değil aslında. Çünkü sizlerin de tahmin edebileceği gibi bizim vermiş olduğumuz bu işlem emrini bilgisayarımızı oluşturan donanım bileşenleri doğrudan anlayamaz. Anlayamadığı için bizden gelen emirlerin donanımların anlayacağı dile çevrilmesi gerekiyor. Bu sebeple de çevirme işleminde görevli çeşitli yapılar bulunuyor.

Kısa açıklamamızın ardından, şimdi aynı örneğimizi tekrar ele alarak arka planda gerçekleşen işlemleri ve görevli yapıları öğrenmeye başlayalım.

Ben klasör oluşturmak istiyorum ve bunu bilgisayarıma ifade etmeliyim. Bilgisayara verilecek emrin ifade biçimi grafiksel arayüz ya da komut kullanımı olabilir. Ben komut kullanımını tercih ediyorum ve komutumu bilgisayara aktarmak için konsol denilen yapıyı kullanmam gerekiyor.

Konsol, komutlarımı kabuğa iletmemi sağlayan yardımcı bir araçtır. Klavyemi kullanarak konsola komutlar veririm, konsolda da benim yazdığım emirlerin kabuğa iletilmesini sağlayarak bilgisayarın bizi anlama yolcuğunun başlamasını sağlar. Örnek üzerinden ele alacak olursak;

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/komut.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/komut.png)

Dosyayı oluşturmak üzere komutumu konsola girdiğimde, yazmış olduğum komut, **shell** yani **kabuk** denilen yapı tarafından alınıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/shell.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/shell.png)

Daha sonra **kernel** yani **çekirdeğe** iletiliyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/kernel.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/kernel.png)

Çekirdek, kabuktan aldığı emri donanımlara ifade ediyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/hardware.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/hardware.png)

Ve en nihayetinde donanım, çekirdekten aldığı emir doğrultusunda yapılması gereken işlevi yerine getiriyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/file.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/file.png)

Yapıyı tekrar kısaca ele alacak olursak; ben yapılmasını istediğim işlemi doğrudan donanımın anlayacağı şekilde ifade edemeyeceğim için bunun yerine **shell** yani **kabuk** denilen yapıya, anladığı dil üzerinden derdimi anlatıyorum. Bu dil benimde kolayca öğrenip yazabileceğim okunaklı ifadelerin olduğu dildir. Bu sayede insan olarak emir vermem kolaylaşıyor. Benden okunaklı ifadeler ile emir almış olan **Shell**, aldığı bilgileri çekirdeğin anlayacağı dilde **çekirdeğe** yani **kernel** olarak geçen yapıya aktarıyor. Son olarak çekirdek yani kernel da, donanımın anlayacağı dilde donanıma emir vererek iş yaptırıyor. Böylelikle insan olarak, derdimi makinenin anlayacağı şekilde iletmiş oluyorum. Neticede sizlerin de fark edebileceği gibi, tekrar tekrar üzerinde durduğumuz aracı yapıların hepsinin temel görevi "**tercümanlık**" oluyor aslında.

İşte en başında klasör oluşturmak için konsola girdiğim okunaklı `mkdir` komutu da aslında "Bash" olarak geçen kabuk dilinin klasör oluşturacak aracı(sistemde yüklü bulunan yazılım) çalıştırmasını sağlıyor. Kabuktan emir alan ve çekirdek ile iletişime geçebilecek şekilde programlanmış olan `mkdir` aracı ilgili işlemi çekirdeğe aktarıyor. Neticede çekirdek de ilgili donanımlara gerekli işi yaptırarak klasörün oluşmasını sağlıyor. Bu yapıyı kısaca aşağıdaki şemadan inceleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/stab.gif](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Giri%C5%9F/stab.gif)

Ben kabuk(shell) ile bash dili aracılığı ile iletişim kurdum dedim ancak kabuk(shell) denilen yapı, yalnızca bash dili ile iletişim kuruyor gibi bir anlam çıkarmayın lütfen.

**Linux** sistemlerinde **BASH** dışında (**ksh,tcsh,zsh,fish...**) gibi birçok **Shell** (**kabuk**) dili bulunuyor. Ancak yetenekleri dolayısıyla **en çok tercih edilen kabuk dili BASH**'dir.

Bash kabuk dili, **Stephen Bourne**'nin UNIX için geliştirmiş olduğu "**sh"** kabuk dilini temel alarak geliştirildiği için; **B**ourne-**A**gain **SH**ell kelimelerinin kısaltması olan **BASH** şeklinde adlandırılmıştır.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Readme/bash_shell.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Readme/bash_shell.png)

Bash kabuk dilinin bu kadar yetenekli(ve dolayısıyla tercih ediliyor) olmasının nedeni; **sh** dili haricinde **ksh**(korn shell) ve **csh**(C shell) gibi çeşitli kabuk dillerinin en iyi özelliklerini içerisinde barındırarak, hem kullanıcı etkileşimi hem de programlanabilirlik için işlevselliği arttıran geliştirmeler içermesidir. Bu sebeple GNU/Linux sistemlerinde **BASH** dışında çeşitli kabuk dilleri barındırılmasına rağmen, genellikle sistemin varsayılan kabuk yorumlayıcısı **BASH**'dir.

Biraz önce bahsettiğimiz "etkileşimli" ve "programlanabilir" ifadelerini kısaca açıklayacak olursak;

**Kabuğun etkileşimli olması demek**, anlık olarak kullanıcıdan gelen emirleri yorumlayıp yine kullanıcıya emirin sonucu sunmasıdır. Kullanıcıdan gelecek emirleri beklediği için kullanıcı etkileşiminin olduğu kullanımdır. 

**Programlanabilir olması ise**, kabuğa verilebilecek olan emirlerin bir dosya içerisinde uygun şekilde toparlanması ve bu dosyanın çalıştırılması ile emirlerin yerine getirildiği kullanımdır. Bu kullanımda aktif kullanıcı etkileşimi gerekmez çünkü emirler önceden programlandığı şekilde otomatik olarak yerine getirilir.

Bizler de bu eğitim serisinde bash kabuk dilini nasıl programlayabileceğimiz üzerinde duruyor olacağız. Burada bahsi geçen "kabuk dilinin programlanması" bash özelinde "**bash shell scripting**" olarak geçiyor. Bu tanımı Türkçe olarak "**bash kabuk senaryolaştırması**" olarak da ifade edebiliriz. Buradaki "**senaryolaştırma**" ifadesi biraz garip bir tanım olsa da aslında yapacağımız işi gayet iyi özetliyor. Zira programlama yaparken aslında durumlara özel senaryolar yazacağımız ve kabuk da bu senaryoya uygun hareket edeceği için "**programlama**" yerine "**senaryolaştırma**" ifadesi de doğru bir çağrışım yapabilir. Kavram açıklamalarına ek olarak "**shell script**" ifadesi Türkçe olarak kısaca "**betik"** olarak da tabir edilebiliyor. Tüm bu programlama işlemine "**betik programlama"**, oluşturacağımız "**script dosyalarına**" da kısaca "**betik**" denebiliyor yani. Aslında nasıl isimlendirildiğinin çok da bir önemi yok. Sadece ileride farklı isimler ile duyduğunuz zaman şaşırmamanız için kısaca bahsetmek istedim.

## Betik Programlamanın Yapısı

Kullanacağımız dilin yapısını bilirsek yani dili tanırsak, amacına uygun işlerde kullanabiliriz. Bash dilini daha yakından tanımak adına açıklamaya devam edelim.

Bash dili "**yorumlayıcı"** yani "**interpreter"** yapıya sahiptir. Zaten anlatımın başında aslında bilgisayar ile iletişim kurmamızı sağlayan tüm yapıların temelde çeviri işlemi yaptığını da söylemiştik. Interpreter ifadesinin Türkçe karşılığı da "çevirmen, tercüman, yorumlayıcı, yorumcu" olarak ifade ediliyor. Bash dili de biz insanların kolayca öğrenip yazabileceği ifadeleri emir olarak alıp yorumlayarak bilgisayarın anlayacağı dile çevirme işlevinde olduğundan "**interpreter**" yani "yorumlayıcı" bir dildir.  Bash dilinin sahip olduğu yapıyı daha iyi anlamak ve bu dilden beklentilerimizi doğru şekilde ölçeklendirebilmek adına, ek olarak ***derleyici(compiler)*** ve ***yorumlayıcı(interpreter)*** yapılarından kısaca bahsedelim.

### Derleyici (Compiler)

Derleyiciler, yüksel seviyeli programlama dillerini bilgisayarların anlayabileceği makine diline çevirme işlevindedir. Programın yüksek seviyeli dil ile yazılmış kaynak kodu derlenerek, bilgisayarın anlayacağı makine diline tercüme edilir. Derleme işlemi sırasında hata ayıklaması ve kaynak kodun stabilize edilmesi sağlanır. Ayrıca, tüm kaynak kodu derlenmeden program çalıştırılamaz.

Bahsi geçen **yüksek seviyeli diller**, biz insanların anlayabileceği ve kolaylıkla programlama yapabileceği genellikle İngilizce kelime gruplarından(if, do, done, while, function, vb..) oluşmuş programlama dillerine verilen genel isimdir.

**Makine dili** ise, bilgisayarların anlayacağı **0** ve **1'**lerden ibaret olan standart dildir.

### Yorumlayıcı (Interpreter)

Derleyicilerden farklı olarak kaynak kodun tamamı uzun uzadıya derlenmeden, program kodları satır satır yada bloklar halinde derlenerek çalıştırılır. 

## Derleyici Ve Yorumlayıcı Arasındaki Fark

Bu noktada kafanızda soru işareti kalmaması adına kısa bir açıklamada bulunmak isterim.

Derleyiciler nispeten yorumlayıcılara oranla daha verimli çalışırlar. Bunun en temel nedeni, derleyicilerin tüm kod bütününü inceleyip bir bütün halinde iyileştirme sunmasıdır. Ayrıca derlenmiş programlar makine dilini içerdiği için çalıştırıldıklarında her bir işlem için ayrı ayrı makine diline çevirme sürecinin uygulanması gerekmez. 

Yorumlayıcılar, sırası gelen kodu çalıştırdığından kodun bütününde iyileştirme sunamaz. Örneğin kod tekrarının olduğu durumlarda derleyici tekrarı düzeltirken yorumlayıcıda hiç bir düzenleme müdahalesi olmaz çünkü her komut ayrı ayrı ele alınır. Ayrıca yorumlayıcı yapı, kodları sırasıyla okuyup çalıştırdığı için her bir kodun ayrı ayrı makine diline çevrilmesi performans açısından olumsuz bir etki oluşturur. Yine de zaten bash dili öncelikli olarak etkileşimli kullanım için geliştirildiğinden yorumlayıcı yapıda olması gerekir.(Konsola girdiğimiz her komutun yanıtını anında alabilmemizi sağlar.)

Bash dilinin yorumlayıcı özelliği nedeniyle performans veriminin düşük olduğunu düşünmeyin. Bu hız farkı ancak çok kapsamlı olan geniş çaplı projelerde hissedilebilecek düzeydedir. Bash dilinin programlanmasının esas amacı; sistem üzerindeki otomatikleştirilebilir görevleri tanımlamak ve çok daha spesifik alanlarda çözümler üretmek olduğundan bu hız farkını asla hissetmezsiniz. Eğitimin ilerleyen aşamalarında bash dilini tanıdıkça hangi amaçla kullanmanız gerektiğini zaten bizzat kavramış olacaksınız. Ayrıca buradaki açıklamamda bash dili ile geniş çaplı komplike proje üretilemez demiyorum, sadece neden üretmemizin mantıksız olduğunu eğitimin geri kalanında anlayacaksınız diyorum. Özetle; bash dilinin kullanım amaçları doğrultusunda yorumlayıcı yapıda olması hem gereklilik ve her bir avantajdır aslında.

En nihayetinde bizler gerekli tüm komutları tek bir dosyada uygun şekilde toparlayarak; durumlara özel senaryolar oluşturacağız ve oluşturduğumuz senaryolara göre de sistem, verilen emirleri otomatik olarak gerçekleştirecek. 

## Neden Bash Programlama Öğrenmeliyiz ?

Bash kabuğunu programlama becerisi ve bize sağlayacağı katkılar neden önemli diyecek olursanız, olası senaryolara bir kaç örnek verelim.

### Otomatikleştirilebilir işleri yerine getirir.

Örneğin sistem dosyalarının her gün yedeklenmesinin gerektiği bir durumda, bu işlemi otomatikleştirmek yerine her gün elle yapmak gereksiz bir uğraş olacaktır. Üstelik insani bir faktör olan unutma riski de yedekleri riske atacaktır.

Yine bir diğer örnek olarak, sistemin online olup olmadığını her daim kontrol etmek yerine bu iş için basit bir betik yazarak 7/24 sistem çalışma durumunun gözetlenmesini ve olası bir kesinti durumunda bizleri haberdar etmesini sağlayabiliriz.

Bu gibi pek çok örnek verebilir ve ayrıca yapılabilecek işlemleri yalnızca böylesine basit işlem adımları olarak da düşünmeyin lütfen. Bu otomatikleştirilebilir işlemlere karmaşık olan görevler de atanabilir. Örneğin sistemdeki işleyişin kontrolü için 50 duruma göre 100 karmaşık komutu her gün dikkatli şekilde konsola girmeniz gerektiği bir durumda, bu işlemleri basit bir betik dosyası ile otomatikleştirmek oldukça verimli ve stabil sonuçlar doğuracaktır. 

### Sistem Üzerindeki Her Araçtan Faydalanılabilir

Ayrıca betik programlama ile birden fazla programlama dilini de tıpkı tek bir program kullanırmışçasına çalıştırabiliyoruz.

Örnek bir senaryoda; betik dosyama, "öncelikle python dili oluşturulmuş olan program dosyasını çalıştır, dosyanın ürettiği çıktılar doğrultusunda perl dili ile oluşturulmuş programı çalıştırıp en son elde edilen çıktıları bana getir" diyebilirim.

Yaptığımız işlem sistem yönetim komutlarını tek bir dosyada düzenli olarak toparlamak olduğu için, sistemi yönetirken yapabileceğimiz gibi çoklu programlama dillerinin ortak paydada çalışmasını sağlayabiliyoruz. Burada betik dosyası çoklu programlama dilleri arasında tutkal görevi görerek bizim işlem emrimizi yerine getiriyor. Üstelik yalnızca alternatif program dilleri de olmak zorunda değil. Sistem üzerinde çalıştırılabilir olan tüm araçlar ile etkileşim kurulması mümkündür. 

### Etkileşimli Kullanımda Ve Sistem Yönetiminde Verimliliğimizi Artırır

Bash kabuk programlamayı öğrenirken aslında bash kabuğunun yapısını öğreneceğimiz için programlama haricinde etkileşimli kullanımda da pek çok yetiye sahip olacağız. Yani bash kabuğuna sahip sistemleri çok daha efektif şekilde konsoldan yönetebiliyor olacağız. Bash programlama sistem yöneticileri haricinde günlük işlerden tutun da siber güvenlik operasyonlarında ve ödül avcılığı araştırmalarında da sıklıkla kullanılan bir yetkinliktir. Kısacası bu eğitim bizlere amaçlarımız doğrultusunda daha güçlü bir sistem yöneticisi olma imkanı sunmak üzere bir rehber olmak amacında.

Bu ve bunlar gibi betik programlamanın sağladığı imkanlar üzerine pek çok örnek verebiliriz. Kısacası bash script kullanarak, mevcut sistem üzerindeki otomatikleştirilebilir olan her türlü işi programlayabiliyoruz.

Betik programlamanın tüm bu özelliklerini dikkate aldığımızda; ihtiyaçlarımıza göre script yazarak bizler için çalışan ve yorulmak bilmeyen binlerce sistem yöneticisi üretebiliriz.

Üstelik bash bir kabuk dili olduğundan diğer dillere oranla sistemle çok daha hızlı etkileşim kurarak, bizlere yüksek performans sağlıyor. Eğitimimizin ilerleyen kısımlarda hız ve işlevsellik konusunda bana katılıyor olacağınıza kesinlikle eminim.

Hazırsanız bu üstün gücü nasıl kontrol edebileceğimizi öğrenmeye başlayalım :)

# Bash hangi komutları bilir ?

Bash kabuğuna verebileceğimiz komutları compgen -b komutu ile öğrenebiliriz.

DEVAM ETTİR

![Giris%CC%A7%2002bcdcd87b97424fb78fe82d5ac59f36/Screenshot_2.png](Giris%CC%A7%2002bcdcd87b97424fb78fe82d5ac59f36/Screenshot_2.png)

[https://youtu.be/Bkxs6KvsUrA?t=561](https://youtu.be/Bkxs6KvsUrA?t=561)

KABUK MODLARI

İNTERACTİVE LOGİN VE BATCH MODUDUR

İNTERKTF ETKİLEŞİMLİ BATCH BETİK DOSYASININ ÇALIŞTIRILDIĞI