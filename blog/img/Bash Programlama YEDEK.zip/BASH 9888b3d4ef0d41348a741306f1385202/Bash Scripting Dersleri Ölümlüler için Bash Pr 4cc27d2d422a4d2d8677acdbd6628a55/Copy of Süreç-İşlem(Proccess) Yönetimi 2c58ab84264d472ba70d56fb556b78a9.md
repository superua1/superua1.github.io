# Copy of Süreç-İşlem(Proccess) Yönetimi

Bu bölümde işletim sistemi programlama gibi bir amacımız olmadığı için bash programlama dahilindeki konuları ele alıyor olacağız. Ancak işletim sistemi programlama yani işletim sisteminin nasıl çalıştığı hakkında fikir sahibi olmanız tüm kavramları çok daha net kavramanızı sağlayabilir. Her ne kadar işletim sisteminin detaylarına girmeyecek olsak da her şeyin temelini oluşturan "process" kavramını kısaca açıklamak mümkün değil. Bizleri yine uzun soluklu ve birbiri ile yakından ilişkili pek çok zincirleme konu anlatımı bekliyor. Bu bölümün sonunda şu ana kadar ele aldığımız ve ileride ele alacağımız pek çok konu bizler için daha anlamlı hale gelecektir.

Her ne kadar bölüm başlığında "süreç" ifadesi geçiyor olsa da aslında ele alacağımız konu "process" olarak geçen "işlem" kavramının anlaşılması ve yönetilebilmesi üzerine olacak. Genellikle "process" terimi için Türkçe olarak "süreç" ifadesi kullanıyor ancak terimin yapısı gereği "işlem" ifadesi daha doğru bir tanımlama olacaktır. Süreç ifadesi de tamamen yanlış bir tanımlama olmasa da bizler anlatımlarımız sırasında "süreç" yerine "işlem" ifadesini tercih ediyor olacağız. Bu açıklamayı harici Türkçe kaynaklara göz attığınızda "işlem" yerine "süreç" ifadesiyle karşılaşmanız halinde şaşırmamanız için ekledim.

Bu bölümde süreçlerden ve yönetimi hususundan bahsediyor olacağız.

wait

bg

fg

jobs

nohup

disown

nice..

vs..

Esas amacımız bash kabuğunun çalışma yapısını kavramak olduğu için konu kapsamını çok dağıtmamak adına anlatım sırasında işletim sistemlerinin nasıl çalıştığının detaylarına girmeyeceğiz. Buradaki anlatımlar bash programlama yaparken bilmemizin gerektiği temel bilgiler kapsamındadır. Daha fazla detay için elbette işletim sistemi özelinde harici kaynaklara göz atabilirsiniz.

# İşlem(Process) Yönetimi

İşlem(Process) Nedir ?

İstisnai durumları bulunsa da söz konusu işletim sistemleri olduğunda; diskimiz üzerinde mevcut bulunan ve sistemin çalıştırabileceği yapıda olan her türlü programın öncelikle RAM(hafıza)'e yüklenmesi ve oradan da sırası geldiğinde CPU(işlemci) üzerinde işlenmesine bütüncül olarak "***process***" yani "***işlem***" diyoruz. Çalışmakta olan programlar genellikle tek işlem olarak ifade edilse de birden fazla işleme sahip olmaları da mümkündür. Ayrıca istenildiği takdirde tek bir işlem çatallama(fork) ile alt işlemler de oluşturabilir. Programlama ait tüm işlemlerin yönetilmesi de işlem yönetimi olarak tabir edilebilir. Eğer açıklama biraz karışık geldiyse endişelenmeyin adım adım ilerleyeceğiz. Elbette farklı sistemlerin farklı işlem mekanizmaları vardır ancak biz *nix sistemlerinde kabul gören çatallama(fork) yapısı üzerinden anlatımlarımızı ele alacağız.

Programı açıkla

disk 

ram

cpu

[https://web.stanford.edu/class/cs101/software-1.html](https://web.stanford.edu/class/cs101/software-1.html)

# GNU/Linux Üzerinde İşlemlerin Oluşumu

Bilgisayarımızı ilk açtığımızda çekirdek init(Bazı modern dağıtımlarda "init" yerine "systemd" yapısı kullanılır.) isimli ana işlemi başlatır ve diğer tüm işlemler bu ana işlemin çatallanması ile oluşturulur. Aslında ilk işlem çekirdek tarafından oluşturulmuşken diğer tüm süreçler ilk işlemin çatallanmasının(fork) ürünüdür. Bu durumu kanıtlamak için konsola `ps ax | head -n 2` komutunu girebilirsiniz. Aldığınız çıktıda PID(process id) yani işlem numarası "1" olan işlemin sisteminize göre "init" ya da "sytemd" olduğunu görebilirsiniz.(Alternatif çalışma ortamlarında duruma göre ilk başlatılan işlem "init" ya da "systemd" dışında herhangi bir yapı da olabilir.) İşlem numaraları çekirdek için "0" olarak kabul edilip sıralı şekilde atandığından, "1" numaralı işlem ilk başlatılan işlemi temsil ediyor.

Hatta açıklamış olduğumuz durumu daha net görebilmek adına konsola `pstree` komutunu verip tüm işlemlerin aslında ilk başlatılan işlemin altında çalışan "sub-process" yani "alt işlem" olduğunu teyit edebiliriz. Burada bahsi geçen alt işlemler "child process" yani "çocuk işlem" olarak isimlendirilirken, alt işlemi oluşturan üst işlemler de "ebeveyn" yani "parent process" olarak ifade edilebiliyor. 

Aldığımız çıktıda; komutumuzu girdiğimiz kabuğun aslında ilk başlatılan işlemin(genellikle "init") alt işlemi olduğunu ve hatta kabuğa girmiş olduğumuz `pstree` komutun da bash işleminin altında çalıştırıldığını görebiliyoruz. 

Mevcut işlemin çatallanarak yeni bir işlem oluşturma durumunu basitçe şematize etmemiz gerekirse;

parent process→ fork→ child process(copy from parent)→ exec→ child process(become new program process)

## Bash Kabuğunda İşlemlerin Oluşumu

Bash kabuğunun komutların türüne göre farklı davranış sergilediğini bilmemiz gerekiyor. Bizim örneğimizde girmiş olduğumuz `pstree` komutu aslında harici bir programdır ve bash kabuğu da eğer sistemde yüklü ise bu programı alt işlem oluşturup çalıştırabilir. Hatta belki de sizin eğitimi takip ettiğiniz sistemde `pstree` aracı yoktu ve bu sebeple `pstree` komutu hatalı sonuç verdi. İşte bu durumun nedeni bash kabuğunun da aslında bir program olmasıdır. Bash kendi bünyesinde bulunan yerleşik komutları(`cd`,`bg`,`echo`..vs.) alt işlem oluşturmaya ihtiyaç duymadan doğrudan çalıştırır. Çünkü bu komutlar aslında bash programının bir parçası olarak kabuk programına atanmış olan işleme dahildirler. Harici olan programlar bash kabuğu üzerinden çalıştırıldığında bash kabuk programının bir parçası olmadığı için bash kabuğunun altında yeni bir alt işlem oluşturulup burada çalıştırılabilirler. Bu sebeple dahili komutlar elbette harici komutlara oranla daha performanslı şekilde çalışır. Çünkü dahili(yerleşik-builtin) komutlar için her defasında alt işlem üretilmesi gerekmez, yalnızca mevcut sürecin devamı olarak yürütülürler.

Mevcut işlemin çatallanarak yeni bir işlem oluşturma durumunu basitçe şematize etmemiz gerekirse;

Üzerinde çalışmakta olduğumuz bash kabuğunda yerleşik komut girersek;

Alt kabuklar hakkında; Betik dosyalarının, parantez içerisine yazılan komutların ve pipe işaretinin

[https://unix.stackexchange.com/a/442704/364572](https://unix.stackexchange.com/a/442704/364572)

## Alt Kabuklar Hakkında

harika subshell ve pipe ;[https://www.jumpingbean.co.za/blogs/mark/bash-subshells-ghost-in-the-subshell](https://www.jumpingbean.co.za/blogs/mark/bash-subshells-ghost-in-the-subshell)

`$(komutlar..)` yapısının kullanımı, tanımı gereği bir alt kabuk oluşturur. Alt kabuk mevcut bash kabuğunun çatallanıp yeni kabuğu(alt kabuk) alt işlemde çalıştırması ile oluşturulur. Bu kullanım yönteminde parantez içerisinde yazılan komutlar alt kabukta çalıştırılır. Elbette alt kabuktaki değişiklikler işlemlerin yapısı gereği üst işlemi yani üst kabuğu etkilemez. Çünkü alt kabuğun tek yaptığı işlem çıktılarını üst kabuğa iletmektir. Örneğin alt kabukta dizin değiştirmek üzere `cd` komutunu kullanırsanız üst kabukta hiç bir değişiklik olmayacaktır. Elbette üst kabuk yani üst işlem kendini çatallayarak alt kabuğu oluşturduğu için bünyesinde bulunan değişken gibi yapılar da alt kabuğa aynen iletilir. 

Genelde karıştırılan bir durum gruplama yapmamızı sağlayan süslü parantez kullanımıdır. Süslü parantez tek başına alt kabuk oluşturmak için kullanılmaz. Süslü parantezin kullanım amacı tıpkı fonksiyonları tanımlarken kullandığımız gibi birden fazla komutun sınırını belirtebilmemizi sağlamaktır.

```bash
#!/bin/bash

echo sh1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
( echo ss1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL \
  | { read LINE
      echo $LINE
      echo ss2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
    }
)
bash -c 'echo sh2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL'
Running the above code on my machine, yielded:

sh1 $$=797 BASHPID=797 PPID=756 SHLVL=2
ss1 $$=797 BASHPID=799 PPID=756 SHLVL=2
ss2 $$=797 BASHPID=800 PPID=756 SHLVL=2
sh2 $$=801 BASHPID=801 PPID=797 SHLVL=3
```

$(..) ile (..) farkı; dolar işareti tüm komutları genişletip çalıştırır. Ters tırnak ile bezer görevdedir. Örneğin $(echo ls) komutunu girersek, ls komutunun çıktıları echo komutu yardımıyla bastırılır. [Mutlaka bak !!](https://stackoverflow.com/a/27472808/7481877) [Mutlaka bak 2](https://superuser.com/a/935427)

Bash kabuğunda alt kabuk oluşturabilecek diğer yöntemler;

- Arkaplan: Arkaplanda çalıştırmamızı sağlayan ve & işareti aslında ilgili komutu alt kabuk oluşturup burada çalıştırır. Yani arkaplandaki süreçler de aslında alt kabuk üzerinde çalıştırılır.
- [P](https://www.gnu.org/software/bash/manual/html_node/Pipelines.html#Pipelines)ipe Kullanımı : Pipe işareti kullanıldığında soldaki ve sağdaki komutlar için iki alt kabuk oluşturulur ve her iki alt kabuğunda sona ermesi beklenir. Soldaki komutun çıktıları sağdaki komutu girdi olarak aktarılır. (Eğer lastpipe seçeneği aktifse pipe işaretinin sağındaki komut mevcut kabuk üzerinde çalıştırılırken soldaki komut altkabukta çalıştırılır.)
- Pipe işareti `komut..|..komut` şeklinde kullanıldığında her iki komut için ayrı ayrı ayrı alt kabuk oluşturulur. Buradaki pipe işareti soldaki komutun çıktılarını sağdaki kabuğa girdi olarak
- Komut İkamesi: `$(…)` (ters tırnak ile aynı ``…``) standart çıktısı bir boruya ayarlanmış bir alt kabuk oluşturur, üstteki çıktıyı toplar ve bu çıktıya, sondaki satırsonlarını çıkararak genişler.
- İşlem İkamesi: `<(…)` Standart çıkışı bir boruya ayarlanmış bir alt kabuk oluşturur ve borunun adına genişler. Üst öğe (veya başka bir işlem) alt kabuk ile iletişim kurmak için boruyu açabilir.
- `>(…)` Aynı şeyi yapar, ancak standart girişteki boru ile.
- Yardımcı İşlem: `coproc …` bir alt kabuk oluşturur ve sona ermesini beklemez. Alt kabuğun standart giriş ve çıkışının her biri, ana boru her bir borunun diğer ucuna bağlanan bir boruya ayarlanır.

Biz bash komutunu girdiğimizde aslında "bash" harici bir araç olduğu için mevcut kabuk işlemi çatallanıyor daha sonra çatallanmış işlem execve sistem çağırısı ile bash programını çalıştıracak işlem halini alıyor. 

Alt kabuk, mevcut kabuğun kopyasını oluşturur. Aynı değişkenlere¹, aynı işlevlere, aynı seçeneklere, vs. sahiptir. Kaputun altında, call² çatal sistemi ile bir alt kabuk oluşturulur; ebeveyn beklerken (ör. $ (…)) veya yaşamına devam ederken (ör.,… &) veya başka bir şekilde ondan bekleneni yaparken (ör.,… |…) çocuk süreç kendisinden bekleneni yapmaya devam eder. ).

$$ ile BASHPID farklı olmasının sebebi $$işaretinin çalıtşırımış olan ana script dosyasının süreç numarasını vermesidir. Alt kabuk oluşturunca alt kabuk elbette farklı süreç numarasına sahip olur fakat ana kabuğun yani ana scripting altında çalıştığı için $$ değeri ana kabuk ile aynı olur. Yine de kendinize özgür süreç numarsını almak için BASHPID komutunu kullanabiliriz.

PİPE;[http://www.rozmichelle.com/pipes-forks-dups/](http://www.rozmichelle.com/pipes-forks-dups/)

# Bash Üzerinde Paralellik

[https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/](https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/)

[http://coldattic.info/post/7/](http://coldattic.info/post/7/)

[https://gioyik.com/p/paralelism-concurrency-logging-bash](https://gioyik.com/p/paralelism-concurrency-logging-bash)

[https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/](https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/)

[http://prll.sourceforge.net/shell_parallel.html](http://prll.sourceforge.net/shell_parallel.html)

[Bash Üzerinde Paralellik](Copy%20of%20Su%CC%88rec%CC%A7-I%CC%87s%CC%A7lem(Proccess)%20Yo%CC%88netimi%202c58ab84264d472ba70d56fb556b78a9/Bash%20U%CC%88zerinde%20Paralellik%20bdec559d8970436da646a950279cdf48.md)

## Job Control | İş Kontrolü

Tek bir süreç birden fazla alt süreç oluşturabileceği için süreçlerin kolay yönetilebilmesi için iş kontrolüne ihtiyaç vardır. Tek bir ana süreç altında oluşturulan tüm alt süreçler bir bütün halinde ele alındığında "job" olarak geçen "iş" kavramına karşılık geliyor. 

Farklı kabuklar alt kabuklardaki veya alt süreçlerdeki süreç numarası bilinen işlemlere müdahale edebilir mi ?

Ebeveyn altında oluşturulan tüm süreçler aynı grupta kabuk edilir. Bu grubun kimlikiği de ppid olarak geçen parrent işlem numarasıdır. Burada bahsi geçen gruplar ancak önplandaki işlemler için geçerli olabilir. Arkaplandaki işlemlerin zaten alt kabuk oluşturulup çalıştığını biliyoruz. Bu sebeple alt kabuklarda ya da arkaplanda çalıştırılan süreçler kendi gruplarına sahiptir. Yani kesme sinyali INT gönderdiğimizde arkaplandaki veya alt kabuktaki süreçler kapsam dışında kalarak kapanmaz. İş kontrolü zaten bu tüm bu süreçlerin kontrolü kolaylaştırmak için vardır. Arkaplandaki süreçleri takip etmek ve gerektiğinde öne almak veya sonlandırmak için bize kolaylık sağlar.

[https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html](https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html)

[https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If the script or program,the foreground to the background](https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If%20the%20script%20or%20program,the%20foreground%20to%20the%20background).

[https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html](https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html)

[https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script](https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script)

## Servis

Servisler tam olarak nedir ve nasıl tanımlanır örneğin bash scriptimiz servis olarak tanımlanabilir mi ?

Servis tanımlamak;[https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6](https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6)