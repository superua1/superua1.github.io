# Ekstra Sözlük

Bu başlık altında kullanılan bazı terimlerin kısaca neleri ifade ettiğini açıklıyor olacağız.

[Sistem Çağrıları (System Call)](Ekstra%20So%CC%88zlu%CC%88k%202808da0b171646bfb9b6d6f7e73b2c8a/Sistem%20C%CC%A7ag%CC%86r%C4%B1lar%C4%B1%20(System%20Call)%20278b25f1674c4a77925a13a62c391c03.md)

[POSIX ve Betik Dosyalarının Taşınabilirliği Hakkında](Ekstra%20So%CC%88zlu%CC%88k%202808da0b171646bfb9b6d6f7e73b2c8a/POSIX%20ve%20Betik%20Dosyalar%C4%B1n%C4%B1n%20Tas%CC%A7%C4%B1nabilirlig%CC%86i%20Hakk%2062a3b2d706cb4f6394f014e227b8cd73.md)

[Çatallama (Fork)](Ekstra%20So%CC%88zlu%CC%88k%202808da0b171646bfb9b6d6f7e73b2c8a/C%CC%A7atallama%20(Fork)%20b6abfb33951243b4af30278fe6633757.md)

[IFS Kavramı](Ekstra%20So%CC%88zlu%CC%88k%202808da0b171646bfb9b6d6f7e73b2c8a/IFS%20Kavram%C4%B1%205df762999a774704ac6de9449d14bbc6.md)

*nix nedir ?

nix olarak kullanildiginda unix turevi sistemleri belirten tabir

EOF yapısının kullanımından da bahset

cat << EOF

>deneme

>metni

EOF

deneme

metni

[https://github.com/icy/bash-coding-style](https://github.com/icy/bash-coding-style)

These definitions are used throughout the remainder of this manual.

**`POSIX`**A family of open system standards based on Unix. Bash is primarily concerned with the Shell and Utilities portion of the POSIX 1003.1 standard.

**`blank`**A space or tab character.

**`builtin`**A command that is implemented internally by the shell itself, rather than by an executable program somewhere in the file system.

**`control operator`**A `token` that performs a control function. It is a `newline` or one of the following: ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’, or ‘)’.

**`exit status`**The value returned by a command to its caller. The value is restricted to eight bits, so the maximum value is 255.

**`field`**A unit of text that is the result of one of the shell expansions. After expansion, when executing a command, the resulting fields are used as the command name and arguments.

**`filename`**A string of characters used to identify a file.

**`job`**A set of processes comprising a pipeline, and any processes descended from it, that are all in the same process group.

**`job control`**A mechanism by which users can selectively stop (suspend) and restart (resume) execution of processes.

**`metacharacter`**A character that, when unquoted, separates words. A metacharacter is a `space`, `tab`, `newline`, or one of the following characters: ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, or ‘>’.

**`name`**A `word` consisting solely of letters, numbers, and underscores, and beginning with a letter or underscore. `Name`s are used as shell variable and function names. Also referred to as an `identifier`.

**`operator`**A `control operator` or a `redirection operator`. See [Redirections](https://www.gnu.org/software/bash/manual/html_node/Redirections.html), for a list of redirection operators. Operators contain at least one unquoted `metacharacter`.

**`process group`**A collection of related processes each having the same process group ID.

**`process group ID`**A unique identifier that represents a `process group` during its lifetime.

**`reserved word`**A `word` that has a special meaning to the shell. Most reserved words introduce shell flow control constructs, such as `for` and `while`.

**`return status`**A synonym for `exit status`.

**`signal`**A mechanism by which a process may be notified by the kernel of an event occurring in the system.

**`special builtin`**A shell builtin command that has been classified as special by the POSIX standard.

**`token`**A sequence of characters considered a single unit by the shell. It is either a `word` or an `operator`.

**`word`**A sequence of characters treated as a unit by the shell. Words may not include unquoted `metacharacters`.