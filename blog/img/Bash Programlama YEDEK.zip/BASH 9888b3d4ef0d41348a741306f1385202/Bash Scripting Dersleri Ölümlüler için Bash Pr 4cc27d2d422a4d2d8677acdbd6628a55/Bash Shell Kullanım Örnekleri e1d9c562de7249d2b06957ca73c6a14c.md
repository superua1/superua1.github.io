# Bash Shell Kullanım Örnekleri

[https://github.com/dogukankurnaz/subdomain_scanner](https://github.com/dogukankurnaz/subdomain_scanner)

TCP port tarayıcısı örneği;

[https://catonmat.net/tcp-port-scanner-in-bash](https://catonmat.net/tcp-port-scanner-in-bash)

OSCP sertifikasında bash scripting nasıl kullanılıyor önemi nedir gibi bir alt konu aç.

Grafiksel arayüz için aşağıdaki programın bash üzerinde çalışan versiyonu yapılabilir.

[https://github.com/AhmetFurkanDEMIR/Unix-and-Cloud-Computing/tree/master/Terminate](https://github.com/AhmetFurkanDEMIR/Unix-and-Cloud-Computing/tree/master/Terminate)

ALGORİTMA KURMA YETENEĞİNİ ARTTIRABİLECEK ÖRNEKLER BUL

CHALLANGE ÇÖZEBİLİRSİN;[https://www.hackerrank.com/domains/shell?filters[status][]=unsolved](https://www.hackerrank.com/domains/shell?filters%5Bstatus%5D%5B%5D=unsolved)

Tor Üzerinden Mesajlaşma

[https://www.xmodulo.com/tcp-udp-socket-bash-shell.html](https://www.xmodulo.com/tcp-udp-socket-bash-shell.html)

- [https://github.com/jichu4n/bash-command-timer](https://github.com/jichu4n/bash-command-timer)

### 5. Perform TCP port scanning against a remote host.

```
#!/bin/bash
host=$1
port_first=1
port_last=65535
for ((port=$port_first; port<=$port_last; port++))
do
  (echo >/dev/tcp/$host/$port) >/dev/null 2>&1 && echo "$port open"
done
```

- [Exercism](https://exercism.io/)
- [Codewars](https://www.codewars.com/)
- [LeetCode](https://leetcode.com/)

BASH SCRİPTİNG İÇİN BEST PRACTİSE YANİ DOĞRU KULLANIM KALIPLARINI ARAŞTIR

KOMUT PARAMETRELERİN ÖRNEK AŞAĞIDAKİ YAPIYA GÖZ AT YA DA DAHA ANLAŞILIR BİR KAYNAK ARAŞTIR 

```bash
case "$prev" in
        -c|--config)
            _filedir
            ;;
        -o|--override|-p|--path)
            _filedir -d
            ;;
        *)
            COMPREPLY=( $( compgen -W '${options[@]} ${services[@]}' -- \
                $cur ) )
            ;;
    esac
```

Bu kurs gerçek hayat örnekleri vermiş bu kurstaki örnekleri değerlendirebilirsiniz.

[https://www.udemy.com/course/linux-bash-shell-scripting-through-real-life-examples/](https://www.udemy.com/course/linux-bash-shell-scripting-through-real-life-examples/)

Bazı örnekler gerçek hayatta pek kullanışlı olmayabilir fakat bu örnekleri uygulamamızdaki temel amaç programlama yeteneğimizi geliştirmektir. Bu sebeple hiç bir örneğin gereksiz olduğunu düşünmeyin sadece en iyi şekilde nasıl programlayabileceğinize odaklanın. Bu örnekler bizim algoritma yeteneğimizi de zamanla arttıracaktır.

milisaniye olarak zamanı bastırmak
echo $(($(date +%s%N)/1000000))

- Basit bir arama fonksiyonu örneği yaz. Yani kelime tamamlama foknsiyonu.
- İki veriyi kıyaslayan ve aralarındaki farkları çıktı olarak basan basit bir program yaz.
    - Yalnızca farklı olan değerleri basan
    - Yalnızca aynı olan değerleri basan

[https://blog.eduonix.com/shell-scripting/how-to-automate-ftp-transfers-in-linux-shell-scripting/](https://blog.eduonix.com/shell-scripting/how-to-automate-ftp-transfers-in-linux-shell-scripting/)
telegram botu kullanrak kullanıcıyı uyarma;
Konu içeriğinde var sonlara doğru dikkatlice oku.
[https://vavkamil.cz/2019/10/09/understanding-the-full-potential-of-sqlmap-during-bug-bounty-hunting/](https://vavkamil.cz/2019/10/09/understanding-the-full-potential-of-sqlmap-during-bug-bounty-hunting/)

parola şifrelenmişş olsun şifreli parola eşleştirmesi ile örnek yapabilirsin. bu parolaryı kali nin hash parolası gibi çözülmesi imaknsız şekilde yap bu örnek ile python birleşimini yani çoklu diller arası iletşimi de sağlayabilirsin.

pomodoro saati programlama alarm ile bizi uyarsın.

Kod örnekleri ile basit oyun programlama alıştırması;
[https://www.codingame.com/ide/puzzle/onboarding](https://www.codingame.com/ide/puzzle/onboarding)
Komut paramatrelerinin kullanım açıklamasını yapan platform ;[https://explainshell.com/about#](https://explainshell.com/about#)

Wifi bağlantısı
"wifi connect bash shell script" araştır
[https://gist.github.com/rjsteinert/4999792f4a7aedd532b2](https://gist.github.com/rjsteinert/4999792f4a7aedd532b2)

BASH TERMİNAL GİRİŞ KISMINI(**ör: root@taylan:~# kısmını**) ÖZELLEŞTİRMEK İÇİN GRAFİKSE BİR ARAÇ YAZ. NAME VE HOSTNAME KISMI İÇİN EMOJİLERİ FALAN KULLANMA SEÇENEĞİ OLAN RENK AYARLARI İLE ONYANABİLECEK BASİT BİR AÇ YAZDIR.

Örnek olarak web projesi: [https://ezprompt.net/](https://ezprompt.net/)

yükleme ikonu için oO* . : |
Güvenlik yazılımı önerisi =>
[https://ogunal.com/python-ile-reputasyon-tabanli-tespit/](https://ogunal.com/python-ile-reputasyon-tabanli-tespit/)

persistence alan oluşturmak için grafiksel arayüze sahip bir uygulama nasıl geliştirilir ? Kaynak için göz at([https://www.acikkaynak.blog/pardus-persistence/](https://www.acikkaynak.blog/pardus-persistence/))

- çoklu dosya ismi değiştirme düzenleme aracı yazılabilir özellikle sed awk özellikleri için ideal örnek