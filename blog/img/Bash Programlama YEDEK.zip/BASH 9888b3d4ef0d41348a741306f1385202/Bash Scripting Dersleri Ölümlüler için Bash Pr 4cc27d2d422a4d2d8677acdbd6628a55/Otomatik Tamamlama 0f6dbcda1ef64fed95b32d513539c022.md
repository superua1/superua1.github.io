# Otomatik Tamamlama

[https://blog.bouzekri.net/2017-01-28-custom-bash-autocomplete-script.html](https://blog.bouzekri.net/2017-01-28-custom-bash-autocomplete-script.html)

[https://learning.oreilly.com/library/view/bash-pocket-reference/9781449388669/re18.html](https://learning.oreilly.com/library/view/bash-pocket-reference/9781449388669/re18.html)

[https://www.gnu.org/software/bash/manual/bash.html#Programmable-Completion](https://www.gnu.org/software/bash/manual/bash.html#Programmable-Completion)

Tab tuşuna bastığımızda, kullanılabilecek olası argümanlar liste şeklinde karşımıza gelir. İşte bu duruma otomatik tamamlama deniyor. Otomatik tamamlama, komut satırı arayüzü ile yani komutlar girerek yönetilecek araçların çok daha kolay kullanılabilmesini sağlar. Bash kabuğu zaten sistem yönetimini kolaylaştırmak adına otomatik tamamlama hizmetini sunuyor. Fakat bizler kendi yazdığımız programlara özel otomatik tamamlama yapısı kurmak isteyebiliriz. Otomatik tamamlama özelliğini kullanmak için de elbette bu yapının tam olarak nasıl çalıştığını kavramamız gerekiyor. 

Temel olarak otomatik tamamlamada görevli "`complete`" "`compgen`" ve "`compopt`" isimli üç yerleşik komut bulunuyor. Anlatımlara `complete` komutu ile başlayabiliriz. 

# `complete` Komutu

Öncelikle pek çok seçeneğe sahip olduğu için bu seçenekleri liste halinde sunup daha sonra açıklamalarını yapalım.

Yardım sayfasına göz attığımızda bizi aşağıdaki seçenek listesi karşılar. 

## Orijinal

> complete [-abcdefgjksuv] [-pr] [-DEI] [-o option] [-A action] [-G globpat] [-W wordlist] [-F function] [-C command] [-X filterpat] [-P prefix] [-S suffix] [name]
> 

## Türkçe:

> complete [-abcdefgjksuv] [-pr] [-DEI] [-o seçenek] [-A işlem] [-G genelyol] [-W kelimelistesi] [-F işlev] [-C komut] [-X süzgeçyolu] [-P önek] [-S sonek] [kelime]
> 

Başlangıçta çok fazla seçeneğe sahip olduğu için göz korkutucu gelebilir ancak endişelenmeyin. Sistematik şekilde ele aldığımızda ne kadara basit yapıda olduğunu görmüş olacaksınız.

Referans kaynağı olması açısından karşımıza gelen seçeneklerin ne anlama geldiğini de liste halinde açıklayalım.

## [-pr]

- `-p` :  Mevcut tamamlama tanımlarının tekrar kullanılabilir şekilde bastırılmasını sağlar. Buradaki tekrar kullanılabilir ifadesi, tanımlama yapılırken girilen komutun olduğu gibi çıktıya basılması anlamına geliyor. Örneğin `complete -F _command command` şeklinde çıktı alırız. Ayrıca bu seçenek kullanılmadan yalnızca `complete` komutu kullanılarak da aynı listeye ulaşmamız mümkündür.
- `-r` : Argüman olarak belirtilmiş olan ifadenin otomatik tamamlama listesinden silinmesini sağlar. Eğer argüman olarak herhangi bir ifade girilmezse tanımlı bulunan tüm otomatik tamamlama önerilerini siler. Bu değişiklikler yalnızca mevcut kabuk üzerinde etkilidir.

## ⚠️ [-DEI] ⚠️

- `-D` : Apply the rest of the options and parameters to the “default” completion, which is used when no other compspec can be found.
- `-E` : Seçeneklerin ve parametrelerin geri kalanını, boş bir giriş satırında tamamlanmaya çalışıldığında kullanılan "boş" tamamlamaya uygulayın.
- `-I` : tamamlamaları ve eylemleri ilk (genellikle komut) kelimesine uygulayın.

Tamamlanmaya çalışıldığında, işlemler yukarıda büyük harf seçeneklerinin listelendiği sırada uygulanır. Birden fazla seçenek sağlanırsa, -D seçeneği -E'ye göre ve her ikisi de -I'den önceliklidir.

## [-A işlem]

Türüne özel olası tamamlama listesi oluşturmak üzere `-A` seçeneğinin ardından tür belirtilebilir. Türler aşağıda açıklanmıştır;

- `alias` : Takma adlar
- `arrayvar` : Dizi değişken adları
- `binding` : Readline kitaplığından bağlamalar
- `builtin` : Kabuk yerleşik komut adları
- `command` : Komut adları
- `directory` : Dizin adları
- `disabled` : Devre dışı bırakılmış kabuk yerleşik komutlarının adları
- `enabled` : Etkinleştirilmiş kabuk yerleşik komutlarının adları
- `export` : Dışa aktarılan değişkenler
- `file` : Dosya adları
- `function` : Kabuk işlevlerinin adları
- `group` : Grup isimleri
- `helptopic` : Yerleşik yardım komutunun izin verdiği yardım konuları
- `hostname` : Adlı dosyada bulunan ana bilgisayar adları $HOSTFILE
- `job` : İş isimleri
- `keyword` : Shell ayrılmış anahtar kelimeleri
- `running` : Çalışan işlerin adları
- `service` : Hizmet adları ( / etc / services'den )
- `setopt` : set -o için geçerli argümanlar
- `shopt` : Shopt yerleşik komutu için geçerli seçenek adları
- `signal` : Sinyal isimleri
- `stopped` : Durdurulan işlerin adları
- `user` : Kullanıcı adları
- `variable` : Kabuk değişken adları

Tamamlamanın sınıfını özellikle belirttiğimizde, o sınıftaki verilerde tamamlama için kullanılabilir oluyor. Hemen denemek için `user` yani `kullanıcı` sınıfına dahil edelim ve komutun ardından TAB tuşuna basalım.

```bash
taylan@taylan:~$ complete -A user komut
taylan@taylan:~$ komut 
ali               Debian-gdm        iodine            man               nobody            _rpc              sys               tss
_apt              Debian-snmp       irc               messagebus        ntp               sshd              systemd-coredump  usbmux
avahi             dnsmasq           king-phisher      miredo            postgres          sslh              systemd-network   uucp
backup            games             lightdm           mysql             proxy             statd             systemd-resolve   vboxadd
bin               geoclue           list              news              pulse             strongswan        systemd-timesync  www-data
colord            gnats             lp                nm-openconnect    redsocks          stunnel4          taylan            
daemon            inetsim           mail              nm-openvpn        root              sync              tcpdump           
taylan@taylan:~$
```

Görebildiğiniz gibi sistemde tanımlı bulunan tüm kullanıcı isimleri tamamlama verisi olarak bize sunulmuş oldu. Bu durum listede yer alan tüm sınıf verileri için aynen geçerli. Hatta tüm bu sınıfları aşağıdaki listede olduğu gibi kısaca da belirtmeniz mümkündür.

Örneğin `kullanıcı` yani `user` sınıfını direk `-u` kısaltması ile belirtebiliriz.

```bash
taylan@taylan:~$ yeni-komut 
ali               Debian-gdm        iodine            man               nobody            _rpc              sys               tss
_apt              Debian-snmp       irc               messagebus        ntp               sshd              systemd-coredump  usbmux
avahi             dnsmasq           king-phisher      miredo            postgres          sslh              systemd-network   uucp
backup            games             lightdm           mysql             proxy             statd             systemd-resolve   vboxadd
bin               geoclue           list              news              pulse             strongswan        systemd-timesync  www-data
colord            gnats             lp                nm-openconnect    redsocks          stunnel4          taylan            
daemon            inetsim           mail              nm-openvpn        root              sync              tcpdump           
taylan@taylan:~$ yeni-komut
```

## [-abcdefgjksuv]

Buradaki tanımlamalar, `-A` seçeneğinin ardından girilen tamamlama ifadelerinin kısaltmalarıdır. (Her ifadenin kısaltması bulunmuyor.)

### Kısaltmalar

- `-a` : -A alias seçeneğinin kısaltması
- `-b` : -A builtin seçeneğinin kısaltması
- `-c` : -A command seçeneğinin kısaltması
- `-d` : -A directory seçeneğinin kısaltması
- `-e` : -A export seçeneğinin kısaltması
- `-f` : -A file seçeneğinin kısaltması
- `-g` : -A group seçeneğinin kısaltması
- `-j` : -A job seçeneğinin kısaltması
- `-k` : -A keyword seçeneğinin kısaltması
- `-s` : -A service seçeneğinin kısaltması
- `-u` : -A user seçeneğinin kısaltması
- `-v` : -A variable seçeneğinin kısaltması

Ayrıca tamamlamaların nasıl davranacağını aşağıdaki seçenekler ile tanımlayabiliriz.

## ⚠️[-o seçenek]⚠️

Tamamlamaların nasıl davranacağını aşağıdaki seçenekler ile tanımlayabiliriz.

- `bashdefault` : Eşleşme yapılmazsa normal Bash tamamlamalarına geri dönün.
- `default` : Hiçbir eşleşme üretilmezse varsayılan tamamlamalarını kullanın.
- `dirnames` : Eşleşme olmazsa dizin adı tamamlama yapın.
- `filenames` : Okuma satırı kitaplığını amaçlanan çıktının dosya adları olduğu konusunda bilgilendirin, böylece kitaplık, dizinler için bir eğik çizgi eklemek veya sondaki boşlukları kaldırmak gibi dosya adına özgü herhangi bir işlem yapabilir.
- `nospace` : Okuma satırı kitaplığına, satırın sonunda tamamlanan kelimelere boşluk eklememesi gerektiğini bildirin.
- `plusdirs` : Dizini tamamlamayı deneyin ve sonuçları önceden oluşturulmuş tamamlamalar listesine ekleyin.

Ne çok da tanım var, ne kadar da sıkıcı değil mi ? Ancak yine de tanımların çokluğu bizi ilgilendirmiyor. Çünkü biz temel çalışma yapısından bahsedip, tanımlara yalnızca ihtiyaç duyduğumuzda başvuracağız. 

`complete` komutuna argüman olarak verilen ifadeler otomatik tamamlama için önerilecek seçenekleri tanımlamamızı sağlar. Tanımlama yapmak üzere `complete` komutunun `-W` seçeneğini kullanalım.

```bash
complete -W öneri1 öneri2 program
```

Bu tanımlamanın ardından mevcut kabukta program komutunun artından TAB tuşuna bastığımda otomatik tamamlama önerileri karşıma sıralanmış oluyor.

```bash
taylan@taylan:~$ program öneri[TAB]
öneri1  öneri2  
taylan@taylan:~$
```

Not: Seçenekler, kelime listesinde tanımladığımız sırayla görüntülenmez, otomatik olarak sıralanır.

Bu gerçekten kullanımı kolay ve pratik çözüm sunuyor olsa da aslında biraz daha spesifik öneriler için yetersiz. Neden yetersiz olduğunu sonraki örneklerde bizzat görmüş olacağız. Şimdi ilerlemeden önce `compgen` komutundan da kısaca bahsedelim. `compgen` komutunun temel görevi, öneri sunmak için liste tutmaktır. Yani bizim çalıştırabileceğimiz komutları veya komutlara verebileceğimiz argümanları `compgen` komutuna bildirebiliriz. Tek başında kullanıldığında pek işlevsel olmasa da otomatik tamamlama yapısının önemli bir parçasıdır. Tek başında kullanımına örnek vermemiz gerekirse, kendisine belirtilmiş olan seçenek ifadelerinin listesi ile argüman olarak girilmiş ifadeyi eşleştirerek öneri sunabilir. 

```bash
taylan@taylan:~$ compgen -W "ilk_ifade ikinci_ifade son_ifade"
ilk_ifade
ikinci_ifade
son_ifade
taylan@taylan:~$ compgen -W "ilk_ifade ikinci_ifade son_ifade" il
ilk_ifade
taylan@taylan:~$ compgen -W "ilk_ifade ikinci_ifade son_ifade" son
son_ifade
taylan@taylan:~$
```

Bu şekilde kullanımına ihtiyacımız olmasa da temel çalışma yapısını kavramak adına yukarıdaki basit örnek yeterli olacaktır. Hatta hazır yeri gelmişken `compgen` komutu ile sistem üzerinde yüklü bulunan komut türlerini de kolayca listeleyebiliriz. `compgen` komutunun anlatımını şimdilik noktalayalım anlatımın devamında ve en sonunda ayrıca değiniyor olacağız.

Kullanım amacını kavramak adına kendinize bir amaç belirleyelim. Örneğin;

COMPREPLY, tamamlamaları depolamak için kullanılan bir dizi değişkenidir - tamamlama mekanizması, içeriğini tamamlamalar olarak görüntülemek için bu değişkeni kullanır