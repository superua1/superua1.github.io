# Ekstra Sözlük

Bu başlık altında anlatım sırasında kullanılan bazı terimlerin kısaca neleri ifade ettiğini açıklıyor olacağız. Bu bölümü eğitimin başında okuduğunuzda pek de anlamlı gelmeyebilir. Yine de anlatımları takip ederken benim atıfta bulunduğum durumlarda bu bölüme dönüp açıklamara bakarsanız tüm kavram açıklamaları son derece anlaşılır olacaktır. Bu sayede kavramların anlamını ve kavramın geçtiği ilgili konu bütününü çok daha iyi anlamış olacaksınız. 

[Sistem Çağrıları (System Call)](Ekstra%20So%CC%88zlu%CC%88k%2019da18b09f454abf8ee9a79dcce15ef3/Sistem%20C%CC%A7ag%CC%86r%C4%B1lar%C4%B1%20(System%20Call)%20ebdb0340c20849358dcc4d912e5cc448.md)

[POSIX ve Betik Dosyalarının Taşınabilirliği Hakkında](Ekstra%20So%CC%88zlu%CC%88k%2019da18b09f454abf8ee9a79dcce15ef3/POSIX%20ve%20Betik%20Dosyalar%C4%B1n%C4%B1n%20Tas%CC%A7%C4%B1nabilirlig%CC%86i%20Hakk%2034e73f29553e4aa1a3955d0bb90ac6ed.md)

[Çatallama (Fork)](Ekstra%20So%CC%88zlu%CC%88k%2019da18b09f454abf8ee9a79dcce15ef3/C%CC%A7atallama%20(Fork)%20c4532ad4fef940419f8f40bacc2a0ebe.md)

[IFS Kavramı](Ekstra%20So%CC%88zlu%CC%88k%2019da18b09f454abf8ee9a79dcce15ef3/IFS%20Kavram%C4%B1%2043c7a6ee695040f3b3c8941c13d9b286.md)

*nix nedir ?

nix olarak kullanildiginda unix turevi sistemleri belirten tabir

EOF yapısının kullanımından da bahset

cat << EOF

>deneme

>metni

EOF

deneme

metni

[https://github.com/icy/bash-coding-style](https://github.com/icy/bash-coding-style)

# Tanımlar

## **Metakarakter:**

Alıntılanmadığı sürece kelimelerin birbirinden ayrılmasını sağlayan karakterdir. Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’ işaretlerinden biridir. Bu karakterlerin hepsi bash için özel anlam ifade eder. 

## **Operatörler:**

Özel işlevi olan ve en az bir metakarakter içeren işaretlerdir. Pek çok operatör çeşidi vardır. Operatör çeşitlerini aşağıdaki şekilde gruplayabiliriz. 

- Aritmetik operatörler('+', '-', '/', '*',...)
- Mantıksal operatörler('&&', '||', '!')
- Yönlendirme operatörleri ('<', '>', '>>', '>&'..)
- Dosya operatörleri ('-e', '-f', '-s'...)
- Karşılaştırma operatörleri
    - Metinsel karşılaştırma('-z', '-n', '=='..)
    - Sayısal karşılaştırma('-eq', '-ne', '-lt'..)
- Bit bazlı operatörler ('<<=', '~', '^='..)

Operatörlerin doğru şekilde tanınması için mutlaka ayırıcı özelliği olan metakarakterler de kullanılır. Metakarakterler operatörün içinde veya dışında kullanılabilir. Operatörün içinde olan yani operatörün parçası olarak ">&" operatörünü örnek verebiliriz. Harici olarak, içerisinde metakarakter içermese de özel anlamına yalnızca metakarakter dahilinde kavuşan "aritmetik operatöleri" örnek gösterebiliriz. Aritmetik operatörleri parantez olmadan kullandığınızda asıl işlevlerini göremezler. Zaten bu sebeple operatörlerde en az bir metakarakter bulunur şeklinde ifade ettik. 

Ayrıca vermiş olduğumuz listede elbette tüm operatörleri ele almadık. Konu anlatımı içerisinde tüm hepsinden bahsediyoruz. Bu liste genel fikir sahibi olmak için kurgulandı.

## **Kontrol Operatörleri:**

Bileşik komutlardaki basit komutları ayırmak için kullanılan metakarakterdir. Yeni satır ya da ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’, ‘)’ işaretlerinden herhangi birisi basit komutun sınırını belirtir. Yani basit komutlar bu metakaraterlerden bir ile bitirilir. Komutu onaylayıp yeni satıra geçmek için kullandığınız enter tuşu aslında bir "yeni satır" metakarakteri oluşturur ve basit komutun sonunu belirtir. Benzer şekilde sıralı şekilde komutlar girerken kullandığınız noktalı virgül de basit komutların birbirinden ayrıştırılmasını sağlayan belirteçtir. Her metakarakterin elbette kullanıldığı duruma göre özel işlevi vardır. Ancak hepsinin ortak noktası peşi sıra girilen basit komutların birbirinden ayrımı için belirteç olmalarıdır. 

These definitions are used throughout the remainder of this manual.

**`POSIX`**A family of open system standards based on Unix. Bash is primarily concerned with the Shell and Utilities portion of the POSIX 1003.1 standard.

**`blank`**A space or tab character.

**`builtin`**A command that is implemented internally by the shell itself, rather than by an executable program somewhere in the file system.

**`control operator`**A `token` that performs a control function. It is a `newline` or one of the following: ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’, or ‘)’.

**`exit status`**The value returned by a command to its caller. The value is restricted to eight bits, so the maximum value is 255.

**`field`**A unit of text that is the result of one of the shell expansions. After expansion, when executing a command, the resulting fields are used as the command name and arguments.

**`filename`**A string of characters used to identify a file.

**`job`**A set of processes comprising a pipeline, and any processes descended from it, that are all in the same process group.

**`job control`**A mechanism by which users can selectively stop (suspend) and restart (resume) execution of processes.

**`metacharacter`**A character that, when unquoted, separates words. A metacharacter is a `space`, `tab`, `newline`, or one of the following characters: ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, or ‘>’.

**`name`**A `word` consisting solely of letters, numbers, and underscores, and beginning with a letter or underscore. `Name`s are used as shell variable and function names. Also referred to as an `identifier`.

**`operator`**A `control operator` or a `redirection operator`. See [Redirections](https://www.gnu.org/software/bash/manual/html_node/Redirections.html), for a list of redirection operators. Operators contain at least one unquoted `metacharacter`.

**`process group`**A collection of related processes each having the same process group ID.

**`process group ID`**A unique identifier that represents a `process group` during its lifetime.

**`reserved word`**A `word` that has a special meaning to the shell. Most reserved words introduce shell flow control constructs, such as `for` and `while`.

**`return status`**A synonym for `exit status`.

**`signal`**A mechanism by which a process may be notified by the kernel of an event occurring in the system.

**`special builtin`**A shell builtin command that has been classified as special by the POSIX standard.

**`token`**A sequence of characters considered a single unit by the shell. It is either a `word` or an `operator`.

**`word`**A sequence of characters treated as a unit by the shell. Words may not include unquoted `metacharacters`.