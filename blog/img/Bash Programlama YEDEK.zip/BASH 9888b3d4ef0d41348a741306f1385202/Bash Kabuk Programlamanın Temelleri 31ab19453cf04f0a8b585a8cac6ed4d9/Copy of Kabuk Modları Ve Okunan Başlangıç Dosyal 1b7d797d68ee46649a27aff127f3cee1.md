# Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları

[https://notes.shichao.io/apue/ch9/](https://notes.shichao.io/apue/ch9/)

Bu bölümde özellikle sistem yönetiminde kabuğun etkili kullanımı için doğru konfigürasyonların doğru dosyada tanımlanması adına son derece önemli hususlara değiniyor olacağız. Bölüm sonunda konfigürasyon ayarlarınızı daha bilinçli şekilde gerçekleştirebileceğinize inanıyorum.

Tüm kavramların kolay anlaşılabilmesi için çok kısaca ve detaysız şekilde sistemin açılmasından bash kabuğunun başlatılmasına kadar geçen aşamalı ele alacağız. Bu işleyişin, kullanmakta olduğunuz sistemin konfigürasyonuna göre tamamen farklılık gösterebileceğini dikkate alarak okumanız gerektiğini de baştan belirteyim. Biz sadece temel işleyiş hakkında kafamızda soru işareti kalmaması için istisnaları gözardı ederek genel işleyişten bahsediyor olacağız. 

Temelde, grafiksel ve komut satırı olmak üzere iki ayrı kullanıcı arayüzüne sahip olduğumuzu biliyoruz. Sahip olduğumuz sistemin hangi arayüz ortamı ile açıldığına bağlı olarak sistemin başlangıçta çalıştıracağı işlemler ve okuyacağı konfigürasyon dosyaları elbette değişik gösteriyor. Yine de sistemin açılışını ortak şekilde aşağıdaki şekilde genelleyebiliriz;

1. **BIOS** : Bios un donanım kontrolü yapıp, işletim sistemini yükleyeceği bilgilere ulaşması.
2. **MBR** : İşletim sistemini yükleyecek olan bootstrap programının bulunup çalıştrılması.
3. **GRUB** : Bootstrap programının işletim sistemi çekirdeğini yüklemesi.
4. **KERNEL** : Linux çekirdeğinin çalışması ve init process nin başlatılması.
5. **INIT** : Init process inin çalışması.
6. **RUNLEVEL** : Init process inin gerekli servis ve işlemleri başlatması.

Tüm bu aşamalardan sonra sistemimiz, daha önce tanımlandığı şekilde grafiksel ya da komut satırı arayüzü için gerekli olan işlemleri çalıştırıyor.

Öncelikle, sistemimizin komut satırı arayüzü ile açıldığını varsayarsak, tty konsolu üzerinden oturum açmamız beklenecektir. Şimdi kısaca bu oturum açma aşamasına değinelim.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled.png)

[https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1](https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1)

[https://unix.stackexchange.com/questions/38175/difference-between-login-shell-and-non-login-shell/46856#46856](https://unix.stackexchange.com/questions/38175/difference-between-login-shell-and-non-login-shell/46856#46856)

[https://learning.lpi.org/en/learning-materials/102-500/105/105.1/105.1_01/](https://learning.lpi.org/en/learning-materials/102-500/105/105.1/105.1_01/)

Çekirdeğimiz ilk işlem olan init(ya da systemd) işlemi başlatır. Init daha önce ilgili konfigürasyon dosyalarında tanımlanmış olan aktif tty konsolları sayısınca fork ile çatallanır. Çatallanmış olan init exec ile getty işlemine dönüştürülür. 

getty açık olan tty konsoluna kullanıcı tarafından kullanıcı adı girilene kadar bekler, kullanıcı adı bilgisini aldıklarında login işlemi exec ile oluşturulup kullanıcı adı argüman olarak login işlemine aktarılır.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%201.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%201.png)

Argüman olarak kullanıcı adını alan login işlemi kullanıcıdan parola girmesini ister. Kullanıcı parola girdikten sonra kullanıcı adı ve parola eşleşmesini doğrulamak üzere /etc/passwd ve /etc/shadow dosyalarına bakar. 

Bu sırada /etc/passwd dosyasından mevcut kullanıcı hesabına ait username, UID, GID, home directory, user shell gibi bilgiler okunup $USER, $UID, $GID, $HOME $SHELL değişkenlerine tanımlanmış olur.

Kullanıcı adı ve parolası doğru girilmiş ise ilgili kullanıcının /etc/passwd dosyasında yer alan kabuk bilgisine göre login shell yani oturum açma kabuğu olarak başlatır.

Eğer etkinleştirilmişse /etc/motd dosyasındaki mesaj konsola bastırılır. 

Oturum açma kabuğumuz için 0, 1 ve 2 dosya tanımlayıcıları terminal cihazına ayarlanır.

Bu aşamada kabuğun konfigürasyonları için sırasıyla ilgili dosyalar okunur.

kullanıcı kabuğu için ayarlamamız gereken herhangi bir takma adı veya bir tür değişkenleri içe aktarmak için / etc / profile dosyası okunur.

/ Etc / profile dosyasını okumayı tamamladığında, kullanıcı ana dizini içeriğini okuyacak ve varsayılan kabuğu bash ise kullanıcı kabuk özelliklerini .bashrc, .bash_profile'a göre değiştirecektir. 

Ardından, bu üç dosyadan herhangi birine şu sırayla bakmaya gider: 

~ / .bash_profile 

~ / .bash_login 

~ / .profile 

Birini bulduğunda çalıştırır ve diğerlerini atlar.

En nihayetinde kullanıcının komutlarını yürütmesi için PS1 istemi sunulur. Bu sayede başlatılan giriş kabuğu altında sistemi kabuk üzerinden yönetebiliriz.

Aşağıda username/password bilgisi girdikten sonraki süreci görebiliriz.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%202.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%202.png)

Komut satırı arayüzünde bu işleyiş hakimdir. Eğer grafiksel arayüzde oturum açarsanız işleyiş daha farklı olacaktır.

Eğer kullanmakta olduğumuz sistem grafiksel arayüz içeriyorsa ve sistem başlangıcında açılacak şekilde konfigüre edildiyse graksel arayüz yardımıyla oturum açarız. Elbette bu durumda sistemi grafiksel arayüz ortamı ile yönetmemiz beklendiğinden bize hemen bir kabuk tahsis edilmez. Grafiksel arayüze sahip oturum açma aşamasından sonra yine masaüstü ortamı ve pencere yöneticileri gibi grafiksel arayüz araçları başlatılır. Eğer grafiksel arayüz üzerinde konsol yani terminal aracını açarsak terminal aracı daha önce ayarlandığı şekilde bir kabuk başlatacaktır. Kullandığınız terminal aracının özelliklerine göre değişmekle birlikte çoğu terminal aracı varsayılan olarak oturum açma olmayan etkileşimli kabuk ile başlar. Dolayısıyla grafiksel arayüz üzerinde terminal aracı ile çağırdığınız kabuk daha önce komut satırı arayüzünde başlatılan "oturum açma kabuğu"^nun okuduğu dosyaları okumaz. Yalnızca oturum açma olmayan etkileşimli kabuk için tanımlı olan konfigürasyon dosyalarını okur. Bu modda / etc / bashrc ve ~ / .bashrc dosyası okunur. Bu dosyaların ayrıntılı açıklaması için aşağıya bakın.

Eğer grafiksel arayüzü kullanarak oturum açarsanız, başlangıçta okunacak olan dosyalar değişiklik gösterebilir. Örneğin çoğu dağıtım grafiksel arayüz üzerinden oturum açıldığında oturum açma kabuğu sunmaz. Dolayısıyla oturum açma kabuğu açılırken okunan dosyalar da grafiksel arayüz ile oturum açılırken okunmaz. Yine de hangi dosyanın okunacağınıza veya kabuğun ne şekilde başlatılacağını kullanılan dağıtımdaki grafiksel arayüz sağlayıcısı için kontrol etmeniz gerekir.  Ayrıca elbette gerekli konfigürasyonlar yapılarak grafiksel arayüz ile oturum açılırken de oturum açma kabuğunda okunan dosyaların okunmasını sağlayabilirsiniz. Bizler kabuğun oturum açma modunda hangi dosyaları okuduğuna dolayısıyla nasıl bir ortama sahip olduğuna odaklanıyor olacağız. 

Neticede grafiksel arayüzün kullanımı için gereken ve komut satırı arayüzü kullanımı için gereken şartlar farklı olduğundan zaten komut satırı üzerinden oturum açtığımızda oturum açma kabuğunun başlatılması son derece normal. Komut satırı üzerinden işlem yapıyorken tüm işlemlerimizi mevcut kabuğun altında gerçekleştireceğimiz için ilk başlatılan kabuğun oturum açma kabuğu olması çok mantıklıdır. Bu sayede bizler komut satırı üzerinde oturum açtığımızda daha önce oturum açma kabuğu için özellikle tanımlamış olduğumuz konfigürasyon ayarlarının geçerli olmasını sağlayabiliriz. Bu sayede komut satırı üzerinde konforlu bir çalışma ortamı elde etmiş oluruz. Neticede oturum açma kabuğu özellikle ilk oturum açılırken kabuk ortamını iyi biçimde ayarlamak için vardır. 

Komut satırı arayüzünde ilk başlatılan işlem kabuk olacağı ve biz bu kabuk üzerinde çalışacağımız için oturum açma kabuğu olarak başlar. Oturum kabuğu belirli dosyalardan konfigürsayonlarını okur. Bizler de komut satırında çalışırken sahip olmak istediğimiz ayarlamaları bu kabuk başlatılırken okunun bu dosyalara ekleriz. 

Ancak grafiksel arayüzde buna doğrudan gerek yoktur. Çünkü grafiksel arayüz ortamı ile oturum açtığımızda zaten masaüsütü ortmaı gibi grafiksel arayüz araçları üzerinde çalışırız. Eğer kabuğa emirler vermek istersek terminal aracını açıp emirlerimizi verebiliriz. Grafiksel arayüzde çalıştırdığımız terminal araçları özellikle ayarlanmadığı sürece oturum açma olmayan interaktif kabuklar ile başlarlar. Çünkü grafiksel arayüzde pek çok terminal aracı açabiliriz. Ve her terminal açtığımızda giriş kabuğunda geçerli olan ayarlamanın yapılması pek makul değildir. Giriş kabuğu daha çok tek sefer ayarlanıp, kabuğun altında çalışacağı diğer kabukları etkili şekilde yönetebileceğimiz ayarlamalrı içeriri. Grafiksel arayüzde tek bir kabuk altında çalışmadığımız için oturum kabuğuna ihtiyacımız yoktur. Yine de oturum açma olmayan interaktif kabuk da kendi konfigürasyonlarını birtakım dosyalardan okur. Eğer her terminal açıldığında yapılmasını istediğimiz bir ayarlama varsa bu dosyalara uygun şekilde ekleyebiliriz.

Oturum açama kabuğu; tty ile oturum açarken, ssh ile ya da bash kabuğunu -l veya —login seçeneği ile çağırarak kullanılabilir.

Oturum açma olmayan interaktif kabuk; Konsol araçları ya da doğrudan bash şeklinde çağırılan bash kabuğu ile ulaştığımız kabuktur.

[https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1](https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1)

Daha detaylı bilgi için;

[https://notes.shichao.io/apue/ch9/#process-groups](https://notes.shichao.io/apue/ch9/#process-groups)

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%203.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%203.png)

Bash kabuğu kullanılacağı alana göre birden fazla kullanım moduna sahiptir. Kullanım modlarının amaçları doğrultusunda elbette kabuğun başlangıçta ve kapanışta okuyup çalıştıracağı dosyalar da farklıdır. Kabuğun aslında bize grafiksel arayüze alternatif olarak bir çalışma ortamı sunan bir araç olduğundan birçok kez bahsettik. Söz konusu kabuğun yani aracın da aslında pek çok farklı çalışma için uygun seçenekeleri vardır. Çalışılacak ortamın elbette gerçekleştirilecek işlere uygun şekilde konfigüre edilmesi gerekiyor. Gerekli konfigürasyonları da çalışma moduna göre uygun dosyalardan okuyarak gerçekleştiriyor. 

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%204.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%204.png)

Bash kabuğu başlatılırken, çalıştırılacağı moda göre birtakım dosyalardan konfigürasyon ayarlarını okur. Çalıştırılan kabuk modunun ve dolayısıyla hangi modda hangi dosyaların okunduğunun bilinmesi, üzerinde çalışılacak kabuk ortamının doğru şekilde ayarlanabilmesi adına son derece önemlidir. Bizler de kabuk modlarını ve modlara göre okunan konfigürasyon dosyalarını daha etkili kullanabilmek adına genel olarak el alıyor olacağız. 

Temelde kabuk "etkileşimli" ve "oturum açma" olmak üzere iki moda sahiptir. 

Yine de bu modların kombinasyonu ile bash kabuğu "etkileşimli" "etkileşimsiz" "oturum açma" "oturum açma olmayan" olmak üzere 4 temel kullanım modu sunuyor. Bu modlar kullanım amaçları doğrultusunda birtakım konfigürasyon dosyalarının okunmasının yanında ayrıca çeşitli kabuk özellikleri aktif veya kapalı olacak bir kabuk ortamı da sunarlar. 

[https://linuxhandbook.com/login-shell/](https://linuxhandbook.com/login-shell/)

## Giriş Kabuğu | Login Shell

Oturum açma kabuğu, etkileşimli bir oturum için bir ana bilgisayarda oturum açtığınızda aldığınız ilk kabuktur. Bir giriş kabuğu, bir kullanıcı adı / şifre kombinasyonunun girilmesini gerektirmez. Bash komutun —login seçeneği ile de giriş kabuğu çağırılabilir.

Bir giriş kabuğu, ilk kez bir bash kabuğu aldığınızda temel ortamınızı kurar.

Bir giriş kabuğundaysanız, bash / etc / profile dosyasını arar ve varsa çalıştırır.

Ardından, bu üç dosyadan herhangi birine şu sırayla bakmaya gider: 

~ / .bash_profile 

~ / .bash_login 

~ / .profile 

Birini bulduğunda çalıştırır ve diğerlerini atlar.

Mevcut kabuğun giriş kabuğu olup olmadığını anlamanın en doğru yolu shopt login_shell komutuyla teyit etmektir. Alternatif olarak echo $0 komutu ile çalıştırılan aracın ilk argümanınını yani çalıştırılan aracı bastırabiliriz. Çıktıda -bash şeklinde başında eksi işareti alıyorsak mevcut kabuk login kabuğudur. Ancak bu durum bash kabuğunu -l ya da —login seçenekleri ile çağırdığımızda gerçekleşmediği teyit etmek üzere kullanılamaz. Bash kabuğu -l ya da —login seçenekleri ile de çağırıldığında login kabuğudur ancak echo $0 çıktısında -bash sonucu vermez. Bu sebeple mevcut kabuğun oturum açma kabuğu olup olmadığını aşağıdaki şekilde teyit etmeniz en sağlıklısı olacaktır.

```jsx
shopt -q login_shell && echo "Login shell" || echo "Not login shell"
```

## Etkileşimli Kabuk

Eğitimin başında etkileşimli kabuğun, anlık olarak kabuğa emirler verdiğimiz ve sonucunda konsolda sonuçlarını gördüğümüz şeklinde tanımlamıştık. Ancak hepsi bundan ibaret değil. 

Örneğin bir kabuk etkileşimli olarak başlatılmadan da read komutu sayesinde gerektiğinde kullanıcıdan veri alabilir. Yani bir kabuğun etkileşimsiz olması demek o kabuğun kullanıcı ile hiç bir etkileşim kurmayacağı anlamına gelmiyor. Etkileşimli kabuğun esas önemi, etkileşimli kullanımda ihtiyaç duyulacak çalışma ortamı için kabuğu uygun özelliklerle donatıyor olmasıdır. Dolayısıyla etkileşimsiz bir kabuğu da gerekli ayarlamayı yaparak etkileşimli kabuktaki ortamı sunmasını sağlayabiliriz. Kabuğun temel modları sunmasındaki amaç, kullanım amacına uygun önceden ayarlanmış kabuk çalışma ortamının sağlanabilmesidir.

Modların sahip olduğu özellikler kabuk üzerinde varsayılan olarak tanımlanmıştır. Dilerseniz kabuğun kaynak kodlarını temin edip "***shell.c***" dosyası içinde kabuk modlarına göre hangi özelliklerin aktif hangilerinin deaktif olduğu gibi pek çok varsayılan detaya ulaşabilirsiniz. 

[https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell](https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell)

Kabuk etkileşimli olarak çalıştığında, davranışını çeşitli şekillerde değiştirir.

1. Kabuk başlangıcında okunan dosyalar başlığı alıntıda açıklanan dosyalar okunur.
2. İş Kontrolü varsayılan olarak etkindir. İş denetimi etkin olduğunda, Bash, klavye tarafından oluşturulan iş denetim sinyallerini SIGTTIN, SIGTTOU ve SIGTSTP'yi yok sayar.
3. Bash expands and displays `PS1` before reading the first line of a command, and expands and displays `PS2` before reading the second and subsequent lines of a multi-line command. Bash expands and displays `PS0` after it reads a command but before executing it. See [Controlling the Prompt](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html), for a complete list of prompt string escape sequences.
4. Bash executes the values of the set elements of the `PROMPT_COMMAND` array variable as commands before printing the primary prompt, `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
5. Readline (see [Command Line Editing](https://www.gnu.org/software/bash/manual/html_node/Command-Line-Editing.html)) is used to read commands from the user’s terminal.
6. Bash inspects the value of the `ignoreeof` option to `set -o` instead of exiting immediately when it receives an `EOF` on its standard input when reading a command (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
7. Command history (see [Bash History Facilities](https://www.gnu.org/software/bash/manual/html_node/Bash-History-Facilities.html)) and history expansion (see [History Interaction](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html)) are enabled by default. Bash will save the command history to the file named by `$HISTFILE` when a shell with history enabled exits.
8. Alias expansion (see [Aliases](https://www.gnu.org/software/bash/manual/html_node/Aliases.html)) is performed by default.
9. In the absence of any traps, Bash ignores `SIGTERM` (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
10. In the absence of any traps, `SIGINT` is caught and handled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)). `SIGINT` will interrupt some shell builtins.
11. An interactive login shell sends a `SIGHUP` to all jobs on exit if the `huponexit` shell option has been enabled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
12. The  invocation option is ignored, and ‘’ has no effect (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    - n
    
    set -n
    
13. Bash will check for mail periodically, depending on the values of the `MAIL`, `MAILPATH`, and `MAILCHECK` shell variables (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
14. Expansion errors due to references to unbound shell variables after ‘’ has been enabled will not cause the shell to exit (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    
    set -u
    
15. The shell will not exit on expansion errors caused by  being unset or null in `${*var*:?*word*}` expansions (see [Shell Parameter Expansion](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html)).
    
    *var*
    
16. Redirection errors encountered by shell builtins will not cause the shell to exit.
17. When running in  mode, a special builtin returning an error status will not cause the shell to exit (see [Bash POSIX Mode](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html)).
    
    POSIX
    
18. A failed `exec` will not cause the shell to exit (see [Bourne Shell Builtins](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html)).
19. Parser syntax errors will not cause the shell to exit.
20. Simple spelling correction for directory arguments to the `cd` builtin is enabled by default (see the description of the `cdspell` option to the `shopt` builtin in [The Shopt Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html)).
21. The shell will check the value of the `TMOUT` variable and exit if a command is not read within the specified number of seconds after printing `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).

## Etkileşimli Oturum Açma Kabuğu

Tty konsollarından birinde ya da ssh bağlantısı ile makinede oturum açıp komutlar verebildiğimiz kabuk modudur. Kullanmakta olduğunu kabuğun oturum açma kabuğua olup olmadığını denetlemek için shopt login_shell komutunu ya da echo $0 komutunda yer alan -bash çıktısı ile teyit edebilirsiniz.

Bu tür bir kabuğun yapılandırmasıyla ilgili olarak, üç dosya dikkate alınır. Bunlar / etc / profile, ~ / .profile ve ~ / .bash_profile'dır. Bu dosyaların ayrıntılı açıklamasını daha sonra yapıyor olacağız.

## Etkileşimli Oturum Açma Olmayan Kabuk

Bu mod, örneğin xterm veya Gnome Terminal gibi yeni bir terminal açmayı ve içinde bir kabuk çalıştırmayı açıklar. Bu modda / etc / bashrc ve ~ / .bashrc dosyası okunur. Bu dosyaların ayrıntılı açıklaması için aşağıya bakın.

## Etkileşimli ve Oturum Açma Olmayan Kabuk

Bu mod, bir kabuk komut dosyası yürütülürken kullanımdadır. Kabuk betiği kendi alt kabuğunda çalışır. Kullanıcı girişi istemediği sürece etkileşimli olmayan olarak sınıflandırılır. Kabuk yalnızca betiği çalıştırmak için açılır ve komut dosyası sona erdiğinde hemen kapatır.

```jsx
./local-script.sh
```

## Etkileşimli Olmayan Oturum Açma Kabuğu

Bu mod, bir bilgisayara, örneğin Secure Shell (ssh) aracılığıyla bir uzaktan kumandadan oturum açmayı kapsar. [Local-script.sh](http://local-script.sh/) kabuk betiği önce yerel olarak çalıştırılır ve çıktısı ssh girdisi olarak kullanılır.

```jsx
./local-script.sh | ssh user@remote-system
```

Ssh'ı başka bir komut olmadan başlatmak, uzaktaki sistemde bir oturum açma kabuğu başlatır. Ssh'nin girdi aygıtının (stdin) uçbirim olmaması durumunda, ssh etkileşimli olmayan bir kabuk başlatır ve komut dosyasının çıktısını uzaktaki sistemde yürütülecek komutlar olarak yorumlar. Aşağıdaki örnek, uzak sistemde uptime komutunu çalıştırır:

```jsx
$ echo "uptime" | ssh localhost

Pseudo-terminal will not be allocated because stdin is not a terminal.

frank@localhost's password:

The programs included with the Debian GNU/Linux system are free software;

the exact distribution terms for each program are described in the

individual files in /usr/share/doc/*/copyright.

Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent

permitted by applicable law.

You have new mail.

 11:58:49 up 23 days, 11:41,  6 users,  load average: 0,10, 0,14, 0,20

$
```

İlginç bir şekilde, ssh, stdin'in bir uçbirim olmadığından şikayet eder ve / etc / motd global yapılandırma dosyasında saklanan günün mesajını (motd) gösterir. Terminal çıkışını kısaltmak için, aşağıda gösterildiği gibi ssh komutunun bir parametresi olarak "sh" seçeneğini ekleyin. Sonuç olarak önce bir kabuk açılır ve iki komut ilk önce motd görüntülenmeden çalıştırılır.

```jsx
$ echo "uptime" | ssh localhost sh

frank@localhost's password:

 12:03:39 up 23 days, 11:46,  6 users,  load average: 0,07, 0,09, 0,16

$$
```

## Login Shell

It reads and executes commands from the first available file (if exists) during login session in the following order:

1. /etc/profile
2. ~/.bash_profile,
3. ~/.bash_login, and
4. ~/.profile

It reads and executes commands from all files (if exists) during logout in the following order:

1. ~/.bash_logout and
2. /etc/bash.bash_logout

## Non-Login Shell

[https://askubuntu.com/questions/879364/differentiate-interactive-login-and-non-interactive-non-login-shell](https://askubuntu.com/questions/879364/differentiate-interactive-login-and-non-interactive-non-login-shell)