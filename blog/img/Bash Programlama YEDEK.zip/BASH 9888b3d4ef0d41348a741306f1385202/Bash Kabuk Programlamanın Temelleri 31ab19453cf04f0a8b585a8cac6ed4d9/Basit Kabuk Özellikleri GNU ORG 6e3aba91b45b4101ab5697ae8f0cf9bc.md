# Basit Kabuk Özellikleri | GNU.ORG

[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[3.1 Bash Sentaks(syntax) Yapısı](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%206e3aba91b45b4101ab5697ae8f0cf9bc/3%201%20Bash%20Sentaks(syntax)%20Yap%C4%B1s%C4%B1%2002bf9f87b38f47b3986658e6770d3161.md)

[3.2 Kabuk Komutları](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%206e3aba91b45b4101ab5697ae8f0cf9bc/3%202%20Kabuk%20Komutlar%C4%B1%201dd190229a684d7a876dc6da1557fcb0.md)