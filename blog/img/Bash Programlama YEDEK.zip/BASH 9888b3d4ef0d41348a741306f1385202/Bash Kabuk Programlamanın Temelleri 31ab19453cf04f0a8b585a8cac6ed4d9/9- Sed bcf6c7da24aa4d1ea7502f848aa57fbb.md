# 9- Sed

Sed esasen esnek kullanıma sahip metinsel veri düzenleme aracıdır ve sed ifadesinin açılımı "**s**tream **ed**itor" yani "akış düzenleyicisi" şeklindedir.

Dosya, standart girdi veya boru hattı(pipeline) gibi bir kaynaktan gelen metinsel verileri yani akış halindeki verileri, istenilen şekilde değiştirmek için kullanılan efektif bir araçtır. Özellikle düzenli ifadelerle birlikte kullanıldığında son derece güçlü bir araçtır. 

Özetle, bizler sed aracını kullanarak metinler üzerinde anlık olarak çeşitli değişiklikler yapabiliyoruz. Değişiklikleri konsoldan komut girerek ya da daha önceden bir dosyaya kaydedilmiş komutların çalıştırılmasını sağlayarak gerçekleştirebiliyoruz. Yani sed aracını hem etkileşimli olarak kullanabilir hem de tekrar eden işleriniz için programlayabilirsiniz. Açıklamalar yetersiz veya kafa karıştırıcı mı ? Hadi yakından göz atalım.

Aşağıdaki tablodan kullanabileceğimiz parametrelere kısaca göz atabilirsiniz.

[Untitled](9-%20Sed%20bcf6c7da24aa4d1ea7502f848aa57fbb/Untitled%20Database%2084b68a0de9aa4aaeb1cba6931c0a2d98.md)

[Untitled](9-%20Sed%20bcf6c7da24aa4d1ea7502f848aa57fbb/Untitled%20Database%20f6cfee469b474955a88bcdbdcb2da625.md)

En yalın hali ile sed editörüne işlenmemiş metinsel veri aktaracağız, sed editörü de aldığı metinsel verileri bizim istediğimiz forma çevirip bize çıktı olarak verecek. Çünkü herhangi bir işlem sonucunda, elde ettiğimiz sonuçlar tam olarak bizim işimize yarayacak metinsel formda olmayabilir. Daha okunaklı olması veya başka bir araca aktarılabilmesi için elimizdeki metinsel verilerin dönüştürülmesi gerekebilir. Zaten bu durumu yönlendirmeler başlığı altında detaylıca ele aldık. Yönlendirmeler yaparak pek çok aracı bir arada kullanabiliriz. Bu müthiş bir avantaj. 

Sed aracı başlı başına çok kapsamlı bir araç olduğu için ben yalnızca en temel ve sık kullanılan özelliklerinden bahsedeceğim. Daha fazlası için gnu dokümantasyonlarına bakabilirsiniz. 

Sed aracı en temelde `sed kural işlenecek_veri` şeklinde kullanılır.

Öncelikle sed editörünün en sık kullanılan temel özelliği ile başlayarak; istediğimiz nitelikte veriyi bulup değiştirme işlevini gerçekleştirelim.

Metin içerisinde değiştirmek istediğimiz ifadeleri `sed` komutunun `s` operatörü sayesinde yeni arzu ettiğimiz ifadeler ile değiştirebiliyoruz.

**Her satırda** yer alan ve **aradığımız ifade ile ilk eşleşen ifadeyi** yenisi ile değiştirmek istersek komutumuzu `sed "s/değiştirilecek_ifade/yeni_ifade/" dosya_adı` şeklinde kullanıyoruz.

Örnek olarak aşağıdaki metni içeren dosyayı kullanacağım.

*Bash bir kabuktur. Üstelik en yaygın kullanıma sahip kabuktur.*

*ZSH da bir kabuktur, ancak Bash kadar yaygın değildir.*

Örneğin belge isimli dosyada yer alan "**birer**" ifadesini "**sırayla**" ifadesi ile değiştirmek için aşağıdaki komutu giriyorum.

```
sed "s/kabuktur/shelldir/" metin.txt
```

Çıktıda da gördüğünüz gibi `sed` komutu her satırda yer alan ilk eşleşmeleri değiştirdi, yani aynı satırda geçen ikinci ifadeye dokunmadı.

![Screenshot_1.png](9-%20Sed%20bcf6c7da24aa4d1ea7502f848aa57fbb/Screenshot_1.png)

Eğer bizler satırda geçen ilk ifadeleri değil de ikinci ya da üçüncü ifadeyi değiştirmek isteseydik komutun sonuna değiştirmek istediğimiz sıra numarasını girmemiz yeterli olacaktı.
Örneğin yalnızca 2. eşleşmedeki ifade değişsin istersem;

```
sed "s/birer/sırayla/2" belge
```

Ya da 4. eşleşme değişmesi için;

```
sed "s/birer/sırayla/2" belge
```

Şayet satırda geçen tek bir ifade yerine tüm ifadeleri kapsasın istersek bu sefer g operatörünü kullanmamız gerekiyor.
Hemen aynı örneği bu sefer g operatörünü ile tekrar ele alalım.

```
sed "s/birer/sırayla/g" belge
```

Gördüğünüz gibi satır üzerindeki tüm eşleşen ifadeler değişmiş oldu.

Kullandığımız örnek dosya kısa içeriğe sahip bu yüzden hangi kısımların değiştirildiğini anlamada zorluk yaşamıyoruz. Ancak uzun içerikli verilerde yalnızca değiştirilmiş olan kısımları görmek isteyebiliriz. Böyle bir durumda p operatörünü kullanabiliyoruz.

```
 sed "s/birer/sırayla/gp" belge
```

Gördüğünüz gibi konsol değiştirilmiş olan satırları tekrar basılarak bize bu satırların değişmiş olduğunu bildirmiş oldu. Ancak bizler iki kez aynı satırı görmek istemezsek sed komutuna vereceğimiz -n parametresi ile yalnızca değiştirilmiş olan satırların birer kez listelenmesini sağlayabiliyoruz.

```
 sed -n "s/birer/sırayla/gp" belge
```

Ayrıca fark ettiyseniz g ve p operatörlerini aynı anda kullanabildik. Bu sed komutunun aynı anda birden fazla operatör alabildiğini gösteriyor.

Şu ana kadar yalnızca mevcut bir dosyadaki verileri düzenleme üzerine örnekler yaptık. Ancak mevcut bir belgedeki verileri düzenlemek yerine anlık olarak alınan verileri de düzenleyip çıktı olarak bastırabiliriz.

Yani örneğin top komutunun çıktılarında yer alan Xorg ifadesi yerine "görüntü" ifadesinin basılmasını sağlayabiliriz.
Bunun için konsola `top | sed "s/Xorg/görüntü/"` komutunu girmemiz yeterli.

Gördüğünüz gibi sed komutu talep ettiğimiz işlemi hızlı bir biçimde yerine getirip ekrana basıyor. Ancak burada dikkat edilmesi gereken şey, sed komutunun mevcut veriler üzerinde kalıcı değişiklik yapmadan yalnızca çıktılar üzerinde değişiklik yaptığıdır.

Eğer bizler yaptığımız değişiklikler kayıt olsun istiyorsak ilgili dosyaya yazdırma operatörünü kullanarak bunu belirtmemiz gerekiyor, aksi halde yapılan hiç bir değişiklik kayıt olmadan yalnızca komut satırına basılıyor olacak.
Yapılan değişikliğin kayıt olabilmesi için w operatörünü `sed 's/eski_veri/yeni_veri/w kayıt_dosyası' veri_kaynağı` şeklinde kullanmamız gerekiyor.

## Birden Çok Sed Linux Komutunu Kullanma

Eğer düzenlemek istediğimiz veriler birden fazla ise sed komutunun ardından -e parametresini kullanarak düzenlenecek verilerin arasına bir önceki veri ile arasında boşluk kalmayacak şekilde noktalı virgül koyarak çoklu işlemleri yerine getirebiliriz.
Kullanımı `sed -e 's/eski/yeni/; s/eski1/yeni1/' dosya` şeklindedir.

Ayrıca birden fazla komut girmek için tek tırnak da kullanabilirsiniz. sed komutunun ardından -e parametresini ekleyip tırnak işareti koyduktan sonra girmek istediğiniz komutları arka arkaya sıralayıp sonuna tek tırnak koyarak çoklu işlemler gerçekleştirebilirsiniz.

## Alternatif Karakter Kullanımı

Sed komutu ile düzenleyeceğimiz veri içerisinde slah işareti barındırıyorsa sed komutunun kullanımı şekli nedeniyle hataya neden olabiliyor.

Yani örneğin ben **/bin/bash/** ifadesini **/shell-kabuk ** şeklinde değiştirmek istersem `sed "s//bin/bash///shell-kabuk/"` kullanımı hatalı olacaktır. Sed komutu ile birlikte slash işareti kullanmamız gerektiğinde, slash işaretinden önce kaçış işareti yani ters slash kullanmamız gerekiyor.

```
 sed "s/\\/bin/bash/\\/\\/shell-kabuk/" 

```

Ancak bu kullanım da gördüğünüz gibi oldukça karmaşık duruyor. Yani daha sonra bu komutları okurken işaretleri ayırt etmek epey zor olacaktır. Bu durumda önüne geçmek için de kaçış işareti kullanmak yerine sed komutunun slash işaretlerini eksi, artı, alt çizgi, ünlem veya pipe işareti gibi diğer işaretler ile değiştirebiliriz. Örnek kullanımlar için aşağıdaki komutlara göz atabilirsiniz.

```
sed "s-/bin/bash/-/shell-kabuk-"
sed "s+/bin/bash/+/shell-kabuk+"
sed "s_/bin/bash/_/shell-kabuk_"
sed "s!/bin/bash/!/shell-kabuk!"  
sed "s|/bin/bash/|/shell-kabuk|" 

```

Gördüğünüz gibi ters slash kullanmak yerine bu şekilde yazdığımız komutlar çok daha okunaklı oluyor ve sorunsuz şekilde işlevini yerine getirmeye devam ediyor.

Peki o zaman bizler şu ana kadar neden sed komutu ile birlikte her zaman slash işareti kullandık diyecek olursanız; Bunun nedeni sed komutu ile slash kullanımının geliştiriciler tarafından sıklıkla tercih edilmesindendir. Yani bizlerin diğer işaretler(eksi, artı, alt çizgi, ünlem, pipe işareti vs.. ) yerine slash işaretini kullanmanız, kodlarınızın daha okunaklı olmasını sağlayacaktır. Bu sebepten slash yerine kullanacağınız diğer tüm işaretleri yalnızca yukarıdaki örnekte olduğu gibi kodların karmaşık gözüktüğü durumda kullanmanızı tavsiye ederim.

## Sed sınırlaması

Sed komutu biz bir sınır koymadığımız sürece tüm alınan veriyi işler. Eğer verilerin tamamı işlenmesin, sadece ihtiyacımız olan kısım kadarlık veriyi işletelim istersek bunun için iki farklı kullanım yöntemi bulunuyor;

- Özel belirtilmiş satırın işlenmesi.
- Özel belirtilmiş satır aralığındaki verilerin işlenmesi.

İşlenecek veriyi belirli bir satıra sınırlamak için bir numara yazabilirsiniz:

$ sed '2s / test / başka bir test /' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/11-sed-restricted.png](https://likegeeks.com/wp-content/uploads/2017/02/11-sed-restricted.png)

Gördüğünüz gibi sadece ikinci satır değiştirildi.

Şimdi de diğer yöntem olan belirtilen satır aralığındaki verileri değiştirmeyi deneyelim.

$ sed '2,4s / test / başka bir test /' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/12-sed-replace-range-of-lines.png](https://likegeeks.com/wp-content/uploads/2017/02/12-sed-replace-range-of-lines.png)

Gördüğünüz gibi çıktımız 2 .ile 4. satır aralığında oldu.
Ayrıca düzenli ifadeleri kullanarak, bir satırdan dosyanın sonuna kadar kapsayacak şekilde de komut girebiliriz.

$ sed '2, $ s / test / başka bir test /' myfile

![https://likegeeks.com/wp-content/uploads/2017/02/13-sed-replace-to-the-end.png](https://likegeeks.com/wp-content/uploads/2017/02/13-sed-replace-to-the-end.png)

Ve ayrıca işlenecek veriyi sınırlandırmak adına başlangıcında yer alan ifadeyi de kapsam dahiline alarak, ihtiyacınız olan spesifik verilerin işleme alınmasını sağlayabilirsiniz.

$ sed '/ likegeeks / s / bash / csh /' / etc / passwd

![https://likegeeks.com/wp-content/uploads/2017/02/14-sed-pattern-match.png](https://likegeeks.com/wp-content/uploads/2017/02/14-sed-pattern-match.png)

Bu örnekleri çoğaltmak mümkün ancak genel olarak düzenli ifadelerin kullanımı ile sıns

## Satırları Sil

Sed aracı ile satır silme işlevinde d operatörünü kullanıyoruz.
Örneğin alınan verideki 2. satırda yer alanları silmek istersek komutumuzu aşağıdaki şekilde kullanabiliyoruz.

$ sed '2d' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/15-sed-delete-line-1.png](https://likegeeks.com/wp-content/uploads/2017/02/15-sed-delete-line-1.png)

Bu örnekte yalnızca 2. satırda yer alan veriyi sildik ancak dilersek daha önce de yaptığımız gibi belirli bir satır aralığını da kapsam dahilinde tutabiliriz.

Örneğin alınan verideki 2 ila 5. satırların hepsini silmek istersek komutumuzu aşağıdaki şekilde kullanabiliyoruz.

$ sed '2,5d' myfile

![https://likegeeks.com/wp-content/uploads/2017/02/16-sed-delete-multiple-line.png](https://likegeeks.com/wp-content/uploads/2017/02/16-sed-delete-multiple-line.png)

Gördüğünüz gibi 2 ile 5. satırların hepsi silinmiş oldu.

Aynı şekilde düzenli ifadeleri kullanarak da aralık belirterek, ilgili verilerin silinmesini sağlayabiliriz.

$ sed '3, $ d' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/17-sed-delete-to-the-end.png](https://likegeeks.com/wp-content/uploads/2017/02/17-sed-delete-to-the-end.png)

Çıktı da gördüğünüz gibi 3. satırdan sonuncu satıra kadar tüm veriler silinmiş oldu.

Tüm bu işlemlerin orjinal veri içeriğinde değişiklik yapmadığınız ve yalnızca komut satırımızda çıktı olarak gösterildiğini unutmayın lütfen. Eğer bu veriler kayıt olsun istiyorsanız w operatörünü kullanmanız gerektiğini de biliyorsunuz.

Bunlar dışında ilgili ifadenin eşleştiği satırların silinmesini de sağlayabiliriz. Örneğin ben içerisinde test ifadesinin geçtiği tüm satırların silinmesini istersem komutumu aşağıdaki şekilde kullanmam yeterli oluyor.

$ sed '/ test / d' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/18-sed-delete-pattern-match.png](https://likegeeks.com/wp-content/uploads/2017/02/18-sed-delete-pattern-match.png)

Ayrıca belirteceğimiz iki ifadenin aralığında geçen tüm satırların da silinmesini sağlayabiliriz.
Örneğin "ikinci" ifadesinin geçtiği kısımdan başlayarak "dördüncü" ifadesine kadar olan kısımların silinmesini istersem aşağıdaki komut bütünü kullanmam yeterli oluyor.

$ sed '/ birinci /, / dördüncü / d' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/19-sed-delete-range-of-lines.png](https://likegeeks.com/wp-content/uploads/2017/02/19-sed-delete-range-of-lines.png)

Çıktıda da gördünüz gibi belirttiğim şekilde ikinci ifadesinden dördüncü ifadesine kadar olan satırlar silinmiş oldu.

## Ekleme işlemleri

Sed editörü ile içeriğe yeni veri ekleme işlemini, alınan verinin başına ya da sonuna olacak şekilde iki farklı yoldan yapabiliyoruz.

Eğer yeni veriyi satır başına eklemek istersek i operatörünü aşağıdaki şekilde kullanıyoruz;

```
sed 'i \\ satır başı verisi' dosya

```

Aldığımız çıktı biraz tuhaf gözüküyor olabilir. Zira bizim beklediğimiz şey yalnızca en baştaki satıra "satır başı verisi" ifadesinin basılmasıydı. Ancak çıktılarda her bir satırdan önce bu ifade tekrar tekrar basılmış olarak gözüküyor.
Aslında burada yanlış bir durum yok, bu çıktıyı almamızın nedeni sed editörünün çalışma yapısı olan; her bir satırı tek tek alıp işlemesiyle ilgili. Yani bizim dosya içeriğimiz; sed editöründe bir bütün olarak algılanmadan, satır satır işleniyor. Bu sebepten aldığımız çıktıda; her satırdan yani her yeni veriden önce istediğimiz ifade basılmış oldu.

$ echo "Başka bir test" | sed 'a \ İlk test'

![https://likegeeks.com/wp-content/uploads/2017/02/21-sed-append.png](https://likegeeks.com/wp-content/uploads/2017/02/21-sed-append.png)

Aynı şekilde satır sonlarına yeni veri eklemek istersek de bu sefer a operatörünü kullanmamız yeterli oluyor.

Ayrıca daha önce de kullandığımız şekilde belirli satırları ya da satır aralıklarını kapsayacak şekilde bu ekleme işlemini yapabiliriz.

Örneğin yalnızca 3. satır öncesine ekleme yapmak için komutumuzu `sed '3i\\satır başı verisi' dosya` şeklinde girmemiz yeterli.

Ayrıca aşağıdaki örneklerde olduğu gibi pek çok farklı şekilde de kullanabiliriz.

4 . satır sonrasına ekleme işlemi için;
`sed '4a\\satır sonu verisi' dosya`
2 . satırdan sonraki tüm satırların sonuna ekleme işlemi için;
`sed '2,$a\\satır sonu verisi' dosya`

a 3. satırdan 6. satıra kadar olan verilerin sonuna ekleme işlemi için;
`sed '3,6a\\satır sonu verisi' dosya`

Bu örnekler düzenli ifadeler kullanılarak çoğaltılabilir ancak temelde bilmeniz gereken i operatörünün satır üstüne, a operatörünün ise satır altına ekleme işlevinde olduğudur.

## Satırları Değiştirme

Belirli bir satırı değiştirmek için, c operatörünü kullanabiliyoruz.
Örneğin 3. satırdaki veriyi istediğimiz ile değiştirmek için aşağıdaki komutu girmemiz yeterli.

$ sed '3c \ Bu değiştirilmiş bir satır.' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/24-sed-modify-line.png](https://likegeeks.com/wp-content/uploads/2017/02/24-sed-modify-line.png)

Genellikle s operatörü ile c operatörü benzer olduğu için karıştırılabiliyor. Ancak buradaki belirgin fark s operatörünün aranan hedef kelimeye göre, c operatörünün ise belirtilen satır numarasına göre hareket etmesidir.

Ancak düzenli ifadeler kullanarak, yine de c operatörünü de s operatörüne benzer şekilde kelime odaklı çalıştırabiliriz. Örneğin ben içerisinde "Şu" ifadesinin geçtiği satırları "burası güncellendi" ifadesi ile değiştirmek istersem komutumu aşağıdaki şekilde kullanabiliyorum.

$ sed '/ Şu / c Satır güncellendi.' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/25-sed-pattern-match-1.png](https://likegeeks.com/wp-content/uploads/2017/02/25-sed-pattern-match-1.png)

## Karakterleri Dönüştür

Otomatik olarak belirli verileri yenileri ile değiştirmek istersek y operatörünü kullanabiliyoruz.
Örneğin verilerin içerisinde geçen 1 2 3 numaralarını sırasıyla 5 6 7 ile değiştirmek istersem komutumu aşağıdaki şekilde kullanıyorum.

$ sed 'y / 123/567 /' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/26-sed-transform-character.png](https://likegeeks.com/wp-content/uploads/2017/02/26-sed-transform-character.png)

Gördüğünüz gibi tüm 1 rakamlarının yerlerini 5 rakamı aldı. Ve diğer rakamlar da sıraya uygun şekilde 2 rakamı 6 ile, 3 rakamı 7 ile olacak şekilde tek tek değiştirildi.

## Satır Numaralarını Yazdır

Eğer satır numaraları da çıktılarda basılsın istersek sed komutumuzla birlikte eşittir operatörünü kullanmamız yeterli oluyor.
Basit bir örnek olarak sed komutu ile okuduğumuz dosya içeriğindeki verilerin satır numaraları ile basılmasını istersek, komutumuzu aşağıdaki şekilde kullanabiliriz.

$ sed '=' dosyam

Bununla birlikte, daha önce de ele aldığımız -n parametresi ile eşittir işareti birleştirerek eşleşmeyi içeren satır numaralarını gösterecek şekilde bastırabiliriz.

$ sed - n '/ test / =' dosyam

![https://likegeeks.com/wp-content/uploads/2017/02/28-sed-hide-lines.png](https://likegeeks.com/wp-content/uploads/2017/02/28-sed-hide-lines.png)

## Dosyadan Veri Okumak

Bir dosyadan veri okumak için r operatörünü kullanabiliyoruz.

Örneğin test isimli dosyada yer alana verilerin test2 isimli dosyanın 2. satırından sonraki kısımda basılmasını istersek aşağıdaki komutu kullanabiliriz.

$ sed '2r test' test2

![https://likegeeks.com/wp-content/uploads/2017/02/29-sed-read-data-from-file.png](https://likegeeks.com/wp-content/uploads/2017/02/29-sed-read-data-from-file.png)

Çıktıda da gördüğünüz gibi test dosyasında yer alan tüm veriler test2 dosyasının 2. satırının ardından basılmış oldu.

## Faydalı Örnekler

Örneğin bir ifadenin bulunduğu kısımdaki veriyi silip onun yerine başka bir dosyadaki verileri aktarmak istersek aşağıdaki komutu kullanabiliriz.

İşi yapmak için (r) ve (d) bayraklarını kullanacağız.

Bu dosyadaki DATA sözcüğü, veri adı verilen başka bir dosyada depolanan gerçek bir içeriğin yer tutucusudur.

Gerçek içerikle değiştireceğiz:

```
sed  '/DATA>/ {

r newfile

d}'  myfile

```

![https://likegeeks.com/wp-content/uploads/2017/02/31-sed-repalce-placeholder.png](https://likegeeks.com/wp-content/uploads/2017/02/31-sed-repalce-placeholder.png)

Gördüğünüz gibi, yer tutucu yeri diğer dosyadaki verilerle dolu.

Bu kısımda sed komutunun temel işlevlerini örnekler üzerinden ele aldık. Sizler bu temel sayesinde ihtiyacınıza göre sınırsız çeşitlilikte işlem gerçekleştirebilirsiniz. Yani bu noktadan sonra sed komutunun işlev sınırları sizlerin elinde.
Bu yüzden lütfen burada yer alan örnekler haricinde de sizler kendi kendinize deneme yaparak çeşitli işlemleri gerçekleştirmeye çalışın.

Bir sonraki kısımda bir diğer güçlü araç olan awk aracından bahsediyor olacağız.

[sed](9-%20Sed%20bcf6c7da24aa4d1ea7502f848aa57fbb/sed%20a16405f218f74bb2b1eb2edb3335a9d6.md)