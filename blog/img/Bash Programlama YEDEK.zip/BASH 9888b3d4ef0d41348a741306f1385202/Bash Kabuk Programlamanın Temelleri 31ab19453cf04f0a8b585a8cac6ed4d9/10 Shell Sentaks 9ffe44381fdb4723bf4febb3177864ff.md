# 10. Shell Sentaks

[https://learning.oreilly.com/library/view/learning-the-bash/0596009658/ch07.html#bash3-CHP-7-SECT-3](https://learning.oreilly.com/library/view/learning-the-bash/0596009658/ch07.html#bash3-CHP-7-SECT-3)

[https://aosabook.org/en/bash.html](https://aosabook.org/en/bash.html)

[https://mywiki.wooledge.org/BashParser](https://mywiki.wooledge.org/BashParser)

[https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_03](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_03)

Bu bölüm eğitim son kısımlarında yer alıyor çünkü eğitim içerisinde bahsi geçen pek çok konuya atıfta bulunmamız gerekiyor. Buradaki amacımız kabuğun gözünden işleyişin nasıl olduğunu **genel hatlarıyla** öğrenebilmektir. Bu sayede ele aldığımız tüm kavramlar ve bu kavramların birbiri ile olan yakın ilişkisi bizler için netleşmiş olacak. Bizlerin kabuğa verdiği emirlerin hangi sıralama ile ele alındığını bilmemiz elbette doğru ve etkili kabuk kullanmamızı sağlayacaktır. 

# 10.1 Kabuğun Genel Çalışma Yapısı

Kabuk, kendisine verilmiş olan emirleri yani girdileri bir dizi işlemden geçirerek yorumlar. Bir dizi işlem olarak tabir ettiğimiz yorumlama süreci **en genel haliyle** ; **sözcük analizi**, **ayrıştırma** ve **çalıştırma** aşamalarından oluşur. Elbette tüm bu sürecin her aşamasında geçerli olan pek çok kural ve bu kuralların bağlam dahilinde uygulanma sıralaması vardır. Anlatımın devamında kabuk için daha anlaşılır emirler vermemize yardımcı olması için biz bu kurallardan **genel hatlarıyla** bahsediyor olacağız. 

Kabuğun bizim emirlerimizi nasıl ele aldığını biliyor olmamız, kabuğa doğru şekilde emir verebilmek için kritik derecede önemlidir. Yani bu bölüm altındaki açıklamalara da ehemmiyetle yaklaşmalıyız.

Buradaki açıklamalar, resmi dokümantasyon(gnu bash, posix shell) ve kaynak kodun analizinden yola çıkarak sadeleştirilmiş en temel işleyişi temsil ediyor. Kabuğun yapısı gereği elbette pek çok farklı duruma özel pek çok ekstra detay ve kompleks aşama bulunuyor. Eğer benim açıkladığım adımları sorgulamak ve daha detaylı araştırma yapmak isterseniz elbette sizler de kaynak kodları analiz edebilir ya da kabuk için posix standartları kılavuzuna göz atabilirsiniz. Bizler kabuğu etkili biçimde kullanabilmemize yetecek düzeyde ayrıntıya değiniyor olacağız.  

Tüm anlatılanların kolay anlaşılabilmesi için öncelikle temel kavramları kısaca ele almamız gerekiyor. 

Token: Kabuk tarafından tek bir birim olarak kabul edilen bir dizi karaktere verilen isimdir. Tokenler ya bir kelime ya da bir operatördür. Tokenlere belirteç gibi Türkçe karşılık da verilibilir ancak token olarak kalması kolay anlaşılması için daha iyi olacaktır.

Kelime: Kabuk tarafından bir birim olarak ele alınan bir dizi karakter. Kelimeler, tırnak veya kaçış karakteri olmadan meta karakterler içeremez.

Operatör: Bir kontrol operatörü veya bir yeniden yönlendirme operatörü. Yeniden yönlendirme işleçlerinin listesi için Yönlendirmeler konusuna bakın. Operatörler en az bir alıntılanmamış meta karakter içerir.

Metakarakter: Alıntı yapılmadığında kelimeleri ayıran bir karakter. Meta karakter bir boşluk, sekme, yeni satır veya şu karakterlerden biridir: "|", "&", ";", "(", ")", "<" veya ">".

Kontrol Operatörü: Kontrol işlevini sağlayan tokene verilen isimdir. Bunlar "yanı satır" ya da ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’,  ‘)’ metakarakterlerini içerir.

# 10.2 Emirin Alınması

Kabuk, emirleri; bir betik dosyasından, bash -c çağırma seçeneğine argüman olarak sağlanan bir dizeden veya doğrudan kullanıcının terminalinden alabilir. Emirler alındıktan sonra eğer history kaydı aktifse komut bütünü history listesine uygun şekilde eklenir ve sözcük analiz aşamasına aktarılır. 

Geçmiş genişletme, tam bir satır okunduktan hemen sonra, kabuk onu kelimelere ayırmadan önce gerçekleştirilir ve her satırda ayrı ayrı gerçekleştirilir. Bash, önceki satırlardan hala etkin olan alıntılar hakkında geçmiş genişletme işlevlerini bilgilendirmeye çalışır.

# 10.3 Sözcük Analizi

Kabuğa emir olarak verilen tüm karakterler **solda sağa doğru tek tek** denetlenir. Emir içerisinde yer alan metakarakterler(Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’) sayesinde tüm emir alıntılama kurallarına da dikkat edilerek "kelimelere" ve "operatörlere" bölünür. Bölme işleminin sonucunda oluşturulan karakter gruplarına "token" denir. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg)

Sözcük analizi yani token oluşturma aşaması en genel haliyle bu şekildedir. Genel açıklamanın ardından şimdi token oluşturma işlemine biraz daha yakından bakalım.

## 10.3.1 Token Üretimi

Kabuğa verilen emirdeki tüm karakterlerin gruplanarak tokenler haline geldiğini söyledik. Token oluşturma aşaması, kullanıcıdan gelen emirlerin doğru şekilde algılanabilmesi için son derece önemlidir. Örneğin Türkçe'den örnek verecek olursak "birtakım" kelimesi ile "bir takım" aynı anlamda mıdır ? Elbette hayır. "Birtakım" aslında "kimi, bazı" anlamındaki sıfatken, "bir takım" sözcüğü ise doğrudan "bir takım elbise" gibi bir adı ifade ediyor. Eğer karakterleri doğru bölümlerden ayrıştırmazsak gerçekte kastetmek istediğimiz anlamlar kaybolacaktır. Aynı durum kabuk ile kurduğumuz iletişimde de geçerlidir. 

Dolayısıyla kullanıcının verdiği emirin anlam kaybı yaşamaması adına kabukta geçerli olan kurallar dahilinde tüm karakterler denetlenip uygun şekilde token gruplarına ayrıştırılırlar. Token oluşturma aşamasında geçerli olan temel kurallardan ve işleyişten bahsederek devam edelim.

Önceki karakter bir operatörün parçası olarak kullanılabiliyorsa bu karakter bütünü tek bir operatör olarak tokenlenir. Örneğin ilk örnekte ortam özelliklerini bastırmamızı sağlayan `$-` operatörü, `$$-` şeklinde kullanılınca kabuk tarafından `$$` ve `-` şeklinde ayrıştırılmış oldu.

```jsx
 ~ → echo $-
himBCHs
 ~ → echo $$-
8-
```

Benzer şekilde önceki karakter operatörden hemen önce kullanılmışsa ancak operatörün bir parçası değilse ilk karakter ile operatör ayrı şekilde tokenlenir.

```jsx
 ~ → echo -$$
-8
```

Mevcut karakter, alıntı karakteri yani "ters taksim `\`", "tek tırnak `'` veya "çift tırnak `"` " içeriyorsa, alıntı karakterinin kapatıldığı karaktere kadar tüm karakterler tek bir token olarak değerlendirilir. Bu token içindeki karakterler alıntılama kurallarında açıkladığımız şekilde değerlendirilecektir. Örneğin tek tırnak içinde istediğiniz karakteri bastırabiliriz.

```jsx
~ → echo '/n\*-"$$'
/n\*-"$$
```

Daha net bir örnek olması açısında örneğin kabuğa `ls -la\ /home` emirini verirsek hata ile karşılaşırız. Verdiğimiz emirde argümanlar arasındaki boşluk karakterini ters taksim kaçış karakteri ile egale ettiğimiz için karakterler boşluk sayesinde ayrı tokenlere bölünememiş oluyor. Yani aslında  `ls` komutuna `-la /home` şeklinde tek bir argüman vermiş oluyoruz. `ls` aracı da argümanın başında yer alan `-` işareti dolayısıyla tüm argümanı seçenek olarak değerlendiriyor ancak `ls` aracının böyle bir seçeneği bulunmadığı için hata kaçınılmaz oluyor. 

```jsx
~ → ls -la\ /home
ls: invalid option -- ' '
Try 'ls --help' for more information.
```

Eğer tırnağı kapatmadan Ctrl + D tuşu ile veri girişini sonlandırırsak elbette kabuk sözdizimi(syntax) hatası verecektir. Tırnak işaretini yine tırnak işareti ile sonlandırılmadığımız için karakter girişinin sonu da doğru şekilde tespit edilemeyip tokenlere bölünemez.

```jsx
~ → echo '/n\*-"$$
>
-bash: unexpected EOF while looking for matching `''
-bash: syntax error: unexpected end of file
```

Mevcut karakter alıntılanmamış dolar işareti `$` ya da ters tırnak ``` ise; bu karakterin devamındaki karaktere göre "parametre genişletme", "komut ikamesi" ya da "aritmetik genişletme" için ayrıştırılırlar. 

Dolar işareti tek başına kullanıldıysa yani devamında standart karakterler geliyorsa bu karakter bütünü tek bir token olarak sınırlandırılır. Örneğin $HOME karakter bütünü tek bir token olarak ele alınır. Benzer şekilde diğer durumlar da aşağıdaki gibidir;

```jsx
~ → echo $HOME
/root
```

Dolar işaretinden sonra kıvırcık parantez karakteri geliyorsa "parametre genişletme" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo ${#HOME}
5
```

Dolar işaretinden sonra parantez karakteri geliyorsa "komut ikamesi" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo $(whoami)
root
```

Dolar işaretinden sonra çift parantez geliyorsa "aritmetik genişletme" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo $((3+5))
8
```

Tek tırnak kullanıldıysa "komut ikamesi" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo `whoami`
root
```

Hatta sınırlandırma işlemini teyit etmek üzere hepsini bir arada da kullanabiliriz. 

```jsx
echo $HOME${#HOME}$(whoami)$((3+5))`whoami`
/root5root8root
```

Elbette anlatımın başında değindiğimiz şekilde metakarakterler de karakter gruplarını ayrı ayrı tokenlenleştirilmesini sağlıyor. 

Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’

```jsx

ls | grep dosyaX
unzip *.zip &
echo ilk_komut ; echo ikinci_komut
(echo komut_1 ; echo komut_2)
ls -la > sonuc.txt
```

Yani örneğin "butekbirsatır" veri girişi tek bir token olarak sınırlandırılırken, "bu tek bir satır" girişi "bu" "tek" "bir" "satır" şeklinde ayrı ayrı tokenlenecektir. Özellikle alıntılanmadığı sürece aradaki boşluğun sayısı fark etmez. Çünkü kabuk boşlukların öncesindeki ve sonrasındaki karakteri birbirinden ayrıştırmak için bu işlemi uygular. 

```jsx
~ → echo Stephen R. Bourne
Stephen R. Bourne
~ → echo Stephen    R.    Bourne
Stephen R. Bourne
~ → echo "Stephen    R.    Bourne"
Stephen    R.    Bourne
```

Yeni satırlar da karakterin birbirinden ayrı tokenlere şeklinde sınırlandırılmasını sağlar.

```jsx
~ → echo "Stephen
> R.
> Bourne
> "
Stephen
R.
Bourne
```

Pipe işaretini komutlara bitişik şekilde kullandığımızda dahi işlevini kaybetmez. Çünkü kabuk token oluşturma sırasında pipe işaretine denk geldiğinde pipe işaretinden önceki ve sonraki karakterleri uygun şekilde tokenlere ayrıştırır.

```jsx
usr → ls
bin  games  include  lib  lib32  lib64  libexec  libx32  local  sbin  share  src
usr → ls|grep lib
lib
lib32
lib64
libexec
libx32
```

Pipe işaretini komutlara bitişik şekilde kullanmak daha okunaklı ve sorunsuz komutlar verebilmek adına kesinlikle önerilmez. Yine de benim bitişik kullanma amacım, token oluşturma aşamasında pipe işaretinin ne kadar ayırt edici olduğunu teyit edebilmekti. Benzer şekilde diğer metakarakterler üzerinden de aynı etki geçerlidir. 

```jsx
sleep 3&sleep 5
echo ilk_komut;echo ikinci_komut
(echo komut_1;echo komut_2)
ls -la > sonuc.txt
```

Komut gruplamada kullanmış olduğumuz parantezlerde boşluk olmasa dahi metakarakter olduğu için kabuk bunları rahatlıkla uygun şekilde tokenlere bölebiliyor. Ancak diğer bir komut gruplama seçeneği olan `{ komut listesi; }` yapısı kullanılırken süslü parantezler arasında boşluk karakteri bulunmak zorunda. Ayrıca komut listesinin sonunda noktalı virgül ya da yeni satır bulunması da şart. Çünkü süslü parantezler metakarakter değil "ayrılmış yani rezerve kelime"dir. Biz burada aslında kabukta bize kolaylık sağlayan bir aracı kullanmış oluyoruz. 

```jsx
{
> echo deneme
> echo sakın
> }
deneme
sakın
```

Dolayısıyla token oluşturma aşamsında bu karakterler sıradan karakter olarak görülürler. Bu karakterin gerçek değeri daha sonraki aşamalarda  ortaya çıkacaktır. Tokenleme aşamasında süslü parantezler herhangi bir karakter olduğu için daha sonraki aşamada doğru işlenebilmesi adına boşluk karakteri ile ayrıştırılması şarttır. AŞAĞIDAKİNİ KESİN OKU

[https://stackoverflow.com/questions/21246552/bash-command-groups-why-do-curly-braces-require-a-semicolon/21246590#21246590](https://stackoverflow.com/questions/21246552/bash-command-groups-why-do-curly-braces-require-a-semicolon/21246590#21246590)

Çünkü {ve}, yalnızca bir komuttaki ilk sözcüklerse özel sözdizimi olarak tanınır.

Kabuk tüm tokenleri birbirinden ayırdıktan sonra tüm komutların ayrı ayrı ele alınması mümkün olur. Süslü parantezler de yalnızca ilk komut olduğunda geçerli olduğu için onların ilk komu olarak ayarlanabilmesi için öncesine metakarakter kullanılmalı. Çünkü sözcük analizcisi komutları metakaraktere bakarak birbirinden ayırıyor.

Yorum yani `#` karakterinden sonraki tüm karakterler yorum olarak değerlendirildiği için tokenleme yapılmaz. Yorum `#`  karakterini sonlandıran şey yeni satıra geçiştir. Yeni satıra geçilmediği sürece yorum karakterinin devamındaki hiç bir karakter işlenmeyecektir.

```jsx
~ → echo ben satır #ben ise yorumum
ben satır
```

Ayrıca burada ortaya çıkan bir diğer husus tek bir satırda komutların arasına "yorum" ekleyebilir miyiz ?

Örneğin echo 1. 2. 3. komutunun arasında `echo 1. #ilk 2. #ikinci 3. #son` şeklinde yorum eklersek ilk yorum satırından sonra diğer komutlar okunmayacaktır. 

```jsx
~ → echo 1. #ilk 2. #ikinci 3. #son
1.
```

Bu durumu atlatmak için ters tırnak ile komut ikamesi içinde yorum belirtebiliriz.

```jsx
~ → echo 1. `#ilk` 2. `#ikinci` 3. #son
1. 2. 3.
```

Fakat ters tırnak değil de `$()` komut ikamesini kullanırsak istediğimiz sonucu elde edemeyiz. Çünkü `$(` ifadesinden sonra gelen yorum karakteri komut ikamesini kapan `)` işaretini de yorum olarak kapsıyor. Dolayısıyla yeni satıra geçip `)` işareti ile komut ikamesini kapatmadığımız için komut bütünü istendiği şekilde çalışmıyor.

[https://stackoverflow.com/questions/43815860/posix-shell-comments-in-command-substitutions](https://stackoverflow.com/questions/43815860/posix-shell-comments-in-command-substitutions)

Karakter girdisinden tokenler oluşturma aşaması bittiğinde dilbilgisi kurallarının gerektirdiği şekilde tokenlerin kategorize edilmesi gerekir.

Takma isim genişletme, tokenler sınırlandırıldıktan hemen sonra dilbilgisi denetimine geçmeden evvel gerçekleştirilir.

Güzel bir örnek takma isim atlatmak için l\s şeklinde bir kullanım olabilir. Takma isim genişletmesi token oluşturma aşamasından hemen sonra gerçekleştiği için l\s yapısındaki kaçış karakteri genişletilemez öylece kalır. Öylece kalınca da mevcut takma isim ile eşleşemez. İşte bu ve bunun gibi sebeplerle kabuğun komutarı nasıl ele aldığını bilmemiz önemli.

Command substitutions içerisindeki komutlar özel muamele görür. Yani tekrar shell synatxinden geçirilmez. Yalnızca IFS sayesinde kelime bölme uygulanır. Bu bir özelliktir, hata değildir: Komut ikamesi sonuçları sözdizimi olarak ayrıştırılırsa, güvenilmeyen verileri işleyen güvenli kabuk komut dosyaları yazmak temelde imkansız olurdu.

[https://stackoverflow.com/questions/59184358/why-isnt-a-semicolon-in-command-substitution-output-treated-identical-to-one-in](https://stackoverflow.com/questions/59184358/why-isnt-a-semicolon-in-command-substitution-output-treated-identical-to-one-in)

Ama örneğin aşağıdaki komut çalışıyor ?

pwd ; $(sleep 11; sleep 22 )

# 10.4 Ayrıştırıcı

Bir ayrıştırıcı, dilbilgisi-gramer ve sözdizimi-sentaks kuralı kontrolcüsü olarak düşünülebilir. Karakter girdilerinden tokenler oluşturulduktan sonra, sözdizimi hatalarını saptamak ve tokenlerin oluşturduğu emir bütününü doğru anlamlandırmak üzere ayrıştırma işlemi uygulanır. 

Neticede bu aşamada kabuğun elinde sıralı şekilde pek çok token vardır. Kabuk bu tokenlerin tek bir komut mu yoksa birden çok komut için mi kullanıldığını ya da hangisinin çalıştırılacak komut hangisinin argüman olduğunu anlamak ister. Türkçemizden örnek verecek olursam "Yavuz kedi eti yedi." cümlesi ile "Yavuz, kedi eti yedi." cümlesi aynı şeyi mi ifade ediyor ? Elbette hayır. Virgül sayesinde kelimeleri **doğru şekilde gruplayarak** doğru bağlamda değerlendirebiliyoruz.

Aynı durum kabuk ile kurduğumuz iletişim için de geçerli. Kabuğun bizi doğru anlayabilmesi için tokenleri doğru şekilde gruplayarak basit ve bileşik komutlar haline getirmesi gerekir. Bunun için de öncelikle elde bulunan sıralı tokenlerin uygun bölümlerden ayrıştırılması gerekir.

## 10.4.1 Tokenlerin Basit ve Bileşik Komutlara Ayrılması

Tokenlerin uygun şekilde ayrıştırılmasını da bizim örneğimizde kullandığımız virgüle benzer şekilde tokenler içerisindeki "kontrol operatörleri" mümkün kılar. Ayrıştırıcı, baştan sonra tüm tokenleri "kontrol operatörü" mü diye kontrol eder. Kontrol operatörüne denk geldiği anda, operatörden önceki tokenleri, komutun devamındaki tokenlerden ayırır. Böylelikle eldeki tüm tokenler uygun şekilde birbirinden ayrılarak gruplanmış olur.

Ayrıca komut içerisinde kullanılan kontrol operatörleri yalnızca tokenlerin gruplanmasını sağlamakla kalmaz, aynı zamanda token gruplarının yani komutların ne şekilde çalıştırılması gerektiğini de belirtir. Örneğin `&` kontrol operatörü ile ayrılmış token grubu aslında arkaplanda çalıştırılacak şekilde işaretlenmiştir. İleride ayrıca ele alacağımız en son aşama olan çalıştırma aşamasında, bu kontrol operatörleri ile belirtilen çalıştırılma yöntemine riayet edilecektir.

Ayrıştırma işleminin ardından tokenlerin sözdizimsel kontrolü yapılır. Bu kontrol, komutun basit veya bileşik olmasın göre değerlendirilir. Daha net anlaşılması için kısaca basit ve bileşik komutları da açıklayalım.

Basit komutlar: Basit komutlar boşluk karakteriyle birbirinden ayrılmış ve bir kontrol operatörü tarafından sonlandırılan bir dizi kelimeyi temsil eder. Genellikle ilk kelime çalıştırılacak komutu belirtirken, geri kalan kelimler çalıştırılan komuta verilen argümanlardır. 

Bileşik Komutlar: Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sonlandırılır. Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve çeşitli mekanizmalar sağlar.

İşte bu aşamada kabuk, token grubunun basit mi bileşik mi olduğunu grup içindeki tokenlere bakarak anlayabilir. Örneğin token grubu `if` tokeni ile başlıyorsa bu token grubu bileşik komut olarak görülür ve bileşik komutun tamamlanması için `fi` tokeni ile bitirilip bitirilmediği kontrol edilir. Eğer bitirilmediyse syntax yani sözdizimi hatası döndürülür. Eğer bitirildiyse token grubu denetimden geçer ve bir sonraki token grubu denetlenir. Bu işlem tüm tokenler sorgulanana kadar devam eder.

Neticede ayrıştırma aşamasında tokenler basit ve bileşik komutlara ayrılıp, basit veya bileşik olma durumları dahilinde sözdizimi kuralları da kontrol edilmiş olur.

### Basit Komutlar

Basit komutlar boşluk karakteriyle birbirinden ayrılmış ve bir kontrol operatörü tarafından sonlandırılan bir dizi kelimeyi temsil eder. Genellikle ilk kelime çalıştırılacak komutu belirtirken, geri kalan kelimler çalıştırılan komuta verilen argümanlardır. 

### Karmaşık Komutlar

Basit komutların çeşitli yollarla bir araya getirilmesi sonucu karmaşık komut yapıları üretebiliriz. Karmaşık komut oluşturmada aşağıdaki yapılar etkilidir.

- Rezerve Kelimeler
- Pipe hattı
- Listelenmiş Komutlar
- Bileşik Komutlar
- Yardımcı İşlemler
- GNU Parallel gibi araçlar.

Zaten kabuğun ayrıştırıcı mekanizması da bu yapılara göz atarak girilen komut bütününü basit ve bileşik şekilde ayrıştırabilir.

Komutun içindeki operatörler "kontrol operatörü" mü diye bakılır. Öyleyse operatöre kadar olan komut, diğer komut bütününden ayrıştırılır. Bu şekilde tüm komutlar birbirinden ayrıştırılımış olur. Daha sonra ayrıştırılmış olan komutlar en baştan hangi türde diye kontrol edilir. Örneğin rezerve bir kelime ise bu rezerve kelimenin bitişi var mı diye bakılır. Eğer yoksa bu komut syntax hatası verecektir. Bu gibi kurallara kontrol edildikten sonra eğer sorun yoksa bir sonraki aşama olan genişletme aşamasına geçilir.

Kısaca bileşik komutları mümkün kılan yapıları açıklamamız gerekirse;

**Rezerve kelimeler;** Ayrılmış sözcükler, kabuk için özel anlamı olan sözcüklerdir. Kabuğun bileşik komutlarını başlatmak ve bitirmek için kullanılırlar. Aşağıdaki sözcükler, alıntı yapılmadığında ve bir komutun ilk sözcüğü olduğunda rezerve olarak kabul edilir (istisnalar için aşağıya bakın):

```jsx
if	then	elif	else	fi	time
for	in	until	while	do	done
case	esac	coproc	select	function
{	}	[[	]]	!
```

in, bir case veya select komutunun üçüncü sözcüğüyse, rezerve bir sözcük olarak tanınır.

in ve do, for komutundaki üçüncü kelimeyse, rezerve kelimeler olarak kabul edilir.

Pipeline; Birkaç basit komutun çıktısını ve girdisini birbirine aktarmayı sağlayan yapıdır. Bu yapı ile birden fazla basit komut kullanılarak bileşik komut oluşturulmuş olur.

Liste; Basit komutların sıralı şekilde koşullara bağlı olarak yürütülmesini sağlar. && ve || operatörleridir.

Bileşik Komutlar: Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sonlandırılır. Bir bileşik komutla ilişkili tüm yeniden yönlendirmeler (bkz. Yeniden Yönlendirmeler), açıkça geçersiz kılınmadıkça, bu bileşik komut içindeki tüm komutlar için geçerlidir. Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve mekanizmalar sağlar.

Komutların doğru şekilde çalıştırılabilmesi için ayrıştırıcı bu aşamada basit ve bileşik komutları ayrıştırır. Örneğin bileşik komut rezerve bir kelime ile başladıysa ancak rezerve bir kelime ile bitmediyse kabuk syntax hatası verecektir. Zaten basit komutlar da kontrol operatörleri sayesinde birbirinden ayrıştırılır. İleriki aşama olan çalıştırma aşamasında bu kontrol operatörleri dikkate alınarak basit komut yapıları uygun şekilde çalıştırılacaktır.

# 10.5 Kelime Genişletme:

Kabuk özellikleri dahilinde gerçek değerine genişletilebilecek karakter gruplarının genişletildiği aşamadır. Ayrıştırma işleminden sonra sırasıyla genişletme adımları uygulanır. 

1. Tilde genişletmesi, parametre genişletmesi, komut ikamesi ve aritmetik genişletme gerçekleştirilir. Tüm genişletmeler aynı önceliğe sahiptir. Komutun solundan sağına doğru sırasıyla tüm genişletmeler uygulanır. Kabuk, genişletmenin türünü token oluşturma başlığı altında ele aldığımız şekilde '`$`', "`${`", "`$(`", '```', "`$((`" karakteri sayesinde bilir. Zaten bu karakterler sayesinde daha önce kelimeler tokenlere bölünmüştü, genişletme aşamasında da türüne göre tokenlerin genişletilmesini sağlıyorlar. 
2. IFS değeri boş değilse 1. aşamada genişletilmiş olan değerleri bölünür.
    
    **Kelime Bölme İşlemi**
    
    [https://mywiki.wooledge.org/WordSplitting](https://mywiki.wooledge.org/WordSplitting)
    
    Bu işlem genişletilmiş kelimler üzerinde uygulanır. Yani genişletme yoksa bu kelime bölme işlevi de elbette uygulanmaz. 
    
    Kabuk, sözcük bölme için çift tırnak içinde meydana gelmeyen parametre genişletme, komut ikamesi ve aritmetik genişletme sonuçlarını tarar. Ve IFS değişkeninin değerine(IFS bölme işlemi için varsayılan olarak boşluk karakterine sahiptir) göre genişletilmiş olan karakterleri kelimelere böler. Genişletilmiş karakterler kelimelere bölündükten sonra dosya genişletme aşamasına geçilir.
    
    Genişletmelerin arından ortaya çıkan karakterler de ilk adımda olduğu gibi tekrar kelime tokenlerine bölünür. Buradaki bölümleme işleminde ilk adımın aksine metakarakterler değil IFS değişkeninin sahip olduğu ayrıştırıcı değer kullanılır. Bu değer özellikle değiştirilmediği sürece boşluk karakteridir. Çünkü genişletmeler yalnızca argüman olarak kullanılmak için yapılır. 
    
3. set -f olmadığı sürece pathname genişletmesi uygulanır.
    
    **Dosya Adı Genişletmesi Globbing**
    
4. En son alıntı karakteri kaldırılır. 

Bu bölümde açıklanan genişletmeler, komutun yürütüldüğü kabuk ortamında gerçekleşecektir. Bir sözcük için uygun olan tam genişletme boş bir alanla sonuçlanırsa, orijinal sözcük tek tırnaklı veya çift tırnaklı karakterler içermedikçe, bu boş alan tamamen genişletilmiş komutu oluşturan alanlar listesinden silinecektir.

Dosya adı genişletmesi de uygulandıktan sonra artık çalıştırılacak komutlar, çalıştırılan komutlara verilecek olan argümanlar tam olarak hazıdır. Bu yapı bir sonraki aşama olan yönlendirme aşamasına devredilir.

# 10.6 Yönlendirmelerin Gerçekleştirilmesi

Yönlendirme operatörleri dikkate alınarak, ilgili yönlendirmeler bu aşamada ayarlanır. Yönlendirmeler de ayarlandıktan sonra nihayet emirin çalıştırılabilmesi için bir sonraki aşamaya geçilebilir.

# 10.7 Çalıştırma Aşaması

Kullanıcının en başta girmiş olduğu emirin kabuk tarafından yorumlanmış en son hali soldan sağa doğru olacak şekilde sırasıyla çalıştırılır. Çalıştırma aşamasında ilk kelime her zaman çalıştırılacak komutu belirtir. Geri kalanlar komutun argümanlarıdır. Zaten ayrıştırma aşamasında basit komutların ne şekilde çalıştırılması gerektii de beliritği için çalıştırma aşaması tüm basit ve bileşik komutları uygun şekilde çalıştırılmasını sağlar.

Kabuk bir komutu çalıştırmak istediğinde öncelikle çalıştırılacak olan komutun bulunması gerekir. Bulma adımları aşağıdaki gibidir.

- Çalıştırılacak olan komut aranır ve argümanlarıyla birlikte uygun şekilde çalıştırılır.
    - Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
    - Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
    - Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
    - İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
    - Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
    - Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
    - İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
    - Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).
- Komutun çalışması bittikten sonra çıkış durumunu döndürür. Ve böylelikle verilen emir kabuk tarafından uygun şekilde yerine getiriliş olur.

Güzel bir örnek takma isim atlatmak için l\s şeklinde bir kullanım olabilir. Takma isim genişletmesi token oluşturma aşamasından hemen sonra gerçekleştiği için l\s yapısındaki kaçış karakteri genişletilemez öylece kalır. Öylece kalınca da mevcut takma isim ile eşleşemez. İşte bu ve bunun gibi sebeplerle kabuğun komutarı nasıl ele aldığını bilmemiz önemli.

# 10.8 Neden Bu İşleyiş Nedir Bu Karmaşa ?

Anlatım sırasında emirlerin kabuk tarafından doğru anlaşılabilmesi için pek çok kural ve kullanılan farklı türde yapı olduğuna değindik. Neden daha sade bir yapılanma olmadığı veya bu yaklaşımların neden tercih edildiği konusunda daha fazla detayı merak ediyorsanız hepsinin ortak cevabı; "geriye dönük uyumluluk" olacaktır. Daha önce de bahsettiğimiz şekilde kabuk bir özellik sunduğunda eski özellikleri çalışmayı etkileyecek şekilde değiştiremez. Yeni sunulan bir özellik de ileriki sürümlerde aynı şekilde kalıcı olmalıdır. Kabuğun gelişimi de uzun yıllara yayıldığı için, zaman içinde oluşan yeni ihtiyaçlara eskisini bozmadan cevap verilebilmesi adına sürekli eklemeler yapılmıştır. Bu durum da kaçınılmaz olarak kabuğun çalışma yapısında çeşitliliğe neden olmuştur. Anlatım sırasında hangi yapının neden kullanıldığı ve doğru kullanılmazsa nasıl sonuçlanacağına kısaca değindik. Yine de eğer ayırdığınız vakte değeceğini düşünüyorsanız, tarihsel olarak hangi yapının ne zaman ve neden tercih edildiğini araştırmakta özgürsünüz. 

KÖTÜYE KULLANIM HAKKINDA BİLGİ VERİLEBİLİR

[Bash Güvenlik Zaafiyetleri](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Bash%20Gu%CC%88venlik%20Zaafiyetleri%2009e4cceb582d4847a0ce76dbefd0826d.md)

DOSYA ADI GENİŞLETME KAVARMINA GÖZ AT [https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html](https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled.png)

- Komut metakarkterler sayesinde tokenlere bölünür.
- Tırnak işareti veya ters eğik çizgi içermeyen bir anahtar kelime olup olmadığını görmek için her komutun ilk belirtecini kontrol eder. If ve diğer kontrol yapısı açıcıları, function, {veya (() gibi bir açılış anahtar sözcüğüyse, komut aslında bir bileşik komuttur. Kabuk ortamını buna göre ayarlar. Anahtar kelime bileşik bir komut açıcı değilse (ör., o zamanki gibi bir kontrol yapısı "orta" ise, else veya do, fi veya done gibi bir "son" veya mantıksal bir işleçse), kabuk sözdizimi hatası verir.
- Her komutun ilk kelimesi takma isim listesinde kontrol edilir. Eğer eşleşme varsa takma adı gerçek değerine genişletir ve ilk adıma yani tokenlere bölme aşamasına dönülür. Eğer takma isimle eşleşme olmazsa bir sonraki adıma geçilir.
- Komut içeriyorsa, küme ayracı genişletmesi uygulanır.
- Komut içeriyorsa, tilde genişletmesi uygulanır.
- Komut içeriyorsa, değişken genişletmesi uygulanır.
- Komut içeriyorsa, komut ikamesi genişletmesi uygulanır.
- Komut içeriyorsa, aritmetik genişletmesi uygulanır.
- Genişletmelerin arından ortaya çıkan karakterleri de ilk adımda olduğu gibi tekrar kelime tokenlerine bölünür. Buradaki bölümleme işleminde ilk adımın aksine metakarakterler değil IFS değişkeninin sahip olduğu ayrıştırıcı değer kullanılır. Bu değer özellikle değiştirilmediği sürece boşluk karakteridir.
- Komut içeriyorsa, pathname expension yani joker karakter genişletmesi uygulanır.
- Gerekli yönlendirmeler gerçekleştirilir.
- Çalıştırılacak olan komut aranır ve argümanlarıyla birlikte uygun şekilde çalıştırılır.
    - Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
    - Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
    - Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
    - İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
    - Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
    - Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
    - İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
    - Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).
- Komutun çalışması bittikten sonra çıkış durumunu döndürür. Ve böylelikle verilen emir kabuk tarafından uygun şekilde yerine getiriliş olur.

Güzel bir örnek takma isim atlatmak için l\s şeklinde bir kullanım olabilir. Takma isim genişletmesi token oluşturma aşamasından hemen sonra gerçekleştiği için l\s yapısındaki kaçış karakteri genişletilemez öylece kalır. Öylece kalınca da mevcut takma isim ile eşleşemez. İşte bu ve bunun gibi sebeplerle kabuğun komutarı nasıl ele aldığını bilmemiz önemli.

Tüm anlatıların kolay anlaşılabilmesi için öncelikle temel kavramları kısaca ele almamız gerekiyor.

Token: Kabuk tarafından tek bir birim olarak kabul edilen bir dizi karaktere verilen isimdir. Tokenler ya bir kelime ya da bir operatördür. Tokenlere belirteç gibi Türkçe karşılık da verilibilir ancak token olarak kalması kolay anlaşılması için daha iyi olacaktır.

Kelime: Kabuk tarafından bir birim olarak ele alınan bir dizi karakter. Kelimeler, tırnaksız meta karakterler içeremez.

Operatör: Bir kontrol operatörü veya bir yeniden yönlendirme operatörü. Yeniden yönlendirme işleçlerinin listesi için Yönlendirmeler konusuna bakın. Operatörler en az bir alıntılanmamış meta karakter içerir.

Metakarakter: Alıntı yapılmadığında kelimeleri ayıran bir karakter. Meta karakter bir boşluk, sekme, yeni satır veya şu karakterlerden biridir: "|", "&", ";", "(", ")", "<" veya ">".

Kontrol Operatörü: Kontrol işlevini sağlayan tokene verilen isimdir. Bunlar "yanı satır" ya da ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’,  ‘)’ metakarakterlerini içerir.

SÖZCÜK ANALİZİ AŞAMASINDA KELİMLERİN TÜRLERİ İLE TOKEN OLUŞTURULDUĞUDAN EMİN OL DOKÜMANDA BU AŞAMA AYRIŞTIRMA KISMINDA GERÇEKLEŞİYOR GİBİ.

[http://www.belgeler.org/bashref/bashref_shell.operation.html](http://www.belgeler.org/bashref/bashref_shell.operation.html)

[https://www.geeksforgeeks.org/developing-linux-based-shell/](https://www.geeksforgeeks.org/developing-linux-based-shell/)

Bu bölüm eğitim son kısımlarında yer alıyor çünkü eğitim içerisinde bahsi geçen pek çok konuya atıfta bulunmamız gerekiyor. Buradaki amacımız kabuğun gözünden işleyişin nasıl olduğunu **genel hatlarıyla** öğrenebilmektir. Bu sayede ele aldığımız tüm kavramlar ve bu kavramların birbiri ile olan yakın ilişkisi bizler için netleşmiş olacak. Bizlerin kabuğa verdiği emirlerin hangi sıralama ile ele alındığını bilmemiz elbette doğru ve etkili kabuk kullanmamızı sağlayacaktır. 

# 10.1 Kabuğun Genel Çalışma Yapısı

Kabuk, kendisine verilmiş olan emirleri yani girdileri bir dizi işlemden geçirerek yorumlar. Bir dizi işlem olarak tabir ettiğimiz yorumlama süreci **en genel haliyle** ; **sözcük analizi**, **ayrıştırma** ve **çalıştırma** aşamalarından oluşur. Elbette tüm bu sürecin her aşamasında geçerli olan pek çok kural ve bu kuralların bağlam dahilinde uygulanma sıralaması vardır. Anlatımın devamında kabuk için daha anlaşılır emirler vermemize yardımcı olması için biz bu kurallardan **genel hatlarıyla** bahsediyor olacağız. 

İşlem adımlarını rahat takip edebilmek adına aşağıdaki komut üzerinden açıklama yapıyor olacağız. 

`find /etc -name "bulbeni*" | sort > sonuc.txt`

buradaki yıldız işareti kabuk tarafından değil find komutu tarafından genişletiliyor. Kabuk "bulbeni*" ifadesini argüman olarak veriyor. Fİnd komutumu da bu argümanı kendi kuralları dahilinde işleyip yıldız işaretini genişletiyor. Tırnak işareti olmadan kullanılığında kabuk bu eşleşmeye uyan tüm dosyaları doğrudan find komutuna argüman olarak iletmiş oluyor. Bu kısım biraz kafa karıştırabilir bu sebeple bu örneğini değilştirmeyi düşün. Bu açıklama genişletmeleri açıklarken faydalı olabilir. Find haricinde kendisi genişletme yapmayan komutlar üzerinden bu durumu kanıtlayabilirsin.

[https://unix.stackexchange.com/questions/345304/in-what-way-does-quoting-parameters-to-find-matter?noredirect=1&lq=1](https://unix.stackexchange.com/questions/345304/in-what-way-does-quoting-parameters-to-find-matter?noredirect=1&lq=1)

`find` komutu ile ***/etc*** dizini altında yer alan ve içerisinde "bulbeni" karakterlerinin geçtiği tüm dosya dizinler bulunup `sort` komutu ile sıralanmasını sağlanacak ve en nihayetin çıktılar sonuc.txt dosyasına yönlendirilecektir.

Elbette bu komut bütünü, kabuğun maruz kalacağı olası tüm emirleri yansıtmıyor olsa da genel hatlarıyla kabuğun yorumlama ve çalıştırma serüveni hakkında bilgi sahibi olmamıza yetecektir. 

Bash kabuğuna verdiğimiz emirlerin okunup yorumlanması sırasında gerçekleşen işlem adımları kısaca aşağıdaki şekildedir.

### 10.1.1 Emirin Alınması

Kabuk emirleri; bir betik dosyasından, bash -c çağırma seçeneğine argüman olarak sağlanan bir dizeden (Bash programının özelliklerini açıkladığımız bölüme göz atın) veya kullanıcının terminalinden okur. Kısacası kabuğa işlemesi üzere emir verilir. Emir alındıktan sonra eğer history kayıt tutma aktifse komut history kaydına uygun şekilde eklenir.

### 10.1.2 Sözcük Analizi: Token Üretimi

Kabuğa verilen emirdeki tüm karakterler alıntı kurallarına da dikkat edilerek aralarındaki metakarakterlerden(Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’), "token" olarak ifade edilen özel karakter gruplarına bölünürler. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg)

Sözcük analizcisi tarafından gruplanan karakterler, bulundukları bağlam dahilinde kendi türlerine göre sınıflandırılırlar. Sınıflandırma sonucunda token dediğimiz karakter grupları elde edilmiş olur.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer_step2.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer_step2.svg)

Girilen karakterlerden token oluşturma işlemi sırasında; eğer girilen karakter ile eşleşen bir takma isim tanımlandıysa, ilgili karakter grubu "takma isim" tokeni olarak işaretlenir. Bu sayede takma isimlerle aynı adlandırmaya sahip komut ya da fonksiyonlardan önce takma isimlerin çalıştırılması mümkün olur.

Bu sözcüksel analiz aşamasında elbette kabuğun sahip olduğu özellikler dahilinde şablonlara uyan birtakım eşleşmeler aranarak tokenler oluşturulur. Örneğin `-` işareti **seçeneklerin** ayrıt edilebilmesini sağlarken, `/` işaretiyle birlikte `/dosya_adı` şeklinde bir girdi kullanıldıysa, sözcük analizi tarafından **çalıştırılacak dosya adı** ayırt edilip buna göre tokeni oluşturulur. ****Kısacası bash kabuğunun özellikleri dahilinde belirlenmiş olan tanım kalıplarına göre; kabuğa verilen tüm karakterler doğru biçimde türlerine göre gruplanmaya çalışılır. 

### 10.1.3 Ayrıştırıcı: Tokenlerin Basit ve Bileşik Komutlara Ayrılması

Bir ayrıştırıcı, dilbilgisi-gramer ve sözdizimi-sentaks kuralı kontrolcüsü olarak düşünülebilir. Karakter girdilerinden tokenler oluşturulduktan sonra, sözdizimi hatalarını saptamak ve tokenlerin oluşturduğu emir bütününü doğru anlamlandırmak üzere ayrıştırma işlemi uygulanır.

Bu işlem için öncelikle tüm komutu basit ve bileşik komut şeklinde ayrıştırır. Ayrıştırma işlemi için operatörlere bakar. Kontrol operatörlerine göre tüm komutu ayrıştırır.

Yani tokenler halinde sunulan "kelime" "seçenek" ve "argüman" gibi kabuk yapılarının uygun sıralama ile verilip verilmediğini kabuğun sözdizimi kuralları dahilinde kontrol eder. Ayrıştırma aşamasında komutlar "basit" ve "bileşik" komutlara ayrılır. Burada yapılan ayrıştırmaya biraz daha yakından bakacak olursak;

## Basit Komutlar

Basit komutlar; tek bir bağlamda çalışması gereken, genellikle ilk kelimeyle çalıştırılacak komutu belirten ve devamında komutun seçenekleri, argümanları, girdi-çıktı yönlendirmesi bulunan komut bütününün en genel tanımıdır.

Kabuğun gözünden basit komutlar metakarakter ile birbirinden ayrılmış, kabuğun kontrol operatörlerinden biri tarafından sonlandırılan bir sözcük dizisidir. 

Burada bahsi geçen kontrol operatörleri basit komutun sınırını belirtir. Örneğin konsola bir komut girip enter ile yeni satıra geçtiğimizde, basit komutu "yeni satır" ile ayırdığımızı kabuğa bildirmiş oluyoruz. Benzer şekilde örneğin birden fazla basit komutu peşi sıra noktalı virgül ile ayırdığımızda da "kontrol operatörlerini" kullanmış oluyoruz. 

Kontrol operatörleri sayesinde, kabuğa iletilmiş olan kelimelerin kabuk tarafından doğru şekilde anlamlandırılması sağlanabiliyor. Örneğin kontrol operatörü olmadan yani yeni satıra geçmeden ya da herhangi bir metakarakter kullanmadan komutları peşi sıra yazarsak ne olur ? 

Peşi sıra iki tane `echo` komutu kullanarak bu durumu gözlemleyelim.

```bash
~ → echo "ben ilkim" echo "ben ikinciyim"
ben ilkim echo ben ikinciyim
```

Çıktıları incelediğinizde kabuğun ikinci `echo` komutunu çalıştıramadığını görebilirsiniz. Bu durumun nedeni kabuğun ikinci komutu ayırt etmesini sağlayacak olan kontrol operatörünün ilk komutun ardından kullanılmamış olmasıdır. Noktalı virgül kontrol operatörünü kullanarak bu durumu teyit edebiliriz.

```bash
~ → echo "ben ilkim" ; echo "ben ikinciyim"
ben ilkim
ben ikinciyim
```

Ayrıca kontrol operatörleri yalnızca komutların birbirinden ayırt edilmesini de sağlamaz. Kontrol operatörleri komutların hangi koşullara göre değerlendirileceğini de belirtir. Bu sebeple yeni satır veya noktalı virgül haricinde pek çok kontrol operatörü vardır.(Sözlükte yer alan "kontrol operatörleri" açıklamasına göz atın.) Örneğin ampersant `&` işareti bir kendisinden önceki komutun arkaplanda çalıştırılması gerektiğini kabuğa bildiren kontrol operatörüdür. Zaten kitap boyunca yeri geldikçe diğer kontrol operatörlerini de konu dahilinde ele aldık. Örneğin mantıksal operatörler de bu sınıfta sayılıyor. Bu işleyiş sayesinde kabuk kendisine verilen basit komutları doğru şekilde anlamlandırabiliyor. Bizim ele aldığımız örnekte kullandığımız pipe da aslında basit komutun bittiğini belirten özel kontrol operatörüdür. Basit komutu bitirip pipe işaretinden sonraki komuta ilk komutun çıktılarını ulaştırmak gibi özel bir amaca hizmet eder.

Kontrol karakterlerini tıpkı bizlerin kullandığı noktalama işaretleri gibi düşünebilirsiniz. Noktalama işaretleri olmadan yazılan ifadeler karşı tarafa doğru şekilde aktarılamaz. En basitinden bir virgül tüm cümlenin anlamını değiştirmeye muktedir değil mi ?

## Bileşik Komutlar

Bileşik komutlar ise, birden fazla basit komutun uygun şekilde sıralanarak kullanılması olarak tanımlayabiliriz. Pipe kullanımı bu duruma en açık örnektir. Nitekim bizim ele aldığımız bulma sıralama örneğinde bizde iki basit komutu pipe ile sıralı şekilde kullanmış olduk.

Daha karmaşık kabuk komutları, çeşitli şekillerde birlikte düzenlenmiş basit komutlardan oluşur: bir komutun çıktısının bir saniyenin girdisi haline geldiği bir boru hattında, bir döngüde veya koşullu yapıda veya başka bir gruplama da aslında bileşik komut kapsamındadır. Birden fazla komutun özel durumlar için sıralı şekilde arada bulunması bileşik komut dediğimiz yapıyı temsil eder. Her ne kadar bizim örneğimizde pipe kullanılmış olsa da çeşitli rezerve kelimeler ve kontrol operatörleri sayesinde çok çeşitli bileşik komut oluşturulması mümkündür.

Bileşik komutların doğru şekilde çalıştırılabilmesi için öncelikle uygun bölümlerinden özellikleri dahilinde ayrıştırılması gerekiyor.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step1.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step1.svg)

Komutlar uygun şekilde ayrıştırıldıktan sonra;

- Genişletme sırasına uygun olarak kabuk genişletmeleri uygulanır.
- Gerekli yeniden yönlendirmeler gerçekleştirilir.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step2.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step2.svg)

Ve en nihayetinde tam olarak hangi şekilde çalıştırılacağı belirlenmiş olan bileşik komut bir sonraki aşama olan "çalıştırma" aşamasına aktarılabilir. Biz işlemleri kolay takip edebilmek adına son derece basit bir komut yapısını ele aldık. Zaten anlatımın başında ele aldığımız örneğin tüm sözcüksel analiz ve ayrıştırma aşamalarını kapsamadığını da belirtmiştik. 

Ayrıştırıcı mekanizması bir sonraki adımda komutların doğru şekilde çalıştırılması için bu ayrıştırmayı yapmak zorundadır. Uygun noktalarda ayrıştırma yapmazsa bir sonraki adım olan "çalıştırma" işlemi kullanıcının gerçekte kastettiği işlemi yerine getiremez. Ayrıştırma işlemini cümlenin anlamsal bütünlüğünü kontrol eden ve gereken kısımlara virgül koyan yapı olarak düşünebilirsiniz. Neticede ayrıştırıcı dediğimiz yapı; elindeki tokenlerden çalıştıracak komutların anlamlı bir tablosu oluşturulur. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%201.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%201.png)

- Komutu yürütür (bkz. Komutları Yürütme).

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%202.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%202.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%203.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%203.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png)

Kabuğa verilen emirin yürütülme süreci genel adımları aşağıdaki gibidir.

- Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
- Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
- Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
- İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
- Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
- Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
- İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
- Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).

Dolayısıyla buradaki anlatımlardan kabuğa verilmiş olan aynı isimli yapıların çalıştırılma sırası aşağıdaki gibidir.

alias > fonksiyon > builtin > external

## Neden Bu İşleyiş Nedir Bu Karmaşa ?

Anlatım sırasında emirlerin kabuk tarafından doğru anlaşılabilmesi için pek çok kural ve kullanılan farklı türde yapı olduğuna değindik. Neden daha sade bir yapılanma olmadığı veya bu yaklaşımların neden tercih edildiği konusunda daha fazla detayı merak ediyorsanız hepsinin ortak cevabı; "geriye dönük uyumluluk" olacaktır. Daha önce de bahsettiğimiz şekilde kabuk bir özellik sunduğunda eski özellikleri çalışmayı etkileyecek şekilde değiştiremez. Yeni sunulan bir özellik de ileriki sürümlerde aynı şekilde kalıcı olmalıdır. Kabuğun gelişimi de uzun yıllara yayıldığı için, zaman içinde oluşan yeni ihtiyaçlara eskisini bozmadan cevap verilebilmesi adına sürekli eklemeler yapılmıştır. Bu durumda da kaçınılmaz olarak kabuğun çalışma yapısında çeşitliliğe neden olmuştur. Anlatım sırasında hangi yapının neden kullanıldığı ve doğru kullanılmazsa nasıl sonuçlanacağına kısaca değindik. Yine de eğer ayırdığınız vakte değeceğini düşünüyorsanız, tarihsel olarak hangi yapının ne zaman ve neden tercih edildiğini araştırmakta özgürsünüz.