# Hedef odaklı veri dönüştürme işlevindedir.

Operatör: August 31, 2020