# Çıktıların istenen dosyaya yazılmasını sağlar. write ifadesinin kısaltmasıdır.

Operatör: September 2, 2020