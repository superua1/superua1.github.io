# Hedef satır altına veri ekleme işlevindedir.

Operatör: September 1, 2020 9:00 AM