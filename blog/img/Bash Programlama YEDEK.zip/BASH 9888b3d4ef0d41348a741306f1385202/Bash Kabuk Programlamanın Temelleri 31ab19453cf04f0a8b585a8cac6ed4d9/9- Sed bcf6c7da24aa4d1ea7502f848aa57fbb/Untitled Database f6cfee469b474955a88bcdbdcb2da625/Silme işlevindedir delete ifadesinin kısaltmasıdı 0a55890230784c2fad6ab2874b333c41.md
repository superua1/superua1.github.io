# Silme işlevindedir. delete ifadesinin kısaltmasıdır.

Operatör: December 1, 2020