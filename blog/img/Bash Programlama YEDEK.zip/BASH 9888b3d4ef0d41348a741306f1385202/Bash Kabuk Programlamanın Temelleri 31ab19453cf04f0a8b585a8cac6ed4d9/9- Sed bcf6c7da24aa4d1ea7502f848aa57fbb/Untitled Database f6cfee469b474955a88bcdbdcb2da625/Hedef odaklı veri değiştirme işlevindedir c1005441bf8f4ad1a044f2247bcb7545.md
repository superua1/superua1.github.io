# Hedef odaklı veri değiştirme işlevindedir.

Operatör: September 6, 2020