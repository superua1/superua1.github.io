# Yazdırma işlevindedir. print ifadesinin kısaltmasıdır.

Operatör: September 1, 2020 6:00 PM