# BASH Güzel Kaynak

Mutlaka bu resmi kaynağı gözden geçirip değinmediğin kavramları sapta;[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[https://www.computerhope.com/unix/ubash.htm#variable-indirection](https://www.computerhope.com/unix/ubash.htm#variable-indirection)

[https://learning.oreilly.com/videos/bash-scripting/9780134580517/9780134580517-BSHA_02_06](https://learning.oreilly.com/videos/bash-scripting/9780134580517/9780134580517-BSHA_02_06)

[https://www.bogotobogo.com/Linux/linux_process_and_signals.php](https://www.bogotobogo.com/Linux/linux_process_and_signals.php)

İş kontrolü;

- [https://medium.com/@copyconstruct/bash-job-control-4a36da3e4aa7](https://medium.com/@copyconstruct/bash-job-control-4a36da3e4aa7)
- [https://bencane.com/2014/04/01/understanding-the-kill-command-and-how-to-terminate-processes-in-linux/#:~:text=SIGTERM - 15 - Term,use when shutting down cleanly](https://bencane.com/2014/04/01/understanding-the-kill-command-and-how-to-terminate-processes-in-linux/#:~:text=SIGTERM%20%2D%2015%20%2D%20Term,use%20when%20shutting%20down%20cleanly).

Neden iş yapısı var ?

Ayrıca bir "iş" bir ardışık düzen olabilir (bu, birden fazla pid'e sahip olduğu anlamına gelir) veya döngü gibi bir bileşik ifade (bu durumda işteki bazı pid'ler iş çalışırken değişebilir) veya bir komut dosyası çalıştırabilir (burada bireysel komutlar çalışırken kendi pid'lerine sahip olurlar). Aslında, bir iş tüm bunları aynı anda yapabilir. İş kimliği olmadan, tüm kurucu pidleri keşfetmek son derece zor olurdu.

Dosya oluşturma dizin listeleme ve benzeri temel linux bilgisini ele alacak mısın ? Yukarıda bahsi geçen nizami kaynak bu gibi konuları de temel olarak ele almış. Eksik olduğun kısımlara göz at. Ayrıca temel linux bilgisini eklemek kötü bir fikir olmayabilir, bunu bir düşün. Eğitim içerisinde temel linux bilgisini de yedirebilirsin.

KİTAP

Linux Command Line and Shell Scripting Bible

Cybersecurity Ops with bash

[https://github.com/icy/bash-coding-style](https://github.com/icy/bash-coding-style)