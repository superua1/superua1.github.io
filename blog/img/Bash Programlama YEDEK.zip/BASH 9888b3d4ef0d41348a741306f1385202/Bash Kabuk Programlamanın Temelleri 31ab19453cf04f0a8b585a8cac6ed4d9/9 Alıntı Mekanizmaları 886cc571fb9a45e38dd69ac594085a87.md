# 9 Alıntı Mekanizmaları

# 9.1 Alıntılamak

[https://www.notion.so/Shell-Sentaks-e722343855474e16b8cf1d5710ca49a8](https://www.notion.so/10-Shell-Sentaks-e722343855474e16b8cf1d5710ca49a8)

[https://wiki.bash-hackers.org/syntax/quoting](https://wiki.bash-hackers.org/syntax/quoting)

Kabuk için özel anlam ifade eden çeşitli sembolleri ve karakterleri, özel anlamlarına genişletilmeden olduğu gibi kullanmak için "alıntılama" mekanizmalarını kullanabiliyoruz. Zaten girilen karakter ve semboller üzerinde hiç bir değişiklik yapılmağı için bu yapıya "alıntılama" deniyor. 

Söz konusu alıntılama olduğunda üç tür yönteminden bahsedebiliriz;

- Karakter Bazında Alıntılama (Ters Taksim)
- Güçlü Alıntılama (Tek Tırnak)
- Zayıf Alıntılama (Çift Tırnak)

## 9.1.1 Karakter Bazında Alıntılama | Kaçış Karakteri

Özel anlam ifade eden tek bir karakteri alıntılamak için ilgili karakterden önce ters taksim işaretini kullanıyoruz. Bu sayede normalde kabuk üzerinde özel bir anlamı olan karakter, hiç bir özel muamele görmeden olduğu gibi kalıyor. Yani özel anlamına genişletilmiyor.

Aşağıdaki örneğe bakarak bu durumu teyit edebilirsiniz.

```bash
~ → echo "Ben $USER ve $PWD konumundayım"
Ben root ve /root konumundayım
~ → echo "Ben $USER ve \$PWD konumundayım"
Ben root ve $PWD konumundayım
```

Normalde dolar işareti, ilgili değişkenin sahip olduğu değere genişletilmesini sağlayan özel bir karakterdir. Ters taksim işareti sayesinde dolar işaretinin özel anlamının kabuk tarafından görmezden gelinmesini sağladık. 

Hatta bu örnekler dışında, örneğin konsola komut girerken eğer komutun sonuna ters taksim işareti ekleyip enter tuşuna basarsanız varsayılan olarak yeni satıra geçme özelliğinden dahi kaçmış olursunuz. 

```jsx
~ → echo ben ilk satır\
> ben ikinci\
> ben son
ben ilk satırben ikinciben son
```

Normal şartlarda konsola(terminal aracına) herhangi bir komut girip enter tuşuna bastığımızda "newline" olarak geçen özellik gereği komutumuz kabuğa iletilir ve konsolda yeni bir satıra geçiş yaparız. SORU: TERMİNALE GİRİLEN TÜM İNPUTLAR DOĞRUDAN KABUĞA MI İLETİLİR YOKSA TANPONDA MI BEKLETİLİR. YANİ BURADAKİ ECHO KOMUTU İLE VERDİĞİM ÖRNEĞİN AÇIKLAMASI DOĞRU MU?? Komutumuzun sonuna ters taksim işareti ekleyince bu özellikten kaçındığımız için konsol bizden komut almak üzere bir alt satıra geçip bekliyor. Bu özellik genel olarak uzun komutların çok daha okunaklı şekilde yazılabilmesi için kullanılıyor.

Not: Elbette kaçış karakteri, diğer alıntılama karakteri yani tek veya çift tırnak içerisinde yazıldığında kendi özelliğini yitirerek standart bir karakter olarak işlenir. 

```jsx
taylan@DESKTOP-E4TGC85:~$ echo ilk\
son
ilkson
taylan@DESKTOP-E4TGC85:~$ echo ilk"\"
ilk
taylan@DESKTOP-E4TGC85:~$ echo ilk'\'
ilk\
```

```bash
taylan@DESKTOP-E4TGC85:~$ echo \"
"
taylan@DESKTOP-E4TGC85:~$ echo "\""
"
taylan@DESKTOP-E4TGC85:~$ echo '\"'
\"
taylan@DESKTOP-E4TGC85:~$
```

## 9.1.2 Güçlü Alıntılama | Tek Tırnak

Bu alıntılama türünde tek tırnak içerisindeki hiç bir karakter özel olarak yorumlanmaz. Yani yazılı halleri ile oldukları gibi alıntılanırlar. Bash kabuğunda hangi özel anlama geldiklerinin bir önemi yoktur. Zaten bu sebeple tek tırnak ile yapılan alıntılamaya "güçlü alıntılama" da denilmektedir.

```bash
~ → echo 'Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ | '
Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ |
```

İstisnai olarak tek tırnak içerisinde kullanamayacağımız tek özel karakter yine tek tırnaktır. Eğer tek tırnak içinde tek bir tane tek tırnak koyarsanız kabuk tırnağın kapatılmadığını belirterek hata verecektir.

```jsx
~ → echo 'Tek tırnak bas: ' '
>
> ^C
```

Eğer tek tırnak içinde yine kapalı şekilde tek tırnak kullanırsanız bu tırnaklar da alıntılanmayacaktır.

```jsx
~ → echo 'Tek tırnak bas: '' '
Tek tırnak bas:
```

## 9.1.3 Zayıf Alıntı | Çift Tırnak Kullanımı

Zayıf alıntıda yani çift tırnak içerisine yazılmış olan **bazı ifadeler** bash üzerinde sahip oldukları anlamdan muaf tutulurlar. Yalnızca bazı özel karakterlerin alıntılanmasını sağladığı için çift tırnak ile yapılan alıntıya "zayıf alıntılama" da denebiliyor. Çift tırnak içerisinde, aşağıdaki yapılar özel anlamları görmezden gelinerek alıntılanabilir.

- Sözcük ayırmak için kullanılan boşluklar.
- Tek tırnaklar.
- Desen eşleştirme karakterleri * {a..z} vb..
- Tilde genişletmesi.
- Dosya adı genişletmesi. {b*,c*,*est*}  t?.sh
- İşlem ikamesi.

Örneğin çift tırnak içinde değişkenler genişletilirken, tilde genişletmesi yapılmadığını aşağıdaki çıktıları inceleyerek teyit edebilirsiniz.

```jsx
~ → echo $USER ~
root /root
~ → echo "$USER ~"
root ~
~ → echo '$USER ~'
$USER ~
```

Eğer çift tırnak içinde kaçış karakteri olan ters taksim işareti kullanılırsa;

Çift tırnak içerisinde genişletilen bir ifade ise o ifadenin özel anlamına genişletilmesini engeller. 

Eğer kaçış karakterinden sonra kullanılan ifade tırnak içinde özel anlamına genişletilen bir karakter değilse ters taksim işareti de olduğu gibi alıntılanır.

```jsx
~ → echo "$USER ~"
root ~
~ → echo "\$USER \~"
$USER \~
```

Bu bağlamda örneğin ters taksim karakterlerinin art arda kullanılması bir ters taksimin basılmasını da sağlar.

```bash
~ → echo "$PWD"
/root
~ → echo "\$PWD"
$PWD
~ → echo "\\$PWD"
\/root
~ → echo "\\abc"
\abc
~ → echo "\abc"
\abc
```

Tek ve çift tırnak ile alıntılama yaptığımızda tırnak içindeki karakterleri tek bir kelime olarak kabuğa aktarmış oluyoruz. Özellikle içerisinde boşluk gibi karakter bulunan kelimeler ile işlem yapıyorken alıntılama kuralları son derece önemlidir. 

## 9.1.4 ANSI C Alıntılaması

Başında dolar işareti bulunan ve tek tırnak içerisinde yazılmış olan aşağıdaki ifadeler özel anlamlarına genişletilirler. Bu, özellikle bazı programlara, sed'e yeni bir satır iletmek gibi argüman olarak özel karakterler iletmek istediğinizde kullanışlıdır. Ortaya çıkan metin tek tırnaklıymış gibi değerlendirilir. Daha fazla genişleme olmaz.

### 9.1.4.1 Alarm  `\a`

Eğer sistem destekliyorsa, bu karakterin geçtiği satır alarm sesi üretecektir.

```jsx
echo $'Çalsın Alarm\a'
```

### 9.1.4.1 Backspace `\b`

Kullanıldığında, öncesinde yer alan bir karakterin silinmesini sağlar.

```jsx
~ → echo $'dene\bme'
denme
```

### 9.1.4.3 Kaçış Karakteri `\e` `\E`

Devamında yer alan tüm karakteri görmezden gelir.

### 9.1.4.4 Girdi Satırı `\f`

Kullanıldığı bölümde içeri doğru girdi oluşturur.

### 9.1.4.5 Yeni Satır`\n`

Bir sonraki karakterden itibaren bir alt satıra geçilmesini sağlar.

```jsx
echo $'dene\nme'
dene
me
```

### 9.1.4.6 Satır Başı`\r`

### 9.1.4.7 Yatay Tab `\t`

### 9.1.4.8 Dikey Tab `\v`

### 9.1.4.9 Ters Taksim `\b`

### 9.1.4.10 Tek Tırnak `\b`

### 9.1.4.11 Çift Tırnak `\b`

### 9.1.4.12 Soru İşareti `\b`

### 9.1.4.13 Sekizlik `\nnn`

### 9.1.4.14 Onaltılık `\xHH`

### 9.1.4.15 Backspace `\uHHHH`

### 9.1.4.16 Backspace `\UHHHHHHHH`

### 9.1.4.17 Backspace `\cx`

Klavyemizden kontrol karakterleri ile verebileceğimiz emirleri bu kullanım ile gerçekleştirebiliyoruz. Örneğin durdurmak üzere Ctrl+Z tuşlaması yerine echo $'\cZ' şeklinde kullanabiliriz.

## 9.1.5 Yerel Ayara Özgü Çeviri

Eğer dolar işaretinden sonra çift tırnak içerisinde bir ifade belirtildiyse bu ifade için var olan yerelleştirme uygulanır.

echo $"generating database..."

I18N anlamına gelir. Bu dizge için bir çeviri mevcutsa, verilen metin yerine kullanılır. Değilse veya yerel C / POSIX ise, dolar işareti basitçe yok sayılır, bu da normal çift tırnaklı bir dizeyle sonuçlanır.

I18N anlamına gelir. Bu dizge için bir çeviri mevcutsa, verilen metin yerine kullanılır. Değilse veya yerel C / POSIX ise, dolar işareti basitçe yok sayılır, bu da normal çift tırnaklı bir dizeyle sonuçlanır.

Kaçış Karakteri Tek bir karakterden özel anlam nasıl kaldırılır. 

Tek Tırnaklar Bir karakter dizisinin yorumlanması nasıl engellenir. 

Çift Tırnaklar Bir dizi karakterin yorumlanmasının çoğu nasıl engellenir. 

ANSI-C Alıntı Yapma ANSI-C dizileri alıntılanmış dizelerde nasıl genişletilir. 

Yerel Çeviri Dizeler farklı dillere nasıl çevrilir.

Örneğin bak bash kabuğunun Türkçe dil çevirisi: [https://translationproject.org/PO-files/tr/bash-5.1.tr.po](https://translationproject.org/PO-files/tr/bash-5.1.tr.po)

.po dosyası içerinde çevirilmiş ifadeler mevcut sistemdeki lokal dil ayarlarına göre ilgili dil dosyası üzerinden çevirinin yapılmasını sağlıyor.