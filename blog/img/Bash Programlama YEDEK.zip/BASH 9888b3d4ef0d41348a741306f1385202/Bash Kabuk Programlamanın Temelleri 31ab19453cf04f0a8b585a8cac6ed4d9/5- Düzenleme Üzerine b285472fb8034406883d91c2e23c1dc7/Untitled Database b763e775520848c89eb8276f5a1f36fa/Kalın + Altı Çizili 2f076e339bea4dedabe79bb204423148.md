# Kalın + Altı Çizili

Kod (Bash): echo -e "\e[1;4mKalın ve Altı Çizili"