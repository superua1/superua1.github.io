# Kalın + Kırmızı metin + Yeşil arka plan

Kod (Bash): echo -e "\e[1;31;42m Kombinasyon Gerçekleşti \e[0m"