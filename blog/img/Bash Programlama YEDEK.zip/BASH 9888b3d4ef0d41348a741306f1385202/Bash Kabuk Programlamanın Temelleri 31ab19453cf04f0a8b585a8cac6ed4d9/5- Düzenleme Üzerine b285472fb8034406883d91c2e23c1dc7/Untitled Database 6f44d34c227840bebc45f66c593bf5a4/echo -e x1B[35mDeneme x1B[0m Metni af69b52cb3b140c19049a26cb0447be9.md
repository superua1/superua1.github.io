# echo -e "\x1B[35mDeneme\x1B[0m Metni"

printf komutu: printf "\x1B[35mDeneme\x1B[0m Metni"