# echo -e "\033[35mDeneme\033[0m Metni"

printf komutu: printf "\033[35mDeneme\033[0m Metni"