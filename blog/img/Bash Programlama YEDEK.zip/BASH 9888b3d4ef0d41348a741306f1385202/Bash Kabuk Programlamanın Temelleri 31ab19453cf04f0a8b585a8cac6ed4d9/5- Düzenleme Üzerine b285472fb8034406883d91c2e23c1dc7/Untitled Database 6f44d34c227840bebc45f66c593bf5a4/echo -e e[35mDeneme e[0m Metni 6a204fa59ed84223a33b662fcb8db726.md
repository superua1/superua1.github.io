# echo -e "\e[35mDeneme\e[0m Metni"

printf komutu: printf "\e[35mDeneme\e[0m Metni"