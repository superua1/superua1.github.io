# Renkleri tersine çevirme sıfırlanır

KOD: 27
Örnek: echo -e "Normal \e[7mTers Renk \e[27mNormal"