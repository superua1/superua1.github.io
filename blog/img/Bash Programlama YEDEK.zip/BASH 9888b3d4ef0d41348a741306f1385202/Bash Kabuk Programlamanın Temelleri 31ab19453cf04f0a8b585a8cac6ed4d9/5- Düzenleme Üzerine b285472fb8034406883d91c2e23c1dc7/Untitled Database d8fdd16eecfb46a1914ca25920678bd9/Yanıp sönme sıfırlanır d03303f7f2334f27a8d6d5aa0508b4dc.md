# Yanıp sönme sıfırlanır

KOD: 25
Örnek: echo -e "Normal \e[5mYanıp Sönme \e[25mNormal"