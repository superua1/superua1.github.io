# Solukluk sıfırlanır

KOD: 22
Örnek: echo -e "Normal \e[2mSoluk \e[22mNormal"