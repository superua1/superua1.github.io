# Kalınlık sıfırlanır

KOD: 21
Örnek: echo -e "Normal \e[1mKalın \e[21mNormal"