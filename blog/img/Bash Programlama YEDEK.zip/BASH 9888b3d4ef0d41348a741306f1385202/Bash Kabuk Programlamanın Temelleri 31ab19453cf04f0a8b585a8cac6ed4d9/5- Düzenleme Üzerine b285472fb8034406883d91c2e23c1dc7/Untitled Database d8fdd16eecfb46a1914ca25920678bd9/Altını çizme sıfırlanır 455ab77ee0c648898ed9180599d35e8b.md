# Altını çizme sıfırlanır

KOD: 24
Örnek: echo -e "Normal \e[4mAltı Çizili \e[24mNormal"