# Bütün özellikler sıfırlar

KOD: 0
Örnek: echo -e "\e[0mNormal Yazı"