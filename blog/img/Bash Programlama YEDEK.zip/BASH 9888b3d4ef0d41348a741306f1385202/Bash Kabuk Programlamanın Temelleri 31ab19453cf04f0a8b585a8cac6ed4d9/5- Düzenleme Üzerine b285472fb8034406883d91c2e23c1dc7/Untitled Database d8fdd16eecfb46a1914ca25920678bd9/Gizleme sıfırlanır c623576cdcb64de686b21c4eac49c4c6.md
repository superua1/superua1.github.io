# Gizleme sıfırlanır

KOD: 28
Örnek: echo -e "Normal \e[8mGizli İfade\e[28mNormal"