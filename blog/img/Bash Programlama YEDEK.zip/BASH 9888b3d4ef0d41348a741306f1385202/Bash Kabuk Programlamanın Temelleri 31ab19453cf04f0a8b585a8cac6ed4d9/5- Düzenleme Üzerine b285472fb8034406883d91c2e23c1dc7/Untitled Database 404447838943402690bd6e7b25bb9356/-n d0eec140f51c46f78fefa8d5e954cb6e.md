# -n

Açıklama: Sonraki satırı atlamaz.