# \\"

İşlev: Tırnak işaretinin çıktı olarak basılmasını sağlar.