# Gizleme (parola uygulamaları için kullanışlıdır.)

KOD: 8
Örnek: echo -e "Normal \e[8mGizli İfade"