# Yanıp söner

KOD: 5
Örnek: echo -e "Normal \e[5mYanıp Sönen"