# Altını çizer

KOD: 4
Örnek: echo -e "Normal \e[4mAltı çizili"