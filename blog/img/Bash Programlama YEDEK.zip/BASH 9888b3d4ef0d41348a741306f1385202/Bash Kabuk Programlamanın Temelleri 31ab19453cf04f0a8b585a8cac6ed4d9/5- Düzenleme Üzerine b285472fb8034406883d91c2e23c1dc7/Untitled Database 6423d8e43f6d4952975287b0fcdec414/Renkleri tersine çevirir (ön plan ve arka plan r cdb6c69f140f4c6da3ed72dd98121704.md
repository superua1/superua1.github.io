# Renkleri tersine çevirir (ön plan ve arka plan renklerini ters çevir)

KOD: 7
Örnek: echo -e "Normal \e[7mTers Renk"