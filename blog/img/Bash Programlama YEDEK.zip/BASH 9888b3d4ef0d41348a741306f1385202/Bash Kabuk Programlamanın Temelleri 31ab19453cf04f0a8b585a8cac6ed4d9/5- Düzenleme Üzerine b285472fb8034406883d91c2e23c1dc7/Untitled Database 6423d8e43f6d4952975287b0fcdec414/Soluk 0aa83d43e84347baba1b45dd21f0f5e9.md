# Soluk

KOD: 2
Örnek: echo -e "Normal \e[2mSoluk"