# Varsayılan ön plan rengi

kod: 39
Örnek: echo -e "Varsayılan \e[39mVarsayılan"