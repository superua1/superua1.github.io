# Cam göbeği

kod: 36
Örnek: echo -e "Varsayılan \e[36mCam göbeği"