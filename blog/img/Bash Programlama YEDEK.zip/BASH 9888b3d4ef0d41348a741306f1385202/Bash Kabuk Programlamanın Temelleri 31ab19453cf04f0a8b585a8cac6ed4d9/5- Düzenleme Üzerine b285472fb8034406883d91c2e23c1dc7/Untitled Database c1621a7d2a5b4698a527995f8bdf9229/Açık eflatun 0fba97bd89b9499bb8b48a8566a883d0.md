# Açık eflatun

kod: 95
Örnek: echo -e "Varsayılan \e[95mAçık eflatun"