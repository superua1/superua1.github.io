# Koyu gri

kod: 90
Örnek: echo -e "Varsayılan \e[90mKoyu gri"