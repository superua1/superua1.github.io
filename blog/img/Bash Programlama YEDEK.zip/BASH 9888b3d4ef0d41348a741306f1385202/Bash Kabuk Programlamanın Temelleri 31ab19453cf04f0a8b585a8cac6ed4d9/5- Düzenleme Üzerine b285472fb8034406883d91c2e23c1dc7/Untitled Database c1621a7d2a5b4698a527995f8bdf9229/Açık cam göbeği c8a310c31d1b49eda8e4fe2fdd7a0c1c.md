# Açık cam göbeği

kod: 96
Örnek: echo -e "Varsayılan \e[96mAçık mavi"