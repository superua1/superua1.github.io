# Açık sarı

kod: 93
Örnek: echo -e "Varsayılan \e[93mAçık sarı"