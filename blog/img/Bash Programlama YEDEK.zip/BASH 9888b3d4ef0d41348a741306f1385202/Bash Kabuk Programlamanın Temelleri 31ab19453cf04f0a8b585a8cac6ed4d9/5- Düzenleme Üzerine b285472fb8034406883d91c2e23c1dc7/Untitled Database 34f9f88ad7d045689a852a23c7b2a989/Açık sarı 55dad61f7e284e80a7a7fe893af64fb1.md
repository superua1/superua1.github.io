# Açık sarı

Kod: 103
Örnek: echo -e "Varsayılan \e[103mAçık sarı"