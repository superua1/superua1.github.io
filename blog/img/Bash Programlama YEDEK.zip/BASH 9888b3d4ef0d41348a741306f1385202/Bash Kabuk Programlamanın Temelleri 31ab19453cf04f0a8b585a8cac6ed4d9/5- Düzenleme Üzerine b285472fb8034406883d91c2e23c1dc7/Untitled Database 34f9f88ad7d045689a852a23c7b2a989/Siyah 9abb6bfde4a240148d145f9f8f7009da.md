# Siyah

Kod: 40
Örnek: echo -e "Varsayılan \e[40mSiyah"