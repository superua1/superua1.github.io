# Koyu gri

Kod: 100
Örnek: echo -e "Varsayılan \e[100mKoyu gri"