# Açık yeşil

Kod: 102
Örnek: echo -e "Varsayılan \e[102mAçık yeşil"