# Açık eflatun

Kod: 105
Örnek: echo -e "Varsayılan \e[105mAçık eflatun"