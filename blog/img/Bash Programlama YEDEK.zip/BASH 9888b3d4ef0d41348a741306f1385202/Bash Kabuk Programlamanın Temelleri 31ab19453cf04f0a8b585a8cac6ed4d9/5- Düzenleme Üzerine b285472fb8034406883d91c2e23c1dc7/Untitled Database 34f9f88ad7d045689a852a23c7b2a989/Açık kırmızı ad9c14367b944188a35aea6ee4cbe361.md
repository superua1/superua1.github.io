# Açık kırmızı

Kod: 101
Örnek: echo -e "Varsayılan \e[101mAçık kırmızı"