# Eflatun

Kod: 45
Örnek: echo -e "Varsayılan \e[45mEflatun"