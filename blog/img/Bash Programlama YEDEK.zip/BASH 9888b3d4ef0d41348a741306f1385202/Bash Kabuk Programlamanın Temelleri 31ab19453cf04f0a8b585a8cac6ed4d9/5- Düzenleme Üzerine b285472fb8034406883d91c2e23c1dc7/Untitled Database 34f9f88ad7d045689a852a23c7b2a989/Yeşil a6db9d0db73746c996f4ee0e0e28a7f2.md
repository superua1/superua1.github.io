# Yeşil

Kod: 42
Örnek: echo -e "Varsayılan \e[42mYeşil"