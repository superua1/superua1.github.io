# Varsayılan arka plan rengi

Kod: 49
Örnek: echo -e "Varsayılan \e[49mVarsayılan"