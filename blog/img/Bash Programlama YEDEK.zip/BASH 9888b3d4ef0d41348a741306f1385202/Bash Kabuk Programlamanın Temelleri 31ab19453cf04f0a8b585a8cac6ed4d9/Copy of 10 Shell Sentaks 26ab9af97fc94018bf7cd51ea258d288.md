# Copy of 10. Shell Sentaks

Komut satırının tüm karakterler solda sağa doğru tek tek denetlenir. Önceki karakter bir operatörün parçası olarak kullanılabiliyorsa bu karakter bütünü tek bir operatör olarak tokenlenir. Örneğin ilk örnekte ortam özelliklerini bastırmamızı sağlayan `$-` operatörü, `$$-` şeklinde kullanılınca kabuk tarafından `$$` ve `-` şeklinde ayrıştırılmış oldu.

```jsx
 ~ → echo $-
himBCHs
 ~ → echo $$-
8-
```

Benzer şekilde önceki karakter operatörden hemen önce kullanılmışsa ancak operatörün bir parçası değilse ilk karakter ile operatör ayrı şekilde tokenlenir.

```jsx
 ~ → echo -$$
-8
```

Mevcut karakter, alıntı karakteri yani "ters taksim `\`", "tek tırnak `'` veya "çift tırnak `"` " içeriyorsa, alıntı karakterinin kapatıldığı karaktere kadar tüm karakterler tek bir token olarak değerlendirilir. Bu token içindeki karakterler alıntılama kurallarında açıkladığımız şekilde değerlendirilecektir. Örneğin tek tırnak içinde istediğiniz karakteri bastırabiliriz.

```jsx
~ → echo '/n\*-"$$'
/n\*-"$$
```

Eğer tırnağı kapatmadan Ctrl + D tuşu ile veri girişini sonlandırırsak elbette kabuk sözdizimi(syntax) hatası verecektir. Çünkü girdiğimiz veriyi doğru şekilde tokenleyemeyecektir. 

```jsx
~ → echo '/n\*-"$$
>
-bash: unexpected EOF while looking for matching `''
-bash: syntax error: unexpected end of file
```

Mevcut karakter alıntılanmamış dolar işareti `$` ya da ters tırnak ``` ise; bu karakterin devamındaki karaktere göre "parametre genişletme", "komut ikamesi" ya da "aritmetik genişletme" için ayrıştırılırlar. 

Dolar işareti tek başına kullanıldıysa yani devamında standart karakterler geliyorsa bu karakter bütünü tek bir token olarak sınırlandırılır. Örneğin $HOME karakter bütünü tek bir token olarak ele alınır. Benzer şekilde diğer durumlar da aşağıdaki gibidir;

```jsx
~ → echo $HOME
/root
```

Dolar işaretinden sonra kıvırcık parantez karakteri geliyorsa "parametre genişletme" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo ${#HOME}
5
```

Dolar işaretinden sonra parantez karakteri geliyorsa "komut ikamesi" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo $(whoami)
root
```

Dolar işaretinden sonra çift parantez geliyorsa "aritmetik genişletme" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo $((3+5))
8
```

Tek tırnak kullanıldıysa "komut ikamesi" kalıbına uyduğu için bu karakter bütünü tek bir token olarak sınırlandırılır. 

```jsx
~ → echo `whoami`
root
```

Hatta sınırlandırma işlemini teyit etmek üzere hepsini bir arada da kullanabiliriz. 

```jsx
echo $HOME${#HOME}$(whoami)$((3+5))`whoami`
/root5root8root
```

Elbette boşluk karakteri de, karakter gruplarını ayrı ayrı tokenlenleştirilmesini sağlıyor. 

Yani örneğin "butekbirsatır" veri girişi tek bir token olarak sınırlandırılırken, "bu tek bir satır" girişi "bu" "tek" "bir" "satır" şeklinde ayrı ayrı tokenlenecektir.

Yorum yani `#` karakterinden sonraki tüm karakterler yorum olarak değerlendirildiği için tokenleme yapılmaz. Yorum `#`  karakterini sonlandıran şey yeni satıra geçiştir. Yeni satıra geçilmediği sürece yorum karakterinin devamındaki hiç bir karakter işlenmeyecektir.

```jsx
~ → echo ben satır #ben ise yorumum
ben satır
```

 

Token sınırlandırma bittiğinde kabuğun dilbilgisi kurallarının gerektirdiği şekilde kategorize edilir.

Takma isim genişletme, tokenler sınırlandırıldıktan hemen sonra dilbilgisi denetimine geçmeden evvel gerçekleştirilir.

Command substitutions içerisindeki komutlar özel muamele görür. Yani tekrar shell synatxinden geçirilmez. Yalnızca IFS sayesinde kelime bölme uygulanır. Bu bir özelliktir, hata değildir: Komut ikamesi sonuçları sözdizimi olarak ayrıştırılırsa, güvenilmeyen verileri işleyen güvenli kabuk komut dosyaları yazmak temelde imkansız olurdu.

[https://stackoverflow.com/questions/59184358/why-isnt-a-semicolon-in-command-substitution-output-treated-identical-to-one-in](https://stackoverflow.com/questions/59184358/why-isnt-a-semicolon-in-command-substitution-output-treated-identical-to-one-in)

Ama örneğin aşağıdaki komut çalışıyor ?

pwd ; $(sleep 11; sleep 22 )

[https://learning.oreilly.com/library/view/learning-the-bash/0596009658/ch07.html#bash3-CHP-7-SECT-3](https://learning.oreilly.com/library/view/learning-the-bash/0596009658/ch07.html#bash3-CHP-7-SECT-3)

[https://aosabook.org/en/bash.html](https://aosabook.org/en/bash.html)

[https://mywiki.wooledge.org/BashParser](https://mywiki.wooledge.org/BashParser)

[https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_03](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_03)

Buradaki açıklamalar, resmi dokümantasyon ve kaynak kodun analizinden yola çıkarak sadeleştirilmiş en temel işleyişi temsil ediyor. Kabuğun yapısı gereği elbette pek çok farklı duruma özel pek çok ekstra detay ve kompleks aşama bulunuyor. Eğer benim açıkladığım adımları sorgulamak ve daha detaylı araştırma yapmak isterseniz elbette sizler de kaynak kodları analiz edebilir ya da kabuk için posix standartları kılavuzuna göz atabilirsiniz. Bizler kabuğu etkili biçimde kullanabilmemize yetecek düzeyde değiniyor olacağız.  

Tüm anlatılanların kolay anlaşılabilmesi için öncelikle temel kavramları kısaca ele almamız gerekiyor. 

Token: Kabuk tarafından tek bir birim olarak kabul edilen bir dizi karaktere verilen isimdir. Tokenler ya bir kelime ya da bir operatördür. Tokenlere belirteç gibi Türkçe karşılık da verilibilir ancak token olarak kalması kolay anlaşılması için daha iyi olacaktır.

Kelime: Kabuk tarafından bir birim olarak ele alınan bir dizi karakter. Kelimeler, tırnaksız meta karakterler içeremez.

Operatör: Bir kontrol operatörü veya bir yeniden yönlendirme operatörü. Yeniden yönlendirme işleçlerinin listesi için Yönlendirmeler konusuna bakın. Operatörler en az bir alıntılanmamış meta karakter içerir.

Metakarakter: Alıntı yapılmadığında kelimeleri ayıran bir karakter. Meta karakter bir boşluk, sekme, yeni satır veya şu karakterlerden biridir: "|", "&", ";", "(", ")", "<" veya ">".

Kontrol Operatörü: Kontrol işlevini sağlayan tokene verilen isimdir. Bunlar "yanı satır" ya da ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’,  ‘)’ metakarakterlerini içerir.

### 10.1.1 Emirin Alınması

Kabuk emirleri; bir betik dosyasından, bash -c çağırma seçeneğine argüman olarak sağlanan bir dizeden veya kullanıcının terminalinden okur. Kısacası kabuğa işlemesi üzere emir verilir. Emir alındıktan sonra eğer history kayıt tutma aktifse komut history kaydına uygun şekilde eklenir.

### 10.1.2 Sözcük Analizi: Token Üretimi

Girilen komut içerisinde yer alan metakarakterler(Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’) sayesinde girdiyi alıntılama kurallarına da dikkat ederek "kelimelere" ve "operatörlere" böler. Bölme işleminin sonucunda oluşturulan karakter gruplarına "token" denir. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg)

Girilen karakterler kontrol edilirken alıntılanmamış `#` yani yorum karakterine denk gelinirse, bu karakterden sonraki hiç bir karakter token olarak ayrıştırılmaz. Yorum kapsamını yalnızca <newline> yani yani satır sonlandırır. Kabuk token oluşturma işlemi sırasında yorum karakterinde denk geldiğinde yeni satıra geçilinceye kadar tüm karakteri yorumdan sayacaktır. 

Girilen karakterlerden tokenler oluşturulduktan sonra, tokenler takma isim listesinde kontrol edilir. Eğer eşleşme varsa takma ad gerçek değerine genişletir. Eğer takma isimle eşleşme olmazsa bir sonraki adıma geçilir.

### 10.1.3 Ayrıştırıcı: Tokenlerin Basit ve Bileşik Komutlara Ayrılması

Bir ayrıştırıcı, dilbilgisi-gramer ve sözdizimi-sentaks kuralı kontrolcüsü olarak düşünülebilir. Karakter girdilerinden tokenler oluşturulduktan sonra, sözdizimi hatalarını saptamak ve tokenlerin oluşturduğu emir bütününü doğru anlamlandırmak üzere ayrıştırma işlemi uygulanır. 

Neticede bu aşamada kabuğun elinde sıralı şekilde pek çok token vardır. Kabuk da bu tokenlerin tek bir komut mu yoksa birden çok komut için mi kullanıldığını anlamak ister. Kısacası tokenleri doğru şekilde gruplayarak basit ve bileşik komutlar haline getirmek istiyor. Bunun için de öncelikle elde bulunan sıralı tokenlerin uygun bölümlerden ayrıştırılması gerek.

Tokenleri uygun şekilde ayrıştırmayı da tokenler içerisindeki "kontrol operatörleri" mümkün kılar. Ayrıştırıcı, baştan sonra tüm tokenleri "kontrol operatörü" mü diye kontrol eder. Kontrol operatörüne denk geldiği anda, operatörden önceki tokenleri, komutun devamındaki tokenlerden ayırır. Böylelikle eldeki tüm tokenler uygun şekilde birbirinden ayrılarak gruplanmış olur.

Ayrıca buradaki kontrol operatörleri gruplanmış olan tokenlerin ne şekilde çalıştırılması gerektiğini de belirtmektedir. Örneğin & kontrol operatörü ile ayrılmış token grubu aslında arkaplanda çalıştırılacak şekilde işaretlenmiştir. 

Ayrıştırma işleminin ardından tokenlerin sözdizimsel kontrolü yapılır. Bu kontrol komutun basit veya bileşik olmasın göre değerlendirilir. Daha net anlaşılması için kısaca basit ve bileşik komutları da açıklayalım.

Basit komutlar: Basit komutlar boşluk karakteriyle birbirinden ayrılmış ve bir kontrol operatörü tarafından sonlandırılan bir dizi kelimeyi temsil eder. Genellikle ilk kelime çalıştırılacak komutu belirtirken, geri kalan kelimler çalıştırılan komuta verilen argümanlardır. 

Bileşik Komutlar: Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sonlandırılır. Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve mekanizmalar sağlar.

İşte bu aşamada kabuk, token grubunun basit mi bileşik mi olduğunu grup içindeki tokenlere bakarak anlayabilir. Örneğin token grubu `if` tokeni ile başlıyorsa bu token grubu bileşik komut olarak görülür ve bileşik komutun tamamlanması için `fi` tokeni ile bitirilip bitirilmediği kontrol edilir. Eğer bitirilmediyse syntax yani sözdizimi hatası döndürülür. Eğer bitirildiyse token grubu denetimden geçer ve bir sonraki token grubu denetlenir. Bu işlem tüm tokenler sorgulanana kadar devam eder.

Neticede ayrıştırma aşamasında tokenler basit ve bileşik komutlara ayrılıp, basit veya bileşik olma durumları dahilinde sözdizimi kuralları da kontrol edilir.

## 10.1.4 Genişletme:

### Parsing | Ayrıştırma Aşaması

Tokenlere ayrılmış olan komut bütünü, içerisinde bulunan kontrol operatörleri sayesinde basit ve bileşik komut olarak ayrıştırılır. 

### Basit Komutlar

Basit komutlar boşluk karakteriyle birbirinden ayrılmış ve bir kontrol operatörü tarafından sonlandırılan bir dizi kelimeyi temsil eder. Genellikle ilk kelime çalıştırılacak komutu belirtirken, geri kalan kelimler çalıştırılan komuta verilen argümanlardır. 

### Karmaşık Komutlar

Basit komutların çeşitli yollarla bir araya getirilmesi sonucu karmaşık komut yapıları üretebiliriz. Karmaşık komut oluşturmada aşağıdaki yapılar etkilidir.

- Rezerve Kelimeler
- Pipe hattı
- Listelenmiş Komutlar
- Bileşik Komutlar
- Yardımcı İşlemler
- GNU Parallel gibi araçlar.

Zaten kabuğun ayrıştırıcı mekanizması da bu yapılara göz atarak girilen komut bütününü basit ve bileşik şekilde ayrıştırabilir.

Komutun içindeki operatörler "kontrol operatörü" mü diye bakılır. Öyleyse operatöre kadar olan komut, diğer komut bütününden ayrıştırılır. Bu şekilde tüm komutlar birbirinden ayrıştırılımış olur. Daha sonra ayrıştırılmış olan komutlar en baştan hangi türde diye kontrol edilir. Örneğin rezerve bir kelime ise bu rezerve kelimenin bitişi var mı diye bakılır. Eğer yoksa bu komut syntax hatası verecektir. Bu gibi kurallara kontrol edildikten sonra eğer sorun yoksa bir sonraki aşama olan genişletme aşamasına geçilir.

Kısaca bileşik komutları mümkün kılan yapıları açıklamamız gerekirse;

**Rezerve kelimeler;** Ayrılmış sözcükler, kabuk için özel anlamı olan sözcüklerdir. Kabuğun bileşik komutlarını başlatmak ve bitirmek için kullanılırlar. Aşağıdaki sözcükler, alıntı yapılmadığında ve bir komutun ilk sözcüğü olduğunda rezerve olarak kabul edilir (istisnalar için aşağıya bakın):

```jsx
if	then	elif	else	fi	time
for	in	until	while	do	done
case	esac	coproc	select	function
{	}	[[	]]	!
```

in, bir case veya select komutunun üçüncü sözcüğüyse, rezerve bir sözcük olarak tanınır.

in ve do, for komutundaki üçüncü kelimeyse, rezerve kelimeler olarak kabul edilir.

Pipeline; Birkaç basit komutun çıktısını ve girdisini birbirine aktarmayı sağlayan yapıdır. Bu yapı ile birden fazla basit komut kullanılarak bileşik komut oluşturulmuş olur.

Liste; Basit komutların sıralı şekilde koşullara bağlı olarak yürütülmesini sağlar. && ve || operatörleridir.

Bileşik Komutlar: Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sonlandırılır. Bir bileşik komutla ilişkili tüm yeniden yönlendirmeler (bkz. Yeniden Yönlendirmeler), açıkça geçersiz kılınmadıkça, bu bileşik komut içindeki tüm komutlar için geçerlidir. Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve mekanizmalar sağlar.

Komutların doğru şekilde çalıştırılabilmesi için ayrıştırıcı bu aşamada basit ve bileşik komutları ayrıştırır. Örneğin bileşik komut rezerve bir kelime ile başladıysa ancak rezerve bir kelime ile bitmediyse kabuk syntax hatası verecektir. Zaten basit komutlar da kontrol operatörleri sayesinde birbirinden ayrıştırılır. İleriki aşama olan çalıştırma aşamasında bu kontrol operatörleri dikkate alınarak basit komut yapıları uygun şekilde çalıştırılacaktır.

### Genişletme

Ayrıştırma işleminden sonra sırasıyla genişletme adımları uygulanır. 

1. Tilde expansion (see [Tilde Expansion](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_01)), parameter expansion (see [Parameter Expansion](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_02)), command substitution (see [Command Substitution](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_03)), and arithmetic expansion (see [Arithmetic Expansion](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_04)) shall be performed, beginning to end. See item 5 in [Token Recognition](https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_03).
2. IFS değeri boş değilse 1. aşamada genişletilmiş olan değerleri bölünür.
3. set -f olmadığı sürece pathname genişletmesi uygulanır.
4. En son alıntı karakteri kaldırılır. 

Bu bölümde açıklanan genişletmeler, komutun yürütüldüğü kabuk ortamında gerçekleşecektir. Bir sözcük için uygun olan tam genişletme boş bir alanla sonuçlanırsa, orijinal sözcük tek tırnaklı veya çift tırnaklı karakterler içermedikçe, bu boş alan tamamen genişletilmiş komutu oluşturan alanlar listesinden silinecektir.

- Shell Expansions
- Komut içeriyorsa, küme ayracı genişletmesi uygulanır.
- Komut içeriyorsa, tilde genişletmesi uygulanır.
- Komut içeriyorsa, değişken genişletmesi uygulanır.
- Komut içeriyorsa, komut ikamesi genişletmesi uygulanır.
- Komut içeriyorsa, aritmetik genişletmesi uygulanır.

Genişletmelerin arından ortaya çıkan karakterler de ilk adımda olduğu gibi tekrar kelime tokenlerine bölünür. Buradaki bölümleme işleminde ilk adımın aksine metakarakterler değil IFS değişkeninin sahip olduğu ayrıştırıcı değer kullanılır. Bu değer özellikle değiştirilmediği sürece boşluk karakteridir. Çünkü genişletmeler yalnızca argüman olarak kullanılmak için yapılır. 

1. parsing and lexical analysis
2. expansion
    1. brace expansion
    2. tidle expansion
    3. variable expansion
    4. artithmetic and other substitutions
    5. command substitution
    6. **word splitting**
    7. filename generation (globbing)
3. removing quotes

**Kelime Bölme İşlemi**

Bu işlem genişletilmiş kelimler üzerinde uygulanır. Yani genişletme yoksa bu kelime bölme işlevi de elbette uygulanmaz. 

Kabuk, sözcük bölme için çift tırnak içinde meydana gelmeyen parametre genişletme, komut ikamesi ve aritmetik genişletme sonuçlarını tarar. Ve IFS değişkeninin değerine(IFS bölme işlemi için varsayılan olarak boşluk karakterine sahiptir) göre genişletilmiş olan karakterleri kelimelere böler. Genişletilmiş karakterler kelimelere bölündükten sonra dosya genişletme aşamasına geçilir.

Dosya adı genişletmesi;

Dosya adı genişletmesi de uygulandıktan sonra artık çalıştırılacak komutlar, çalıştırılan komutlara verilecek olan argümanlar tam olarak hazıdır. Bu yapı bir sonraki aşama olan çalıştırma aşamasına devredilir.

## Çalıştırma Aşaması

Kullanıcının en başta girmiş olduğu emirin kabuk tarafından yorumlanmış en son hali soldan sağa doğru olacak şekilde sırasıyla çalıştırılır. Çalıştırma aşamasında ilk kelime her zaman çalıştırılacak komutu belirtir. Geri kalanlar komutun argümanlarıdır. Zaten ayrıştırma aşamasında basit komutların ne şekilde çalıştırılması gerektii de beliritği için çalıştırma aşaması tüm basit ve bileşik komutları uygun şekilde çalıştırılmasını sağlar.

Kabuk bir komutu çalıştırmak istediğinde öncelikle çalıştırılacak olan komutun bulunması gerekir. Bulma adımları aşağıdaki gibidir.

- Çalıştırılacak olan komut aranır ve argümanlarıyla birlikte uygun şekilde çalıştırılır.
    - Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
    - Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
    - Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
    - İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
    - Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
    - Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
    - İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
    - Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).
- Komutun çalışması bittikten sonra çıkış durumunu döndürür. Ve böylelikle verilen emir kabuk tarafından uygun şekilde yerine getiriliş olur.

Güzel bir örnek takma isim atlatmak için l\s şeklinde bir kullanım olabilir. Takma isim genişletmesi token oluşturma aşamasından hemen sonra gerçekleştiği için l\s yapısındaki kaçış karakteri genişletilemez öylece kalır. Öylece kalınca da mevcut takma isim ile eşleşemez. İşte bu ve bunun gibi sebeplerle kabuğun komutarı nasıl ele aldığını bilmemiz önemli.

DOSYA ADI GENİŞLETME KAVARMINA GÖZ AT [https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html](https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled.png)

- Komut metakarkterler sayesinde tokenlere bölünür.
- Tırnak işareti veya ters eğik çizgi içermeyen bir anahtar kelime olup olmadığını görmek için her komutun ilk belirtecini kontrol eder. If ve diğer kontrol yapısı açıcıları, function, {veya (() gibi bir açılış anahtar sözcüğüyse, komut aslında bir bileşik komuttur. Kabuk ortamını buna göre ayarlar. Anahtar kelime bileşik bir komut açıcı değilse (ör., o zamanki gibi bir kontrol yapısı "orta" ise, else veya do, fi veya done gibi bir "son" veya mantıksal bir işleçse), kabuk sözdizimi hatası verir.
- Her komutun ilk kelimesi takma isim listesinde kontrol edilir. Eğer eşleşme varsa takma adı gerçek değerine genişletir ve ilk adıma yani tokenlere bölme aşamasına dönülür. Eğer takma isimle eşleşme olmazsa bir sonraki adıma geçilir.
- Komut içeriyorsa, küme ayracı genişletmesi uygulanır.
- Komut içeriyorsa, tilde genişletmesi uygulanır.
- Komut içeriyorsa, değişken genişletmesi uygulanır.
- Komut içeriyorsa, komut ikamesi genişletmesi uygulanır.
- Komut içeriyorsa, aritmetik genişletmesi uygulanır.
- Genişletmelerin arından ortaya çıkan karakterleri de ilk adımda olduğu gibi tekrar kelime tokenlerine bölünür. Buradaki bölümleme işleminde ilk adımın aksine metakarakterler değil IFS değişkeninin sahip olduğu ayrıştırıcı değer kullanılır. Bu değer özellikle değiştirilmediği sürece boşluk karakteridir.
- Komut içeriyorsa, pathname expension yani joker karakter genişletmesi uygulanır.
- Gerekli yönlendirmeler gerçekleştirilir.
- Çalıştırılacak olan komut aranır ve argümanlarıyla birlikte uygun şekilde çalıştırılır.
    - Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
    - Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
    - Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
    - İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
    - Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
    - Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
    - İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
    - Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).
- Komutun çalışması bittikten sonra çıkış durumunu döndürür. Ve böylelikle verilen emir kabuk tarafından uygun şekilde yerine getiriliş olur.

Güzel bir örnek takma isim atlatmak için l\s şeklinde bir kullanım olabilir. Takma isim genişletmesi token oluşturma aşamasından hemen sonra gerçekleştiği için l\s yapısındaki kaçış karakteri genişletilemez öylece kalır. Öylece kalınca da mevcut takma isim ile eşleşemez. İşte bu ve bunun gibi sebeplerle kabuğun komutarı nasıl ele aldığını bilmemiz önemli.

Tüm anlatıların kolay anlaşılabilmesi için öncelikle temel kavramları kısaca ele almamız gerekiyor.

Token: Kabuk tarafından tek bir birim olarak kabul edilen bir dizi karaktere verilen isimdir. Tokenler ya bir kelime ya da bir operatördür. Tokenlere belirteç gibi Türkçe karşılık da verilibilir ancak token olarak kalması kolay anlaşılması için daha iyi olacaktır.

Kelime: Kabuk tarafından bir birim olarak ele alınan bir dizi karakter. Kelimeler, tırnaksız meta karakterler içeremez.

Operatör: Bir kontrol operatörü veya bir yeniden yönlendirme operatörü. Yeniden yönlendirme işleçlerinin listesi için Yönlendirmeler konusuna bakın. Operatörler en az bir alıntılanmamış meta karakter içerir.

Metakarakter: Alıntı yapılmadığında kelimeleri ayıran bir karakter. Meta karakter bir boşluk, sekme, yeni satır veya şu karakterlerden biridir: "|", "&", ";", "(", ")", "<" veya ">".

Kontrol Operatörü: Kontrol işlevini sağlayan tokene verilen isimdir. Bunlar "yanı satır" ya da ‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’,  ‘)’ metakarakterlerini içerir.

SÖZCÜK ANALİZİ AŞAMASINDA KELİMLERİN TÜRLERİ İLE TOKEN OLUŞTURULDUĞUDAN EMİN OL DOKÜMANDA BU AŞAMA AYRIŞTIRMA KISMINDA GERÇEKLEŞİYOR GİBİ.

[http://www.belgeler.org/bashref/bashref_shell.operation.html](http://www.belgeler.org/bashref/bashref_shell.operation.html)

[https://www.geeksforgeeks.org/developing-linux-based-shell/](https://www.geeksforgeeks.org/developing-linux-based-shell/)

Bu bölüm eğitim son kısımlarında yer alıyor çünkü eğitim içerisinde bahsi geçen pek çok konuya atıfta bulunmamız gerekiyor. Buradaki amacımız kabuğun gözünden işleyişin nasıl olduğunu **genel hatlarıyla** öğrenebilmektir. Bu sayede ele aldığımız tüm kavramlar ve bu kavramların birbiri ile olan yakın ilişkisi bizler için netleşmiş olacak. Bizlerin kabuğa verdiği emirlerin hangi sıralama ile ele alındığını bilmemiz elbette doğru ve etkili kabuk kullanmamızı sağlayacaktır. 

# 10.1 Kabuğun Genel Çalışma Yapısı

Kabuk, kendisine verilmiş olan emirleri yani girdileri bir dizi işlemden geçirerek yorumlar. Bir dizi işlem olarak tabir ettiğimiz yorumlama süreci **en genel haliyle** ; **sözcük analizi**, **ayrıştırma** ve **çalıştırma** aşamalarından oluşur. Elbette tüm bu sürecin her aşamasında geçerli olan pek çok kural ve bu kuralların bağlam dahilinde uygulanma sıralaması vardır. Anlatımın devamında kabuk için daha anlaşılır emirler vermemize yardımcı olması için biz bu kurallardan **genel hatlarıyla** bahsediyor olacağız. 

İşlem adımlarını rahat takip edebilmek adına aşağıdaki komut üzerinden açıklama yapıyor olacağız. 

`find /etc -name "bulbeni*" | sort > sonuc.txt`

buradaki yıldız işareti kabuk tarafından değil find komutu tarafından genişletiliyor. Kabuk "bulbeni*" ifadesini argüman olarak veriyor. Fİnd komutumu da bu argümanı kendi kuralları dahilinde işleyip yıldız işaretini genişletiyor. Tırnak işareti olmadan kullanılığında kabuk bu eşleşmeye uyan tüm dosyaları doğrudan find komutuna argüman olarak iletmiş oluyor. Bu kısım biraz kafa karıştırabilir bu sebeple bu örneğini değilştirmeyi düşün. Bu açıklama genişletmeleri açıklarken faydalı olabilir. Find haricinde kendisi genişletme yapmayan komutlar üzerinden bu durumu kanıtlayabilirsin.

[https://unix.stackexchange.com/questions/345304/in-what-way-does-quoting-parameters-to-find-matter?noredirect=1&lq=1](https://unix.stackexchange.com/questions/345304/in-what-way-does-quoting-parameters-to-find-matter?noredirect=1&lq=1)

`find` komutu ile ***/etc*** dizini altında yer alan ve içerisinde "bulbeni" karakterlerinin geçtiği tüm dosya dizinler bulunup `sort` komutu ile sıralanmasını sağlanacak ve en nihayetin çıktılar sonuc.txt dosyasına yönlendirilecektir.

Elbette bu komut bütünü, kabuğun maruz kalacağı olası tüm emirleri yansıtmıyor olsa da genel hatlarıyla kabuğun yorumlama ve çalıştırma serüveni hakkında bilgi sahibi olmamıza yetecektir. 

Bash kabuğuna verdiğimiz emirlerin okunup yorumlanması sırasında gerçekleşen işlem adımları kısaca aşağıdaki şekildedir.

### 10.1.1 Emirin Alınması

Kabuk emirleri; bir betik dosyasından, bash -c çağırma seçeneğine argüman olarak sağlanan bir dizeden (Bash programının özelliklerini açıkladığımız bölüme göz atın) veya kullanıcının terminalinden okur. Kısacası kabuğa işlemesi üzere emir verilir. Emir alındıktan sonra eğer history kayıt tutma aktifse komut history kaydına uygun şekilde eklenir.

### 10.1.2 Sözcük Analizi: Token Üretimi

Kabuğa verilen emirdeki tüm karakterler alıntı kurallarına da dikkat edilerek aralarındaki metakarakterlerden(Metakarakterler; "boşluk", "tab", "yeni satır" ya da ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’), "token" olarak ifade edilen özel karakter gruplarına bölünürler. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer.svg)

Sözcük analizcisi tarafından gruplanan karakterler, bulundukları bağlam dahilinde kendi türlerine göre sınıflandırılırlar. Sınıflandırma sonucunda token dediğimiz karakter grupları elde edilmiş olur.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer_step2.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/lexical_analyzer_step2.svg)

Girilen karakterlerden token oluşturma işlemi sırasında; eğer girilen karakter ile eşleşen bir takma isim tanımlandıysa, ilgili karakter grubu "takma isim" tokeni olarak işaretlenir. Bu sayede takma isimlerle aynı adlandırmaya sahip komut ya da fonksiyonlardan önce takma isimlerin çalıştırılması mümkün olur.

Bu sözcüksel analiz aşamasında elbette kabuğun sahip olduğu özellikler dahilinde şablonlara uyan birtakım eşleşmeler aranarak tokenler oluşturulur. Örneğin `-` işareti **seçeneklerin** ayrıt edilebilmesini sağlarken, `/` işaretiyle birlikte `/dosya_adı` şeklinde bir girdi kullanıldıysa, sözcük analizi tarafından **çalıştırılacak dosya adı** ayırt edilip buna göre tokeni oluşturulur. ****Kısacası bash kabuğunun özellikleri dahilinde belirlenmiş olan tanım kalıplarına göre; kabuğa verilen tüm karakterler doğru biçimde türlerine göre gruplanmaya çalışılır. 

### 10.1.3 Ayrıştırıcı: Tokenlerin Basit ve Bileşik Komutlara Ayrılması

Bir ayrıştırıcı, dilbilgisi-gramer ve sözdizimi-sentaks kuralı kontrolcüsü olarak düşünülebilir. Karakter girdilerinden tokenler oluşturulduktan sonra, sözdizimi hatalarını saptamak ve tokenlerin oluşturduğu emir bütününü doğru anlamlandırmak üzere ayrıştırma işlemi uygulanır.

Bu işlem için öncelikle tüm komutu basit ve bileşik komut şeklinde ayrıştırır. Ayrıştırma işlemi için operatörlere bakar. Kontrol operatörlerine göre tüm komutu ayrıştırır.

Yani tokenler halinde sunulan "kelime" "seçenek" ve "argüman" gibi kabuk yapılarının uygun sıralama ile verilip verilmediğini kabuğun sözdizimi kuralları dahilinde kontrol eder. Ayrıştırma aşamasında komutlar "basit" ve "bileşik" komutlara ayrılır. Burada yapılan ayrıştırmaya biraz daha yakından bakacak olursak;

## Basit Komutlar

Basit komutlar; tek bir bağlamda çalışması gereken, genellikle ilk kelimeyle çalıştırılacak komutu belirten ve devamında komutun seçenekleri, argümanları, girdi-çıktı yönlendirmesi bulunan komut bütününün en genel tanımıdır.

Kabuğun gözünden basit komutlar metakarakter ile birbirinden ayrılmış, kabuğun kontrol operatörlerinden biri tarafından sonlandırılan bir sözcük dizisidir. 

Burada bahsi geçen kontrol operatörleri basit komutun sınırını belirtir. Örneğin konsola bir komut girip enter ile yeni satıra geçtiğimizde, basit komutu "yeni satır" ile ayırdığımızı kabuğa bildirmiş oluyoruz. Benzer şekilde örneğin birden fazla basit komutu peşi sıra noktalı virgül ile ayırdığımızda da "kontrol operatörlerini" kullanmış oluyoruz. 

Kontrol operatörleri sayesinde, kabuğa iletilmiş olan kelimelerin kabuk tarafından doğru şekilde anlamlandırılması sağlanabiliyor. Örneğin kontrol operatörü olmadan yani yeni satıra geçmeden ya da herhangi bir metakarakter kullanmadan komutları peşi sıra yazarsak ne olur ? 

Peşi sıra iki tane `echo` komutu kullanarak bu durumu gözlemleyelim.

```bash
~ → echo "ben ilkim" echo "ben ikinciyim"
ben ilkim echo ben ikinciyim
```

Çıktıları incelediğinizde kabuğun ikinci `echo` komutunu çalıştıramadığını görebilirsiniz. Bu durumun nedeni kabuğun ikinci komutu ayırt etmesini sağlayacak olan kontrol operatörünün ilk komutun ardından kullanılmamış olmasıdır. Noktalı virgül kontrol operatörünü kullanarak bu durumu teyit edebiliriz.

```bash
~ → echo "ben ilkim" ; echo "ben ikinciyim"
ben ilkim
ben ikinciyim
```

Ayrıca kontrol operatörleri yalnızca komutların birbirinden ayırt edilmesini de sağlamaz. Kontrol operatörleri komutların hangi koşullara göre değerlendirileceğini de belirtir. Bu sebeple yeni satır veya noktalı virgül haricinde pek çok kontrol operatörü vardır.(Sözlükte yer alan "kontrol operatörleri" açıklamasına göz atın.) Örneğin ampersant `&` işareti bir kendisinden önceki komutun arkaplanda çalıştırılması gerektiğini kabuğa bildiren kontrol operatörüdür. Zaten kitap boyunca yeri geldikçe diğer kontrol operatörlerini de konu dahilinde ele aldık. Örneğin mantıksal operatörler de bu sınıfta sayılıyor. Bu işleyiş sayesinde kabuk kendisine verilen basit komutları doğru şekilde anlamlandırabiliyor. Bizim ele aldığımız örnekte kullandığımız pipe da aslında basit komutun bittiğini belirten özel kontrol operatörüdür. Basit komutu bitirip pipe işaretinden sonraki komuta ilk komutun çıktılarını ulaştırmak gibi özel bir amaca hizmet eder.

Kontrol karakterlerini tıpkı bizlerin kullandığı noktalama işaretleri gibi düşünebilirsiniz. Noktalama işaretleri olmadan yazılan ifadeler karşı tarafa doğru şekilde aktarılamaz. En basitinden bir virgül tüm cümlenin anlamını değiştirmeye muktedir değil mi ?

## Bileşik Komutlar

Bileşik komutlar ise, birden fazla basit komutun uygun şekilde sıralanarak kullanılması olarak tanımlayabiliriz. Pipe kullanımı bu duruma en açık örnektir. Nitekim bizim ele aldığımız bulma sıralama örneğinde bizde iki basit komutu pipe ile sıralı şekilde kullanmış olduk.

Daha karmaşık kabuk komutları, çeşitli şekillerde birlikte düzenlenmiş basit komutlardan oluşur: bir komutun çıktısının bir saniyenin girdisi haline geldiği bir boru hattında, bir döngüde veya koşullu yapıda veya başka bir gruplama da aslında bileşik komut kapsamındadır. Birden fazla komutun özel durumlar için sıralı şekilde arada bulunması bileşik komut dediğimiz yapıyı temsil eder. Her ne kadar bizim örneğimizde pipe kullanılmış olsa da çeşitli rezerve kelimeler ve kontrol operatörleri sayesinde çok çeşitli bileşik komut oluşturulması mümkündür.

Bileşik komutların doğru şekilde çalıştırılabilmesi için öncelikle uygun bölümlerinden özellikleri dahilinde ayrıştırılması gerekiyor.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step1.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step1.svg)

Komutlar uygun şekilde ayrıştırıldıktan sonra;

- Genişletme sırasına uygun olarak kabuk genişletmeleri uygulanır.
- Gerekli yeniden yönlendirmeler gerçekleştirilir.

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step2.svg](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/parser_step2.svg)

Ve en nihayetinde tam olarak hangi şekilde çalıştırılacağı belirlenmiş olan bileşik komut bir sonraki aşama olan "çalıştırma" aşamasına aktarılabilir. Biz işlemleri kolay takip edebilmek adına son derece basit bir komut yapısını ele aldık. Zaten anlatımın başında ele aldığımız örneğin tüm sözcüksel analiz ve ayrıştırma aşamalarını kapsamadığını da belirtmiştik. 

Ayrıştırıcı mekanizması bir sonraki adımda komutların doğru şekilde çalıştırılması için bu ayrıştırmayı yapmak zorundadır. Uygun noktalarda ayrıştırma yapmazsa bir sonraki adım olan "çalıştırma" işlemi kullanıcının gerçekte kastettiği işlemi yerine getiremez. Ayrıştırma işlemini cümlenin anlamsal bütünlüğünü kontrol eden ve gereken kısımlara virgül koyan yapı olarak düşünebilirsiniz. Neticede ayrıştırıcı dediğimiz yapı; elindeki tokenlerden çalıştıracak komutların anlamlı bir tablosu oluşturulur. 

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%201.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%201.png)

- Komutu yürütür (bkz. Komutları Yürütme).

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%202.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%202.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%203.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Untitled%203.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png)

Kabuğa verilen emirin yürütülme süreci genel adımları aşağıdaki gibidir.

- Komut içinde eğik çizgi ile kullanılan bir ifade varsa bu ifade çalıştırılabilir bir dosya olarak görülüp, çalıştırılır. Örneğin "./dosya" ifadesi kabuk tarafından mevcut konumda bulunan çalıştırılabilir dosya olarak ele alınır.  Biz bu kullanım ile doğrudan çalıştırılacak olan dosyayı kabuğa belirtmiş oluyoruz. Eğer komut içinde eğik çizgi yoksa yani doğrudan dosya ismi belirtilmediyse bu ifadenin karşılığını bulmak üzere kabuk arayışa girer.
- Öncelikle bu isimle tanımlı bir fonksiyon var mı diye bakılır. Varsa bu fonksiyon çağırılır.
- Eğer isimle eşleşen bir fonksiyon tanımlı değilse, kabuk bu ifadeyi kabuğun içindeki araçların ismi yani kabuk yerleşikleri içerisinde arar. Eğer eşleşiyorsa kabuk üzerindeki yerleşik araç çalıştırılır.
- İfade, eğik çizgi içermiyorsa, tanımlı fonksiyon değilse ve yerleşik araçlar ile eşleşmediyse PATH olarak isimlendirilen "çalıştırılabilir dosyaları" içeren dizin yolu üzerinde aranır. Eğer eşleşen bir dosya varsa bu dosyayı çalıştırır ve dosyanın ismi ile birlikte dosya yolunu bir tabloya kaydeder. Bu sayede aynı ifade için her defasında tüm PATH yolunu araması gerekmez.
- Eğer ilgili ifade PATH yolu üzerindeki hiç bir dosya ile de eşleşmediyse, tanımlı olması halinde kabuk "command_not_found_handle" isimli fonksiyonu çalıştırır. Komutun tamamı bu fonksiyona argüman olarak verilir. Bu fonksiyon varsayılan olarak tanımlı değildir. Eğer biz istersek tanımlayabiliriz. Bu sayede sistem üzerinde verilen komut bulunamadığın ne yapılması gerektiğini özellikle belirtebilme fırsatımız olur.
- Eğer bu fonksiyon(command_not_found_handle) tanımlı değilse kabuk "komut bulunamadı" hata mesajını yazdırır ve çıkış kodu olarak "127" değerini döndürür.
- İfade ile eşleşen dosya bulunur ancak çalıştırmak için gereken ortam doğru belirlenemezse, ilgili dosya "kabuk betiği-shell script" olarak çalıştırılır.
- Kabuk üzerinden çalıştırılan tüm işlemlerde, işlemler özellikle arkaplanda başlatılmadığı sürece, kabuk işlemin tamamlanmasını bekler ve çıkış durumunu toplar. (bkz. Çıkış Durumu).

Dolayısıyla buradaki anlatımlardan kabuğa verilmiş olan aynı isimli yapıların çalıştırılma sırası aşağıdaki gibidir.

alias > fonksiyon > builtin > external

# Alıntı Mekanizmaları

Alıntı mekanizması isminden de anlaşılacağı üzere ilgili ifadelerin değiştirilmeden olduğu gibi kullanılmasını sağlar. Neticede gerçek hayatta herhangi birinden alıntı yapıldığında hiç bir kelimesi değiştirilemez. Değiştirilirse buna alıntı denilemez. İşte burada bahsi geçen "alıntılama" da bash kabuğunda farklı anlam ifade edebilecek çeşitli karakter ve kelimelerin özel anlamları dışında yalnızca yazıldıkları şekilde yansıtılmasıdır. 

Bash üzerinde geçerli olan üç tür alıntı mekanizması vardır. Bunlar; "kaçış karakteri(ters taksim)" "tek tırnak" ve "çift tırnak" kullanımıdır. Bu mekanizmalar sayesinde kabuk üzerinde özel anlam taşıyan her türlü ifade, değişmeden standart metin ifadesi olarak kullanılabilir. Örnekler üzerinden açıkladığımızda tam olarak neyden bahsettiğimizi kavramış olacaksınız.

### Kaçış Karakteri ( Ters Taksim) `\`

Ters taksim işaretinin hemen ardından yazılan karakter, bash kabuğunda özel anlama sahip olsa bile standart şekilde işlenir. Zaten bu sebeple bu işarete kaçış karakteri de denmektedir. Kendisinden sonra gelen karakter özelliklerinin bash kabuğu tarafından görmezden gelinmesini sağlar. Bu durumu gözlemlemek için aşağıdaki çıktılara göz atabilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $degisken
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo \$degisken
$degisken
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Gördüğünüz gibi kaçış karakteri(ters taksim `\`) değişken değerinin çağırılmasını sağlayan dolar işaretinin işlevini görmezden gelerek olduğu gibi bastırmış oldu.

Hatta bu örnekler dışında, örneğin konsola komut girerken eğer komutun sonuna ters taksim işareti ekleyip enter tuşuna basarsanız varsayılan olarak yeni satıra geçme özelliğinden dahi kaçmış olursunuz. Normal şartlarda konsola(terminal aracına) herhangi bir komut girip enter tuşuna bastığımızda "newline" olarak geçen özellik gereği komutumuz kabuğa iletilir ve konsolda yeni bir satıra geçiş yaparız. Komutumuzun sonuna ters taksim işareti ekleyince bu özellikten kaçındığımız için konsol bizden komut almak üzere bir alt satıra geçip bekliyor. Bu özellik genel olarak uzun komutların çok daha okunaklı şekilde verilebilmesi için kullanılıyor.

Not: Elbette kaçış karakteri, diğer alıntılama karakteri yani tek veya çift tırnak içerisinde yazıldığında kendi özelliğini yitirerek standart bir karakter olarak işlenir. 

```bash
taylan@DESKTOP-E4TGC85:~$ echo \"
"
taylan@DESKTOP-E4TGC85:~$ echo "\""
"
taylan@DESKTOP-E4TGC85:~$ echo '\"'
\"
taylan@DESKTOP-E4TGC85:~$
```

## Tek Tırnak Kullanımı

Kabuğun herhangi bir özel karakteri yorumlamasını önlemek için metnin etrafında tek tırnak işaretleri kullanılabilir. Dolar işaretleri, boşluklar, ve işaretleri, yıldız işaretleri ve diğer özel karakterler tek tırnak içine alındığında göz ardı edilir. Aşağıdaki örnek bu durumu kanıtlar niteliktedir.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ | '
Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ |
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

İstisnai olarak tek tırnak içerisinde kullanamayacağımız tek özel karakter tek tırnaktır.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnak bas: ' '
>
> ^C
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnak bas: '' '
Tek tırnak bas:
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

## Çift Tırnak Kullanımı

Çift tırnaklar, tek tırnaklara benzer şekilde hareket eder, ancak çift tırnaklar kabuğun dolar işaretlerinin, ters tırnakların, kaçış karakterinin ve geçmiş genişletme aktifse ünlem işaretinin yorumlamasına izin verir. Yine de kabuk ortamında posix modu aktifse geçmiş genişletme aktif olsa dahi ünlem işaretini özel anlamında kullanılmaz.

Dolar işareti ve ters tırnak özel anlamlarını çift tırnak içinde korurlar. Yani bu iki karakter için kabuk genişletmeleri çift tırnak içerisinde uygulanır;

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$(echo $BASH_SUBSHELL)"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$(echo $BASH_SUBSHELL)"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$degisken"
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "`echo $BASH_SUBSHELL`"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Kaçış karakteri ise dolar işareti, ters tırnak, çift tırnak ya da newline olarak geçen yeni satıra geçme karakterlerinden kaçmayı sağlar. Zaten bu karakterler dışındaki hiç bir karakter çift tırnak içerisinde özel anlamlarına genişletilmez. Çift tırnak içerisinde özel anlamlarına genişletilen karakterleri standart karakterler olarak bastırmak istediğimizde kaçış karakterini kullanabiliriz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$degisken"
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "\$degisken"
$degisken
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Geçmiş özelliğinin aktif olması halinde çift tırnak içinde bu ünlem işareti ile geçmişten komut getirebiliriz. 

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ set -o histexpand
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ pwd
/home/taylan
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "!!"
echo "pwd"
pwd
```

Ancak daha önce de belirttiğimiz şekilde eğer geçmiş özelliğiyle birlikte posix ortam özelliği de aktifse bu kez ünlem işaretleri özel anlamını kaybeder.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ set -o posix
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ pwd
/home/taylan
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "!!"
!!
```

Ayrıca * ve @ işaretleri çift tırnak içinde kabuk parametre genişletmesine de uğrarlar. Örneğin dizi elemanlarını çağırmak üzere kullanıldıklarında çift tırnak içinde dizi elemanlarını çağırırlar. 

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ dizi=(eleman1 eleman2 eleman3)
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo ${dizi[*]}
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "${dizi[*]}"
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "${dizi[@]}"
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo '${dizi[@]}'
${dizi[@]}
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Tüm bahsi geçen alıntı karakterlerinin kullanımına dair örnek bir tablo;

```bash
# | Expression  | Result      | Comments
---+-------------+-------------+--------------------------------------------------------------------
 1 | "$a"        | apple       | variables are expanded inside ""
 2 | '$a'        | $a          | variables are not expanded inside ''
 3 | "'$a'"      | 'apple'     | '' has no special meaning inside ""
 4 | '"$a"'      | "$a"        | "" is treated literally inside ''
 5 | '\''        | **invalid** | can not escape a ' within ''; use "'" or $'\'' (ANSI-C quoting)
 6 | "red$arocks"| red         | $arocks does not expand $a; use ${a}rocks to preserve $a
 7 | "redapple$" | redapple$   | $ followed by no variable name evaluates to $
 8 | '\"'        | \"          | \ has no special meaning inside ''
 9 | "\'"        | \'          | \' is interpreted inside "" but has no significance for '
10 | "\""        | "           | \" is interpreted inside ""
11 | "*"         | *           | glob does not work inside "" or ''
12 | "\t\n"      | \t\n        | \t and \n have no special meaning inside "" or ''; use ANSI-C quoting
13 | "`echo hi`" | hi          | `` and $() are evaluated inside ""
14 | '`echo hi`' | `echo hi`   | `` and $() are not evaluated inside ''
15 | '${arr[0]}' | ${arr[0]}   | array access not possible inside ''
16 | "${arr[0]}" | apple       | array access works inside ""
17 | $'$a\''     | $a'         | single quotes can be escaped inside ANSI-C quoting
18 | "$'\t'"     | $'\t'       | ANSI-C quoting is not interpreted inside ""
19 | '!cmd'      | !cmd        | history expansion character '!' is ignored inside ''
20 | "!cmd"      | cmd args    | expands to the most recent command matching "cmd"
21 | $'!cmd'     | !cmd        | history expansion character '!' is ignored inside ANSI-C quotes
---+-------------+-------------+--------------------------------------------------------------------
```

## ANSI-C

ANSI-C adında farklı bir alıntı türü de mevcut. Bu alıntı türünde dolar işaretinden sonra tek tırnak içinde kaçış karakteri kullanılarak yazılan birtakım ifadelerin özel anlamları vardır. 

```bash
\a
alert (bell)

\b
backspace

\e
\E
an escape character (not ANSI C)

\f
form feed

\n
newline

\r
carriage return

\t
horizontal tab

\v
vertical tab

\\
backslash

\'
single quote

\"
double quote

\?
question mark

\nnn
the eight-bit character whose value is the octal value nnn (one to three octal digits)

\xHH
the eight-bit character whose value is the hexadecimal value HH (one or two hex digits)

\uHHHH
the Unicode (ISO/IEC 10646) character whose value is the hexadecimal value HHHH (one to four hex digits)

\UHHHHHHHH
the Unicode (ISO/IEC 10646) character whose value is the hexadecimal value HHHHHHHH (one to eight hex digits)

\cx
a control-x character
```

Kullanım örneği için aşağıdaki çıktıları inceleyebilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $'a\nb'
a
b
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $"a\nb"
a\nb
```

## Yerel Ayara Özgü Çeviri (Locale-Specific Translation)

[https://unix.stackexchange.com/a/334765/364572](https://unix.stackexchange.com/a/334765/364572)

# Yerelleştirme

Yerelleştirme, belgelenmemiş bir Bash özelliğidir.

Yerelleştirilmiş bir kabuk betiği, metin çıktısını sistemin yerel ayarı olarak tanımlanan dilde yansıtır. Almanya, Berlin'deki bir Linux kullanıcısı, komut dosyası çıktısını Almanca olarak alırken, Berlin, Maryland'deki kuzeni aynı komut dosyasından İngilizce çıktı alırdı.

Yerelleştirilmiş bir komut dosyası oluşturmak için, kullanıcıya tüm mesajları (hata mesajları, istemler vb.) Yazmak için aşağıdaki şablonu kullanın.

Önünde dolar işareti ('$') bulunan çift tırnaklı bir dize, dizenin geçerli yerel ayara göre çevrilmesine neden olur. Gettext altyapısı, aşağıda açıklandığı gibi LC_MESSAGES ve TEXTDOMAIN kabuk değişkenlerini kullanarak mesaj kataloğu aramasını ve çevirisini gerçekleştirir. Ek ayrıntılar için gettext belgelerine bakın. Geçerli yerel ayar C veya POSIX ise veya mevcut çeviri yoksa, dolar işareti yok sayılır.

[http://mywiki.wooledge.org/BashFAQ/098](http://mywiki.wooledge.org/BashFAQ/098)

[https://www.linuxjournal.com/content/internationalizing-those-bash-scripts](https://www.linuxjournal.com/content/internationalizing-those-bash-scripts)

[https://tldp.org/LDP/abs/html/localization.html](https://tldp.org/LDP/abs/html/localization.html)

## Yorum Alanı

Etkileşimli olmayan bir kabukta veya yerleşik interactive_commentsseçeneğin shoptetkinleştirildiği etkileşimli bir kabukta (bkz . Shopt Yerleşik ), 'ile başlayan bir kelime#'bu kelimenin ve o satırdaki kalan tüm karakterlerin yok sayılmasına neden olur. interactive_comments Seçeneğin etkinleştirilmediği etkileşimli bir kabuk yorumlara izin vermez. interactive_comments Seçenek etkileşimli kabuklarda öntanımlı olarak açıktır. Bir kabuğu neyin etkileşimli kıldığının açıklaması için Etkileşimli Kabuklar'a bakın .