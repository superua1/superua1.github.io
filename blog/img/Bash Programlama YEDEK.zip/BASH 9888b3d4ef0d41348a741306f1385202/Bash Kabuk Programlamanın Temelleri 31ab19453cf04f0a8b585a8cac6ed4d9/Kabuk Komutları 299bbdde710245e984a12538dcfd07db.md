# Kabuk Komutları

Kabuğa verdiğimiz komutların da elbette kendi içinde türleri bulunuyor. En geniş tanım ile kabuk üzerinde basit ve bileşik olmak üzere iki komut türü olduğunu söyleyebiliriz.

# Basit Komutlar

Basit olarak ithaf ettiğimiz komutlar, en sık karşılaştığımız komut türüdür. Basit komutlar boşluklarla ayrılmış, kabuğun kontrol operatörlerinden biri tarafından sonlandırılan bir sözcük dizisidir. İlk kelime genellikle çalıştırılacak bir komutu belirtir, geri kalan kelimeler o komutun argümanlarıdır. 

Burada bahsi geçen kontrol operatörleri basit komutun sınırını belirtir. Örneğin konsola bir komut girip enter ile yeni satıra geçtiğimizde, basit komutu "yeni satır" ile ayırdığımızı kabuğa bildirmiş oluyoruz. Benzer şekilde birden fazla basit komutu peşi sıra noktalı virgül ile ayırdığımızda da "kontrol operatörlerini" kullanmış oluyoruz. 

Kontrol operatörleri sayesinde, kabuğa iletilmiş olan kelimelerin kabuk tarafından doğru şekilde anlamlandırılması sağlanabiliyor. Örneğin kontrol operatörü olmadan yani yeni satıra geçmeden ya da herhangi bir metakarakter kullanmadan komutları peşi sıra yazarsak ne olur ? 

Peşi sıra iki tane `echo` komutu kullanarak bu durumu gözlemleyelim.

```bash
~ → echo "ben ilkim" echo "ben ikinciyim"
ben ilkim echo ben ikinciyim
```

Çıktıları incelediğinizde kabuğun ikinci `echo` komutunu çalıştıramadığını görebilirsiniz. Bu durumun nedeni kabuğun ikinci komutu ayırt etmesini sağlayacak olan kontrol operatörünün ilk komutun ardından kullanılmamış olmasıdır. Noktalı virgül kontrol operatörünü kullanarak bu durumu teyit edebiliriz.

```bash
~ → echo "ben ilkim" ; echo "ben ikinciyim"
ben ilkim
ben ikinciyim
```

Ayrıca kontrol operatörleri yalnızca komutların birbirinden ayırt edilmesini de sağlamaz. Kontrol operatörleri komutların hangi koşullara göre değerlendirileceğini de belirtir. Bu sebeple yeni satır veya noktalı virgül haricinde pek çok kontrol operatörü vardır. Örneğin ampersant `&` işareti bir sonraki komutun arkaplanda çalıştırılması gerektiğini kabuğa bildiren kontrol operatörüdür. Zaten kitap boyunca yeri geldikçe diğer kontrol operatörlerini de konu dahilinde ele alıyoruz. Örneğin mantıksal operatörler de bu sınıfta sayılıyor. Bu işleyiş sayesinde kabuk kendisine verilen basit komutları doğru şekilde anlamlandırabiliyor. Kontrol karakterlerini tıpkı bizlerin kullandığı noktalama işaretleri gibi düşünebilirsiniz. Noktalama işaretleri olmadan yazılan ifadeler karşı tarafa doğru şekilde aktarılamaz. En basitinden bir virgül tüm cümlenin anlamını değiştirmeye muktedir değil mi ?

## Bileşik Komutlar

Basit komutların bir arada kullanılmasıyla ortaya çıkan komutlardır.

## Ayrılmış Kelimeler

Kabuk için özel anlam ifade eden sözcüklerdir. Bu sözcükleri bileşik komutları başlatmak ve bitirmek için yani bileşik komutların sınırlarını belirtmek için kullanıyoruz. Kabuk üzerinde tanımlı olan ayrılmış kelimelerin tamamına `compgen -k` komutu ile ulaşabiliriz. Ayrılmış kelimeler; "if", "then", "else", "elif", "fi", "case", "esac", "for", "select", "while", "until", "do", "done", "in", "function", "time", "{", "}", "!", "[[", "]]", "coproc",

## Boru Hattı | Pipelines

Pipeline olarak geçen boru hattı kullanımı birden fazla süreç arasında iletişimi mümkün kılan yapıdır. Boru hattı oluşturmak için '`|`' ya da '`|&`' kontrol operatörlerinden birisi kullanılır. Kabuk bu operatörlerinden birini gördüğünde, operatörün devamında yer alan komutları ayrı süreç içerisinde çalıştırır. Ve ayrıca operatörün solunda yer alan komutların çıktılarını da sağ taraftaki işleme aktarır. Bu sayede ilk komutun ürettiği çıktıları ayrı bir süreç olan ikinci komut tarafından tekrar işlenebilir olur. Bu özellik kabuğun en güçlü yanıdır. Bu yöntemle birden fazla aracı bir arada kullanıp karmaşık sorunlara kolay çözümler üretebiliriz. 

Yalnızca pipe yani düz çubuk kullanılırsa `|` ilk işlemin yalnızca hatasız çıktıları ikinci işleme aktarılır.

Eğer ampersant işareti ile yani `|&` şeklinde kullanılırsa da hem hatalı hem de hatasız çıktılar ikinci işleme aktarılır. 

Bu konunun detaylarına "Yönlendirmeler" konusunun ardından uzun uzadıya değiniyor olacağız.

## Komut Listesi

Komutları peşi sıra çalıştırmak istediğimizde bunları listeleyebiliyoruz. Listeleme işlemi için ‘;’, ‘&’, ‘&&’, ‘||’ sembolleri kullanılabiliyor.

Noktalı virgül: Noktalı virgül kullanımında sıralanmış olan tüm komutlar soldan sağa doğru tek tek sırası ile çalıştırılır. Bir komutun çalışması bitmeden diğeri çalıştırılmaz.

Ampersant işareti: Bu işaret ilgili komutun arkaplanda çalıştırılmasını sağlar. 

Ve mantıksal operatörü: && işaretinin solunda yer alan işlem başarılı olursa yani çıkış kodu 0 olursa sağdaki işlem çalıştırılır. 

Veya mantıksal operatörü: || işaretinin solunda yer alan işlem başarısız olduğunda yani 0 dan farklı bir çıkış kodu döndürdüğünde sağ taraftaki işlem çalıştırılır. 

Hepsinin bir arada kullanıldığı bir komut listesinde kabuğun yorumlama sıralaması şu şekildedir.

"&&" = "||" > ";" = "&"

Yani "&&" ve "||" eşit önceliğe sahiptir ve ilk olarak yorumlanır, ardından eşit önceliğe sahip ";" ve "&" gelir. Çünkü koşullu durumların yapısı gereği belki ikinci bölüm çalıştırılmayacağı için hiç yorumlanması gerekmeyebilir.

Örneğin ilk komut hatalı ise ikincisinin çalıştırılacağı durumda ilk komut hatasızsa ikinci komuta bakılması gerekmez.

## Bileşik Komutlar

Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sona erdirilir. Bileşik bir komutla ilişkili tüm yeniden yönlendirmeler (bkz. Yeniden Yönlendirmeler), açıkça geçersiz kılınmadığı sürece bu bileşik komut içindeki tüm komutlar için geçerlidir. Çoğu durumda, bir bileşik komutun açıklamasındaki bir komut listesi, komutun geri kalanından bir veya daha fazla yeni satırla ayrılabilir ve ardından noktalı virgül yerine yeni bir satır gelebilir. Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve mekanizmalar sağlar.

- Döngüsel yapılar
    - until
    - while
    - for
- Koşullu yapılar
    - if
    - case
    - select
    - ((…))
    - [[…]]
- Komut gruplama
    - ()
    - {}

## Komut Gruplama

Bash, bir birim olarak yürütülecek komutların bir listesini gruplamak için iki yol sağlar. Komutlar gruplandığında, yönlendirmeler tüm komut listesine uygulanabilir. Örneğin, listedeki tüm komutların çıktısı tek bir akışa yönlendirilebilir.

### **`()`**

```jsx
( *list* )
```

Parantezler arasına bir komut listesi yerleştirmek, bir alt kabuk ortamının oluşturulmasına (bkz. Komut Yürütme Ortamı) ve listedeki komutların her birinin o alt kabukta çalıştırılmasına neden olur. Liste bir alt kabukta yürütüldüğünden, değişken atamaları alt kabuk tamamlandıktan sonra etkin kalmaz.

### **`{}`**

```jsx
{ *list*; }
```

Küme ayraçları arasına bir komut listesi yerleştirmek, listenin geçerli kabuk bağlamında çalıştırılmasına neden olur. Alt kabuk oluşturulmaz. Aşağıdaki liste noktalı virgül (veya yeni satır) gereklidir.

Bir alt kabuğun yaratılmasına ek olarak, bu iki yapı arasında tarihsel nedenlerden dolayı ince bir fark vardır. Kaşlı ayraçlar ayrılmış sözcüklerdir, bu nedenle listeden boşluklarla veya diğer kabuk metakarakterleriyle ayrılmalıdırlar. Parantezler operatörlerdir ve listeden boşluklarla ayrılmasalar bile kabuk tarafından ayrı simgeler olarak tanınırlar. Bu yapıların her ikisinin de çıkış durumu, listenin çıkış durumudur.

## Yardımcı İşlemler | Coprocesses

Coproc ayrılmış kelimesi herhangi bir işlemi arkaplanda başlatıp bu işlem ile pipe ataması yapmadan veri alışverişinde bulunabildiğimiz özelliktir. Bu özellik bash kabuğuna 4.0 sürümle birlikte eklenmiştir. 

Pipe işleminde süreçler arasında tek yönlü veri aktarımı olduğunu biliyorsunuz.   Coproc ile mevcut kabuğa iki pipe ile bağlı olan bir alt işlem oluşturulabiliyor. Bu sayede kabuk üzerinden başlatılan herhangi bir işlem bu alt işlem ile hem veri okuma hem de veri gönderme noktasında iletişim kurabiliyor. Yani aslında mevcut kabuk için "ortak işlem" oluşturulmuş oluyor. Elbette ortak işlem arkaplanda yürütülüyor. 

İlk komut basit komutlar durumunda kullanılır. Komuta ad verilmemelidir çünkü basit komut durumunda, basit komutun ilk kelimesi olarak yorumlanır. Bileşik komutlar durumunda, ikinci komut kullanılır. Ad belirtilmezse, COPROC varsayılan olarak "ad" dır. Yardımcı işlem yürütüldüğünde, çalıştırılan kabuğun bağlamında 'ad' adında bir dizi oluşturulur (ad komutta sağlanmadıysa varsayılan olarak COPROC). Bu dizinin ilk elemanı çıkış tanımlayıcısı iken, dizinin ikinci elemanı ortak işlemin giriş tanımlayıcısıdır. Yürütme kabuğu ve ortak işlem arasında çift yönlü bir boru oluşturulur. Bash, bu borular için dosya tanımlayıcılarını diziye koyar:

isim [0], yürütme kabuğundaki ortak işlemin standart çıktısına bağlanan borunun dosya tanımlayıcısıdır. 

isim [1], yürütme kabuğundaki ortak işlemin standart girişine bağlanan borunun dosya tanımlayıcısıdır. 

Bu kanallar, komut tarafından herhangi bir yeniden yönlendirme yapılmadan önce oluşturulur. Bu dosya tanımlayıcıları, standart sözcük genişletmeleri kullanılarak kabuk komutları ve yeniden yönlendirmeler için bağımsız değişkenler olarak kullanılabilir. Name_PID değişkeni, işlem kimlik numarasını depolar. Wait yerleşik komutu, ortak işlemin yürütülmesini tamamlamasını beklemek için kullanılabilir. Coproc komutu, zaman uyumsuz bir komut olarak oluşturulduğu için her zaman başarı döndürür. Bir ortak işlemin dönüş durumu, komutun çıkış durumuyla aynıdır.