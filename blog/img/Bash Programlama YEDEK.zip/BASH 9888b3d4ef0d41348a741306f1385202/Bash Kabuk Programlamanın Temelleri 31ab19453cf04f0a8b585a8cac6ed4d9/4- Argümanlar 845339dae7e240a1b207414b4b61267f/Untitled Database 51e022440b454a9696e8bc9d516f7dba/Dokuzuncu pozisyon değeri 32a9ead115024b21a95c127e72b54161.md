# Dokuzuncu pozisyon değeri.

Değer: 9