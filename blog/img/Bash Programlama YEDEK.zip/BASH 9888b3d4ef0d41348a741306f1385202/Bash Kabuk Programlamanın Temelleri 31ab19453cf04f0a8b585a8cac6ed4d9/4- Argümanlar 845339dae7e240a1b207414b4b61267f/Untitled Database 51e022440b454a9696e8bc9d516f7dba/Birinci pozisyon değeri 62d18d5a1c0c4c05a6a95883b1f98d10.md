# Birinci pozisyon değeri.

Değer: 1