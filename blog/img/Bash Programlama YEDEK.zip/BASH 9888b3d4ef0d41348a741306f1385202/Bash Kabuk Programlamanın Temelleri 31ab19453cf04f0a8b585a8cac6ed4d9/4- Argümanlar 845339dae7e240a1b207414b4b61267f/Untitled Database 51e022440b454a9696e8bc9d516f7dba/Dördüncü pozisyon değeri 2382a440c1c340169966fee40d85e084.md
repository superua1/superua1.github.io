# Dördüncü pozisyon değeri.

Değer: 4