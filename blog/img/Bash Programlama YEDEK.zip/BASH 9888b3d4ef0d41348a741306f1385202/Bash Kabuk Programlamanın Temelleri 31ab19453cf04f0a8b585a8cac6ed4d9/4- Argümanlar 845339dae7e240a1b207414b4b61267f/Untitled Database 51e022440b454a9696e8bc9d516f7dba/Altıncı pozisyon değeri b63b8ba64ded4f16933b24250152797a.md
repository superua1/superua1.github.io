# Altıncı pozisyon değeri.

Değer: 6