# İkinci pozisyon değeri.

Değer: 2