# Beşinci pozisyon değeri.

Değer: 5