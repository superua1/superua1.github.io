# Yedinci pozisyon değeri.

Değer: 7