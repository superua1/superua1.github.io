# Üçüncü pozisyon değeri.

Değer: 3