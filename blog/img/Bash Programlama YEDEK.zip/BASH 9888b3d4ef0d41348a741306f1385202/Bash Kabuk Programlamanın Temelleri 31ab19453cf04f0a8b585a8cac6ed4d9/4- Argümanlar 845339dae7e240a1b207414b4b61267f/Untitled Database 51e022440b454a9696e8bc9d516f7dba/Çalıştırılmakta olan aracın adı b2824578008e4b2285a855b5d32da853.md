# Çalıştırılmakta olan aracın adı.

Değer: 0