# Sekizinci pozisyon değeri.

Değer: 8