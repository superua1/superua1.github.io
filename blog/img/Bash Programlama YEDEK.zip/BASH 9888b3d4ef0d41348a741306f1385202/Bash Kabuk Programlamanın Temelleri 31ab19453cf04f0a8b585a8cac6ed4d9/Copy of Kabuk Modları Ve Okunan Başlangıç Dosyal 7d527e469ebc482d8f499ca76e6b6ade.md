# Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları

Bash kabuğunun bizlere çalışma ortamı sunan bir araç olduğu biliyoruz. Bash kabuğu pek çok ihtiyaca uygun bir çalışma ortamı sunabilmek için kendi içinde pek çok seçeneği de barındırıyor. Yani bash kabuğunun başlatılma şekli, çalışacağımız kabuk ortamının nasıl olacağını belirliyor. Bash kabuğunu çağırırken kullanabileceğimiz pek çok seçenek var ancak şimdi bu seçenekleri açıklamayacağız. Seçeneklerin işlevlerinin daha net anlaşılabilmesi için daha öncesinde birkaç temel husustan bahsetmemiz gerekiyor. Bu sayede tüm yapıya çok daha geniş bir çerçeveden bakabiliyor olacağız. 

Bash kabuğunu çağırırken kullanabileceğiniz seçenekleri görmek isterseniz `bash —help` komutunu kullanabilirsiniz. Bash kabuğunun sunduğu ortam pek çok farklı kullanım seçeneği ile özelleştirilebilir olsa da temelde bash kabuğu; "etkileşimli" "etkileşimsiz" "oturum açma" "oturum açma olmayan" olmak üzere 4 kullanım modu sunuyor. Bu modlar kullanım amaçları doğrultusunda birtakım konfigürasyon dosyalarının okunmasının yanında ayrıca çeşitli kabuk özellikleri aktif veya kapalı olacak bir kabuk ortamı da sunarlar. 

Öncelikle türlerin genel açıklamalarını yapıp daha sonra ayrıntılarına değinebiliriz;

- **Etkileşimli kabuk**, kabuk ile konsol aracılığı ile etkileşim kurarak emirler verdiğimiz ve emirlerin sonuçlarını tekrar konsolda görüntüleyebildiğim kullanım modudur. Bu mod isminden de anlaşılacağı üzere aktif olarak bizim yani kullanıcının etkileşiminin olduğu durumu karşılar.
- **Etkileşimsiz kabuk**, betik dosyalarının çalıştırılması gibi kullanıcıdan emir beklemek yerine dosyadan okunup emirlerin yerine getirildiği moddur.
- **Oturum açma kabuğu**, komut satırı arayüzü ile oturum açtıktan hemen sonra çalıştırılan kabuktur. Komut satırı arayüzü ile çalışmaya uygun bir ortam sunmak için gerekli olan konfigürasyonları içerir.
- **Oturum açma olmayan kabuk**, oturum açtıktan sonra kullanıcı tarafından çalıştırılan veya oturum açmış bir kullanıcıya bağlı olmayan herhangi bir otomatik işlem tarafından çalıştırılan diğer kabuklarıdır.

## Etkileşimli Kabuk

Tanım sırasında etkileşimli kabuğun, anlık olarak kabuğa emirler verdiğimiz ve sonucunda konsolda sonuçlarını gördüğümüz şeklinde tanımladık. Ancak hepsi bundan ibaret değil. 

Örneğin bir kabuk etkileşimli olarak başlatılmadan yani örneğin betik dosyası içinde `read` komutu ile gerektiğinde kullanıcıdan veri alabilir. Bu durum betik dosyasının çalıştırıldığı etkileşimsiz kabuğu etkileşimli mi yapar ? Elbette hayır. Bir kabuğun etkileşimsiz olması demek o kabuğun kullanıcı ile hiç bir etkileşim kurmayacağı anlamına gelmiyor. Etkileşimli kabuğun esas önemi, etkileşimli kullanımda ihtiyaç duyulacak çalışma ortamı için kabuğu uygun özelliklerle donatıyor olmasıdır. 

Etkileşimli kabukta, anlık olarak emir verirken ve sistemi yönetirken işlerimizi kolaylaştıracak birtakım özellikler varsayılan olarak aktif gelir. 

Dolayısıyla etkileşimsiz bir kabuğu da gerekli ayarlamayı yaparak etkileşimli kabuktaki ortamı sunmasını sağlayabiliriz. Kabuğun temel modları sunmasındaki amaç, kullanım amacına uygun önceden ayarlanmış kabuk çalışma ortamının sağlanabilmesidir.

Modların sahip olduğu özellikler kabuk üzerinde varsayılan olarak tanımlanmıştır. Dilerseniz kabuğun kaynak kodlarını temin edip "***shell.c***" dosyası içinde kabuk modlarına göre hangi özelliklerin aktif hangilerinin deaktif olduğu gibi pek çok varsayılan detaya ulaşabilirsiniz. 

[https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell](https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell)

Kabuk etkileşimli olarak çalıştığında, davranışını çeşitli şekillerde değiştirir.

1. Kabuk başlangıcında okunan dosyalar başlığı alıntıda açıklanan dosyalar okunur.
2. İş Kontrolü varsayılan olarak etkindir. İş denetimi etkin olduğunda, Bash, klavye tarafından oluşturulan iş denetim sinyallerini SIGTTIN, SIGTTOU ve SIGTSTP'yi yok sayar.
3. Bash expands and displays `PS1` before reading the first line of a command, and expands and displays `PS2` before reading the second and subsequent lines of a multi-line command. Bash expands and displays `PS0` after it reads a command but before executing it. See [Controlling the Prompt](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html), for a complete list of prompt string escape sequences.
4. Bash executes the values of the set elements of the `PROMPT_COMMAND` array variable as commands before printing the primary prompt, `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
5. Readline (see [Command Line Editing](https://www.gnu.org/software/bash/manual/html_node/Command-Line-Editing.html)) is used to read commands from the user’s terminal.
6. Bash inspects the value of the `ignoreeof` option to `set -o` instead of exiting immediately when it receives an `EOF` on its standard input when reading a command (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
7. Command history (see [Bash History Facilities](https://www.gnu.org/software/bash/manual/html_node/Bash-History-Facilities.html)) and history expansion (see [History Interaction](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html)) are enabled by default. Bash will save the command history to the file named by `$HISTFILE` when a shell with history enabled exits.
8. Alias expansion (see [Aliases](https://www.gnu.org/software/bash/manual/html_node/Aliases.html)) is performed by default.
9. In the absence of any traps, Bash ignores `SIGTERM` (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
10. In the absence of any traps, `SIGINT` is caught and handled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)). `SIGINT` will interrupt some shell builtins.
11. An interactive login shell sends a `SIGHUP` to all jobs on exit if the `huponexit` shell option has been enabled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
12. The  invocation option is ignored, and ‘’ has no effect (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    - n
    
    set -n
    
13. Bash will check for mail periodically, depending on the values of the `MAIL`, `MAILPATH`, and `MAILCHECK` shell variables (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
14. Expansion errors due to references to unbound shell variables after ‘’ has been enabled will not cause the shell to exit (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    
    set -u
    
15. The shell will not exit on expansion errors caused by  being unset or null in `${*var*:?*word*}` expansions (see [Shell Parameter Expansion](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html)).
    
    *var*
    
16. Redirection errors encountered by shell builtins will not cause the shell to exit.
17. When running in  mode, a special builtin returning an error status will not cause the shell to exit (see [Bash POSIX Mode](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html)).
    
    POSIX
    
18. A failed `exec` will not cause the shell to exit (see [Bourne Shell Builtins](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html)).
19. Parser syntax errors will not cause the shell to exit.
20. Simple spelling correction for directory arguments to the `cd` builtin is enabled by default (see the description of the `cdspell` option to the `shopt` builtin in [The Shopt Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html)).
21. The shell will check the value of the `TMOUT` variable and exit if a command is not read within the specified number of seconds after printing `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).

Sizlerin de teyit edebileceği gibi tüm özellikler, konsol üzerinden anlık olarak sistemi yönetirken kullanıcının işlerini kolaylaştırma üzerinedir. 

Bash kabuğunun, ihtiyaçlar doğrultusunda kullanılabilecek 4 temel modu bulunuyor. Elbette her bir 

Bash kabuğu başlatılırken, çalıştırılacağı moda göre birtakım dosyalardan konfigürasyon ayarlarını okur. Çalıştırılan kabuk modunun ve dolayısıyla hangi modda hangi dosyaların okunduğunun bilinmesi, üzerinde çalışılacak kabuk ortamının doğru şekilde ayarlanabilmesi adına son derece önemlidir. Bizler de kabuk modlarını ve modlara göre okunan konfigürasyon dosyalarını daha etkili kullanabilmek adına genel olarak el alıyor olacağız. 

Temelde kabuk "etkileşimli" ve "oturum açma" olmak üzere iki moda sahiptir. 

Yine de bu modların kombinasyonu ile bash kabuğu "etkileşimli" "etkileşimsiz" "oturum açma" "oturum açma olmayan" olmak üzere 4 temel kullanım modu sunuyor. Bu modlar kullanım amaçları doğrultusunda birtakım konfigürasyon dosyalarının okunmasının yanında ayrıca çeşitli kabuk özellikleri aktif veya kapalı olacak bir kabuk ortamı da sunarlar. 

[https://linuxhandbook.com/login-shell/](https://linuxhandbook.com/login-shell/)

[https://notes.shichao.io/apue/ch9/](https://notes.shichao.io/apue/ch9/)

## 

Bu bölümde özellikle sistem yönetiminde kabuğun etkili kullanımı için doğru konfigürasyonların doğru dosyada tanımlanması adına son derece önemli hususlara değiniyor olacağız. Bölüm sonunda konfigürasyon ayarlarınızı daha bilinçli şekilde gerçekleştirebileceğinize inanıyorum.

# Giriş Kabuğu

Giriş kabuğunun doğru biçimde anlaşılabilmesi için hangi durumda ve ne şekilde karşımıza çıktığına değinmemiz gerekiyor. Tüm kavramların kolay anlaşılabilmesi için çok kısaca ve detaysız şekilde sistemin açılmasından bash giriş kabuğunun başlatılmasına kadar geçen aşamaları ele alacağız. Bu işleyişin, kullanmakta olduğunuz sistemin konfigürasyonuna göre farklılık gösterebileceğini dikkate alarak okumanız gerektiğini de baştan belirteyim. Biz sadece temel işleyiş hakkında kafamızda soru işareti kalmaması için istisnaları gözardı ederek genel işleyişten bahsediyor olacağız. 

Temelde, grafiksel ve komut satırı olmak üzere iki ayrı kullanıcı arayüzüne sahip olduğumuzu biliyoruz. Sahip olduğumuz sistemin hangi arayüz ortamı ile açıldığına bağlı olarak sistemin başlangıçta çalıştıracağı işlemler ve okuyacağı konfigürasyon dosyaları elbette değişik gösteriyor. Yine de sistemin açılışını ortak şekilde aşağıdaki şekilde genelleyebiliriz;

1. **BIOS** : Bios un donanım kontrolü yapıp, işletim sistemini yükleyeceği bilgilere ulaşması.
2. **MBR** : İşletim sistemini yükleyecek olan bootstrap programının bulunup çalıştrılması.
3. **GRUB** : Bootstrap programının işletim sistemi çekirdeğini yüklemesi.
4. **KERNEL** : Linux çekirdeğinin çalışması ve init process nin başlatılması.
5. **INIT** : Init process inin çalışması.
6. **RUNLEVEL** : Init process inin gerekli servis ve işlemleri başlatması.

Tüm bu aşamalardan sonra sistemimiz, daha önce tanımlandığı şekilde grafiksel ya da komut satırı arayüzü için gerekli olan işlemleri çalıştırır.

Öncelikle, sistemimizin komut satırı arayüzü ile açıldığını varsayarsak, tty konsolu üzerinden oturum açmamız beklenecektir. Şimdi kısaca bu oturum açma aşamasına değinelim.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled.png)

[https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1](https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1)

[https://unix.stackexchange.com/questions/38175/difference-between-login-shell-and-non-login-shell/46856#46856](https://unix.stackexchange.com/questions/38175/difference-between-login-shell-and-non-login-shell/46856#46856)

[https://learning.lpi.org/en/learning-materials/102-500/105/105.1/105.1_01/](https://learning.lpi.org/en/learning-materials/102-500/105/105.1/105.1_01/)

### Komut Satırı Arayüzünde Oturum Açmak ve Kabuğun Çağırılması

Init daha önce ilgili konfigürasyon dosyalarında tanımlanmış olan aktif tty konsolları sayısınca fork ile çatallanır. Çatallanmış olan **init** işlemleri `exec` ile **getty** işlemine dönüştürülür. 

getty açık olan tty konsoluna kullanıcı tarafından kullanıcı adı girilene kadar bekler, kullanıcı adı bilgisini aldığında **login** işlemi `exec` ile oluşturulup kullanıcı adı argüman olarak login işlemine aktarılır.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%201.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%201.png)

Argüman olarak kullanıcı adını alan login işlemi, kullanıcıdan parola girmesini ister. Kullanıcı parola girdikten sonra kullanıcı adı ve parola eşleşmesini doğrulamak üzere ***/etc/passwd*** ve ***/etc/shadow*** dosyalarına bakar. 

Bu sırada /etc/passwd dosyasından mevcut kullanıcı hesabına ait kullanıc adı, UID, GID, ev dizini, varsayılan kabuk gibi bilgiler okunup `$USER`, `$UID`, `$GID`, `$HOME`, `$SHELL` değişkenlerine tanımlanmış olur.

Kullanıcı adı ve parolası doğru girilmiş ise ilgili kullanıcının ***/etc/passwd*** dosyasında yer alan kabuk bilgisine göre **login shell** yani oturum açma kabuğu olarak başlatır.

Eğer etkinleştirilmişse `*/etc/motd*` dosyasındaki mesaj mevcut tty konsoluna bastırılır. 

Oturum açma kabuğu için 0, 1 ve 2 dosya tanımlayıcıları terminal cihazına bağlanır.

Artık bu aşamada giriş kabuğunun konfigürasyonları için sırasıyla ilgili dosyalar okunur.

kullanıcı kabuğu için ayarlamamız gereken herhangi bir takma adı veya bir tür değişkenleri içe aktarmak için / etc / profile dosyası okunur.

/ Etc / profile dosyasını okumayı tamamladığında, kullanıcı ana dizini içeriğini okuyacak ve varsayılan kabuğu bash ise kullanıcı kabuk özelliklerini .bashrc, .bash_profile'a göre değiştirecektir. 

Ardından, bu üç dosyadan herhangi birine şu sırayla bakmaya gider: 

~ / .bash_profile 

~ / .bash_login 

~ / .profile 

Birini bulduğunda çalıştırır ve diğerlerini atlar.

En nihayetinde kullanıcının komutlarını yürütmesi için PS1 istemi sunulur. Bu sayede mevcut tty konsoluyla, kendi hesabımızla ilişkili olarak başlatılan giriş kabuğu üzerinden sistemi yönetebiliriz.

Aşağıda username/password bilgisi girdikten sonraki süreci görebiliriz.

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%202.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%202.png)

Komut satırı arayüzünde bu işleyiş hakimdir. Eğer grafiksel arayüzde oturum açarsanız işleyiş daha farklı olacaktır.

### Grafiksel Arayüzde Oturum Açmak ve Kabuğun Çağırılması

Eğer kullanmakta olduğumuz sistem grafiksel arayüz içeriyorsa ve sistem başlangıcında açılacak şekilde konfigüre edildiyse graksel arayüz yardımıyla oturum açarız. Elbette bu durumda sistemi grafiksel arayüz ortamı ile yönetmemiz beklendiğinden bize hemen bir kabuk tahsis edilmez. Grafiksel arayüze sahip oturum açma aşamasından sonra yine masaüstü ortamı ve pencere yöneticileri gibi grafiksel arayüz araçları başlatılır. 

Eğer grafiksel arayüz üzerinde konsol yani terminal aracını açarsak, kullanmakta olduğumuz terminal aracı daha önce ayarlandığı şekilde bir kabuk başlatacaktır. Başlatılacak kabuğun türü kullandığınız terminal aracının özelliklerine göre değişmekle birlikte çoğu terminal aracı varsayılan olarak "oturum açma olmayan etkileşimli kabuk" ile başlar. Dolayısıyla grafiksel arayüz üzerinde terminal aracı ile çağırdığınız kabuk daha önce komut satırı arayüzünde başlatılan "oturum açma kabuğu"nun okuduğu dosyaları okumaz. Yalnızca oturum açma olmayan etkileşimli kabuk için tanımlı olan konfigürasyon dosyalarını okur. Bu modda / etc / bashrc ve ~ / .bashrc dosyası okunur. Bu dosyaların ayrıntılı açıklaması için aşağıya bakın.

Eğer grafiksel arayüzü kullanarak oturum açarsanız, başlangıçta okunacak olan dosyalar değişiklik gösterebilir. Örneğin çoğu dağıtım grafiksel arayüz üzerinden oturum açıldığında oturum açma kabuğu sunmaz. Dolayısıyla oturum açma kabuğu açılırken okunan dosyalar da grafiksel arayüz ile oturum açılırken okunmaz. Yine de hangi dosyanın okunacağınıza veya kabuğun ne şekilde başlatılacağını kullanılan dağıtımdaki grafiksel arayüz sağlayıcısı için kontrol etmeniz gerekir.  Ayrıca elbette gerekli konfigürasyonlar yapılarak grafiksel arayüz ile oturum açılırken de oturum açma kabuğunda okunan dosyaların okunmasını sağlayabilirsiniz. Bizler kabuğun oturum açma modunda hangi dosyaları okuduğuna dolayısıyla nasıl bir ortama sahip olduğuna odaklanıyor olacağız. 

Neticede grafiksel arayüzün kullanımı için gereken ve komut satırı arayüzü kullanımı için gereken şartlar farklı olduğundan zaten komut satırı üzerinden oturum açtığımızda oturum açma kabuğunun başlatılması son derece normal. Komut satırı üzerinden işlem yapıyorken tüm işlemlerimizi mevcut kabuğun altında gerçekleştireceğimiz için ilk başlatılan kabuğun oturum açma kabuğu olması çok mantıklıdır. Bu sayede bizler komut satırı üzerinde oturum açtığımızda daha önce oturum açma kabuğu için özellikle tanımlamış olduğumuz konfigürasyon ayarlarının geçerli olmasını sağlayabiliriz. Bu sayede komut satırı üzerinde konforlu bir çalışma ortamı elde etmiş oluruz. Neticede oturum açma kabuğu özellikle ilk oturum açılırken kabuk ortamını iyi biçimde ayarlamak için vardır. 

Komut satırı arayüzünde ilk başlatılan işlem kabuk olacağı ve biz bu kabuk üzerinde çalışacağımız için oturum açma kabuğu olarak başlar. Oturum kabuğu belirli dosyalardan konfigürsayonlarını okur. Bizler de komut satırında çalışırken sahip olmak istediğimiz ayarlamaları bu kabuk başlatılırken okunun bu dosyalara ekleriz. 

Ancak grafiksel arayüzde buna doğrudan gerek yoktur. Çünkü grafiksel arayüz ortamı ile oturum açtığımızda zaten masaüsütü ortmaı gibi grafiksel arayüz araçları üzerinde çalışırız. Eğer kabuğa emirler vermek istersek terminal aracını açıp emirlerimizi verebiliriz. Grafiksel arayüzde çalıştırdığımız terminal araçları özellikle ayarlanmadığı sürece oturum açma olmayan interaktif kabuklar ile başlarlar. Çünkü grafiksel arayüzde pek çok terminal aracı açabiliriz. Ve her terminal açtığımızda giriş kabuğunda geçerli olan ayarlamanın yapılması pek makul değildir. Giriş kabuğu daha çok tek sefer ayarlanıp, kabuğun altında çalışacağı diğer kabukları etkili şekilde yönetebileceğimiz ayarlamalrı içeriri. Grafiksel arayüzde tek bir kabuk altında çalışmadığımız için oturum kabuğuna ihtiyacımız yoktur. Yine de oturum açma olmayan interaktif kabuk da kendi konfigürasyonlarını birtakım dosyalardan okur. Eğer her terminal açıldığında yapılmasını istediğimiz bir ayarlama varsa bu dosyalara uygun şekilde ekleyebiliriz.

Oturum açama kabuğu; tty ile oturum açarken, ssh ile ya da bash kabuğunu -l veya —login seçeneği ile çağırarak kullanılabilir.

Oturum açma olmayan interaktif kabuk; Konsol araçları ya da doğrudan bash şeklinde çağırılan bash kabuğu ile ulaştığımız kabuktur.

[https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1](https://udaysysadmin.blogspot.com/2016/08/an-overview-of-login-process-in-linux.html?m=1)

Daha detaylı bilgi için;

[https://notes.shichao.io/apue/ch9/#process-groups](https://notes.shichao.io/apue/ch9/#process-groups)

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%203.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%203.png)

Bash kabuğu kullanılacağı alana göre birden fazla kullanım moduna sahiptir. Kullanım modlarının amaçları doğrultusunda elbette kabuğun başlangıçta ve kapanışta okuyup çalıştıracağı dosyalar da farklıdır. Kabuğun aslında bize grafiksel arayüze alternatif olarak bir çalışma ortamı sunan bir araç olduğundan birçok kez bahsettik. Söz konusu kabuğun yani aracın da aslında pek çok farklı çalışma için uygun seçenekeleri vardır. Çalışılacak ortamın elbette gerçekleştirilecek işlere uygun şekilde konfigüre edilmesi gerekiyor. Gerekli konfigürasyonları da çalışma moduna göre uygun dosyalardan okuyarak gerçekleştiriyor. 

![Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%204.png](Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1/Untitled%204.png)

Bash kabuğu başlatılırken, çalıştırılacağı moda göre birtakım dosyalardan konfigürasyon ayarlarını okur. Çalıştırılan kabuk modunun ve dolayısıyla hangi modda hangi dosyaların okunduğunun bilinmesi, üzerinde çalışılacak kabuk ortamının doğru şekilde ayarlanabilmesi adına son derece önemlidir. Bizler de kabuk modlarını ve modlara göre okunan konfigürasyon dosyalarını daha etkili kullanabilmek adına genel olarak el alıyor olacağız. 

Temelde kabuk "etkileşimli" ve "oturum açma" olmak üzere iki moda sahiptir. 

Yine de bu modların kombinasyonu ile bash kabuğu "etkileşimli" "etkileşimsiz" "oturum açma" "oturum açma olmayan" olmak üzere 4 temel kullanım modu sunuyor. Bu modlar kullanım amaçları doğrultusunda birtakım konfigürasyon dosyalarının okunmasının yanında ayrıca çeşitli kabuk özellikleri aktif veya kapalı olacak bir kabuk ortamı da sunarlar. 

[https://linuxhandbook.com/login-shell/](https://linuxhandbook.com/login-shell/)

## Giriş Kabuğu | Login Shell

Oturum açma kabuğu, etkileşimli bir oturum için bir ana bilgisayarda oturum açtığınızda aldığınız ilk kabuktur. Bir giriş kabuğu, bir kullanıcı adı / şifre kombinasyonunun girilmesini gerektirmez. Bash komutun —login seçeneği ile de giriş kabuğu çağırılabilir.

Bir giriş kabuğu, ilk kez bir bash kabuğu aldığınızda temel ortamınızı kurar.

Bir giriş kabuğundaysanız, bash / etc / profile dosyasını arar ve varsa çalıştırır.

Ardından, bu üç dosyadan herhangi birine şu sırayla bakmaya gider: 

~ / .bash_profile 

~ / .bash_login 

~ / .profile 

Birini bulduğunda çalıştırır ve diğerlerini atlar.

Mevcut kabuğun giriş kabuğu olup olmadığını anlamanın en doğru yolu shopt login_shell komutuyla teyit etmektir. Alternatif olarak echo $0 komutu ile çalıştırılan aracın ilk argümanınını yani çalıştırılan aracı bastırabiliriz. Çıktıda -bash şeklinde başında eksi işareti alıyorsak mevcut kabuk login kabuğudur. Ancak bu durum bash kabuğunu -l ya da —login seçenekleri ile çağırdığımızda gerçekleşmediği teyit etmek üzere kullanılamaz. Bash kabuğu -l ya da —login seçenekleri ile de çağırıldığında login kabuğudur ancak echo $0 çıktısında -bash sonucu vermez. Bu sebeple mevcut kabuğun oturum açma kabuğu olup olmadığını aşağıdaki şekilde teyit etmeniz en sağlıklısı olacaktır.

```jsx
shopt -q login_shell && echo "Login shell" || echo "Not login shell"
```

## Etkileşimli Kabuk

Eğitimin başında etkileşimli kabuğun, anlık olarak kabuğa emirler verdiğimiz ve sonucunda konsolda sonuçlarını gördüğümüz şeklinde tanımlamıştık. Ancak hepsi bundan ibaret değil. 

Örneğin bir kabuk etkileşimli olarak başlatılmadan da read komutu sayesinde gerektiğinde kullanıcıdan veri alabilir. Yani bir kabuğun etkileşimsiz olması demek o kabuğun kullanıcı ile hiç bir etkileşim kurmayacağı anlamına gelmiyor. Etkileşimli kabuğun esas önemi, etkileşimli kullanımda ihtiyaç duyulacak çalışma ortamı için kabuğu uygun özelliklerle donatıyor olmasıdır. Dolayısıyla etkileşimsiz bir kabuğu da gerekli ayarlamayı yaparak etkileşimli kabuktaki ortamı sunmasını sağlayabiliriz. Kabuğun temel modları sunmasındaki amaç, kullanım amacına uygun önceden ayarlanmış kabuk çalışma ortamının sağlanabilmesidir.

Modların sahip olduğu özellikler kabuk üzerinde varsayılan olarak tanımlanmıştır. Dilerseniz kabuğun kaynak kodlarını temin edip "***shell.c***" dosyası içinde kabuk modlarına göre hangi özelliklerin aktif hangilerinin deaktif olduğu gibi pek çok varsayılan detaya ulaşabilirsiniz. 

[https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell](https://unix.stackexchange.com/questions/277130/bash-c-and-noninteractive-shell)

Kabuk etkileşimli olarak çalıştığında, davranışını çeşitli şekillerde değiştirir.

1. Kabuk başlangıcında okunan dosyalar başlığı alıntıda açıklanan dosyalar okunur.
2. İş Kontrolü varsayılan olarak etkindir. İş denetimi etkin olduğunda, Bash, klavye tarafından oluşturulan iş denetim sinyallerini SIGTTIN, SIGTTOU ve SIGTSTP'yi yok sayar.
3. Bash expands and displays `PS1` before reading the first line of a command, and expands and displays `PS2` before reading the second and subsequent lines of a multi-line command. Bash expands and displays `PS0` after it reads a command but before executing it. See [Controlling the Prompt](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html), for a complete list of prompt string escape sequences.
4. Bash executes the values of the set elements of the `PROMPT_COMMAND` array variable as commands before printing the primary prompt, `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
5. Readline (see [Command Line Editing](https://www.gnu.org/software/bash/manual/html_node/Command-Line-Editing.html)) is used to read commands from the user’s terminal.
6. Bash inspects the value of the `ignoreeof` option to `set -o` instead of exiting immediately when it receives an `EOF` on its standard input when reading a command (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
7. Command history (see [Bash History Facilities](https://www.gnu.org/software/bash/manual/html_node/Bash-History-Facilities.html)) and history expansion (see [History Interaction](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html)) are enabled by default. Bash will save the command history to the file named by `$HISTFILE` when a shell with history enabled exits.
8. Alias expansion (see [Aliases](https://www.gnu.org/software/bash/manual/html_node/Aliases.html)) is performed by default.
9. In the absence of any traps, Bash ignores `SIGTERM` (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
10. In the absence of any traps, `SIGINT` is caught and handled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)). `SIGINT` will interrupt some shell builtins.
11. An interactive login shell sends a `SIGHUP` to all jobs on exit if the `huponexit` shell option has been enabled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
12. The  invocation option is ignored, and ‘’ has no effect (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    - n
    
    set -n
    
13. Bash will check for mail periodically, depending on the values of the `MAIL`, `MAILPATH`, and `MAILCHECK` shell variables (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
14. Expansion errors due to references to unbound shell variables after ‘’ has been enabled will not cause the shell to exit (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    
    set -u
    
15. The shell will not exit on expansion errors caused by  being unset or null in `${*var*:?*word*}` expansions (see [Shell Parameter Expansion](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html)).
    
    *var*
    
16. Redirection errors encountered by shell builtins will not cause the shell to exit.
17. When running in  mode, a special builtin returning an error status will not cause the shell to exit (see [Bash POSIX Mode](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html)).
    
    POSIX
    
18. A failed `exec` will not cause the shell to exit (see [Bourne Shell Builtins](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html)).
19. Parser syntax errors will not cause the shell to exit.
20. Simple spelling correction for directory arguments to the `cd` builtin is enabled by default (see the description of the `cdspell` option to the `shopt` builtin in [The Shopt Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html)).
21. The shell will check the value of the `TMOUT` variable and exit if a command is not read within the specified number of seconds after printing `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).

## Etkileşimli Oturum Açma Kabuğu

Tty konsollarından birinde ya da ssh bağlantısı ile makinede oturum açıp komutlar verebildiğimiz kabuk modudur. Kullanmakta olduğunu kabuğun oturum açma kabuğua olup olmadığını denetlemek için shopt login_shell komutunu ya da echo $0 komutunda yer alan -bash çıktısı ile teyit edebilirsiniz.

Bu tür bir kabuğun yapılandırmasıyla ilgili olarak, üç dosya dikkate alınır. Bunlar / etc / profile, ~ / .profile ve ~ / .bash_profile'dır. Bu dosyaların ayrıntılı açıklamasını daha sonra yapıyor olacağız.

## Etkileşimli Oturum Açma Olmayan Kabuk

Bu mod, örneğin xterm veya Gnome Terminal gibi yeni bir terminal açmayı ve içinde bir kabuk çalıştırmayı açıklar. Bu modda / etc / bashrc ve ~ / .bashrc dosyası okunur. Bu dosyaların ayrıntılı açıklaması için aşağıya bakın.

## Etkileşimli ve Oturum Açma Olmayan Kabuk

Bu mod, bir kabuk komut dosyası yürütülürken kullanımdadır. Kabuk betiği kendi alt kabuğunda çalışır. Kullanıcı girişi istemediği sürece etkileşimli olmayan olarak sınıflandırılır. Kabuk yalnızca betiği çalıştırmak için açılır ve komut dosyası sona erdiğinde hemen kapatır.

```jsx
./local-script.sh
```

## Etkileşimli Olmayan Oturum Açma Kabuğu

Bu mod, bir bilgisayara, örneğin Secure Shell (ssh) aracılığıyla bir uzaktan kumandadan oturum açmayı kapsar. [Local-script.sh](http://local-script.sh/) kabuk betiği önce yerel olarak çalıştırılır ve çıktısı ssh girdisi olarak kullanılır.

```jsx
./local-script.sh | ssh user@remote-system
```

Ssh'ı başka bir komut olmadan başlatmak, uzaktaki sistemde bir oturum açma kabuğu başlatır. Ssh'nin girdi aygıtının (stdin) uçbirim olmaması durumunda, ssh etkileşimli olmayan bir kabuk başlatır ve komut dosyasının çıktısını uzaktaki sistemde yürütülecek komutlar olarak yorumlar. Aşağıdaki örnek, uzak sistemde uptime komutunu çalıştırır:

```jsx
$ echo "uptime" | ssh localhost

Pseudo-terminal will not be allocated because stdin is not a terminal.

frank@localhost's password:

The programs included with the Debian GNU/Linux system are free software;

the exact distribution terms for each program are described in the

individual files in /usr/share/doc/*/copyright.

Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent

permitted by applicable law.

You have new mail.

 11:58:49 up 23 days, 11:41,  6 users,  load average: 0,10, 0,14, 0,20

$
```

İlginç bir şekilde, ssh, stdin'in bir uçbirim olmadığından şikayet eder ve / etc / motd global yapılandırma dosyasında saklanan günün mesajını (motd) gösterir. Terminal çıkışını kısaltmak için, aşağıda gösterildiği gibi ssh komutunun bir parametresi olarak "sh" seçeneğini ekleyin. Sonuç olarak önce bir kabuk açılır ve iki komut ilk önce motd görüntülenmeden çalıştırılır.

```jsx
$ echo "uptime" | ssh localhost sh

frank@localhost's password:

 12:03:39 up 23 days, 11:46,  6 users,  load average: 0,07, 0,09, 0,16

$$
```

## Login Shell

It reads and executes commands from the first available file (if exists) during login session in the following order:

1. /etc/profile
2. ~/.bash_profile,
3. ~/.bash_login, and
4. ~/.profile

It reads and executes commands from all files (if exists) during logout in the following order:

1. ~/.bash_logout and
2. /etc/bash.bash_logout

## Non-Login Shell

[https://askubuntu.com/questions/879364/differentiate-interactive-login-and-non-interactive-non-login-shell](https://askubuntu.com/questions/879364/differentiate-interactive-login-and-non-interactive-non-login-shell)

# Bash Kabuğunu Çağırmak

# Kabuk Tarafından Okunan Dosyalar

Kabuğun çağırılma şekline göre okunan ve çalıştırılan birtakım dosyalar vardır. Dosyalardan herhangi biri varsa ancak okunamıyorsa, Bash bir hata bildirir.

## Etkileşimli Oturum Açma Kabuğu Çağırıldığında

Bash, etkileşimli bir oturum açma kabuğu olarak veya `--login` seçeneğiyle etkileşimli olmayan bir kabuk olarak çağrıldığında, ilk olarak eğer mevcutsa ***/etc/profile*** dosyasından komutları okur ve çalıştırır. Daha sonra, sırasıyla ~ / .bash_profile, ~ / .bash_login ve ~ / .profile arar ve var olan dosyaları sırasıyla okuyup çalıştırır. Eğer `--noprofile` seçeneği ile başlatılırsa burada bahsi geçen başlangıç dosyaları okunup çalıştırılmaz.

Kabuk kapatılırken ~ / .bash_logout dosyasını okuyup çalıştırır.

## Etkileşimli Oturum Açma Olmayan Kabuk Çağırıldığında

Bash, etkileşimli ancak oturum açma olmayan kabuk olarak çağırıldığında eğer mevcutsa ilk olarak ~/.bashrc dosyasını okur ve çalıştırır. Bu dosyanın okunması , `--norc` seçeneği kullanılarak engellenebilir. Hatta `--rcfile` seçeneği `--rcfile dosya_adı` kullanımı ile başlangıçta doğrudan bizim istediğimiz bir dosyayı okuyup çalıştırmasını sağlayabiliriz. 

## Etkileşimli Olmayan Kabuk

Bash, etkileşimli olmayan bir şekilde başlatıldığında, örneğin bir kabuk komut dosyasını çalıştırmak için, ortamda BASH_ENV değişkenini arar, orada görünüyorsa değerini genişletir ve genişletilmiş değeri okumak ve yürütmek için bir dosyanın adı olarak kullanır. . Bash, aşağıdaki komut çalıştırılmış gibi davranır:

```jsx
if [ -n "$BASH_ENV" ]; then . "$BASH_ENV"; fi
```

ancak PATH değişkeninin değeri dosya adını aramak için kullanılmaz.

Yukarıda belirtildiği gibi, etkileşimli olmayan bir kabuk --login seçeneğiyle çağrılırsa, Bash komutları oturum açma kabuğu başlangıç dosyalarından okumaya ve yürütmeye çalışır.

## Posix Modu Çağırıldığında

Bash, --posix komut satırı seçeneğinde olduğu gibi POSIX modunda başlatıldığında, başlangıç dosyaları için POSIX standardını izler. Bu modda, etkileşimli kabuklar ENV değişkenini genişletir ve komutlar, adı genişletilmiş değer olan dosyadan okunur ve yürütülür. Başka hiçbir başlangıç dosyası okunmaz.

## Remote Deamon Olarak Çağırıldığında

Bash, uzak kabuk arka plan programı (genellikle rshd) veya güvenli kabuk arka plan programı sshd tarafından yürütüldüğünde olduğu gibi, standart girişi bir ağ bağlantısına bağlı olarak ne zaman çalıştırılacağını belirlemeye çalışır. Bash, bu şekilde çalıştırıldığını belirlerse, ~ / .bashrc dosyasındaki komutları okur ve yürütür, bu dosya varsa ve okunabilir durumdaysa. Sh olarak çağrılırsa bunu yapmaz. --Norc seçeneği bu davranışı engellemek için kullanılabilir ve --rcfile seçeneği başka bir dosyayı okunmaya zorlamak için kullanılabilir, ancak ne rshd ne de sshd genellikle bu seçeneklerle kabuğu çağırmaz veya bunların belirtilmesine izin vermez.

## Eşit olmayan etkili ve gerçek UID / GID'ler ile Çağırıldığında

Bash, gerçek kullanıcı (grup) kimliğine eşit olmayan etkin kullanıcı (grup) kimliği ile başlatılırsa ve -p seçeneği sağlanmazsa, başlangıç dosyaları okunmaz, kabuk işlevleri ortamdan, SHELLOPTS, BASHOPTS, CDPATH ve GLOBIGNORE değişkenleri, ortamda görünürlerse göz ardı edilir ve etkin kullanıcı kimliği gerçek kullanıcı kimliğine ayarlanır. Çağrıda -p seçeneği sağlanırsa, başlangıç davranışı aynıdır, ancak etkin kullanıcı kimliği sıfırlanmaz.

# Etkileşimli Kabuk

Etkileşimli bir kabuk, -s belirtilmediği sürece, -c seçeneği belirtilmeden ve hem girdisi hem de hata çıktısının terminallere bağlı olduğu, seçenek olmayan argümanlar olmadan başlatılan bir kabuktur. Ayrıca -i seçeneği ile de başlatılabilir.

Etkileşimli bir kabuk genellikle bir kullanıcının terminalinden okur ve ona yazar. -S çağrı seçeneği, etkileşimli bir kabuk başlatıldığında konumsal parametreleri ayarlamak için kullanılabilir.

## Kabuğum Etkileşimli Mi ?

Kabuğun etkileşimli olup olmadığını anlamak için alternatifler bulunmasına karşın başlangıç dosyalarında aşağıdaki iki komut bloğu ile bu durum teyit edebilir.

```jsx
case "$-" in
*i*)	echo This shell is interactive ;;
*)	echo This shell is not interactive ;;
esac
```

```jsx
if [ -z "$PS1" ]; then
        echo This shell is not interactive
else
        echo This shell is interactive
fi
```

## Etkileşimli Kabuğun Davranışları

Kabuk etkileşimli olarak çalıştığında, davranışını çeşitli şekillerde değiştirir.

1. Kabuk başlangıcında okunan dosyalar başlığı alıntıda açıklanan dosyalar okunur.
2. İş Kontrolü varsayılan olarak etkindir. İş denetimi etkin olduğunda, Bash, klavye tarafından oluşturulan iş denetim sinyallerini SIGTTIN, SIGTTOU ve SIGTSTP'yi yok sayar.
3. Bash expands and displays `PS1` before reading the first line of a command, and expands and displays `PS2` before reading the second and subsequent lines of a multi-line command. Bash expands and displays `PS0` after it reads a command but before executing it. See [Controlling the Prompt](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html), for a complete list of prompt string escape sequences.
4. Bash executes the values of the set elements of the `PROMPT_COMMAND` array variable as commands before printing the primary prompt, `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
5. Readline (see [Command Line Editing](https://www.gnu.org/software/bash/manual/html_node/Command-Line-Editing.html)) is used to read commands from the user’s terminal.
6. Bash inspects the value of the `ignoreeof` option to `set -o` instead of exiting immediately when it receives an `EOF` on its standard input when reading a command (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
7. Command history (see [Bash History Facilities](https://www.gnu.org/software/bash/manual/html_node/Bash-History-Facilities.html)) and history expansion (see [History Interaction](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html)) are enabled by default. Bash will save the command history to the file named by `$HISTFILE` when a shell with history enabled exits.
8. Alias expansion (see [Aliases](https://www.gnu.org/software/bash/manual/html_node/Aliases.html)) is performed by default.
9. In the absence of any traps, Bash ignores `SIGTERM` (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
10. In the absence of any traps, `SIGINT` is caught and handled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)). `SIGINT` will interrupt some shell builtins.
11. An interactive login shell sends a `SIGHUP` to all jobs on exit if the `huponexit` shell option has been enabled (see [Signals](https://www.gnu.org/software/bash/manual/html_node/Signals.html)).
12. The  invocation option is ignored, and ‘’ has no effect (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    - n
    
    set -n
    
13. Bash will check for mail periodically, depending on the values of the `MAIL`, `MAILPATH`, and `MAILCHECK` shell variables (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).
14. Expansion errors due to references to unbound shell variables after ‘’ has been enabled will not cause the shell to exit (see [The Set Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html)).
    
    set -u
    
15. The shell will not exit on expansion errors caused by  being unset or null in `${*var*:?*word*}` expansions (see [Shell Parameter Expansion](https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html)).
    
    *var*
    
16. Redirection errors encountered by shell builtins will not cause the shell to exit.
17. When running in  mode, a special builtin returning an error status will not cause the shell to exit (see [Bash POSIX Mode](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html)).
    
    POSIX
    
18. A failed `exec` will not cause the shell to exit (see [Bourne Shell Builtins](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html)).
19. Parser syntax errors will not cause the shell to exit.
20. Simple spelling correction for directory arguments to the `cd` builtin is enabled by default (see the description of the `cdspell` option to the `shopt` builtin in [The Shopt Builtin](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html)).
21. The shell will check the value of the `TMOUT` variable and exit if a command is not read within the specified number of seconds after printing `$PS1` (see [Bash Variables](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)).

# Kısıtlanmış Kabuk

Bash, rbash adıyla başlatılırsa veya çağırma sırasında --restricted veya -r seçeneği sağlanırsa, kabuk kısıtlanır. Standart kabuktan daha kontrollü bir ortam kurmak için kısıtlı bir kabuk kullanılır. Kısıtlanmış bir kabuk, aşağıdakilerin izin verilmemesi veya gerçekleştirilmemesi dışında bash ile aynı şekilde davranır:

- Changing directories with the `cd` builtin.
- Setting or unsetting the values of the `SHELL`, `PATH`, `HISTFILE`, `ENV`, or `BASH_ENV` variables.
- Specifying command names containing slashes.
- Specifying a filename containing a slash as an argument to the `.` builtin command.
- Specifying a filename containing a slash as an argument to the `history` builtin command.
- Specifying a filename containing a slash as an argument to the  option to the `hash` builtin command.
    - p
- Importing function definitions from the shell environment at startup.
- Parsing the value of `SHELLOPTS` from the shell environment at startup.
- Redirecting output using the ‘’, ‘’, ‘’, ‘’, ‘’, and ‘’ redirection operators.
    
    >
    
    >|
    
    <>
    
    >&
    
    &>
    
    >>
    
- Using the `exec` builtin to replace the shell with another command.
- Adding or deleting builtin commands with the  and  options to the `enable` builtin.
    - f
    - d
- Using the `enable` builtin command to enable disabled shell builtins.
- Specifying the  option to the `command` builtin.
    - p
- Turning off restricted mode with ‘’ or ‘’
    
    set +r
    
    set +o restricted
    

Bu kısıtlamalar, herhangi bir başlangıç dosyası okunduktan sonra uygulanır. Kabuk betiği olduğu tespit edilen bir komut çalıştırıldığında (bkz. Kabuk Betikleri), rbash, betiği çalıştırmak için ortaya çıkan kabuktaki tüm kısıtlamaları kapatır. Kısıtlı kabuk modu, yararlı bir kısıtlanmış ortamın yalnızca bir bileşenidir. PATH, yalnızca birkaç doğrulanmış komutun yürütülmesine izin veren bir değere ayarlanmalıdır (kabuk çıkışlarına izin veren komutlar özellikle savunmasızdır), kullanıcıyı oturum açtıktan sonra kendi ana dizini dışında yazılamaz bir dizinde bırakarak, Kabuk komut dosyalarını yürütmek için kısıtlanmış kabuk ve bazı komutların davranışlarını değiştirmesine neden olan değişkenlerin ortamını temizleme (örneğin, VISUAL veya PAGER). Modern sistemler, hapishaneler, bölgeler veya konteynerler gibi kısıtlı bir ortamı uygulamak için daha güvenli yollar sağlar.

Kısıtlı kabuğu atlatmak ve özellikle iyi konfigüre edilmemiş yapılandırmalardan kaçmak mümkün olduğundan günümüzde bu kullanıma pek ihtiyaç kalmamıştır. Ancak yine özellikle ihtiyaç duymanız veya karşılaşmanız halinde bilgi sahibi olabilmeniz açısından eklemek istedim.

Örneğin kısıtlı kabuktan kaçma örneği; [https://gaissecurity.com/bilgi/linux-restricted-shell-atlatma-teknikleri/](https://gaissecurity.com/bilgi/linux-restricted-shell-atlatma-teknikleri/)

# Bash POSIX Modu

Posix kelimesinin açılımı (**P**ortable **O**perating **S**ystem **I**nterface for Uni**x**) yani Türkçe olarak UNIX için "taşınabilir işletim sistemi arabirimi" olarak çevirilebilir. Posix denilen kavram aslından isim açılımında da yer aldığı şekilde, işletim sistemlerinin gelişimini tutarlı şekilde desteklemek adına belirli standartlar belirleyen ve standartlar dahilinde "uyumlu" dolayısıyla daha "taşınabilir" bir işletim sistemi ekosistemi oluşturmayı hedefler. İsim açılımında her ne kadar "unix" ifadesi yer alsa da aslında GNU/Linux sistemleri de dahil olmak üzere Posix standartlarına uyan tüm sistemlerin ortak noktada buluşabildiklerini söyleyebiliriz. 

Özellikle özgür yazılım ve açık kaynak hareketi doğrultusunda insanların pek çok farklı işletim sistemi ve araç geliştirme çabasının toplum yararına olacak şekilde ortak temellere dayanması amacıyla Posix standartlarının kullanılması son derece makul bir çözümdür. Posix isim önerisini yapan kişi de zaten GPL lisansını ortaya atan Richard Stallman'dır. Bu standartlar dünya çapında kabul gören IEEE(Institute of Electrical and Electronics Engineers-Elektrik ve Elektronik Mühendisleri Enstitüsü) topluluğu tarafından yayınlanmaktadır. 

Posix standartlarına dikkat edilerek geliştirilmiş her türlü yazılım, yine posix standartları dahilinde hareket eden işletim sistemi ortamlarında rahatlıkla çalıştırılabilir. 

Her ne kadar posix standartları taşınabilirlik açısından iyi fırsatlar sunuyor olsa da, elbette her yazılım posix standartlarına uymak zorunda değildir. Bir işletim sistemi ya da yazılım parçası tamamen ya da kısmen posix standartlarına uyarak da çalışabilir. Bu durum yazılımların hangi amaçlar kullanılacağına bağlıdır.

Örneğin Bash kabuğu tamamen Posix uyumlu değildir fakat kendi içerisinde Posix standartlarına uyan bir takım bileşenleri ve özellikleri içerir. Eğer bizler betik programlama yaparken yalnızca posix standartlarına uyan bash kabuğunun özelliklerini kullanırsak, yazdığımız betik dosyası da posix standartlarına uyan çeşitli ortamlar arasında çalıştırılabilir olur. Yani yazdığımız betik dosyasının çok daha geniş kitleler tarafından kullanılmasını istersek, daha "taşınabilir" olması için Posix standartlarına uygun geliştirme yapmamız gerekir. Yine de elbette Posix standartlarının tamamına uygun programlar geliştirmek zorunda değilsiniz. Bu tamamen programlama yaptığınız betik dosyasının hangi amaçla hangi sistemlerde kullanılacağı ile ilgilidir. Örneğin yalnızca bash kabuğunun sahip olduğu özellikleri kullanarak geliştirme yaptığınızda yalnızca bash kabuğuna sahip olan kişiler sizin betik dosyanızı sorunsuzca çalıştırabilir. Zaten yeri geldikçe bash kabuğu içerisindeki posix standartlarına uyan yapılardan bahsediyor olacağız. Sizler de bu durumun farkında olarak amaçlarınız doğrultusunda geliştirme yapabilirsiniz. 

 [https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html)

Bash'in --posix komut satırı seçeneğiyle başlatılması veya Bash çalışırken 'set -o posix' çalıştırılması, Bash'in varsayılan değerinin olduğu alanlarda POSIX tarafından belirtilen davranışla eşleşecek şekilde davranışı değiştirerek POSIX standardına daha yakın bir şekilde uyum sağlamasına neden olur. farklıdır.

Sh olarak çağrıldığında Bash, başlangıç dosyalarını okuduktan sonra POSIX moduna girer. 

Aşağıdaki liste, "POSIX modu" yürürlükte olduğunda neler değiştiğini göstermektedir:

1. Bash ensures that the `POSIXLY_CORRECT` variable is set.
2. When a command in the hash table no longer exists, Bash will re-search `$PATH` to find the new location. This is also available with ‘’.
    
    shopt -s checkhash
    
3. Bash will not insert a command without the execute bit set into the command hash table, even if it returns it as a (last-ditch) result from a `$PATH` search.
4. The message printed by the job control code and builtins when a job exits with a non-zero status is ‘Done(status)’.
5. The message printed by the job control code and builtins when a job is stopped is ‘Stopped()’, where  is, for example, `SIGTSTP`.
    
    *signame*
    
    *signame*
    
6. Alias expansion is always enabled, even in non-interactive shells.
7. Reserved words appearing in a context where reserved words are recognized do not undergo alias expansion.
8. The  `PS1` and `PS2` expansions of ‘’ to the history number and ‘’ to ‘’ are enabled, and parameter expansion is performed on the values of `PS1` and `PS2` regardless of the setting of the `promptvars` option.
    
    POSIX
    
    !
    
    !!
    
    !
    
9. The  startup files are executed (`$ENV`) rather than the normal Bash files.
    
    POSIX
    
10. Tilde expansion is only performed on assignments preceding a command name, rather than on all assignment statements on the line.
11. The default history file is  (this is the default value of `$HISTFILE`).
    
    ~/.sh_history
    
12. Redirection operators do not perform filename expansion on the word in the redirection unless the shell is interactive.
13. Redirection operators do not perform word splitting on the word in the redirection.
14. Function names must be valid shell `name`s. That is, they may not contain characters other than letters, digits, and underscores, and may not start with a digit. Declaring a function with an invalid name causes a fatal syntax error in non-interactive shells.
15. Function names may not be the same as one of the  special builtins.
    
    POSIX
    
16. POSIX special builtins are found before shell functions during command lookup.
17. When printing shell function definitions (e.g., by `type`), Bash does not print the `function` keyword.
18. Literal tildes that appear as the first character in elements of the `PATH` variable are not expanded as described above under [Tilde Expansion](https://www.gnu.org/software/bash/manual/html_node/Tilde-Expansion.html).
19. The `time` reserved word may be used by itself as a command. When used in this way, it displays timing statistics for the shell and its completed children. The `TIMEFORMAT` variable controls the format of the timing information.
20. When parsing and expanding a ${…} expansion that appears within double quotes, single quotes are no longer special and cannot be used to quote a closing brace or other special character, unless the operator is one of those defined to perform pattern removal. In this case, they do not have to appear as matched pairs.
21. The parser does not recognize `time` as a reserved word if the next token begins with a ‘’.
    - 
22. The ‘’ character does not introduce history expansion within a double-quoted string, even if the `histexpand` option is enabled.
    
    !
    
23. If a  special builtin returns an error status, a non-interactive shell exits. The fatal errors are those listed in the  standard, and include things like passing incorrect options, redirection errors, variable assignment errors for assignments preceding the command name, and so on.
    
    POSIX
    
    POSIX
    
24. A non-interactive shell exits with an error status if a variable assignment error occurs when no command name follows the assignment statements. A variable assignment error occurs, for example, when trying to assign a value to a readonly variable.
25. A non-interactive shell exits with an error status if a variable assignment error occurs in an assignment statement preceding a special builtin, but not with any other simple command.
26. A non-interactive shell exits with an error status if the iteration variable in a `for` statement or the selection variable in a `select` statement is a readonly variable.
27. Non-interactive shells exit if  in `.`  is not found.
    
    *filename*
    
    *filename*
    
28. Non-interactive shells exit if a syntax error in an arithmetic expansion results in an invalid expression.
29. Non-interactive shells exit if a parameter expansion error occurs.
30. Non-interactive shells exit if there is a syntax error in a script read with the `.` or `source` builtins, or in a string processed by the `eval` builtin.
31. While variable indirection is available, it may not be applied to the ‘’ and ‘’ special parameters.
    
    #
    
    ?
    
32. When expanding the ‘’ special parameter in a pattern context where the expansion is double-quoted does not treat the `$*` as if it were double-quoted.
    - 
33. Assignment statements preceding  special builtins persist in the shell environment after the builtin completes.
    
    POSIX
    
34. The `command` builtin does not prevent builtins that take assignment statements as arguments from expanding them as assignment statements; when not in  mode, assignment builtins lose their assignment statement expansion properties when preceded by `command`.
    
    POSIX
    
35. The `bg` builtin uses the required format to describe each job placed in the background, which does not include an indication of whether the job is the current or previous job.
36. The output of ‘’ prints all the signal names on a single line, separated by spaces, without the ‘’ prefix.
    
    kill -l
    
    SIG
    
37. The `kill` builtin does not accept signal names with a ‘’ prefix.
    
    SIG
    
38. The `export` and `readonly` builtin commands display their output in the format required by .
    
    POSIX
    
39. The `trap` builtin displays signal names without the leading `SIG`.
40. The `trap` builtin doesn’t check the first argument for a possible signal specification and revert the signal handling to the original disposition if it is, unless that argument consists solely of digits and is a valid signal number. If users want to reset the handler for a given signal to the original disposition, they should use ‘’ as the first argument.
    - 
41. `trap -p` displays signals whose dispositions are set to SIG_DFL and those that were ignored when the shell started.
42. The `.` and `source` builtins do not search the current directory for the filename argument if it is not found by searching `PATH`.
43. Enabling  mode has the effect of setting the `inherit_errexit` option, so subshells spawned to execute command substitutions inherit the value of the  option from the parent shell. When the `inherit_errexit` option is not enabled, Bash clears the  option in such subshells.
    
    POSIX
    
    - e
    - e
44. Enabling  mode has the effect of setting the `shift_verbose` option, so numeric arguments to `shift` that exceed the number of positional parameters will result in an error message.
    
    POSIX
    
45. When the `alias` builtin displays alias definitions, it does not display them with a leading ‘’ unless the  option is supplied.
    
    alias
    
    - p
46. When the `set` builtin is invoked without options, it does not display shell function names and definitions.
47. When the `set` builtin is invoked without options, it displays variable values without quotes, unless they contain shell metacharacters, even if the result contains nonprinting characters.
48. When the `cd` builtin is invoked in  mode, and the pathname constructed from `$PWD` and the directory name supplied as an argument does not refer to an existing directory, `cd` will fail instead of falling back to  mode.
    
    *logical*
    
    *physical*
    
49. When the `cd` builtin cannot change a directory because the length of the pathname constructed from `$PWD` and the directory name supplied as an argument exceeds  when all symbolic links are expanded, `cd` will fail instead of attempting to use only the supplied directory name.
    
    *PATH_MAX*
    
50. The `pwd` builtin verifies that the value it prints is the same as the current directory, even if it is not asked to check the file system with the  option.
    - P
51. When listing the history, the `fc` builtin does not include an indication of whether or not a history entry has been modified.
52. The default editor used by `fc` is `ed`.
53. The `type` and `command` builtins will not report a non-executable file as having been found, though the shell will attempt to execute such a file if it is the only so-named file found in `$PATH`.
54. The `vi` editing mode will invoke the `vi` editor directly when the ‘’ command is run, instead of checking `$VISUAL` and `$EDITOR`.
    
    v
    
55. When the `xpg_echo` option is enabled, Bash does not attempt to interpret any arguments to `echo` as options. Each argument is displayed, after escape characters are converted.
56. The `ulimit` builtin uses a block size of 512 bytes for the  and  options.
    - c
    - f
57. The arrival of `SIGCHLD` when a trap is set on `SIGCHLD` does not interrupt the `wait` builtin and cause it to return immediately. The trap command is run once for each child that exits.
58. The `read` builtin may be interrupted by a signal for which a trap has been set. If Bash receives a trapped signal while executing `read`, the trap handler executes and `read` returns an exit status greater than 128.
59. Bash removes an exited background process’s status from the list of such statuses after the `wait` builtin is used to obtain it.

Bash'in POSIX modunda olsa bile varsayılan olarak uygulamadığı başka POSIX davranışları da vardır.

1. The `fc` builtin checks `$EDITOR` as a program to edit history entries if `FCEDIT` is unset, rather than defaulting directly to `ed`. `fc` uses `ed` if `EDITOR` is unset.
2. As noted above, Bash requires the `xpg_echo` option to be enabled for the `echo` builtin to be fully conformant.

Bash, oluşturma sırasında yapılandırmak için --enable-tight-posix-default belirtilerek, varsayılan olarak POSIX uyumlu olacak şekilde yapılandırılabilir.

# Kabuk Uyumluluk Modu

Bash-4.0, shopt yerleşik için bir dizi seçenek olarak belirtilen bir "kabuk uyumluluk düzeyi" kavramını tanıttı (uyumlu31, uyumlu32, uyumlu40, uyumlu41 vb.). Yalnızca bir geçerli uyumluluk düzeyi vardır - her seçenek birbirini dışlar. Uyumluluk düzeyi, kullanıcıların komut dosyalarını mevcut özellikleri ve davranışı kullanmak üzere geçirirken daha yeni sürümlerle uyumlu olmayan davranışları önceki sürümlerden seçmelerine olanak sağlamak için tasarlanmıştır. Geçici bir çözüm olması amaçlanmıştır. Bu bölüm, belirli bir sürüm için standart olan davranıştan bahsetmez (örneğin, uyumlu32'yi ayarlamak, düzenli ifade eşleştirme operatörünün rh'lerinin alıntılanmasının, sözcükteki özel normal ifade karakterlerinden alıntı yaptığı anlamına gelir, bu, bash-3.2 ve üzeri sürümlerde varsayılan davranıştır). Bir kullanıcı, örneğin, uyumlu32'yi etkinleştirirse, mevcut uyumluluk düzeyine kadar ve dahil olmak üzere diğer uyumluluk düzeylerinin davranışını etkileyebilir. Buradaki fikir, her uyumluluk düzeyinin Bash'in o sürümünde değişen davranışı kontrol etmesidir, ancak bu davranış önceki sürümlerde mevcut olabilir. Örneğin, yerel tabanlı karşılaştırmaları kullanmak için yapılan değişiklik [[komutu bash-4.1'de geldi ve önceki sürümler ASCII tabanlı karşılaştırmalar kullandı, bu nedenle uyumlu32'yi etkinleştirmek ASCII tabanlı karşılaştırmaları da etkinleştirir. Bu ayrıntı, tüm kullanımlar için yeterli olmayabilir ve sonuç olarak, kullanıcılar uyumluluk düzeylerini dikkatli bir şekilde kullanmalıdır. Mevcut davranışı öğrenmek için belirli bir özelliğin belgelerini okuyun. Bash-4.3 yeni bir kabuk değişkeni tanıttı: BASH_COMPAT. Bu değişkene atanan değer (4.2 gibi bir ondalık sürüm numarası veya 42 gibi uyumluNN seçeneğine karşılık gelen bir tam sayı) uyumluluk düzeyini belirler. Bash-4.4 ile başlayarak, Bash eski uyumluluk seviyelerini kullanımdan kaldırmaya başladı. Sonunda, seçenekler BASH_COMPAT lehine kaldırılacaktır. Bash-5.0, önceki sürüm için ayrı bir alışveriş seçeneğinin olacağı son sürümdür. Kullanıcılar, bash-5.0 ve sonraki sürümlerde BASH_COMPAT kullanmalıdır. Aşağıdaki tablo, her bir uyumluluk seviyesi ayarı tarafından kontrol edilen davranış değişikliklerini açıklamaktadır. CompatibleNN etiketi, aşağıdaki mekanizmalardan birini kullanarak uyumluluk düzeyini NN olarak ayarlamak için bir kısaltma olarak kullanılır. Bash-5.0'dan önceki sürümler için, uyumluluk seviyesi, ilgili uyumluNN shopt seçeneği kullanılarak ayarlanabilir. Bash-4.3 ve sonraki sürümler için BASH_COMPAT değişkeni tercih edilir ve bash-5.1 ve sonraki sürümler için gereklidir.

**`compat31`**

• quoting the rhs of the `[[` command’s regexp matching operator (=~) has no special effect

**`compat32`**

• interrupting a command list such as "a ; b ; c" causes the execution of the next command in the list (in bash-4.0 and later versions, the shell acts as if it received the interrupt, so interrupting one command in a list aborts the execution of the entire list)

**`compat40`**

• the ‘<’ and ‘>’ operators to the `[[` command do not consider the current locale when comparing strings; they use ASCII ordering. Bash versions prior to bash-4.1 use ASCII collation and strcmp(3); bash-4.1 and later use the current locale’s collation sequence and strcoll(3).

**`compat41`**

• in posix mode, `time` may be followed by options and still be recognized as a reserved word (this is POSIX interpretation 267)
• in posix mode, the parser requires that an even number of single quotes occur in the *word* portion of a double-quoted ${…} parameter expansion and treats them specially, so that characters within the single quotes are considered quoted (this is POSIX interpretation 221)

**`compat42`**

• the replacement string in double-quoted pattern substitution does not undergo quote removal, as it does in versions after bash-4.2
• in posix mode, single quotes are considered special when expanding the *word* portion of a double-quoted ${…} parameter expansion and can be used to quote a closing brace or other special character (this is part of POSIX interpretation 221); in later versions, single quotes are not special within double-quoted word expansions

**`compat43`**

• the shell does not print a warning message if an attempt is made to use a quoted compound assignment as an argument to declare (declare -a foo=’(1 2)’). Later versions warn that this usage is deprecated
• word expansion errors are considered non-fatal errors that cause the current command to fail, even in posix mode (the default behavior is to make them fatal errors that cause the shell to exit)
• when executing a shell function, the loop state (while/until/etc.) is not reset, so `break` or `continue` in that function will break or continue loops in the calling context. Bash-4.4 and later reset the loop state to prevent this

**`compat44`**

• the shell sets up the values used by `BASH_ARGV` and `BASH_ARGC` so they can expand to the shell’s positional parameters even if extended debugging mode is not enabled
• a subshell inherits loops from its parent context, so `break` or `continue` will cause the subshell to exit. Bash-5.0 and later reset the loop state to prevent the exit
• variable assignments preceding builtins like `export` and `readonly` that set attributes continue to affect variables with the same name in the calling environment even if the shell is not in posix mode

**`compat50 (set using BASH_COMPAT)`**

• Bash-5.1 changed the way `$RANDOM` is generated to introduce slightly more randomness. If the shell compatibility level is set to 50 or lower, it reverts to the method from bash-5.0 and previous versions, so seeding the random number generator by assigning a value to `RANDOM` will produce the same sequence as in bash-5.0
• If the command hash table is empty, Bash versions prior to bash-5.1 printed an informational message to that effect, even when producing output that can be reused as input. Bash-5.1 suppresses that message when the -l option is supplied.

# Bind Shell ve Reverse Shell Nedir ?

Yalnızca bash kabuğuna özel bir durum olmasa da sık karşılaşacağınız iki kavrama da açıklık getirelim. Genellikle güvenlik testlerinde kullanılan yöntemler olduğu için kurban ve saldırgan örneklemleri ile ele alacak olursak;

● Bind Shell ile saldırgan, kurban üzerinde bir port açar ve bu porta bağlanır

● Reverse shell ile kurban, saldırganın dinlemeye aldığı port’a bağlantı yapar