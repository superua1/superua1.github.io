# 7- Kullanıcıdan Veri Almak

# Kullanıcıdan veri almak.

Yazacağımız betikler her zaman kendi başına hareket etmeyeceğinden, kimi zaman kullanıcıdan gelecek veri girişlerini de kabul etmemiz gerekecektir.

## Read

Kullanıcılardan veri girişi almak için Türkçe "**okuma**" anlamına gelen `read` komutunu kullanabiliyoruz.

Basit bir örnek ile başlamak için kullanıcıya adını sorarak, kullanıcının girdiği değere göre ismini bastırmayı deneyelim.

```
echo "İsminizi giriniz:"
read isim
echo "Merhaba $isim tanıştığımıza memnun oldum"

```

Yukarıdaki komutların işlevlerini açıklayacak olursak;

`echo` komutunun ardından girdiğimiz `read` komutu konsola girilen değeri alarak "**isim**" değişkenine aktarıyor.
Daha sonra kullanıcıdan alınan değer, "**isim**" değişkeni aracılığı ile konsola bastırılıyor.

Bu kullanımda `echo` komutuna bağlı kaldık ancak `echo` komutu olmadan da `read` komutu ile konsola çıktı bastırabiliriz. Bunun için `read` komutunun **p** seçeneğini kullanmamız yeterli.

```
read -p "Soyadınızı giriniz:" soyisim
read -p "Soy isminiz: $soyisim"

```

Bu kullanım dışında `read` komutunun çeşitli seçenekleri bulunuyor.
Bahsi geçen seçeneklere ve kısaca işlevlerine aşağıdaki tablodan göz atabilirsiniz.

[Untitled](7-%20Kullan%C4%B1c%C4%B1dan%20Veri%20Almak%20c2b14ea074144097916acf66086ef75a/Untitled%20Database%20a7cb8fafc96d4500a2a693b9e2335526.md)

## p

**prompt** ifadesinin kısaltmasını, Türkçe olarak "**sufle etmek/suflörlük yapmak**"ifadesini temsil ediyor. `echo` komutuna benzer şekilde konsola çıktı basılmasını sağlıyor.

## n

**nchars** ifadesinin kısaltmasını, Türkçe olarak "**n sayıda karakter**" ifadesini temsil ediyor. `read` komutunun alacağı, diğer bir deyişle kullanıcının girebileceği maksimum karakter saysını belirtiyor.

Örneğin kullanıcı maksimum 5 karakter girebilsin istersek;

```
read -n 5 -p "Karakter girin:" 

```

Komutunu kullanarak `read` komutunun **maksimum 5 karaktere kadar** değer alabilmesini sağlayabiliriz.

Örneğimizdeki gibi kısıtlanmış olan karakter girişlerinde, belirtilen karakter sayısına ulaştıktan sonra konsol otomatik olarak işlemi sonlandırarak, fazladan karakter girişini engelliyor.

Bu kullanımda kullanıcı belirtilen karakter sayısını aşamaz ancak daha az sayıda karakter girişi yapabilir.

## s

"**secret**" ifadesinin kısaltmasını, Türkçe olarak "**gizli**" ifadesini temsil ediyor.

Bu seçenek kullanıldığında yazılan ifadeler konsol üzerinde gözükmez. Genellikle parola girişi ya da hassas bilgi girişi için tercih edilir. Kullanım alanını daha net anlamak adına aşağıdaki basit örneğe göz atabilirsiniz.

```
read -s -p "Şifrenizi giriniz:"

```

Bu kullanım ile, kullanıcının yapacağı şifre girişi konsol üzerinde gözükmeyecektir. Eğer daha önce `passwd` komutu ile Linux sistemlerinde parola atama ve değiştirme işlemini gerçekleştirdiyseniz, girilen parola bilgisinin konsol üzerinde gözükmediğini deneyimlemişsinizdir. Buradaki özellik de bizlere bire bir aynı imkanı sağlıyor.

## r

**Backslash(ters slash)** (\) karakterinin kaçış karakteri olduğunu daha önceki kısımlarda ele almıştık. Eğer bu karakteri metin içerisinde kullanırsak konsol bunun kaçış karakteri olduğunu düşünüp **ters slash** karakterini çıktılarda basmaz. Eğer ters slash karakterinin çıktılarda gözükmesini istiyorsak, bunu **r** seçeneği ile belirtmemiz gerekiyor.

Aşağıdaki iki kullanım örneğine bakarak **r** seçeneğinin işlevini çok daha net kavrayabilirsiniz.

```
taylan@kali:~$ read -p "test:" -r isim
test:metin \\n
taylan@kali:~$ echo $isim
metin \\n
taylan@kali:~$ read -p "test:" isim
test:metin \\n
taylan@kali:~$ echo $isim
metin n
taylan@kali:~$

```

## d

**delimiter** ifadesinin kısaltmasını, Türkçe olarak "**sınırlayıcı**" ifadesini temsil ediyor.

Bu seçenek ile belirtilen karakter, `read` komutuna girdi olarak verildiğinde ilgili karakterden sonra yeni karakter giriş işlemi sonlandırılıyor. Bu seçeneğin **n** seçeneğinden farkı, **karakter sayısına değil bizzat girilen karaktere göre** hareket ediyor olmasıdır.

Örneğin soru işaretinin(**?**) ardından kullanıcının veri girişi engellensin istersem komutumu aşağıdaki şekilde kullanabilirim.

```
read -d? -p "Karakter girişi yapınız:"

```

Gördüğünüz gibi uzun bir metnin ardından soru işaretini koymamız ile, konsol yeni karakter girişini engelleyerek işlemi sonlandırdı. Ancak burada belirleyeceğimiz tek karakter kullanıcının veri girişi içerisinde geçen bir ifade ise, kullanıcı henüz veri girişini tamamlamadan giriş işlemi sonlanacağı için sorun oluşabilir. Bu duruma çözüm olarak herhangi bir karakter yerine NULL(`0x00`) yani boş değerini tanımlayarak kullanıcının konsola girebileceği olası tüm değerlerden kaçmış oluruz. Boş karakteri tanımlamak için **$'\0'** ifadesini çıkış karakteri olarak atamamız yeterli.

```
read -d $'\\0'

```

Bu atamayı gerçekleştirdikten sonra kullanıcı, hiçliği ifade eden **Ctrl + @** tuşlamasını yaptığında veri girişi sonlandırılır. Böylelikle kullanıcı hangi karakteri girerse girsin veri girişi engellenmemiş olur.

## a

**array** ifadesinin kısaltmasını, Türkçe olarak "**dizi**" ifadesini temsil ediyor. Biz "a" seçeneğini kullandığımızda kullanıcı tarafından girilen ve arasında boşluk karakteri bulunan her veri diziye eklenir.

```
read -a dizi
elma armut muz kiraz
echo $dizi
elma
echo ${dizi[*]}
elma armut muz kiraz

```

Aynı işlemi "a" seçeneği olmadan denediğimizde dizi özelliğinin varlığını teyit edebiliyoruz.

```
read  dizi2
elma armut muz kiraz
echo $dizi2
elma armut muz kiraz
echo ${dizi[*]}
elma armut muz kiraz

```

Eğer sizler de kullanıcının gireceği her veriyi dize olarak barındırmak isterseniz mutlaka `read` komutu ile birlikte "a" seçeneğini de kullanın.

## t

**timeout** ifadesinin kısaltmasını, Türkçe olarak "**zaman aşımı**" ifadesini temsil ediyor.

Eğer belirtilen süre içerisinde veri girişi tamamlanmazsa, veri giriş işlemi iptal edilebiliyor.

Örneğin kullanıcı 5 saniye içerisinde veri girişini tamamlamazsa, veri giriş isteği otomatik olarak sonlandırılsın istersem;

```
read -t 5 -p "5 Saniye içerisinde veri girişi yapın:"

```

Girdiğim komut ile , kullanıcının veri girmesi için 5 saniyesi bulunuyor. Kullanıcı bu süre içerisinde veri girişini tamamlamazsa işlem otomatik olarak iptal oluyor.

## e

**edit** ifadesinin kısaltmasını, Türkçe olarak "**düzenleme**" ifadesini temsil ediyor.

Bu seçenek kullanıcının **readline** özelliklerini kullanabilmesine, yani girdilerini konsol üzerinden düzenleyerek kullanabilmesine olanak tanıyor. Peki tam olarak `readline` nedir diyecek olursanız;

Readline, imleci hareket ettirmenize, kelimeleri silmenize, imleçten satır sonuna kadar silmenize ve bunlar gibi işlevsel kısayolları kullanmanıza olanak tanır. Bu özellikleri temel Linux eğitimi içerisinde **kısayollar** konusunda, **bash kısayolları** başlığı altında ele aldık.

Örneğin çok uzun bir veri girişinde bulundunuz ve daha sonra bu verinin ilk satırlarında bir hata olduğunu fark ettiniz. Bu durumda ilk baştaki hatayı düzeltmek için readline özelliklerini kullanabilirsiniz.

Örneğin ben **e** seçeneğini girmeden bu kısayolları kullanmaya çalışırsam, konsol benim kısayolları kullanmak istediğimi bilemeyeceğinden, sadece bastığım tuş kombinasyonu konsola çıktı olarak yansıtacaktır.

Eğer **e** seçeneğini eklersem bash kabuğuna özel olan tüm kısayollar, konsol tarafından veri girişi yapılırken de tanınıyor olacak.

Bu durumu teyit etmek için aşağıdaki **e** seçeneğinin bulunduğu ve bulunmadığı çıktılara bakabilirsiniz.

Satır başına gitmek için **Ctrl+a** tuş kombinasyonunu uyguluyorum;

İşte sizler de kullanıcıdan veri alırken, kullanıcılar bu kısayolları kullanabilsin isterseniz **e** seçeneği ile bu durumu özellikle belirtmeniz gerekiyor.

## i

Bu özellik aslında kullanıcının gerçekleştireceği veri girişini standart bir yazı değeri ile başlatıyor. Ancak bu özellik tek başına başına kullanıldığında çalışmıyor. Bu özelliğin aktif olması için bir de bu özellikten önce "e" özelliğinin yani kullanıcının konsol üzerindeki verileri düzenleme imkanının bulunması gerekiyor. Hemen basit bir örnek verelim.

```
taylan@kali:~$ read -e -i "Adınız:" isim
Adınız:taylan
taylan@kali:~$ echo $isim
Adınız:taylan
taylan@kali:~$ 

```

Örneği incelediğinizde bizim kullanıcıya önceden tanımayıp sunduğumuz metin ifadesi, kullanıcının yeni girdiği verilerle birleşerek ilgili değişkene atanmış oldu. Elbette burada yer alan bizim önceden belirlediğimiz varsayılan metin şablonunun, kullanıcının "e" özelliği ile sahip olduğu düzenleme imkanı doğrultusunda silinmesi de mümkündür.

```
taylan@kali:~$ read -e -i "Adınız:" isim
Adı taylan
taylan@kali:~$ echo $isim
Adı taylan
taylan@kali:~$ 

```

Bu özelliğin işlevini ve kullanımı tam olarak kavrayamadıysanız aynı özelliği "e" seçeneği aktif değilken test edip aradaki farkları kıyaslayın lütfen.

## u

Bu seçeneğin kullanımı ile dosya tanımlayıcısı ile oluşturuluş olan tanımdan veri çekilebilir. Burada bahsi geçen "dosya tanımlayıcısı" kavramını ilerleyen kısımlarda ayrıca ele alacağız. Ancak şimdilik bilmeniz gereken, rakama atanmış olan değerin read komutunun u seçeneği aracılığı ile read -u dosya tanımlayıcı değeri şeklinde kullanılması mümkün oluyor. Şu an buradaki açıklamanın sizin için açıklayıcı olmadığını farkındayım ancak merak etmeyin. Yönlendirmeler konusu altında gerekli açıklamaya kavuşmuş olacaksınız.

[https://alisezisli.com.tr/shell-script-7-interaktif-scriptler/](https://alisezisli.com.tr/shell-script-7-interaktif-scriptler/)

## **read Kullanımı**

“**read**” ifadesi, kullanıcıdan ya da bir dosyadan input almak amacıyla kullanılır. read ifadesi işlenirken, aşağıdaki mantık takip edilir:

- Input, token’lar hâlinde alınır. Token dediğimiz şey ise, birbiri ardına sıralanmış karakterlerdir. Tokenlar birbirinden “**whitespace**” karakterleriyle ayrılır. Tabii ki token, çift tırnak işaretleri arasına alınarak boşluk içermesi sağlanabilir.
- Yukarıdaki konuyu biraz daha açıklamaya çalışalım. Input’ları birbirinden ayırmak için kullanılan karakterlere “**IFS (Input Field Seperator)**” diyoruz. Varsayılan olarak boşluk, tab ve yeni satır karakterleri kullanılır. Ancak dilerseniz, bu davranışı değiştirebilirsiniz: Virgül, noktalı virgül gibi.
- İlk token, ilk değişkene atanır.
- Token sayısı, değişken sayısından fazlaysa; son değişken tüm token’ları tutar.
- Eğer değişken sayısı, token sayısından fazlaysa; fazlalık değişkenlerin değeri “**null**” olur.
- Eğer bir değişken belirtilmediyse, token’lar “**$REPLY**” değişkeninde tutulur.

Bunların hepsini açıklamaya ve anlamaya çalışacağız.

Aşağıdaki örnekte read, 3 değişken için değer bekliyor: sayi1, sayi2 ve sayi3. Sonrasında aralarında birer boşluk bırakarak 3 sayı yazıyorum ve enter’a basıyorum. Verdiğim input’lar, değişkenlere **sırasıyla** atanıyor:

```
[root@localhost ShellScripting101]# read sayi1 sayi2 sayi3
19 28 35
[root@localhost ShellScripting101]# echo $sayi1
19
[root@localhost ShellScripting101]# echo $sayi2
28
[root@localhost ShellScripting101]# echo $sayi3
35
[root@localhost ShellScripting101]#
```

Token sayısı, değişken sayısından fazla olursa ne olur?:

```
[root@localhost ShellScripting101]# read esya1 esya2
klavye monitör fare hoparlör
[root@localhost ShellScripting101]# echo $esya1
klavye
[root@localhost ShellScripting101]# echo $esya2
monitör fare hoparlör
[root@localhost ShellScripting101]#
```

Görüldüğü üzere, ilk token ilk değişkene atandı. Kalan tüm token’lar ise son değişkene atandı.

Peki değişken sayısı, token sayısından fazla olursa ne olur?:

```
[root@localhost ShellScripting101]# read degisken1 degisken2 degisken3
token1 token2
[root@localhost ShellScripting101]# echo $degisken1
token1
[root@localhost ShellScripting101]# echo $degisken2
token2
[root@localhost ShellScripting101]# echo $degisken3

[root@localhost ShellScripting101]#
```

Görüldüğü üzere; birinci token birinci değişkene, ikinci token ikinci değişkene atandı. Üçüncü değişken ise **null** kaldı.

Eğer bir değişken ismi belirtilmezse, token’lar $REPLY değişkeninde tutulur:

```
[root@localhost ShellScripting101]# read
Bu token'lar nerede saklanacak?
[root@localhost ShellScripting101]# echo $REPLY
Bu token'lar nerede saklanacak?
[root@localhost ShellScripting101]#
```

## Yönlendirmeler

Hepimizin bildiği üzere; konsola girmiş olduğumuz komutlar kabuk tarafından yorumlanarak, ilgili işlemenin olumlu ya da olumsuz sonuçlarını basar. İşte bu kısımda da konsol ile iletişimimizi sağlayan bu temel yapılardan ve gerektiğinde bu çıktıları nasıl yönlendirebileceğimizden bahsedeceğiz.

## Standart Girdi: Stdin (0)

Konsola yapılmış olan girdiler İngilizce olarak "**standard input**" olarak ifade ediliyor. Standard input ifadesinin anlamı Türkçe olarak "**standart girdiler**" olmakla birlikte genellikle kısaltması olan "**stdin**" ifadesi kullanıyor. Yönlendirme işlemlerinde temsili değeri **0** rakamıdır.

## Standart Çıktı: Stdout (1)

Konsola girilen komutlar sonucunda, konsoldan alınan hatasız çıktılara "**standard output**" yani "**standart çıktı**" deniyor. Standart çıktılar kısaca "**stdout**" olarak ifade ediliyor. Yönlendirme işlemlerinde **1** rakamı ile temsil ediliyor.

## Standart Hata: Stderr (2)

Standart çıktılardan farklı olarak, bu çıktılar **yalnızca hata bildirisinde** bulunurlar. Girmiş olduğumuz komutlar neticesinde gerçekleşen hataları, "**standard error**" yani "**standart hata**" adı altından konsoldan çıktı olarak alabiliriz. Standart hata ifadesi kısaca "**stderr**" olarak geçmektedir. Yönlendirme işlemlerinde **2** rakamı ile temsil edilir.

Aşağıdaki basit şemaya bakarak bahsi geçen kavramları daha net kavrayabilirsiniz.

ŞEMA PC DE D DİSKİNDE BASH DERSLERİ KLASÖRÜNDE VAR !

Kısaca girdilerden ve hatalı-hatasız aldığımız çıktılardan bahsettiğimize göre şimdi bu çıktıların yönlendirilmesi üzerinde duralım.

Daha önceki eğitimimizde tek ve çift büyüktür işareti ile mevcut verileri başka bir konuma yönlendirebileceğimizi görmüştük.

- **Tek büyüktür işareti** kendinden önceki tüm verileri silip üzerine yenilerini yazar.
- **Çift büyüktür işareti** ise var olan verileri koruyarak, mevcut verilerin sonuna ekleme yapar.

Şeklinde açıklamalarda bulunup örnek çalışmalar yürüttük. Buradaki ifadeler doğru olsa da aslında biraz eksik. Nelerin eksik olduğunu birkaç örnek sonra çok daha iyi anlamış olacaksınız.

## Hatasız Çıktıların Yönlendirilmesi

Konsoldan aldığımız **hatasız çıktıları** yönlendirmek istediğimizde yapmamız gereken; hatasız çıktıları temsil eden **1** rakamını, yönlendirme operatörü olan büyüktür işareti ile birlikte kullanmaktır.

Bu kısımda, konsola girilmiş olan bir komutun neticesinde üretilen hatalı ve hatasız çıktıları nasıl yönlendirebileceğimizi ele alacağız. Ancak tek bir komut ile hem hatalı hem de hatasız çıktılar elde etmek her zaman mümkün olmayabiliyor. Bu yüzden hatalı ve hatasız çıktılarımızı tek bir komut neticesinde üretmek üzere kendi hazırladığımız betiği `alias` ile yeni bir komuta tanımlayarak kullanacağız.

Hem hatalı hem de hatasız çıktılar üreten betiğimiz.

```
echo "Sorunsuz bir çıktı"
asdf 
whoami
ls -
echo "Sorunsuz başka bir çıktı daha"

```

Bu betiği `alias komut="bash betik.sh"` komutu ile "**komut**" isimli yeni bir komut olarak atamış oluyoruz.
Ve artık hem hatalı hem de hatasız çıktılar üreten bir komutumuz olmuş oldu.

Eğer bu çıktılardan **yalnızca hatasız** olanları bir dosyaya yönlendirmek istersek, komutumuzun sonuna `1> dosya.txt` komutunu girmemiz yeterli oluyor.

```
komut 1> hatasız.txt

```

Gördüğünüz gibi konsola yalnızca hatalı çıktılar basılırken, hatasız çıktılar bizim yönlendirmemiz ile "**hatasız.txt**" dosyasına kaydedilmiş oldu.

Aslında burada belirtmiş olduğumuz **1** rakamını yazmadan, yalnızca **>** operatörü kullanılarak da hatasız çıktılar dosyaya aktarılabiliyor.

Bunun nedeni **1** rakamının varsayılan yönlendirme operatörü olmasıdır. Biz özellikle farklı bir rakam belirtmedikçe yönlendirme operatörünün alacağı değer **1** rakamıdır. Yani daha önceleri de büyüktür işaretini kullanarak komut çıktılarını dosyalara yönlendirirken, aslında **sadece hatasız çıktıları** yönlendirmiş oluyorduk. Hemen söylediklerimizi tetlm.

```
komut > hatasız.txt

```

## Hatalı Çıktıların Yönlendirilmesi

Şimdi de yalnızca hatalı çıktıları bir dosyaya aktaralım.

```
komut 2> hata.txt

```

Çıktılarda gördüğünüz gibi hatalı çıktıları bir dosyaya yönlendirdikten sonra, konsola yalnızca hatasız çıktılar basılmış oluyor.

Ayrıca yeri gelmişken belirtelim, çift büyüktür işaretini kullanarak önceki verimdn yeni verilerin dosyanın sonuna eklenmesini sağlayabiliyoruz.

```
komut 1>> hatasiz.txt
komut 2>> hata.txt

```

## Hatalı ve Hatasız Çıktıların Yönlendirilmesi

Eğer hem hatalı hem de hatasız çıktıları tek bir dosyaya yönlendirmek istersek, **ampersant**(**&**) işaretini kullanabiliyoruz.

```
komut &> hatalı-hatasız.txt

```

Ayrıca bu kullanımın dışında alternatif olarak aşağıdaki şekilde çıktıların yönlendirilebilmesi de mümkün.

```
komut > hatalı-hatasız.txt 2>&1
komut 2> hatalı-hatasız.txt 1>&2

```

Bu kullanımda gerçekleşen olay, ampersant işaretinin yol gösterici olarak çalışması ile meydana geliyor.

İlk kullanımda hatalı çıktıları hatasız çıktılar gönderip, üzerine hatalı çıktılar eklenmiş olan hatasız çıktıları dosyamıza yazdırdık.

İkinci kullanımda ise hatasız çıktıları hatalı çıktılara gönderip, üzerine hatasız çıktılar eklenmiş olan hatalı çıktıları dosyamıza yazdırdık.

Okurken biraz karmaşık gelmiş olabilir ancak örneklere ve yapılan açıklamaya biraz daha dikkat ederseniz ne demek istediğimi çok rahat kavrayabilirsiniz.

Elbette hatalı ve hatasız çıktıları tek seferde iki ayrı dosyaya da yönlendirebiliyoruz.

```
komut > hatasiz.txt 2> hata.txt

```

## Çıktıların Yok Edilmesi

Çıktıların hepsini boşluğa göndermek yani konsola veya herhangi bir dosyaya çıktı bastırmadan çıktıları yok etmek istersek, **/dev/null** adresine yönlendirmemiz gerekiyor.

```
komut &> /dev/null

```

Aynı şekilde yalnızca hata çıktılarını ya da hatasız çıktıları da boşluğa gönderebiliyoruz.

```
komut 1> /dev/null
komut 2> /dev/null

```

## Yazma Korumalı Dosyalara Yönlendirme İşlemi

Önemli dosyaların üzerine hatalı veri girişi yapılmasını önlemek adına `noclobber` kullanımını görmüştük.

Bu kısımda ise, üzerinde yazma koruması bulunan bu tür dosyalara çıktılarımızı nasıl yönlendirebileceğimizi ele alacağız.

Öncelikle "**yazılamaz.txt**" isimli dosyaya **noclobber** korumasını atayalım.

```
touch yazılamaz.txt
set -o noclobber yazılmaz.txt

```

Yazma korumalı dosyamız oluştuğuna göre şimdi de üzerine yazma işlemi için yönlendirme operatörü ile birlikte **pipe** (**|**) işaretini kullanalım.

```
komut >| yazılamaz.txt

```

Bu kullanım ile hatasız çıktıları yazma korumalı "**yazılamaz.txt**" dosyasına yazdırmayı başardık.

Aynı şekilde hatalı çıktıları yazdırmak için de `2>|` operatörünü kullanmamız yeterli oluyor.

Ancak burada dikkat etmeniz gereken, hem hatalı hem hatasız çıktıları yazma korumalı dosyalara yazdırırken `&>|` kullanımının geçersiz olmasıdır. Bunun yerine hatalı ve hatasız çıktıları aynı anda yönlendirmeye yarayan ikinci kullanım şeklini tercih etmeniz gerekiyor.

```
komut >| yazılamaz.txt 2>&1
komut 2>| yazılamaz.txt 1>&2

```

Peki ama **noclobber** yazma koruması olan dosyaların üzerine veri yazabiliyorsak bu korumanın anlamı nedir ?

Aslında burada yapılan işlem bilinçli olarak dosyanın üzerine yazma işlemi olduğundan teknik olarak bir sorun bulunmuyor. **noclobber** kullanımındaki temel amaç bilinçsizce veri girişini engellemek. Burada **pipe** işaretini kullanarak bu işin bilincinde olduğumuzu, herhangi bir dikkatsizliğin bulunmadığını kabuğa bildirmiş oluyoruz.

## Veri Giriş Yönlendirmesi

Söz konusu yönlendirme işlemleri olduğunda yalnızca komut çıktılarını yönlendirmekle kalmıyor, dosyalardan da komutlara veri yönlendirmesi yapabiliyoruz. Bunun için kullanmamız gereken operatör **küçüktür işareti**(**<**) oluyor.

Örneğin hata çıktılarımızın yer aldığı **hata.txt** dosyamızı `cat` komutuna yönlendirerek konsol ekranına basılmasını sağlayabiliriz.

```
cat < hata.txt

```

Bir örnek daha yapalım ve dosyada yer alan standart ifadelerin değişmesini sağlayalım.

Dosya içerisinde geçen tüm "**Ad:**" ifadelerini "**İsim**" ifadesi ile değiştirelim. Ve bu işlemi "**isimler**" dosyasından **veri çekme operatörü** olan **küçüktür karakteri** ile yapalım.

```
sed 's|Ad:|İsim:|' < isimler 

```

Gördüğünüz gibi verileri küçüktür işareti sayesinde isimler dosyasından çekebildik.

Bu operatörün kullanımında dikkat edilmesi gereken, bütün komutların bu yönlendirme operatörünün kullanımı için uygun olmadığıdır. Yani dosyalardan herhangi bir veriyi çekmek istediğinizde işlemin başarılı olabilmesi için kullanmış olduğunuz komutun operatörden gelecek veriyi kabul edecek yapıda olması gerekir.

Örneğin `cat` komutu veri çekme operatörünü tanıyorken, `echo` komutu bu operatörü tanımaz.

Bu durumun nedeni, her bir komutun tanımlandığı görev dahilinde hareket edebilen fonksiyonel programlar olmasıdır. Yani komutların sınırsız özellikleri ya da sezgisel tepkileri yoktur. Bu yüzden veri girişini bu şekilde küçüktür işareti ile yapmak istediğinizde kullanmış olduğunuz komutun bunu desteklediğinden emin olmanız gerekiyor.

Esasen çok sık kullanılan bir yöntem olmasa da daha sonra karşılaşmanız halinde bu operatörün hangi işlevde olduğunu bilmenizi istediğim için bu kısımda kısaca değinmek istedim. Ve artık hangi işlevde olduğunu biliyorsunuz :)

## Tüm Komut Çıktılarının Yönlendirilmesi

Bu bölüme kadar tek bir komutun ürettiği hatalı ve hatasız çıktıları nasıl yönlendirebileceğimiz üzerinde durduk. Şimdi de konsoldan üretilen tüm çıktıların tek elden yönlendirilmesini ele alalım.

**Örneğin;** Yazmış olduğum bir betik dosyası içerisinde yer alan tüm komutların hatalı ya da hatasız olan çıktılarının özellikle tek bir dosya üzerinde toparlanmasını istersem `exec` komutu ile kalıcı hedef gösterme yapmam gerekiyor.

Yazmış olduğum betik dosyasının içerisine;

Hatasız çıktıları yönlendirmek üzere; `exec > hatasızlar.txt`
Hatalı çıktıları yönlendirmek üzere; `exec 2> hatalılar.txt`
Hem hatalı hem de hatasızları yönlendirmek üzere; `exec &> tum-cıktılar.txt`

Komutlardan herhangi birini ihtiyacıma göre kullanabilirim.

Bu şekilde betik dosyam çalıştırıldığında, betik dosyasının içerisinde yer alan komutların ürettiği tüm çıktılar otomatik olarak ilgili dosyaya yönlendirilmiş oluyor. Benden betik dosyasını çalıştırırken haricen bir yönlendirme yapmamı beklemiyor.

Daha iyi anlamak adına basit bir örnek yapalım. Örneğin kullanıcıdan konsola komut isteyelim ve girdiği komutların hatasız çıktılarını "**hatasızlar.txt**" isimli bir dosyaya yönlendirelim. Neticede kullanıcı konsola potansiyel olarak sınırsız sayıda komut girebileceğin bu işi otomatize etmemiz gerekiyor. Girilen komut her ne olursa olsun hatasız çıktılar oluşturduğunda, "**hatasızlar.txt**" dosyasına yazılması için `exec >> hatasızlar.txt` komutunu kullanalım.

Basit bir `while` döngüsü kuralım ve kullanıcı "**q**" çıkma komutunu girene kadar kullanıcıdan komut istemeye devam edelim.

```
#! /bin/bash
exec >> hatasızlar.txt

while [ "$komut" != "q" ] 
        do
                read -p "Komut girin:" komut
                echo -e "\\e[32mGirdiğiniz komut:\\e[22m" $komut  "\\n-----------------"
                echo -e "\\e[31mKomutun Çıktıları:\\e[0m " $($komut)
        done

```

Bu kullanım ile kullanıcı konsola ne kadar komut girerse girsin, hatasız çıktıları hepsi otomatik olarak "**hatasızlar.txt**" dosyasına kayıt oluyor olacak.

Böylelikle exec komutu yardımıyla istediğimiz sonucu elde edebildik. Peki ama exec komutu tam olarak hangi işlevde, yani exec komutunun çalışma yapısı nasıl. Şimdi de buna bir göz atalım.

## exec Komutu

`exec` komutu **bash yerini alıyor** ve tıpkı bizlerin bash'e komut girdiği gibi komut alıp komutları yürütebiliyor. Bu tam olarak ne demek oluyor ?

Bizler terminalden komut girerken aslında terminal aracına atanmış olan bash kabuğu üzerinde çalışıyoruz. Terminal aracı sadece bash yani sistemin kabuğu ile bizim etkileşimli olarak iletişim kurmamızı sağlıyor. Yani aslında bizim yazdığımı tüm komutlar, terminale atanmış olan bu kabuk sürecine aktarılarak işlem görüyor.

Eğitim başlarında da bu durumlardan bahsettik. Hatırlarsanız betik dosyası çalıştırıldığında mevcut kabuğun altında bir kabuk başlatılarak, betik dosyasının bu alt kabuk üzerinden yürütüldüğünü söylemiştik. Yani betik dosyası içerisinde yer alan tüm komutlar aslında oluşturulan bir alt kabukta çalıştırılıyor.

İşte `exec` komutu da, çalışmakta olduğu **bash süreci ile yer değiştirerek** tıpkı bash gibi davranıp komutların yürütülmesini sağlıyor.

Daha iyi anlamak adına tüm hatasız çıktıları yönlendirdiğimiz örneği tekrar ele alalım.

1- Betik dosyamızı konsol üzerinden çalıştırdık.

2- Konsol, betik dosyasını çalıştırmak için bir alt bash oluşturdu ve bu alt kabuğu betik dosyasına tanımladı.

3- Betik dosyasına tanımlanmış olan alt bash kabuğu, betik dosyasının içeriğini okumaya başladı.

4- Betik dosyası için atanan bu alt bash kabuğu `exec` komutuna gelince kendi görevini `exec` komutuna devretti. Bu devretme işleminde herhangi bir yeni alt kabuk oluşturulmadı, sadece görev devri yapıldı.

5- Görevi devralan `exec`, betik dosyası üzerindeki tüm komutları çalıştırmaya ve komutlar hakkında bilgi sahibi olmaya başladı. Artık betik dosyası içerisindeki tüm komutlara tek bir `exec` komutu hakimdi ve biz de `exec` komutundan aldığımız verileri tek elden işleyebilir hale geldik.

6- Neticede yazmış olduğumuz betik dosyası içerisinde hangi komut çalıştırılırsa çalıştırılsın `exec` üzerinden çalıştırıldığı için, `exec` komutu ile hatasız çıktıların hepsini tek elden ilgili dosyaya yönlendirebiliyoruz.

7- Eğer `exec` komutu kullanılmazsa, bu yönlendirmeler betik dosyası başlatılırken `bash betik.sh 2> hatalı-yönlendirme.txt` şeklinde kullanıcı tarafından özellikle belirtilmek zorunda. Çünkü bizim amacımız tüm komutların hatasız çıktılarını tek bir dosyaya yönlendirmek ve tüm komutlar yalnızca **bash** kabuğu üzerinden takip edilebiliyor. Ancak bash süreci betik dosyası açılırken başlatıldığı için, bash sürecine betik dosyası içerisinden müdahale edemiyoruz. Bash sürecine ancak başlatılması esnasında müdahale edebiliriz. İşte `exec` komutu da betik dosyası içerisinden, bash sürecine müdahale imkanı tanıyor.

Ayrıca `exec` komutunu neden betiğin en başında kullandık diyecek olursanız, betik okuma düzeninin yukarıdan aşağıya ve soldan sağa doğru olduğunu hatırlamanız gerekir. Betik yukarıdan aşağıda okunacağı için, üretilen tüm çıktıların betik çalıştırılır çalıştırılmaz hatasızlar dosyasına gideceğini konsola ilk satırlarda bildirmemiz gerekir. İlk satırda bash kabuğunun görevini `exec` komutuna devretmeliyiz ki, sonraki satırdaki komutlar `exec` tarafından çalıştırılsın ve çıktıları da `exec` tarafından yönlendirilebilsin.
Eğer tüm adımları dikkatli bir biçimde takip ettiyseniz `exec` komutunun, yönlendirme örneğimizde ne kadar kritik role sahip olduğunu ve tam olarak hangi işe yaradığını kavramış olmalısınız.