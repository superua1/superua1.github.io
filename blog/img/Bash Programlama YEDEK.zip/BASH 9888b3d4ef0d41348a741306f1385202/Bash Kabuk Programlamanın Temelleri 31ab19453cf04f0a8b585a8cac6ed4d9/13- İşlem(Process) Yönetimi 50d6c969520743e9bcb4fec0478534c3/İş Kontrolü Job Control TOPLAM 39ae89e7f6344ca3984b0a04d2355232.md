# İş Kontrolü | Job Control TOPLAM

İşlemin temelde ne olduğunu artık biliyoruz. Mevcut kabuk üzerinde bir işlem çalıştırılırken, ilgili işlemin çalışması bitmeden kabuk yeni komutlar almaz. Zaten işlem oluşturma mekanizmasından bahsederken ebeveyn işlemin, çocuk işlemin sonlanmasını beklediğini belirtmiştik. Ancak kabuğun, yalnızca tek bir işlemle meşgul olması özellikle etkileşimli kabuk kullanımında pek verimli bir yaklaşım değildir. Sistem yönetiminde verimli olabilmesi için kabuğun, işlemleri arka planda başlatabilmesi veya arka plana alabilmesi yani işlemleri beklemek zorunda olmaması ve gerektiğinde başlatılan işlemleri duraklatabilme, devam ettirebilme ve sonlandırabilme kabiliyetinin olması gerekir. Bu duruma çözüm olarak bash kabuğu, kendi altında çalıştırılan işlemlere bir "iş" gözüyle bakma yaklaşımına gitmiştir. 

Kabuk, kendisi üzerinden başlatılmış olan tüm işlemleri iş tablosu olarak geçen bir tabloda tutar. Her kabuğun kendine ait iş tablosu vardır. Bu tablo sayesinde mevcut kabuk üzerinde çalıştırılan işlemlerin gerektiğinde durdurulması, arka plana alınması veya arka plandaki işlemlerin tekrar ön plana alınması gibi etkileşimli kullanımda hayatımızı kolaylaştıracak imkanlar, süreç numaraları ile uğraşmaya gerek kalmadan yerine getirilebilir.

Neden böyle bir yapıya ihtiyaç duyulduğunu daha iyi anlamak için öncelikle işlemlerin durdurulması, arkaplanda ve önplanda çalışması gibi detaylardan bahsedelim.

Not: İş kontrolü(job control) yalnızca etkileşimli kabukta varsayılan olarak aktiftir. İleride kabuğun modlarından ve bu modların sahip olduğu özelliklerden bahsederken bu duruma da tekrar atıfta bulunuyor olacağız.

### Ön Plandaki İşlemler

Kabuğun standart çalışma şekli ön planda çalışan işlemi temsil eder. Normal şartlarda kabuk, emirleri sırasıyla tek tek alır ve bir işlem çalışmayı bitirmeden bir diğer işlemi çalıştırmaz. Bu durumu deneyimlemek için konsola `sleep 5` komutunu girip hemen ardından kabuğa başka bir emir vermeye deneyebilirsiniz.

```jsx
└─$ sleep 5
echo deneme
└─$ echo deneme
deneme
```

Örnekteki durumda, `sleep` işlemi 5 saniye boyunca çalıştığı için kabuk `echo deneme` komutunu `sleep` işlemi bitmeden değerlendiremedi, çünkü kabuk `sleep` komutunu bekliyordu. `sleep` işlemi biter bitmez vermiş olduğumuz komut kabuk tarafından işlenmiş oldu. Neticede standart davranış gereği işlemin önplanda başlatılıp, ilgili işlem bitmeden bir diğerinin çalıştırılmadığını bizzat teyit ettik. 

Eğer bizler halihazırda bir işlem çalışıyorken kabuğa yeni komutlar girebilmeyi de istiyorsak, işlemi arkaplanda başlatmamız gerekiyor. 

### İşlemleri Arka Planda Başlatmak

Komutun sonuna ampersand yani & işaretini eklediğimizde, ilgili işlem arka planda çalıştırılacaktır. Arka plandaki işlem çocuk işlem olarak çalışır. Kabuk bu çocuk işlemi beklemeden çalışmaya devam eder.

```jsx
└─$ sleep 5&
[1] 28
┌──(I have no name!㉿DESKTOP-E4TGC85)-[~]
└─$ echo deneme
deneme
```

Madem kabuk arka plandaki işlemi beklemiyor, arka plandaki işlemi nasıl kontrol edeceğiz ? Başı boş mu kaldı ? Hayır. Bir işlem arka planda başlatıldığında veya arkaplana alındığında(ileride bahsedeceğim), mevcut kabuğun iş tablosuna eklenir. Bu tablo üzerindeki işleme atanmış olan sıra numarası üzerinden arka plandaki işlemi kolaylıkla durdurup, devam ettirebilir, ön plana alabilir ya da sonlandırabiliriz. 

Zaten arka planda bir komut çalıştırdığınız, çıktıdan da görebileceğiniz gibi komutun hemen ardından iş tablosundaki numarası da konsola da basıldı.  Çıktıdaki "[1]", işlemin iş tablosunda sıra numarasını, "22" ise işlemin işlem numarasını(pid) belirtiyor. 

Aksi belirtilmedikçe ve iş kontrolü özelliği mevcut kabukta aktif olduğu sürece kabuk üzerindeki işlem gruplarının her biri bir iş olarak kabul edilir. Örneğin `sleep 11 &` komutunu girdiğimizde arkaplanda çalıştırılan `sleep` işlemi mevcut kabuğun iş tablosuna ekleniyor. Görmek için mevcut kabuktaki işlerin tablosunu bastıran `jobs` komutunu kullanabiliriz.

```jsx
└─$ sleep 11&
[1] 22
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ jobs
[1]+  Running                 sleep 11 &
```

Hali hazırda tüm işlemlerin işlem numaraları olduğu için ekstra iş tablosundaki numaraları ile uğraşmak belki ilk bakışta verimli gelmemiş olabilir. Sonuçta `ps` gibi bir araç ile işlemin işlem numarası öğrenilip `kill` komutu ile işleme sinyaller göndererek de iş kontrolüne benzer faaliyetlerde bulunabiliriz. Ancak iş kontrolü göründüğü kadar verimsiz değil.

Öncelikle, tüm sistemde çalışmakta olan işlemlere oranla iş tablosunda çok daha az işlem listelendiği için mevcut kabuk üzerinden çalıştırılan işlemlerin kontrolü ve takibi çok daha kolaydır. Ayrıca tek seferde birden çok işlemi arkaplanda başlatmanız ve bu işlemleri yönetmeniz de gerekebilir. Bu duruma pipeline harika bir örnektir.

Pipeline üzerinde yer alan komutlar, aynı anda arka planda birden fazla işlemin çalışmasına neden olur. Aynı anda birden çok işlem başlatılsa da pipeline üzerindeki işlem grubu da tek bir iş olarak iş tablosuna eklenir.  Bu sayede gerektiğinde pipline üzerinde yer alan tüm işlemleri tek seferde arka plana alma, ön plana alma veya tek seferde sonlandırma gibi etkileşimli kullanımda büyük bir kolaylığa sahip oluruz.

```jsx
└─$ sleep 11 | sleep 22 | sleep 33&
[1] 25
└─$ jobs
[1]+  Running                 sleep 11 | sleep 22 | sleep 33 &
```

İş kontrolü yapabilmemiz için işlemlerin arkaplanda çalıştırılması veya halihazırda önplanda çalışıyorsa durdurulup arkaplana alınması gerekiyor. Çünkü mevcut kabuk önplandaki iş ile meşgülken bizden yeni komut alamayacağı için elbette iş kontrolünü sağlamamız mümkün olmaz.

Örneğimizde de olduğu şekilde işlemleri arka planda başlatmak için ampersant `&` işaretini ilgili komutun sonunda kullanmamız yeterli. Peki ya halihazırda çalışmakta olan bir işlemi nasıl arka plana alabiliriz ?

### İşlemleri Arka Plana Almak

Eğer bir işlemi arkaplanda başlatmadıysak duraklatıp arkaplana almamız da mümkündür. Bu sayede işlem arkaplanda çalışamaya devam ederken bizler de kabuğa yeni komutlar verebiliriz. 

Ön planda çalışmakta olan bir işlemi arka plana almak istersek öncelikle ilgili işlemi **Ctrl+Z** tuşlaması ile duraklatmamız gerekiyor. Zaten duraklattığımızda işlemin durduğunu ve işlem tablosundaki numarasını konsoldaki çıktıdan görebiliyoruz. Yine de tekrar teyit etmek için elbette `jobs` komutunu da kullanabilirsiniz.

```bash
taylan@taylan:~$ sleep 150
^Z
[1] 2138
taylan@taylan:~$ jobs
[1]+  Çalışıyor           sleep 150 &
taylan@taylan:~$
```

Duraklatmış olduğumuz işlemin arka planda çalışmaya devam edebilmesi için `bg %iş_numarası` ya da `bg %komut_adı` şeklinde komut vermemiz gerekiyor. Buradaki `bg` komutu "background" yani "arka plan" ifadesinden geliyor.

Artık böylelikle, ön plandaki bir işlemi arka plana almış oldunuz. Dilerseniz arka plandaki işlemleri ön plana da alabilirsiniz. 

### İşlemleri Ön Plana Almak

Arkaplanda çalışmakta olan işlemi ön plana almak için `fg %iş_numarası` ya da `fg %komut_adı` komutlarını kullanabilirsiniz. Burada "fg" olarak geçen komut "foreground" yani "ön plan" anlamındadır.

Denemek için arka plandaki bir işlemi ön plana alalım.

```jsx
─$ sleep 111&
[1] 1191
┌──(kali㉿kali)-[~]
└─$ jobs
[1]+  çalışıyor               sleep 111 &
┌──(kali㉿kali)-[~]
└─$ fg %1
sleep 111
```

İlgili işlem tekrar ön planda çalışmaya başladı.

İşlem kontrolü ile ilgili temel yapıdan bahsettik. Konuyu çok dağıtmamak için bahsedemediğimiz bazı ayrıntılar bulunuyor. Gelin şimdi geride kalan ayrıntılardan bahsedelim.

## jobs Komutu

`jobs` komutu mevcut kabuk üzerinde çalıştırılmış olan görevlerin durumlarını listeler. Tek başına kullanıldığında etkin olan durumların bilgisini listeler. 

```bash
taylan@taylan:~$ sleep 101 & #arkaplanda başlattık.
[1] 1881
taylan@taylan:~$ sleep 102
^Z        # Ctrl + Z tuşlamamsıyla duraklattık.
[2]+  Durdu                   sleep 102
taylan@taylan:~$ sleep 103
^C        # Ctrl + C tuşlamasıyla süreci sonlandırdık.
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 101 &
[2]+  Durdu                   sleep 102
taylan@taylan:~$
```

Görebildiğiniz gibi arkaplanda çalışmakta olan ve durdurulmuş olan(beklemede olan) işlemler listelenirken, sonlandırılmış(tamamlanmış) işlem listelenmemektedir.

Eğer ek olarak işlem numaraları(pid) da sunulsun istersek, `-l` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ jobs -l
[1]-  1881 Bitti                   sleep 101
[2]+  1882 Durduruldu              sleep 102
taylan@taylan:~$ jobs -l
[2]+  1882 Durduruldu              sleep 102
taylan@taylan:~$
```

Çıktıları incelediğimizde sol tarafta ilgili işin işlem numarasının da listelenmiş olduğunu görebiliyoruz. Ayrıca fark edebileceğiniz gibi arka plandaki işlemler tamamlandığında bir defaya mahsus bu bilgiyi `jobs` komutu çalıştırıldıktan sonra bize "Bitti" şeklinde iletiyor. 

Eğer daha önce `jobs` komutu ile hakkında bilgi aldığımız komutun değişen bir durumu olup olmadığını teyit etmek istersek `-n` seçeneğini kullanabiliriz. Bu seçeneğinde ardından eğer daha önce `jobs` komutu ile kontrol ettiğimiz bir görevde değişiklik olduysa çıktı alırız, aksi halde hiç bir çıktı basılmaz.

```bash
taylan@taylan:~$ jobs
[2]+  Durdu                   sleep 102
taylan@taylan:~$ bg "%sleep 102" 
[2]+ sleep 102 &
taylan@taylan:~$ jobs -n
[2]+  Bitti                   sleep 102
taylan@taylan:~$
```

Yalnızca işlerin işlem numaralarını almak istersek `-p` seçeneğini kullanabiliriz. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2120
taylan@taylan:~$ sleep 102 &
[2] 2121
taylan@taylan:~$ jobs -p
2120
2121
taylan@taylan:~$ jobs -l
[1]-  2120 Çalışıyor           sleep 101 &
[2]+  2121 Çalışıyor           sleep 102 &
taylan@taylan:~$
```

Yalnızca çalışmakta olan işleri listelemek istersek `-r` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ sleep 201 &
[1] 2328
taylan@taylan:~$ sleep 202
^Z
[2]+  Durdu                   sleep 202
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 201 &
[2]+  Durdu                   sleep 202
taylan@taylan:~$ jobs -r
[1]-  Çalışıyor           sleep 201 &
taylan@taylan:~$
```

Yalnızca durdurulmuş olan işleri listelemek için `-s` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ sleep 301 &
[1] 2346
taylan@taylan:~$ sleep 302
^Z
[2]+  Durdu                   sleep 302
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 301 &
[2]+  Durdu                   sleep 302
taylan@taylan:~$ jobs -s
[2]+  Durdu                   sleep 302
taylan@taylan:~$
```

`x` seçeneğini kullanarak; mevcut kabuktaki işlerin işlem numaralarını(pid) alıp başka bir komuta argüman olarak verebiliriz. Örneğin birkaç yeni işlem başlatıp en son işlemin işlem numarasını ekran bastırmayı deneyelim. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2157
taylan@taylan:~$ sleep 102 &
[2] 2158
taylan@taylan:~$ sleep 103 &
[3] 2159
taylan@taylan:~$ jobs
[1]   Çalışıyor           sleep 101 &
[2]-  Çalışıyor           sleep 102 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ jobs -x echo %3 
2159
taylan@taylan:~$ jobs -l
[1]   2157 Çalışıyor           sleep 101 &
[2]-  2158 Çalışıyor           sleep 102 &
[3]+  2159 Çalışıyor           sleep 103 &
taylan@taylan:~$ jobs -x echo %3 
2159
taylan@taylan:~$
```

Biz burada yalnızca işlem numarasını `echo` komutu yardımıyla bastırdık fakat sizler dilediğiniz komuta işlem numaralarını argüman olarak verebilirsiniz. Örneğin `kill` komutuna `jobs -x kill -9 %%` şeklinde argüman olarak verdiğinizde mevcut kabuktaki en son çalıştırılan görev sonlandırılır. Özetle işlem numarası ile çalışabilecek tüm komutlara, mevcut kabuk üzerinde çalıştırılmış olan görevlerin işlem numaralarını iletebilirsiniz.

Mevcut kabuktaki görevleri belirtirken yüzde işareti `%` kullandığımızı fark etmişsinizdir. Bu işaret işi belirtme anlamında yani "jobspec" olarak anılır. İşleri `jobs` komutu ile sıraladığımızda sol tarafta zaten iş numaraları sıralı şekilde listeleniyor. Bu numaraları ya da alternatif kısayolları kullanarak mevcut kabuk üzerindeki işleri kolayca kontrol edebiliriz. Kullanım örnekleri için aşağıya göz atabilirsiniz.

`%iş_numarası` : iş numarası belirtilmiş işlemi kapsar.

`%komut` : tam komut adı belirtilmiş işi kapsar.

`%+` ya da `%%` : her iki kullanım da iş tablosundaki en son işi kapsar.

`%-` : iş tablosundaki sondan bir önceki işi kapsar.

Aşağıdaki çıktılara bakarak bu durumu kendiniz de teyit edebilirsiniz.

```bash
└─$ sleep 201&
[1] 3013
└─$ sleep 202&
[2] 3014
└─$ sleep 203&
[3] 3015
└─$ sleep 204&
[4] 3016
└─$ jobs -l
[1]   3013 Running                 sleep 201 &
[2]   3014 Running                 sleep 202 &
[3]-  3015 Running                 sleep 203 &
[4]+  3016 Running                 sleep 204 &
└─$ jobs -x echo %%
3016
└─$ jobs -x echo %+
3016
└─$ jobs -x echo %-
3015
└─$ jobs -x echo %1
3013
```

Zaten `jobs` komutunun çıktılarında da en son görev için artı ve en sondan bir önceki için eksi işareti açıkça görülebiliyor. Burada jobs komutu için kullandığımız jobspec "%" kısayolları aynen diğer iş kontrol komutları için de geçerlidir. Yani iş kontrolü için kullanılan "bg, fg, kill, jobs, wait, disown, nohup, suspend" komutlarının hepsinde aynı yaklaşımı izleyebilirsiniz. 

## wait Komutu

### Arka Plandaki İşlemlerin Beklenmesi

İşlemler arka planda çalışırken birbirlerini beklemezler. Bu durumun kanıtı olarak aşağıdaki örneğe bakabiliriz.

time (sleep 5 | sleep 10 | sleep 15)

Bu komut aynı anda arka planda üç çocuk işlem başlatacaktır. Eğer arka plandaki bu işlemler birbirini bekliyor olsaydı tüm pipeline üzerindeki işlemlerin bitmesi 30 saniye sürecekti. Ancak arka plandaki işlemler aynı anda çalışır, özellikle belirtilmediği sürece birbirini beklemez. Bu sebeple aldığımız çıktı en uzun süren 15 saniyelik bekleyiş doğrultusunda oldu.

Aynı anda birden fazla işlemi arka planda çalıştırabilmek kabuğu verimli kılan bir avantajdır. Ancak, arka plandaki işlemlerin birbirini bekleyerek çalışmasını gerektirecek durumlar ile karşılaşabiliriz. 

Örneğin arkaplandaki bir sürecin sonunda bir klasör oluşturulacaksa ve daha sonra bu oluşturulan klasöre geçiş yapılacaksa tüm komutların sırasına uygun şekilde hareket etmesi gerekir. Aşağıdaki çıktıları inceleyerek `wait` komutunun önemini daha net görebilirsiniz.

```bash
#!/bin/bash

sleep 5 & mkdir yeni_dizin & #5 sn. dur ve klasör oluştur.
cd yeni_dizin #klasöre geçiş yap
pwd #bulunduğun dizin adresini bastır.
```

Betik dosyası çalıştırıldığında elde edilen çıktı;

```bash
taylan@taylan:~$ bash yeni.sh 
yeni.sh: satır 4: cd: yeni_dizin: Böyle bir dosya ya da dizin yok
/home/taylan
taylan@taylan:~$
```

Eğer `wait` komutunu eklersek, arkaplandaki klasör oluşturma sürecinin bitmesi bekleneceği için hata almadan ilgili dizine geçiş yapılabilir.

```bash
#!/bin/bash

sleep 5 & mkdir dizin & #5 sn. dur ve klasör oluştur.
wait #arkaplandaki süreçin bitmesini bekle
cd  dizin #klasöre geçiş yap
pwd #bulunduğun dizin adresini bastır.
```

```bash
taylan@taylan:~$ bash yeni.sh 
#5 saniye kadar bekliyoruz...
/home/taylan/dizin
taylan@taylan:~$
```

Burada biz işlem numarası(pid) ya da iş numarası(jobspec) belirtmeden direk arka planda çalışacak işlemin ardından `wait` komutunu kullandık. Bu kullanımda, mevcut tüm çocuk işlemler beklenir. Ancak dilerseniz, işlem numarası veya iş numarası belirterek de ilgili işlemin bitmesinin beklenmesini sağlayabilirsiniz. 

```jsx
└─$ sleep 30&                                                                             
[1] 1174
└─$ wait %1                                                                           
bu
bir
komut
[1]+  Done                    sleep 30
└─$ bu                                                                                    
bu: command not found
└─$ bir                                                                                   
bir: command not found
└─$ komut                                                                                 
komut: command not found
└─$ sleep 30&                                                                             
[1] 1184
└─$ wait 1184                                                                           
bu
bir
komut
[1]+  Done                    sleep 30
└─$ bu                                                                                    
bu: command not found
└─$ bir                                                                                   
bir: command not found
└─$ komut                                                                                 
komut: command not found
```

-n seçeneği kullanıldığında, komut, verilen işlem numarasından veya iş numarasından yalnızca tek bir işin tamamlanmasını bekler ve çıkış durumunu döndürür. 

```jsx
└─$ sleep 30& sleep 35& sleep 40&                                                         
[2] 1188
[3] 1189
[4] 1190
└─$ wait -n %2 %3 %4
[2]   Done                    sleep 30
```

Eğer işlem ya da iş numarası verilmezse, `wait -n` herhangi bir arka plan işinin tamamlanmasını ve iş çıkış durumunu döndürmesini bekler.

```jsx
└─$ sleep 30& sleep 35& sleep 40&                                                      
[1] 1191
[2] 1192
[3] 1193
└─$ wait -n
[1]   Done                    sleep 30
```

Basit bir betik üzerinden `wait` ile `wait -n` kullanımının farkına örnek verelim.

```
#!/bin/bash
sleep 5 &
sleep 10 &
sleep 15 &
wait -n
echo "İlk iş tamamlandı."
wait
echo "Tüm işler tamamlandı."
```

Komut dosyası yürütüldüğünde, 3 arka plan işlemi ortaya çıkarır. `wait -n` ilk işin tamamlanmasını bekler. `wait` ise tüm alt arka plan işlerinin tamamlanmasını bekler.

Burada bahsi geçen çıkış durumu, işlemin tamamlandığında döndürdüğü durum kodudur. Eğer işlem sorunsuzca çalıştıysa 0, eğer başka bir durum varsa 0 harici bir kod döndürülür. Bu konunun detayına daha sonra tekrar değineceğiz.

Eğer ilk tamamlanan işlemin işlem numarası lazımsa, bunu `-p` seçeneği ile elde edebilirsiniz. `p` seçeneğini kullanarak bir değişkene, ilk kapanan işlemin işlem numarasını atayabilirsiniz.

```jsx
└─$ sleep 30& sleep 35& sleep 40&
[4] 1205
[5] 1206
[6] 1207
└─$ wait -p islem_no -n
[4]   Done                    sleep 30
└─$ echo $islem_no
1205
```

`p` seçeneği Bash 5.1 sürümüyle birlikte geldi. Daha eski bir Bash sürümü kullanıyorsanız, "geçersiz seçenek" hatası alırsınız. Çok sık kullanılmasa da ihtiyaç duyacağınız bir an olabilir.

`-f` seçeneği kullanıldığında, ilgili işlemin tamamen bitmesi beklenir. Normalde wait komutu ilgili işlemin iş durumu değiştiğinde, durma, arka veya ön plana alınma gibi durumlara kadar bekler. Ancak -f seçeneği kullanıldığında ilgili işlemin iş durumu değişse bile işlem tamamen sonlandırılana dek bekleme devam eder.

Denemek için arka planda yeni bir işlem başlatalım ve bu işlemin wait ile beklenmesini sağlayalım.

```jsx
─$ sleep 300&                                                                            
[1] 1277
└─$ wait 1277
```

Şimdi yeni bir konsol üzerinden, bu işlemi `kill -STOP işlem_numrası` komutu ile duraklatalım.(kill komutu ile durdurma "STOP" sinyali gönderdik. kill komutundan ve sinyallerden daha sonra bahsedeceğiz. )

```jsx
-$ kill -STOP 1277
```

Bu komutun hemen ardından, wait yani bekleme sona eriyor ve ilgili işlemin son durumu konsola basılıyor. 

```jsx
└─$ wait 1277                                                                             

[1]+  Stopped                 sleep 300
```

Eğer aynı örneği bu kez -f seçeneği ile uygularsak, işlemin durumunun değişmesi `wait` komutunun çalışmasını etkilemeyecektir. `wait` komutu işlem sonlanana yani bitene kadar bekleyecektir.

```jsx
└─$ wait -f 1295                                                                          

[2]+  Stopped                 sleep 300
komut
giremiyorum
```

### disown Komutu

`disown` komutu bash kabuğu içerisinde yerleşik(builtin) olarak bulunan bir komuttur. Temel görevi kendisine argüman olarak verilmiş işlemin, kabuk üzerinde tutulan iş kontrolü(job control) listesinden çıkarmaktır. Yani hedef süreç çalışmaya devam eder fakat işlemin iş kontrol(job control) tablosundan çıkarılması sağlanır. Bu sayede konsol kapatılsa dahi işlemin arka planda çalışmaya devam etmesi sağlanır. Normal şartlarda işlemin çalıştırıldığı kabuk kapatılırken **SIGHUP** sinyali ile iş tablosundaki mevcut işler kabukla birlikte kapatılır.(Sinyaller konusundan daha sonra bahsedeceğiz.) Eğer `disown` komutu kullanıldıysa, işlemler iş tablosunda yer almayacağı için SIGHUP sinyaline de doğal olarak maruz kalmazlar.

<aside>
⚠️ Not: Örnekler esnasında kullanılan "gedit" aracı sadece basit bir metin düzenleme aracıdır. Bu araç dışında sizler test etmek için dilediğiniz herhangi bir aracı, yeni işlem başlatmak için kullanabilirsiniz.(Mümkünse grafiksel arayüze sahip bir uygulama seçin çünkü grafiksel arayüze sahip uygulamaların takibi görsel olarak daha kolaydır.) Ayrıca `sleep` komutu da benzer şekilde takip edilebilir yeni bir işlem başlatmak için kullanılmış olan bash kabuğundaki "belirtilen süre kadar bekletme" işlevini sağlayan test amaçlı kullanılmış bir komuttur. (Daha fazla bilgi için komutun açıklama sayfasına göz atabilirsiniz.)

</aside>

En temel kullanımı `disown işlem_numarası` şeklindedir. Elbette bu komutun(`disown`) mevcut kabuk üzerinde yazılabilmesi için ilgili işlemin arka planda başlatılması ya da başlatıldıktan sonra arka plana alınması gerekiyor. Bahsetmiş olduğumuz durumu test etmek için "gedit" isimli metin editörünü `gedit&` komutu ile arka planda başlatalım. Daha sonra konsolu kapatıp "gedit" aracının da kapatılıp kapatılmadığını teyit edelim. Bu işlemin ardından "gedit" aracının konsol yani mevcut kabukla birlikte sonlandırıldığına şahit oluyoruz. 

Bu durumu önlemek için `disown` komutunu kullanabiliriz. Test etmek için tekrar "gedit" aracını `gedit &` komutu ile arkaplanda çalıştıralım ve `jobs -l` komutu ile mevcut kabuk üzerinden çalıştırılmış olan işlerin işlem numaralarını listeleyelim. Daha sonra `disown` komutunun ardından işlem numarasını girip, işlemin iş tablosundan silinmesini sağlayalım. İş tablosundan silinip silinmediğini teyit etmek için tekrar `jobs -l` komutunu kullanabiliriz. Aldığımız çıktıda "gedit" aracı yer almamasına karşın "gedit" işlemi arka planda çalışmaya devam ediyor. Son olarak testi tamamlamak adına mevcut kabuğumuzu da kapatalım. Kabuğu kapattığımızda "gedit" aracının çalışmaya devam ettiğini de teyit edebiliyoruz. İşte `disown` komutu bu şekilde arka plandaki işlemleri iş tablosundan çıkararak kabuğun çıkarken uyguladığı HUB kapatma sinyalinden muaf tutuyor.

**Ek bir bilgi olarak;** eğer bizler işlem numarasını belirtmezsek yani `disown` komutunu tek başına kullanırsak, en son çalıştırılmış olan işlem üzerinde etkili olacaktır. Bu sebeple `gedit & disown` komutunu kullanarak doğrudan gedit aracının arka planda iş tablosuna yazılmadan çalışmasını sağlayabiliriz. 

Örneklerimizi işlem numarası üzerinden yaptık ancak işlem numarası yerine `j`obspec yani % yüzde işareti ile iş numarasını da kullanabiliriz. Örneğin arka planda birden fazla işlem başlatıp bu işlemleri iş numaralarını kullanarak sonlandıralım. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2660
taylan@taylan:~$ sleep 102 &
[2] 2661
taylan@taylan:~$ sleep 103 &
[3] 2662
taylan@taylan:~$ jobs
[1]   Çalışıyor           sleep 101 &
[2]-  Çalışıyor           sleep 102 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ disown %2
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 101 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ 
```

## Bu Komuta Ne Zaman İhtiyacımız Olur ?

Bu komutun kullanım alanı için; örneğin konsol üzerinden kabuğunuza komut vererek bir araç çalıştırdınız. Bir süre sonra konsol ile işiniz bittiğinde konsolu kapatmak fakat çalıştırmış olduğunuz aracın çalışmaya devam etmesini isterseniz `disown` komutunu kullanabilirsiniz. 

Bu temel kullanımı dışında ayrıca `disown` komutunun alabildiği birkaç seçenek de bulunuyor;

## İş Tablosundan Silmeden HUB Sinyaline Karşı Korumak

`disown` komutu ile `-h` seçeneği kullanıldığında işlem iş tablosundan çıkarılmaz fakat SIGHUB sinyaline karşı korunur. Denemek için gedit aracını arka planda başlatalım. Başlattıktan sonra `jobs -l` komutu ile işlemin iş tablosunda yer aldığını teyit edebiliriz. Teyit ettikten sonra `disown -h işlem_numarası` şeklinde komutumuzu girelim ve tekrar iş tablosunu listelemek üzere `jobs -l` komutunu verelim. İş tablosundan gedit işleminin silinmediğini görebiliyoruz. Şimdi testi tamamlamak için mevcut kabuğumuzu kapatalım. Kabuğumuzu kapattığımızda gedit aracı çalışmaya devam ediyor.  Çünkü bizler `disown -h` komutu ile iş listesinden çıkarmadan işlemin HUB sinyali ile kapatılmasını önledik.

## Mevcut Kabuktaki Tüm İşlemleri İş Tablosundan Silmek ve HUB Sinyaline Karşı Korumak

`disown` komutunun, `-a` seçeneği kullanıldığında tüm işlemleri iş tablosundan kaldırarak **SIGHUB** sinyaline karşı korunur. Üstelik iş tablosunda yer alan işlemlerin çalışıyor ya da durdurulmuş olması fark etmez. Hemen denemek için `sleep 101 &` komutu ile arka planda ilk işlemimizi başlatalım, daha sonra `sleep 102` komutunun ardından "**Ctrl + Z"** tuşlaması ile başlatmış olduğumuz ikinci işlemi durduralım. Konsola `jobs -l` komutunu girdiğimizde ilk işlem & işareti sayesinde arka planda çalışmaya devam ederken ikinci işlemin **Ctrl + Z** tuşlaması sayesinde duraklatılmış olduğunu teyit edebiliyoruz. Şimdi tüm bu işlemleri iş tablosundan kaldırmak istersek `disown -a` komutunu girmemiz yeterli. Bu komutun ardından tekrar `jobs -l` komutunu girerek iş tablosunun silinmiş olduğunu görebiliyoruz. Bu da mevcut kabuk kapatılırken bu işlemlerin kapatılmayacağı(kabuk kapatılırken HUB sinyalinden etkilenmezler) anlamına geliyor.

## Mevcut Kabukta Çalışmakta Olan İşlemleri İş Tablosundan Silmek ve HUB Sinyaline Karşı Korumak

Eğer yalnızca arka planda **çalışmakta olan** tüm işlemleri tek seferde `disown` komutu ile kapsamak istersek `-r` seçeneğini kullanabiliriz. Bir üst başlıkta bahsetmiş olduğumuz özelliğe benzer şekilde çalışır fakat bu seçenekte durdurulmuş olan işlemler dahil edilmeden yalnızca çalışmakta olan işlemler dikkate alınır. Denemek için arka planda iki adet işlem başlatıp üçüncü işlemi de **Ctrl + Z** kısayolu(bu kısayol mevcut işleme durdurma sinyali göndermemiz sağlar) ile durduralım. Ve tüm bu süreci `jobs -l` komutu ile teyit edelim.

```bash
taylan@taylan:~$ jobs -l                                                  
taylan@taylan:~$ sleep 201 &
[1] 2247                                                                  
taylan@taylan:~$ sleep 202 &                                             
[2] 2248                                                                  
taylan@taylan:~$ sleep 203
^Z
[3]+  Durdu                   sleep 203
taylan@taylan:~$ jobs -l
[1]   2247 Çalışıyor           sleep 201 &
[2]-  2248 Çalışıyor           sleep 202 &
[3]+  2250 Durduruldu              sleep 203
taylan@taylan:~$
```

Şimdi de yalnızca çalışmakta olan işlemleri kapsamak üzere konsola `disown -r` komutunu girelim. Buradaki `r` ifadesi zaten İngilizce olarak "**r**unning" yani "çalışan" ifadesinin kısaltmasından geliyor. Bu komutun hemen ardından iş tablosuna göz atmak üzere tekrar `jobs -l` komutunu girerek yalnızca çalışmakta olan işlemlerin iş tablosundan silindiğini teyit edebiliriz.

```bash
taylan@taylan:~$ disown -r
taylan@taylan:~$ jobs -l
[3]   2250 Durduruldu              sleep 203
taylan@taylan:~$
```

## HUB Sinyaline Karşı disown Komutu ile Korunmuş Olan İşlemi Sonlandırmak

Bu bölüme kadar `disown` komutunun kabuk kapatılırken çalıştırılan HUB kapatma sinyalinden işlemleri koruyabildiği üzerinde durduk. Fakat kullanıcı istediğinde `disown` komutu ile korunmuş olan işleme özellikle HUB kapatma sinyalini gönderip, işlemin sonlanmasını sağlayabilir. Çünkü `disown` komutunun asıl amacı, kabuk kapatılırken oluşturulan HUB sinyaline karşı işlemi koruyarak kabuk kapatılsa dahi ilgili işlemin devam edebilmesidir. Koruma altındaki işlemi sonlandırmak için `kill -s HUP işlem_numarası` şeklinde komutumuzu girmemiz yeterlidir. Grafiksel arayüze sahip bir araç ile test ettiyseniz, HUB sinyalini gönderdiğinizde aracın kapandığını teyit edebilirsiniz.

## Son Olarak

Eğer işleminiz kullanıcını `kill` komutunu girse dahi yani HUB sinyali özellikle gönderilse dahi sonlandırılsın istemezseniz `nohup` isimli komutu kullanabilirsiniz. `disown` komutu ile `nohup` komutu arasındaki fark, `nohup` ile başlayan işlemin, sinyali kimin gönderdiği fark etmeksizin HUP yani kapatma sinyalini yok saymasıdır. 

Eğer `nohup` komutu hakkında bilgi sahibi değilseniz mutlaka buradan komutun açıklamasına da ayrıca göz atın.

### nohup Komutu

Normal şartlarda kabuk üzerinden çalıştırılmış olan tüm araçlar kabuk kapatılırken sonlandırılır. Eğer bizler kabuk kapanırken araçlarımız çalışmaya devam etsin istersek `nohup` komutunu kullanabiliriz. Yerleşik komut değildir.

`nohup`, kabuk kapatılırken mevcut kabuk üzerindeki tüm işlemlere gönderilen HUP kapatma sinyalini görmezden gelerek kendisine argüman olarak verilmiş olan işlemi bu kapatma sinyaline karşı korur.

En temel kullanımı `nohup korunacak_işlem` şeklindedir. Hemen denemek için "gedit" isimli grafiksel arayüze sahip metin editörünü konsol üzerinden çalıştıralım. Aracımız çalıştıktan sonra, aracımızı çalıştırdığımız konsolu(dolayısı ile konsola bağlı bulunan kabuğu) kapattığımızda "gedit" aracının da kapatıldığını görebiliyoruz. Eğer konsol kapatılsa da "gedit" aracı çalışmaya devam etsin istersek "gedit" aracını `nohup gedit` komutu ile çalıştırmamız gerekiyor. Bu komutun ardından konsol aracını kapattığımızda "gedit" aracının çalışmaya devam ettiğini teyit edebiliyoruz. 

nohup komutu ilgili işlemi kabuktan bağımsız kıldığı için elbette kabuğun sunduğu imkanları da kaybetmiş oluyor. Bu durum "gedit" gibi grafiksel arayüz üzerinden çalışan uygulamaları pek etkilemiyor olsa da konsol üzerinden çalıştırılan ve kullanıcı ile etkileşim kurması gereken uygulamaları etkiler. Bu ne anlama geliyor ? Bizler konsol üzerinden bir işlem başlatırken aslında "stdin" "sterr" "stout" olarak ifade edilen üç dosya tanımlayıcısına sahip oluyoruz. 

**stdin olarak geçen yapı;** standart input yani kullanıcının klavyesi ile yazdığı veri girişleridir.

**stderr olarak geçen yapı;** standart error yani çalıştırılmış olan aracın ürettiği hata çıktılarıdır.

**stdout olarak geçen yapı;** standart output yani çalıştırılan aracın çalışması sonucu üretilmiş olan çıktılardır.

İşte bizler nohup komutu ile bir aracı çalıştırdığımızda bu araç konsol üzerinden input almıyor ve çıktılarını kullanıcının ev dizini altında nohup.out adlı bir dosyaya kaydediyor. Çünkü nohup komutunun yapısı gereği çalıştırılan aracı konsoldan ayırdığı için, ilgili aracın input alabileceği ya da çıktıları kullanıcılara aktarabileceği bir konsol olmuyor. Standart çıktıları(stdout) ve standart hataları(stdout) hepsini nohup.out dosyasına kaydediyor. Hemen denemek için basit bir betik dosyası oluşturalım. 

Ben kullanıcıdan komut alıp bu komutu bastıracak ve en sonunda aslında hiç olmayan bir komutu çalıştırmayı deneyecek bir betik oluşturuyorum. Betik dosyam aşağıdaki şekilde. 

```bash
read -p "Veri girin:" veri
echo "Girdiğiniz veri:$veri"
olmayan-komut
```

Bu dosyayı standart şekilde konsol üzerinden çalıştırdığımızda bizden veri alıp bu veriyi ve en son hatalı komutun hata çıktısını konsola basıyor.

```bash
taylan@taylan:~$ bash betik.sh                                            
Veri girin:bu bir veri girişidir                                          
Girdiğiniz veri:bu bir veri girişidir                                     
betik.sh: satır 3: olmayan-komut: komut yok                               
taylan@taylan:~$
```

Şimdi aynı betik dosyasını `nohup` komutu ile konsoldan bağımsız şekilde çalıştırmayı deneyelim.

```bash
taylan@taylan:~$ nohup ./betik.sh                                         
nohup: girdi gözardı ediliyor ve çıktı 'nohup.out' e ekleniyor            
```

Gördüğünüz gibi betik dosyası çalıştırıldı fakat bizlerden herhangi bir veri girişi istemedi ya da konsola çıktı bastırmadı. Çıktıların '**nohup.out**' dosyasına eklendiğini belirtti sadece. Bu dosyanın içeriğini de `cat` komutu ile okuyarak bu durumu teyit edebiliyoruz.

```bash
taylan@taylan:~$ cat nohup.out 
Girdiğiniz veri:
./betik.sh: 3: olmayan-komut: not found
taylan@taylan:~$
```

`nohup` komutu ile hangi aracı çalıştırırsak çalıştıralım aracın ürettiği konsol çıktıları bu dosyaya alt alta ekleniyor olacak. Eğer isterseniz bu varsayılan dosya konumunu da dilediğiniz şekilde değiştirebilirsiniz. Örneğin ben tüm çıktıların "Belgeler" dizini altında "çıktı.txt" isimli bir dosyaya gönderilmesini istersem çıktıları büyüktür işareti `>` ile yönlendirebilirim.

```bash
taylan@taylan:~$ nohup ./betik.sh > Belgeler/çıktı.txt
nohup: girdi gözardı ediliyor ve stderr stdout'a gönderiliyor
taylan@taylan:~$ cat Belgeler/çıktı.txt 
Girdiğiniz veri:
./betik.sh: 3: olmayan-komut: not found
taylan@taylan:~$
```

Konsoldan bağısız olan işlemi sonlandırmak istersek de tek yapmamız gereken işlem numarasını `pgrep` komutu yardımıyla öğrenip `kill işlem_numarası` şeklinde sonlandırmaktır.

```bash
taylan@taylan:~$ pgrep "gedit"
3706
taylan@taylan:~$ kill 3706
taylan@taylan:~$ pgrep "gedit"
taylan@taylan:~$
```

Fakat `nohup` komutu ile başlatılmış bir işleme HUP kapatma sinyali işlemeyecektir. Zaten `nohup` komutunun ana işlevi de başlatılmış olan süreci HUP kapatma sinyaline karşı korumaktır. Zaten komutun adı da buradan geliyor. HUP sinyali hariç diğer kapatma yöntemleri işlemi sonlandırabilir. Bu durumu teyit etmek için `nohup` ile başlattığınız işlemi `kill -s HUP işlem_numarası` komutu ile sonlandırmayı deneyebilirsiniz.

`nohup` komutunun bash kabuğunda yerleşik olarak bulunan `disown` isimli alternatifi vardır. 

`disown` ile `nohup` arasındaki en temel farklılıklar;

`disown` yalnızca kabuk kapatılırken gönderilen HUP sinyaline karşı korurken, `nohup` ne şekilde geldiğine bakılmaksızın HUP sinyalinden ilgili işlemi korur.

`disown` komutu arka plandaki işlemler üzerinde etkilidir yani öncelikle işlem çalıştırılıp arka plana alınmalı daha sonda `disown` komutu çalıştırılmalıdır. 

`nohup` komutu ise ilgili işlemden önce belirtilmelidir.

Kullanım alanlarına bakacak olursak; örneğin konsol üzerinden bir araç çalıştırdığınız ve konsolu kapatıp aracın açık kalmasını istiyorsunuz. Bu durumda aracı duraklatıp arkaplana alabilir ve `disown` komutu ile konsol kapansa dahi çalışmaya devam etmesini sağlayabilirsiniz. `nohup` komutu ise aynı durumun daha planlı şekilde yapılışıdır. Yani zaten konsolu ya da daha doğrusu mevcut kabuğu kullanmayacağınız önceden belli ise doğrudan `nohup` komutunun ardından çalıştırmak istediğimiz aracı yazabilirsiniz. Genelleyecek olursak `nohup` daha çok planlı durumlar için `disown` ise daha sonradan verilen kararlar için kullanılabilir. 

## İşlem Önceliğini Ayarlama | `nice` ve `renice`

[https://www.tecmint.com/set-linux-process-priority-using-nice-and-renice-commands/](https://www.tecmint.com/set-linux-process-priority-using-nice-and-renice-commands/)

## İş Yönetimi ve Sinyaller Hakkında

Kabuk altında çalıştırılan işlemlerin, iş tablosuna eklendiğini ve bu sayede mevcut kabuk üzerinden işlemlerin kolayca yönetilebildiğini öğrendik. Ancak her zaman iş yönetimini kullanmak istemeyebilir ya da özellikle kullanamayacağımız durumlar ile karşılaşabiliriz. Bu noktada işlemleri yönetmek için sinyallerden yardım alırız.

Birkaç ayrıntıyı daha paylaşırsam, sanırım ele aldığımız ve alacağımız tüm kavramlar daha net anlaşılacaktır.

Başlatılan her işlemin benzersiz bir işlem numarası(pid) olduğunu biliyoruz. Pipe gibi yapılar sayesinde tek seferde birden fazla işlemi içeren işlem grupları oluşturabildiğimizi de biliyoruz. Tek seferde çalıştırılmış olsa da elbette işlem grubundaki her bir işlem benzersiz işlem numarasına sahiptir. İşlem numarası haricinde bir de işlem grubundaki tüm işlemler, işlem grubu numarası(process group ID) olarak geçen ortak pgid'a sahiptirler. Bu sayede, gerektiğinde işlem grubu içerisinde yer alan ve farklı işlem numaralarına sahip tüm işlemleri tek bir pgid üzerinden kontrol edebiliriz. pgid sayesinde tek seferde hepsini duraklatabilir, arka ya da ön plana alabilir veya sonlandırabiliriz. Zaten kabuk üzerinde bulunun iş kontrol mekanizması da bu bilgiden yararlanarak çalışır. 

Tek bir işlem çalıştırıldıysa;

Benzersiz bir işlem numarasına(pid) sahiptir.

Ebeveyn işlem numarası(ppid), onu çalıştıran bir önceki işlemin işlem numarasıdır(pid).

Tekil bir işlem olduğu için işlem gurubu numarası(pgid), işlem numarası(pid) ile aynıdır.

Çıktılara bakarak teyit edebilirsiniz.

```jsx
└─$ sleep 111 &
[1] 1987
└─$ ps o pid,ppid,pgid,command
    PID    PPID    PGID COMMAND
   1980    1977    1980 /usr/bin/bash
   1987    1980    1987 sleep 111
   1988    1980    1988 ps o pid,ppid,pgid,command
```

Aynı görev için birden fazla işlem pipe ile çalıştırıldıysa;

Her bir işlemin işlem numarası(pid) benzersizdir.

İşlemlerin ebeveyn işlem numaraları(ppid), işlem gurubu çalıştıran işlem numarasıdır(pid). 

İlk çalıştırılan işlemin işlem numarası(pid), tüm işlem grubunun işlem gurubu numarasını(pgid) olarak tanımlanır.

Çıktılara bakarak teyit edebilirsiniz.

```jsx
└─$ sleep 111|sleep 222| sleep 333&
[1] 2004
└─$ ps o pid,ppid,pgid,command
    PID    PPID    PGID COMMAND
   1995    1992    1995 /usr/bin/bash
   2002    1995    2002 sleep 111
   2003    1995    2002 sleep 222
   2004    1995    2002 sleep 333
   2005    1995    2005 ps o pid,ppid,pgid,command
```

Yapı gereği harici bir kabuktan, başka bir kabuktaki işleri kontrol etmek için fg, bg, ^Z, ^C ve benzerlerini kullanamazsınız. Yani farklı kabuk ortamlarında çalıştırılmış olan işlemler üzerinde iş kontrolüne sahip değilsiniz. İş kontrolü, yalnızca işlemlerin başlatılmasına aracılık eden kabuktadır. Her kabuk kendine özel iş tablosu tutar. Dolayısıyla başka bir kabuk üzerinden örneğin arka plandaki işlemleri görebilirken, bunları iş kontrolünü kullanarak ön plana alamazsınız. 

Eğer farklı bir kabuk üzerinden çalıştırılmış işlemlere durdurma devam ettirme gibi müdahalelerde bulunmak istiyorsanız, sinyalleri kullanabilirsiniz. İlgili işlemin işlem numarasını bildiğiniz sürece kill komutu ile sinyal gönderebilirsiniz.