# İş Kontrolü | Job Control

İş kontrolü ile her çocuk kendi PGID'sini alır. İş kontrolü olmadan, ebeveynin PGID'sini devralırlar. Ancak, bir süreç grubu lideri değilse, ebeveyn PGID'sini ebeveyninden devralmış olabilir.

Bir işlem yetim kaldıysa, onu farklı bir kabuğa "yeniden ebeveynleştiremez" ve onu kontrol etmek için fg, bg, ^Z, ^C ve benzerlerini kullanamazsınız. Yani farklı kabuk ortamlarında çalıştırılmış olan işlemler üzerinde iş kontrolüne sahip değilsiniz. İş kontrolü, yalnızca işlemlerin başlatılmasına aracılık eden kabuktadır. Her kabuk kendine özel iş tablosu tutar. Dolayısıyla başka bir kabuk üzerinden örneğin arkaplandaki işlemleri görebilirken, bunları iş kontrolünü kullanarak ön plana alamazsınız. 

Eğer farklı bir kabuk üzerinden çalıştırılmış işlemlere duruduma devam ettirme gibi müdahalelerde bulunmak isitorsanız, sinyalleri kullanabilirsiniz. İlgili işlemin işlem numarasını bildiğiniz sürece kill komutu ile sinyal gönderebilirsiniz.

[https://tldp.org/LDP/abs/html/x9644.html](https://tldp.org/LDP/abs/html/x9644.html)

İşlemin temelde ne olduğunu artık biliyoruz. Mevcut kabuk üzerinde bir işlem çalıştırılırken, ilgili işlemin çalışması bitmeden kabuk yeni komutlar almaz. Zaten işlem oluşturma mekanizmasından bahsederken ebeveyn işlemin, çocuk işlemin sonlanmasını beklediğini belirtmiştik. Ancak kabuğun, yalnızca tek bir işlemle meşgul olması özellikle etkileşimli kabuk kullanımında pek verimli bir yaklaşım değildir. Sistem yönetiminde verimli olabilmesi için kabuğun, işlemleri arka planda başlatabilmesi veya arka plana alabilmesi yani işlemleri beklemek zorunda olmaması ve gerektiğinde başlatılan işlemleri duraklatabilme, devam ettirebilme ve sonlandırabilme kabiliyetinin olması gerekir. Bu duruma çözüm olarak bash kabuğu, kendi altında çalıştırılan işlemlere bir "iş" gözüyle bakma yaklaşımına gitmiştir. 

Kabuk, kendisi üzerinden başlatılmış olan tüm işlem gruplarını iş tablosu olarak geçen bir tabloda tutar. Her kabuğun kendine ait iş tablosu vardır. Bu tablo sayesinde mevcut kabuk üzerinde çalıştırılan işlemlerin gerektiğinde durdurulması, arkaplana alınması veya arkaplandaki işlemlerin tekrar ön plana alınması gibi etkileşimli kullanımda hayatımızı kolaylaştıracak imkanlar, süreç numaraları ile uğraşmaya gerek kalmadan yerine getirilebilir.

Bilmeyenler için işlemlerin durdurulması, arkaplanda ve önplanda çalışmasına kısaca değinelim.

Kabuğun standart çalışma şekli ön planda çalışan işlemi temsil eder. Normal şartlarda kabuk, emirleri sırasıyla tek tek alır ve bir işlem çalışmayı bitirmeden bir diğer işlemi çalıştırmaz. Bu durumu deneyimlemek için konsola `sleep 5` komutunu girip hemen ardından kabuğa başka bir emir vermeye deneyebilirsiniz.

```jsx
└─$ sleep 5
echo deneme
└─$ echo deneme
deneme
```

Örnekteki durumda, `sleep` işlemi 5 saniye boyunca çalıştığı için kabuk `echo deneme` komutunu `sleep` işlemi bitmeden değerlendiremedi, çünkü kabuk `sleep` komutunu bekliyordu. `sleep` işlemi biter bitmez vermiş olduğumuz komut kabuk tarafından işlenmiş oldu. Neticede standart davranış gereği işlemin önplanda başlatılıp, ilgili işlem bitmeden bir diğerinin çalıştırılmadığını bizzat teyit ettik. 

Eğer bizler halihazırda bir işlem çalışıyorken kabuğa yeni komutlar girebilmek istersek, işlemi arkaplanda başlatmamız ya da duraklatıp arkaplana almamız yeterlidir. Bu sayede işlem arkaplanda çalışamaya devam ederken bizler de kabuğa yeni komutlar verebiliriz. 

## İşlemleri Arkaplanda Başlatmak

Komutun sonuna ampersant işaretini eklediğimizde, ilgili işlem arkaplanda çalıştırılacaktır. Arkaplandaki işlem çocuk işlem olarak çalışır. 

```jsx
└─$ sleep 5&
[1] 28
┌──(I have no name!㉿DESKTOP-E4TGC85)-[~]
└─$ echo deneme
deneme
```

Peki arkaplandaki işlemi nasıl kontrol edeceğiz ? Başı boş mu kaldı ? Hayır. Bir işlem arkaplanda başlatıldığında veya arkaplana alındığında, mevcut kabuğun iş tablosuna eklenir. Bu tablo üzerindeki sıra numarası üzerinden işlemi kolaylıkla durdurup, devam ettirebilir, ön plana alabilir ya da sonlandırabiliriz. 

Aksi belirtilmedikçe ve iş kontrolü özelliği mevcut kabukta aktif olduğu sürece kabuk üzerindeki işlem gruplarının her biri bir iş olarak kabul edilir. Örneğin `sleep 11 &` komutunu girdiğimizde arkaplanda çalıştırılan `sleep` işlemi mevcut kabuğun iş tablosuna ekleniyor. Görmek için mevcut kabuktaki işlerin tablosunu bastıran `jobs` komutunu kullanabiliriz.

```jsx
└─$ sleep 11&
[1] 22
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ jobs
[1]+  Running                 sleep 11 &
```

Zaten arkaplanda bir komut çalıştırdığınız, çıktıdan da görebileceğiniz gibi komutun hemen ardından iş tablosundaki numarası da konsola basılıyor.  Çıktıdaki "[1]" işlemin iş tablosunda sıra numarasını, "22" ise işlemin işlem numarasını belirtiyor. 

Hali hazırda tüm işlemlerin işlem numaraları olduğu için ekstra iş tablosundaki numaraları ile uğraşmak belki ilk bakışta verimli gelmemiş olabilir. Sonuçta `ps` gibi bir araç ile işlemin işlem numarası öğrenilip `kill` komutu ile işleme sinyaller göndererek de iş kontrolüne benzer faaliyetlerde bulunabiliriz. Ancak iş kontrolü göründüğü kadar verimsiz değil.

Öncelikle, tüm sistemde çalışmakta olan işlemlere oranla iş tablosunda çok daha az işlem listelendiği için mevcut kabuk üzerinden çalıştırılan işlemlerin kontrolü ve takibi çok daha kolaydır. Ayrıca tek seferde birden çok işlemi arkaplanda başlatmanız ve bu işlemleri yönetmeniz de gerekebilir. Bu duruma pipeline harika bir örnektir.

Pipeline üzerinde yer alan komutlar, aynı anda arka planda birden fazla işlemin çalışmasına neden olur. Aynı anda birden çok işlem başlatılsa da pipeline üzerindeki işlem grubu da tek bir iş olarak iş tablosuna eklenir.  Bu sayede gerektiğinde pipline üzerinde yer alan tüm işlemleri tek seferde arka plana alma, ön plana alma veya tek seferde sonlandırma gibi etkileşimli kullanımda büyük bir kolaylığa sahip oluruz.

```jsx
└─$ sleep 11 | sleep 22 | sleep 33&
[1] 25
└─$ jobs
[1]+  Running                 sleep 11 | sleep 22 | sleep 33 &
```

Bu tablo mevcut kabuk üzerindeki işlemlerin işlem numaralarına ek olarak **jobspec** olarak geçen sıralı iş numaraları da tutar. Bu numaralar üzerinden gerektiğinde işlem numarasına ihtiyaç duymadan kolayca mevcut kabuk üzerindeki işlem üzerinde durdurma, arkaplana alma gibi kontrollere sahip oluruz.

İş kontrolü yapabilmemiz için işlemlerin arkaplanda çalıştırılması veya halihazırda önplanda çalışıyorsa durdurulup arkaplana alınması gerekiyor. Çünkü mevcut kabuk önplandaki iş ile meşgülken bizden yeni komut alamayacağı için elbette iş kontrolünü sağlamamız mümkün olmaz.

Örneğimizde de olduğu şekilde işlemleri arkaplanda başlatmak için ampersant `&` işaretini ilgili komutun sonunda kullanmamız yeterli. 

Eğer önplanda çalışmakta olan bir işlemi arkaplanda almak istersek öncelikle ilgili işlemi Ctrl+Z tuşlaması ile duraklatmamız gerekiyor. Daha sonra duraklatmış olduğumuz işlemin arkaplanda çalışmaya devam edebilmesi için `bg %iş_numarası` ya da `bg işlem_numarası` şeklinde komut vermemiz gerekiyor.

ctrl c ctrl z gibi klavye tarafından oluşturulan sinyalleri alabilmeleri için "terminal process group id" TPGID gurubu vardır. Mevcut terminal üzerinden başlatılan işlemler aynı terminal işlem grubundadır. Dolayısıyla bu işlemlere ctrl z ve ctrl c gibi kısayollar yanlızca ilgili terminal üzerinden geldiğinde işe yarar.

[bg Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/bg%20Komutu%20856b3c55ce0f4c62a7cc37175c06378b.md) 

[fg Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/fg%20Komutu%203ec8e8485c9b45fcbc1ee985031d4187.md) 

[jobs Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/jobs%20Komutu%20ac89ca11ecbd46fca44b5ba3178a5fd0.md) 

[wait Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/wait%20Komutu%207d4de8426a5d42d89cfc03047082364c.md) 

[nohup Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/nohup%20Komutu%20d6695d97dba147699ce296b5ffd82131.md) 

[disown Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/disown%20Komutu%20221d0dc6a3834731bc63cadb7d4e23f0.md) 

[suspend Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/suspend%20Komutu%200f017c165a624412a56266c95ceccf57.md) 

[logout Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/logout%20Komutu%20daf848dbd2904ef1817b37564314fb86.md) 

[kill Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/kill%20Komutu%2027b21f410df441ad94999c9680023be6.md) 

[times Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/times%20Komutu%204845fa5e717b47de8ac5c2a1c19f293d.md) 

[command Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/command%20Komutu%20a48d8704c1cb421f89427d9d067aaa3b.md) 

[enable Komutu](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/enable%20Komutu%209262cd8fd5644cc89bdc9c6e67ede412.md) 

[https://www.notion.so/builtin-Komutu-c8307cc43150499e9bb6633ac6a16f4a](../Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/builtin%20Komutu%20c8307cc43150499e9bb6633ac6a16f4a.md)

Ek olarak renice kavramından bahsedilebilir.

## İş Kontrol Değişkenleri

[https://www.gnu.org/software/bash/manual/html_node/Job-Control-Variables.html](https://www.gnu.org/software/bash/manual/html_node/Job-Control-Variables.html)

`auto_resume`

Bu değişken, kabuğun kullanıcı ve iş denetimi ile nasıl etkileşime gireceğini kontrol eder. Bu değişken varsa, yeniden yönlendirme içermeyen tek kelimelik basit komutlar, mevcut bir işin yeniden başlatılması için adaylar olarak değerlendirilir. Belirsizliğe izin verilmez; yazılan dize ile başlayan birden fazla iş varsa, en son erişilen iş seçilecektir. Bu bağlamda durdurulan bir işin adı, onu başlatmak için kullanılan komut satırıdır. Bu değişken "tam" değerine ayarlanırsa, sağlanan dize durdurulan işin adıyla tam olarak eşleşmelidir; "alt dize" olarak ayarlanırsa, sağlanan dizenin durdurulan bir işin adının bir alt dizesiyle eşleşmesi gerekir. 'Alt dizi' değeri, '%?' iş kimliğine benzer bir işlevsellik sağlar (bkz. İş Kontrolü Temelleri). Başka bir değere ayarlanırsa, sağlanan dize durdurulan işin adının öneki olmalıdır; bu, '%' iş kimliğine benzer işlevsellik sağlar.