# 2- Gerekli Çalışma Ortamının Kurulması

# Gerekli Ortamın Kurulması

Teknik anlatımlara geçmeden önce verimli bir çalışma sergileyebilmemiz için kendimize uygun çalışma ortamı kurmamız gerekiyor.

Kurulum rehberlerinde sizler için rahat olan çalışma ortamını oluşturmak adına macos windows linux android ve web üzerinden çalışabileceğiniz birden fazla alternatif ortamı ele aldım. Böylelikle kendiniz için ideal olan çalışma ortamını seçebilir ve eğitiminize kesintisiz şekilde devam edebilirsiniz.

Eğitimden maksimum verim alabilmek adına lütfen eğitim içeriğini, verilen müfredat sırasına göre takip edin.

Örnek olarak verilen komutların hepsini elle konsola girmenizin öğrenme süreci için önemli olduğunu da lütfen unutmayın. Ayrıca öğrendiğiniz her bilgiyi tekrar etmek adına mutlaka ama mutlaka birden fazla kez aralıklar ile farklı farklı örnekler üzerinden uygulayın.

Ön hazırlığı konuştuğumuza göre şimdi kurulum aşamalarına geçebiliriz.

# web

Hangi işletim sisteminizi kullandığınıza bakmaksızın tarayıcı üzerinden bash kabuk programlama yapabilmenize olanak sağlayan ücretsiz online web platformunu ele alacağız.

Bizlere bu imkanı sağlayan pek çok ücretsiz platform olsa da, ben yalnızca en kullanışlı bulduğum 2 platformu önereceğim. Yine de eğitimi takip ettiğiniz dönemde bu servisler hizmet vermiyor olabilir. Alternatiflerini araştırıp eğer mevcutsa kolayca bulabilirsiniz.

1# [repl.it](https://repl.it/languages/bash)
Muadilleri içerisinde en kullanışlı bulduğum platform **[repl.it](http://repl.it/) **
Bu platform bizlere sağladığı özellikler ile ihtiyacınız olan hemen her işlevi yerine getirmenize yardımcı oluyor. Üstelik kullanımı da oldukça kolay olduğundan çok kısa bir sürede çok rahat bir biçimde tüm özelliklerini kullanabiliyor olacaksınız.

2#[tutorialspoint.com](https://www.tutorialspoint.com/execute_bash_online.php)
Bu platformda oldukça kullanışlı olduğundan, ilk platforma herhangi bir sebepten ulaşamadığınız durumlarda kullanabileceğiniz bir alternatif olarak veriyorum.

Bu hizmetin de bizlere sunduğu pek çok kolaylık olduğunu belirterek, mutlaka bu platforma da göz atmanızı öneririm.

online interactive bash shell yazıp karşınıza çıkan herhangi bir servisi kullanabilirisniz. Burada benim özellikle önereceğim bir servis bulunmuyor. Sizler bizzat birden fazla servisi test edip hangisi ile daha rahat çalışabildiğinize kendiniz karar verebilirsiniz.

Her iki platforma da üye olmanız, yaptığınız çalışmalara sürekli ulaşabilmenizi sağlayacaktır.

# windows(wsl)

Windows üzerinden kullanım için sanal makine kurulumu ya da windows store üzerinde yer alan ubuntu dağıtımını kurarak bash kullanımını ele alacağız. Eğer WSL olarak geçen windows için linux alt sistemini kullanırsak aynı zamanda bash kabuğunu windows makinemizi yönetmek için de kullanabiliyor oluruz.
Ayrıca git üzerinden de yapılabiliyor.

1. **Ayarları** açın.
2. **Güncelleme & Güvenlik** bölümüne girin.
3. **Geliştiriciler için** sekmesine tıklayın.
4. **Geliştirici Modu** seçeneğini seçin.
5. Sorulan onay mesajına "**Evet**" onayını verin.
6. Bilgisayarınızı yeninden başlatın.
7. **Denetim Masası**'nı açın.
8. **Progamlar**'a tıklayın.
9. **Windows özelliklerini aç ya da kapa** seçeneğine tıklayın.
10. **Linux için Windows alt sistemleri** kutucuğunu işaretleyin.
11. **Tamam** diyerek değişikliklerin geçerli olmasını sağlayın.
12. Son olarak **sistemi yeniden** başlatın.

Sistem yeninden başlatıldıktan sonra Microsoft Store yani mağaza uygulamasını açın. Mağaza içerisinde mevcut bulunan dilediğiniz bir dağıtımı kurun. Benim önerim Ubuntu'nun mevcut olan en yeni sürümünü tercih etmenizdir. Seçmiş olduğunuz dağıtım indirildikten sonra "Başlat" diyerek ilk aşama olarak dağıtımın kurulmasını sağlayın. Kısa süre sonra sizden kullanıcı adı ve parola oluşturmanızı isteyecektir. Oluşturup devam edin.

## Git Bash

WSL yöntemi yerine kullanılabilecek olan alternatiftir ancak mümkünse verimlilik açısından WSL kullanılması tavsiye edilir. 

## macOS

macOS işletim sistemi varsayılan olarak bash kabuk dilini kullandığından, herhangi bir kurulum yapmadan terminal üzerinden çalışmalarınızı yürütebilirsiniz.

## linux

İstisnalar hariç genellikle bir çok linux dağıtımı varsayılan olarak bash kabuk dili ile geldiğinden herhangi bir linux işletim sisteminde çalışabilirsiniz. Ancak kullanım kolaylığı dolayısı ile sizlere debian tabanlı olan işletim sistemleri(ubuntu, mint, kali, fedora ..) üzerinden anlatımları takip etmenizi öneririm.

## android

Andorid üzerinden kullanımda, internet erişiminiz olması durumunda web üzerinden kullanabileceğiniz servisleri android üzerinden de kullanabilirsiniz. Bunun dışında Andorid markette yer alan Termux isimli uygulamayı kurarak komut satırı üzerinden dersleri takip edebilirsiniz.

## iOS

iOS platformu için özellikle geliştirilmiş olan stabil çalışan bir emülator henüz bulunmuyor maalesef. Ancak bunun yerine web üzerinde yer alan [repl.it](http://repl.it/) gibi platformlar ile de dersleri takip edebilirsiniz. Ayrıca VPS kiralayarak SSH bağlantısı ile dersleri takip edebilirsiniz.

Tüm bu bahsi geçen yöntemler zaman içinde değişime uğrayabilir ya da daha iyi alternatifleri ortaya çıkabilir. Ancak sizin odaklanmanız gereken tek detay bash kabuğunu kullanabileceğiniz herhangi bir ortama sahip olmanızdır. Sahip olduğunuz ortama göre bash kabuğunu kullanarak programlama yapabilirsiniz.

Örneğin windows sistemi üzerinden bash kabuğu ile çalışıyorsanız windows sistemi için bash kabuğu ile programlama yapabilirsiniz. 

# Metin Editörü Seçimi

Esasen hangi metin editörünü kullandığınızın pek bir önemi yok. Metin editörlerinin birbirinden ayrıldığı nokta, otomatik tamamlama veya renklendirme gibi kolaylıklar sunabilmesidir. Ben eğitimi Linux dağıtımı üzerinden hazırladığım için sistemde yüklü bulunan nano aracını kullanıyor olacağım. Ancak sizler çalışmakta olduğunuz ortamda yüklü bulunan ya da harici olarak kurup kullanmak istediğiniz herhangi bir araç üzerinden eğitimi rahatlıkla takip edebilirsiniz. visualstudio code, atom, vi, gvim, notepad++ gibi pek çok farklı metin editörü alternatifiniz bulunuyor. Yazı yazıp kaydedebildiğiniz sürece hangi editörü kullanacağınız sizin tercihinize bağlıdır.