# Koşul İfadeleri

# Koşullu İfadeler

Yazdığımız betiklerin belirli durumlara göre vermesi gereken tepkiler varsa bunları koşullu ifadeler ile belirtebiliyoruz. X koşulu sağlanırsa abc işlemi yürütülsün, sağlanmazsa xyz işlemi.. gibi özel durumlar tanımlayabiliyoruz.

Üstelik koşullu durumları belirtmek için yalnızca tek bir kullanım yöntemi bulunmuyor. İhtiyacımıza göre çeşitli koşul ifadelerini kullanabiliyoruz. Şimdi sırasıyla bu ifadeleri tek tek ele alalım.

## if - then - elif - else

Başlıkta geçen ifadelerin anlamları;
**`if`** = "**eğer"** 

**`then`** = "**sonra"** 

**`elif`** = "**eğer yoksa**/**eğer değilse"** 

**`else`** = "**aksi halde"**

Buradaki açıklamalar elbette yeterli değil. Bu ifadelerin işlevlerini örnekler üzerinden çok daha net kavrayabiliriz.

Koşulların kullanımı aşağıdaki şemaya benzer şekildedir.

```bash
if [ durum-koşullar ] #Bir koşul belirtir.
then #Koşul sağlanırsa yapılacaklar.
	Komutlar..
elif [ durum-koşullar ] #Başka bir koşul belirtir.
then #Koşul sağlanırsa yapılacaklar.
Komutlar..
else #Hiç bir koşul sağlanmaz ise yapılacaklar..
Komutlar..
fi
```

Şemada yer alan **`if`** ifadesinin bitişiğindeki köşeli parantez içerisinde belirtilen koşulun sağlanması halinde konsol olumlu sonuç döndürerek, **`then`** ifadesinin ardından belirtilmiş komutları yürütür.

Eğer **`if`** koşulu sağlanmaz ise **`elif`** yapısı kontrol edilir ve başka bir koşulun sağlanıp sağlanmadığına bakılır. **`elif`** ile belirtilmiş herhangi bir koşul sağlanıyorsa sağlanan koşula bağlı komut yürütülür. Yani **`elif`** koşulu, **`if`** koşulunun alternatifini oluşturur. Şayet **`if`** ve **`elif`** koşullarının hiç biri sağlanmıyorsa en son **`else`** ifadesi ile belirtilmiş komutlar yürütülür.

En sonda yer alan **`fi`** ifadesi ise **koşulun sınır hattını** yani hangi kısımların koşula dahil olduğunu belirtir. Koşul ifadeleri **`if`** ile başlar **`fi`** ile biter.

Peki ama koşul durumlarını nasıl belirteceğiz ?

Koşulların sağlanıp sağlanmadığını tayin edebilmek adına, büyüktür, küçüktür, eşittir, büyük eşittir, dosya vardır, dosya yoktur, dosya doludur, dosya boştur ve benzeri pek çok doğrulama operatörlerini kullanabiliyoruz.

Doğrulama operatörlerini kullanıyorken dikkat etmemiz gereken şey, ilgili koşulun hangi veri tipine bağlı olduğunun bilincinde olmanızdır.
Yazı dizileri(string), sayılar(integer) ve dosyalar(file) için birbirinden farklı pek çok operatör bulunur ve bunların yerli yerinde kullanılması şarttır. Yani tek bir operatör tüm veri tipleri için geçerli değildir.

Yeri gelmişken hangi veri tipinin hangi işlevde olduğunu kavramak adına kısa açıklamada bulunalım;

**String:** Bu ifade Türkçe olarak "dizi" şeklinde çevrilebilir, ancak programlamada **yazı dizisi**ni temsil ediyor. Burada bahsi geçen yazı dizisi, aritmetik bir değeri bulunmayan tüm karakterleri karşılıyor.

**Integer:** Bu ifade ise Türkçe olarak **tam sayı** anlamına geliyor. Bu veri türü ise aritmetik olarak işleme alınabilecek sayıları ifade ediyor.

Burada verilen açıklamalar yeterli gelmediyse lütfen okumaya devam edin. Örnekler üzerinden ele aldığımızda esasen ne demek istediğimi tam olarak kavramış olacaksınız.

Şimdilik anlatıma devam edecek olursak, aşağıdaki tabloya bakarak hangi operatörün hangi durumda ne şekilde kullanıldığını görebilirsiniz.

### Yazı Dizisi için Doğrulama Operatörleri

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%20bb995b5c70864fc29463d3d0acd79fd0.md)

Büyüktür ve küçüktür operatörleri hariç, diğer operatörler için çift ve tek köşeli parantez kullanımı mümkündür. Ancak büyüktür ve küçüktür operatörü için yalnızca çift köşeli parantez kullanılabilir.

### Tam Sayılar(integer) İçin Doğrulama Operatörleri

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%200d33d91f436f4e99af88692f038983a0.md)

Kısaltmalar yerine semboller ile de aynı işlevleri belirtebiliriz. Fakat yazı dizelerinde kullanılan semboller ile karışmaması için mutlaka çift yay parantez kullanılması gerekiyor.

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%2031d5bb68092b42a787f731c6b39cae96.md)

### Dosyalar İçin Doğrulama Operatörleri

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%20434db77a0c5e4bd6bc6f6e997d240134.md)

# İkili Dosya Kıyas Operatörleri

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%206c0729b3941048e0bfbf20fc54474284.md)

# Mantıksal Öperatörler

[Untitled](Kos%CC%A7ul%20I%CC%87fadeleri%205873a432b08f46f9ba7f4b99f3f725c6/Untitled%20Database%20d3a938bed777464ab893287dd890c91a.md)

## Null komutu

Birçok durumda, hiçbir şey yapmayan ve 0 gibi bir başarı durumu döndüren bir komuta ihtiyacımız olabilir. Bu gibi durumlarda null komutunu kullanabiliriz. İki nokta üst üste (:) ile temsil edilir. Örneğin, if döngüsünde, başarılı olursa herhangi bir komut eklemek istemiyoruz, ancak başarısız olursa yürütülecek belirli komutlarımız var. Bu gibi durumlarda null komutunu kullanabiliriz. Bu, aşağıdaki if_19.sh komut dosyasında gösterilmiştir. Sonsuza kadar döngü yapmak istiyorsak, null komutu for döngüsünde kullanılabilir:
**#!/bin/bash
city=London
if grep "$city" city_database_file >& /dev/null
then
:
else
echo "City is not found in city_database_file "
exit 1
fi**

İki nokta üst üste işareti, özel karakterler sınıfında yer alan ve özetle "**hiç bir şey yapma**" anlamına gelen yapıdır. Genel kullanım amacına bakıldığında tıpkı `true` komutu gibi "**doğru**" değeri döndürmek amacıyla kullanıldığını görebiliriz. Test etmek için yalnızca iki nokta üst üste karakterini komut satırımıza girelim ve hemen ardından çıkış değerini kontrol etmek için `echo $?` komutunu kullanalım. Ve benzerliği görmek adına `true` komutunu girip bu komutun da çıkış değerini görelim.

```bash
:
echo $?
0
true
echo $?
0
```

Görebildiğiniz gibi iki nokta üst üste karakteri de tıpkı `true` komutu gibi çıkış kodu olarak "**0**" yani "**komut hatasız çalıştı**" değerini veriyor.

Örneğin bu yapı sayesinde aşağıdakine benzer şekilde sonsuz döngü oluşturulabilir. Çünkü döngüyü sağlayan iki nokta üst üste işareti her daim olumlu sonuç döndürecektir.

```bash
while :
do
   echo "döngü devam ediyor..."
done
```

Aynı işlemi `true` komutu ile de kurabiliriz.

```bash
while true
do
   echo "döngü devam ediyor..."
done
```

Benzer şekilde if/then yapısında koşul durumunu atlamak için boş değer döndürücü şekilde de kullanabiliriz.

```bash
if kosul-durumu
then :   # Hiç bir şey yapma sadece devam et:)
else     
   echo "İlk koşul boş geçildiği için bu satır bastırıldı.."
fi
```

Pas geçme özelliğinin dışında ayrıca, değişken değeri atanmamış olan değişkenlere yeni değerler atabilmektir. Basit bir örnek olması açısından daha önce tanımlanmamış olan yeni isimli bir değişkene iki nokta üst üste yapısı ile değer atamaya çalışalım. 

Örneğin `: ${sistem="linux"}` kullanımında eğer `sistem` değişkenine daha önce bir değer atanmadıysa belirtmiş olduğum "**linux**" değeri atanır. Ancak daha önce değer ataması yapıldıysa değişmeden kalır. 

```bash
$ : ${sistem="linux"}
$ echo $sistem
linux
$ : ${sistem="gnu-linux"}
$ echo $sistem
linux
$ 
```

Özellikle değişken değerlerinin yeniden tanımlanırken eski değerlerini yok ettiğini bildiğimiz için, bu kullanım eğer varsa eski değerin korunmasını istediğimiz durumlarda kullanabileceğimiz yapıdır.

## Bonus: Haberin Olsun :)

Kullanım alanı pek yaygın ve önerilmiyor olsa da karşılaşmanız halinde yadırgamamak adına iki farklı özelliğinden de kısaca bahsedelim. 

İki nokta üst üste işareti "pas geçmek" amacıyla kullanıldığı için dosyaların içerisinde yer alan tüm verilerin silinmesi için `: > hedef-dosya` şeklinde bir kullanım alternatifi de vardır. Bu kullanım hedef dosya içerisindeki tüm verileri siler fakat, aslında bu işlem iki nokta üst üste işareti olmadan da aynen yapılabilir. Yani komutumuzu yalnızca `> hedef-dosya` şeklinde girerek de dosya içeriğinin silinmesini sağlayabiliriz. Burada iki nokta üst üste karakterinin kullanılmasının nedeni genellikle betik dosyasını okuyacak kişilerin bu işlemi daha net fark edebilmesi sağlamaktır. Yani iki nokta işaretinin "pas geçme" anlamında olduğunu bilen kişiler dosya içeriğinin boşaltılacağını daha rahat anlayabilir. Fakat dediğim gibi genelde pek sık karşılaşmazsınız ve çok da önerilen bir kullanım sayılmaz.

<aside>
⚠️ **Not:** Özellikle harici olarak temin ettiğiniz betik dosyalarının içerisinde art niyetli olarak bu ifadenin dosyaları silmek amacıyla kullanıldığına şahit olabilirsiniz. Genellikle doğrudan silme ifadesi yer almadığından ve kullanımı yaygın olmadığı için gözlerden kaçabiliyor, aman dikkat. Bu gibi tuzaklara karşı mutlaka çalıştırmadan önce betik dosyası içeriğini kontrol edin. Açık kaynaklı projeler harikadır ama herkesin bu imkanı iyiye kullandığını söyleyemeyiz. Açık kaynak olması güvenilir olduğu anlamına gelmez.

</aside>

Harici olarak kesinlikle önerilmeyen yine de rast gelmenizin olası olduğu diğer kullanımı ise yorum satırı belirtmek için kullanılmasıdır. Normal şartlarda bash kabuğu için `#` işaretinden sonra yazılmış tüm karakterler yorum satırı olarak kabuk edilir yani yorum satırı eklemek için doğru kullanım budur. Ancak yine de kimileri iki nokta üst üste karakterinden sonrasını yorum satırı olarak kullanabiliyorlar. Bu kullanım çok yanlış çünkü yorum satırı içerisindeki özel karakter veya komutların, kabuk tarafından farklı şekilde algılanıp yorumlanması ve özellikle hata ayıklama noktasında oldukça fazla sorun çıkarması olasıdır. Yani yorum satırı için kullanımını kesinlikle önermemekle birlikte, gördüğünüzde şaşırmamanız için bu kullanım şeklinin aklınızda bulunmasında fayda var.

Burada her bir özelliği tek tek ele almayacağımız için tabloyu dikkatlice inceleyerek, kullanım şekillerine ve işlevlerini göz atmanız oldukça önemli.

Her özelliği tek tek örneklendirmiyor olmamızı dert etmeyin lütfen. Zaten birkaç örnek inceledikten sonra kullanım şekline tablodan bakarak dilediğiniz özelliği rahatlıkla kullanabilirsiniz. Yani her bir özelliği tek tek ele almak konuyu gereksiz uzatacaktır, bunun yerine tablo sizin rehberiniz olsun.

Neden sayı ya da yazı dizisi olunca farklı durum belirteçleri kullanılıyor diyecek olursanız; daha önce yapmış olduğumuz string ve integer tanımlarına tekrar göz atmanız, bu konuya açıklık getirecektir.

Ama yine de basit bir örnek vermek gerekirse; yazı dizilerinde büyüklük ölçütü alfabetik sıraya göre belirlenirken, sayı dizilerinde büyüklük sayısal üstünlüğe göre belirlenmektedir. Yani kısacası her iki koşul durumu da yapısı gereği birbirinden farklı çalıştığı için, sayı(integer) ya da yazı dizisi(string) için ayrı ayrı durum belirteçleri kullanılıyor.

Kullanımını daha net anlamak adına birkaç örnek yapalım.

```
#!/bin/bash
read -p "Kullanıcı adı giriniz:" ad

if [ "$ad" == "root" ]

then 
        echo "merhaba root"

elif [ "$ad" == "admin" ]

then

        echo "admin hoş geldin"

else 

        echo "$ad isiminde bir kullanıcı bulunmuyor. "

fi

```

Yukarıdaki örnekte;

- "root" yazı dizisini değer olarak girersek, "merhaba root"
- "admin" yazı dizisini değer olarak girersek, "admin hoş geldin"
- eğer "root" ya da "admin" dışında herhangi bir ifade girersek de girdiğimiz ifade, "xyz isiminde bir kullanıcı bulunmuyor."

şeklinde sonuç döndürüyor.

Burada kullanmış olduğunuz çift eşittir(==) durum belirteci, girilen yazı dizisinin belirtilen ifade ile bire bir aynı olduğu durumları temsil ediyor.

Eğer çift eşittir yerine sayılar için kullanılan eşitlik durum belirtecini yani "-eq" ifadesini kullansaydık konsol çıktı olarak "**tamsayı ifadesi bekleniyordu**" şeklinde bir hata mesajı basıyor olacaktı.

İşte bu yüzden eğer koşul durumu sayı içeriyorsa sayılara özel, eğer yazı dizisi içeriyorsa da yazı dizilerine özel durum belirteçleri kullanılmak zorunda.

Şimdi birde sayılara özel olan bir örnek yapalım;

```
#!/bin/bash
read -p "Sayı değeri girin:" sayi
if (( "$sayi" > 5 ))
then
        echo "$sayi büyüktür 5 rakamından"
elif (( "$sayi" < 5 ))
then
        echo "$sayi küçüktür 5 rakamından"
else
        echo "$sayi tam olarak 5 rakamına eşittir"
fi

```

Aynı örneği aşağıdaki şekilde de kullanabiliyoruz.

```
#!/bin/bash
read -p "Sayı değeri girin:" sayi
if [ "$sayi" gt 5 ]
then
        echo "$sayi büyüktür 5 rakamından"
elif [ "$sayi" lt 5 ]
then
        echo "$sayi küçüktür 5 rakamından"
else
        echo "$sayi tam olarak 5 rakamına eşittir"
fi

```

Şu ana kadar ele aldığımız durum belirteçleri, if koşulu ile kullanabileceğimiz belirteçlerin tamamını oluşturmuyor. Ele aldıklarımız haricinde aşağıdaki doğrulama operatörleri de sık kullanılan operatörlerdir.

Gördüğünüz gibi koşul durumlarını kullanmak bu kadar kolay. Üstelik koşul tanımlarken birbirine bağlı çoklu koşullarda tanımlayabiliyoruz. Tanımlama yaparken tek bir satırda birden fazla koşul durumunu belirterek, ilgili koşulların tamamının ya da en az birinin sağlandığı durumlara göre işlemler gerçekleştirilmesini sağlıyoruz.

Çoklu koşul belirtme işlemi için de AND ve OR operatörlerini kullanabiliyoruz.

## AND ve OR Operatörleri

Çift ampersant(**&&**) "**ve**" ifadesini, çift pipe(**||**) ise "**ya da**" ifadesini karşılıyor.

**&& :** Çift ampersant işaretinin kullanıldığı çoklu koşul tanımlarında her koşulun sağlanması beklenir.

**Örneğin;** "18-25 yaş arası", "erkek", "180 cm boyunda" koşullarından hepsi sağlanıyorsa koşul olumlu sonuç döndürürken, koşullardan biri bile sağlanmasa koşul sonucu olumsuz olur.

**|| :** Çift pipe işaretinde ise çoklu koşullardan en az 1 tanesinin sağlanması yeterlidir.

**Örneğin;** "python, ruby, go" dillerinden en az birini bilen; ifadesindeki koşullarından en az biri bile sağlansa koşul olumlu sonuç döndürür. Olumsuz sonuç döndürülmesi için hiç bir koşulun sağlanmıyor olması gerekir.

Aşağıdaki kullanım örneklerine bakarak hangi işaretin hangi amaçla kullanıldığını görebilirsiniz.

Ayrıca buradaki işaretler yerine -e ve -o operatörleri kullanılarak da aynı şekilde çoklu koşullar belirtilebiliyor. Yukarıdaki aynı örneğin bu kez -e ve -o operatörleri ile yazılmış halini aşağıdaki örneklerde görebilirsiniz.

## Case

Case komutu ise ileride detaylıca ele alacağımız if elif else koşullarına benzer şekilde çalışıyor. Case komutu ile birden fazla durumda göre yapılması gereken işlemleri tanımlayabiliyoruz.

Kullanım şekli aşağıdaki gibidir.

```
case $degisken in 
		durum1) işlem
	  ;; 
		durum2) işlem
	  ;; 
		*) işlem
	  ;; 
esac

```

Komutun işlevini daha net anlamak adına aşağıdaki örneği inceleyebilirsiniz.

```
#!/bin/bash
case $1 in
        "1")
        echo "1 rakamını girdiniz."
 ;;

        "2")
        echo "2 rakamını girdiniz"
 ;;

        *)
        echo "$1 değerini girdiniz"
 ;;
esac

```

Yukarıdaki örnekte, kullanıcı 1 ya da 2 rakamını girerse, buna göre 1 ya da 2 rakamını girdiniz şeklinde çıktı alıyorken. 1 ya da 2 rakamı haricinde herhangi bir karakter girişi yaptığında çıktıda "girilen_karakter değerini girdiniz" şeklinde çıktı alıyor. Yani buradaki * işareti tanımlanan durumlar haricindeki tüm durumları kapsıyor.

Bu şekilde case komutu ile kullanıcıdan alınan girdilere göre işlemeler gerçekleştirebiliyor.

## Select komutu