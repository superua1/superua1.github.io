# Bash Kabuğunu Çağırmak

SHEBANG SATIRINDA ORTAM ÖZELLİKLERİNİN HANGİLERİNİN TANIMLANABİLDİĞİNE DEĞİN ÖRNEĞİN SET KOMUTUNUN TAMAMI MI YA DA UZUN İSİMLERİ DE GEÇERLİ Mİ YA DA SHOPT KOMUTU İLE TANIMLANAN ÖZELLİKLER DE SHEBANG SATIRINDA YA DA BASH ÇAĞIRIIRLIKEN KULLANILABİLİYOR MU 

Tüm özellikleri baştan sona okuyup doğru ve uygun bağlamda açıkladın mı diye test et. Test etmeden ve doğruluğunu teyit etmeden hiç birini es geçme. Açıklamaları sadece ve açık hale getir.

# Bash Kabuğunu Çağırmak

Öncelikle buradaki tüm özelliklere sıklıkla başvurmanız gerekmeyeceğini bilmeniz istiyorum. Bazı özellikler son derece sık kullanılan özellikler iken kimi özelliklere çok özel durumlar hariç ihtiyacınız olması pek muhtemel değil. Ayrıca buradaki özellikler elbette kabuğun yapısı gereği hem etkileşimli hem de etkileşimsiz kullanımda kabuğu etkileyebilecek pek çok işlevi barındırıyor. Bu durum hiç bir özelliği bir önemsiz kılmıyor. Gerektiğinde kullanabilmeniz için bu bölümde yer alan tüm özelliklere mutlaka göz atmanızı tavsiye ederim. Bu sayede unutsanız da anımsamanın gücü sayesinde dönüp tekrar bu bölüme göz gezdirebilirsiniz.

Artık nihayet eğitim genelinde sıklıkla değinmek durumunda kaldığımız kabuğun ortam özelliklerinin ayarlanması üzerinde durabiliriz. Kabuğu nasıl çağırdığımız yani nasıl başlattığımız kabuğun çalışma ortamını tamamen değiştirebiliyor. Söz konusu kabuk ortamı olduğunda, kabuğu çağırırken veya kabuğun çalışması sırasında tanımlayabileceğimiz pek çok özellik bulunuyor.

Kabuk başlatılırken kabuk ortamını ayarlamak için bash —help komutunun çıktılarında yer alan özellikleri istediğimiz ortam özelliklerine sahip kabuk başlatmak için kullanabiliriz. Doğrudan bash komutuna argüman olarak verebileceğimiz gibi, betik dosyalarında shebang satırında da bu seçenekler belirtilebilir. Yine de shebang env ardından çoklu argümanlarda sorun çıkarabiliyor. Bu konuya da ayrıca değin!

 Bu özelliklerin detaylarına `set` ve `shopt` komutlarından bahsettikten sonra tekrar değiniyor olacağız. 

`set` yerleşik komutu ile kullanılabilen tekil tüm seçenekler bash kabuğunu çağırırken ortam özelliğini ayarlamak üzere kullanılabilir. Ek olarak, kullanabileceğiniz birkaç çok karakter seçeneği vardır. Bu seçenekler, tek karakterli seçenekler tanınmadan önce komut satırında görünmelidir.

- **`-debugger`**
    
    Arrange for the debugger profile to be executed before the shell starts. Turns on extended debugging mode (see [The Shopt Builtin](https://www.gnu.org/software/bash/manual/bash.html#The-Shopt-Builtin) for a description of the `extdebug` option to the `shopt` builtin).
    
    - **`-dump-po-strings`**
    
    A list of all double-quoted strings preceded by ‘$’ is printed on the standard output in the GNU `gettext` PO (portable object) file format. Equivalent to -D except for the output format.
    
    - **`-dump-strings`**
    
    Equivalent to -D.
    
    - **`-help`**
    
    Display a usage message on standard output and exit successfully.
    
    - **`-init-file *filename*`**
    - **`-rcfile *filename*`**
    
    Execute commands from *filename* (instead of ~/.bashrc) in an interactive shell.
    
    - **`-login`**
    
    Equivalent to -l.
    
    - **`-noediting`**
    
    Do not use the GNU Readline library (see [Command Line Editing](https://www.gnu.org/software/bash/manual/bash.html#Command-Line-Editing)) to read command lines when the shell is interactive.
    
    - **`-noprofile`**
    
    Don’t load the system-wide startup file /etc/profile or any of the personal initialization files ~/.bash_profile, ~/.bash_login, or ~/.profile when Bash is invoked as a login shell.
    
    - **`-norc`**
    
    Don’t read the ~/.bashrc initialization file in an interactive shell. This is on by default if the shell is invoked as `sh`.
    
    - **`-posix`**
    
    Change the behavior of Bash where the default operation differs from the POSIX standard to match the standard. This is intended to make Bash behave as a strict superset of that standard. See [Bash POSIX Mode](https://www.gnu.org/software/bash/manual/bash.html#Bash-POSIX-Mode), for a description of the Bash POSIX mode.
    
    - **`-restricted`**
    
    Make the shell a restricted shell (see [The Restricted Shell](https://www.gnu.org/software/bash/manual/bash.html#The-Restricted-Shell)).
    
    - **`-verbose`**
    
    Equivalent to -v. Print shell input lines as they’re read.
    
    - **`-version`**
    
    Show version information for this instance of Bash on the standard output and exit successfully.
    

There are several single-character options that may be supplied at invocation which are not available with the `set` builtin.

- **`c`**
    
    Read and execute commands from the first non-option argument *command_string*, then exit. If there are arguments after the *command_string*, the first argument is assigned to `$0` and any remaining arguments are assigned to the positional parameters. The assignment to `$0` sets the name of the shell, which is used in warning and error messages.
    
    - **`i`**
    
    Force the shell to run interactively. Interactive shells are described in [Interactive Shells](https://www.gnu.org/software/bash/manual/bash.html#Interactive-Shells).
    
    - **`l`**
    
    Make this shell act as if it had been directly invoked by login. When the shell is interactive, this is equivalent to starting a login shell with ‘exec -l bash’. When the shell is not interactive, the login shell startup files will be executed. ‘exec bash -l’ or ‘exec bash --login’ will replace the current shell with a Bash login shell. See [Bash Startup Files](https://www.gnu.org/software/bash/manual/bash.html#Bash-Startup-Files), for a description of the special behavior of a login shell.
    
    - **`r`**
    
    Make the shell a restricted shell (see [The Restricted Shell](https://www.gnu.org/software/bash/manual/bash.html#The-Restricted-Shell)).
    
    - **`s`**
    
    If this option is present, or if no arguments remain after option processing, then commands are read from the standard input. This option allows the positional parameters to be set when invoking an interactive shell or when reading input through a pipe.
    
    - **`D`**
    
    A list of all double-quoted strings preceded by ‘$’ is printed on the standard output. These are the strings that are subject to language translation when the current locale is not `C` or `POSIX` (see [Locale Translation](https://www.gnu.org/software/bash/manual/bash.html#Locale-Translation)). This implies the -n option; no commands will be executed.
    
    **`[-+]O [*shopt_option*]`**
    
    *shopt_option* is one of the shell options accepted by the `shopt` builtin (see [The Shopt Builtin](https://www.gnu.org/software/bash/manual/bash.html#The-Shopt-Builtin)). If *shopt_option* is present, -O sets the value of that option; +O unsets it. If *shopt_option* is not supplied, the names and values of the shell options accepted by `shopt` are printed on the standard output. If the invocation option is +O, the output is displayed in a format that may be reused as input.
    
    - **`-`**
    
    A `--` signals the end of options and disables further option processing. Any arguments after the `--` are treated as filenames and arguments.
    

A *login* shell is one whose first character of argument zero is ‘-’, or one invoked with the --login option.

An *interactive* shell is one started without non-option arguments, unless -s is specified, without specifying the -c option, and whose input and output are both connected to terminals (as determined by `isatty(3)`), or one started with the -i option. See [Interactive Shells](https://www.gnu.org/software/bash/manual/bash.html#Interactive-Shells), for more information.

If arguments remain after option processing, and neither the -c nor the -s option has been supplied, the first argument is assumed to be the name of a file containing shell commands (see [Shell Scripts](https://www.gnu.org/software/bash/manual/bash.html#Shell-Scripts)). When Bash is invoked in this fashion, `$0` is set to the name of the file, and the positional parameters are set to the remaining arguments. Bash reads and executes commands from this file, then exits. Bash’s exit status is the exit status of the last command executed in the script. If no commands are executed, the exit status is 0.

[https://zwischenzugs.com/2019/04/03/eight-obscure-bash-options-you-might-want-to-know-about/](https://zwischenzugs.com/2019/04/03/eight-obscure-bash-options-you-might-want-to-know-about/)

# Mevcut Kabuğun Özelliklerini Değiştirmek

Eğer mevcut kabuğun özelliklerini değiştirmek istersek yerine göre  `set` ve `shopt` kullanabiliriz.

Kabuk ortam özelliklerini değiştirmek için `sh` kabuğundan süregelen ve Posix standartlarında da yer alan `set` özelliği kullanılabilir. Ancak bash kabuğunun tüm özelliklerinin yalnızca `set` ile ayarlanması mümkün değildir. Zaman içinde kabuk üzerinde kullanılabilecek seçeneklerin sayısı arttıkça, `set` ile seçenekler tek harfli karakterlerle temsil edildiği için tanımlanmaları zorlaşmıştır. Karmaşaya neden olmamak adına bash kabuğuna özgü olan birtakım yeni özellikler `shopt` yerleşik komutu ile tanımlanabilecek şekilde ayarlanmıştır. Dolayısıyla tüm özellikler için tek bir komutu kullanamazsınız. Gereken özellik için gerekli yerleşik komutu(`set` veya `shopt`) ve seçeneği kullanmanız gerekir. Bu durum, maalesef belirli bir seçeneği bulmayı ve ayarlamayı kafa karıştırıcı hale getirebilir ancak neyseki her an başvurabileceğimiz yardım sayfaları mevcut. Gerektiğinde yardım sayfalarına kısaca göz atmaktan çekinmeyin lütfen.

Mevcut kabukta aktif olan özellikleri `SHELLOPTS` ve `BASHOPTS` olmak üzere iki değişken tutar. Bu değişkenlerden `SHELLOPTS` `set` ile aktifleştirilmiş özellikleri verirken, `BASHOPTS` **bash kabuğuna özel olan** `shopt` yerleşiği ile aktifleştirilmiş olan özellikleri sunar.

```jsx
$ set | grep -e SHELLOPTS -e BASHOPTS
BASHOPTS=checkwinsize:cmdhist:complete_fullquote:expand_aliases:extquote:force_fignore:globasciiranges:histappend:hostcomplete:interactive_comments:login_shell:progcomp:promptvars:sourcepath
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
```

Komutların kullanımı ile ayarlayabileceğimiz ortam özelliklerini listeleyerek aralarındaki farkı daha net görebiliriz. Listeme işlemi için ilgili komutu yazıp hemen ardından TAB tuşuna basmamız yeterlidir. Bu sayede kullanılabilir olan tüm seçenekler karşımıza listelenmiş olur.

```bash
$ set -o 
allexport             functrace             interactive-comments  noglob                physical              vi
braceexpand           hashall               keyword               nolog                 pipefail              xtrace
emacs                 histexpand            monitor               notify                posix                 
errexit               history               noclobber             nounset               privileged            
errtrace              ignoreeof             noexec                onecmd                verbose               
$ shopt 
assoc_expand_once        compat32                 dotglob                  globstar                 lastpipe                 nullglob
autocd                   compat40                 execfail                 gnu_errfmt               lithist                  progcomp
cdable_vars              compat41                 expand_aliases           histappend               localvar_inherit         progcomp_alias
cdspell                  compat42                 extdebug                 histreedit               localvar_unset           promptvars
checkhash                compat43                 extglob                  histverify               login_shell              restricted_shell
checkjobs                compat44                 extquote                 hostcomplete             mailwarn                 shift_verbose
checkwinsize             complete_fullquote       failglob                 huponexit                nocaseglob               sourcepath
cmdhist                  direxpand                force_fignore            inherit_errexit          nocasematch              xpg_echo
compat31                 dirspell                 globasciiranges          interactive_comments     no_empty_cmd_completion  
```

[set Komutu](Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%20d320fb4125864c7fa5539571151871cf/set%20Komutu%20e15322b7b10747d384331d1e9c887e73.md)

[shopt Komutu](Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%20d320fb4125864c7fa5539571151871cf/shopt%20Komutu%20050bad313f7a4c2c80720171a232347e.md)

[Copy of shopt Komutu](Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%20d320fb4125864c7fa5539571151871cf/Copy%20of%20shopt%20Komutu%201652a759a30b4be0b5c7a592df22b14d.md)