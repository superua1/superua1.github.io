# Kaynakça ve Kullanılan Araçlar

# Kullanılan Araçlar

Hazırlık aşamasında kullanılan araçlar.

Diyagramlar için açık kaynaklı araç.

[https://app.diagrams.net/](https://app.diagrams.net/)

# Kaynakça