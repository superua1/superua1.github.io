# 6- Aritmetik İşlemler

### Aritmetik işlemleri değişkenlerin ardından ele almalı, bunu bir düşün.

## Aritmetik İşlemler

Bash üzerinde tanımlı olan fonksiyonlar sayesinde, temel matematiksel işlemleri kolaylıkla yerine getirebiliyoruz. Ancak bu işlemler yalnızca tam sayılarda geçerli olan basit matematiksel işlemlerdir. Virgüllü ve özel matematiksel ifadeler için haricen araç kullanımı gerekiyor. Bu konuya anlatımın ilerleyen kısımlarda değinmiş olacağız. Zaten amacınız verimli şekilde matematiksel hesaplama yapacak gelişmiş bir program oluşturmaksa bash dilini kullanmak öncelikli tercihiniz olmamalıdır. Çünkü bu işi bash kabuğundan çok daha etkili yapacak alternatif dileler ve araçlar bulunur. Bash dilinin güçlü olan yanı bir nevi yapıştırıcı rolünü üstlenerek sistem yönetimini sağlayan pek çok aracı verimli şekilde programlamayabilmemizi sağlamasıdır. 

Aşağıdaki tablodan temel matematik işlemlerini hangi karakteri kullanarak uygulayabileceğinize gözatabilirsiniz.

[Untitled](6-%20Aritmetik%20I%CC%87s%CC%A7lemler%20822ebfca85994de2b2d52802cf3c6143/Untitled%20Database%204746ff0d254a45f2855112454b93c258.md)

Temel kullanım için üç farklı yol bulunuyor, her üç şekilde de temel matematiksel işlemleri yapabiliyoruz.

- $(( işlem ))
- $[ işlem ]
- $(`expr` işlem)

Basit bir örnek üzerinden temel işlemleri görelim.

```
echo $(( 3+5 ))
printf $(( 3+5 ))

```

Aynı örneği köşeli parantez ile de kullanabilirdik.

```
echo $[ 3+5 ]
printf $[ 3+5 ]

```

Ya da **expr** aracılığı ile de aynı örneği uygulayabiliriz.

```
echo $(expr 3 + 5)
printf $(expr 3 + 5)

```

Bu kısımda tek tek toplama çıkarma işareti nasıl olur diye gösterme gereği duymuyorum. Çünkü temel kullanım şekli tüm işlemler için aynı. Tek yapmanız gereken ilgili işlem için gerekli olan karakter simgesini kullanmak. Aşağıdaki örneğe bakarak da bu durumu teyit edebilirsiniz.

```
a=5
b=3

echo $ [ a+b ]
echo $ [ a-b ]
echo $ [ a*b ]
echo $ [ a/b ]
echo $ [ a%b ]
echo $ [ a**2 ]
echo $ [ b**3 ]
echo $ [ a++ ]
echo $ [ b-- ]

```

Temel hesaplama işlemlerini yaparken tek bir istisna bulunuyor; o da "expr" ifadesini ile birlikte çarpma işlemi için yıldız işaretini kullandığımızda çarpma işlemi gerçekleşmiyor. Hata almamak adına aşağıdaki örnekte olduğu şekilde kaçış karakteri olan ters slash kullanmamız gerekiyor.

```
echo $(expr a \\* b)

```

Aslında `expr` kullanımı pek tercih edilmiyor ancak yine de gördüğünüz zaman, hangi işlevde olduğunu bilmenizi istediğim için kısaca değinmek istedim. Ve artık hangi işlevde olduğunu biliyorsunuz.

Bash üzerinde işlem hesaplaması yaparken dikkat etmeniz gereken tek şey, matematiksel işlem önceliğidir.
Çünkü Bash kabuğu da elbette tüm işlemleri matematiksel önceliği dikkate alarak yapar. Yani parantez içi ve çarpma bölme işlemleri öncelikli olacak şekilde, soldan sağa doğru hesaplama yapılır. Hemen bu durumu test etmek adına bir örnek yapalım.

echo $[ (3+5)*3+2*5 ]

**İşleminde;**

- öncelikle parantez içerisindeki toplama yapıldı,
- ardından sol tarafta yer aldığı için 3 ile çarpıldı,
- daha sonra 2 ile de 5 rakamı çarpılarak,
- en son bulunan tüm değerler toplandı.

Neticede 34 sayısı işlem sonucu olarak konsola basıldı.

Aynı örneği bu kez parantez olmadan yaptığımızda bakın sonuç nasıl değişiyor;

echo $[ 3+5*3+2*5 ]

**İşleminde;**

- öncelikle 5 ile 3 çarpıldı,
- arından 2 ile 5 çarpıldı,
- daha sonra en baştaki 3 rakamı da dahil tüm sayılar toplandı.

Neticede 28 sayısı işlem sonucu olarak konsola basıldı.

Böylelikle matematiksel işlem önceliğinin, bash kabuğu üzerindeki önemini de görmüş olduk.

## Sonucun var olan değişkene atanması

Matematiksel işlem sonucunun, işlem sırasında referans alınan değere aktarılması için; ilgili işlem karakterinden sonra eşittir işareti kullanmamız yeterli oluyor.

Örneğin değeri 10 olan "rakam" isimli değişkene 3 eklemek için aşağıdaki şekilde komut girebiliyorum.

echo $[ rakam+=3 ]

Böylelikle işlemi her gerçekleştirdiğimde "rakam" isimli değişkenimin değeri 3'er 3'er artarak, 13, 16, 19, 22 .. şeklinde yeni değerlere sahip oluyor.

Örnekte de gördüğünüz şekilde, yapılan işlemin arından elde edilen çıktılar var olan değişken değerine atanabiliyor.

Üzerine ekleme işlevini diğer matematiksel hesaplamalarda da kullanmanız mümkündür. Ayrıca biz burada `echo` komutunu yalnızca konsola çıktı bastırmak için kullandık yani aritmetik işlem yaparken yalnızca `echo` komutunu kullanmak zorunda olmadığınızı biliyorsunuz. Örneğin daha önce öğrendiğimiz `printf` komutunu kullanarak da tüm işlem sonuçlarının konsola bastırılmasını sağlayabiliriz. Yani benim örnekleri `echo` komutu üzerinden vermiş olmam sizi sınırlamasın lütfen.

## LET KOMUTU

`let` komutu kabuk üzerinde tanımlanmış olan değişkenler üzerinde temel aritmetik işlemler yapabilmemizi sağlayan bir araçtır.

Basit aritmetik işlemler için `let` komutuyla birlikte toplama (+), çıkarma (-), çarpma (*), bölme (/) ve modül (%) seçenekleri kullanılabilir. Kullanım örneği için aşağıdaki çıktıları inceleyebilirsiniz.

```
let a=5+10
echo $a  
15

```

İfadeleri tırnak içerisinde de yazmamız mümkündür. Bu sayede uzun işlemlerde daha okunaklı bir yazım elde edebiliriz.

```
let "b=15*5"
echo $b  
75

```

Gördüğünüz gibi `let` komutunun aritmetik işlemi yerine getirebilmesi için bir değişken üzerinden çalışması gerekiyor. Bu durumu gözlemlemek adına herhangi bir değişken olmadan, doğrudan aritmetik işlemi yaptırmayı deneyebilirsiniz.

```
let "9 - 3"

```

Bu komutun ardından konsola hiç bir değer basılmayacak çünkü, ortaya çıkan sonucu tutacak bir değişken tanımlaması yapmadık. Bu sebeple sonuç üretilse dahi değişken olmadığı için öğrenemiyoruz. İşte `let` komutunun çalışma yapısı gereği hesaplamaları değişkenler üzerinden gerçekleştirmemiz gerekiyor.

- *Artış (++) / Azalış(--) :**Çift artı ya da çift eksi işareti ise değişkenin sahip olduğu değeri bir arttırıp bir azaltma görevindedir. Ancak bu işaretlerin değişkenin önünde veya arkasında bulunma durumuna göre farklı sonuçlar elde edilebilir. Bu durum örnekler üzerinden çok daha net bir içimde anlaşılacaktır.

```
let "sayi=10" "sayi2=sayi++" ; echo "sayi değişkeni:$sayi" "sayi2 değişkeni:$sayi2" 
sayi değişkeni:11 sayi2 değişkeni:10
let "sayi=10" "sayi2=++sayi" ; echo "sayi değişkeni:$sayi" "sayi2 değişkeni:$sayi2" 
sayi değişkeni:11 sayi2 değişkeni:11

```

Çıktılardaki sayıların farklı olmasını çift artı işaretini nerede kullandığımız belirledi. İlk örneğimizde "sayi" değişkenin değeri öncelikle "sayi2" değişkenine aktarılıyor, daha sonra "sayi1" değişkenin değeri 1 arttırılıyor.
İkinci örnekte ise öncelikle "sayi" değişkeninin değeri 1 arttırılıp daha sonra bu yeni değer "sayi2" değişkenine aktarılıyor. İşte çift artı işaretini nerede kullandığımızda göre aldığımız çıktılar bu şekilde değişiklik gösterebileceğinden hangi işareti nereye koyduğunuza dikkat edin lütfen. Aynı durum elbette bir azaltma işlemi için de geçerli.

```
let "sayi=10" "sayi2=sayi--" ; echo "sayi değişkeni:$sayi" "sayi2 değişkeni:$sayi2" 
sayi değişkeni:9 sayi2 değişkeni:10
let "sayi=10" "sayi2=--sayi" ; echo "sayi değişkeni:$sayi" "sayi2 değişkeni:$sayi2" 
sayi değişkeni:9 sayi2 değişkeni:9

```

- *Tek artı (+değişken) / tek eksi (-değişken):**Değişken değerlerinin önüne koyacağınız artı ya da eksi işaretine göre, ilgili değişken artı ya da eksi ile çarpılır. Aşağıdaki örneklere bakarak ne demek istediğimi çok daha net kavrayabilirsiniz.

```
let "arti=5" "eski=-5" "sayi1=-arti" "sayi2=+arti" "sayi3=-eksi" "sayi4=+eksi" ; echo $say1 $sayi2 $sayi3 $sayi4

-5 5 5 -5

```

**Tilde işareti(~)**: Mantıksal ve bit seviyesinde olumsuzlama olarak geçen bu işaretin işlevi, mevcut değeri negatif değeri ile çarpıp bir azaltmaktır. Aşağıdaki örnek, işlevini anlamanıza yardımcı olabilir.

```
let "sayi=5" "sayi2=~sayi" ; echo $sayi2
-6
et "sayi=-5" "sayi2=~sayi" ; echo $sayi2
4

```

- * Üs Kuvvet (**)**: Sayının üs kuvvetlerini almak için kullanılan seçenektir.

```
set "a=5**2" ; echo $a
25
set "a=5**3" ; echo $a
125

```

**Eşittir ve eşit değildir (== / =!):** Eğer iki değişken değerinin eşit olup olmadığını test etmek istersek çift eşittir işareti ile sorgulayabiliriz. Benzer şekilde eşittir işaretinde önce ünlem işareti kullanarak iki değişkenin eşit olmadığını durumları da sorgulayabiliriz.
Eğer aldığımız çıktı "1" ise bu olumlu demektir, aksi durumda aldığımız çıktı "0" olursa bu da sonucun olumsuz olduğu anlamına gelir.

```
let "a=5" "b=5" c="a==b" ; echo $c
1
let "a=5" "b=7" c="a==b" ; echo $c
0
let "a=5" "b=5" c="a!=b" ; echo $c
0
let "a=5" "b=7" c="a!=b" ; echo $c
1

```

Ayrıca temel işlemleri gerçekleştirirken kullandığımız toplama çıkarma gibi işaretlerin yanına eşittir işareti getirerek değişkenin değeri üzerinde doğrudan işlem yapabiliriz.
Örneğin;

```
let a=5 a=a+5 ; echo $a
10

```

Yukarıdaki komut yerine aşağıdaki komut bütününü kullanabiliriz.

```
let a=5 a+=5 ; echo $a
10

```

Eşittir işareti, üzerinde işlem yapılan değişkenin değerini işlemin sonucuna göre tekrar revize edip sonucu tekrar değişkene atıyor.

## Virgüllü Sayılarda İşlem

Esasen bash kabuğunun virgüllü sayılar ile matematiksel işlem yapmak gibi bir fonksiyonu bulunmuyor. Yine de bizler harici araçlar kullanarak hem virgüllü hem de çok daha kapsamlı matematiksel işlemleri yapabiliyoruz.

Virgüllü sayılarda işlem yapmak istediğimizde awk ya da bc araçlarından birini ihtiyacımıza göre kullanabiliriz. AWK aracına ilerleyen kısımlarda detaylıca değineceğiz o yüzden şimdilik sadece awk aracının virgüllü sayılarda işlem yapabilme yeteneğinin olduğunu bilmeniz yeterli. Yeri geldiğinde zaten awk üzerinden virgüllü işlemleri nasıl yapabileceğimizi de göreceğiz.

Şimdiki kısımda ele alacağımız araç awk ya benzer şekilde sık tercih edilen "basic calculator" ifadesinin kısaltması şeklinde yazılan bc aracıdır. İsminden de anlaşılacağı üzere bc aracı, basit hesaplama işlemleri yapabilmemize olanak tanıyan işlevsel bir araçtır.

Eğer sisteminizde varsayılan olarak bc aracı yoksa `apt install bc` komutu ile kurabilirsiniz. Betik dosyanızın içerisinde de bu komutu ekleyip betiği çalıştırmak isteyen kişilerin bu aracı yüklemesini talep edebilirsiniz.

bc aracı, kendisine gönderilen verileri işleyerek sonuçları çıktı olarak konsola bastırır.

En temel kullanımı; `echo "işlem" | bc -l` şeklindedir. Yani pipe ile bc aracına veri göndermemiz gerekiyor.
Hemen basit bir örnek üzerinden bc aracının kullanımını görelim.

```
echo '1.4*4.41' | bc -l

```

Ayrıca alternatif kullanım için "bc <<< 3*4" bu kullanım da mümkündür.

Komutumuzda yer alan -l parametresi bc aracının matematik kütüphanelerini kullanmasını sağlıyor. Eğer bu -l parametresi olamadan komut girersek sonuçların virgüllü kısımları tam olarak gözükmeyecektir.

Aracımızın temel olarak hangi işlevleri yerine getirebildiğini tabloya bakarak öğrenebilirsiniz. Zaten tüm işlem emirleri daha önce de öğrendiğimiz temel aritmetik hesaplama işlemleri ile benzer. Tek dikkat etmeniz gereken detay, virgüllü sayı kullanırken -l özelliği ile matematik kütüphanelerini dahil ederek tam sonuca ulaşmaktır.

```
   -ifade Sonuç, ifade'nin negatifi olur.

   ++değişken
          değişken'in değerine önce 'bir' eklenir ve yeni değer ifadenin sonucu olur.

   --değişken
          değişken'in değeri önce 'bir' eksiltilir ve yeni değer ifadenin sonucu olur.

   değişken++
          İfadenin sonucu değişkenin değerine göre hesaplanır, sonra değişken'in değeri 'bir' artırılır.

   değişken--
          İfadenin sonucu değişkenin değerine göre hesaplanır, sonra değişken'in değeri 'bir' eksiltilir.

   ifade + ifade
          Sonuç, iki ifade'nin toplamıdır.

   ifade - ifade
          Sonuç, iki ifade'nin farkıdır.

   ifade * ifade
          Sonuç, iki ifade'nin çarpımıdır.

   ifade / ifade
          Sonuç, iki ifade'nin bölümüdür. Sonucun bölüntüsü scale değişkeninin değeridir.

   ifade % ifade
          Sonuç,  "kalan"ı  verir  ve  şu  şekilde  hesaplanır. a%b'yi hesaplarken, ilk önce a/b scale haneli olarak hesaplanır. scale+scale(b) ve
          scale(a)'dan hangisi daha büyükse bu bölüntüye göre a-(a/b)*b ifadesi  sonucu hesaplamak için kullanılır. Eğer scale 0'a eşitlenirse  ve
          her iki ifade de tamsayı ise, bu ifade tamsayı kalan işlevidir.

   ifade ^ ifade
          İfadenin  sonucu,  birincinin ikinciye göre üssüdür. İkinci ifade bir tamsayı olmalıdır. (Eğer ikinci ifade tamsayı değilse, önce ekrana
          bir uyarı gelir ve ifade tamsayı olacak şekilde kesilir, yani ikinci ifadenin tam kısmı alınır). Sonucun bölüntüsü ise, eğer üs  negatif
          ise  scale'dir.  Üs pozitif ise scale(a^b) = min(scale(a)*b, max(scale, scale(a)))'dır. Unutulmamalıdır ki ifade^0 ifadesinin sonucu her
          zaman "1" olur.

   ( ifade )
          Parantezler, ifadenin değeri bulunurken standart önceliği değiştirir ve parantez içine alınan ifade daha önce hesaplanır.

   değişken = ifade
          İfadenin sonucu değişkene atanır.

   değişken <işleç>= ifade
          Bu, "değişken = değişken <işleç> ifade" ile eşdeğerdir ancak bir farkla; değişken'in değeri sadece bir kere elde edilir.  Eğer  değişken
          bir dizi ise, işlemin bir kere yapılacağı gözden uzak tutulmamalıdır.

   İlişkisel  ifadeler  (karşılaştırma ifadeleri), sonuçları her zaman 0 veya 1 olan özel ifadelerdir. 0, yanlış (false) ve 1, doğru (true) olarak
   yorumlanır. Bunlar herhangi bir ifade içerisinde yer alabilirler. (POSIX bc'de ise ilişkisel ifadeler sadece  if,  while  ve  for  deyimlerinde
   kullanılabilir ve sadece bir tane ilişkisel sınama olabilir.) İlişkisel işleçler şunlardır:

   ifade1 < ifade2
          Sonuç, eğer ifade1, ifade2'den küçükse 1 olur. Aksi halde 0 olur.

   ifade1 <= ifade2
          Sonuç, eğer ifade1, ifade2'den küçük ya da eşitse 1 olur. Aksi halde 0 olur.

   ifade1 > ifade2
          Sonuç, eğer ifade1, ifade2'den büyükse 1 olur. Aksi halde 0 olur.

   ifade1 >= ifade2
          Sonuç, eğer ifade1, ifade2'den büyük ya da eşitse 1 olur. Aksi halde 0 olur.

   ifade1 == ifade2
          Sonuç, eğer ifade1, ifade2'ye eşitse 1 olur. Aksi halde 0 olur.

   ifade1 == ifade2
          Sonuç, eğer ifade1, ifade2'den farklıysa 1 olur. Aksi halde 0 olur.

   bc'de   mantıksal  (boolean) işlemler de geçerlidir. (POSIX bc'de mantıksal işlemler yoktur.) Mantıksal işlemlerin sonucu, ilişkisel işlemlerde
   olduğu gibi, 0 (false) yada 1 (true) olmaktadır. Mantıksal işleçler şunlardır:

   !ifade ifade 0 ise sonuç 1'dir. Aksi halde 0 olur.

   ifade && ifade
          ifade'lerin ikiside sıfırdan farklıysa sonuç 1'dir. Aksi halde 0 olur.

   ifade || ifade
          ifade'lerden biri sıfırdan farklıysa sonuç 1'dir. Aksi halde 0 olur.

```

Tabloda yer alan temel matematiksel işlemler dışında bc aracının sahip olduğu pek çok matematiksel işlem kabiliyeti bulunuyor. Ancak hepsini burada tek tek değinmemiz oldukça anlamsız. Çünkü bc aracının manuel sayfalarının baştan sona harika bir Türkçe çevirisi bulunuyor. Sisteminizdeki manuel sayfalarından bc aracının tüm işlevleri hakkında çok daha detaylıca Türkçe bilgi edinebilirsiniz. Neticede virgüllü sayılarda veya daha kapsamlı matematiksel işlemlerde hangi aracı kullanmanız gerektiğini artık biliyorsunuz. Yani bu kadarlık bilgi şimdilik bizim için yeterli.

Aslında temel aritmetik işlemler dışında ağır matematiksel hesaplamalara bash programlama yaparken ihtiyaç duymanız düşük bir olasılık. Şayet ihtiyaç duysanız dahi bu hesaplamalar için bash dilini kullanmanız da verimlilik açısından pek doğru bir tercih olmayacağından temel aritmetik işlemlerin nasıl yapıldığını bilmeniz pek çok durumda sizlere yetecektir.

[https://www.gnu.org/software/bash/manual/html_node/Shell-Arithmetic.html](https://www.gnu.org/software/bash/manual/html_node/Shell-Arithmetic.html)

# **Kabuk Aritmetiği**

Kabuk, aritmetik ifadelerin, kabuk genişletmelerinden biri olarak veya `((`bileşik komut, `let`yerleşik veya-ben`declare`yerleşik seçeneği .

Değerlendirme, taşma kontrolü olmaksızın sabit genişlikli tam sayılarla yapılır, ancak 0'a bölme yakalanır ve bir hata olarak işaretlenir. Operatörler ve bunların önceliği, ilişkilendirilebilirliği ve değerleri C dilindekilerle aynıdır. Aşağıdaki işleç listesi, eşit öncelikli işleç düzeylerine göre gruplandırılmıştır. Seviyeler, azalan öncelik sırasına göre listelenmiştir.

***`id*++ *id*--`**değişken artış sonrası ve azaltma sonrası**`++*id* --*id*`**değişken ön artış ve ön azaltma**`- +`**tekli eksi ve artı**`! ~`**mantıksal ve bitsel olumsuzlama**`**`**üs alma**`* / %`**çarpma, bölme, kalan**`+ -`**toplama çıkarma**`<< >>`**sol ve sağ bitsel kaymalar**`<= >= < >`**karşılaştırma**`== !=`**eşitlik ve eşitsizlik**`&`**bitsel AND**`^`**bit düzeyinde özel VEYA**`|`**bitsel VEYA**`&&`**mantıksal AND**`||`**mantıksal VEYA**`expr ? expr : expr`**koşullu operatör**`= *= /= %= += -= <<= >>= &= ^= |=`**Görev**`expr1 , expr2`**virgül

Kabuk değişkenlerine işlenenler olarak izin verilir; ifade değerlendirilmeden önce parametre genişletme gerçekleştirilir. Bir ifade içinde, kabuk değişkenlerine, parametre genişletme sözdizimi kullanılmadan adla da başvurulabilir. Boş olan veya ayarlanmayan bir kabuk değişkeni, parametre genişletme sözdizimi kullanılmadan adla başvurulduğunda 0 olarak değerlendirilir. Bir değişkenin değeri, başvurulduğunda aritmetik bir ifade olarak veya '' kullanılarak *tamsayı* özniteliği verilen bir değişkene göre değerlendirilir. beyan -ibir değer atanır. Boş değer 0 olarak değerlendirilir. Bir kabuk değişkeninin bir ifadede kullanılması için *tamsayı* özniteliğinin açık olması gerekmez.

Tamsayı sabitleri, son ekler veya karakter sabitleri olmadan C dili tanımını takip eder. Başında 0 olan sabitler sekizlik sayılar olarak yorumlanır. Bir lider '0x'veya'0X'onaltılı gösterir. Aksi takdirde, sayılar [ *taban*`#` ] *n* biçimini alır; burada isteğe bağlı *taban* , aritmetik tabanı temsil eden 2 ile 64 arasında bir ondalık sayıdır ve *n* , bu tabandaki bir sayıdır. Eğer *temel*`#` atlanırsa, o zaman temel 10 kullanılır. *N* belirtirken , rakam olmayan bir rakam gerekliyse, 9'dan büyük rakamlar küçük harflerle, büyük harflerle temsil edilir, '@', ve '_', bu sırayla. Eğer *taban* az ya da 36, küçük harf ve harfler 10 ile 35 arasındaki sayıları temsil etmek için birbirinin yerine kullanılabilir büyük eşittir.

Operatörler öncelik sırasına göre değerlendirilir. Parantez içindeki alt ifadeler önce değerlendirilir ve yukarıdaki öncelik kurallarını geçersiz kılabilir.