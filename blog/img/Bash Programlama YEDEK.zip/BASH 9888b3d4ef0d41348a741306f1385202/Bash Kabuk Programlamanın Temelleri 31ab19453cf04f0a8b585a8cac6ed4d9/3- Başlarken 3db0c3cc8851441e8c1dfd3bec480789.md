# 3- Başlarken

## Başlarken

Gerekli çalışma ortamını kurduk ve artık çalışmak için hazırız. Anlatımlara başlamadan önce belirtmem gerekiyor ki, biz bu eğitimde Linux sisteminin temel kullanımından yani sistem yönetiminin temellerinden bahsetmeyeceğiz. Bizim bu eğitimdeki amacımız; halihazırda yönetebildiğimiz sistemdeki işlerimizi kolaylaştırmak veya verimini artırmak için bash kabuğunu daha yakından tanıyıp işlerimizi nasıl senaryolaştırabileceğimizi(scripting) öğrenmektir.

Bu durumun nedeni konu kapsamını mümkün oldukça dağıtmadan verimli şekilde öğrenmenizi sağlamaktır. Ancak ben yine de konu bütünlüğünü sağlamak adına sistem yönetimi ve kullanılan harici komutlar hakkında yeri geldikçe kısa hatırlatmalarda bulunuyor olacağım.

Kısacası bu eğitimden verim alabilmeniz için en azından temel seviye Linux bilgisine sahip olmanızı şiddetle tavsiye ederim. Şayet bu konuda eksiğiniz varsa, benim bir önceki video eğitimim olan "Kali Linux ile Sıfırdan Temel Linux Eğitimi" kursuna kaydolmanızı ya da "Temel Linux Eğitimi" dokümantasyonuna göz atamanızı öneririm. Zira bu eğitim temel Linux eğitimimin devamı niteliğinde, eğitimden maksimum verim alabilmek adını her iki eğitimi de bir bütün olarak ele almanız çok daha iyi olacaktır.

Bu girizgahtan sonra artık esas konumuza dönebiliriz.

Öncelikle yönetmekte olduğumuz kullanıcı hesabında hangi kabuk programı kullanılıyor bu öğrenelim. Öğrenmek üzere konsola `echo $SHELL` komutunu girebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/1.png)

Burada "**SHELL**" olarak geçen ifade mevcut kullanıcı hesabı için varsayılan kabuğun hangisi olduğunun bilgisine tutan **değişkendir**. `echo` komutu da bu değişkenin değerini konsola bastırmamızı sağlayan araçtır. Çıktıda yer alan "**/bin/bash**" ifadesi, bash kabuğunun tam dosya konumunu belirtiyor. Bu sayede mevcut kullanıcı için varsayılan kabuğun "bash" olduğunu öğrenmiş olduk.

Eğer sizin kullanıcı hesabınızdaki varsayılan kabuk "bash" değilse kolay çalışabilmek adına devam etmeden önce "bash" olarak değiştirmeniz gerekiyor. Aslında varsayılan kabuğu bash olarak değiştirmeden konsola `bash` komutunu girerek de bash kabuk ortamında çalışmaya başlayabilirsiniz. 

<aside>
⚠️ Not: Eğer kullanmakta olduğunuz sistemde bash kabuğu yüklü değilse `bash` komutunun neticesinde "komut yok" şeklinde hata almış olabilirsiniz. Bu durumda tek yapmanız gereken bash kabuğunu mevcut sisteminize yüklemektir. Bash kabuğunu nasıl yükleyeceğimizi "Gerekli Ortamın Kurulması" bölümünde detaylıca ele aldık. Ayrıca mevcut sistemi temel düzeyde kullanabiliyor olmanızın eğitimi takip edebilmek için şart olduğunu başta belirtmiştik hatırlarsanız. Çünkü tanımadığınız sistemi yönetmek için programlayamazsınız. Bizler sistemi yönetmeyi değil bash programlamanın esaslarını öğreniyor olacağız.

</aside>

`bash` komutu ile başlatabilecek olsa da biz her seferinde bu işlem ile uğraşmak istemediğimiz için bash kabuğunu mevcut hesabımız için nasıl varsayılan olarak ayarlayabileceğimize de değinelim.

## Varsayılan Kabuğu BASH Olarak Değiştirmek

Değiştirmek için öncelikle "bash" kabuğunun sistem üzerinde hangi konumda yüklü olduğunu öğrenmemiz gerekiyor. Öğrenmek üzere `which bash` komutunu kullanabiliriz. 

```jsx
$ which bash
/usr/bin/bash
```

Aldığımız çıktı bash kabuğunun tam dosya konumunu belirtiyor. Sizde bu çıktı benimkinden farklı olabilir. Zaten farklı olma ihtimaline karşı `which` komutu ile bash kabuğunun dosya konumunu saptamaya çalıştık. 

Artık bash kabuğunun tam dosya konumunu öğrendiğimize göre, mevcut kullanıcı hesabımız için bash kabuğunu varsayılan yapabiliriz. Bu sayede hesabımızda her oturum açtığımızda konsol üzerinden doğrudan bash kabuğuna emir verebiliyor olacağız.

Kullanıcıların varsayılan kabuk ayarını değiştirmek için, kullanıcıların temel hesap bilgilerinin tutulduğu ***/etc/passwd*** dosyasında değişiklik yapmamız gerekiyor. Bu dosyayı yetkili olarak herhangi bir metin editörü ile açalım.

```bash
sudo nano /etc/passwd
```

Dosyayı açtıktan sonra, kabuğunu değiştirmek istediğimiz kullanıcı satırını bulup, sondaki kabuk adresini bash kabuğunun tam dosya adresi ile değiştirelim. Örneğin ben zsh olan kabuğu bash ile değiştirmeyi örnekledim.

```bash
taylan:x:1000:1000:,,,:/home/taylan:/usr/bin/zsh
```

```bash
taylan:x:1000:1000:,,,:/home/taylan:/usr/bin/bash
```

***/etc/passwd*** dosyası her oturum açılışında sistem tarafından okunduğu için değişikliğin geçerli olabilmesi adına oturumunuzu kapatıp tekrar açmalısınız.

Oturum açtıktan sonra, değişikliği `echo $SHELL` komutu ile teyit edebilirsiniz. Bu şekilde sistem üzerinde yüklü bulunan pek çok kabuk programından, istediğiniz bir tanesini kendi kullanıcı hesabınız için varsayılan olarak ayarlayabilirsiniz. 

Eğer kullanmakta olduğunuz sisteminizde hangi kabukların yüklü olduğunu öğrenmek isterseniz ***/etc*** dizini altında yer alan ***shells*** isimli dosyanın içeriğine bakabilirsiniz. 

Konsola `cat /etc/shells` komutunu girerek dosyamızın içeriğini okuyalım.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/3.png)

Gördüğünüz gibi sistemde yüklü bulunan kabuk programlarının hepsi bu dosya içerisinde listelenmiş bulunuyor. Birden fazla kabuk olma durumunu teyit ederken, sizde yer alan kabuk program çeşitleri bende listelenmiş olanlardan eksik ya da fazla gözüküyor olabilir. Bu durumun nedeni sistemde yer alan kabuk program çeşitlerinin, kullanılan dağıtıma göre değişiklik gösterebiliyor olmasıdır. Yani benimle bire bir aynı çıktıları almadıysanız da hiçbir problem yok. Çünkü zaten bizim bu eğitimde odaklanacağımız kabuk programı yalnızca "bash" olacak. 

Yine de buna rağmen bash kabuğu için bile birden fazla dosya konumu olması göze çarpıyor. Hem "/bin/bash" hem de "/usr/bin/bash" konumları bash kabuğunu içeriyor. Tek bir kabuk için neden birden fazla dosya konumu listelendi ki ?

Bu durumun nedeni dosya sistemi hiyerarşisi ile ilgili aslında. Yani temel linux eğitimine göz atmanız daha doğru bilgi almanızı sağlar. Yine de kısaca izah etmek gerekirse;

***/bin***, hem sistem yöneticisi hem de kullanıcılar tarafından kullanılabilen, ancak başka hiçbir dosya sistemi bağlanmadığında (örneğin tek kullanıcı modunda) gerekli olan komutları içerir. Ayrıca betikler tarafından dolaylı olarak kullanılan komutları da içerebilir.

***/bin*** içine yerleştirilecek kadar gerekli olmayan komut dosyaları bunun yerine ***/usr/bin*** içine yerleştirilmelidir. Yalnızca kök olmayan kullanıcılar tarafından gerekli olan öğeler (X Pencere Sistemi, chsh, vb.) genellikle kök bölüme yerleştirilecek kadar gerekli değildir.

***/usr/bin/*** sistemdeki yürütülebilir komutların birincil dizinidir. Yerel olarak oturum açmış kullanıcılar tarafından erişilmesi amaçlanan uygulama dosyaları buraya yer alır.

Yine de yardımcı programları farklı dizinlere dağıtmak artık gerekli değildir ve bunların tümünü ***/usr/bin*** içinde depolamak dosya sistemi hiyerarşisini basitleştirir. 

Tarihsel olarak geçmişte tek bir diskte yeterli disk alanı olmadığı için harici disklerde dizinler dağıtılmıştı. ***/bin*** ve ***/sbin*** dizinlerindeki yardımcı programlar harici diskteki ***/usr*** bölümünü monte(mount) etmek için kullanılıyordu. Bu iş günümüzde initramfs tarafından yapılmaktadır ve bu nedenle dizinleri bölmek artık herhangi bir amaca hizmet etmemektedir. Tarihsel detaylara kısa bir internet araştırması ile ulaşabilirsiniz. Tüm dağıtımlarda olmasa da basitleştirilmiş dosya sistemi hiyerarşisini benimseyen dağıtımlar, ***/bin***, ***/sbin***, ***/lib***, ***/lib64***'ü dizinlerini ***/usr*** içindeki karşılıklarıyla birleştirmektedir. ***/usr*** birleştirmesinden sonra, tüm dosyalar hem ***/bin*** hem de ***/usr/bin*** içinde kullanılabilir hale gelir. Yani hem ***/sbin*** hem de ***/usr/sbin*** dosya yolu olarak kullanılabilir çünkü ***/bin***, ***/usr/bin***'e, ***/sbin***'de ***/usr/sbin***'e bir sembolik bağ olur. Şimdilik bu kadar bilgi yeterli.

En nihayetinde; daha önce de belirttiğimiz şekilde birden fazla kabuk programının olduğunu ve bunların aynı sistemde yüklü bulunabileceğini ve hatta dilediğimiz kabuğu kullanabileceğimizi de hep birlikte teyit etmiş olduk.

## Betik Dosyası(Script) Oluşturma

Bash script yazarken ilk olarak dosyanın başına unix sistemlerinde "**shebang"** olarak geçen "**#!**" tanımını, betiğin çalıştırılacağı ortamı da belirterek "**#!/bin/bash**" şeklinde eklememiz gerekiyor.

![3-%20Bas%CC%A7larken%203db0c3cc8851441e8c1dfd3bec480789/shebang.png](3-%20Bas%CC%A7larken%203db0c3cc8851441e8c1dfd3bec480789/shebang.png)

İlk satıra eklenen bu ifade, sonraki alt satırların hangi çalışma ortamı tarafından yorumlanacağını bildiren standart bir tanımdır. Dosya açıldığında ilk olarak buraya bakılır ve dosyanın çalıştırılabilir ortamının mevcut olup olmadığına karar verilir. İlgili ortam sistemde yüklü ise dosya bu ortam üzerinden çalıştırılır. Dolayısıyla komutların doğru yorumlanabilmesi için her bash script dosyasında bu tanım mutlaka bulunmalıdır.

Ayrıca bu kullanımın dışında çalıştırılacak ortamı `#!/usr/bin/env bash` şeklinde belirtmeniz de mümkün. Bu kullanım ile bash ortamının sistemde kurulu olduğu konum otomatik olarak bulunup betik dosyası bu ortam üzerinden çalıştırılıyor. Bu neden gerekli diyecek olursanız; istisnai durumlarda bash ortamı bizim ilk olarak belirtiğimiz konum olan **/bin/bash** konumunda yer almayabiliyor. Nitekim ***/etc/shells*** dosyasında da bu durumu bizzat görmüştük. Bu gibi durumlarda betik dosyamızın çalıştırılacağı bash ortamının sistem üzerinde nerede kurulu olduğunu tayin etme işini `env` aracı üstleniyor. `env` aracı, çevre değişkenlerini sorgulayarak bash ortamının sistem üzerinde yüklü olduğu konumu kolayca bulabiliyor.

Peki ama `env` komutu tüm sistemlerde ***/usr/bin/*** altında mı ? Yani `env` komutunun konumu da sistemden sisteme göre değişmiyor mu ? Çok nadir durumlar dışında hayır değişmiyor, çünkü pek çok betik dosyası bu yöntem ile çalıştırılacak ortamı belirtiyor. Sistemler de bu durumu göz önünde bulundurarak env aracının dosyasını ***/usr/bin/*** dizinini altında tutuyor. ****Bu durumu gözlemlemek adına, farklı sistemler üzerinden bu durumu teyit etmeyi deneyebilirsiniz. Debian, Ubuntu, CentOS, MacOS, SUSE, RHEL, NetBSD, OpenBSD, FreeBSD, Solaris.. sistemlerinde ***/usr/bin/env*** konumunda yer alıyor.

Kafanızda soru işareti kalmaması adına biraz daha açıklamak istiyorum. Bahsi geçen `env` komutu İngilizce "**environment**" ifadesinin yani "**ortam**" ifadesinin kısaltmasıdır. Görevi de sistem üzerinde yüklü bulunan ortamlardan haberdar olup, gerektiğinde bu ortamların çalıştırılabilmesini sağlamaktır. Örneğin Python ile yazılmış bir programın çalışması için Python ortamına ihtiyacı vardır. Çünkü Python dili ile yazılmış komutları yalnızca Python ortamı anlamlandırıp, bilgisayarımıza aktarabilir. Eğer sistemimizde Python ortamı yüklü ise bizler bu ortamın nerede bulunduğunu bilmeye ihtiyaç duymadan `env python` komutu ile gerekli ortamın açılmasını sağlayabiliriz. Çünkü Python çalışma ortamı farklı sistemlerde farklı konumlarda bulunuyor olabilir ve ayrıca dosyanın Python ortamı ile çalışması gerektiğini de `env` sayesinde özellikle bildirmiş oluyoruz. İşte bizler de yazmış olduğumuz aracın tüm sistemlerde kendi çalışma ortamını otomatik olarak bulunup çalıştırılabilmesi için `env` komutundan faydalanıyoruz. Bu sayede eğer sistem üzerinde bash ortamı yüklü ise `env` komutu gidip bash ortamını bulup çalıştırıyor. Yani bu kullanım, yazmış olduğumuz betik dosyalarının tüm Linux sistemlerinde ortak olarak çalıştırılabilmesi için diğer bir deyişle betik dosyamızın taşınabilir bir dosya olması için elzemdir. Dolayısıyla komutların doğru yorumlanabilmesi için her bash script dosyasında mutlaka bulunmalıdır.

![3-%20Bas%CC%A7larken%203db0c3cc8851441e8c1dfd3bec480789/shebang-env-lt.png](3-%20Bas%CC%A7larken%203db0c3cc8851441e8c1dfd3bec480789/shebang-env-lt.png)

Program çalıştırıldığında sistem tarafından öncelikle ilk satır okunur ve ilk satırda geçen kabuk diline göre program ilgili kabuk dili aracılığı ile çalıştırılır dedik.

Şayet ilk satıra hiç bir ifade eklemezseniz, sistem varsayılan olarak mevcut kabuk üzerinden script dosyasını çalıştırmayı dener. Yani aslında mevcut sisteminizde kullanılan kabuk bash ise, "**#!/usr/bin/env bash**" ifadesini betik dosyanıza eklemeseniz dahi betik dosyanız, sistemde varsayılan kabuk bash olduğundan sorunsuz şekilde çalışacaktır. Ancak yine de yazmış olduğunuz betik dosyasının, diğer sistemlerde de doğru şekilde çalıştırılabilmesi için "**#! /usr/bin/env bash**" yani "shebang" ifadesini betik dosyanızın başına eklemiş olmanız son derece önemlidir. Zira çoğu Linux dağıtımı bash kabuğunu varsayılan olarak kullanıyor olsa da, istisnai durumlarda farklı kabukların varsayılan olarak kullanıldığı da olabiliyor. Örneğin sizin bash için yazdığınız betik dosyası, varsayılan çalışma ortamı zsh olan bir sistemde çalıştırıldığında eğer başında bu betik dosyasının bash ortamında çalışmaya uygun olduğunu belirten shebang ifadesi yoksa doğru şekilde çalışmayacaktır. Çünkü sistem dosyayı açtığında özellikle bir çalışma ortamı belirtilmediğini görecek ve varsayılan kabuk(örneğimizdeki kabuk zsh) üzerinden çalıştırmayı deneyecektir.

Ayrıca shebang ifadesinin satır başına eklenmesi, biraz da "clean code" denilen "düzenli(temiz) kod" yazma kültürünün bir parçasıdır. Bu gibi alışkanlıklar uzun vadede verimli çalışmalar ortaya koymak adına oldukça önemli. Siz veya betik dosyanızı paylaştığınız diğer insanlar dosyayı açıp baktıklarında bash kabuğu için yazılmış olduğunu bu sayede kolayca fark edebilir. İlerleyen zamanlarda kendi yazmış olduğunuz betikleri açıp incelediğinizde ya da diğer insanların yazmış olduğu kapsamlı betik içeriklerini incelerken bu gibi düzenli çalışmaların, programın çalışma yapısını anlamada ne kadar kolaylık sağladığını sizler de görmüş olacaksınız.

Evet, script içerisinde kullanılan kabuk program çeşidini diğer bir deyişle gerekli çalışma ortamını dosyamızın en başına yazdığımıza göre artık script yazmaya tamamen hazırız.

İlk scriptimize, konsol ekranına çıktı basan standart bir örnek ile başlayalım istiyorum. Aksi halde başımıza taş falan yağabilir :)

Bunun için konsola çıktı basan komutumuz olan `echo` komutunu kullanacağız. Örneğin ben konsola `echo "selamlar"` yazarsam, çıktı olarak **selamlar** ifadesi konsola basılmış olacak.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/5.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/5.png)

İşte bu komutu betik dosyamızın içerisine yazıp kaydedersek, betik dosyamızı her çalıştırdığımızda konsol ekranına **selamlar** ifadesi otomatik olarak basılacaktır.

Hemen test etmek için `echo "selamlar"` komutumu betik dosyamın içerisine yazıp, dosyamı "**[selam.sh](http://selam.sh/)**" ismi ile kaydediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/6.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/6.png)

Dosyamı kaydederken dosya isminin sonuna **.sh** dosya uzantısını eklemem mecburi olmasa da, biraz önce bahsettiğimiz düzenli çalışma adına önemli bir ayrıntı olduğu için ekledim.
Aslında betik dosyamız, uygun çalışma ortamına sahip olduğu sürece sonunda "**sh"** uzantısı olmadan da çalışabilir. Ancak ileride hangi dosyaların betik dosyası olduğunu anlama konusunda, dosyaların sonlarındaki "**sh"** ifadeleri bizlere yardımcı olacağı için özellikle belirtilmesi önemlidir. Zira Linux sistemlerinde dosyayı çalıştırırken dosyanın uzantısının bir önemi yoktur. İlgili dosyanın çalıştırılması için gereken ortam sistemde yüklü ise dosya çalıştırılır. Yine de bu gibi uzantıları eklemek, dosyanın daha sonra kolay bulunabilmesi adına sınıflandırmaya katkı sunar.

Bu durumu daha iyi anlamak adına, yüzlerce dosyanın bulunduğu bir klasör ve bu klasördeki dosyaların hiç birinde ayırt edici uzantı bulunmadığı bir durum hayal edin. Böyle bir durumda hangi dosyanın betik dosyası olduğunu anlamanın tek yolu, dosyaların her birini tek tek açarak içlerine bakmayı gerektirir. Bu işi yapan araçları kullanabilirsiniz ancak bu verimsiz bir yöntemdir. En ideal yöntem dosya isimlerinin sonunda dosya türlerini belirterek, dosyaları kolay sınıflandırabilir kılmaktır.

Daha somut bir örnek görmek adına örneğin; içerisinde bir çok dosyanın bulunduğu bir dizindeyken, konsola `ls *.sh` gibi kısacık bir komut girerek sonunda **.sh** ifadesi geçen tüm betik dosyalarını tek seferde listeleyebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/7.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/7.png)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/8.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/8.png)

Ayrıca dosyalara uzantı eklemek, dosyayı çalıştırabilecek olan programların dosyaları kolay algılayabilmesini de sağlar. Örneğin kullanmakta olduğunuz editör destekliyorsa, bash programlamaya özel renklendirme ve programlamayı kolaylaştıran bir takım araçlar "**sh"** uzantısı sayesinde kullanılabilir olur.

Basit bir örnek olması açısından sonu "**sh"** ile biten ve bitmeyen iki dosyayı editör üzerinde açarak karşılaştırma yapabilirsiniz. Test etmek için nano editörünü kullanabilirsiniz. Bu duruma ek olarak dosya uzantıları, özellikle grafiksel arayüz kullanımında, dosyanın üzerine tıklandığında çalıştırılabilir olan araç ile doğrudan açılması gibi kolaylıklar da sağlar.

Yani kısacası dosyamı, sonunda "**.sh"** uzantısı olmadan da kaydetsem çalışacaktır. Ancak bu dosya uzantısını ekleyerek kazanacağım olumlu özellikler düşünüldüğünde, eklemeden kaydetmek oldukça mantıksız olacaktır. 

Ayrıca dosya isimlerinizde mümkün oldukça **Türkçe karakter** ve **kelimeler arasında boşluk** kullanımından kaçınmanızı öneririm. Zira kimi sistemlerde Türkçe karakter ve boşluk karakterinden doğacak sorunlar yüzünden betik dosyanız çalıştırılamayabilir.

Aşağıdaki kullanımlar global isimlendirmeye **uygun olmayanlara** birkaç örnektir.

**Örn;** "**betik dosyası**", "**merhaba dünya**", "**test betiği**", "**fıstıkçı şahap**", "**BETİK**".. vb..

Yukarıdaki örneklerde hem Türkçe karakter hem de kelimeler arası boşluk var ve bu tür isimlendirmeler, global yani herkes tarafından kullanılabilir betik dosyaları için yanlış isim tercihlerdir.

## Betik Dosyalarını Çalıştırmak

Yazmış olduğumuz betik dosyasını çalıştırmanın birden fazla yolu bulunmaktadır. Bunlardan ilki ve en basiti, konsola `bash betik_dosyası_adı` şeklinde komut vermektir. 

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/9.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/9.png)

Burada yapmış olduğumuz işlem, betik yazarken kullanmış olduğumuz kabuk dilini yani betiğin çalışabileceği ortamı doğrudan belirtmektir. 

Ayrıca betik dosyamızı `./betik` komutuyla da çalıştırabiliriz.

Aslında bu kullanım ilkine oranla daha sık tercih edilen bir yöntemdir. Hatta betik dosyalarını çalıştırmak için doğru olan temel kullanım yöntemimiz budur.

Ancak bu kullanımda diğer kullanımdan farklı olarak, dosyamızın çalıştırma yetkisinin bulunması gerekiyor. Aksi takdirde gördüğünüz gibi dosyamız **erişim yetkisi hatası**("**Erişim engellendi**") belirterek çalıştırılamıyor. 

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/11.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/11.png)

Hatta durumu teyit etmek üzere `ls -la` komutu ile dosyamızın yetkilerini inceleyecek olursak, dosyamızda çalıştırma yetkisinin bulunmadığını görebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/12.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/12.png)

Neticede betik dosyamız şuan sadece okunup/yazılabilir bir metin belgesinden ibaret. Bu sorunu aşmak için dosyamıza `chmod` komutu ile gereken çalıştırma yetkisini vermemiz gerekiyor.

Ben tüm kullanıcılara çalıştırma yetkisi vermek için konsola `chmod +x selam.sh` komutunu giriyorum. İşlemin ardından `ls -la` komutu ile dosyamızın aldığı yetkiyi teyit edebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/13.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/13.png)

Çıktılardan da anlayabileceğimiz gibi dosyamız artık çalıştırılabilir durumda. Hemen dosyamızı çalıştırarak bu durumu kesin olarak teyit edelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/14.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/14.png)

Ve gördüğünüz gibi betik dosyamız aldığı yetki sayesinde sorunsuz şekilde çalışmış oldu. Eğer yetkilendirme işlemini ve işlemde kullanılan komut bütününü anlamadıysanız temel Linux bilginizi tazelemeniz gerekebilir. Zira benim özellikle ayrıntılı olarak anlatmadığım tüm konular temel Linux bilgisi kapsamındaki konulardır. Lütfen eğitimden maksimum verimi alabilmek adına temel Linux bilginiz olduğundan emin olarak eğitime devam edin.

Dosyamızı çalıştırdık ancak, dosyamızı çalıştırmak üzere girmiş olduğumuz komutun çalışma yapısını daha iyi anlamak adına, kullanmış olduğumuz `./` ifadesini de ayrıca açıklamak istiyorum.

Komutumuzda kullandığımız `.`(nokta) ifadesi, şu anda bulunmakta olduğumuz mevcut dizini temsil ediyor.

Noktadan sonra kullanmış olduğumuz `/`(slash-taksim) ifadesi ise bulunduğumuz konumdaki betik dosyasına ulaşıp çalıştırmamızı sağlıyor.

Yani ***/root/selam.sh*** konumunda bulunan betiği çalıştırmak için benim konsola `./selamlar.sh` şeklinde yazmamla `/root/selam.sh` şeklinde yazmam aslında aynı şeyi ifade ediyor. Bu örnekte ben **/root** dizinindeyken komut girdiğim için **nokta** ifadesi bu ***/root*** konumunu temsil ediyor. Kabuğa taksim işareti `/` ile bir dosyanın tam konumu belirtildiğinde, kabuk bu dosyanın uygun ortamda çalıştırılmasını sağlar. Yani kabuğa tam konumu belirtilmiş ve çalıştırılma yetkisi olan tüm dosyalar kabuğun gözünde "çalıştırılacak dosya" sınıfındadır.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/15.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/15.png)

Şu ana kadar her şey harika gitti ve betik dosyamızı iki farklı yoldan nasıl çalıştırabileceğimizi görmüş olduk.

Peki ama daha öncesinde `bash` komutu ile aynı dosyamızı çalıştırma yetkisi bulunmamasına rağmen nasıl çalıştırabilmiştik ?

Yani `bash selamlar.sh` ile `./selamlar.sh` kullanımları arasındaki yetki almayı gerektiren fark neydi ?

Bu durumun nedeni `bash` komutunu kullandığımızda konsola, "***bu bir bash kabuk betiğidir, bu betiği doğrudan bash ortamında çalıştırabilirsin***" diyor olmamızdır. Halihazırda bash kabuğunu çalıştırma yetkimiz olduğundan(nitekim şu an ona emir veriyoruz), bu dosya için ekstra çalıştırma yetkisine ihtiyaç duymadan bash üzerinden çalıştırabildik. Kabuğa bash [selamlar.sh](http://selamlar.sh) komutu girdiğimde; mevcut kabuğum bash aracını çalıştırmak istediğimi çekirdeğe bildiriyor, çekirdekte çalıştırma yetkim olduğu için bash aracını "selamlar.sh" argümanı ile çalıştırmama izin veriyor. Argüman olarak "selamlar.sh" dosyasını alan bash aracı en nihayetinde betiği alıp çalıştırıyor.

Öte yandan kabuğa `./betik` şeklinde emir verdiğimizde, "*al bu dosyayı uygun ortam hangisi ise onda çalıştır*" demiş oluyoruz. Kabukta; "*madem dosyanın çalıştırılmasını istiyorsun o zaman dosyanın çalıştırılabilirlik durumuna bakayım ona göre çalıştırılmasını sağlayayım*" diyor. Eğer dosyanın çalıştırılma yetkisi yoksa dosya içeriği henüz okunmadan "erişim engellendi" hatası ile işlemi iptal ediyor. Dosyanın çalıştırılabilirlik yetkisi varsa hangi ortamda çalıştırılacağını öğrenmek için dosyanın ilk satırı okunuyor. Eğer bizler ilk satırı boş bırakmışsak yani "shebang" tanımını eklemediysek, sistemde varsayılan olarak kullanılan kabuk dili aracılığı ile dosyamız çalıştırılıyor. Şayet ilk satırda başka bir kabuk dili veya çalışma ortamı belirtmişsek de dosyanın bu ortam çalıştırılması sağlanıyor. Hatta bu durumu teyit etmek üzere, dosyamızın başına alakasız bir çalışma ortamı ekleyip, sonucu gözlemleyebiliriz.

Dosyamın başına **/bin/bash** yerine **/bin/deneme** şeklinde bir ifade ekleyip kaydediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/16.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/16.png)

Ve dosyamı `./selamlar.sh` şeklinde çalıştırmayı deniyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/17.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/17.png)

Bu işlemin sonucunda konsol bana "***hatalı yorumlayıcı: Böyle bir dosya ya da dizin yok***" şeklinde çıktı basarak, shebang kısmında belirtilen ortamın sistemde mevcut olmadığını belirtmiş oldu.

Aynı dosyayı `bash selamlar.sh` komutu ile çalıştırdığımda ise, sistem dosyanın shebang kısmında yer alan ortamın ne olduğuna bakmadan doğrudan bash ortamında dosyayı çalıştırıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/18.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Ba%C5%9Flarken/18.png)

En nihayetinde ilk betik dosyamızı oluşturup sorunsuzca çalıştırmayı başardık. Üstelik anlatım sırasında hangi işlemin neden gerçekleştiğini de sırasıyla öğrenmiş olduk.

Bir sonraki kısımda kısaca kabuğun komutları nasıl ele aldığından bahsedip, değişkenlere de değiniyor olacağız.

<aside>
ℹ️ **Ek Açıklama:** Anlatımlar sırasında tıpkı bu bölümde olduğu gibi kullanacağımız yapıları ve bu yapıların tepkilerini anında gözlemeyebilmek için öncelikle konsol üzerinden etkileşimli şekilde ele alıyor olacağız. Zaten anlatımlara devam ettikçe öğrendiğimiz yapıları nasıl betik dosyası içerisinde bir bütün halinde kullanabileceğimizi de öğrenmiş olacağız. Özetle bu eğitim her ne kadar betik oluşturmak üzerine olsa da öğrenme aşamasında genellikle doğrudan sonuçları görebileceğimiz etkileşimli kabuk yani konsol üzerinden ilerliyor olacağız.

</aside>

<aside>
⚠️ **Yazar Notu:** Anlatımlar sonuç odaklı bir yol izlemekten ziyade temeli sağlam oluşturmak üzere ilerlediğinden kimi kısımlardaki anlatımlar belki biraz uzun olarak gözükebilir. Ancak eğitim sürecinde yer alan anlatımların, konuyu iyi bir biçimde kavramanız ve kolay öğrenmeniz için bulunduğunu lütfen unutmayın. Yani tüm gayretimiz "ne" olduğundan ziyade "neden" olduğunu kavrayabilmektir. Bu sayede öğrendiğimiz bilgiler bizim için gerçekten anlamlı ve kalıcı olabilir. Ve çok daha önemlisi merak duygunuzu tetikleyerek daha derinlemesine araştırma yapmanızı sağlayabilir. Eğitmen olarak bana inanmıyorsanız bile sadece güvenin ve eğitim sonunda kararınızı kendiniz verin. Özetle anlatımı yapılan hiç bir konuyu ben özellikle belirtmediğim sürece doğrudan geçmenizi tavsiye etmem.(Ara vermek ya da sıkılıp daha sonrası için bırakmayı kast etmiyorum. Bir daha okumamak üzere doğrudan atlamaktan bahsediyorum.)

</aside>

Betik dosyamızı oluşturup nasıl çalıştırabileceğimizi öğrendik. Peki ama kabuk dediğimiz yapı bizden aldığı emirleri nasıl anlamlandırıp gerektiğinde ilgili aracı bulup çalıştırıyor ? Yani kabuk aslında nasıl çalışıyor ?

# Kabuk Nasıl Çalışır ?

Elbette tüm detayları ile kabuğun nasıl çalıştığına şimdilik değinmemiz mümkün değil. Burada genel çalışma yapısından bahsedip kitap boyunca bu yapıya atıfta bulunarak ayrıntılarından uygulamalı olarak bahsediyor olacağız. Neticede kabuğun nasıl çalıştığı tüm kitabın özetidir. Bu sayede kitabın sonlarına doğru tüm çalışma yapısını uygulamalı olarak teyit etmiş olacağız. 

Kabuğun aslında bir yazılım olduğundan ve bize grafiksel arayüz harici bir çalışma ortamı sunduğunu biliyoruz. Kabuğa bir emir veririz kabukta bu emiri anlamlandırıp işlemin gerçekleştirilmesine aracılık eder.