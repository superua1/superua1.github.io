# SIGTTOU

Description: TTOU signal is sent to a process when it attempts to write from the tty while in the background. The compliment to TTIN.
Number: 22
Standard: POSIX