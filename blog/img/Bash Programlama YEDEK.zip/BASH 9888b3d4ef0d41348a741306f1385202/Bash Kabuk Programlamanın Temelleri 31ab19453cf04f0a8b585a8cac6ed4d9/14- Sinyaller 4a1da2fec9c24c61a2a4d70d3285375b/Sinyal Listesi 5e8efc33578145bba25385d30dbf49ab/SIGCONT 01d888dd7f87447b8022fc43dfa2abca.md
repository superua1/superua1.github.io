# SIGCONT

Description: Continue executing after stopped, e.g., by STOP
Number: 18
Standard: POSIX