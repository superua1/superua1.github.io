# SIGFPE

Description: Floating point exception. The FPE signal is sent to a process when it executes an erroneous arithmetic operation, such as division by zero.
Number: 8
Standard: ANSI