# SIGIO,SIGPOLL

Description: Input/output is now possible. SIGPOLL is a synonym for SIGIO, and in Linux its behavior is identical to SIGURG.
Number: 29
Standard: 4.2 BSD