# SIGSTOP

Description: The STOP signal instructs the operating system to stop a process for later resumption. This is one of two signals, along with KILL, which cannot be intercepted, ignored, or handled by the process itself.
Number: 19
Standard: POSIX