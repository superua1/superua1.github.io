# SIGXFSZ

Description: The XFSZ signal is sent to a process when it grows a file larger than the maximum allowed size.
Number: 25
Standard: 4.2 BSD