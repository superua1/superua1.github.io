# SIGUSR2

Description: User-defined signal 2. This is one of two signals designated for custom user signal handling.
Number: 12
Standard: POSIX