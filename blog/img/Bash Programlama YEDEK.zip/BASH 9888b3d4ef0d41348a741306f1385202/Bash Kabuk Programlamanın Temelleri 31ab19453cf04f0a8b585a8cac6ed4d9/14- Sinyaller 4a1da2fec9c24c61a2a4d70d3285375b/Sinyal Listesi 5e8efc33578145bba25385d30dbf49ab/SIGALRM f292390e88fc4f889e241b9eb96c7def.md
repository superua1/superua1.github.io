# SIGALRM

Description: The ALRM signal notifies a process that the time interval specified in a call to the alarm() system function has expired.
Number: 14
Standard: POSIX