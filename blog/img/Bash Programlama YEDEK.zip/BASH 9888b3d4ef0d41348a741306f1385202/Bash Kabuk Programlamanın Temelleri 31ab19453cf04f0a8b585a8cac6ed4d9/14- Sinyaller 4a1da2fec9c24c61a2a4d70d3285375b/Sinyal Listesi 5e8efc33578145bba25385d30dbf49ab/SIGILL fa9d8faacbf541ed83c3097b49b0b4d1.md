# SIGILL

Description: Illegal instruction. The ILL signal is sent to a process when it attempts to execute a malformed, unknown, or privileged instruction.
Number: 4
Standard: ANSI