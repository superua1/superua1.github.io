# SIGINT

Description: The INT signal is sent to a process by its controlling terminal when a user wishes to interrupt the process. This signal is typically initiated by pressing Control-C, but on some systems, the "delete" character or "break" key can be used.
Number: 2
Standard: ANSI