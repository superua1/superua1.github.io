# SIGUNUSED,SIGSYS

Description: Unused signal. This signal is provided for compatibility reasons, for example when porting software from an operating system with different or unsupported signals in Linux. In Linux, SIGSYS is a synonym for SIGUNUSED.
Number: 31
Standard: System V r4