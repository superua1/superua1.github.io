# SIGWINCH

Description: Window change. The WINCH signal is sent to a process when its controlling terminal changes size, for instance if you resize it in your window manager.
Number: 28
Standard: 4.3 BSD, Sun