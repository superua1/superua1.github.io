# SIGPWR,SIGLOST

Description: Power failure. The PWR signal is sent to a process when the system detects a power failure. SIGLOST is a synonym for SIGPWR.
Number: 30
Standard: System V