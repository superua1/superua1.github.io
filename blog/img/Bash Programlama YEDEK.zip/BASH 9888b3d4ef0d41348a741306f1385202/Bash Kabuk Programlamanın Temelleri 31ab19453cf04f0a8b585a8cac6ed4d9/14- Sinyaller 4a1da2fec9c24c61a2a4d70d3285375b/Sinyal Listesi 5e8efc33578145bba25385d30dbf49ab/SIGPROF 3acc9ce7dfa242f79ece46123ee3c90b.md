# SIGPROF

Description: Profiling alarm clock. Indicates expiration of a timer that measures CPU time used by the current process ("user" time), and CPU time expended on behalf of the process by the system ("system" time). These times may be used to implement code profiling facilities. By default, this signal terminates the process, but it's intended for use with process-specific signal handling.
Number: 27
Standard: 4.2 BSD