# Böl ve Eşitle

Karakter: /=