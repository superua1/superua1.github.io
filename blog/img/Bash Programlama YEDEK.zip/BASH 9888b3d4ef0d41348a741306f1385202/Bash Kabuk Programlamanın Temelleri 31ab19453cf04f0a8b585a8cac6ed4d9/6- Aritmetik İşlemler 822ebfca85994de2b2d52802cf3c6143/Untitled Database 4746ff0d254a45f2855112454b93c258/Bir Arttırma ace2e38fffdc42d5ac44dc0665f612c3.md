# Bir Arttırma

Karakter: ++