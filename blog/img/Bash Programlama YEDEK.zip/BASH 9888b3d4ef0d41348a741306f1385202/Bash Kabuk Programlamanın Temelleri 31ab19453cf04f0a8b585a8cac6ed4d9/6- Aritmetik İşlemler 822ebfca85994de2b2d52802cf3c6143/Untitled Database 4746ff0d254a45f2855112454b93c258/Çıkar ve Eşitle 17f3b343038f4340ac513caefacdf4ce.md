# Çıkar ve Eşitle

Karakter: -=