# Mod Al ve Eşitle

Karakter: %=