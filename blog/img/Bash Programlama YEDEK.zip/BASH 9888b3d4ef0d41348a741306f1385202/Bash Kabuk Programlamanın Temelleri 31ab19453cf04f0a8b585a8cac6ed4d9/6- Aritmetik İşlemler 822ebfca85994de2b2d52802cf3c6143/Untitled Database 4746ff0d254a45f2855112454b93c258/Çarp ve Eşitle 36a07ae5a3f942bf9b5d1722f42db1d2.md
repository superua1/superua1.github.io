# Çarp ve Eşitle

Karakter: *=