# Çıkarma

Karakter: -