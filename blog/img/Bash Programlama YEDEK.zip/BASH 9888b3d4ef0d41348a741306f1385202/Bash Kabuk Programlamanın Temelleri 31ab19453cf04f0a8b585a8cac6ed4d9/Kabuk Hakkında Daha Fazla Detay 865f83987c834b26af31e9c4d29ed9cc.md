# Kabuk Hakkında Daha Fazla Detay

Kabuğun competetive olması ne demek : [https://unix.stackexchange.com/questions/145522/what-does-it-mean-to-be-sh-compatible?noredirect=1&lq=1](https://unix.stackexchange.com/questions/145522/what-does-it-mean-to-be-sh-compatible?noredirect=1&lq=1)

![Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%20865f83987c834b26af31e9c4d29ed9cc/Untitled.png](Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%20865f83987c834b26af31e9c4d29ed9cc/Untitled.png)