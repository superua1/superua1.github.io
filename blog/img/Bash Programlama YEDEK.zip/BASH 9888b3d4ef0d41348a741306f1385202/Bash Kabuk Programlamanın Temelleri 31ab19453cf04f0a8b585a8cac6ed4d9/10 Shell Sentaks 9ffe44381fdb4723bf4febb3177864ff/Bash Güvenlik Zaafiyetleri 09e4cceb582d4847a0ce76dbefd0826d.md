# Bash Güvenlik Zaafiyetleri

Bunları yapmayın !!!

[https://mywiki.wooledge.org/BashGuide/Practices#Don.27t_Ever_Do_These](https://mywiki.wooledge.org/BashGuide/Practices#Don.27t_Ever_Do_These)

Her yazılımda olabileceği gibi bash kabuğunda da güvenlik zaafiyetleri keşfedilebiliyor. Bu sebeple mümkün olduğunca yeni kabuk sürümlerini kullanmanız yani sisteminizdeki kabuğu güncel tutmanız son derece önemlidir. Bu durumun kritikliğine örnek olarak geçmişte ortaya çıkmış birkaç zaaftan bahsedebiliriz.

20 yıl sonra fark edilen shellshock zaafiyeti

env degisken=”() { :;} ; echo Bash is Infected” /bin/sh -c “echo completed”

# Kullanıcıdan Veri Almak

Ayrıca diğer bir bakış açısıyla çalıştırılan betikler kullanıcılardan veri alıyorsa, bu verilerin betik içerisinde kullanıldığı alanlara dikkat etmek gerekir. Aksi halde yetkisiz kullanıcıların sistemde komut yürütmesine varan kritik zaafiyetlere neden olabilir. Örneğin `eval`, isminden de anlaşılabileceği gibi yanlış kullanımda son derece kötü sonuçlar doğurabilir. 

Kullanıcıdan gelecek emirlerin ya da değişkenlere tanımlanan komutların çalıştırılması konusunda dikkatli olmak gerek;

[https://unix.stackexchange.com/a/444949/364572](https://unix.stackexchange.com/a/444949/364572)