# 13- İşlem(Process) Yönetimi

[https://devconnected.com/understanding-processes-on-linux/](https://devconnected.com/understanding-processes-on-linux/)

[https://icarus.cs.weber.edu/~dab/cs1410/textbook/4.Pointers/memory.html](https://icarus.cs.weber.edu/~dab/cs1410/textbook/4.Pointers/memory.html)

Kısa özet: [https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7](https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7)

[https://totozhang.github.io/2016-01-16-linux-zombieprocess/](https://totozhang.github.io/2016-01-16-linux-zombieprocess/)

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

Oturum açtığınızda, kabuk başlar ve onu başlatan / bin / login programından bir dizi değişkeni, G / Ç akışını ve işlem özelliklerini devralır . Buna karşılık, oturum açma veya ana kabuktan başka bir kabuk üretilirse (çatallanırsa), bu alt kabuk (alt kabuk) ana kabuğundan belirli özellikleri devralır. Bir alt kabuk, çeşitli nedenlerle başlatılabilir: arka planda işlemeyi işlemek için, komut gruplarını işlemek için veya komut dosyalarını yürütmek için. Alt kabuk, üst biriminin ortamını miras alır. Ortam, işlem izinlerinden (işlemin sahibi olan), çalışma dizini, dosya oluşturma maskesi, özel değişkenler, açık dosyalar ve sinyallerden oluşur.

KABU TÜRLERİ>KABUĞUN KULLANDIĞI DOSYALAR>İŞLEMLER...

process environment source ve bunların yakın ilişkisini daha sıralı ve açık şekilde ifade et

harici araçlar çalıştırılırken mevcut işlem fork ile çatallanıp exec ile ilgili işlemi yürütüyor. Mevcut işlemdeki çevresel değişkenler bu işleme aktarılmıyor. Kabuk üzerindeki her işlem execution environmen adı verilen değerlere sahiptir. Alt kabukta başlatılan ya da doğrudan yerleşik veya kabuk fonksiyonu olan işlemlerde mevcut çalıştırma ortamı bu işlemlere de aktarılır. AÇIKLAMALAR YANLIŞ VEYA YETERSİZ OLABİLİR ANCAK BU KONUYLA BAĞLANTILI PEK ÇOK KAVRAM VE BU KAVRAMLARI NETLEŞTİR MUTLAKA

FORKSTAT ARACINA MUTLAKA BAK. BU ARAÇ İLE FORK EXEC VE EXİT TAKİBİ YAPILABİLİYOR..

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_2.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_2.png)

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_3.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_3.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png)

Bu bölümde "process" olarak geçen "işlem" kavramının anlaşılması ve yönetilebilmesi üzerinde duruyor olacağız. Kimi zaman "process" terimi için Türkçe olarak "süreç" ifadesi hatta "proses" kullanılsa da, terimin yapısı gereği "işlem" ifadesi daha doğru bir tanımlama olacaktır. Bizler de anlatımlarımız sırasında "process" kavramı için "işlem" ifadesini tercih ediyor olacağız. Bu açıklamayı, harici Türkçe kaynaklara göz attığınızda "işlem" yerine "süreç" ya da "proses" ifadeleriyle karşılaşmanız halinde şaşırmamanız için ekledim. 

Bu bölümün sonunda, şu ana kadar ele aldığımız ve ileride ele alacağımız pek çok kavramın bizler için daha anlamlı hale geleceğini umuyorum. Çok ayrıntılı olmasa da **genel işleyişi kavramamıza yardımcı olacak temel bilgilere** değiniyor olacağız. O halde daha fazla vakit kaybetmeden, anlatımlara "işlem" yani "process" olarak geçen yapının tanımı ile başlayabiliriz.

wait

bg

fg

jobs

nohup

disown

nice..

vs..

<aside>
ℹ️ **Not:** Buradaki anlatımlar bash programlama kapsamında ele alınmıştır. Daha fazla detay için elbette işletim sistemi özelinde harici kaynaklara(işletim sistemi nasıl çalışır? işletim sistemi nasıl programlanır ? vb.) göz atabilirsiniz. Anlatımlar sırasında mümkün oldukça temelden başlayıp konu bağlamından uzaklaşmamaya ve gerekli olan bilgileri aktarmaya özen göstereceğiz. Yine de bu bölüm içerisinde bağlantılı şekilde pek çok kavramdan bahsedeceğimiz için baştan sona birkaç kez okumak isteyebilirsiniz.

</aside>

## İşlem(Process) Nedir?

Oldukça genel bir tanımla, söz konusu işletim sistemleri olduğunda; diskimiz üzerinde mevcut bulunan ve sistemin çalıştırabileceği yapıda olan her türlü programın öncelikle RAM(hafıza)'e yüklenmesi ve oradan da sırası geldiğinde CPU(işlemci) üzerinde işlenmesine bütüncül olarak "***process***" yani "***işlem***" diyoruz. Tanımı daha anlaşılır kılmak adına bahsi geçen temel kavramları kısaca açıklayacak olursak;

**Program:** herhangi bir yazılım dili ile yazılmış ve makine kodu olarak derlenmiş olan talimatlar dizisine verilen genel isimdir. Örneğin bash kabuğu C dili ile yazılmış ve derlenmiş olan bir programdır. Yani aslında bizler bash kabuk programını çalıştırırken, makine kodundan oluşturulmuş talimatlar dizisi işlemci tarafından işlenmektedir.

**Makine Kodu:** 2'lik sayı sistemi(binary) ile yani 0 ve 1 rakamları ile oluşturulmuş, işlemciler tarafından anlaşılabilen ve işlenebilen dildir. Bizler yüksel seviyeli olarak geçen "bash", "python", "java", "C" ve benzeri diller ile programlarımızı yazarız ancak bu dili işlemcimiz doğrudan anlamlandıramaz. Yüksek seviyeli diller insanların kolay okuyup yazabileceği yapıdadır.  Yüksel seviyeli diller ile programladığımız talimatların işlemcinin anlayacağı dil olan düşük seviyeli makine diline, çevirici yardımıyla dönüştürülmesi gerekir. Dönüştürme işleminde "derleyici" ve "yorumlayıcı" olmak üzere 2 temel yaklaşım vardır. Kısaca açıklamamız gerekirse;

**Derleyici:** Tüm komutları okuyup optimizasyonu yaparak işlemcinin çalıştırabileceği şekilde makine koduna dönüştürür. 

**Yorumlayıcı:** Komutları satır satır okuyup sırasıyla yorumlayarak işlemci tarafından anlaşılır hale getirilmesini sağlar. Yorumlayıcılar tek seferde kodun tamamına bakmaz, kodun parça parça dönüştürülmesini sağlar. Derleyicilere oranla bu yöntemde kodun genelinde iyileştirme yapılmadığından komutlar kısmen daha verimsiz çalışır. Ancak kabuk dili gibi anlık olarak komutların yorumlanması gereken durumlar için yorumlayıcı özelliği harika bir çözüm sunmaktadır. Bash de yorumlayıcı yapıda bir dil olduğu için kullanıcıdan gelen komutları satır satır okuyup değerlendirir. 

Programlama için kullandığımız bash kabuğumuz hem etkileşimli kullanım hem de programlanabilirlik sunduğu için yorumlayıcı yapıda olması makuldür. Kabuk özelinde bu konunun daha fazla ayrıntısına şu an için ihtiyacımız yok. İşlem dediğimiz olgunun temelde hangi aşamalardan geçtiğine kısaca değinmek üzere temel bileşenleri açıklayarak devam edebiliriz.

Örneğin firefox tarayıcısını açmak için kabuğunuza firefox komutunu girdiğinizde, kabuk programı yazdığınız komutu yorumlayıp firefox programı diskte yüklü ise bulup başlatılmasını sağlar. 

Firefox programının başlatılabilmesi için yani işlem halini alabilmesi için sırasıyla disk > ram > cpu aktarım aşamalarından geçmelidir.

![https://web.stanford.edu/class/cs101/software-program.png](https://web.stanford.edu/class/cs101/software-program.png)

**Disk:** Programlar gibi sistem için gerekli olan dosyaları bünyesinde bulunduran kalıcı depolama birimidir. Programların aslında makine kodu talimatlarını içeren dosyalar olduğunu biliyorsunuz. Disk bunları kalıcı olarak depolamaktan sorumludur.

![https://web.stanford.edu/class/cs101/software-cpu.png](https://web.stanford.edu/class/cs101/software-cpu.png)

**RAM:** Disk üzerinde yer alan programların(makine kodu talimatlarının) işlemci tarafından işlenmek üzere geçici olarak hafızada tutulmasını sağlar. Diskteki verilerin doğrudan işlemciye aktarılmayıp RAM'e aktarılmasının en temel nedeni RAM'in sağladığı hızdır. RAM'in, verileri kalıcı olarak kaydetme ve saklama zorunluluğu bulunmadığı için programlara ait talimatlar dizisini çok hızlı şekilde alıp işlemciye aktarabiliyor. İşi biten talimatlar da RAM üzerinden siliniyor. Yüksek hızlı aktarım sayesinde yüksek işlem kapasitesi sağlanabiliyor.

**CPU:** Program dosyaları içerisinde bulunan işlem emirlerini yerine getirmek üzere, RAM üzerinde yer alan programın makine kodu talimatlarını okuyup uygun şekilde işler. 

![https://web.stanford.edu/class/cs101/software-program-run.png](https://web.stanford.edu/class/cs101/software-program-run.png)

En nihayetinde disk üzerindeki programımız bir işleme dönüştürülmüş olur. 

Netleştirmek için son olarak program ile işlemin farkını tek cümlede özetleyecek olursak; Program, belirli bir görevi tamamlamak için tasarlanmış bir dizi talimat içerir. Programlar, disk üzerinde gerektiğinde çalıştırılmak üzere kalıcı olarak tutulur. İşlem ise programın hafızaya(RAM) yüklenip işlemci tarafından çalıştırılmasıdır. 

Programların işleme dönüşümünün en yalın hali bahsettiğimiz şekildedir. Bu detayları(hatta çok çok daha fazlasını) biliyor ya da bilmeseniz de buradaki düzeyde açıklanmış olmasını gereksiz buluyor olabilirsiniz. Yine de anlatımın herkes tarafından sıralı ve kolay takip edilebilir olası için eklendiğini bilmenizi isterim. 

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled.png)

Genel hatlarıyla işlemin ne olduğunu öğrenmiş olduk. Şimdi GNU/Linux yani işletim sistemi özelinde işlemin nasıl oluştuğuna da çok kısaca değinerek ihtiyacımız olan bilgiyi edinelim.

İşlemler çekirdek tarafından oluşturulur. Elbette çekirdek durduk yere işlem de oluşturmaz. İlk işlem hariç, sistem üzerinde çalıştırılan çeşitli işlemler yeni işlemler oluşturulması için çekirdeğe çağrıda bulunur. 

# GNU/Linux Üzerinde İşlemlerin Oluşumu

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

[https://linuxhint.com/fork-system-call-linux/](https://linuxhint.com/fork-system-call-linux/)

[https://www.youtube.com/watch?v=2JC39IN0fnY&ab_channel=ahmetalpbalkan](https://www.youtube.com/watch?v=2JC39IN0fnY&ab_channel=ahmetalpbalkan)

Asıl odak noktamız doğrudan GNU/Linux mimarisi değil ama sağlam temel için kısaca özetlememiz gerekirse, GNU/Linux'ta, tipik önyükleme işleminde 6 farklı aşama vardır.

1. **BIOS** : Bilgisayarınızı ilk açtığınızda donanım kontrolü gerçekleştirir. Daha sonra işletim sisteminin boot edilebilmesine öncülük eden MBR önyükleyicisini bulup çalıştırır.
2. **MBR** : İşletim sistemini kurulu olduğu diskten boot edecek olan bootstrap(GRUB) programını bulup çalıştırır.
3. **GRUB** : İşletim sistemi çekirdeğinin önyüklenmesini sağlar. Birden fazla alternatif varsa seçenek listesi şeklinde hangisini önyüklemek istediğiniz size sorulur.
4. **KERNEL** : İlk işlem olan init işlemini başlatır.
5. **INIT** : Çalışma seviyesine(runlevel) göre gerekli işlemlerin başlatılmasını sağlar. Bu noktada, sistem başlatma tamamlanmıştır.
6. **RUNLEVEL** : Sistemin başlatılacağı çalışma seviyesini ifade eder. Farklı çalışma seviyesinde farklı hizmet ve servisler başlatılır. Farklı çalışma seviyeleri sayesinde sistem tam olarak ihtiyaç duyulan servis ve hizmetler ile başlatılabilir.

Çok kısaca açıkladığımız genellemenin ardından ilk işlem olan init hakkında biraz daha ayrıntıya deyenelim.

[https://ocw.unican.es/pluginfile.php/2782/course/section/2579/topic_3.pdf](https://ocw.unican.es/pluginfile.php/2782/course/section/2579/topic_3.pdf)

Çekirdeğimiz ilk işlem olan ana işlemi yani "init" işlemini başlatıyor. Burada init olarak geçen işlem, sistem başlangıcında çalıştırılması gereken işlemlerin başlatılmasından sorumludur. Zaten "init" isimi "initialization" yani "başlatma" ifadesinin kısaltmasıdır. Sistemin açıldığı runlevel yani çalışma seviyesine göre sistem başlangıcında belirli işlemlerin başlatılmasına öncülük eder. System V, upstart, systemd gibi pek çok init varyasyonu vardır. Sizin sisteminizde başlatma için hangi init'in kullanıldığı fark etmeksizin, tüm işlemler init yani ilk işlemin altında hiyerarşik düzende başlatılır. Init ata işlemdir. Bu ne demek oluyor ?

Sistemin yapısı gereği, çekirdeğin başlattığı init işlemi hariç, yeni bir işlem başlatılabilmesi için mevcut işlemin fork( ) ve exec( ) sistem çağırısında bulunması gerekiyor. Netleştirmek için açıklamaya devam edelim.

Örneklendirecek olursak, diyelim ki init işlemi çalıştıktan hemen sonra bash kabuğunun başlatılmasını istedi. Bash kabuğunun başlatılması için bash kabuğunun yeni bir işlem olarak çalıştırılması gerek. Yeni işlem oluşturmak için init işlemi, çekirdeğe çatallama olarak geçen fork( ) sistem çağrısında bulunur. Çatallama çağrısı sonucunda mevcut init işleminin **birebir kopyası olan** yeni bir işlem oluşturulur ve yeni işleme benzersiz bir işlem numarası(pid) tanımlanır. Bu sayede ana işlem ve oluşturulan yeni alt işlem kolaylıkla ayırt edilip takip edebilir. 

![Untitled](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%201.png)

Ancak tüm süreç bununla sınırlı değildir. Çünkü yeni bir işlem oluşturulmuş olsa bile henüz çalıştırmak istediğimiz yeni programın yani bash programının makine kodu talimatları, oluşturulan yeni işleme aktarılmamıştır. Oluşturulan yeni alt işlem kopyalanarak oluşturulduğu için hala init'in makine kodu talimatlarına sahiptir. Çatallanmış olan işlemde çalıştırılmasını istediğimiz program talimatlarının tanımlanabilmesi için exec( ) sistem çağırısı yapılır. 

![Untitled](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%202.png)

Böylelikle init işleminden kopyalanan program talimatlarının yerini bash kabuk programının talimatları alır. En nihayetinde bash programının makine kodu talimatlarını içeren ve benzersiz işlem numarasına sahip yeni bir işlem oluşturulmuş olur. İşletim sistemi üzerinde yeni bir işlem oluşturmanın en yalın hali bu bahsi geçen süreçtir. Eğer biraz karmaşık geldiyse endişelenmeyin. Anlatımın devamında tüm kavramlar yerli yerine oturmuş olacak.

[http://www.it.uu.se/education/course/homepage/os/vt18/module-2/process-management/](http://www.it.uu.se/education/course/homepage/os/vt18/module-2/process-management/)

Çok temel düzeyde işlemlerin oluşturulma yapısından bahsettik. Şimdi de somutlaştırmak üzere sorgulamaya devam edelim. İlk oluşturulan ana işlemin hangisi olduğunu teyit etmek için konsola `ps -ax | head -2` komutunu girebilirsiniz. Aldığınız çıktıda PID(process id) yani işlem numarası "1" olan işlemin sisteminize göre "init" ya da "sytemd" olduğunu görebilirsiniz.(Daha önce de bahsettiğimiz şekilde alternatif çalışma ortamlarında duruma göre ilk başlatılan işlem "init" ya da "systemd" dışında herhangi bir yapı da olabilir.) İşlemlere tanımlanan işlem numaraları, çekirdek için "0" olarak kabul edilip sıralı şekilde atandığından, "1" numaralı işlem ilk başlatılan işlemi yani "init" işlemini temsil ediyor.

Açıklamış olduğumuz çatallama durumunu daha net görebilmek adına konsola `pstree` komutunu verip, tüm işlemlerin aslında ilk başlatılan ata işlemin altında çalışan "child-process" yani "çocuk işlem" olduğunu teyit edebilirsiniz. 

```jsx
└─$ ps axf
  PID TTY      STAT   TIME COMMAND
    1 ?        Sl     0:00 /init
    7 ?        Ss     0:00 /init
    8 ?        S      0:00  \_ /init
    9 pts/0    Ss     0:00      \_ -bash
   37 pts/0    R+     0:00          \_ ps axf
```

Çekirdek init işlemini başlattı, init fork ile çatallanıp exec çağrısı ile bash kabuk programını işlem olarak başlattı, kabuk programı da çatallanıp exec çağrısı ile ps aracını yeni bir çocuk işlem olarak başlatmış oldu. Böylelikle anlatımın başında bahsetmiş olduğumuz hiyerarşik düzeni bizzat teyit edebiliyoruz. 

Bu hiyerarşik düzende özellikle aksi belirtilmediği sürece bash kabuğu ps aracının işini tamamlamasını beklerken, init işlemi de bash kabuğunun işini tamamlamasını bekleyecektir. Örneğin init işlemi sonlandırılırsa altındaki tüm çocuk işlemler de otomatik olarak sonlanacaktır.

Ebeveyn işlem, aksi belirtilmediği sürece çocuk işlemin işini bitirmesini bekler. Yan, ebeveyn wait( ) sistem çağrısı ile çocuk işlemden gelecek exit( ) çağrısını bekler. Başlatılan çocuk işlem sona erdiğinde, ebeveyn işlem exit( ) sistem çağrısı sayesinde çocuk işlemin sona erdiğini öğrenmiş olur. Üstelik döndürülen çıkış koduna(exit code) göre, çocuk işlemin başarılı olup olmadığından da haberdarıdır.(Bu konuya ileride detaylıca değineceğiz.)

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%203.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%203.png)

Ayrıca burada bahsi geçen alt işlemler "child process" yani "çocuk işlem" olarak isimlendirilirken, alt işlemi oluşturan üst işlemler de "ebeveyn" yani "parent process" olarak ifade edilebiliyor. Elbette bu bağlamda ana işlem çocuk işlemleri doğurabileceği gibi çocuklar da zamanı geldiğinde kendi çocuk işlemlerini doğurarak alt işlemleri için ebeveyn olabilirler. Zaten burada bahsi geçen çocuk ve ebeveyn gibi isimlendirmeler de yapının kolay kavranması için tercih edilmiştir. 

Eğer `pstree` komutunu kullandıysanız, bash kabuğun aslında ilk başlatılan işlemin(genellikle "init") alt işlemi olduğunu ve hatta kabuğa girmiş olduğumuz `pstree` komutun da bash işleminin altında çalışan bir işlem olduğunu fark etmişsinizdir. En nihayetinde sistemin genel işlem oluşturma yapısına değindiğimize göre şimdi bash kabuğu özelinde işlemlerin nasıl ele alındığına daha yakından bakabiliriz.  

## Bash Kabuğunda İşlemlerin Oluşumu

Bash kabuğu da en nihayetinde kendisinden önce başlatılmış olan bir işlemin çatallanması ve exec ile bash kabuk programının yeni işlem olarak çalıştırılması ile var olur. Bizler de bash kabuğuna komutlar vererek, bash kabuğu altında, programlar için işlemlerin oluşturulup çalıştırılmasını sağlamış oluruz. 

Bash kabuğuna verilmiş olan komutların türüne göre işlem oluşturma davranışı değişebilir. 

Bash, kendi bünyesinde bulunan yerleşik komutları(`cd`,`bg`,`echo`.. vs.) alt işlem oluşturmaya ihtiyaç duymadan geçerli kabuk işleminde çalıştırır. Çünkü bu komutlar aslında bash programının bir parçası olarak kabuk programına tahsis edilmiş olan işleme dahildirler. Dolayısıyla yeni bir işleme ihtiyaç olmadan, mevcut kabuk işlemi üzerinde çalıştırılırlar. Yeni işlem oluşturma zahmetine girilmediği için dahili komutlar son derece hızlı çalışırlar. Hızlı çalışmalarının yanında dahili komutlar, yalnızca kabuk iç bileşenlerine doğrudan erişimle yerine getirilebilecek görevler için vardırlar. Özetle, temel görevleri yerine getirmek üzere mevcut kabuk işlemine dahil olan pek çok dahili komut vardır. Dahili komutlar için yeni işlem oluşturulmaz.

Harici olan programlar bash kabuğu üzerinden çalıştırıldığında, bash kabuk programının bir parçası olmadıkları için; mevcut işlemin çatallanması ile oluşturulan kopya işlemdeki program talimatları,               exec çağrısı ile çalıştırılacak programın talimatları ile değiştirilir. Yani bash kabuğuna dahili olmayan araçlar kabuğunun altında yeni bir çocuk işlem oluşturulup burada çalıştırılabilirler. Örneğin bizim anlatım sırasında girmiş olduğumuz `ps` komutu aslında harici bir programdır. Eğer sistemde yüklü ise `ps` programının çocuk işlem üzerinden çalıştırılmasına bash kabuğu yalnızca aracılık eder. ps aracını çalıştırmak üzere kabuğa emir verdiğimizde, mevcut bash kabuk işlemi çatallanır ve exec ile ps program talimatları çatallanmış olan bash program talimatlarının yerini alır. Böylelikle bash kabuğu altında ps harici programı çocuk işlem olarak çalıştırılmış olur.

Bash kabuğu kendi bünyesinde bulunan dahili komutları çalıştırırken yalnızca çatallama işlemi için sistem çağrısında bulunur. Ancak harici araçların bash kabuğu üzerinden çalıştırılması talep edildiğinde, çatallama ve exec sistem çağrıları ile ilgili araç alt işlemde çalıştırılır. Bu sebeple dahili komutlar elbette harici komutlara oranla daha performanslı şekilde çalışır. Çünkü dahili(yerleşik-builtin) komutlar için her defasında exec sistem çağırısı ile yeni program talimatları yüklenmez, yalnızca mevcut bash işleminin devamı olarak yürütülürler.

Mevcut işlemin çatallanarak yeni bir işlem oluşturma durumunu basitçe şematize etmemiz gerekirse;

Üzerinde çalışmakta olduğumuz bash kabuğunda yerleşik komut girersek;

**Not:** Bash kabuğunda yerleşik olan tüm komutları `compgen -b` komutu ile öğrenebilirsiniz. 

Üzerinde çalışmakta olduğumuz bash kabuğunda harici komut girersek;

İşlemlerden ve işlemlerde ebeveyn-çocuk ilişkisinden bahsetmiş olduk. Peki ya daha önce hiç alt-kabuk(subshell)  diye bir kavram duymuş muydunuz ? Alt kabuk kavramı genellikle çocuk işlem ile karıştırılan bir kavramdır. Karışıklığı önlemek adına gelin altkabuk kavramını açıklayarak devam edelim.

Alt kabuklar hakkında; Betik dosyalarının, parantez içerisine yazılan komutların ve pipe işaretinin

[https://unix.stackexchange.com/a/442704/364572](https://unix.stackexchange.com/a/442704/364572)

[https://unix.stackexchange.com/questions/393349/difference-between-subshells-and-process-substitution](https://unix.stackexchange.com/questions/393349/difference-between-subshells-and-process-substitution)

command substation process substation sub shell bu kavramları netleştir

[http://mywiki.wooledge.org/ProcessSubstitution](http://mywiki.wooledge.org/ProcessSubstitution)

## Alt Kabuklar(Subshell) Hakkında

Eğer kabuğa `bash` komutunu girersek, mevcut kabuğumuz sistem üzerinde bash programını arar ve muhtemelen /usr/bin/bash dizininde bulduktan sonra harici bir program olduğu için çocuk işlem oluşturup kabuğu burada çalıştırır. 

bash fork exec bash

Her ne kadar mevcut kabuğun altında çocuk işlem olarak çalıştırılmış olsa da bu kabuğa alt kabuk denmez. Bash kabuğuna göre, çalıştırılan yeni kabuk yalnızca çocuk işlem olarak çalıştırılan harici bir programdır. 

Buna karşın biz özellikle çocuk işlemde mevcut kabuğun birebir kopyasını çalıştırmak istediğimizi uygun şekilde belirtirsek, bu defa **mevcut kabuğun birebir kopyası** çocuk işlemde çalıştırılır. 

Eğer çocuk işlemde, mevcut kabuğun birebir kopyası yani tüm ortam özellikleri de dahil bir kopyasının çalıştırılmasını sağlarsak buna alt kabuk(subshell) denir. Burada bahsi geçen [ortam özellikleri](https://pubs.opengroup.org/onlinepubs/9699919799.2016edition/utilities/V3_chap02.html#tag_18_12) ileride ayrıca bahsedeceğimiz; açık dosyalar-dosya tanımlayıcılar, mevcut çalışma dizini, umask, ulimit, trap, kabuk değişkenleri, fonksiyonlar, takma adlar, seçenekler gibi öznitelikleri içerir. Yani örneğin ana kabukta tanımlı olan tüm değişkenler, alt kabuğa da aynen aktarılır. 

Yani başlatılan çocuk işlemde çalışan kabuk, ebeveyn işlemdeki kabuğun birebir kopyası-klonudur.

Her ne kadar ana kabuktaki ortam özellikleri alt kabuğa aktarılsa da, alt kabuktaki ortam özelliği değişimleri ana kabuğu etkilemez. Alt kabuğun ana kabuk üzerinde bir etkisi yoktur. Alt kabuk çocuk işlemde çalışır gerekti çıktıyı üretir ve görevini tamamlayıp sonlanır. 

Netleştirmek adına belirtelim, elbette herhangi bir harici programa mevcut kabuğun ortam özellikleri aktarılmaz. Çünkü temelde harici olarak yalnızca bash programı değil herhangi bir program da çalıştırılabilir. Neticede her çalıştırılan harici programa mevcut kabuğun özelliklerinin aktarılması da mantıklı değildir. Nitekim bizler bash [betik.sh](http://betik.sh) ya da . /betik.sh komutlarını kullandığımızda, betik dosyası çocuk işlem üzerinde harici bir program olarak çalıştırılır dolayısıyla mevcut kabuğun ortam özelliklerinden etkilenmez. 

Bu durumun daha net anlaşılabilmesi alt kabuğa miras olarak aktarılan bilgilerin üzerinde biraz daha duralım istiyorum. 

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

[https://pubs.opengroup.org/onlinepubs/9699919799.2016edition/utilities/V3_chap02.html#tag_18_12](https://pubs.opengroup.org/onlinepubs/9699919799.2016edition/utilities/V3_chap02.html#tag_18_12)

İşte alt kabuk ve alt işlem arasındaki farklılık tam olarak budur. Eğer henüz tam olarak netleşmediyse örnekler üzerinden ele aldığımızda çok daha iyi anlayacaksınız. Şimdi nasıl alt kabuk oluşturabileceğimizi öğrenerek devam edelim.

## Komut İkamesi (Command Substitution)

İkame kelimesi "yerine koyma, yer değiştirme" anlamındadır. Komut ikamesi sayesinde, bir komutun çıktılarını başka bir komut içinde kullanabiliyoruz.

Komut ikamesi, UNIX kabuğunun çok güçlü bir konseptidir. Bir komutun çıktısını ikinci bir komuta eklemek için kullanılır.

```
$ echo "Today is $(date +%A), it's $(date +%H:%M)"
    Today is Monday, it's 13:21
```

Tüm ikamelerde olduğu gibi çift tırnak içinde olmadığı sürece komut ikamesinin sonuçları kabuğun kelime ayrıştırma yani WordSplitting aşamasına tabi tutulur.

Komut ikameleri iç içe olabilir.

```jsx
IPs=($(awk /"$(</etc/myname)"/'{print $1}' /etc/hosts))
```

Özellikle, bir komut ikamesi içindeyken, kabuk tamamen yeni bir alıntı bağlamı başlatır. Yani, ikame içindeki çift tırnaklar, ikame dışındaki çift tırnaklarla eşleşmez. Yani, bunun gibi şeyler yapılabilir:

```jsx
echo "The IPs are $(awk /"$(</etc/myname)"/'{print $1}' /etc/hosts | tr '\n' ' ')"
```

En dıştaki tırnak işaretleri, echo ya iletilecek tek bir argümanı sınırlar. İçteki çift tırnaklar, iç komut ikamesinin sonuçlarında sözcük bölünmesini veya glob genişlemesini önler. İki çift tırnak kümesi birbirinden bağımsızdır.

Komut ikameleri alt kabuklar oluşturur, bu nedenle komut ikamesi içindeki değişkenlerde, geçerli dizinde vb. herhangi bir değişiklik, üst kabuğu değil, yalnızca ikamenin geri kalanını etkiler.

```
    $ var=$(cd ../../usr/bin; pwd)
    $ echo "$var"
    /usr/bin
    $ pwd
    /home/user
```

Alt kabukta yürütülen son komutun çıkış durumu, komut ikamesi için çıkış durumu olarak kullanılır.

```
    $ var=$("non existent command")
    bash: non existent command: command not found
    $ echo $?
    127
```

Komut ikamesi olarak test tırnak da kullanılabilir ancak, iç içe kullanımlarda okuması zorlaşacağı için öncelikli olarak tercih edilmez.

Farklı yazı tiplerinde ters tırnağı tek tırnak ile karıştırılması daha olasıdır. 

$(komut) kullanımı çok daha bariz şekilde komut ikamesine işaret eder. Kolay okunur olduğu için yaygın kullanıma sahiptir. 

## İşlem İkamesi(Process Substitution)

İşlem ikamesi, geçici dosyaları açıkça kullanmaktan kaçınmak için aşağı yukarı sözdizimsel bir kısayoldur.

Bir alt kabukta çalışır

Komutun standart çıktısını önceki komuta aktarmak için `<(komut)` 

Bir önceki komutun standart çıktısını standart girdi olarak kullanmak için `>(komut)` yapısı kullanılır.

```
$ cat <(date)
Thu Jul 21 12:40:53 EEST 2011
```

Aslında bir STDIN akışı verilmek yerine, cat'e açılması ve okunması gereken bir dosyanın adı verildi. Bunu test etmek için cat yerine echo komutunu kullanabiliriz.

```
$ echo <(date)
/proc/self/fd/11
```

cat dosya adını aldığında, dosyanın içeriğini bizim için okudu. Öte yandan, echo bize iletildiği dosyanın adını gösterdi. Daha fazla ikame eklerseniz bu fark daha belirgin hale gelir:

```
$ cat <(date) <(date) <(date)
Thu Jul 21 12:44:45 EEST 2011
Thu Jul 21 12:44:45 EEST 2011
Thu Jul 21 12:44:45 EEST 2011

$ echo <(date) <(date) <(date)
/proc/self/fd/11 /proc/self/fd/12 /proc/self/fd/13
```

İşlem değiştirmeyi (bir dosya oluşturan) ve giriş yeniden yönlendirmesini (bir dosyayı STDIN'e bağlayan) birleştirmek mümkündür:

```
$ cat < <(date)
Thu Jul 21 12:46:22 EEST 2011
```

Hemen hemen aynı görünüyor ama bu sefer kedi bir dosya adı yerine STDIN akışından geçti. Bunu echo ile deneyerek görebilirsiniz:

```
$ echo < <(date)
<blank>
```

echo STDIN'i okumadığından ve hiçbir argüman iletilmediği için hiçbir şey alamıyoruz.

Borular ve giriş yönlendirmeleri, içeriği STDIN akışına iter. İşlem ikamesi komutları çalıştırır, çıktılarını özel bir geçici dosyaya kaydeder ve ardından komut yerine bu dosya adını iletir. Hangi komutu kullanırsanız kullanın, onu bir dosya adı olarak kabul eder. Oluşturulan dosyanın normal bir dosya olmadığını, ancak artık gerekmediğinde otomatik olarak kaldırılan adlandırılmış bir kanal olduğunu unutmayın.

Komut ikamesi `<(komut)` ve `>(komut)` şeklinde kullanılabilir. Her form, işletim sistemine bağlı olarak, /tmp veya /var/tmp altında bir FIFO oluşturulmasına neden olur veya adlandırılmış bir dosya tanımlayıcısı (/dev/fd/*) kullanır. Yerine koyma sözdizimi, FIFO veya FD file descritptor adıyla değiştirilir ve içindeki komut arka planda çalıştırılır.

Değiştirme parametre genişletme ve komut ikamesi ile aynı anda yapılır yani aynı önceliğe sahiptir.

Bu özelliğin en yaygın kullanımlarından biri, geçici dosyaların oluşturulmasını önlemektir.

Örneğin aşağıdaki iki komut aynı görevi yapar

```jsx
diff <(sort list1) <(sort list2)
```

```jsx
mkfifo /var/tmp/fifo1
mkfifo /var/tmp/fifo2
sort list1 >/var/tmp/fifo1 &
sort list2 >/var/tmp/fifo2 &
diff /var/tmp/fifo1 /var/tmp/fifo2
rm /var/tmp/fifo1 /var/tmp/fifo2
```

<(...) ve >(...) arasındaki fark, yalnızca yönlendirmelerin hangi yolla yapıldığıdır. <(...) ile birinin ikameden okuması beklenir ve komut bunu stdout olarak kullanmak üzere ayarlanır. >(...) ile birinin ikameye yazması beklenir ve içindeki komut onu stdin olarak kullanmak üzere ayarlanır.

OLMADIK YERDE OLMADIK BİLGİYİ VERME GEREĞİNDEN FAZLA BİLGİNİN HENÜZ ÖĞRENİLMEYEN KONULAR OLDUĞUNDA BİR ÖNEMİ YOK !!!

Pipe ile işlem ikamesi performans karşılaştırma;[https://unix.stackexchange.com/questions/127645/performance-differences-between-pipelines-and-process-substitution?rq=1](https://unix.stackexchange.com/questions/127645/performance-differences-between-pipelines-and-process-substitution?rq=1)

# Bash Kabuğunda Nasıl Alt Kabuk Oluşturulur ?

Alt kabuk oluşturmak için birden fazla yöntem bulunuyor. Bu yöntemler bash kabuğunun kuralları dahilinde tanımlanmış olan yöntemlerdir.

### Parantez ile Alt Kabuk Oluşturmak

Parantez içerisinde yazılmış olan komutlar alt kabuk oluşturulup bu alt kabuk üzerinde çalıştırılır. Tüm komutlar işlendikten sonra alt kabuk kapatılarak ana kabuğa dönülür.

### Pipe ile Alt Kabuk Oluşturmak

[P](https://www.gnu.org/software/bash/manual/html_node/Pipelines.html#Pipelines)ipe Kullanımı : Pipe işareti kullanıldığında soldaki ve sağdaki komutlar için iki alt kabuk oluşturulur ve her iki alt kabuğunda sona ermesi beklenir. Soldaki komutun çıktıları sağdaki komuta girdi olarak aktarılır. (Eğer lastpipe seçeneği aktifse pipe işaretinin sonundaki komut mevcut kabuk üzerinde çalıştırılırken öncesindeki komutlar altkabukta çalıştırılır.) 

![https://www.it.uu.se/education/course/homepage/dsp/vt19/images/module-2/parent-children-pipe.png](https://www.it.uu.se/education/course/homepage/dsp/vt19/images/module-2/parent-children-pipe.png)

`$(komutlar..)` yapısının kullanımı, tanımı gereği bir alt kabuk oluşturur. Alt kabuk mevcut bash kabuğunun çatallanıp yeni kabuğu(alt kabuk) alt işlemde çalıştırması ile oluşturulur. Bu kullanım yönteminde parantez içerisinde yazılan komutlar alt kabukta çalıştırılır. Elbette alt kabuktaki değişiklikler işlemlerin yapısı gereği üst işlemi yani üst kabuğu etkilemez. Çünkü alt kabuğun tek yaptığı işlem çıktılarını mevcut tty konsoluna iletmektir. Örneğin alt kabukta dizin değiştirmek üzere `cd` komutunu kullanırsanız üst kabukta hiç bir değişiklik olmayacaktır. 

```jsx
pwd ; $(cd /etc ; pwd)
```

Elbette üst kabuk yani üst işlem kendini çatallayarak alt kabuğu oluşturduğu için bünyesinde bulunan değişken gibi yapılar da alt kabuğa aynen iletilir. 

Genelde karıştırılan bir durum gruplama yapmamızı sağlayan süslü parantez kullanımıdır. Süslü parantez tek başına alt kabuk oluşturmak için kullanılmaz. Süslü parantezin kullanım amacı tıpkı fonksiyonları tanımlarken kullandığımız gibi birden fazla komutun sınırını belirtebilmemizi sağlamaktır.

```bash
#!/bin/bash

echo sh1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
( echo ss1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL \
  | { read LINE
      echo $LINE
      echo ss2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
    }
)
bash -c 'echo sh2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL'
Running the above code on my machine, yielded:

sh1 $$=797 BASHPID=797 PPID=756 SHLVL=2
ss1 $$=797 BASHPID=799 PPID=756 SHLVL=2
ss2 $$=797 BASHPID=800 PPID=756 SHLVL=2
sh2 $$=801 BASHPID=801 PPID=797 SHLVL=3
```

## Alt Kabuk(Subshell) Kullanma Maaliyeti

Tek sefer için alt kabuk kullanmak çok maliyetli olmasa da tekrar eden işlemler için her defasında alt kabuğun kullanılması hissedilir derecede yavaşlığa sebebiyet verecektir. Bu durumu aşağıdaki örnek komutları çalıştırarak gözlemleyebilirsiniz.

Comparing

```
time for((i=0;i<10000;i++)); do echo "$(echo hello)"; done >/dev/null 

```

with

```
time for((i=0;i<10000;i++)); do echo hello; done >/dev/null 
```

Bu sebeple alt kabukları kullanacağımız durumları iyi belirlemeliyiz. Ayrıca alt kabuklar mevcut kabuk ortamı dışına hiç bir veri aktaramadığı için ana kabuk ya da diğer kabuklar ile haberleşemez. Bu da çoğu durumda bir dezavantajdır. 

Alt işlem ile pipe ı karşılaştırdığımızda pipe daha verimsiz çalışır çünkü pipe ın oluşturduğu çocuk işlemlerin bitmesi ebeveyn tarafından beklenir. Aşağıdaki çıktılara bakarak bu durumu teyit edebilirsiniz.

Scripts:

`pipeline.bash`:

```
for i in {1..10000}; do
    echo foo bar |
    while read; do
        echo $REPLY >/dev/null
    done
done

```

`proc-sub.bash`

```
for i in {1..10000}; do
    while read; do
        echo $REPLY >/dev/null
    done < <(echo foo bar)
done

```

Results:

```
~$ time ./pipeline.bash

real    0m17.678s
user    0m14.666s
sys     0m14.807s

~$ time ./proc-sub.bash

real    0m8.479s
user    0m4.649s
sys     0m6.358s
```

With `pipe`:

```
$ strace -fqc ./pipe.sh
% time     seconds  usecs/call     calls    errors syscall
------ ----------- ----------- --------- --------- ----------------
 70.76    0.215739           7     30000     10000 wait4
 28.04    0.085490           4     20000           clone
  0.78    0.002374           0    220008           rt_sigprocmask
  0.17    0.000516           0    110009     20000 close
  0.15    0.000456           0     10000           pipe

```

With `proc-sub`:

```
$ strace -fqc ./procsub.sh
% time     seconds  usecs/call     calls    errors syscall
------ ----------- ----------- --------- --------- ----------------
 52.38    0.033977           3     10000           clone
 32.24    0.020913           0     96070      6063 read
  5.24    0.003398           0     20009           open
  2.34    0.001521           0    110003     10001 fcntl
  1.87    0.001210           0    100009           close
```

$(..) ile (..) farkı; dolar işareti tüm komutları genişletip çalıştırır. Ters tırnak ile benzer görevdedir. Örneğin $(echo ls) komutunu girersek, ls komutunun çıktıları echo komutu yardımıyla bastırılır. [Mutlaka bak !!](https://stackoverflow.com/a/27472808/7481877) [Mutlaka bak 2](https://superuser.com/a/935427)

Bash kabuğunda alt kabuk oluşturabilecek diğer yöntemler;

- Arkaplan: Arkaplanda çalıştırmamızı sağlayan ve & işareti aslında ilgili komutu alt kabuk oluşturup burada çalıştırır. Yani arkaplandaki süreçler de aslında alt kabuk üzerinde çalıştırılır.
- [P](https://www.gnu.org/software/bash/manual/html_node/Pipelines.html#Pipelines)ipe Kullanımı : Pipe işareti kullanıldığında soldaki ve sağdaki komutlar için iki alt kabuk oluşturulur ve her iki alt kabuğunda sona ermesi beklenir. Soldaki komutun çıktıları sağdaki komuta girdi olarak aktarılır. (Eğer lastpipe seçeneği aktifse pipe işaretinin sağındaki komut mevcut kabuk üzerinde çalıştırılırken soldaki komut altkabukta çalıştırılır.)
- Komut İkamesi: `$(…)` (ters tırnak ile aynı ``…``) standart çıktısı bir boruya ayarlanmış bir alt kabuk oluşturur, üstteki çıktıyı toplar ve bu çıktıya, sondaki satırsonlarını çıkararak genişler.
- İşlem İkamesi: `<(…)` Standart çıkışı bir boruya ayarlanmış bir alt kabuk oluşturur ve borunun adına genişler. Üst öğe (veya başka bir işlem) alt kabuk ile iletişim kurmak için boruyu açabilir.
- `>(…)` Aynı şeyi yapar, ancak standart girişteki boru ile.
- Yardımcı İşlem: `coproc …` bir alt kabuk oluşturur ve sona ermesini beklemez. Alt kabuğun standart giriş ve çıkışının her biri, ana boru her bir borunun diğer ucuna bağlanan bir boruya ayarlanır.

Alt kabuk, mevcut kabuğun kopyasını oluşturur. Aynı değişkenlere¹, aynı işlevlere, aynı seçeneklere, vs. sahiptir. Kaputun altında, call² çatal sistemi ile bir alt kabuk oluşturulur; ebeveyn beklerken (ör. $ (…)) veya yaşamına devam ederken (ör.,… &) veya başka bir şekilde ondan bekleneni yaparken (ör.,… |…) çocuk süreç kendisinden bekleneni yapmaya devam eder. ).

$$ ile BASHPID farklı olmasının sebebi $$işaretinin çalıtşırımış olan ana script dosyasının süreç numarasını vermesidir. Alt kabuk oluşturunca alt kabuk elbette farklı süreç numarasına sahip olur fakat ana kabuğun yani ana scripting altında çalıştığı için $$ değeri ana kabuk ile aynı olur. Yine de kendinize özgür süreç numarsını almak için BASHPID komutunu kullanabiliriz.

PİPE;[http://www.rozmichelle.com/pipes-forks-dups/](http://www.rozmichelle.com/pipes-forks-dups/)

# Bash Üzerinde Paralellik

[https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/](https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/)

[http://coldattic.info/post/7/](http://coldattic.info/post/7/)

[https://gioyik.com/p/paralelism-concurrency-logging-bash](https://gioyik.com/p/paralelism-concurrency-logging-bash)

[https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/](https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/)

[http://prll.sourceforge.net/shell_parallel.html](http://prll.sourceforge.net/shell_parallel.html)

[Bash Üzerinde Paralellik](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Bash%20U%CC%88zerinde%20Paralellik%2040b9989da6f04c689557dd29a73862ab.md)

## Job Control | İş Kontrolü

İş kontrolü, işlemlerin yürütülmesini seçici olarak durdurma (askıya alma) ve daha sonraki bir noktada yürütmeye devam etme (devam ettirme) yeteneğini ifade eder. Bir kullanıcı genellikle bu olanağı, işletim sistemi çekirdeğinin terminal sürücüsü ve Bash tarafından ortaklaşa sağlanan etkileşimli bir arabirim aracılığıyla kullanır.

[https://www.gnu.org/software/bash/manual/html_node/Job-Control.html#Job-Control](https://www.gnu.org/software/bash/manual/html_node/Job-Control.html#Job-Control)

Kısa özet: [https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7](https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7)

İşlem ile ilgili tüm temel kavramlardan bahsettiğimize göre artık bash kabuğunun sunduğu "iş kontrolü/job control" mekanizmasından da söz edelim. Bu özellik etkileşimli kabuk kullanımında mevcut kabuk üzerinden işlemlerin kolay yürütülebilmesini sağlar. 

Tek bir işlem birden fazla alt işlem oluşturabileceği için işlemlerin kolay yönetilebilmesi için iş kontrolüne ihtiyaç vardır. Tek bir ana işlem altında oluşturulan tüm alt işlemler bir bütün halinde ele alındığında "job" olarak geçen "iş" kavramına karşılık geliyor. 

Farklı kabuklar alt kabuklardaki veya alt süreçlerdeki süreç numarası bilinen işlemlere müdahale edebilir mi ?

Ebeveyn altında oluşturulan tüm süreçler aynı grupta kabul edilir. Bu grubun kimlikiği de ppid olarak geçen parrent işlem numarasıdır. Burada bahsi geçen gruplar ancak önplandaki işlemler için geçerli olabilir. Arkaplandaki işlemlerin zaten alt kabuk oluşturulup çalıştığını biliyoruz. Bu sebeple alt kabuklarda ya da arkaplanda çalıştırılan süreçler kendi gruplarına sahiptir. Yani kesme sinyali INT gönderdiğimizde arkaplandaki veya alt kabuktaki süreçler kapsam dışında kalarak kapanmaz. İş kontrolü zaten bu tüm bu süreçlerin kontrolü kolaylaştırmak için vardır. Arkaplandaki süreçleri takip etmek ve gerektiğinde öne almak veya sonlandırmak için bize kolaylık sağlar.

[https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html](https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html)

[https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If the script or program,the foreground to the background](https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If%20the%20script%20or%20program,the%20foreground%20to%20the%20background).

[https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html](https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html)

[https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script](https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script)

PROCCESS GROUP KAVARIMINI ELE AL SİGNAL İLE İLİŞKİLİ

## Servis

Servisler tam olarak nedir ve nasıl tanımlanır örneğin bash scriptimiz servis olarak tanımlanabilir mi ?

Servis tanımlamak;[https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6](https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6)

[https://web.stanford.edu/class/cs101/software-cpu.png](https://web.stanford.edu/class/cs101/software-cpu.png)

Bu anlatımdan çıkaracağımız en önemli ek ders; aslında bash kabuğunun da yalnızca kullanıcı ile çekirdek arasında iletişimi sağlayan aracı katman olduğudur. Benzer şekilde bizler sistem yönetiminde kabuk yerine grafiksel arayüzü kullandığımızda, aslında grafiksel arayüzü sağlayan programı kullanmış oluyoruz. Bu program da tıpkı bash kabuğunda olduğu gibi bizim isteklerimizi çekirdeğe iletiyor. Yani özetle; grafiksel ya da bash kabuğu gibi bir komut satırı arayüzü kullanarak amaçladığımız tek şey, bir insan olarak sistem çekirdeğine derdimizi rahatça anlatabilmek. 

[Ekstra notlar](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Ekstra%20notlar%201d48e26bc45d448e9a49d55630297752.md)

[İş Kontrolü | Job Control](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/I%CC%87s%CC%A7%20Kontrolu%CC%88%20Job%20Control%20fe0dd4d5fa314a5682ff525620031e79.md)

[İş Kontrolü | Job Control TOPLAM](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/I%CC%87s%CC%A7%20Kontrolu%CC%88%20Job%20Control%20TOPLAM%2039ae89e7f6344ca3984b0a04d2355232.md)