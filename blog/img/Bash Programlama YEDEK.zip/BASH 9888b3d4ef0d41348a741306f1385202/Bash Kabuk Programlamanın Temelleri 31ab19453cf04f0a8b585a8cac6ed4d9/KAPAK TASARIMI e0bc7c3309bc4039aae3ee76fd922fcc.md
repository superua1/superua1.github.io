# KAPAK TASARIMI

Buradaki görseller gayet güzel. Benzeri bir grafik tasarım yapabilirsin.

[https://darknetdiaries.com/episode/](https://darknetdiaries.com/episode/)