# Bash Yerleşik Komutlarının Açıklaması

YÜKLENEBİLİR YERLEŞİKLER DİYE BİR KAVRAM VAR

Kendi ihtiyaçların doğrultusunda derlemiş olduğun araçları, kabuğun yerleşikleri içerisine dahil ederek verimli şekilde çalışmasını sağlayabilirsin. Bash kaynak kodunda /examples/loadable/ klasörü altında yüklenebilir yerleşik komut örnekleri vardır. Yeni sürümlerde bu örnekler değişebilir. Bash v2.0 dan beri bu özellik destekleniyor.

```bash
.../bash-4.0$ CC=whatever ./configure
.../bash-4.0$ make
.../bash-4.0$ exec ./bash
.../bash-4.0$ cd examples/loadables/
.../loadables$ make
.../loadables$ enable -f finfo finfo
.../loadables$ help finfo
```

Bu bölüm altında sıralı şekilde bash kabuğuyla birlikte gelen yerleşik araçların kullanımlarını açıklayalım.

Yerleşik olarak geçen komut setleri; yalnızca kabuğa dahil olarak verimli ve doğru şekilde çalışabilecek olan araçları tanımlar. Kabuk ile gelen standart yerleşik araçlar vardır. 

Yerleşik, Bash araç setinde yer alan ve kelimenin tam anlamıyla yerleşik bir komuttur. Bu, ya performans nedenlerinden ötürüdür - yerleşikler, genellikle ayrı bir işlemin çatallanmasını [1] gerektiren harici komutlardan daha hızlı çalışır - veya belirli bir yerleşik kabuk iç bileşenlerine doğrudan erişim.

[https://tldp.org/LDP/abs/html/internal.html](https://tldp.org/LDP/abs/html/internal.html)

Bash yerleşik komutlarının neler olduğunu öğrenmek için konsola `compgen -b` komutunu girmemiz yeterlidir. Burada kullanmış olduğumuz `compgen` komutu yani `compgen` aracı da aslında bash yerleşik araçlarından biridir. Görevi ise tab tuşuna basıldığında mevcut komutlara yönelik kısmi parametrelerin ve seçeneklerin tamamlanması için sistem üzerindeki araçlara ait bilgi sunmaktır. Yani daha sonra ayrıca ele alacağımız  `complete` aracıyla birlikte bash kabuğunun sahip olduğu tab tuşu ile otomatik tamamlama özelliğini mümkün kılar. Sırası geldiğinde tüm yerleşik komutları(araçları) açıklamış olacağız. O zaman bu aracın işlevini çok daha net anlayacaksınız.

Yerleşik yardımcı programlar, -n seçeneğiyle birlikte enable komutu kullanılarak devre dışı bırakılabilir.

enable -n kill komutu kill yerleşik komutunun mevcut kabuk üzerinde devredışı bırkılmasını sağlar.

[`.` (nokta) & `source` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/(nokta)%20&%20source%20Komutu%20e3e489f49fb84c9db16579d21ba30c04.md)

[`:` (iki nokta üst üste) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/(iki%20nokta%20u%CC%88st%20u%CC%88ste)%20Komutu%208c671304c19c4a8aa747f2e36e716ea7.md)

[[ ] (Köşeli Parantez) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/%5B%20%5D%20(Ko%CC%88s%CC%A7eli%20Parantez)%20Komutu%20573f69fbacb348b0af5d7d3ada48d40a.md)

[`alias` ve `unalias` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/alias%20ve%20unalias%20Komutu%206cedd22abe114babab0816fae9ee407d.md)

[bg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/bg%20Komutu%20856b3c55ce0f4c62a7cc37175c06378b.md)

[bind Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/bind%20Komutu%2064522752df8d4c3e80eb7f524ff75570.md)

[break Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/break%20Komutu%20faf9e4f4eaf74ffd8c7a741d82554ced.md)

[builtin Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/builtin%20Komutu%20c8307cc43150499e9bb6633ac6a16f4a.md)

[caller Komutu ! EKSİK !](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/caller%20Komutu%20!%20EKSI%CC%87K%20!%204e31f6d84fda453ebd0a23f9cda47060.md)

[cd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/cd%20Komutu%200bd4a8b2b6bd4a428d49c34d2fd28057.md)

[command Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/command%20Komutu%20a48d8704c1cb421f89427d9d067aaa3b.md)

[compgen Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/compgen%20Komutu%202f321ded0da34ddfaa555e0a6c796a47.md)

[complete Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/complete%20Komutu%203fc8eb0469d64e29b5d26cbdba9c9f2f.md)

[compopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/compopt%20Komutu%20a0f4b5356c404da4a7b06b55719a135f.md)

[continue Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/continue%20Komutu%203e5900d30b5748b793821f5efb787e45.md)

[declare ve typeset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/declare%20ve%20typeset%20Komutu%201adbba434e144399bfd6451a0178f382.md)

[`pushd` `dirs` `popd` Komutları](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/pushd%20dirs%20popd%20Komutlar%C4%B1%20219332745a2d48e68945901e008ded7c.md)

[disown Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/disown%20Komutu%20221d0dc6a3834731bc63cadb7d4e23f0.md)

[nohup Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/nohup%20Komutu%20d6695d97dba147699ce296b5ffd82131.md)

[echo Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/echo%20Komutu%2063127c7cc98b4398a69a6016a6a26d3c.md)

[enable Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/enable%20Komutu%209262cd8fd5644cc89bdc9c6e67ede412.md)

[eval Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/eval%20Komutu%2005adf45b07564e178603234d43cb9bd4.md)

[exec Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/exec%20Komutu%20adb1a8379a334f2ebc31aa5b1ab5b95c.md)

[exit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/exit%20Komutu%2079e2d3ac15da42c8988feb05f99d18de.md)

[export Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/export%20Komutu%20e1f874d497c24ec6956723ae51d6ed32.md)

[false & true Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/false%20&%20true%20Komutu%20e889a526a62f4eecb0e0649a71115562.md)

[fc Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/fc%20Komutu%2009fc1d235ef849bc89c27ca502fc76c0.md)

[fg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/fg%20Komutu%203ec8e8485c9b45fcbc1ee985031d4187.md)

[getopts Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/getopts%20Komutu%209e0bf629450647ca8dbafcb4912c3ead.md)

[hash Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/hash%20Komutu%206f7748189d99458b97f36b41e55c13da.md)

[help Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/help%20Komutu%201bd0fba82ae44da2afa273722108d64b.md)

[history Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/history%20Komutu%204cc7b9ec1eb842c7887f10ffb68e93dc.md)

[jobs Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/jobs%20Komutu%20ac89ca11ecbd46fca44b5ba3178a5fd0.md)

[kill Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/kill%20Komutu%2027b21f410df441ad94999c9680023be6.md)

[let Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/let%20Komutu%202ebf2109f81843c1a6060de9cdc78350.md)

[local Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/local%20Komutu%2089f19e76936243c09c398f5a9040bfbb.md)

[logout Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/logout%20Komutu%20daf848dbd2904ef1817b37564314fb86.md)

[mapfile ve readarray Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/mapfile%20ve%20readarray%20Komutu%20e6c6259d4f9f49a29c60f814f7ef39bf.md)

[suspend Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/suspend%20Komutu%200f017c165a624412a56266c95ceccf57.md)

[pwd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/pwd%20Komutu%2053c17e8bd2a34302a88dc2260411bd7a.md)

[return Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/return%20Komutu%20eebbe16a810847b3b271aad9ed495aed.md)

[type Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/type%20Komutu%20d81f0f48323348c8bef0d1fa0b122c80.md)

[readonly Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/readonly%20Komutu%208b5bea34ecff4c51a5151be0d0327966.md)

[unset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/unset%20Komutu%208007f76e262843049c049b189c774e3a.md)

[shopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/shopt%20Komutu%201c082b48855a4b39bf62133edb397561.md)

[times Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/times%20Komutu%204845fa5e717b47de8ac5c2a1c19f293d.md)

[trap Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/trap%20Komutu%20bec688ae0b634251aec2c20b2399f35b.md)

[ulimit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/ulimit%20Komutu%2016c6fd48f8e9475f8e336b9487909d2c.md)

[umask Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/umask%20Komutu%2063c5c0cbfbdc4427bdcaf779472517f8.md)

[wait Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f/wait%20Komutu%207d4de8426a5d42d89cfc03047082364c.md)