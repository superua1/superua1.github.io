# Bash Üzerinde Paralellik

BU BOLÜMDEKİ ZAMAN ÇIKTILARINI İYİ ANALİZ ETMEK İÇİN TİME KONUSUNDAKİ REAL USER SYSTEM TİME KAVRAMLARI NET BİÇİMDE ANLAŞILMIŞ OLMALI. BUNU ÖĞRENİP TEKRAR DÜZENLE

Eğer uygun şekilde programlayabilirsek, normal şartlarda uzun sürebilecek işlerimizi paralellik kullanarak çok daha kısa sürede sonuçlandırabiliriz. Buradaki paralellikten kastımız gerçekleştirmek istediğimiz "işin" yani "ana problemin" uygun alt parçalara bölünüp aynı anda çoklu işlem birimlerinde yürütülmesidir. Bu sayede zamandan tasarruf sağlanır. Özellikle günümüzde çoklu işlem birimlerine(çekirdek) sahip işlemcilerin yaygınlaşması ile paralellik herkes için çok daha ulaşabilir bir yöntem olmuştur. 

Bash üzerinde paralellik sağlamak için daha önce bahsetmiş olduğumuz alt kabuktan yararlanabiliyoruz. Normal şartlarda kabuk bizim girmiş olduğumuz komutları sırasına uygun şekilde çalıştıracak ve önceki çalıştırılan komutlar görevlerini bitirmeden bir sonraki komut işleme alınmayacaktır. Eğer biz bir işi uygun parçalara bölüp bu işleri alt kabuklarda çalıştırırsak, işlerin birbirini bekleyip zaman kaybetmesi gerekmez çünkü hepsi aynı anda yürütülebilir. Bu durum birim zamanda sistem kaynaklarının fazla kullanılmasına neden olsa da doğru şekilde kullanıldığında görev bütününün çok daha kısa sürede tamamlanmasını sağlar.

Ancak çoğu durumda herhangi bir "ana problemi" alt parçalara doğru şekilde bölmesi zor olduğundan tam tersi şekilde performans sorunlarına neden olabilirsiniz. Zaten bu sebeple paralel olarak çalışan çok fazla betik programına da rastlamayız. 

Bu girizgahtan sonra artık bizler de bizzat uygulama üzerinden paralellik özelliğinin avantaj ve dezavantajlarını gözlemleye başlayabiliriz. 

Aynı anda yürütülmesini isteyeceğimiz nasıl bir işimiz olabilir ? Somut ve kolay kurgulanabilir bir örnek olarak log dosyalarının sıkıştırılmasını ele alabiliriz. Örneğin ben alandan tasarruf etmek için /log klasörü altında yer alan tüm log kayıtlarını sıkıştırmak üzere aşağıdaki basit betiği kullanabilirim. 

```bash
for kayit in log*
do
	gzip $kayit
done
```

Bu betiği çalıştırdığımda mevcut klasörde bulunan ***log*** ismi ile başlayan her bir dosya tek tek `gzip` aracı ile sıkıştırılacaktır. Elbette sıkıştırma işlemi sırasında her bir sıkıştırma işlemi bir sonrakini bekleyeceğinden bu işlem biraz uzun sürebilir. Bu durumu gözlemlemek adına betik dosyamızı `time` komutu başta olacak şekilde çalıştıralım ve işlemin ne kadar zaman alacağına bakalım. Ben test etmek için öncelikle 2 çekirdekli sanal sistem üzerinde 1000 log dosyasını sıkıştırmayı deniyorum.

```bash
taylan@taylan:~/logs$ time ./test 

real    0m40,735s
user    0m36,188s
sys     0m4,446s
taylan@taylan:~/logs$
```

Çıktıdan da görülebileceği gibi işlem yaklaşık 40 saniye sürmüş. Bu metot yerine eğer bilgisayarımızda birden fazla işlem birimi(çekirdek) varsa, her işlem birimi için bir log dosyası olacak şekilde logları paralel olarak sıkıştırmayı da tercih edebiliriz. Bu yöntem gözle görülür şekilde hız artışı sağlayacaktır. Sıkıştırma işlemini arkaplanda yani alt kabukta başlatmak için `&` işaretini ekleyelim ve betik dosyamızı tekrar `time` komutuyla birlikte çalıştıralım.

```bash
for kayit in log*
do
	gzip $kayit &
done
```

```bash
taylan@taylan:~/logs$ time ./test 

real    0m22,259s
user    0m31,786s
sys     0m11,385s
taylan@taylan:~/logs$
```

Aldığımız çıktıda tüm işlemin yaklaşık 22 saniyede tamamlandığını belirtiliyor. 40 saniyeye oranla aynı iş için bu hatırı sayılır bir zaman tasarrufu demek. Eğer `htop` yazılımı gibi bir araç ile betik dosyası çalışırken işlemci tüketimini gözlemlerseniz, paralel olarak çalışan betiğin tüm çekirdekleri kullandığını görebilirsiniz.(Alternatiflerine oranla `htop` aracı çok daha kolay takip edilebilir arayüz sunar. Eğer sisteminizde yüklü değilse en azından test aşaması için kurmanızı öneririm.) Yani paralellikte bize zamandan tasarruf sağlayan şey aslında çekirdek sayısı ile de doğru orantılı. Bu bağlamda tek çekirdekli sistemlerde paralellik özelliğinin kullanılması normalin aksine performans kaybına neden olacaktır. Bu durumu deneyimlemek üzere tek çekirdekli sanal bir sistem üzerinden aynı arşivleme işlemini paralellik olmadan ve paralellik varken test edelim.

Tek çekirdekli sistemde paralel olmayan arşivleme işlemi;

```bash
taylan@taylan:~/logs$ time ./test 

real    0m40,368s
user    0m33,786s
sys     0m4,667s
```

Tek çekirdekli sistemde paralel arşivleme işlemi;

```bash
taylan@taylan:~/logs$ time ./test 

real    0m42,769s
user    0m32,601s
sys     0m8,185s
```

Çıktıları kıyasladığınızda aynı iş için tek çekirdekli bir sistemde paralelliğin ekstra 2 saniye kaybettirdiğini yani ekstra yük oluşturduğunu teyit edebilirsiniz. Bu durumun nedeni, tek çekirdekli sistemde her bir iş için altkabuk oluşturmanın gereksiz bir maliyet olmasıdır. Normalde çok çekirdekli sistemlerde yeni oluşturulan alt kabuk boşta olan çekirdek üzerinde çalışacağı için paralellik kullanımı mantıklıdır. Ancak tek çekirdekli sistemde boşta hiç çekirdek olmayacağından alt kabuklar oluşturmak yalnızca mevcut kaynağın israfı ile sonuçlanıyor. 

Yine de artık çok çekirdekli işlemcilerin neredeyse standart haline geldiği günümüz dünyasında paralellik gayet kullanışlı olabilir. Çok çekirdekli yapıya sahip olduğumuzda paralellik heyecan verici olsa da aslında doğru şekilde kullanılmadığında sistem kaynaklarının yönetimi konusunda büyük problemler oluşturabilir.

Bizim örneğimizden yola çıkacak olursak; basit betiğimiz aynı anda tüm dosyaları sıkıştırmak üzere kontrolsüzce çekirdek sayısından daha fazla alt kabuk başlatarak tüm sistem kaynağını sömürüyor. Yani çekirdeklerin hepsi kullanımda olsa dahi alt kabuk oluşturmak üzere sistem kaynağı tüketiliyor. Bu örneğimizde işlediğimiz veriler çok daha büyük olsaydı tüm sistemin çökmesine neden olabilecek kritik bir hata yapmış olurduk. Elbette bu gibi bir hata özellikle işletmelere ait servislerin çalıştığı bir sunucuda yapılması kabul edilebilir bir yanlış değildir. Biz buradaki işlemle durmaksızın arkaplanda alt kabuk başlattığımız için ilgili işlemler bitmeden bu süreçlerin sonlandırılması, halihazırda tüm sistem kaynağı tükeniyorken çok zor olacaktır. Hatta sırf bu işi yapan ve yaygın olarak karşılaşabileceğiniz "fork bomb" olarak geçen aşağıdaki kod parçası da kullanılır.

```bash
:(){ :|:& };:
```

Basitçe yukarıdaki kodu açıklamak gerekirse :() ile bir fonksiyon tanımlanır, :|: ile fonksiyon kendi içinden çağırılır, ek olarak burada fonksyion 2 defa çağırılıyor ve & ile arkaplanda çalışması sağlanır, ; fonksiyonunu sonlandırır ve : ile fonksyion çağırılır.

Engellemek için kabaca kullanıcının yada bir gurubun çalıştıracağı maksimum işlem adedi sınırlanmalıdır, /etc/security/limits.conf altından yapılabilir, örnek olarak :

```bash
# cat /etc/security/limits.conf

kullanici hard nproc 100
@grup hard nproc 10
```

Özetle bilinçsiz kullanımda sistemin kaynaklarını tüketerek çökmesine neden olacağı için, yalnızca sınırlı sayıda eşzamanlı işi başlatmak üzere bir yola ihtiyacımız var. Bu sınırı da biraz önce bahsettiğimiz konfigürasyon dosyası haricinde, mevcut sistemimizdeki işlemci çekirdeği sayısı üzerinden betik dosyamız içinde belirleyebiliriz. 

## Paralelliği Sınırlamak

Önceki basit örneğimizde çekirdek sayısından bağımsız şekilde tüm dosyalar sıkıştırılana kadar her bir sıkıştırma işlemi için alt kabuk oluşturarak tüm çekirdekleri tam kapasite meşgul ediyorduk. Bu durum, işlenmesi uzun sürebilecek olan problemlerde sistemin çalışmasına engel oluşturabilir. Bu sorunun en basit çözümü; her adımda yalnızca çekirdek sayısı kadar alt kabuğun oluşturulmasına olanak tanımaktır. Bu sayede çekirdekler üzerinde tam zamanlı aşırı yükleme olmadan sistemin geri kalanındaki işlemler için de işlemci kaynağı bırakılabilir. Bu işlemi gerçekleştirmek için aşağıdaki basit yapı işimizi görecektir. Bu yapı içerisinde kullanmış olduğumuz `wait` komutu arkaplandaki işlerin tıpkı önplandaki işler gibi sırası ile yapılmasını sağlıyor. Arkaplandaki işlem bitmeden bir sonraki işleme geçilmiyor. 

```bash
say=0
CPU_S=2
for kayit in log*
do
        gzip $kayit &
        let say++
        [[ $((say%CPU_S)) -eq 0 ]] && wait
done
```

Yapıdaki komutları tek tek açıklayacak olursak;

- `say` değişkeni, kurmuş olduğumuz `for` döngüsünün kaç kez tekrar ettiğinin bilgisini tutmak için tanımlandı.
- `CPU_S` değişkeni, mevcut betik dosyasının kullanabileceği maksimum çekirdek sayısını belirtmek için tanımlandı.
- `for` döngüsü, mevcut klasör konumunda yer alan tüm **log** ifadesi ile başlayan dosyaların bilgisini `kayit` isimli değişkene aktarıyor.
- `gzip` komutu `kayit` değişkeninden aldığı hedef dosyaları sıkıştırıyor. Bu satırın sonundaki `&` işareti, sıkıştırma işleminin alt kabuk oluşturulup arkaplanda başlatılmasını sağlıyor. Bu sayede bir sonraki sıkıştırma işlemine geçildiğinde öncekinin bitmiş olması beklenmiyor.
- `let` komutu, her döngü tekrarında `say` isimli değişkenin değerini 1 arttırıyor.
- `say` değişkenindeki değerin `CPU_S` değişkenindeki çekirdek sayısına göre modu alınıp, bu mod 0 değerine eşitse `wait` komutu çalıştırılıyor. Buradaki `&&` işaretinin yalnızca ilk komut doğruysa ikincisini çalıştırdığını biliyorsunuz. İşte eğer döngü tekrarı yani oluşturulmuş olan alt kabuk sayısı çekirdek sayısının katlı oranına eşitse `wait` komutu çalıştırılıp arkaplandaki mevcut işlerin bitmesi bekleniyor. Bu sayede 2. 4. 6. 8. 10. .. döngülerde arkaplandaki işler beklendiği için tüm sıkıştırma işlemleri çekirdek sayısı oranınca yani bizim örneğimizde 2 şer 2 şer ilerlemiş oluyor.

Elbette bu işlem çekirdeklerin maksimum kapasitede aralıksız çalışmasını sağlamadığı için bir önceki yönteme oranla küçük miktarda zamandan kayıplar oluştursa da sistemin genel sağlığı için çok daha doğru bir yaklaşımdır. Ben aynı iş için yani 1000 log dosyasının 2 çekirdek ile paralel olarak sıkıştırılması için bu metodu kullandığımda aşağıdaki zamanlama sonucunu aldım.

```bash
taylan@taylan:~/logs$ time ./test 

real    0m23,654s
user    0m36,199s
sys     0m7,474s
```

Yaklaşık bir saniyelik kayıp olsa da halihazırda üzerinde çalışmakta olduğumuz sistemin de nefes alabilmesi için bu metodun kullanımı daha sağlıklıdır. Zaten betik dosyasını çalıştırdığınız sırada çekirdek kullanım oranlarına ve aynı anda oluşturulan alt işlem sayısına bakarak da bu durumu teyit edebilirsiniz. Somut şekilde karşılaştırma yapabilmek adına bir önceki ve burada bahsi geçen yöntemi `htop` aracı ile çalışma esnasında gözlemlemenizi öneririm. 

---

Bu Sorunu Çözersen Ekle Yoksa Alta Çünkü Daha Fazla Performans Sorununa Neden Olabilir.

Ele aldığımız çekirdek sayısı ile sınırlama yaklaşımı her ne kadar makul bir yöntem olsa da aslında daha da verimli hale getirilebilir. Zira biz tüm işleri mevcut çekirdek sayımızın katlı oranlarınca paralelleştirdiğimiz için aslında çeşitli durumlarda boşta kalan çekirdekleri kullanmıyor olma ihtimalimiz de var. Örneğin 8 çekirdekli bir sistemde 7 işlem yapılıp 8. işlemin uzun sürmesi halinde döngü tamamlanmayacağı için 8. işlem bitene kadar boşta kalan 7 çekirdek de bekletilir. Bu durum özellikle birbirinden farklı zorlukta işlerin gerçekleştirildiği durumlarda verimliliği düşürebilecek bir kusurdur. 

---

## Sonuç

Paralellik özelliğinin doğru şekilde kullanıldığında zamandan tasarruf sağlayabildiğini deneyimlemiş olduk. Elbette bu özelliği kullanırken dikkat etmemiz gereken en önemli nokta, ana problemi doğru alt parçalara bölerek çalıştırmaktır. Özellikle birbirinden bağımsız birkaç alt süreci işletmek istediğimizde paralellik bize zaman kazandırabilir. Ancak yine de sıraya uygun ve birbiri ile yakından ilişkili araçlar geliştirmek istediğimizde, paralel işleme her sistem üzerinde stabil şekilde çalışmayabilir. Gerçekten gerekmedikçe, herkesin kullanımına açık olacak(farklı işlemci türlerinde çalışması muhtemel) betiklerde paralelleştirme özelliğini kullanmanızı önermem. Çünkü her sistemde aynı şekilde çalışacağını garanti edemeyebilirsiniz. 

Ayrıca bizim programlamamız dışında, paralellik için halihazırda birden fazla alternatif araç da bulunuyor. Bunlardan en yaygın kullanımda olanı "GNU Parallel" isimli araçtır. Eğer bu paketi edinip yüklerseniz işlemlerin paralel olarak yürütülmesini sağlayabilirsiniz. Elbette harici paket yükleme imkanı herkes için her zaman mümkün olmayacağından; anlatım boyunca ele aldığımız şekilde bash kabuğunun kendi imkanlarını kullanarak paralelleştirme yapmanız çok daha taşınabilir betikler oluşturmanızı sağlayacaktır. Harici araç kullanım imkanı olduğunda "GNU Parallel" bizim oluşturacağımız yapılardan çok daha verimli paralelleştirme de sunabilir. Üstelik oldukça küçük bir disk alanı kapladığı için son derece kullanışlıdır. Şimdi kısaca bu aracın kullanımına da değinmiş olalım.

## GNU Parallel

[https://www.gnu.org/software/bash/manual/html_node/GNU-Parallel.html#GNU-Parallel](https://www.gnu.org/software/bash/manual/html_node/GNU-Parallel.html#GNU-Parallel)

Baştan belirtelim GNU Parallel aracı neredeyse bir kitap kadar açıklanabilecek kullanım seçeneklerine sahiptir. Ancak bizler GNU Parallel ile tanışıp sık kullanılan seçeneklerinden bahsediyor olacağız. Daha fazlası için manuel sayfası ve web üzerinde yer alan resmi dokümantasyon kaynağı size çok geniş bilgi sunacaktır. 

Bash'de yerleşik olmayan komutları paralel olarak çalıştırmanın yolları vardır. GNU Parallel, tam da bunu yapmak için bir araçtır.

GNU Parallel, adından da anlaşılacağı gibi, paralel olarak komutlar oluşturmak ve çalıştırmak için kullanılabilir. Dosya adları, kullanıcı adları, ana bilgisayar adları veya dosyalardan okunan satırlar gibi farklı argümanlarla aynı komutu çalıştırabilirsiniz. GNU Paralel, en yaygın işlemlerin çoğuna (giriş satırları, giriş satırının çeşitli kısımları, giriş kaynağını belirlemenin farklı yolları, vb.) Kısa referanslar sağlar. Parallel, xargs'ın yerini alabilir veya komutları girdi kaynaklarından Bash'in birkaç farklı örneğine aktarabilir. Tam bir açıklama için GNU Paralel belgelerine bakın. Birkaç örnek, kullanımına kısa bir giriş sağlamalıdır.

Örneğin, xargs'ı geçerli dizindeki ve alt dizinlerindeki tüm html dosyalarını gzip olarak değiştirmek kolaydır:

```bash
find . -type f -name '*.html' -print | parallel gzip
```

## Performans Üzerine

Paralel işlemlerde her zaman beklenen performans elde edebilemeyebilir. Bu durumun nedeni mevcut bulunan donanımın özellikleridir. Örneğin hyperthreathing olarak geçen özellik paralellik için uygun değildir.

[https://unix.stackexchange.com/questions/304377/can-i-expect-linear-scaling-with-gnu-parallel](https://unix.stackexchange.com/questions/304377/can-i-expect-linear-scaling-with-gnu-parallel)

[https://serverfault.com/questions/779935/gnu-parallel-doesnt-fully-utilize-my-cpus](https://serverfault.com/questions/779935/gnu-parallel-doesnt-fully-utilize-my-cpus)

BU KONUYU BİRAZ DAHA ARAŞTIR..

[https://www.gnu.org/software/parallel/man.html#EXAMPLE:-Running-more-than-250-jobs-workaround](https://www.gnu.org/software/parallel/man.html#EXAMPLE:-Running-more-than-250-jobs-workaround)