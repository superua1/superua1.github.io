# SON- Eğitim Bitti Ya Sonra ?

Temel eğitimi bitirdik ancak bundan sonrası sizin sistemi ne kadar iyi bildiğinizle ilgili. Sistemi ne kadar iyi tanırsanız o kadar geniş çaplı programlarlar hazırlayabilirsiniz.
Burada öğrendikleriniz bash kabuğunu üzerinden programlama yapabilmeniz için gerekli olan tüm temel bilgileri içeriyor. Yani sıfırdan başlayıp bash kabuğu için sağlam bir temel atmış oldunuz. Artık uzmanlık seviyesi sizin linux işletim sistemini hakkında ne kadar fazla bilgiye sahip olduğunuzla ile ilgili olacak. Biz burada bash dilini kullanarak derdimizi nasıl ifade edeceğimizi öğrenmiş olduk. Tıpkı gerçek hayatta olduğu gibi bu dili kullanarak ileri seviye konulara da değinebilirsiniz basit anlatımlarda da bulunabilirsiniz. Bu durum tamamen sizin anlatacaklarınızı ne kadar iyi bildiğinizle ilgilidir. Yani dilin temellerini öğrendikten sonra konuştuklarınız sizin konuşacağınız konudaki tecrübenize kalıyor. Bizim durumumuz için konuşacağımız alan Linux sistemi ve içindeki araçları olduğu için bu noktadan sonrası, Linux sistemini ve içindeki araçları ne kadar iyi bildiğimizle ilgili. 

Programlama yeteneğinizin gelişebilmesi için kendinize sistem üzerinde yerine getirilecek görevler belirleyip bunları en verimli şekilde nasıl programlayabileceğinizi düşünmeniz gerekiyor.

Ayrıca programlama yaparken karşılaştığınız sorunların çözümü için internetten nasıl yardım bulabileceğinizi ve ara ara diğer geliştiricilerin de yazmış olduğu betikleri incelemenizin önemi üzerinde kısaca durmak da istiyorum.

## Aradığını Bulabilmek

Her şeyi bilmek veya öğrendiklerinizi sürekli hatırlamak zorunda değilsiniz. Neyi nasıl arayacağınızı biliyorsanız, sık ihtiyaç duymadığınız bilgiler için interneti kullanmanız son derece doğru bir yaklaşımdır. Profesyonel de olasınız sürekli interneti kullanıyor olacaksınız. Önemli olan aradığınız şeyi bulabilmeniz.

Karşılaştığınız sorunların çözümleri için yeterince kafa yorduktan sonra, "unix.stackexchange" gibi platformlardan topluluk desteği alabilirsiniz. Soruları doğru şekilde sorduğunuz sürece, size yardımcı olmak isteyecek pek çok geliştirici bulunuyor. Elbette soru sormadan önce diğer insanların sorduğu sorulara ve yanıtlarına mutlaka göz atın. Çok büyük olasılıkla sormak istediğiniz soru daha önce sorulmuş ve yanıtlanmıştır. Arama motorlarını etkili şekilde kullanıyorsanız, aradığınız cevaba ulaşmanız çoğu durumda çok kısa sürecektir.

Programlamayı hedeflediğimiz betik için gereken komutlar ve sistem bilgisi için binlerce geliştiricinin yardım etmek için can attığı "unix.stackexchange" platformunun kullanımına değinmek istiyorum. Bu platformda soruları yeterince açık şekilde sorduğunuzda çoğu durumumda pek çok doğru yanıta ulaşabilirsiniz. Ayrıca daha önce benzeri soruların sorulmuş olması ihtimaline karşı her daim öncelikle internet üzerinde anahtar kelime araştırması yapmanız da son derece önemli. Hem bu sayede kendi kendinize yeni bilgilere nasıl ulaşabileceğinizi ve nasıl doğru şekilde soru sorabileceğinizi de öğrenmiş olacaksınız. Ek olarak her zaman soru sormak yerine, sorulmuş olan sorulara cevap vermeye çalışmanız da gelişiminizi son derece destekleyecektir. Bu süreç içerisinde her şeyden daha önemlisi kendi kendine araştırma, sorgulama ve öğrenme kabiliyetlerini kazandığınızda artık kendi kendinize yetebiliyor olacaksınız. 

Cevabını aradığın sorular için stackoverflow gibi ortamları kullanmayı öğren. Her şeyin cevabını bilmek zorunda değilsin ihtiyaç duyduğunda insanlara sormaktan ve dokümanlara göz atmaktan çekinmeyin.

Artıları Eksileri ve daha detaylıca konuları ele al.

Stackover üzerinden soru sormayı github üzerindeki kodları incelemeyi belirt.