# Copy of 13- İşlem(Process) Yönetimi

Kısa özet: [https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7](https://copyconstruct.medium.com/bash-job-control-4a36da3e4aa7)

[https://totozhang.github.io/2016-01-16-linux-zombieprocess/](https://totozhang.github.io/2016-01-16-linux-zombieprocess/)

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

Oturum açtığınızda, kabuk başlar ve onu başlatan / bin / login programından bir dizi değişkeni, G / Ç akışını ve işlem özelliklerini devralır . Buna karşılık, oturum açma veya ana kabuktan başka bir kabuk üretilirse (çatallanırsa), bu alt kabuk (alt kabuk) ana kabuğundan belirli özellikleri devralır. Bir alt kabuk, çeşitli nedenlerle başlatılabilir: arka planda işlemeyi işlemek için, komut gruplarını işlemek için veya komut dosyalarını yürütmek için. Alt kabuk, üst biriminin ortamını miras alır. Ortam, işlem izinlerinden (işlemin sahibi olan), çalışma dizini, dosya oluşturma maskesi, özel değişkenler, açık dosyalar ve sinyallerden oluşur.

KABU TÜRLERİ>KABUĞUN KULLANDIĞI DOSYALAR>İŞLEMLER...

process environment source ve bunların yakın ilişkisini daha sıralı ve açık şekilde ifade et

harici araçlar çalıştırılırken mevcut işlem fork ile çatallanıp exec ile ilgili işlemi yürütüyor. Mevcut işlemdeki çevresel değişkenler bu işleme aktarılmıyor. Kabuk üzerindeki her işlem execution environmen adı verilen değerlere sahiptir. Alt kabukta başlatılan ya da doğrudan yerleşik veya kabuk fonksiyonu olan işlemlerde mevcut çalıştırma ortamı bu işlemlere de aktarılır. AÇIKLAMALAR YANLIŞ VEYA YETERSİZ OLABİLİR ANCAK BU KONUYLA BAĞLANTILI PEK ÇOK KAVRAM VE BU KAVRAMLARI NETLEŞTİR MUTLAKA

FORKSTAT ARACINA MUTLAKA BAK. BU ARAÇ İLE FORK EXEC VE EXİT TAKİBİ YAPILABİLİYOR..

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_2.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_2.png)

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_3.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Screenshot_3.png)

![10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png](10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff/Screenshot_4.png)

Bu bölümde "process" olarak geçen "işlem" kavramının anlaşılması ve yönetilebilmesi üzerinde duruyor olacağız. Kimi zaman "process" terimi için Türkçe olarak "süreç" ifadesi hatta "proses" kullanılsa da, terimin yapısı gereği "işlem" ifadesi daha doğru bir tanımlama olacaktır. Bizler de anlatımlarımız sırasında "process" kavramı için "işlem" ifadesini tercih ediyor olacağız. Bu açıklamayı, harici Türkçe kaynaklara göz attığınızda "işlem" yerine "süreç" ya da "proses" ifadeleriyle karşılaşmanız halinde şaşırmamanız için ekledim. 

Bu bölümün sonunda, şu ana kadar ele aldığımız ve ileride ele alacağımız pek çok kavramın bizler için daha anlamlı hale geleceğini umuyorum. Çok ayrıntılı olmasa da **genel işleyişi kavramamıza yardımcı olacak temel bilgilere** değiniyor olacağız. O halde daha fazla vakit kaybetmeden, anlatımlara "işlem" yani "process" olarak geçen yapının tanımı ile başlayabiliriz.

wait

bg

fg

jobs

nohup

disown

nice..

vs..

<aside>
ℹ️ **Not:** Buradaki anlatımlar bash programlama kapsamında ele alınmıştır. Daha fazla detay için elbette işletim sistemi özelinde harici kaynaklara(işletim sistemi nasıl çalışır? işletim sistemi nasıl programlanır ? vb.) göz atabilirsiniz. Anlatımlar sırasında mümkün oldukça temelden başlayıp konu bağlamından uzaklaşmamaya ve gerekli olan bilgileri aktarmaya özen göstereceğiz. Yine de bu bölüm içerisinde bağlantılı şekilde pek çok kavramdan bahsedeceğimiz için baştan sona birkaç kez okumak isteyebilirsiniz.

</aside>

## İşlem(Process) Nedir?

Oldukça genel bir tanımla, söz konusu işletim sistemleri olduğunda; diskimiz üzerinde mevcut bulunan ve sistemin çalıştırabileceği yapıda olan her türlü programın öncelikle RAM(hafıza)'e yüklenmesi ve oradan da sırası geldiğinde CPU(işlemci) üzerinde işlenmesine bütüncül olarak "***process***" yani "***işlem***" diyoruz. Tanımı daha anlaşılır kılmak adına bahsi geçen temel kavramları kısaca açıklayacak olursak;

**Program:** herhangi bir yazılım dili yazılmış ve makine kodu olarak derlenmiş olan talimatlar dizisine verilen genel isimdir. Örneğin bash kabuğu C dili ile yazılmış ve derlenmiş olan bir programdır. Yani aslında bizler bash kabuğunu çalıştırırken, makine kodundan oluşturulmuş talimatlar dizisi işlemci tarafından işlenmektedir.

**Makine Kodu:** 2'lik sayı sistemi(binary) ile yani 0 ve 1 rakamları ile oluşturulmuş, işlemciler tarafından anlaşılabilen ve işlenebilen dildir. 0 ve 1'lerin sıralanarak oluşturduğu anlam, işlemci mimarisine göre değişiklik gösterebilir. Bu sebeple farklı işlemci aileleri ve mimarileri için farklı çeviri işlemleri yapılmaktadır. Bizler yüksel seviyeli olarak geçen "bash", "python", "java", "C" ve benzeri diller ile programlarımızı yazarız ancak bu dili işlemcimiz doğrudan anlamlandıramaz. Yüksek seviyeli dille programladığımız talimatların işlemcinin anlayacağı dil olan düşük seviyeli makine diline, çevirici yardımıyla dönüştürülmesi gerekir. Dönüştürme işleminde "derleyici" ve "yorumlayıcı" olmak üzere 2 temel seçenek vardır. Kısaca açıklamamız gerekirse;

**Derleyici:** Tüm komutları okuyup optimizasyonu yaparak işlemcinin çalıştırabileceği şekilde makine koduna dönüştürür. 

**Yorumlayıcı:** Komutları satır satır okuyarak anlık olarak verilen komutların yorumlanarak işlemci tarafından anlaşılır hale getirilmesini sağlar. Derleyicilere oranla bu yöntemde kodun genelinde iyileştirme yapılmadığından komutlar kısmen daha verimsiz çalışır. Ancak kabuk dili gibi anlık olarak komutların yorumlanması gereken durumlar için yorumlayıcı özelliği harika bir çözüm sunmaktadır. Bash de yorumlayıcı bir dil olduğu için kullanıcıdan gelen komutları satır satır okuyup değerlendirir. Yani yorumlayıcı, komutların çalıştırılmasına her aşamada aracılık eder. Bu sebeple verimsizidir. Ancak derleyici tek seferde makine kodu olarak doğrudan işlemci için dönüştürüldüğünden daha verimlidir. 

Kabuğumuz hem etkileşimli kullanım hem de programlanabilirlik sunduğu için yorumlayıcı yapıda olması makul bir yaklaşım. Kabuk özelinde bu konunun daha fazla ayrıntısına şu an için ihtiyacımız yok. İşlem dediğimiz olgunun temelde hangi süreçten geçtiğine kısaca değinmek üzere temel bileşenleri açıklayarak devam edebiliriz.

Kabuk bir programlama dili olarak kullanıldığında, komutlar ve kabuk kontrol yapıları bir düzenleyiciye yazılır ve komut dosyası adı verilen bir dosyaya kaydedilir. Dosyadaki satırlar kabuk tarafından birer birer okunur ve yürütülür. Bu programlar yorumlanır, derlenmez. Derlenen programlar, yürütülmeden önce makine diline dönüştürülür. Bu nedenle, kabuk programları genellikle ikili yürütülebilir programlardan daha yavaştır, ancak yazmaları daha kolaydır ve temel olarak basit görevleri otomatikleştirmek için kullanılırlar. Kabuk programları ayrıca komut satırında etkileşimli olarak yazılabilir ve çok basit görevler için bu en hızlı yoldur. Bununla birlikte, daha karmaşık komut dosyaları için, bir düzenleyicide komut dosyaları yazmak daha kolaydır (gerçekten harika bir daktilo değilseniz). Aşağıdaki komut dosyası, aynı sonuçları vermek için herhangi bir kabuk tarafından çalıştırılabilir.

![https://web.stanford.edu/class/cs101/software-program.png](https://web.stanford.edu/class/cs101/software-program.png)

**Disk:** Programlar gibi sistem için gerekli olan dosyaları bünyesinde bulunduran kalıcı depolama birimidir. 

![https://web.stanford.edu/class/cs101/software-cpu.png](https://web.stanford.edu/class/cs101/software-cpu.png)

**RAM:** Disk üzerinde yer alan programların(makine kodu talimatlarının) işlemci tarafından işlenmek üzere geçici olarak hafızada tutulmasını sağlar. Diskteki verilerin doğrudan işlemciye aktarılmamasının en temel nedeni RAM'in sağladığı hızdır. RAM'in, verileri kaydetme ve saklama zorunluluğu bulunmadığı için programlara ait talimatlar dizisini çok hızlı şekilde alıp işlemciye aktarabiliyor. İşi biten talimatlar da RAM üzerinden siliniyor. Bu sayede yüksek işlem kapasitesi sağlanabiliyor.

**CPU:** Program dosyaları içerisinde bulunan işlem emirlerini yerine getirmek üzere, ram üzerinde yer alan program talimatlarını okuyup uygun şekilde işler. 

![https://web.stanford.edu/class/cs101/software-program-run.png](https://web.stanford.edu/class/cs101/software-program-run.png)

İşlemin ne olduğu ve nasıl işlendiğinin en yalın hali bahsettiğimiz şekildedir. Bu detayları(hatta çok çok daha fazlasını) biliyor ya da bilmeseniz de açıklanmış olmasını gereksiz buluyor olabilirsiniz. Yine de anlatımın herkes tarafından sıralı ve kolay takip edilebilir olası için eklendiğini bilmenizi isterim. 

[https://web.stanford.edu/class/cs101/software-1.html](https://web.stanford.edu/class/cs101/software-1.html)

Çalışmakta olan programlar genellikle tek işlem olarak ifade edilse de birden fazla işleme sahip olmaları da mümkündür. Ayrıca istenildiği takdirde tek bir işlem çatallanarak(fork) alt işlemler de oluşturabilir. 

Eğer bu son açıklama yeterine açık gelmediyse lütfen endişelenmeyin. En nihayetinde işlem denilen kavramın **ne olduğu** ve **nasıl işlendiğine** kısaca değinmiş olduk. Anlatımın devamında ise bir işlemin **nasıl oluştuğunu** adım adım açıklıyor olacağız. 

Gözden geçir; [https://www.linuxtopia.org/online_books/introduction_to_linux/chap_04.html](https://www.linuxtopia.org/online_books/introduction_to_linux/chap_04.html)

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled.png)

En nihayetinde çok genel hatlarıyla işlemin ne olduğunu öğrenmiş olduk. Şimdi GNU/linux yani işletim sistemi özelinde işlemin nasıl oluştuğuna çok da kısaca değinerek ihityacımız olan bilgiyi edinelim.

# GNU/Linux Üzerinde İşlemlerin Oluşumu

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

[https://linuxhint.com/fork-system-call-linux/](https://linuxhint.com/fork-system-call-linux/)

[https://www.youtube.com/watch?v=2JC39IN0fnY&ab_channel=ahmetalpbalkan](https://www.youtube.com/watch?v=2JC39IN0fnY&ab_channel=ahmetalpbalkan)

GNU/Linux sisteminin açılışını kısaca aşağıdaki şekilde genelleyebiliriz;

1. **BIOS** : Bios un donanım kontrolü yapıp, işletim sistemini yükleyeceği bilgilere ulaşması.
2. **MBR** : İşletim sistemini yükleyecek olan bootstrap programının bulunup çalıştırılması.
3. **GRUB** : Bootstrap programının işletim sistemi çekirdeğini yüklemesi.
4. **KERNEL** : Linux çekirdeğinin çalışması ve init process nin başlatılması.
5. **INIT** : Init process inin çalışması.
6. **RUNLEVEL** : Init process inin gerekli servis ve işlemleri başlatması.

Bilgisayarımızı ilk açtığımızda sistem çekirdeğimiz, "init" olarak geçen ana işlemi başlatır. Ana işlem başlatıldıktan sonra diğer tüm işlemler bu ana işlemin çatallanması(fork) ile oluşturulur. Yani aslında ilk işlem çekirdek tarafından oluşturulmuşken diğer tüm işlemler ilk işlemin çatallanmasının ürünüdür. 

Çatallama olarak geçen yapı en basit tanımla, mevcut ana işlemin kopyalanıp alt işlem haline dönüştürülmesi olarak açıklanabilir. Bu sayede hiyerarşik şekilde ana işlemlerin kontrolü altında pek çok farklı işlem aynı anda yürütülebilir. Tüm kavramların daha da netleşmesi için şema üzerinden birazcık daha detay belirtebiliriz.

Süreci temel düzeyde adım adım açıklayacak olursak;

Çekirdeğimiz ilk işlemi(bizim örneğimizde "init") başlattıktan sonra ilk işlem, başka işlemlerin de yürütülebilmesi için çekirdeğe çatallama(**fork)** çağrısında bulunur. İlk işlemden çağrı alan çekirdek, işlemi çatallayarak mevcut işlemin birebir kopyası olan "alt işlemi" oluşturur. Çatallama işleminden sonra, oluşturulmuş olan "alt işlem" ile "ana işlem" aynı programı ayrı işlemler olarak yürütürler. Bu noktada, alt işlemde farklı bir program çalıştırılabilmesi için exec çağrısı yapılır. exec, ilgili sürece tanımlı olan programı istenilen başka bir program ile değiştirir. Bu sayede yeni üretilmiş olan alt işlemde, istenilen program çalıştırılabilir. Aksi belirtilmedikçe ana işlem alt işlemin sonlandırılmasını bekleyecektir.

![13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%203.png](13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3/Untitled%203.png)

Çok temel düzeyde işlemlerin oluşturulma yapısından bahsettik. Şimdi de somutlaştırmak üzere sorgulamaya devam edelim. İlk oluşturulan ana işlemin hangisi olduğunu teyit etmek için konsola `ps ax | head -2` komutunu girebilirsiniz. Aldığınız çıktıda PID(process id) yani işlem numarası "1" olan işlemin sisteminize göre "init" ya da "sytemd" olduğunu görebilirsiniz.(Alternatif çalışma ortamlarında duruma göre ilk başlatılan işlem "init" ya da "systemd" dışında herhangi bir yapı da olabilir.) İşlem numaraları çekirdek için "0" olarak kabul edilip sıralı şekilde atandığından, "1" numaralı işlem ilk başlatılan işlemi temsil ediyor.

Hatta açıklamış olduğumuz çatallama durumunu daha net görebilmek adına konsola `pstree` komutunu verip, tüm işlemlerin aslında ilk başlatılan işlemin altında çalışan "sub-process" yani "alt işlem" olduğunu teyit edebilirsiniz. Ayrıca burada bahsi geçen alt işlemler "child process" yani "çocuk işlem" olarak isimlendirilirken, alt işlemi oluşturan üst işlemler de "ebeveyn" yani "parent process" olarak ifade edilebiliyor. Elbette bu bağlamda ana işlem çocuk işlemleri doğurabileceği gibi çocuklar da zamanı geldiğinde kendi çocuk işlemlerini doğurarak alt işlemleri için ebeveyn olabilirler. Zaten burada bahsi geçen çocuk ve ebeveyn gibi isimlendirmeler de yapının kolay kavranması için tercih edilmiştir. 

Eğer `pstree` komutunu kullandıysanız, bash kabuğun aslında ilk başlatılan işlemin(genellikle "init") alt işlemi olduğunu ve hatta kabuğa girmiş olduğumuz `pstree` komutun da bash işleminin altında çalışan bir işlem olduğunu fark etmişsinizdir. En nihayetinde sistemin genel işlem oluşturma yapısına değindiğimize göre şimdi bash kabuğu özelinde işlemlerin nasıl ele alındığına daha yakından bakabiliriz.  

## Bash Kabuğunda İşlemlerin Oluşumu

Bash kabuğu da en nihayetinde kendisinden önce başlatılmış olan bir işlemin çatallanması ve exec ile bash kabuk programının yeni işlem olarak çalıştırılması ile var olur. Bizler de bash kabuğunu kullanarak yeni programları çalıştırılması için yeni işlemlerin oluşturulmasını da sağlayabiliriz. 

Bash kabuğu, kendisine verilmiş olan komutların türüne göre işlem oluşturma davranışını değiştirebilir. Bash, kendi bünyesinde bulunan yerleşik komutları(`cd`,`bg`,`echo`.. vs.) alt işlem oluşturmaya ihtiyaç duymadan geçerli kabuk işleminde çalıştırır. Çünkü bu komutlar aslında bash programının bir parçası olarak kabuk programına tahsis edilmiş olan işleme dahildirler. Harici olan programlar bash kabuğu üzerinden çalıştırıldığında, bash kabuk programının bir parçası olmadığı için bash kabuğunun altında yeni bir alt işlem oluşturulup burada çalıştırılabilirler. Örneğin bizim anlatım sırasında girmiş olduğumuz `pstree` komutu aslında harici bir programdır. Bash kabuğu da eğer sistemde yüklü ise `pstree` programının alt işlem üzerinden çalıştırılmasına aracılık eder.

Bash kabuğu kendi bünyesinde bulunan dahili komutları çalıştırırken yalnızca çatallama işlemi için sistem çağrısında bulunur. Ancak harici araçların bash kabuğu üzerinden çalıştırılması talep edildiğinde, çatallama ve exec sistem çağrıları ile ilgili araç alt işlemde çalıştırılır. Bu sebeple dahili komutlar elbette harici komutlara oranla daha performanslı şekilde çalışır. Çünkü dahili(yerleşik-builtin) komutlar için her defasında alt işlem üretilmesi gerekmez, yalnızca mevcut bash işleminin devamı olarak yürütülürler.

Mevcut işlemin çatallanarak yeni bir işlem oluşturma durumunu basitçe şematize etmemiz gerekirse;

Üzerinde çalışmakta olduğumuz bash kabuğunda yerleşik komut girersek;

**Not:** Bash kabuğunda yerleşik olan tüm komutları `compgen -b` komutu ile öğrenebilirsiniz. 

Üzerinde çalışmakta olduğumuz bash kabuğunda harici komut girersek;

İşlemler ve alt işlemlerden bahsetmiş olduk. Peki ya daha önce hiç altkabuk diye bir kavram duymuş muydunuz ? Alt kabuk kavramı genellikle alt işlem ile karıştırılan bir kavramdır. Karışıklığı önlemek adına gelin altkabuk kavramını açıklayarak devam edelim.

Alt kabuklar hakkında; Betik dosyalarının, parantez içerisine yazılan komutların ve pipe işaretinin

[https://unix.stackexchange.com/a/442704/364572](https://unix.stackexchange.com/a/442704/364572)

Değişkenler hakkında;[https://www.baeldung.com/linux/bash-variables-export](https://www.baeldung.com/linux/bash-variables-export)

Bir değişken export edildiğinde, tüm alt işlemler için kullanılabilir olur. Bu ikisi arasındaki temel fark, dışa aktarma komutunun, değişkeni, o kabukta yürütülen sonraki tüm komutlar için kullanılabilir hale getirmesidir.

## Alt Kabuklar Hakkında

Eğer kabuğa `bash` komutunu girersek, mevcut kabuğumuz sistem üzerinde bash programını arar ve muhtemelen /usr/bin/bash dizininde bulduktan sonra harici bir program olduğu için alt işlem oluşturup kabuğu burada çalıştırır. Her ne kadar mevcut kabuğun alt işlemi olarak çalıştırılmış olsa da bu kabuk aslında alt kabuk değildir. Bash kabuğuna göre yalnızca alt işlem üzerinde çalıştırılan harici bir programdır. Fakat biz özellikle alt işlemde kabuk programını çalıştırmak istediğimizi uygun şekilde belirtirsek, bu defa **mevcut kabuğun birebir kopyası** alt işlemde çalıştırılır. Alt işlemde çalıştırılan bu kabuk, ana kabuğun ortam özellikleri de dahil birebir aynısıdır. Burada bahsi geçen [ortam özellikleri](https://pubs.opengroup.org/onlinepubs/9699919799.2016edition/utilities/V3_chap02.html#tag_18_12) daha önce de bahsetmiş olduğumuz; açık dosyalar, umask, çalışma dizini, kabuk değişkenleri / işlevleri / takma adları gibi şeyleri içerir. Yani örneğin ana kabukta tanımlı olan tüm değişkenler, alt kabuğa da aynen aktarılmıştır. Her ne kadar ana kabuktaki ortam özellikleri alt kabuğa aktarılsa da, alt kabuktaki ortam özelliği değişimleri ana kabuğu etkilemez.

Elbette harici programa da mevcut kabuğun ortam özellikleri aktarılmaz. Çünkü temelde harici olarak yalnızca bash programı değil herhangi bir program da çalıştırılabilir. Neticede her çalıştırılan harici programa mevcut kabuğun özelliklerinin aktarılması da mantıklı değildir. Nitekim bizler bash [betik.sh](http://betik.sh) ya da . /betik.sh komutlarını kullandığımızda, betik dosyası alt işlem üzerinde çalıştırılır. 

Bu durumun daha net anlaşılabilmesi alt kabuğa miras olarak aktarılan bilgilerin üzerinde biraz daha duralım istiyorum.

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch01lev1sec6.html)

Alt kabuk, değişkenlerin, işlevlerin, bayrakların ve her şeyin ana kabukta olduğu gibi mevcut olduğu ana kabuğun bir kopyasıdır.

ALT İŞLEM: Bir çocuk kabuk, çatal olarak başlar, ancak başlangıç yapılandırmalarında verilen kabuk varsayılan değerlerine sıfırlanır. Bazı kodları çalıştırmak için kullanılan bir işlem haline gelir (bir kabuk veya bir komut).

İşte alt işlem ile alt kabuk arasındaki farklılık; alt işlemin herhangi bir programı çalıştırmak, alt kabuğun ise yalnızca kabuk olarak çalışmak üzere oluşturulmasından kaynaklanır. Biz herhangi bir programı değil de alt kabuk oluşturmak istediğimizi belirtirsek, mevcut kabuğun birebir kopyası alt işlemde çalıştırılır. Ancak biz konsola bash komutunu verip yeni bir bash kabuk programı çalıştırırsak bu sadece harici bir program olarak çalışır. Elbette harici programa da mevcut kabuğun ortam özellikleri aktarılmaz. Çünkü temelde harici olarak yalnızca bash programı değil herhangi bir program da çalıştırılabilir. Neticede her çalıştırılan harici programa mevcut kabuğun özelliklerinin aktarılması da mantıklı değildir. Nitekim bizler bash [betik.sh](http://betik.sh) ya da . /betik.sh komutlarını kullandığımızda, betik dosyası alt işlem üzerinde çalıştırılır. 

İşte alt kabuk ve alt işlem arasındaki farklılık tam olarak budur. Eğer henüz tam olarak netleşmediyse örnekler üzerinden ele aldığımızda çok daha iyi anlayacaksınız. Şimdi nasıl alt kabuk oluşturabileceğimizi öğrenerek devam edelim.

# Bash Kabuğunda Nasıl Alt Kabuk Oluşturulur ?

Alt kabuk oluşturmak için birden fazla yöntem bulunuyor. Bu yöntemler bash kabuğunun kuralları dahilinde tanımlanmış olan yöntemlerdir.

### Parantez ile Alt Kabuk Oluşturmak

Parantez içerisinde yazılmış olan komutlar alt kabuk oluşturulup bu alt kabuk üzerinde çalıştırılır. Tüm komutlar işlendikten sonra alt kabuk kapatılarak ana kabuğa dönülür.

### Pipe ile Alt Kabuk Oluşturmak

[P](https://www.gnu.org/software/bash/manual/html_node/Pipelines.html#Pipelines)ipe Kullanımı : Pipe işareti kullanıldığında soldaki ve sağdaki komutlar için iki alt kabuk oluşturulur ve her iki alt kabuğunda sona ermesi beklenir. Soldaki komutun çıktıları sağdaki komuta girdi olarak aktarılır. (Eğer lastpipe seçeneği aktifse pipe işaretinin sonundaki komut mevcut kabuk üzerinde çalıştırılırken öncesindeki komutlar altkabukta çalıştırılır.) 

![https://www.it.uu.se/education/course/homepage/dsp/vt19/images/module-2/parent-children-pipe.png](https://www.it.uu.se/education/course/homepage/dsp/vt19/images/module-2/parent-children-pipe.png)

`$(komutlar..)` yapısının kullanımı, tanımı gereği bir alt kabuk oluşturur. Alt kabuk mevcut bash kabuğunun çatallanıp yeni kabuğu(alt kabuk) alt işlemde çalıştırması ile oluşturulur. Bu kullanım yönteminde parantez içerisinde yazılan komutlar alt kabukta çalıştırılır. Elbette alt kabuktaki değişiklikler işlemlerin yapısı gereği üst işlemi yani üst kabuğu etkilemez. Çünkü alt kabuğun tek yaptığı işlem çıktılarını mevcut tty konsoluna iletmektir. Örneğin alt kabukta dizin değiştirmek üzere `cd` komutunu kullanırsanız üst kabukta hiç bir değişiklik olmayacaktır. 

```jsx
pwd ; $(cd /etc ; pwd)
```

Elbette üst kabuk yani üst işlem kendini çatallayarak alt kabuğu oluşturduğu için bünyesinde bulunan değişken gibi yapılar da alt kabuğa aynen iletilir. 

Genelde karıştırılan bir durum gruplama yapmamızı sağlayan süslü parantez kullanımıdır. Süslü parantez tek başına alt kabuk oluşturmak için kullanılmaz. Süslü parantezin kullanım amacı tıpkı fonksiyonları tanımlarken kullandığımız gibi birden fazla komutun sınırını belirtebilmemizi sağlamaktır.

```bash
#!/bin/bash

echo sh1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
( echo ss1 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL \
  | { read LINE
      echo $LINE
      echo ss2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL
    }
)
bash -c 'echo sh2 $\$=$$ BASHPID=$BASHPID PPID=$PPID SHLVL=$SHLVL'
Running the above code on my machine, yielded:

sh1 $$=797 BASHPID=797 PPID=756 SHLVL=2
ss1 $$=797 BASHPID=799 PPID=756 SHLVL=2
ss2 $$=797 BASHPID=800 PPID=756 SHLVL=2
sh2 $$=801 BASHPID=801 PPID=797 SHLVL=3
```

## Alt Kabuk(Subshell) Kullanma Maaliyeti

Tek sefer için alt kabuk kullanmak çok maliyetli olmasa da tekrar eden işlemler için her defasında alt kabuğun kullanılması hissedilir derecede yavaşlığa sebebiyet verecektir. Bu durumu aşağıdaki örnek komutları çalıştırarak gözlemleyebilirsiniz.

Comparing

```
time for((i=0;i<10000;i++)); do echo "$(echo hello)"; done >/dev/null 

```

with

```
time for((i=0;i<10000;i++)); do echo hello; done >/dev/null 
```

Bu sebeple alt kabukları kullanacağımız durumları iyi belirlemeliyiz. Ayrıca alt kabuklar mevcut kabuk ortamı dışına hiç bir veri aktaramadığı için ana kabuk ya da diğer kabuklar ile haberleşemez. Bu da çoğu durumda bir dezavantajdır. 

$(..) ile (..) farkı; dolar işareti tüm komutları genişletip çalıştırır. Ters tırnak ile benzer görevdedir. Örneğin $(echo ls) komutunu girersek, ls komutunun çıktıları echo komutu yardımıyla bastırılır. [Mutlaka bak !!](https://stackoverflow.com/a/27472808/7481877) [Mutlaka bak 2](https://superuser.com/a/935427)

Bash kabuğunda alt kabuk oluşturabilecek diğer yöntemler;

- Arkaplan: Arkaplanda çalıştırmamızı sağlayan ve & işareti aslında ilgili komutu alt kabuk oluşturup burada çalıştırır. Yani arkaplandaki süreçler de aslında alt kabuk üzerinde çalıştırılır.
- [P](https://www.gnu.org/software/bash/manual/html_node/Pipelines.html#Pipelines)ipe Kullanımı : Pipe işareti kullanıldığında soldaki ve sağdaki komutlar için iki alt kabuk oluşturulur ve her iki alt kabuğunda sona ermesi beklenir. Soldaki komutun çıktıları sağdaki komuta girdi olarak aktarılır. (Eğer lastpipe seçeneği aktifse pipe işaretinin sağındaki komut mevcut kabuk üzerinde çalıştırılırken soldaki komut altkabukta çalıştırılır.)
- Komut İkamesi: `$(…)` (ters tırnak ile aynı ``…``) standart çıktısı bir boruya ayarlanmış bir alt kabuk oluşturur, üstteki çıktıyı toplar ve bu çıktıya, sondaki satırsonlarını çıkararak genişler.
- İşlem İkamesi: `<(…)` Standart çıkışı bir boruya ayarlanmış bir alt kabuk oluşturur ve borunun adına genişler. Üst öğe (veya başka bir işlem) alt kabuk ile iletişim kurmak için boruyu açabilir.
- `>(…)` Aynı şeyi yapar, ancak standart girişteki boru ile.
- Yardımcı İşlem: `coproc …` bir alt kabuk oluşturur ve sona ermesini beklemez. Alt kabuğun standart giriş ve çıkışının her biri, ana boru her bir borunun diğer ucuna bağlanan bir boruya ayarlanır.

Alt kabuk, mevcut kabuğun kopyasını oluşturur. Aynı değişkenlere¹, aynı işlevlere, aynı seçeneklere, vs. sahiptir. Kaputun altında, call² çatal sistemi ile bir alt kabuk oluşturulur; ebeveyn beklerken (ör. $ (…)) veya yaşamına devam ederken (ör.,… &) veya başka bir şekilde ondan bekleneni yaparken (ör.,… |…) çocuk süreç kendisinden bekleneni yapmaya devam eder. ).

$$ ile BASHPID farklı olmasının sebebi $$işaretinin çalıtşırımış olan ana script dosyasının süreç numarasını vermesidir. Alt kabuk oluşturunca alt kabuk elbette farklı süreç numarasına sahip olur fakat ana kabuğun yani ana scripting altında çalıştığı için $$ değeri ana kabuk ile aynı olur. Yine de kendinize özgür süreç numarsını almak için BASHPID komutunu kullanabiliriz.

PİPE;[http://www.rozmichelle.com/pipes-forks-dups/](http://www.rozmichelle.com/pipes-forks-dups/)

# Bash Üzerinde Paralellik

[https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/](https://galvanist.com/posts/2013-05-23-managed-concurrency-in-the-bash-shell/)

[http://coldattic.info/post/7/](http://coldattic.info/post/7/)

[https://gioyik.com/p/paralelism-concurrency-logging-bash](https://gioyik.com/p/paralelism-concurrency-logging-bash)

[https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/](https://thoughtsimproved.wordpress.com/2015/05/18/parellel-processing-in-bash/)

[http://prll.sourceforge.net/shell_parallel.html](http://prll.sourceforge.net/shell_parallel.html)

[Bash Üzerinde Paralellik](Copy%20of%2013-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%20372faa9aced8468fbc117be31c86dacf/Bash%20U%CC%88zerinde%20Paralellik%206595778ee8f64259b45d41df73e13693.md)

## Job Control | İş Kontrolü

Tek bir işlem birden fazla alt işlem oluşturabileceği için işlemlerin kolay yönetilebilmesi için iş kontrolüne ihtiyaç vardır. Tek bir ana işlem altında oluşturulan tüm alt işlemler bir bütün halinde ele alındığında "job" olarak geçen "iş" kavramına karşılık geliyor. 

Farklı kabuklar alt kabuklardaki veya alt süreçlerdeki süreç numarası bilinen işlemlere müdahale edebilir mi ?

Ebeveyn altında oluşturulan tüm süreçler aynı grupta kabuk edilir. Bu grubun kimlikiği de ppid olarak geçen parrent işlem numarasıdır. Burada bahsi geçen gruplar ancak önplandaki işlemler için geçerli olabilir. Arkaplandaki işlemlerin zaten alt kabuk oluşturulup çalıştığını biliyoruz. Bu sebeple alt kabuklarda ya da arkaplanda çalıştırılan süreçler kendi gruplarına sahiptir. Yani kesme sinyali INT gönderdiğimizde arkaplandaki veya alt kabuktaki süreçler kapsam dışında kalarak kapanmaz. İş kontrolü zaten bu tüm bu süreçlerin kontrolü kolaylaştırmak için vardır. Arkaplandaki süreçleri takip etmek ve gerektiğinde öne almak veya sonlandırmak için bize kolaylık sağlar.

[https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html](https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html)

[https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If the script or program,the foreground to the background](https://www.linuxjournal.com/content/job-control-bash-feature-you-only-think-you-dont-need#:~:text=If%20the%20script%20or%20program,the%20foreground%20to%20the%20background).

[https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html](https://cs162.eecs.berkeley.edu/static/readings/ic221_s16_lec17.html)

[https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script](https://linuxconfig.org/how-to-propagate-a-signal-to-child-processes-from-a-bash-script)

## Servis

Servisler tam olarak nedir ve nasıl tanımlanır örneğin bash scriptimiz servis olarak tanımlanabilir mi ?

Servis tanımlamak;[https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6](https://medium.com/@benmorel/creating-a-linux-service-with-systemd-611b5c8b91d6)

[https://web.stanford.edu/class/cs101/software-cpu.png](https://web.stanford.edu/class/cs101/software-cpu.png)

Bu anlatımdan çıkaracağımız en önemli ek ders; aslında bash kabuğunun da yalnızca kullanıcı ile çekirdek arasında iletişimi sağlayan aracı katman olduğudur. Benzer şekilde bizler sistem yönetiminde kabuk yerine grafiksel arayüzü kullandığımızda, aslında grafiksel arayüzü sağlayan programı kullanmış oluyoruz. Bu program da tıpkı bash kabuğunda olduğu gibi bizim isteklerimizi çekirdeğe iletiyor. Yani özetle; grafiksel ya da bash kabuğu gibi bir komut satırı arayüzü kullanarak amaçladığımız tek şey, bir insan olarak sistem çekirdeğine derdimizi rahatça anlatabilmek. 

[Ekstra notlar](Copy%20of%2013-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%20372faa9aced8468fbc117be31c86dacf/Ekstra%20notlar%2058c6d83b9d384e25a896c0f6d5f0d072.md)

[](Copy%20of%2013-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%20372faa9aced8468fbc117be31c86dacf/Untitled%200e37ee0653d94631ad2f2a8e63236677.md)