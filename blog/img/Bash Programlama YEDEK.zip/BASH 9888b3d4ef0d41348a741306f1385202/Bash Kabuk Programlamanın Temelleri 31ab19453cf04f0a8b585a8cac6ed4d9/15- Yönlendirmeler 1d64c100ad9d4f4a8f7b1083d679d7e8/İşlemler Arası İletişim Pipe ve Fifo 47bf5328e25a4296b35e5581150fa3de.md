# İşlemler Arası İletişim | Pipe ve Fifo

İşlemler, çekirdek ve diğer işlemlerle iletişim kurarak davranışlarını koordine eder. Linux, çeşitli süreçler arası iletişim (IPC) mekanizmalarını destekler, sinyaller ve borular bunlardan ikisidir. Ek olarak, Linux ayrıca System V’in IPC mekanizmasını da destekler (adını ilk Unix sürümünden alır).

[https://medium.com/@gokhansengun/unix-domain-socket-nedir-ve-ne-işe-yarar-c72fe8decb30](https://medium.com/@gokhansengun/unix-domain-socket-nedir-ve-ne-i%C5%9Fe-yarar-c72fe8decb30)

### Süreçler Arası iletişim (IPC) Yöntemleri

- Sinyaller ( signals )
- Boru Hatları ( pipes )
- Soketler ( sockets )
- Paylaşımlı Bellek ( shared memory )

If you're on a Linux system, create a file in `/dev/shm`. Files stored in this directory are only stored in shared memory; they are not written to disk.

Depending on your system configuration, `/tmp` and/or `/var/tmp` may be mounted as a tmpfs, making them behave the same way. Your mileage may vary.

- Paylaşılan Dosyalar ( shared files )
- Mesaj Kuyrukları ( message queues )

Pipe

Pipe ve fifo avantaj dezavantajlarını araştır.

Pipe olarak geçen tünel ya da boru yapısı esasen isimsiz ve isimli olmak üzere iki türe ayrılıyor. 

## İsimsiz Tünelleme | Pipe

Tünellemede temel amaç işlemler arasında iletişimi sağlamaktır. İsimsiz tünelleme olarak geçen pipe operatörü; operatörden önceki işlemin çıktılarını, operatörden sonraki işlemin okuma yani girdi ucuna bağlar. Pipe ile iletişimi sağlanan tüm işlemeler mevcut kabuğun altında, ayrı ayrı alt kabuk başlatılarak çalıştırılır. Bu sayede işlemler aynı anda paralel olarak yürütülebilir. İsimsiz pipe yapısından veriler tek yönlü akar. Yani operatörden önceki işlemin çıktıları operatörden sonraki işleme girdi olarak bağlanır. Bunun tersi pipe ile mümkün değildir. İlk işlemin ürettiği veriler sıralı şekilde ikinci işlemin girdisine bağlanır. Veri aktarımı sırasında her iki işlem de birbirini beklemek durumundadır. Veriler ikinci işlem tarafından okunana kadar ilk işlemde bekletilir, ya da ikinci işlem hızlı okuduğunda ilk işlemin veri göndermesini bekler. Bu sebeple pipe operatörü kullanılarak iletişim kurması sağlanmış işlemlerin verileri yazma ve okuma hızları birbirine parelel olmalıdır. Aksi halde tünel yapısı aralıklı olarak tıkanarak performans sorunlarına neden olabilir. Pipe yapısının isimsiz olarak geçmesinin nedeni tek kullanımlık olmasıdır. Pipe ram yani bellek üzerinde geçici olarak oluşturulmuş aktarma kanalıdır ve aktardığı verileri diske kaydetmez. İşi bittiğinde veriler ile birlikte açılmış olan pipe tüneli de kapatılır. Bellek üzerinden çalıştığı ve disk üzerinde herhangi bir okuma yazma yapmadığı için dosyalar üzerinden yönlendirmeye oranla çok daha hızlı çalışır.

## İsimli Tünelleme | Fifo

İsimli pipe ise fifo olarak geçer. Bir FIFO (İlk Giren İlk Çıkar) pipe yapısına benzer. Temel fark, bir FIFO'nun dosya sistemi içinde bir ada sahip olması ve normal bir dosyayla aynı şekilde açılmasıdır.

FIFO'nun bir yazma sonu ve bir okuma ucu vardır ve veri borudan yazıldığı sırayla okunur.

Boru ve FIFO'nun derinlemesine anlaşılması için. Lütfen bunu ve bunu okuyun. Bu yazıda birbirlerinden ne kadar farklı olduklarını öğreneceğiz.

# **PIPE ve FIFO Süreçler Arası İletişim arasındaki fark**

Geçici dosyalar disk üzerinden işlem görür. Pipe ise ram yani bellek üzerinden işlem gördüğü için çok daha hızlıdır. Pipe kullanıldığında aktarım yapılan taraflar alt işlem olarak çalıştığından parelel olarak işlem görürler ve anlık olark veri aktarımı yapılır. Bu sebeple aktarım yapılan uçlardaki araçların çıktı üretme ve çıktıları okuma noktasında aynı hıza sahip olması gerekir aksi halde boru tıkanır. iki taraf da birbirini beklemek zorunda kalır

gecici dosyalarda veriler geici olarak da olsa tutulur pipe ise veriyi bellek üzerinden akıtır sadece 

geçici dosyaların pipe yerine kullanmasının mantıklı olduğu tek durum verilerin tekrar tekrar okunması gereken durumlardır.

[https://brandonwamboldt.ca/how-linux-pipes-work-under-the-hood-1518/](https://brandonwamboldt.ca/how-linux-pipes-work-under-the-hood-1518/)

[https://stackoverflow.com/questions/6977561/pipe-vs-temporary-file](https://stackoverflow.com/questions/6977561/pipe-vs-temporary-file)

[https://linuxhint.com/bash_pipe_tutorial/](https://linuxhint.com/bash_pipe_tutorial/)

Bir Unix kanalı, birinci sürecin STDOUT (standart çıktı) dosya tanımlayıcısını, ikincisinin STDIN (standart giriş) 'e bağlar. O zaman olan şey, ilk işlem STDOUT'a yazdığında, bu çıktı ikinci işlem tarafından hemen okunabilir (STDIN'den).

Birden çok boru kullanmak, tek bir boru kullanmaktan farklı değildir. Her bir boru bağımsızdır ve basitçe bitişik işlemlerin STDOUT ve STDIN'lerini birbirine bağlar.

# Pipe

Yönlendirme işlemleri sırasında girdileri ve çıktıları istediğimiz şekilde nasıl aktarabileceğimizi öğrendik. Sizlerin de bildiği üzere yönlendirme sırasında aslında dosyalar arasında veri aktarımı yapmış olduk. Eğer dosyalar yerine anlık olarak işlemler arasında veri aktarmak istersek, isimli(named-fifo) ve isimsiz(unnamed-ordinary) pipe olarak geçen yapıları kullanabiliriz. Pipe yapısına ihtiyaç duymamızdaki en temel iki sebep; hızlı çalışması ve aynı anda paralel şekilde işlemler arasında aktarım yapılabilmesidir. Anlatımın devamında bu açıklama çok daha mantıklı hale gelecektir. Anlatımlarımıza isimsiz yani sıradan(ordinary) pipe ile başlayalım.

## İsimsiz-Sıradan Pipe(Unnamed-Ordinary)

İsimsiz olarak geçen pipe, çubuk şeklinde görünen dik çizgi  `|` operatörü ile temsil edilir. Pipe operatöründen önceki işlemin çıktıları, operatörden sonraki işlemin girdisi olarak aktarılır. Pipe metodunun aktarım biçimi "ilk giren ilk çıkar/first in first out(fifo)" şeklindedir. Yani veriler ilk işlemin ürettiği sıraya uygun şekilde tek yönlü olarak bir sonraki işleme aktarılır. Daha iyi anlamak adına çalışma yapısına daha yakından bakalım.

Basit bir örnek üzerinden gidecek olursak `ls` komutu ile mevcut dizinimizi listeleyelim ve liste içerisinde geçen istediğimiz bir anahtar kelimeyi `grep` komutu ile filtreleyelim.

```bash
└─$ ls
bin  games  include  lib  lib32  lib64  libexec  libx32  local  sbin  share  src
└─$ ls | grep "lib"
lib
lib32
lib64
libexec
libx32
```

Bu işlem sırasında mevcut kabuk işlemi çatallanarak `ls` ve `grep` komutları iki ayrı alt kabukta çalıştırıldı. İlk işlemin yani `ls` çıktıları, `grep` komutuna girdi olarak bağlandığı için `grep` komutu ile "**lib**" ifadesi geçenleri filtreleyebildik. 

![I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled.png](I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled.png)

Daha detaylı şekilde bizim basit örneğimiz aşağıdaki adımlardan geçerek çalıştı;

- Ana işlem iki kez çatallanarak iki alt kabuk işlemini oluşturdu.
- Ana işlem, çatalladığı alt işlemlerin her ikisinin de sona ermesini beklemeye(wait) başladı.
- Oluşturulan her bir alt işlem exec ile yürütmesi gereken aracı işleme aldı.
- İlk işlemin stdout yani çıktıları pipe'nin yazma ucuna gönderildi.
- Pipe kendisine gönderilen veriyi okuma ucuna bağlı olan ikinci alt işlemin stdin yani girdisine iletti.
- Pipe üzerinden girdi alan ikinci işlemimiz, verileri yürütmekte olduğu araca argüman olarak verdi. (Her araç girdileri doğrudan argüman olarak kullanmayabilir. İleride xargs konusunda bu durumdan bahsedeceğiz.)
- İkinci işlem aldığı verileri işleyip özellikle herhangi bir yere yönlendirilmediği için varsayılan durum olan mevcut konsola çıktıyı gönderdi. Artık pipe üzerinde görevlerini tamamlayan işlemler kapanarak, beklemekte olan ana işleme kapandıklarını iletti.

Pipe da wait yani bekleme olduğu için işlem ikamesine göre pipe daha yavaştır.

![I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled%201.png](I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled%201.png)

Bölümün başındaki açıklamada pipe kavramının hız kattığından ve işlemleri paralel olarak yürüttüğünden bahsettik. İşlemleri paralel olarak yürüttüğünü ilerleyen kısımlarda daha net göreceğiz ancak şimdi neden pipe kullanımının bize hız sağladığına yakından bakalım. Bir önceki örnekte pipe operatörünü kullanarak gerçekleştirdiğimiz işlemi, çıktıları geçici bir dosyaya yönlendirerek ve bu dosyanın okunmasını sağlayarak da gerçekleştirebilirdik.

```bash
└─$ ls > /tmp/akis ; grep "lib" < /tmp/akis
lib
lib32
lib64
libexec
libx32
```

Örneğimizde `ls` komutunun çıktılarını "akis" isminde geçici bir dosyaya aktarıp, `grep` komutu tarafından bu geçici dosyanın okunmasını sağladık. İşimizi görmüş olsa da bu yöntem özellikle pek çok aracın peş peşe bağlantılı şekilde kullanılması esnasında hem **hız** hem de **uygulanabilirlik** açısından pek makul bir yaklaşım değildir. 

**Hız açısından verimli değildir çünkü;** çıktıları yazdırdığımız ve okuduğumuz dosya disk üzerinde yer alır. Dolayısıyla işlemler sırasında verilerin diske yazılıp diskten okunması gerekir. Bu durumun aksine pipe kullandığımızda tüm veriler bellek(RAM) üzerinden yüksek hızla tek seferde aktarılır. Pipe, diski kullanmadığı için geçici hafıza üzerinden yüksek hızlı veri aktarımı mümkün olur. 

**Uygulanabilirlik açısından makul değildir çünkü;** dosya isimlerinin yazımı ve doğru sıralama ile yönlendirilmesi pipe kullanımına oranla çok daha zahmetlidir. Bu durumum özellikle ikiden fazla işlemin birbirine bağlandığı durumlarda karmaşaya neden olur. Aşağıdaki çıktıları inceleyerek nasıl bir karmaşaya neden olabileceğini öngörebilirsiniz.

```bash
└─$ ls | grep "lib" | rev
bil
23bil
46bil
cexebil
23xbil
└─$ ls > /tmp/akis ; grep "lib" </tmp/akis > /tmp/grep_out ; rev < /tmp/grep_out
bil
23bil
46bil
cexebil
23xbil
```

![I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/sema_(1)_(4).png](I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/sema_(1)_(4).png)

![I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled%202.png](I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Untitled%202.png)

## Pipe Kullanım Amacı ve Pipeline Kavramı

Şu ana kadar ele aldığımız örnekler pipe kullanımı için son derece uyumlu çalışabilecek araçlar üzerinden oluşturulduğu için sorunsuzca tamamlandı. Daha fazla ilerlemeden önce bu noktada hatalı pipe kullanımından doğabilecek olası problemleri de kısaca ele alarak pipe yapısını doğru şekilde kavramaya çalışalım.

Veri aktarımında bulunmak istediğimiz işlemleri peşi sıra pipe çubuğu ile ayırdığımızda "pipeline" olarak geçen birbirine bağımlı bir "boru hattı" oluşturmuş oluruz. Bu hattı tıpkı sıvı gibi materyalleri aktaran basit boru hatları gibi düşünebiliriz. Eğer hattın bir noktasında tıkanma ya da kesinti olursa ilgili materyal başlangıç noktasından bitiş noktasına ulaştırılamaz. 

Pipeline üzerindeki işlemler arasında pipe ile veri aktarımı yaptığımız tüm araçlar, hat üzerinde bulundukları konuma göre çıktıları okuma ya da çıktı üretme durumundadır. Aksi halde pipe olarak geçen aktarım borusu tıkanıp işlemi sonlandıracaktır. Örneğin ilk komut sorunsuzca çıktı üretiyor ancak ikinci komut bu çıktıları okumuyorsa ilk işlem tıkanır. Benzer şekilde ilk komut çıktı üretmiyorsa ikinci komut okuma yaparak çalışıyorsa ikinci komut da tıkanarak çalışmaz. Her iki durum da pipeline yani boru hattının tıkanıp çalışmamasına neden olur. Bu sebeple çıktıları üretecek ve çıktıları okuyacak olan işlemlerin birbirine uyumlu şekilde seçilmesi çok önemlidir. 

Pipeline kullanım amacı yani peşi sıra birden fazla işlemi paralel olarak çalıştırıp çıktılarını birbirine bağlamayı yalnızca çok katmanlı bir problem çözümü için tercih etmemiz gerekir. Unix felsefesi gereği araçlar tek bir işi en iyi şekilde yerine getirmeli ve gerektiğinde girdi alıp okunaklı çıktılar üretebilmelidir. Zaten pipe özelliği, işini çok iyi yapan birden fazla aracı tek bir karmaşık sorunu çözmek üzere ortak olarak kullanabilmemiz içindir. İhtiyaçlarımıza göre, basit işlevleri yerine getiren girdileri okuyan ve çıktılar üretebilen araçların kombinasyonu ile neredeyse tüm ihtiyaçlarımızı karşılayabilen pipeline çözümleri geliştirebiliriz. Pipeline üzerinde yer alan işlemler birbiriyle uyumlu olduğu sürece, paralel olarak çalıştırıldıkları ve veri aktarımı eş zamanlı yapıldığı için son derece hızlı çalışırlar.

Detaylarına değinmeyecek olsak da hazır yeri gelmişken unix felsefesini de aşağıdaki şekilde özetleyebiliriz;

- Tek bir işi en iyi şekilde yapan araçlar geliştirilmedir. Mevcut araçlara yeni işleri yapabilmesi için özellik eklemek yerine bu işi yapabilen yeni araçlar geliştirilmelidir.
- Geliştirilen araçlar birbiri ile bağlantılı şekilde çalışabilmelidir. Yani araçlar çıktı üretip, gerektiğinde başka araçların çıktılarını okuyup işleyebilmelidir. Bu sebeple üretilen çıktılar okunaklı biçimde olmalıdır. Gerekmedikçe sütunlu tablolar şeklinde ya da ikili formatta olmamalıdır.
- Genel olarak metin akışlarını işleyebilecek yapıda araçlar geliştirilmelidir. Çünkü metin ifadeleri evrensel şekilde araçlar tarafından üretilebilen ve girdi olarak alınıp işlenebilen veri biçimidir.

Tüm bu felsefe bizlere, son derece esnek ve güçlü araç kombinasyonları oluşturarak kompleks problemleri dahi kolayca çözümleyebilme olanağı tanır. Biz uzun uzadıya değinmedik ancak, bahsi geçen unix felsefesinin detaylarını ayrıca araştırmanızı da şiddetle tavsiye ederim. 

Çıktı üretme ve üretilen çıktıların okunması noktasında uyumlu araçların tercih edilmesi gerektiğini vurguladık. Bu noktada dikkat edilmesi gereken husus; her araç bir önceki işlemden gelen girdileri argüman olarak işlemeyebileceğidir. Yani her araç stdin kısmından okuduklarını aracın argümanı olarak kullanmayabilir. Normalde unix felsefesi gereği araçların tek bir iş yapıp onu en iyi şekilde yapması ve kullanıcıları interaktif kullanıma zorlamaması gerekir. Yani hatalı ve hatasız çıktılar üretmesi ve argümanlarını girdiden alabiliyor olması gerekir. Yine de her araç argümanlarını girdiden almayabilir. Bu durum pipe kullanımı ile araçların bağlantılı şekilde çalışmasına engel oluşturur. İşte tam da bu noktada xargs aracını çözüm için kullanabiliriz. 

[Xargs](I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%2047bf5328e25a4296b35e5581150fa3de/Xargs%203ea3cba6d4c342eabde62fcdf2d2a964.md)

## Hatalı ve Hatasız Çıktıların Pipe ile Yönlendirilmesi

Eğer standart çıktılarla birlikte hatalı çıktıların da bir sonraki komutun girdisi olarak kullanılmasını istersek pipe(`|`) işaretinden sonra ampersant(`&`) işaretini `|&` şeklinde eklememiz yeterli. Aslında bu kullanım `2>&1 |` kullanımının kısaltmasıdır. Yani her iki kullanım ile de aynı sonucu elde etmek mümkündür.

Örnek için daha önce oluşturduğumuz hatalı ve hatasız çıktı üreten betik dosyamızı tekrar kullanabiliriz. Bu betiği çalıştırıp hatalı ve hatasız çıktıları hem kısa hem de uzun kullanım metodu ile aktarmayı deneyelim.

 `|&` kullanımı:

```bash
└─$ komut |& cat > sonuc.txt
└─$ cat sonuc.txt
Sorunsuz bir çıktı
betik.sh: line 2: asdf: command not found
taylan
ls: cannot access '-': No such file or directory
Sorunsuz başka bir çıktı daha
```

`2>&1 |` kullanımı:

```bash
└─$ komut |& cat > sonuc2.txt
└─$ cat sonuc2.txt
Sorunsuz bir çıktı
betik.sh: line 2: asdf: command not found
taylan
ls: cannot access '-': No such file or directory
Sorunsuz başka bir çıktı daha
```

Eğer "yönlendirmeler" konusunu iyi bir biçimde kavradıysanız yukarıdaki her iki örnek de sizlere yeterince açık gelecektir. Burada hatalı çıktıları da hatasızların yönlendirildiği adres olan pipe'a yönlendirmiş olduk sadece. Normalde pipe yalnızca hatasız çıktıları aktarır ancak bu gibi yönlendirmeler sayesinde istediğimiz türdeki verinin aktarılmasını sağlamamız da mümkündür. Örneğin yalnızca hatasız çıktıları da pipe üzerinden aktarabiliriz.

## Hatasız Çıktıların Pipe ile Yönlendirilmesi

Hatasız çıktıları pipe ile aktarmak üzere kullanabileceğimiz birkaç yapı örneği;

```bash
komut 2>&1 >/dev/null | cat > hatalılar.txt

komut 2> /dev/fd/1 1> /dev/null | cat > hatalılar.txt

komut 2> /dev/stdout 1> /dev/null | cat > hatalılar.txt

komut 3>&1 1>&2 2>&3 | cat > hatalılar.txt
```

Kısaca açıklayacak olursak;

**İlk örnek:** hatalı çıktıyı hatasız olanların yönlendirildiği adrese yani stdout'a yönlendiriyoruz. Daha sonra hatasız çıktının da /dev/null dosyasına gönderilerek yok olmasını sağlıyoruz. Bu sayede stdout'u okuyan pipe yalnızca hatalı çıktıyı aktarıyor.

**İki ve üçüncü örnek:** Aslında ilk örneğin dosya isimleri üzerinden ifade edilmiş halidir. Hatasız yani standart olan 1 numaralı dosya tanımlayıcısı "***/dev/fd/1***" ya da "***/dev/stdout***" dosyaları ile de ifade edilebilir. Bu kullanım kombinasyonları isteğe göre çok çeşitlilik gösterebilir. Neticede özel dosya ismi ya da dosya tanımlayıcı numarası aynı işe hizmet etmekledir. 

**Dördüncü örnek:** 3 numaralı dosya tanımlayıcısı açıp bunu 1 numaralıya yani stdout adresine yönlendiriyoruz. Daha sonra 1 numaralı dosya tanımlayıcıyı da 2 numaralı dosya tanımlayıcısına yani stderr adresine yönlendiriyoruz. Son olarak 2 numaralı dosya tanımlayıcısını, stdout adresine yönlendirilmiş olan 3 numaralı dosya tanımlayıcıya yönlendiriyoruz. Bu sayede hatasız çıktılar konsola basılırken, hatalı çıktılar pipe ile yönlendirilmiş oluyor. Yani normalde pipe kullanımında gerçekleşen işlemin tam tersi gerçekleşmiş olur.

Bu yöntemlerin hepsi yönlendirme bölümünde ele aldığımız temel bilgiler ile uygulanabilecek alternatifler. Yönlendirme biçimi tamamen sizin hayal gücünüze kalmış. Buradaki esas nokta hatasız çıktıları bloke edip yalnızca hatalı olan çıktıları bir sonraki işleme iletmektir.

## Çıktıların Dosyaya Ve Konsola Aktarılması | T-Pipe

Pipe'ın esasen tek yönlü aktarım yapan bir borunun soyutlanmış hali olduğunu öğrendik. Bu yapıyı kullanarak hatalı ve hatasız çıktılarımızı istediğimiz işleme aktarabiliyoruz. Bu oldukça kullanışlı olsa da ihtiyaç halinde verilerimizi hem bir sonraki işleme aktarmak hem de herhangi bir dosyaya yazdırmak isteyebiliriz. Bize bu imkanı `tee` aracı sunar. Hatta "boru" soyutlamasına uygun şekilde bu araç "T-boru" yani "T-pipe" olarak da ifade edilebilir.(`tee` aracı haricinde benzer işlevi yapan farklı araçlar da bulunabilir, ancak en yaygın kullanıma sahip olanı `tee`'dir. T-pipe resmi bir ifade olmasa da `tee` aracını çağrıştırdığı için belirtmek istedim.)

`tee` aracı kendisine iletilen verileri stdout yani standart çıktıya ve belirtilmişse bir dosyaya yazar. Öncesinde ve sonrasında pipe ile kullanılınca arada T boru görevi görerek dosyalara ve işlemlere aynı verilerin aktarılmasını sağlar.

Hemen basit bir örnek ile bir işlemin çıktılarını hem bir sonraki işleme hem de konsol ekranımıza bastıralım.

```bash
└─$ ls /usr | tee liste.txt | rev
nib
semag
edulcni
bil
└─$ cat liste.txt
bin
games
include
lib
```

Görebildiğiniz gibi, `tee` aracı `ls` komutunun çıktısını "*liste.txt"* dosyasına yazdırıp bir sonraki işlem olan `rev` komutuna da iletmiş oldu. Yalnızca dosyalara yönlendirme işlemi de yapmak zorunda değiliz. Eğer komut ikamesi özelliğini kullanırsak aynı veriyi birden fazla işleme aktarmamız da mümkündür.

Örneğin mevcut log dosyalarını hem gzip ile hem de bzip ile sıkıştırmak ve sıkıştırılan dosya isimlerini cat komutu ile bir dosyaya yazdırmayı deneyelim.

Ayrıca `tee` aracı -a seçeneğini kullanmadığımız sürece hedef dosya içeriğinin üzerine yazar. 

```bash
└─$ echo "test" | tee cıktı.txt | cat
test
└─$ echo "test" | tee cıktı.txt | cat
test
└─$ cat cıktı.txt
test
```

Eğer veriler dosya sonuna eklensin istiyorsak `—append` yani ekleme anlamına gelen `-a` seçeneğini kullanmamız gerek.

```bash
└─$ echo "test" | tee -a cıktı.txt | cat
test
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "test" | tee -a cıktı.txt | cat
test
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat cıktı.txt
test
test
test
```

## Pipe İle Çalıştırılan İşlemlerin Zamanını Ölçmek

Pipe kullanırken araçlar alt işlemde paralel olarak çalıştırıldıkları için zamanlamayı doğru şekilde ölçmek zor olabilir. Boru hattı için zaman sonucu, en son sonlandırılan işlem üzerinden yansıtılır. Bu durumu gözlemlemek adına aşağıdaki basit örneğe göz atabilirsiniz

```bash
└─$ time ( sleep 5 | sleep 3)

real    0m5.008s
user    0m0.000s
sys     0m0.000s
```

Çıktılardan da anlaşıldığı üzere `sleep` komutlarının her ikisi de paralel olarak yürütülerek en son kapanan işlem yani `sleep 5` işleminin zamanı çıktıya yansıtılmış.

Yerleşik olarak kullanılan time yani zaman komutunu eğer -p seçeneği ile kullanırsak POSIX uyumlu şekilde çıktı elde ederiz. Ayrıca TIMEFORMAT değişkeni üzerinden zaman formatının biçimini de değiştirmemiz mümkündür.

## Pipefail Ortam Özelliğinin Etkisi

Normalde pipeline üzerindeki en son yani en sağdaki işlemin çıkış durumu tüm pipeline üzerindeki işlemlerin çıkış durumu gibi yansıtılır. 

```bash
└─$ true | false | true
└─$ echo $?
0
└─$ true | true | false
└─$ echo $?
1
└─$ false | false | true
└─$ echo $?
0
```

Eğer en sağdaki işlem yerine en son hata veren işlemin çıkış durumunu almak istersek `set` ile `pipefail` ortam özelliğini aktif edebiliriz. Bu özellik sayesinde tüm komutlar 0 yani sorunsuz çıkış kodu döndürmediği sürece en son çalıştırılan hatalı işlemin kodu çıkış kodu olarak yansıtılır. Bu durumu gözlemlemek adına doğrudan `exit` ile istediğimiz çıkış kodlarının döndürülmesini sağlayabiliriz. Öncelikle `pipefail` özelliği aktif değilken, daha sonra aktifleştirip hangi işlemin çıkış kodunun pipeline çıkış kodu olarak yansıtıldığını görelim.

```bash
└─$ exit 5 | exit 10 | exit 0
└─$ echo $?
0
└─$ exit 5 | exit 0 | exit 10
└─$ echo $?
10
└─$ set -o pipefail
└─$ exit 5 | exit 10 | exit 0
└─$ echo $?
10
└─$ exit 5 | exit 0 | exit 0
└─$ echo $?
5
└─$ exit 0 | exit 0 | exit 0
└─$ echo $?
0
```

Ayrıca daha önce bahsetmiş olduğumuz "mantıksal olumsuzlama" yöntemini pipeline üzerinde de kullanmamız mümkündür. Pipline başında ünlem işareti kullanarak çıkış durumunu mantıksal olumsuzu ile değiştirebiliriz. Mantıksal olmusuzlamada 0 haricindeki tüm çıkış değerlerin olumsuzu "0" olarak, "0" değerinin olumsuzu ise "1" olarak yansıtılır. 

```bash
└─$ true | false
└─$ echo $?
1
└─$ ! true | false
└─$ echo $?
0
└─$ false | true
└─$ echo $?
0
└─$ ! false | true
└─$ echo $?
1
```

## Lastpipe Ortam Özelliğinin Etkisi

Pipe üzerindeki işlemlerin ayrı alt kabuklarda yürütüldüğünü biliyoruz. Her işlem yeni bir alt kabukta çalıştığı için pipeline sırasındaki işlemlerin değişken değerleri korunmaz. Değişken değerleri korunmadığı için bu değerleri okumaya çalışan sonraki işlemler doğru şekilde çalışmayabilir.

Bu konu "işlem ikamesi" ve "isimli pipe" ile ilişkili olduğu için tekrar dönüş yap. İşlem kavramını ve alt işlem oluştururken hangi ortam özelliklerinin alt kabuğa aktarıldığını da kesin olarak kavra.

Bu durumu aşağıdaki basit örnek üzerinden gözlemleyebiliriz.

Bash bu soruna çözüm olarak 4.2 sürümünden beri lastpipe ortam özelliğini sunuyor.

## İsimlendirilmiş Pipe(named pipe | FIFO )

Daha önce de bahsettiğimiz şekilde pipe üzerinde geçerli olan "ilk giren ilk çıkar/first in first out" yapısı gereği "isimli pipe" genellikle fifo olarak ifade ediliyor. Yani "named pipe" yerine kısaca "fifo" şeklinde ifade edildiğini de sıklıkla görebilirsiniz. 

Bildiğiniz üzere, isimsiz pipe tek kullanımlıktır ve iki işlem arasında tek yönlü aktarım yapabilir. Önceki işlemden aldığı verileri bir sonraki işlemin girdisi olarak iletir ve tüm işlemler tamamlanınca yok edilir. Eğer ihtiyacımız olan şey belirli bir süre boyunca açık kalan ve birden fazla işlem tarafından yazılıp okunabilen bir boru hattı oluşturmaksa fifo yapısını kullanabiliyoruz.

Eğer isimlendirilmiş boru hattı yani fifo kullanırsak disk üzerinde gerçekte var olamayan sanal bir dosya oluşturulup girdi ve çıktılar bu dosya üzerinden aktarılabilir. İşlemler FIFO aracılığıyla veri alışverişinde bulunurken, çekirdek tüm verileri dosya sistemine yazmadan dahili olarak iletir. Bu nedenle, FIFO özel dosyasının dosya sisteminde gerçek bir içeriği yoktur; dosya sistemi girdisi yalnızca bir referans noktası olarak hizmet eder. Böylece işlemler, dosya sistemindeki bir adı kullanarak boruya erişebilirler. Birden çok işleme aynı pipe hattını vermek için bu yöntem kullanılır. 

Uygulamalar üzerinden kullanım amacını ve yapısını daha net kavrayabiliriz.

Öncelikle isimli bir pipe oluşturmak için mkfifo a

mkfifo

mknod

bu kavramların analışması için dosya tablosu inode gibi kavramları daha net kavra örneğin 

## Fifo Dosyaların Kullanılması

Open two shells. In shell 1 do this:

```
mkfifo fifo
exec < fifo

```

In shell 2 do this:

```
exec 3> fifo;
echo 'echo test' >&3

```