# Copy of KAYNAK

## Bölüm III: Yönlendirmeler

Bash'de yeniden yönlendirmelerle çalışmak, her şeyin dosya tanımlayıcılarını değiştirmekle ilgili olduğunu fark ettiğinizde gerçekten kolaydır. Bash başladığında, üç standart dosya tanımlayıcısını açar: stdin (dosya tanımlayıcısı 0), stdout (dosya tanımlayıcısı 1) ve stderr (dosya tanımlayıcısı 2). Daha fazla dosya tanımlayıcısı (3, 4, 5, ... gibi) açabilir ve kapatabilirsiniz. Dosya tanımlayıcılarını da kopyalayabilirsiniz. Ve onlara yazabilir ve onlardan okuyabilirsiniz.

Dosya tanımlayıcıları her zaman bir dosyaya işaret eder (kapalı olmadıkları sürece). Genellikle bash üç dosya tanımlayıcısını da başlattığında, stdin, stdout ve stderr, terminalinizi gösterir. Giriş, terminale yazdıklarınızdan okunur ve her iki çıkış terminale gönderilir.

Terminalinizin olduğunu varsayarsak, `/dev/tty0` bash başladığında dosya tanımlayıcı tablo şöyle görünür:

![https://catonmat.net/images/bash-redirections/initial-fd-table.png](https://catonmat.net/images/bash-redirections/initial-fd-table.png)

Bash bir komutu çalıştırdığında, `man 2 fork`tüm dosya tanımlayıcılarını ana süreçten devralan bir çocuk süreci (bkz. ) Çatallar , ardından belirttiğiniz yeniden yönlendirmeleri ayarlar ve komutu çalıştırır (bkz. `man 3 exec`).

Bash yeniden yönlendirmelerinde profesyonel olmak için tek yapmanız gereken, yeniden yönlendirmeler gerçekleştiğinde dosya tanımlayıcılarının nasıl değiştiğini görselleştirmektir. Grafik çizimler size yardımcı olacaktır.

**1. Bir komutun standart çıktısını bir dosyaya yönlendirin**

```
$ command> dosya

```

Operatör `>`, çıktı yeniden yönlendirme operatörüdür. Bash önce dosyayı yazmak için açmaya çalışır ve başarılı olursa stdout'unu `command`yeni açılan dosyaya gönderir . Dosyayı açamazsa, tüm komut başarısız olur.

Yazmak `command >file`, yazmakla aynıdır `command 1>file`. Numara `1`standart çıkış için dosya tanıtıcı numarasıdır Stdout'a, kısaltmasıdır.

Dosya tanımlayıcı tablosu nasıl değişir. Bash, `file`dosya tanımlayıcısı 1'i açar ve işaret eden dosya tanımlayıcısıyla değiştirir `file`. Dolayısıyla, bundan sonra 1 numaralı dosya tanımlayıcısına yazılan tüm çıktılar şu adrese yazılacak `file`:

![https://catonmat.net/images/bash-redirections/redirect-stdout.png](https://catonmat.net/images/bash-redirections/redirect-stdout.png)

Genel olarak `command n>file`, dosya tanımlayıcısını ' `n`a yönlendirecek şekilde yazabilirsiniz `file`.

Örneğin,

```
$ ls> dosya_listesi

```

`ls`Komutun çıktısını `file_list`dosyaya yeniden yönlendirir .

**2. Bir komutun standart hatasını bir dosyaya yönlendirin**

```
$ command 2> dosya

```

Burada bash, stderr'i dosyaya yönlendirir. Sayı `2`, stderr anlamına gelir.

Dosya tanımlayıcı tablosu şu şekilde değişir:

![https://catonmat.net/images/bash-redirections/redirect-stderr.png](https://catonmat.net/images/bash-redirections/redirect-stderr.png)

Bash `file`yazma için açılır , bu dosyanın dosya tanımlayıcısını alır ve dosya tanımlayıcısı 2'yi bu dosyanın dosya tanımlayıcısıyla değiştirir. Artık stderr'e yazılan her şey dosyaya yazılıyor.

**3. Hem standart çıktıyı hem de standart hatayı bir dosyaya yeniden yönlendirin**

```
$ command &> dosya

```

Bu tek astar kullanmaktadır `&>`stdout'u ve stderr'yi - - her iki çıkış akışı yeniden yönlendirmek için operatör `command`için `file`. Bu, her iki akışı da aynı hedefe hızlı bir şekilde yeniden yönlendirmek için bash'ın kısayoludur.

Bash her iki akışı da yeniden yönlendirdikten sonra dosya tanımlayıcı tablosu şöyle görünür:

![https://catonmat.net/images/bash-redirections/redirect-stdout-stderr.png](https://catonmat.net/images/bash-redirections/redirect-stdout-stderr.png)

Gördüğünüz gibi hem stdout hem de stderr şimdi işaret ediyor `file`. Yani stdout ve stderr'e yazılan her şey yazılır `file`.

Her iki akışı da aynı hedefe yönlendirmenin birkaç yolu vardır. Her akışı birbiri ardına yeniden yönlendirebilirsiniz:

```
$ command> dosya 2> & 1

```

Bu, her iki akışı bir dosyaya yeniden yönlendirmenin çok daha yaygın bir yoludur. İlk olarak stdout'a yeniden yönlendirilir `file`ve ardından stderr, stdout ile aynı olacak şekilde çoğaltılır. Yani her iki akış da işaret ediyor `file`.

Bash birkaç yönlendirme gördüğünde, onları soldan sağa doğru işler. Adımları inceleyelim ve bunun nasıl olduğunu görelim. Herhangi bir komutu çalıştırmadan önce bash'ın dosya tanımlayıcı tablosu şuna benzer:

![https://catonmat.net/images/bash-redirections/initial-fd-table.png](https://catonmat.net/images/bash-redirections/initial-fd-table.png)

Şimdi bash, ilk yönlendirmeyi işler `>file`. Bunu daha önce gördük ve şu noktayı gösteriyor `file`:

![https://catonmat.net/images/bash-redirections/redirect-stdout.png](https://catonmat.net/images/bash-redirections/redirect-stdout.png)

Sonraki bash ikinci yönlendirmeyi görür `2>&1`. Bu yönlendirmeyi daha önce görmemiştik. Bu, dosya tanımlayıcısı 2'yi dosya tanımlayıcısı 1'in bir kopyası olacak şekilde çoğaltır ve şunu elde ederiz:

![https://catonmat.net/images/bash-redirections/redirect-stdout-stderr.png](https://catonmat.net/images/bash-redirections/redirect-stdout-stderr.png)

Her iki akış adresine yeniden yönlendirildi `file`.

Ancak burada dikkatli olun! Yazı:

```
komut> dosya 2> & 1

```

Yazmakla aynı şey değil:

```
$ command 2> & 1> dosya

```

Bash'de yönlendirmelerin sırası önemlidir! Bu komut yalnızca standart çıktıyı dosyaya yönlendirir. Stderr yine de terminale yazdıracaktır. Bunun neden olduğunu anlamak için adımlardan tekrar geçelim. Bu nedenle, komutu çalıştırmadan önce dosya tanımlayıcı tablosu aşağıdaki gibi görünür:

![https://catonmat.net/images/bash-redirections/initial-fd-table.png](https://catonmat.net/images/bash-redirections/initial-fd-table.png)

Şimdi bash, soldan sağa yönlendirmeleri işler. Önce görür, `2>&1`böylece stderr'i stdout'a kopyalar. Dosya tanımlayıcı tablosu şöyle olur:

![https://catonmat.net/images/bash-redirections/duplicate-stderr-stdout.png](https://catonmat.net/images/bash-redirections/duplicate-stderr-stdout.png)

Şimdi bash ikinci yönlendirmeyi görüyor `>file`ve stdout'u şuraya yönlendiriyor `file`:

![https://catonmat.net/images/bash-redirections/duplicate-stderr-stdout-stdout-file.png](https://catonmat.net/images/bash-redirections/duplicate-stderr-stdout-stdout-file.png)

Burada ne olduğunu görüyor musun? Stdout şimdi işaret ediyor, `file`ancak stderr hala terminali gösteriyor! Stderr'e yazılan her şey hala ekrana yazdırılıyor! Bu nedenle, yeniden yönlendirme sırasına çok çok dikkat edin!

Ayrıca bash'ta şunu yazdığına dikkat edin:

```
$ command &> dosya

```

Şununla tamamen aynıdır:

```
$ command> & dosya

```

Ancak ilk biçim tercih edilir.

**4. Bir komutun standart çıktısını atın**

```
$ komut> / dev / null

```

Özel dosya `/dev/null`, kendisine yazılan tüm verileri atar. Yani burada yaptığımız şey stdout'u bu özel dosyaya yönlendirmek ve atılıyor. Dosya tanımlayıcı tablonun bakış açısından şöyle görünüyor:

![https://catonmat.net/images/bash-redirections/redirect-stdout-dev-null.png](https://catonmat.net/images/bash-redirections/redirect-stdout-dev-null.png)

Benzer şekilde, önceki tek satırları birleştirerek, hem stdout hem de stderr'i şu şekilde atabiliriz:

```
$ command> / dev / null 2> & 1

```

Ya da sadece basitçe:

```
$ command &> / dev / null

```

Bu başarı için dosya tanımlayıcı tablosu şuna benzer:

![https://catonmat.net/images/bash-redirections/redirect-stdout-stderr-dev-null.png](https://catonmat.net/images/bash-redirections/redirect-stdout-stderr-dev-null.png)

**5. Bir dosyanın içeriğini bir komutun stdinine yönlendirin**

```
$ command & lt; dosya

```

Burada bash, herhangi bir komutu çalıştırmadan önce dosyayı okumak için açmaya çalışır. Dosyayı açma başarısız olursa, bash hata vererek çıkar ve komutu çalıştırmaz. Dosyayı açma başarılı olursa, bash komut için stdin dosya tanımlayıcısı olarak açılan dosyanın dosya tanımlayıcısını kullanır.

Bunu yaptıktan sonra dosya tanımlayıcı tablo şu şekilde görünür:

![https://catonmat.net/images/bash-redirections/redirect-stdin.png](https://catonmat.net/images/bash-redirections/redirect-stdin.png)

İşte bir örnek. Bir değişkendeki dosyanın ilk satırını okumak istediğinizi varsayalım. Bunu basitçe yapabilirsiniz:

```
$ okuma -r satır <dosya

```

Bash'in yerleşik `read`komutu, standart girişten tek bir satırı okur. Girdi yeniden yönlendirme operatörünü kullanarak, `<`satırı dosyadan okuyacak şekilde ayarladık.

**6. Bir grup metni bir komutun stdinine yönlendirin**

```
$ komut & lt; & lt; EOL
sizin
çok hatlı
Metin
gider
buraya
EOL
```

Burada burada belge yeniden yönlendirme operatörünü kullanıyoruz `<<MARKER`. Bu operatör, bash'a yalnızca içeren bir satır bulunana kadar girişi stdin'den okumasını söyler `MARKER`. Bu noktada bash, o ana kadar okunan tüm girdileri komutun stdinine aktarır.

İşte yaygın bir örnek. Panoya bir grup URL kopyaladığınızı ve `http://`bunların bir kısmını kaldırmak istediğinizi varsayalım . Bunu yapmanın hızlı bir yolu şu olacaktır:

```
$ sed 's | http: // ||' << EOL
http://url1.com
http://url2.com
http://url3.com
EOL
```

Burada, bir URL listesinin girdisi, girdiden ayrılan `sed`komuta yönlendirilir `http://`.

Bu örnek şu çıktıyı üretir:

```
url1.com
url2.com
url3.com
```

**7. Tek bir metin satırını bir komutun stdinine yönlendirin**

```
$ komut & lt; & lt; & lt; "foo bar baz"

```

Örneğin, panonuzdaki metni stdin olarak hızlı bir şekilde bir komuta geçirmek istediğinizi varsayalım. Şunun gibi bir şey yapmak yerine:

```
$ echo "pano içeriği" | komut

```

Şimdi yazabilirsiniz:

```
$ komut & lt; & lt; & lt; "pano içeriği"

```

Bu numara öğrendiğimde hayatımı değiştirdi!

**8. Tüm komutların stderrini sonsuza kadar bir dosyaya yönlendirin**

```
$ exec 2> dosya
$ command1
$ command2
$ ...
```

Bu tek satırlık yerleşik `exec`bash komutunu kullanır . Ondan sonra yeniden yönlendirmeler belirtirseniz, sonsuza kadar sürer, yani siz onları değiştirene veya betikten / kabuktan çıkana kadar.

Bu durumda `2>file`yeniden yönlendirme, mevcut kabuğun stderrini `file`. Bu yeniden yönlendirmeyi kurduktan sonra komutları çalıştırmak, hepsinin stderr'ini dosyaya yeniden yönlendirecektir. Komut dosyasında meydana gelen tüm hataların eksiksiz bir günlüğüne sahip olmak istediğiniz, ancak `2>file`her komuttan sonra belirtmek istemediğiniz durumlarda gerçekten yararlıdır !

Genel `exec`olarak bir komutun isteğe bağlı bir argümanını alabilir. Belirtilmişse, bash kendisini komutla değiştirir. Yani aldığınız şey sadece çalışan komuttur ve artık kabuk kalmaz.

**9. Özel bir dosya tanımlayıcı kullanarak okumak için bir dosya açın**

```
$ exec 3 & lt; dosyası

```

Burada `exec`komutu tekrar kullanıyoruz ve `3<file`ona yönlendirmeyi belirtiyoruz. Bunun yaptığı şey, dosyayı okumak için açar ve açılan dosya tanımlayıcısını kabuğun dosya tanımlayıcı numarasına atar `3`. Dosya tanımlayıcı tablosu artık şuna benzer:

![https://catonmat.net/images/bash-redirections/custom-fd.png](https://catonmat.net/images/bash-redirections/custom-fd.png)

Artık dosya tanımlayıcıdan şu şekilde okuyabilirsiniz `3`:

```
$ okuma -u 3 satır

```

Bu, az önce fd olarak açtığımız dosyadan bir satır okur `3`.

Veya `grep`dosya tanımlayıcısı gibi normal kabuk komutlarını kullanabilirsiniz `3`:

```
$ grep "foo" <& 3

```

Burada olan şey, dosya tanımlayıcısının dosya tanımlayıcısına `3`kopyalanmasıdır `1`- grep'in stdin. Dosya tanımlayıcısını okuduktan sonra tükendiğini ve kullanmak için onu kapatıp yeniden açmanız gerektiğini unutmayın. (Bash'de bir fd'yi geri alamazsınız.)

Fd'yi kullanmayı bitirdikten sonra `3`, şu şekilde kapatabilirsiniz:

```
$ exec 3> & -

```

Burada dosya tanımlayıcı `3`kopyalanır `-`, bu da bash'ın "bu fd'yi kapat" demenin özel bir yoludur.

**10. Özel bir dosya tanımlayıcı kullanarak yazmak için bir dosya açın**

```
$ exec 4> dosya

```

Burada bash'a dosyayı yazmak için açmasını ve ona numara atamasını söylüyoruz `4`. Dosya tanımlayıcı tablosu şuna benzer:

![https://catonmat.net/images/bash-redirections/custom-fd-writing.png](https://catonmat.net/images/bash-redirections/custom-fd-writing.png)

Gördüğünüz gibi dosya tanımlayıcıların sırayla kullanılması gerekmiyor, 0'dan 255'e kadar istediğiniz herhangi bir dosya tanımlayıcı numarasını açabilirsiniz.

Şimdi dosya tanımlayıcısına yazabiliriz `4`:

```
$ echo "foo"> & 4

```

Ve dosya tanımlayıcısını kapatabiliriz `4`:

```
$ exec 4> & -

```

Özel dosya tanımlayıcılarla nasıl çalışılacağını öğrendikten sonra artık çok basit!

**11. Hem yazmak hem de okumak için bir dosya açın**

```
$ exec 3 <> dosyası

```

Burada bash'ın elmas operatörünü kullanıyoruz `<>`. Elmas operatörü hem okuma hem de yazma için bir dosya tanımlayıcı açar.

Örneğin, bunu yaparsanız:

```
$ echo "foo bar"> dosya # "foo bar" dizesini "dosya" dosyasına yaz.
$ exec 5 <> dosya # rw için "dosya" açın ve fd 5 atayın.
$ read -n 3 var <& 5 # fd 5'ten ilk 3 karakteri okur.
$ echo $ var
```

Bu `foo`, dosyadan ilk 3 karakteri okuduğumuzda çıktı verecektir .

Şimdi dosyaya bazı şeyler yazabiliriz:

```
$ echo -n +> & 5 # 4. konuma "+" yazın.
$ exec 5> & - # kapat fd 5.
$ cat dosyası
```

Bu, `foo+bar`biz `+`dosyada 4. pozisyondaki karakteri yazdığımızda çıktı verecektir .

**12. Çıktıyı birden çok komuttan bir dosyaya gönderin**

```
$ (command1; command2)> dosya

```

Bu tek astar `(commands)`, komutları bir alt kabuk çalıştıran yapıyı kullanır . Alt kabuk, mevcut kabuk tarafından başlatılan bir alt süreçtir.

Yani burada olan şey, komutlar `command1`ve `command2`alt kabukta çalıştırılıyor ve bash çıktılarını adresine yönlendiriyor `file`.

**13. Kabuktaki komutları bir dosya aracılığıyla yürütün**

İki mermi açın. Kabuk 1'de şunu yapın:

```
mkfifo fifo
exec <fifo
```

Kabuk 2'de şunu yapın:

```
exec 3> fifo;
echo 'yankı testi'> & 3
```

Şimdi shell 1'e bir göz atın `echo test`. Çalıştırılacak . Komut yazmaya devam edebilirsiniz `fifo`ve kabuk 1 onları çalıştırmaya devam edecektir.

İşte nasıl çalıştığı.

Kabuk 1'de `mkfifo`adı verilen bir kanal oluşturmak için komutu kullanırız `fifo`. Adlandırılmış bir kanal (FIFO olarak da adlandırılır), dosya sisteminin bir parçası olarak erişilmesi dışında normal bir boruya benzer. Okuma veya yazma için birden fazla işlemle açılabilir. İşlemler FIFO aracılığıyla veri alışverişinde bulunurken, çekirdek tüm verileri dosya sistemine yazmadan dahili olarak aktarır. Bu nedenle, FIFO özel dosyasının dosya sisteminde içeriği yoktur; dosya sistemi girişi yalnızca bir referans noktası görevi görür, böylece süreçler dosya sistemindeki bir ad kullanarak boruya erişebilir.

Daha sonra `exec < fifo`mevcut kabuğun stdinini ile değiştiririz `fifo`.

Şimdi kabuk 2'de adlandırılmış boruyu yazmak için açıyoruz ve ona özel bir dosya tanımlayıcı 3 atıyoruz. Daha `echo test`sonra, dosya tanımlayıcı 3'e yazıyoruz , bu da `fifo`.

Kabuk 1'in stdin'i bu boruya bağlı olduğu için onu yürütür! Gerçekten çok basit!

**14. bash aracılığıyla bir web sitesine erişin**

```
$ exec 3 <> / dev / tcp / www.google.com / 80
$ echo -e "GET / HTTP / 1.1 \ n \ n"> & 3
$ kedi <& 3
```

Bash, `/dev/tcp/host/port`dosyayı özel bir dosya olarak ele alır . Sisteminizde bulunması gerekmez. Bu özel dosya, bash aracılığıyla tcp bağlantılarını açmak içindir.

Bu örnekte, ilk olarak okuma ve yazma için dosya tanımlayıcı 3'ü açıp onu 80 numaralı bağlantı noktasına `/dev/tcp/www.google.com/80`bağlantı olan özel dosyaya yönlendiriyoruz `www.google.com`.

Daha `GET / HTTP/1.1\n\n`sonra 3. dosya tanımlayıcısına yazıyoruz . Ve sonra da kullanarak aynı dosya tanımlayıcısından yanıtı okuyoruz `cat`.

Benzer şekilde, `/dev/udp/host/port`özel dosya aracılığıyla bir UDP bağlantısı oluşturabilirsiniz .

İle `/dev/tcp/host/port`bile bash liman tarayıcıları gibi şeyler yazabilir!

**15. Çıktıyı yeniden yönlendirirken bir dosyanın içeriğinin üzerine yazılmasını önleyin**

```
$ set -o noclobber

```

Bu `noclobber`, mevcut kabuk için seçeneği açar. Noclobber seçeneği,> operatörüyle mevcut dosyaların üzerine yazmanızı engeller.

Çıktıyı var olan bir dosyaya yeniden yönlendirmeyi denerseniz, bir hata alırsınız:

```
$ program> dosya
bash: dosya: mevcut dosyanın üzerine yazılamaz
```

Dosyanın üzerine yazmak istediğinizden% 100 eminseniz, `>|`yeniden yönlendirme operatörünü kullanın :

```
$ program> | dosya

```

Bu, noclobber seçeneğini geçersiz kıldığı için başarılı olur.

**16. Standart girişi bir dosyaya yönlendirin ve standart çıktıya yazdırın**

```
$ command | tee dosyası

```

`tee`Komut süper kullanışlıdır. Bu bash'ın bir parçası değil ama sık sık kullanacaksınız. Bir girdi akışını alır ve hem standart çıktıya hem de bir dosyaya yazdırır.

Bu örnekte, komutun stdout'unu alır, onu dosyaya koyar ve stdout'a yazdırır.

İşte nasıl çalıştığına dair grafik bir örnek:

![https://catonmat.net/images/bash-redirections/tee.png](https://catonmat.net/images/bash-redirections/tee.png)

**17. Bir sürecin stdout'unu başka bir sürecin standart çıkışına gönder**

```
$ command1 | komut2

```

Bu basit bir boru bağlantısıdır. Eminim herkes buna aşinadır. Sadece eksiksiz olması için buraya ekliyorum. Sadece hatırlatmak için, bir boru stdout'u `command1`stdin of ile birleştirir `command2`.

Bir grafikle gösterilebilir:

![https://catonmat.net/images/bash-redirections/pipe.png](https://catonmat.net/images/bash-redirections/pipe.png)

Gördüğünüz gibi, command1 dosya tanımlayıcısına (stdout) gönderilen her şey, komut2'nin dosya tanımlayıcısı 0 (stdin) 'e bir boru yoluyla yeniden yönlendiriliyor.

İçinde borular hakkında daha fazla bilgi edinebilirsiniz `man 2 pipe`.

**18. Bir sürecin stdout ve stderr'ini başka bir sürecin standart çıkışına gönder**

```
$ command1 | & command2

```

Bu, 4.0'dan itibaren bash sürümlerinde çalışır. Yeniden `|&`yönlendirme operatörü, command1'in hem stdout'unu hem de stderr'ini bir boru üzerinden command2'nin stdin'ine gönderir.

Bash 4.0'ın yeni özellikleri yaygın olarak kullanılmadığından, aynısını yapmanın eski ve daha taşınabilir yolu şudur:

```
$ command1 2> & 1 | komut2

```

Dosya tanımlayıcılara ne olduğunu gösteren bir örnek:

![https://catonmat.net/images/bash-redirections/pipe-stdout-stderr.png](https://catonmat.net/images/bash-redirections/pipe-stdout-stderr.png)

İlk olarak command1'in stderr'i stdout'a yeniden yönlendirilir ve sonra command1'in stdout'u ile command2'nin stdin'i arasında bir boru kurulur.

**19. Dosya tanımlayıcılara isim verin**

```
$ exec {filew}> output_file

```

Adlandırılmış dosya tanımlayıcıları, bash 4.1'in bir özelliğidir. Adlandırılmış dosya tanımlayıcıları gibi görünür `{varname}`. Bunları normal, sayısal, dosya tanımlayıcıları gibi kullanabilirsiniz. Bash, dahili olarak ücretsiz bir dosya tanımlayıcı seçer ve ona bir ad atar.

**20. Yönlendirme sırası**

Yönlendirmeleri istediğiniz komutta herhangi bir yere koyabilirsiniz. Bu 3 örneğe bakın, hepsi aynı şeyi yapıyor:

```
$ echo merhaba> / tmp / örnek
$ echo> / tmp / örnek merhaba
$> / tmp / örnek echo merhaba
```

Bash'i sevmelisin!

**21. Standart çıkış ve stderr'yi değiştirin**

```
$ command 3> & 1 1> & 2 2> & 3

```

Burada ilk önce dosya tanımlayıcısı 3'ü stdout'un bir kopyası olacak şekilde çoğaltıyoruz. Sonra stdout'u stderr'nin bir kopyası olacak şekilde çoğaltıyoruz ve son olarak stderr'i, stdout olan 3. dosya tanımlayıcısının bir kopyası olacak şekilde çoğaltıyoruz. Sonuç olarak stdout ve stderr'i değiştirdik.

Her yeniden yönlendirmeyi resimlerle inceleyelim. Komutu çalıştırmadan önce, terminale işaret eden dosya tanımlayıcılarımız var:

![https://catonmat.net/images/bash-redirections/initial-fd-table.png](https://catonmat.net/images/bash-redirections/initial-fd-table.png)

Sonraki bash `3>&1`yeniden yönlendirmeyi ayarlar . Bu, dosya tanımlayıcısı 3'ü dosya tanımlayıcısı 1'in bir kopyası olacak şekilde oluşturur:

![https://catonmat.net/images/bash-redirections/fd3-copy-of-fd1.png](https://catonmat.net/images/bash-redirections/fd3-copy-of-fd1.png)

Sonraki bash `1>&2`yeniden yönlendirmeyi ayarlar . Bu, dosya tanımlayıcı 1'i dosya tanımlayıcı 2'nin bir kopyası yapar:

![https://catonmat.net/images/bash-redirections/fd1-copy-of-fd2.png](https://catonmat.net/images/bash-redirections/fd1-copy-of-fd2.png)

Sonraki bash `2>&3`yeniden yönlendirmeyi ayarlar . Bu, dosya tanımlayıcı 2'yi dosya tanımlayıcı 3'ün bir kopyası yapar:

![https://catonmat.net/images/bash-redirections/fd2-copy-of-fd3.png](https://catonmat.net/images/bash-redirections/fd2-copy-of-fd3.png)

İyi vatandaşlar olmak istiyorsak, artık gerekli olmadığı için dosya tanımlayıcı 3'ü de kapatabiliriz:

```
$ command 3> & 1 1> & 2 2> & 3 3> & -

```

Dosya tanımlayıcı tablosu şu şekilde görünür:

![https://catonmat.net/images/bash-redirections/fd1-fd2-swap.png](https://catonmat.net/images/bash-redirections/fd1-fd2-swap.png)

Gördüğünüz gibi, dosya tanımlayıcıları 1 ve 2 değiştirildi.

**22. stdout'u bir işleme ve stderr'i başka bir sürece gönderin**

```
$ komut>> (stdout_cmd) 2>> (stderr_cmd)

```

Bu tek astar, süreç ikamesi kullanır. `>(...)`Operatör komutları çalıştırır `...`anonim adlandırılmış borunun okuma kısmına bağlı stdin'nin ile. Bash, operatörü anonim kanalın dosya adıyla değiştirir.

Örneğin, ilk oyuncu değişikliği `>(stdout_cmd)`geri dönebilir `/dev/fd/60`ve ikinci oyuncu değişikliği geri gelebilir `/dev/fd/61`. Bu dosyaların her ikisi de, anında oluşturulan kanallar olarak adlandırılır. Her iki adlandırılmış kanal da okuyucu olarak komutlara sahiptir. Komutlar, verileri okuyabilmeleri için birinin borulara yazmasını bekler.

Komut şu şekilde görünür:

```
$ komut> / dev / fd / 60 2> / dev / fd / 61

```

Şimdi bunlar sadece basit yönlendirmeler. Stdout adresine yönlendirilir `/dev/fd/60`ve stderr adresine yeniden yönlendirilir `/dev/fd/61`.

Komut standart çıktıya yazdığında, arkasındaki `/dev/fd/60`süreç (işlem `stdout_cmd`) verileri okur. Ve komut stderr'e yazdığında, arkasındaki `/dev/fd/61`süreç (süreç `stderr_cmd`) verileri okur.

**23. Tüm borulu komutların çıkış kodlarını bulun**

Diyelim ki, hepsi birlikte borulu birkaç komut çalıştırıyorsunuz:

```
$ cmd1 | cmd2 | cmd3 | cmd4

```

Ve tüm bu komutların çıkış durum kodlarını öğrenmek istiyorsunuz. Bunu nasıl yapıyorsun? Tüm komutların çıkış kodlarını almanın kolay bir yolu yoktur çünkü bash yalnızca son komutun çıkış kodunu döndürür.

Bash geliştiricileri bunu düşündüler `PIPESTATUS`ve boru akışındaki tüm komutların çıkış kodlarını kaydeden özel bir dizi eklediler .

Dizinin öğeleri `PIPESTATUS`, komutların çıkış kodlarına karşılık gelir. İşte bir örnek:

```
$ echo 'pantolonlar havalı' | grep 'moo' | sed 's / o / x /' | awk '{baskı $ 1}'
$ echo $ {PIPESTATUS [@]}
0 1 0 0
```

Bu örnekte `grep 'moo'`başarısız olur ve `PIPESTATUS`dizinin 2. öğesi başarısızlığı gösterir.