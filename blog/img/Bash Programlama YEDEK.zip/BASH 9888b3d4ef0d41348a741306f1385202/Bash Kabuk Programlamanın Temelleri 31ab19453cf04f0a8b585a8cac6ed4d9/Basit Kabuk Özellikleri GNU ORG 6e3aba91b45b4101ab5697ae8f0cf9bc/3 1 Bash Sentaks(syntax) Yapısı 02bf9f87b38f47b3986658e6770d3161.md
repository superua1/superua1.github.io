# 3.1 Bash Sentaks(syntax) Yapısı

Kabuk, kedisine verilmiş olan emirleri yani girdileri bir dizi işlemden geçirerek yorumlar. Bir dizi işlem olarak tabir ettiğimiz yorumlama süreci kısaca; tüm girişin kabuk dahilindeki kurallara göre ayrıştırılıp işlenmesidir. Elbette ayrıştırma işleminde geçerli olan pek çok kural ve bu kuralların uygulanma sıralaması vardır. Anlatımın devamında kabuk için daha anlaşılır emirler vermemize yardımcı olması için bu kurallardan bahsediyor olacağız. 

## Kabuğun Genel Çalışma Yapısı

Bash kabuğuna verdiğimiz emirlerin okunup yorumlanması sırasında gerçekleşen işlem adımları kısaca aşağıdaki şekildedir.

- Girdisini bir betik dosyasından, -c çağırma seçeneğine argüman olarak sağlanan bir dizeden (Bash programının özelliklerini açıkladığımız bölüme göz atın) veya kullanıcının terminalinden okur. Kısacası kabuğa işlemesi üzere emir verilir.
- Alıntı kurallarına da uyarak kabuk aldığı girdiyi kelimelere ve işleçlere böler. Takma ad yani alias genişletme bu adımda gerçekleştirilir.
- Belirteçleri basit ve bileşik komutlara ayırır (bkz. Kabuk Komutları).
- Çeşitli kabuk genişletmelerini gerçekleştirir (bkz. Kabuk Genişletmeleri), genişletilmiş belirteçleri dosya adları listelerine (bkz. Dosya Adı Genişletme) ve komutlar ve bağımsız değişkenlere(argümanlara) böler.
- Gerekli yeniden yönlendirmeleri gerçekleştirir (bkz. Yeniden Yönlendirmeler) ve yeniden yönlendirme işleçlerini ve bunların işlenenlerini bağımsız değişken listesinden kaldırır.
- Komutu yürütür (bkz. Komutları Yürütme).
- İsteğe bağlı olarak komutun tamamlanmasını bekler ve çıkış durumunu toplar (bkz. Çıkış Durumu).

# Alıntı Mekanizmaları

Alıntı mekanizması isminden de anlaşılacağı üzere ilgili ifadelerin değiştirilmeden olduğu gibi kullanılmasını sağlar. Neticede gerçek hayatta herhangi birinden alıntı yapıldığında hiç bir kelimesi değiştirilemez. Değiştirilirse buna alıntı denilemez. İşte burada bahsi geçen "alıntılama" da bash kabuğunda farklı anlam ifade edebilecek çeşitli karakter ve kelimelerin özel anlamları dışında yalnızca yazıldıkları şekilde yansıtılmasıdır. 

Bash üzerinde geçerli olan üç tür alıntı mekanizması vardır. Bunlar; "kaçış karakteri(ters taksim)" "tek tırnak" ve "çift tırnak" kullanımıdır. Bu mekanizmalar sayesinde kabuk üzerinde özel anlam taşıyan her türlü ifade, değişmeden standart metin ifadesi olarak kullanılabilir. Örnekler üzerinden açıkladığımızda tam olarak neyden bahsettiğimizi kavramış olacaksınız.

### Kaçış Karakteri ( Ters Taksim) `\`

Ters taksim işaretinin hemen ardından yazılan karakter, bash kabuğunda özel anlama sahip olsa bile standart şekilde işlenir. Zaten bu sebeple bu işarete kaçış karakteri de denmektedir. Kendisinden sonra gelen karakter özelliklerinin bash kabuğu tarafından görmezden gelinmesini sağlar. Bu durumu gözlemlemek için aşağıdaki çıktılara göz atabilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $degisken
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo \$degisken
$degisken
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Gördüğünüz gibi kaçış karakteri(ters taksim `\`) değişken değerinin çağırılmasını sağlayan dolar işaretinin işlevini görmezden gelerek olduğu gibi bastırmış oldu.

Hatta bu örnekler dışında, örneğin konsola komut girerken eğer komutun sonuna ters taksim işareti ekleyip enter tuşuna basarsanız varsayılan olarak yeni satıra geçme özelliğinden dahi kaçmış olursunuz. Normal şartlarda konsola(terminal aracına) herhangi bir komut girip enter tuşuna bastığımızda "newline" olarak geçen özellik gereği komutumuz kabuğa iletilir ve konsolda yeni bir satıra geçiş yaparız. Komutumuzun sonuna ters taksim işareti ekleyince bu özellikten kaçındığımız için konsol bizden komut almak üzere bir alt satıra geçip bekliyor. Bu özellik genel olarak uzun komutların çok daha okunaklı şekilde verilebilmesi için kullanılıyor.

Not: Elbette kaçış karakteri, diğer alıntılama karakteri yani tek veya çift tırnak içerisinde yazıldığında kendi özelliğini yitirerek standart bir karakter olarak işlenir. 

```bash
taylan@DESKTOP-E4TGC85:~$ echo \"
"
taylan@DESKTOP-E4TGC85:~$ echo "\""
"
taylan@DESKTOP-E4TGC85:~$ echo '\"'
\"
taylan@DESKTOP-E4TGC85:~$
```

## Tek Tırnak Kullanımı

Kabuğun herhangi bir özel karakteri yorumlamasını önlemek için metnin etrafında tek tırnak işaretleri kullanılabilir. Dolar işaretleri, boşluklar, ve işaretleri, yıldız işaretleri ve diğer özel karakterler tek tırnak içine alındığında göz ardı edilir. Aşağıdaki örnek bu durumu kanıtlar niteliktedir.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ | '
Tek tırnaktayız; # + $ % ½ "" & ? * " \ - _ |
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

İstisnai olarak tek tırnak içerisinde kullanamayacağımız tek özel karakter tek tırnaktır.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnak bas: ' '
>
> ^C
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo 'Tek tırnak bas: '' '
Tek tırnak bas:
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

## Çift Tırnak Kullanımı

Çift tırnaklar, tek tırnaklara benzer şekilde hareket eder, ancak çift tırnaklar kabuğun dolar işaretlerinin, ters tırnakların, kaçış karakterinin ve geçmiş genişletme aktifse ünlem işaretinin yorumlamasına izin verir. Yine de kabuk ortamında posix modu aktifse geçmiş genişletme aktif olsa dahi ünlem işaretini özel anlamında kullanılmaz.

Dolar işareti ve ters tırnak özel anlamlarını çift tırnak içinde korurlar. Yani bu iki karakter için kabuk genişletmeleri çift tırnak içerisinde uygulanır;

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$(echo $BASH_SUBSHELL)"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$(echo $BASH_SUBSHELL)"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$degisken"
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "`echo $BASH_SUBSHELL`"
1
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Kaçış karakteri ise dolar işareti, ters tırnak, çift tırnak ya da newline olarak geçen yeni satıra geçme karakterlerinden kaçmayı sağlar. Zaten bu karakterler dışındaki hiç bir karakter çift tırnak içerisinde özel anlamlarına genişletilmez. Çift tırnak içerisinde özel anlamlarına genişletilen karakterleri standart karakterler olarak bastırmak istediğimizde kaçış karakterini kullanabiliriz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "$degisken"
ben değişkenim
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "\$degisken"
$degisken
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Geçmiş özelliğinin aktif olması halinde çift tırnak içinde bu ünlem işareti ile geçmişten komut getirebiliriz. 

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ set -o histexpand
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ pwd
/home/taylan
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "!!"
echo "pwd"
pwd
```

Ancak daha önce de belirttiğimiz şekilde eğer geçmiş özelliğiyle birlikte posix ortam özelliği de aktifse bu kez ünlem işaretleri özel anlamını kaybeder.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ set -o posix
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ pwd
/home/taylan
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "!!"
!!
```

Ayrıca * ve @ işaretleri çift tırnak içinde kabuk parametre genişletmesine de uğrarlar. Örneğin dizi elemanlarını çağırmak üzere kullanıldıklarında çift tırnak içinde dizi elemanlarını çağırırlar. 

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ dizi=(eleman1 eleman2 eleman3)
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo ${dizi[*]}
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "${dizi[*]}"
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "${dizi[@]}"
eleman1 eleman2 eleman3
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo '${dizi[@]}'
${dizi[@]}
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Tüm bahsi geçen alıntı karakterlerinin kullanımına dair örnek bir tablo;

```bash
# | Expression  | Result      | Comments
---+-------------+-------------+--------------------------------------------------------------------
 1 | "$a"        | apple       | variables are expanded inside ""
 2 | '$a'        | $a          | variables are not expanded inside ''
 3 | "'$a'"      | 'apple'     | '' has no special meaning inside ""
 4 | '"$a"'      | "$a"        | "" is treated literally inside ''
 5 | '\''        | **invalid** | can not escape a ' within ''; use "'" or $'\'' (ANSI-C quoting)
 6 | "red$arocks"| red         | $arocks does not expand $a; use ${a}rocks to preserve $a
 7 | "redapple$" | redapple$   | $ followed by no variable name evaluates to $
 8 | '\"'        | \"          | \ has no special meaning inside ''
 9 | "\'"        | \'          | \' is interpreted inside "" but has no significance for '
10 | "\""        | "           | \" is interpreted inside ""
11 | "*"         | *           | glob does not work inside "" or ''
12 | "\t\n"      | \t\n        | \t and \n have no special meaning inside "" or ''; use ANSI-C quoting
13 | "`echo hi`" | hi          | `` and $() are evaluated inside ""
14 | '`echo hi`' | `echo hi`   | `` and $() are not evaluated inside ''
15 | '${arr[0]}' | ${arr[0]}   | array access not possible inside ''
16 | "${arr[0]}" | apple       | array access works inside ""
17 | $'$a\''     | $a'         | single quotes can be escaped inside ANSI-C quoting
18 | "$'\t'"     | $'\t'       | ANSI-C quoting is not interpreted inside ""
19 | '!cmd'      | !cmd        | history expansion character '!' is ignored inside ''
20 | "!cmd"      | cmd args    | expands to the most recent command matching "cmd"
21 | $'!cmd'     | !cmd        | history expansion character '!' is ignored inside ANSI-C quotes
---+-------------+-------------+--------------------------------------------------------------------
```

## ANSI-C

ANSI-C adında farklı bir alıntı türü de mevcut. Bu alıntı türünde dolar işaretinden sonra tek tırnak içinde kaçış karakteri kullanılarak yazılan birtakım ifadelerin özel anlamları vardır. 

```bash
\a
alert (bell)

\b
backspace

\e
\E
an escape character (not ANSI C)

\f
form feed

\n
newline

\r
carriage return

\t
horizontal tab

\v
vertical tab

\\
backslash

\'
single quote

\"
double quote

\?
question mark

\nnn
the eight-bit character whose value is the octal value nnn (one to three octal digits)

\xHH
the eight-bit character whose value is the hexadecimal value HH (one or two hex digits)

\uHHHH
the Unicode (ISO/IEC 10646) character whose value is the hexadecimal value HHHH (one to four hex digits)

\UHHHHHHHH
the Unicode (ISO/IEC 10646) character whose value is the hexadecimal value HHHHHHHH (one to eight hex digits)

\cx
a control-x character
```

Kullanım örneği için aşağıdaki çıktıları inceleyebilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $'a\nb'
a
b
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo $"a\nb"
a\nb
```

## Yerel Ayara Özgü Çeviri (Locale-Specific Translation)

[https://unix.stackexchange.com/a/334765/364572](https://unix.stackexchange.com/a/334765/364572)

# Yerelleştirme

Yerelleştirme, belgelenmemiş bir Bash özelliğidir.

Yerelleştirilmiş bir kabuk betiği, metin çıktısını sistemin yerel ayarı olarak tanımlanan dilde yansıtır. Almanya, Berlin'deki bir Linux kullanıcısı, komut dosyası çıktısını Almanca olarak alırken, Berlin, Maryland'deki kuzeni aynı komut dosyasından İngilizce çıktı alırdı.

Yerelleştirilmiş bir komut dosyası oluşturmak için, kullanıcıya tüm mesajları (hata mesajları, istemler vb.) Yazmak için aşağıdaki şablonu kullanın.

Önünde dolar işareti ('$') bulunan çift tırnaklı bir dize, dizenin geçerli yerel ayara göre çevrilmesine neden olur. Gettext altyapısı, aşağıda açıklandığı gibi LC_MESSAGES ve TEXTDOMAIN kabuk değişkenlerini kullanarak mesaj kataloğu aramasını ve çevirisini gerçekleştirir. Ek ayrıntılar için gettext belgelerine bakın. Geçerli yerel ayar C veya POSIX ise veya mevcut çeviri yoksa, dolar işareti yok sayılır.

[http://mywiki.wooledge.org/BashFAQ/098](http://mywiki.wooledge.org/BashFAQ/098)

[https://www.linuxjournal.com/content/internationalizing-those-bash-scripts](https://www.linuxjournal.com/content/internationalizing-those-bash-scripts)

[https://tldp.org/LDP/abs/html/localization.html](https://tldp.org/LDP/abs/html/localization.html)

## Yorum Alanı

Etkileşimli olmayan bir kabukta veya yerleşik interactive_commentsseçeneğin shoptetkinleştirildiği etkileşimli bir kabukta (bkz . Shopt Yerleşik ), 'ile başlayan bir kelime#'bu kelimenin ve o satırdaki kalan tüm karakterlerin yok sayılmasına neden olur. interactive_comments Seçeneğin etkinleştirilmediği etkileşimli bir kabuk yorumlara izin vermez. interactive_comments Seçenek etkileşimli kabuklarda öntanımlı olarak açıktır. Bir kabuğu neyin etkileşimli kıldığının açıklaması için Etkileşimli Kabuklar'a bakın .