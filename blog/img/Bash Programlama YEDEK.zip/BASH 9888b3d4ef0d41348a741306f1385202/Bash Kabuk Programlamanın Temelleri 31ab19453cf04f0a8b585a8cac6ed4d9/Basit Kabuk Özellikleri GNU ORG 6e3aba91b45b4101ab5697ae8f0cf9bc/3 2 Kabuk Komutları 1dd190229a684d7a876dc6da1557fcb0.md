# 3.2 Kabuk Komutları

[https://www.gnu.org/software/bash/manual/html_node/Shell-Commands.html#Shell-Commands](https://www.gnu.org/software/bash/manual/html_node/Shell-Commands.html#Shell-Commands)

## 3.2.1 Rezerve Kelimeler

Ayrılmış sözcükler, kabuk için özel anlamı olan sözcüklerdir. Kabuğun bileşik komutlarını başlatmak ve bitirmek için kullanılırlar.

Aşağıdaki sözcükler, alıntı yapılmadığında ve bir komutun ilk sözcüğü olduğunda ayrılmış olarak kabul edilir (istisnalar için aşağıya bakın):

```bash
if	then	elif	else	fi	time
for	in	until	while	do	done
case	esac	coproc	select	function
{	}	[[	]]	!
```

"in" kelimesi case ya da select komutları ile kullanıldığında rezerve kelime olarak algılanır. Benzer şekilde in ve do kelimeleri de for döngüsünde özel anlamı olan kelimelerdir.

## 3.2.2 **Basit Komutlar**

Basit bir komut, en sık karşılaşılan komut türüdür. Sadece `blank`s ile ayrılmış , kabuğun kontrol operatörlerinden biri tarafından sonlandırılan bir kelime dizisidir (bkz. [Tanımlar](https://www.gnu.org/software/bash/manual/html_node/Definitions.html) ). İlk kelime genellikle çalıştırılacak bir komutu belirtir, geri kalanı o komutun argümanlarıdır.

## 3.2.3 Boru Hatları | Pipelines

Boru hattındaki her komutun çıktısı, bir sonraki komutun girişine bir boru aracılığıyla bağlanır. Yani, her komut önceki komutun çıktısını okur. Bu bağlantı, komut tarafından belirtilen herhangi bir yeniden yönlendirmeden önce gerçekleştirilir.

"| &" Kullanılırsa, standart çıktısına ek olarak command1’in standart hatası, kanal aracılığıyla command2’nin standart girişine bağlanır; 2> & 1 | için bir kısaltmadır. Bu hata yönlendirmesi tüm yönlendirme yapıldıktan sonra gerçekleştirilir.

Rezerve kelimelerden olan `time` kelimesi, boru hattındaki tüm işlemlerin toplam ne kadar sürede tamamlandığını verir.  Şu anda istatistikler, geçen (duvar saati) zamanı ve komutun yürütülmesi tarafından tüketilen kullanıcı ve sistem süresinden oluşur. 

• gerçek: Sürecin başından sonuna kadar çalıştırılması için harcanan gerçek süre, sanki bir kronometre ile bir insan tarafından ölçülmüş gibi wall-clock yani duvar saati olarak da isimlendirilir.

• kullanıcı: Hesaplama sırasında tüm CPU'lar tarafından harcanan kümülatif süre 

• sys: Bellek ayırma gibi sistemle ilgili görevler sırasında tüm CPU'lar tarafından harcanan toplam süre. 

Not: Birden çok işlemci paralel olarak çalışabileceğinden, bazen kullanıcı + sys'in gerçek olandan daha büyük olabileceğine dikkat edin.

time kelimesinin -P seçeneği çıktı biçimini POSIX tarafından belirtilen şekilde değiştirir. Kabuk POSIX modundayken (Bash POSIX Moduna bakın), sonraki simge '-' ile başlıyorsa zamanı ayrılmış bir kelime olarak tanımaz. TIMEFORMAT değişkeni, zamanlama bilgilerinin nasıl görüntülenmesi gerektiğini belirten bir biçim dizgisine ayarlanabilir. Kullanılabilir formatların bir açıklaması için Bash Değişkenlerine bakın. Zamanın ayrılmış bir sözcük olarak kullanılması, kabuk yerleşiklerinin, kabuk işlevlerinin ve boru hatlarının zamanlamasına izin verir. Harici bir zaman komutu bunları kolayca zamanlayamaz.

Ardışık düzen eşzamansız olarak çalıştırılmazsa (bkz. Listeler), kabuk kanaldaki tüm komutların tamamlanmasını bekler.

Bir boru hattındaki her komut, ayrı bir işlem olan kendi alt kabuğunda yürütülür (bkz. Komut Yürütme Ortamı). Son boru seçeneği shopt yerleşik kullanılarak etkinleştirilirse (bkz. Shopt Yerleşik), bir boru hattının son elemanı kabuk işlemi tarafından çalıştırılabilir.

Bir ardışık düzenin çıkış durumu, pipefail-ardışık düzen seçeneği etkinleştirilmedikçe, ardışık düzendeki son komutun çıkış durumudur (bkz. Yerleşik Ayar). Ardışık düzen etkinleştirilmişse, ardışık düzenin dönüş durumu, sıfır olmayan bir durumla çıkmak için son (en sağdaki) komutun değeridir veya tüm komutlar başarıyla çıkarsa sıfırdır. Ayrılmış '!' Sözcüğü ardışık düzenten önce gelirse, çıkış durumu, yukarıda açıklandığı gibi çıkış durumunun mantıksal olumsuzlamasıdır. Kabuk, bir değer döndürmeden önce kanaldaki tüm komutların sona ermesini bekler.

## 3.2.4 Komut Listeleri

Komut listesi, bir ve birden fazla  ‘;’, ‘&’, ‘&&’, ya da ‘||’ gibi operetörlerle ayrılmıştır ve isteğe bağlı olarak ‘;’, ‘&’ ya da "newline" olarak geçen yeni satır ile sonlandırılmıştır. Bu liste operatörlerinden "&&" ve "||" eşit önceliğe sahiptir, ardından eşit önceliğe sahip ";" ve "&" gelir.

Listede komutları sınırlamak için noktalı virgülle eşdeğer bir veya daha fazla satırsonu dizisi görünebilir. Bir komut kontrol operatörü "&" tarafından sonlandırılırsa, kabuk komutu eşzamansız olarak bir alt kabukta yürütür. Bu, arka planda komutun yürütülmesi olarak bilinir ve bunlara eşzamansız komutlar denir. Kabuk komutun bitmesini beklemez ve dönüş durumu 0'dır (doğru). İş denetimi etkin olmadığında (bkz. İş Denetimi), herhangi bir açık yönlendirme olmadığında eşzamansız komutlar için standart girdi / dev / null'dan yeniden yönlendirilir.

";" İle ayrılan komutlar sırayla yürütülür; kabuk, her komutun sırayla sona ermesini bekler. Dönüş durumu, yürütülen son komutun çıkış durumudur.

VE ve VEYA listeleri, sırasıyla "&&" ve "||" kontrol operatörleri ile ayrılmış bir veya daha fazla işlem hattının dizileridir. VE ve VEYA listeleri, sol ilişkilendirilebilirlikle yürütülür.

VE kullanıldığında;

```bash
command1 && command2
```

command2, ancak ve ancak, komut1 sıfır (başarılı) çıkış durumu döndürürse çalıştırılır.

VEYA kullanıldığında;

```bash
command1 || command2
```

command2, yalnızca ve ancak, command1 sıfır olmayan bir çıkış durumu döndürürse çalıştırılır.

VE ve VEYA listelerinin dönüş durumu, listede yürütülen son komutun çıkış durumudur.

## 3.2.5 Bileşik Komutlar

Birleşik komutlar, kabuk programlama dili yapılarıdır. Her yapı rezerve edilmiş bir kelime veya kontrol operatörü ile başlar ve karşılık gelen rezerve edilmiş kelime veya operatör tarafından sona erdirilir. Bileşik bir komutla ilişkili tüm yeniden yönlendirmeler (bkz. Yeniden Yönlendirmeler), açıkça geçersiz kılınmadığı sürece bu bileşik komut içindeki tüm komutlara uygulanır.

Çoğu durumda, bir bileşik komutun açıklamasındaki bir komut listesi, komutun geri kalanından bir veya daha fazla yeni satırla ayrılabilir ve ardından noktalı virgül yerine yeni bir satır gelebilir.

Bash, komutları gruplamak ve bunları bir birim olarak yürütmek için döngüsel yapılar, koşullu komutlar ve mekanizmalar sağlar.

Bileşik komutlar üç tür olarak sınıflanabilir;

- Döngü Yapıları: Yinelemeli eylem için kabuk komutları.
- Koşullu Yapılar: Koşullu yürütme için kabuk komutları.
- Komut Gruplama: Komutları gruplama yolları.

## 3.2.6 Yardımcı İşlemler Coprocesses

Bir coprocess, coproc ayrılmış sözcüğünden önce gelen bir kabuk komutudur. Bir eş işlem, bir alt kabukta eşzamansız olarak, komut "&" kontrol operatörü ile sonlandırılmış gibi, çalıştıran kabuk ve yardımcı işlem arasında iki yönlü bir boru ile çalıştırılır.

Bir yardımcı işlemin biçimi şu şekildedir:

```bash
coproc [NAME] command [redirections]
```

Bu, NAME adlı bir yardımcı işlem oluşturur. NAME sağlanmadıysa, varsayılan ad COPROC olur. Komut basit bir komutsa, NAME sağlanmamalıdır (bkz. Basit Komutlar); aksi takdirde, basit komutun ilk kelimesi olarak yorumlanır.

Yardımcı işlem yürütüldüğünde, kabuk, yürütme kabuğunun bağlamında NAME adlı bir dizi değişkeni oluşturur (bkz. Diziler). Standart komut çıktısı, yürütme kabuğundaki bir dosya tanımlayıcısına bir boru yoluyla bağlanır ve bu dosya tanımlayıcı, NAME [0] 'a atanır. Standart komut girişi, yürütme kabuğundaki bir dosya tanımlayıcısına bir boru yoluyla bağlanır ve bu dosya tanımlayıcı, NAME [1] 'e atanır. Bu kanal, komut tarafından belirtilen herhangi bir yeniden yönlendirmeden önce oluşturulur (bkz. Yeniden Yönlendirmeler). Dosya tanımlayıcıları, standart sözcük genişletmeleri kullanılarak kabuk komutlarına ve yeniden yönlendirmelere argümanlar olarak kullanılabilir. Komut ve işlem değişikliklerini yürütmek için oluşturulanların dışında, dosya tanımlayıcıları alt kabuklarda kullanılamaz.

Ortak işlemi yürütmek için oluşturulan kabuğun işlem kimliği, NAME_PID değişkeninin değeri olarak mevcuttur. Wait yerleşik komutu, yardımcı işlemin sona ermesini beklemek için kullanılabilir.

Yardımcı işlem eşzamansız bir komut olarak oluşturulduğundan, coproc komutu her zaman başarı döndürür. Bir yardımcı işlemin dönüş durumu, komutun çıkış durumudur.