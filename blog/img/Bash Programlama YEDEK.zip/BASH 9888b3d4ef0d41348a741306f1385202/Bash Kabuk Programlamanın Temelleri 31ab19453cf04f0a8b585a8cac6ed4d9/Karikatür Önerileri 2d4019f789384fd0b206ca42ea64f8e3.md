# Karikatür Önerileri

Bash kabuğunun geçmişten beri varsayılan olarak kullanılmasının nedeni geçmişe yönelik uyumluluktur. Mevcut betiklerin geçerliliğini korumak için yeni bir kabuğa geçilmez. Bu durumu:"aman ali rıza bey tadımız kaçmasın" şeklinde karikatürüze edebilirisin. Ali rıza tekerlekli sandalyede bash programalama yapıyordur. Anladın işte..

Kabuğun teyit edilmesi aşamasında bu karikatür kullanılabilir. Sen bash kabuğunu savundun. SAVUNMADIM! Savundun savunmadım çıkar göster.

Düzenli kod yazma üzerine;

![Karikatu%CC%88r%20O%CC%88nerileri%202d4019f789384fd0b206ca42ea64f8e3/Untitled.png](Karikatu%CC%88r%20O%CC%88nerileri%202d4019f789384fd0b206ca42ea64f8e3/Untitled.png)