# help Komutu

`help` komutu bash kabuğunda yerleşik(builtin) olan komuttur. İsminden de anlaşılabileceği üzere yerleşik olan komutların yardım bilgilerini sunar. En temel kullanımı hakkında bilgi alınmak istenen komutun `help komut` şeklinde yazılmasıdır. 

```bash
taylan@taylan:~$ help disown 
disown: disown [-h] [-ar] [görevtan ... | pid ...]
    Görevleri geçerli kabuktan kaldır.
    
    Her İŞTANIMı argümanını etkin görevler tablosundan kaldırır. İŞTANIMı olmadan,
    kabuk geçerli görev kavramını kullanır.
    
    Seçenekler:
      -a        İŞTANIMı belirtilmemişse tüm görevleri kaldır
      -h        her İŞTANIMını işaretle, böylece kabul bir SIGHUP aldığında göreve SIGHUP
                gönderme
      -r        sadece çalışan görevleri kaldırremove 
    
    Çıkış Durumu:
    Geçersiz bir seçenek veya İŞTANIMı girilmedikçe başarılı döner.
taylan@taylan:~$
```

Ayrıca `help` komutunun da alabileceği birkaç seçenek vardır. Örneğin yalnızca ilgili komutun ne işe yaradığını öğrenmek istersek, kısa açıklama almak üzer `-d` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ help -d disown 
disown - Remove jobs from current shell.
taylan@taylan:~$
```

Eğer çıktıları manuel sayfalarının düzeni gibi almak istersek `-m` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ help -m disown 
NAME
    disown - Görevleri geçerli kabuktan kaldır.

SYNOPSIS
    disown [-h] [-ar] [görevtan ... | pid ...]

DESCRIPTION
    Görevleri geçerli kabuktan kaldır.
    
    Her İŞTANIMı argümanını etkin görevler tablosundan kaldırır. İŞTANIMı olmadan,
    kabuk geçerli görev kavramını kullanır.
    
    Seçenekler:
      -a        İŞTANIMı belirtilmemişse tüm görevleri kaldır
      -h        her İŞTANIMını işaretle, böylece kabul bir SIGHUP aldığında göreve SIGHUP
                gönderme
      -r        sadece çalışan görevleri kaldırremove 
    
    Çıkış Durumu:
    Geçersiz bir seçenek veya İŞTANIMı girilmedikçe başarılı döner.

SEE ALSO
    bash(1)

IMPLEMENTATION
    GNU bash, sürüm 5.0.18(1)-release (x86_64-pc-linux-gnu)
    Copyright (C) 2019 Free Software Foundation, Inc.
    Lisans GPLv3+: GNU GPL sürüm 3 veya sonrası <http://gnu.org/licenses/gpl.html>

taylan@taylan:~$
```

Yalnızca sorgulanan komutun seçeneklerini kısaca görmek istersek `-s` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ help -s disown 
disown: disown [-h] [-ar] [görevtan ... | pid ...]
taylan@taylan:~$
```

Unutmamanız gereken detay; `help` komutunun yalnızca kabuk üzerinde yerleşik olan yani builtin olarak geçen komutlar hakkında bilgi sunduğudur. Eğer diğer komutlar hakkında bilgi almak isterseniz manuel sayfalarına `man komut_adı` şeklinde ulaşabilirsiniz.

Ayrıca komutların yardım bilgisini görüntüleyen —help seçeneği ile de karıştırmayın. Burada bahsettiğimiz doğrudan help aracıdır. Normalde neredeyse her araç kendine ait kısa kullanım bilgisini sunan —help gibi seçenekler sağlıyor.