# times Komutu

Bu kanyak ve altındaki yorumlar açıklalyıcı olabilir [https://unix.stackexchange.com/a/52318/364572](https://unix.stackexchange.com/a/52318/364572)