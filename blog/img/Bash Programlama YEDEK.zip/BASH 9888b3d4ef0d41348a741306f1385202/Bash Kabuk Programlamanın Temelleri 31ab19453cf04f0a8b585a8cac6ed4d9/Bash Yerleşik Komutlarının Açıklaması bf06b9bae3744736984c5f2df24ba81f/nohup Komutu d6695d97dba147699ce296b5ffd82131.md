# nohup Komutu

Normal şartlarda kabuk üzerinden çalıştırılmış olan tüm araçlar kabuk kapatılırken sonlandırılır. Eğer bizler kabuk kapanırken araçlarımız çalışmaya devam etsin istersek `nohup` komutunu kullanabiliriz. Yerleşik komut değildir.

`nohup`, kabuk kapatılırken mevcut kabuk üzerindeki tüm işlemlere gönderilen HUP kapatma sinyalini görmezden gelerek kendisine argüman olarak verilmiş olan işlemi bu kapatma sinyaline karşı korur.

En temel kullanımı `nohup korunacak_işlem` şeklindedir. Hemen denemek için "gedit" isimli grafiksel arayüze sahip metin editörünü konsol üzerinden çalıştıralım. Aracımız çalıştıktan sonra, aracımızı çalıştırdığımız konsolu(dolayısı ile konsola bağlı bulunan kabuğu) kapattığımızda "gedit" aracının da kapatıldığını görebiliyoruz. Eğer konsol kapatılsa da "gedit" aracı çalışmaya devam etsin istersek "gedit" aracını `nohup gedit` komutu ile çalıştırmamız gerekiyor. Bu komutun ardından konsol aracını kapattığımızda "gedit" aracının çalışmaya devam ettiğini teyit edebiliyoruz. 

nohup komutu ilgili işlemi kabuktan bağımsız kıldığı için elbette kabuğun sunduğu imkanları da kaybetmiş oluyor. Bu durum "gedit" gibi grafiksel arayüz üzerinden çalışan uygulamaları pek etkilemiyor olsa da konsol üzerinden çalıştırılan ve kullanıcı ile etkileşim kurması gereken uygulamaları etkiler. Bu ne anlama geliyor ? Bizler konsol üzerinden bir işlem başlatırken aslında "stdin" "sterr" "stout" olarak ifade edilen üç dosya tanımlayıcısına sahip oluyoruz. 

**stdin olarak geçen yapı;** standart input yani kullanıcının klavyesi ile yazdığı veri girişleridir.

**stderr olarak geçen yapı;** standart error yani çalıştırılmış olan aracın ürettiği hata çıktılarıdır.

**stdout olarak geçen yapı;** standart output yani çalıştırılan aracın çalışması sonucu üretilmiş olan çıktılardır.

İşte bizler nohup komutu ile bir aracı çalıştırdığımızda bu araç konsol üzerinden input almıyor ve çıktılarını kullanıcının ev dizini altında nohup.out adlı bir dosyaya kaydediyor. Çünkü nohup komutunun yapısı gereği çalıştırılan aracı konsoldan ayırdığı için, ilgili aracın input alabileceği ya da çıktıları kullanıcılara aktarabileceği bir konsol olmuyor. Standart çıktıları(stdout) ve standart hataları(stdout) hepsini nohup.out dosyasına kaydediyor. Hemen denemek için basit bir betik dosyası oluşturalım. 

Ben kullanıcıdan komut alıp bu komutu bastıracak ve en sonunda aslında hiç olmayan bir komutu çalıştırmayı deneyecek bir betik oluşturuyorum. Betik dosyam aşağıdaki şekilde. 

```bash
read -p "Veri girin:" veri
echo "Girdiğiniz veri:$veri"
olmayan-komut
```

Bu dosyayı standart şekilde konsol üzerinden çalıştırdığımızda bizden veri alıp bu veriyi ve en son hatalı komutun hata çıktısını konsola basıyor.

```bash
taylan@taylan:~$ bash betik.sh                                            
Veri girin:bu bir veri girişidir                                          
Girdiğiniz veri:bu bir veri girişidir                                     
betik.sh: satır 3: olmayan-komut: komut yok                               
taylan@taylan:~$
```

Şimdi aynı betik dosyasını `nohup` komutu ile konsoldan bağımsız şekilde çalıştırmayı deneyelim.

```bash
taylan@taylan:~$ nohup ./betik.sh                                         
nohup: girdi gözardı ediliyor ve çıktı 'nohup.out' e ekleniyor            
```

Gördüğünüz gibi betik dosyası çalıştırıldı fakat bizlerden herhangi bir veri girişi istemedi ya da konsola çıktı bastırmadı. Çıktıların '**nohup.out**' dosyasına eklendiğini belirtti sadece. Bu dosyanın içeriğini de `cat` komutu ile okuyarak bu durumu teyit edebiliyoruz.

```bash
taylan@taylan:~$ cat nohup.out 
Girdiğiniz veri:
./betik.sh: 3: olmayan-komut: not found
taylan@taylan:~$
```

`nohup` komutu ile hangi aracı çalıştırırsak çalıştıralım aracın ürettiği konsol çıktıları bu dosyaya alt alta ekleniyor olacak. Eğer isterseniz bu varsayılan dosya konumunu da dilediğiniz şekilde değiştirebilirsiniz. Örneğin ben tüm çıktıların "Belgeler" dizini altında "çıktı.txt" isimli bir dosyaya gönderilmesini istersem çıktıları büyüktür işareti `>` ile yönlendirebilirim.

```bash
taylan@taylan:~$ nohup ./betik.sh > Belgeler/çıktı.txt
nohup: girdi gözardı ediliyor ve stderr stdout'a gönderiliyor
taylan@taylan:~$ cat Belgeler/çıktı.txt 
Girdiğiniz veri:
./betik.sh: 3: olmayan-komut: not found
taylan@taylan:~$
```

Konsoldan bağısız olan işlemi sonlandırmak istersek de tek yapmamız gereken işlem numarasını `pgrep` komutu yardımıyla öğrenip `kill işlem_numarası` şeklinde sonlandırmaktır.

```bash
taylan@taylan:~$ pgrep "gedit"
3706
taylan@taylan:~$ kill 3706
taylan@taylan:~$ pgrep "gedit"
taylan@taylan:~$
```

Fakat `nohup` komutu ile başlatılmış bir işleme HUP kapatma sinyali işlemeyecektir. Zaten `nohup` komutunun ana işlevi de başlatılmış olan süreci HUP kapatma sinyaline karşı korumaktır. Zaten komutun adı da buradan geliyor. HUP sinyali hariç diğer kapatma yöntemleri işlemi sonlandırabilir. Bu durumu teyit etmek için `nohup` ile başlattığınız işlemi `kill -s HUP işlem_numarası` komutu ile sonlandırmayı deneyebilirsiniz.

`nohup` komutunun bash kabuğunda yerleşik olarak bulunan `disown` isimli alternatifi vardır. 

`disown` ile `nohup` arasındaki en temel farklılıklar;

`disown` yalnızca kabuk kapatılırken gönderilen HUP sinyaline karşı korurken, `nohup` ne şekilde geldiğine bakılmaksızın HUP sinyalinden ilgili işlemi korur.

`disown` komutu arka plandaki işlemler üzerinde etkilidir yani öncelikle işlem çalıştırılıp arka plana alınmalı daha sonda `disown` komutu çalıştırılmalıdır. 

`nohup` komutu ise ilgili işlemden önce belirtilmelidir.

Kullanım alanlarına bakacak olursak; örneğin konsol üzerinden bir araç çalıştırdığınız ve konsolu kapatıp aracın açık kalmasını istiyorsunuz. Bu durumda aracı duraklatıp arkaplana alabilir ve `disown` komutu ile konsol kapansa dahi çalışmaya devam etmesini sağlayabilirsiniz. `nohup` komutu ise aynı durumun daha planlı şekilde yapılışıdır. Yani zaten konsolu ya da daha doğrusu mevcut kabuğu kullanmayacağınız önceden belli ise doğrudan `nohup` komutunun ardından çalıştırmak istediğimiz aracı yazabilirsiniz. Genelleyecek olursak `nohup` daha çok planlı durumlar için `disown` ise daha sonradan verilen kararlar için kullanılabilir. 

`disown` ilgili işlemi job control yani iş kontrolü tablosundan çıkarır ve HUP kapatma sinyaline karşı korur. süreci kabuğun iş kontrolünden kaldırır, ancak yine de terminale bağlı bırakır. Sonuçlardan biri, kabuğun ona bir SIGHUP göndermemesidir. Açıkçası, yalnızca arka plan işlerine uygulanabilir, çünkü bir ön plan işi çalışırken giremezsiniz.

`nohup` , süreci terminalden ayırır, çıktısını nohup.out'a yeniden yönlendirir ve onu SIGHUP'tan korur. Etkilerden biri (adlandırma), sürecin gönderilen herhangi bir SIGHUP'ı almamasıdır. İş kontrolünden tamamen bağımsızdır ve prensipte ön plandaki işler için de kullanılabilir (bu çok kullanışlı olmasa da).