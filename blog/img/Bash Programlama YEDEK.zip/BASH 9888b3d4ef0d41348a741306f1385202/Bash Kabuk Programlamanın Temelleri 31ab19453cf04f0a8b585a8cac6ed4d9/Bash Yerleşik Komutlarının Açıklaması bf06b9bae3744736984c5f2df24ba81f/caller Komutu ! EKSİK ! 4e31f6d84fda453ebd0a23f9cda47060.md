# caller Komutu ! EKSİK !

`caller` komutu, geçerli olan altyordam(subroutine) çağrısının bağlamını yani ne zaman çağırıldığının bilgisini sunar. Alt yordam çağrısı dediğimiz şey de aslında fonksiyonlara verilen diğer bir isimdir. Fonksiyon kelimesi yerine alt yordam(subroutine), alt program(subprogram), rutin(routine) hatta prosedür(procedure) kelimelerinin dahi kullanıldığına çeşitli dokümanlarda rastlayabilirsiniz. Karşılaştığınızda şaşırmamanız için ben de tanımlama esnasında "fonksiyon" ifadesi yerine "altyordam" ifadesini tercih ettim. Korkmayın teknik tabirlere boğulmak gibi bir niyetimiz yok.

Fonksiyon dediğimiz şeyin aslında, programın herhangi bir yerinde çağrılan ve çalıştırılan yaygın olarak kullanılan belirli bir rutin işi gerçekleştirme görevinde olan kod parçası olduğunu biliyoruz. Yaygın olarak gerçekleştirilen görevlere her ihtiyaç duyulduğunda kodu yazmak yerine, rutinler oluşturulur ve bu görevlerin gerçekleştirilmesi gerektiğinde çağrılır. Elbette fonksiyonlar tanımlanmış olsalar dahi çağırılmadıkları sürece asla çalıştırılmazlar. Buradaki "çağırılma" ifadesi de aslında ingilizce olarak "call" ifadesinden geliyor. İşte `caller`  komutu da, ilgili fonksiyonun çağırıldığı zaman(satır numarası) hakkında bize bilgi sunuyor. 

`caller` komutu etkileşimli kullanım için pek kullanışlı değildir, ancak orta derecede karmaşık komut dosyalarındaki hataları izlemek için kullanılabilir. Biz basit bir örnek vererek fonksiyonun ne zaman çağırıldığının bilgisini almaya çalışalım.

```bash
!/bin/bash

oku(){
echo "Ben fonksiyonum ve çalıştım !"
caller 0 k
}

oku1(){
echo "Ben diğer bir fonksiyonum ve çalıştım !"
caller 0 
}

oku
echo "Başka, komutları temsilen.."
oku1
oku

oku1
```

Çıkıtıları

```
taylan@taylan:~$ bash yeni.sh 
Ben foknsiyonum ve çalıştım !
13 main yeni.sh
Başka, komutları temsilen..
Ben düğer bir foknsiyonum ve çalıştım !
15 main yeni.sh
Ben foknsiyonum ve çalıştım !
16 main yeni.sh
Ben düğer bir foknsiyonum ve çalıştım !
18 main yeni.sh
taylan@taylan:~$
```

Görebildiğiniz gibi `caller` komutu sayesinde ilgili fonksiyonun betik dosyası içerisinde hangi satır sırasında çağırıldığı konusunda haberdar ediliyoruz. Bizim oluşturduğumuz örnek kolay anlaşılır olması açısından son derece basit. Fakat çok daha karmaşık olan projelerde hatanın kaynağını saptayabilmek için ilgili fonksiyonun ne zaman çalıştırıldığının bilgisine ulaşmanız yani hata ayıklama yapmak için kullanmamız gerekebilir. Ayrıca `caller` komutu `source` ya da `.` nokta komutu ile dışarıdan içeriye aktarılmış olan fonksiyonlar üzerinde de etkilidir.

```bash
#!/bin/bash

oku(){
echo "Ben foknsiyonum ve çalıştım !"
caller 0 
}

oku1(){
echo "Ben düğer bir foknsiyonum ve çalıştım !"
caller 0 
}
source ./yaz.sh
oku
echo "Başka, komutları temsilen.."
oku1
yaz
```

Çıktısı

```bash
taylan@taylan:~$ bash yeni.sh 
Ben foknsiyonum ve çalıştım !
13 main yeni.sh
Başka, komutları temsilen..
Ben düğer bir foknsiyonum ve çalıştım !
15 main yeni.sh
Ben 'yaz' isimli fonksiyonum ve başka bir dosyadan çağırıldım.
16 yeni.sh
taylan@taylan:~$
```