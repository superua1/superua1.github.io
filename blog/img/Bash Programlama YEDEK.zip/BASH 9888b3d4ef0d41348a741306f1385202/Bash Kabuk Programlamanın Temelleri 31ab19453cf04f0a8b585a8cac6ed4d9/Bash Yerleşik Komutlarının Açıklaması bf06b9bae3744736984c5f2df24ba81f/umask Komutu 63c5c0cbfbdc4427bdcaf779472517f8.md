# umask Komutu

`umask` komutu bash kabuğunda yerleşik olan posix standartlarına uyan bir araçtır.

Sistem üzerinde yeni bir dizin ya da dosya oluştururken daha önceden varsayılan olarak belirlenmiş olan `umask` değeri üzerinden yetkilendirme işlemi otomatik olarak yapılır. Bash programlamaya kalkıştığımıza göre Linux sistemlerindeki yetkilendirme yapısına hakim olduğumuzu varsayabiliriz. Yine de anlatımları daha rahat takip edebilmek adına kısaca yetki kavramından söz etmiş olalım.

Sistemin güvenli şekilde yönetilebilmesi için elbette dosya ve dizinlere özel olarak yetki tanımlamaları yapılıyor. Yetki kavramını daha net anlayabilmek adına yeni bir klasör ve dosya oluşturup `ls -l` komutu ile özelliklerini listeleyelim.

```bash
taylan@taylan:~/test$ mkdir dizin
taylan@taylan:~/test$ touch dosya
taylan@taylan:~/test$ ls -l
toplam 4
drwxr-xr-x 2 taylan taylan 4096 Eyl 19 18:38 dizin
-rw-r--r-- 1 taylan taylan    0 Eyl 19 18:39 dosya
taylan@taylan:~/test$
```

Almış olduğumuz listenin sol tarafında dosya ve dizinlerin sahip olduğu "izinler" bilgisi yer alıyor. Bu ifadelerin neyi temsil ettiğini anlamak adına aşağıdaki şemaya göz atabiliriz.

```bash
drwxr-xr-x 2   taylan   taylan 4096 Eyl 19 18:38 dizin
|[-][-][-]    [------] [------]
| |  |  |        |       |       
| |  |  |        |       +-----------> Grup
| |  |  |        +-------------------> Sahibi
| |  |  +----------------------------> Diğer kullanıcıların yetkileri
| |  +-------------------------------> Aynı gruptaki kullanıcıların yetkileri
| +----------------------------------> Dizin sahibinin yetkileri
+------------------------------------> Türü-Çeşidi
```

Listenin en solunda yer alan ifade aslında türü belirtiyor. Linux'ta aşağıdaki gibi farklı dosya türleri olabilir; 

- `-` .txt, .js, .sh, .py, .rb vb. gibi farklı uzantılara sahip basit normal dosyayı gösterir
- `d` Dizini yani klasörleri temsil eder.
- `l` Sembolik linki temsil eder.
- `c` Karakter cihazı dosyasını temsil eder.(Örneğin; seri bağlantı noktaları, paralel bağlantı noktaları, ses kartları.)
- `b` Blok cihaz dosyasını temsil eder. (Örneğin; sabit disk, usb diskler ve usb kameralar..)

İzin tanımlamasının geri kalanını üç grup haline ele almamız gerekiyor. 

### İlk Grup | Dosya-Dizin Sahibi

İlk grup dosya ya da dizini oluşturan kişinin sahip olduğu izinleri temsil ediyor. 

### İkinci Grup | Dahil Olduğu Grup

İkinci grup ise dosyayı oluşturan kişinin dahil olduğu gruptaki herkesin sahip olduğu izinleri temsil ediyor.

### Üçüncü Grup | Diğer Kullanıcılar

Üçüncü grup ise dosyayı oluşturmamış ve dosyayı oluştan kişi ile aynı grupta olmayan diğer herkesin sahip olduğu izinleri temsil ediyor.

Tüm bu izinler dosya ve dizinler için önceden tanımlanmış olan standartlar dahilinde oluşturuluyor. 

Grupların izinlerinde yer alan "`r`" "`w`" "`x`" ifadelerinin anlamları da aşağıdaki şekildedir;

`r` = "read" yani "okuma" iznini temsil eder. Bu izne sahip olanlar ilgili dosya içeriği okuyabilir ve dizinleri listeleyip görüntüleyebilir. Simgesel gösterimi dışında sayısal olarak "`4`" rakamı ile temsil edilir.

`w` = "write" yani "yazma" iznini temsil eder. Bu izne sahip olanlar, dosya içeriğinde değişiklik yapabilir ve mevcut dizin üzerinde değişiklik yapabilir. Simgesel gösterimi dışında sayısal olarak "`2`" rakamı ile temsil edilir.

`x` = "execute" yani "çalıştırma" iznini temsil eder. Bu izne sahip olanlar, çalıştırılabilir olan dosyaları çalıştırma ve dizin içeriğine geçiş yapabilme yetkisine sahip olurlar. Simgesel gösterimi dışında sayısal olarak "`1`" rakamı ile temsil edilir.

### Standart Dizin İzinleri

Yeni oluşturulan standart dizinlerin yetkisi "`rwxr-xr-x"` şeklindedir. Bu izinin anlamı;

**Dizin sahibi;** okuyabilir(`r`), yazabilir(`w`), çalıştırabilir(`x`) = `rwx`

**Aynı gruptakiler;** okuyabilir(`r`), yazamaz(`-`), çalıştırabilir(`x`) = `r-x`

**Diğer kullanıcılar;** okuyabilir(`r`), yazamaz(`-`), çalıştırabilir(`x`) = `r-x`

### Standart Dosya İzinleri

Yeni oluşturulan standart dosyaların yetkisi "`rw-r--r--`" şeklindedir. Bu izinin anlamı;

**Dosya sahibi;** okuyabilir(`r`), yazabilir(`w`), çalıştıramaz(`-`) = `rw-`

**Aynı gruptakiler;** okuyabilir(`r`), yazamaz(`-`), çalıştıramaz(`-`) = `r--`

**Diğer kullanıcılar;** okuyabilir(`r`), yazamaz(`-`), çalıştıramaz(`-`) = `r--`

Biz değiştirmediğimiz sürece yeni oluşturulan tüm dosya ve dizinler belirtilmiş olan standart iziler dahilinde oluşturulur. Mevcut izinleri maskeleyip standart dosya ya da dizin izinleri tanımlamamızı sağlayan yapı da `umask` yapısıdır. Daha net kavramak adına açıklamaya devam edelim.

## **Umask'ı anlamak**

Dosya ve dizinlerin oluşturulma esnasında sahip olacakları izinleri `umask` sayesinde kısıtlayabiliyoruz. Devam etmeden önce mevcut `umask` değerini görmek adına komutumuzu girelim.

```bash
taylan@taylan:~$ umask
0022
taylan@taylan:~$
```

Aldığımız "0022" çıktısı hangi izinlerin maskelenerek kısıtlanacağını belirtiyor. Yani aslında bu maske değeri "gruptaki" ve "diğer kullanıcıların" "2" ile temsil edilen "yazma yetkisini" geçersiz kılmayı sağlıyor. 

```bash
taylan@taylan:~$ umask
0022
||||
|||+----------------------------> Diğer kullanıcılardan eksiltilecek izin numarası
||+-------------------------------> Aynı gruptaki kullanıcılardan eksiltilecek izin numarası
|+----------------------------------> Dizin sahibinden eksiltilecek izin numarası
+------------------------------------> Sekizlik sayı göstermi için gereken "0"
```

Normal şartlarda dosyalar "666", dizinler ise "777" yetkilerine sahiptirler. 0022 değeriyle maskeleme işleminin ardından dosyaların yetkisi "644" olarak kalırken, dizinlerin yetkisi "755" olarak kalır. Çünkü `umask` yapısına atanmış olan izinler aslında çıkarılacak olan izinleri temsil ediyor. Sayısal izin karşılıklarını simgesel ve anlamsal olarak açıkladığımızda dosya ve dizinlerin oluşturulurken sahip olduğu varsayılan izinleri ortaya çıkıyor. Ayrıca istersek, çıkarılacak olan izinlerin simgesel karşılıklarını görmek için `-S` seçeneğini de kullanabiliriz.

```bash
taylan@taylan:~$ umask -S
u=rwx,g=rx,o=rx
taylan@taylan:~$
```

Kısıtlama işleminin nasıl çalıştığını deneyimlemek için yeni bir `umask` tanımlaması yapalım ve yeni oluşturulan dosya ve dizinlerin hangi yetkilere sahip olduğuna bakalım.

Örneğin `umask 077` komutunu girersek, dosya sahibi dışındaki hiç kimsenin hiç bir yetkisi olmayacaktır. 

```bash
taylan@taylan:~/test$ umask 077
taylan@taylan:~/test$ umask
0077
taylan@taylan:~/test$ mkdir yeni-dizin
taylan@taylan:~/test$ touch yeni-dosya
taylan@taylan:~/test$ ls -l
toplam 8
drwxr-xr-x 2 taylan taylan 4096 Eyl 19 18:38 dizin
-rw-r--r-- 1 taylan taylan    0 Eyl 19 18:39 dosya
drwx------ 2 taylan taylan 4096 Eyl 20 20:28 yeni-dizin
-rw------- 1 taylan taylan    0 Eyl 20 20:28 yeni-dosya
taylan@taylan:~/test$
```

Çıktılara göz attığımızda `umask` komutunun varsayılan izinleri atarken aslında izinleri maskeleme yani kendisine belirtilen rakamlar doğrultusunda silme yöntemi ile bu işi yaptığını da teyit edebiliyoruz. İzin kısıtlamalarını dilersek sayılar yerine doğrudan izin sembolleri ile de tanımlayabiliriz. Örnek için aşağıdaki çıktıları inceleyebilirsiniz.

```bash
taylan@taylan:~$ umask u=rwx,g=r,o=
taylan@taylan:~$ umask
0037
taylan@taylan:~$ umask -S
u=rwx,g=r,o=
taylan@taylan:~$
```

Tüm bu değişiklikler yalnızca mevcut kabuk üzerinde geçerli olacağı için, kabuk kapatılırken yaptığımız ayarlama de silinmiş olacak. Eğer dosya ve dizinlerin varsayılan yetki ayarlarını kalıcı olarak tanımlamak isterseniz oturum başlangıcında okunan .bashrc gibi konfigürasyon dosyalarından birine ilgili eklemeyi yapabilirsiniz.

## Ek Not:

Ek olarak yeni oluşturulan tüm sembolik bağlantılar varsayılan olarak herkese açık yetkilere(lrwxrwxrwx) sahiptirler. Bu durumun nedeni aslında sembolik bağlantının sahip olduğu yetkinin bir öneminin olmamasıdır. Sembolik bağlantının tek görevi sembolik olarak orada bulunup, kaynak dosyaya yönlendirme yapmaktır. Yani aslında tek işlevi kaynak dosyanın adresi bilmektir. İlgili adrese yönlendirilen kullanıcılar kendi yetkileri dahilinde dosya üzerinde işlem yapabilirler. Bu durumu gözlemleyebilmek için yetkisi olmayan bir kullanıcı hesabı ile kaynak dosyayı ve sembolik dosyayı okumayı deneyelim. (Geçiş yaptığım "ali" kullanıcısının kaynak dosya üzerinde hiçbir yetkisi yok.)

```bash
taylan@taylan:~/Belgeler$ ls -l
toplam 4
-rwx------ 1 taylan taylan 13 Eki  6 08:02 metin.txt
lrwxrwxrwx 1 taylan taylan  9 Eki  6 08:27 sembolik-link -> metin.txt
taylan@taylan:~/Belgeler$ su ali
Parola: 
ali@taylan:/home/taylan/Belgeler$ cat metin.txt 
cat: metin.txt: Erişim engellendi
ali@taylan:/home/taylan/Belgeler$ cat sembolik-link 
cat: sembolik-link: Erişim engellendi
```

Çıktılardan da görebildiğiniz gibi sembolik bağlantının hangi yetkiye sahip olduğunun kaynak dosya üzerinde hiç bir önemi yoktur. Zaten sembolik bağlantının izinleri de değiştirilemezdir. Eğer yetkili kullanıcıysanız ve sembolik bağlantının yetkilerini değiştirmeye çalışırsanız kaynak dosyanın yetkilerini değiştirmiş olursunuz. Aşağıdaki örneğe bakarak bu durumu kendiniz de teyit edebilirsiniz.

```bash
taylan@taylan:~/Belgeler$ ls -l
toplam 4
-rwx------ 1 taylan taylan 13 Eki  6 08:02 metin.txt
lrwxrwxrwx 1 taylan taylan  9 Eki  6 08:27 sembolik-link -> metin.txt
taylan@taylan:~/Belgeler$ chmod 000 sembolik-link 
taylan@taylan:~/Belgeler$ ls -l
toplam 4
---------- 1 taylan taylan 13 Eki  6 08:02 metin.txt
lrwxrwxrwx 1 taylan taylan  9 Eki  6 08:27 sembolik-link -> metin.txt
taylan@taylan:~/Belgeler$
```

Sembolik bağlantı üzerindeki yetki değiştirme denemesinin ardından aslında kaynak dosyanın tüm yetkilerinin sıfırlandığını çıktılarda görebiliyoruz. (Elbette sembolik bağlantı üzerinden kaynak dosyanın yetkisinin değiştirilebilmesi için de dosyanın sahibi ya da en yetkili "root" kullanıcısı olmanız gerekir.)

Tahmin edebileceğiniz gibi sembolik bağlantıların yetkileri bu şekilde olmasaydı sistem güvenliği sağlanamazdı. Sembolik bağlantılar, kaynak dosyanın nerede olduğunu herkesin bilmesine izin vermek için varsayılan olarak herkese açık yetkilere sahiptir. Neticede asıl önemli olan kaynak dosyanın sahip olduğu erişim izinleridir.