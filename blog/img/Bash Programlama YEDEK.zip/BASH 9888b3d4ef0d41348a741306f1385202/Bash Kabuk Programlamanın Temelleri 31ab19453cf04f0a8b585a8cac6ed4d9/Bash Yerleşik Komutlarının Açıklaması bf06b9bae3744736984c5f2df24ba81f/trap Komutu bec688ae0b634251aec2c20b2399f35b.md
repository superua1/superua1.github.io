# trap Komutu

Kabuğa gönderilmiş olan sinyallerin yakalanmasını sağlar. Zaten komutun ismi de İngilizce "**trap**" yani "**tuzak**" ifadesinden gelir. İlgili sinyal yakalandıktan sonra gerçekleştirilmesi gereken işlem `trap` komutunun ardından argüman olarak belirtilebilir. 

Kullanımı `trap ARGUMAN SİNYAL` şeklindedir.

Temel olarak kullanılan sinyaller açıklamalarıyla birlikte aşağıdaki şekildedir;

`EXIT` : Mevcut kabuktan çıkılırken ilgili argümanın çalıştırılmasını sağlar.(`0` sinyal numarası ile de belirtilebilir.)

`DEBUG` : Her standart komuttan önce ilgili argümanın çalıştırılmasını sağlar.

`RETURN` : Fonksiyonların ya da harici dosyaların(kütüphane fonksiyonları) içeri aktarılmasının(`source` ya da `.` komutu ile) ardından ilgili argümanın çalıştırılmasını sağlar.

`ERR` : Hatalı komutların ardından ilgili argümanın çalıştırılmasını sağlar.(0 haricindeki tüm çıkış değerleri hatalı olarak kabul edilir.)

Kullanımlarını kavramak adına basit örnekler yapalım.

`EXIT` sinyali için;

```bash
trap "echo 'Çıkış sinyali gönderildi!'" EXIT
echo "İlk Komut"
exit
echo "Son Komut"
```

```bash
taylan@taylan:~$ bash hata
İlk Komut
Çıkış sinyali gönderildi!
taylan@taylan:~$
```

```bash
trap "echo 'Çıkış sinyali gönderildi!'" EXIT
echo "İlk Komut"
echo "Son Komut"
```

```bash
taylan@taylan:~$ bash betik.sh 
İlk Komut
Son Komut
Çıkış sinyali gönderildi!
taylan@taylan:~$
```

`DEBUG` sinyali için;

```bash
trap "echo 'Komut girildi.'" DEBUG
echo "İlk Komut"
whoami
olmayan_komut
echo "Son Komut"
```

```bash
taylan@taylan:~$ bash betik.sh 
Komut girildi.
İlk Komut
Komut girildi.
taylan
Komut girildi.
betik.sh: satır 4: olmayan_komut: komut yok
Komut girildi.
Son Komut
taylan@taylan:~$
```

Çıktıları incelediğinizde DEBUG sinyalinin her komuttan önce `trap` ile yakalandığını görebilirsiniz.

`RETURN` sinyali için;

Fonksiyonların işi bittiğinde en son komutun çıkış değerini `return` olarak geçen çıkış kodu olarak döndürdüğünü biliyoruz. İşte `RETURN` sinyali de fonksiyonların işi bittiğinde gönderilen sinyaldir.  Fonksiyonlar üzerinde `DEBUG` ve `RETURN` sinyallerinin eksiksiz olarak yakalanabilmesi için "functrace" seçeneğinin aktifleştirilmiş olması gerekir. Aksi halde mevcut fonksiyonların ürettikleri sinyaller yakalanamaz. 

```bash
set -o functrace
trap "echo 'Return yakalandı !'" RETURN 
echo "Bu ilk komut"
fonksiyon(){
  echo "Ben fonksiyonum."
  return
}
fonksiyon
source lib_func
echo "Bu da son komut"
```

Çıktı;

```bash
taylan@taylan:~$ bash betik.sh 
Bu ilk komut
Ben fonksiyonum.
Return yakalandı !
Ben 'lib_func' dosyası içerisindeki komutum ve çalıştım !
Return yakalandı !
Bu da son komut
taylan@taylan:~$
```

"functrace" yani "T" seçeneği olmadan aynı betik dosyası çalıştırıldığında `DEBUG` ya da `RETURN` sinyallerinin yakalanamadığını teyit edebilirsiniz.

`ERR` sinyali için;

```bash
trap "echo 'Hatalı komut verildi !'" ERR
echo "İlk Komut"
olmayan_komut
echo "Son Komut"
```

```bash
İlk Komut
hata: satır 3: olmayan_komut: komut yok
Hatalı komut verildi !
Son Komut
```

Bunlar haricinde yakalayabileceğimiz sinyallerin hangileri olduğunuz görmek için `kill-l` komutu haricinde `trap -l` komutunu da kullanabiliriz.

```bash
taylan@taylan:~$ trap -l
 1) SIGHUP       2) SIGINT       3) SIGQUIT      4) SIGILL       5) SIGTRAP
 6) SIGABRT      7) SIGBUS       8) SIGFPE       9) SIGKILL     10) SIGUSR1
11) SIGSEGV     12) SIGUSR2     13) SIGPIPE     14) SIGALRM     15) SIGTERM
16) SIGSTKFLT   17) SIGCHLD     18) SIGCONT     19) SIGSTOP     20) SIGTSTP
21) SIGTTIN     22) SIGTTOU     23) SIGURG      24) SIGXCPU     25) SIGXFSZ
26) SIGVTALRM   27) SIGPROF     28) SIGWINCH    29) SIGIO       30) SIGPWR
31) SIGSYS      34) SIGRTMIN    35) SIGRTMIN+1  36) SIGRTMIN+2  37) SIGRTMIN+3
38) SIGRTMIN+4  39) SIGRTMIN+5  40) SIGRTMIN+6  41) SIGRTMIN+7  42) SIGRTMIN+8
43) SIGRTMIN+9  44) SIGRTMIN+10 45) SIGRTMIN+11 46) SIGRTMIN+12 47) SIGRTMIN+13
48) SIGRTMIN+14 49) SIGRTMIN+15 50) SIGRTMAX-14 51) SIGRTMAX-13 52) SIGRTMAX-12
53) SIGRTMAX-11 54) SIGRTMAX-10 55) SIGRTMAX-9  56) SIGRTMAX-8  57) SIGRTMAX-7
58) SIGRTMAX-6  59) SIGRTMAX-5  60) SIGRTMAX-4  61) SIGRTMAX-3  62) SIGRTMAX-2
63) SIGRTMAX-1  64) SIGRTMAX
taylan@taylan:~$
```

Bu sinyallerden SIGTSTP sinyalini Ctrl + Z, SIGINT sinyalini ise Ctrl + C kısayol tuşlaması ile konsola göndermemiz mümkündür. Bizler de şimdi hem kısayol ile sinyal gönderimini hem de nasıl yakalanacağını kavramak adına basit bir örnek yapalım. Ctrl + Z tuşlaması ile çıkış sinyali(SIGTSTP) gönderildiğinde, konsola "Ctrl + Z tuşlaması yaptınız ! " çıktısının basılmasını sağlayalım.

```bash
trap "echo 'Ctrl + Z tuşlaması yaptınız ! '" SIGTSTP
trap "echo 'Ctrl + C tuşlaması yaptınız ! '" SIGINT
sleep 5

```

Yukarıdaki betik dosyası çalıştırıldığında Ctrl + C yani **INT**(kesme-durdurma sinyali) sorunsuzca çalışacak fakat Ctrl + Z yani **TSTP**(duraklatma) sinyali beklediğimiz çıktıyı vermeyecek. Bu durumun nedeni bash kabuğunun, harici bir komutun bitmesini beklerken herhangi bir tuzak çalıştırmıyor olmasıdır. Harici komutun süreci bittikten sonra ilgili sinyale göre sonraki işlem yapılır. `sleep` komutu harici bir komut yani bash içerisinde yerleşik(builtin) değil. **INT** sinyali süreci kesme işlevinde olduğu için sinyal alındığında `sleep` komutu üzerinde etkili oluyor ve `sleep` komutunun süreci sonlandıktan sonra diğer komutlar çalıştırılıyor. **TSTP** sinyali ise mevcut süreci duraklattığı için devam ettirene kadar bir sonraki sürece geçilemiyor dolayısı ile betik dosyası konsoldan girilen hiç bir ifadeye yanıt vermiyor. Neticede bir sonraki sürecin çalıştırılabilmesi ve sürece sinyal gönderilebilmesi için mevcut sürecin bitmesi gerekiyor. Bu durumun bash içerisindeki yerleşik komutlar üzerinde etkili olmadığını yani sinyal gönderimi için yerleşik komutların bitmesinin beklenmediğini de aşağıdaki çıktıya bakarak teyit edebilirsiniz.

Ayrıca bu sorunu açmak için job control olarak geçen iş kontrolü özelliğini etkinleştirmeniz de yeterlidir. Bu sayede duraklatılmış olan işlem iş kontrolü tarafından kabuğa bildirileceği için sonraki komutlar çalışmaya devam edebilir. Yani eğer betik dosyası içerisinde set -m komutu ile iş kontrolünü aktifleştirirsek TSTP sinyali ile durdurulmuş olan süreç betiğin yanıt vermemesine neden olmaz. Çünkü durdurma durumu iş kontrolü tarafından kontrol edilir.

## Birden Fazla Sinyalin Yakalanması

Biz örneklerimizde sinyallerin tek ve yalnızca isimleriyle tanımladık. Fakat sinyalleri numaraları ile ya da birden fazla sinyali aynı anda belirtmemiz de mümkündür. Aşağıdaki tanımlamalar SIGINT(2) SIGQUIT(3) SIGTERM(15) sinyallerinin üçünü de birden kapsayacaktır.

```bash
trap "Sinyal yakalandı" SIGINT SIGQUIT SIGTERM
```

```bash
trap "Sinyal yakalandı" 2 3 15
```

## Tuzakların Kapsamı

Fark ettiyseniz örnekler sırasında `trap` komutunu betik dosyasının en başında tanımladım. Betik dosyası baştan sonra sıralı şekilde çalıştırıldığı için `trap` işlevinin en başta yer alması tüm betik içeriğindeki sinyalleri yakalayabilmesini sağlar. Sizler de programlama yaparken hangi bölümden itibaren sinyallerin yakalanmasını istiyorsanız ona göre `trap` işlevini konumlandırabilirsiniz. Ayrıca bölgesel olarak trap komutunun işlevini kapatmanız da mümkündür. Betik dosyası içerisinde kapsama alanı dışında tutmak istediğimiz bölümü `trap` komutunun argüman kısmına `-` kısa çizgi ya da boş bırakarak tanımlayabiliriz. Betik dosyası bu komutu okuduktan sonra önceki sinyal tuzaklarını sıfırlayarak devam eder. Aşağıdaki ifadenin geçtiği bölümden sonraki kısımlarda ilgili sinyaller yakalanmazlar.

Örneğin

```bash
trap "Sinyal yakalandı !" SIGINT SIGQUIT SIGTERM #bu bölümden sonra ilgili sinyaller yakalanabilir.
echo "test" 
echo "test 2"
trap - SIGQUIT SIGTERM #bu bölümden sonra ilgili sinyaller yakalanamaz.
echo "test 3"
echo "test 4"
```

## Sinyallerin Engellenmesi

Eğer ilgili sinyal yakalandıktan sonra herhangi bir işlem yapılmasın ve yalnızca sinyalin işlevi engellensin istersek, `trap` komutunun argüman kısmına içerisi boş tırnak işareti ekleyebiliriz.

Örneğin;

```
trap " " 2 3 15 #sinyaller sayılar ile belirtilebilir 
trap " " SIGINT SIGQUIT SIGTERM #sinyaller yazılı ifadeler ile belirtilebilir 
```

## Tanımlı Tuzakların Listelenmesi

Tanımlanmış olan yakalanacak sinyallerin listesini almak için `trap -p` komutunu kullanabiliriz.

```bash
taylan@taylan:~$ trap -p
trap -- 'echo '\''Ctrl + Z tuşlaması yaptınız ! '\''' SIGINT
taylan@taylan:~$
```

## Fonksiyon İçerisindeki Sinyallerin Yakalanması

Fonksiyonların çıkış değerine göre hareket edildiği için fonksiyon dışında tanımlanmış olan `trap` komutu, fonksiyonun çıkış durumuna göre hareket edeceği için beklenmeyen sonuçlar verebilir.

Çünkü özellikle belirtilmediği sürece fonksiyon içerisindeki komutlar tek tek değerlendirilmez, yalnızca fonksiyonun çıkış koduna göre sinyal yakalama işlemi uygulanır. Bahsedilmiş olduğumuz durumu aşağıdaki örneğe bakara görebilirsiniz.

Örneğin biz fonksiyon içerisinde yer alan hatalı komutları yakalayıp uyarıda bulunmak istersek aşağıdakine benzer bir yapı kurabiliriz.

```bash
#!/bin/bash
trap 'tuzak $? $LINENO' ERR
tuzak() {
  echo "Hata Kodu: $1 Satır No: $2"
}
fonksiyon() {
  olmayan_komut
  echo "Ben fonksiyonum ve çalıştım !"
}
fonksiyon
```

Herhangi bir sorun yokmuş gibi dursa da betik dosyasını çalıştırdığımızda hatalı komut tuzağa takılmıyor.

```bash
taylan@taylan:~$ bash betik.sh 
betik.sh: satır 7: olmayan_komut: komut yok
Ben fonksiyonum ve çalıştım !
```

Burada sorunu oluşturan durum, fonksiyon içerisindeki komutların tek tek değerlendirilmeyip yalnızca fonksiyon içerisinde en son çalıştırılan komutun çıkış durumu dikkate almasıdır. Bu durumda hatanın yakalanabilmesi için hatalı komutun fonksiyonun sonunda yer alması gerekir.

```bash
#!/bin/bash
trap 'tuzak $? $LINENO' ERR
tuzak() {
  echo "Hata Kodu: $1 Satır No: $2"
}
fonksiyon() {
  echo "Ben fonksiyonum ve çalıştım !"
  olmayan_komut
}
fonksiyon
```

Betik dosyasının çıktısı aşağıdaki gibidir;

```bash
taylan@taylan:~$ bash betik.sh 
Ben fonksiyonum ve çalıştım !
betik.sh: satır 8: olmayan_komut: komut yok
Hata Kodu: 127 Satır No: 10
taylan@taylan:~$
```

Çıktıyı incelediğinizde hatanın, fonksiyonun çağırıldığı satırda meydana geldiği belirtiliyor çünkü bu durumda yalnızca fonksiyonun döndürdüğü en son çıkış değeri dikkate alınıyor. Bu duruma çözüm olarak `set -E` seçeneği ile ERR sinyali fonksiyon içerisinde de geçerli olur. Şimdi bu özelliğin ne işe yaradığını teyit etmek adına aynı örneği bu özellik aktifken deneyelim.

```bash
#!/bin/bash
set -E
trap 'tuzak $? $LINENO' ERR
tuzak() {
  echo "Hata Kodu: $1 Satır No: $2"
}
fonksiyon() {
  olmayan_komut0
  echo "Ben fonksiyonum ve çalıştım !"
  olmayan_komut
  olmayan_komut2
}
fonksiyon
```

Çıktılar;

```bash
taylan@taylan:~$ bash betik.sh 
betik.sh: satır 8: olmayan_komut0: komut yok
Hata Kodu: 127 Satır No: 8
Ben fonksiyonum ve çalıştım !
betik.sh: satır 10: olmayan_komut: komut yok
Hata Kodu: 127 Satır No: 10
betik.sh: satır 11: olmayan_komut2: komut yok
Hata Kodu: 127 Satır No: 11
Hata Kodu: 127 Satır No: 13
taylan@taylan:~$
```

Gördüğünüz gibi fonksiyon içerisinde bulunan hatalı komutlar da `trap` tarafından yakalanmış oldu.

## Yakalanamayan-Engellenemeyen Sinyaller

SIGKILL ve SIGSTOP sinyalleri yakalanamaz, engellenemez ve yoksayılamaz. Bu sayede gerektiğinde ilgili betik sürecinin sonlandırılması mümkün olur.

Özellikle bash programlama yaparken `trap` komutu sık kullanılır. Yine de hangi sinyali hangi durumda kullanacağınıza iyi karar vermelisiniz ve mutlaka pek çok farklı durum için bu sinyallerin nasıl çalıştığını test etmelisiniz. Aksi halde sinyalleri yakalama konusunda beklediğinizden farklı sonuçlar oluşabilir.