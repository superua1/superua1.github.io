# suspend Komutu

Mevcut kabuğu askıya almak için `suspend` komutunu kullanabiliriz. Normal şartlarda, mevcut kabuk üzerinde başlatılmış olan herhangi bir işlemi durdurmak için Ctrl + Z tuşlaması ile ya da `kill` komutu yardımıyla SIGNSTP sinyalini gönderebiliriz. Fakat mevcut kabuğu bu şekilde askıya almamız mümkün değildir. Bu durum için `suspend` komutunu kullanırız. Hemen denemek için yeni bir çocuk kabuk oluşturup bu kabuğu süreç numarası ile askıya almayı deneyelim.

```bash
taylan@taylan:~$ bash
taylan@taylan:~$ ps f
    PID TTY      STAT   TIME COMMAND
   2722 pts/0    Ss     0:00 /bin/bash
   2725 pts/0    S      0:00  \_ bash
   2735 pts/0    R+     0:00      \_ ps f
taylan@taylan:~$ kill STP 2725
bash: kill: STP: argümanlar süreç veya iş kimlikleri olmalı
taylan@taylan:~$
```

Gördüğünüz gibi yeni oluşturduğumuz ve üzerinde çalışmakta olduğumuz kabuğu askıya alamadık. Şimdi aynı örneği `suspend` komutu ile tekrar edelim.

```bash
taylan@taylan:~$ suspend
[1]+  Durdu                   bash
taylan@taylan:~$ jobs -l
[1]+  2725 Durduruldu (sinyal)     bash
taylan@taylan:~$
```

Görebildiğiniz gibi `suspend` komutunun ardından mevcut bash kabuğu askıya alındı ve biz bir önceki ana kabuktan çalışmaya devam ettik. İşte sizler de bu şekilde mevcut kabuğu askıya alıp ana kabuktan işlem yapabilir ve gerektiğinde tekrar kabuk işlemini `fg` komutu ile ön plana alarak çocuk kabuktan çalışmaya devam edebilirsiniz. Gerçek hayattaki kullanımına bir örnek vermemiz gerekirse; örneğin root yetkilerine sahip bir çocuk kabuk oluşturdunuz ve gerektiğinde root yetkisi dışında bir işlem yapmak için mevcut kabuğu kapatmadan ana kabuğa geçmek istediğinizde kullanabilirsiniz. Bu durumu aşağıdaki çıktıları inceleyerek daha net görebilirsiniz. 

```bash
taylan@taylan:~$ whoami
taylan
taylan@taylan:~$ sudo bash
[sudo] password for taylan: 
root@taylan:/home/taylan# whoami
root
root@taylan:/home/taylan# suspend

[1]+  Durdu                   sudo bash
taylan@taylan:~$ whoami
taylan
taylan@taylan:~$ fg
sudo bash
root@taylan:/home/taylan# whoami
root
root@taylan:/home/taylan#
```

Ek olarak oturum açma kabukları yalnızca `suspend` komutu ile askıya alınamaz. Oturum açma kabuklarını durdurmak için `suspend` komutunun `-f` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ bash --login
taylan@taylan:~$ suspend
bash: suspend: bir oturum açma kabuğu engellenemez
taylan@taylan:~$ suspend -f

[1]+  Durdu                   bash --login
taylan@taylan:~$
```

Oturum açma kabuğu da ne anlama geliyor diyorsanız, bu konuyu kabuğun ortam özellikleri ve modları bölümünde ayrıca ele alıyor olacağız.