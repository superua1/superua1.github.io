# history Komutu

Mevcut konsol üzerinde girilen kayıtların hepsi önbelleğe alınıp tutuluyor ve konsol kapatılırken kayıt dosyasına yazılıyor.

Kabuğa girmiş olduğumuz komutlar daha sonra tekrar ulaşabilmemiz için "history" yani "geçmiş" adı altında liste şeklinde depolanıyor.  `history` komutu da bizlere geçmiş listesini görüntüleyip düzenleyebilme olanağı tanıyor. Öncelikle `history` komutunun nasıl kullanıldığına göz atıp daha sonra geçmişteki komutları nasıl tekrar kullanabileceğimize değinelim.

## Kabuğa Girilmiş Olan Geçmiş Komutları Listelemek

Bash kabuğuna girmiş olduğumuz komutlar mevcut kabuk kapatılırken, ev dizinimiz(/home/kullanıcı-adı) altındaki .bash_history isimli bir dosyaya otomatik olarak kayıt olur. Geçmiş kayıtlarına ulaşmak için bu dosyayı açıp okuyabileceğimiz gibi yalnızca `history` komutunu girerek de kayıtlı geçmiş komutlarına ulaşmamız mümkündür.

Eğer en son girilen belirli sayıdaki komutları görüntülemek isterseniz `history` komutunun ardından, sondan kaç komutu listelemek istediğinizi belirtebilirsiniz. Örneğin sondan 5 komutu listelemek için `history 5` komutu kullanılır.

```bash
taylan@taylan:~$ history 5
 1416  whoami
 1417  date
 1418  lsb_release 
 1419  pwd
 1420  history 5
taylan@taylan:~$
```

Geçmiş listesindeki komutların isimleri ile arama yapmak istersek `grep` komutundan yardım alabilir ya da Ctrl + R tuşlaması ile geçmiş kayıtları üzerinden araştırma yapabiliriz.

Örneğin içerisinde `disown` ifadesinin geçtiği geçmişteki komutları listelemek için aşağıdaki iki yöntemi de kullanabilirim.

```bash
taylan@taylan:~$ history | grep "disown"
1005  disown -a
 1010  disown -a
 1014  disown --help
 1020  disown -r
 1022  gedit & disown 
 1028  disown 1613
 1037  disown %2
 1039  disown %%
 1430  history | grep "disown"
taylan@taylan:~$
```

Grep komutu haricinde **Ctrl + R** tuşlamasının ardından "disown" ifadesini yazarsam, içerisinde "disown" ifadesi geçen en son kaydedilmiş komut bana öneri olarak sunulacaktır. Eğer aradığım komut bu değilse diğer kayıtlara bakmak için tekrar tekrar **Ctrl + R** tuşlamasına basabilirim.

```bash
(reverse-i-search)`disown': history | grep "disown"
#tekrar Ctrl + R tuşlamsına basarak önceki kayıta geçil yapabiliriz.
(reverse-i-search)`disown': disown %2
```

Aradığımız komuta ulaştığımızda enter harici herhangi bir tuşa basarak komutun konsola kopyalanmasını sağlayabilir ve eğer istersek komutu düzenleyip tekrar kullanabiliriz. Eğer geçmiş kayıtlarından aradığımız komuta ulaştığımızda doğrudan enter tuşuna basarsak da ilgili komut hiç düzenlenmeden çalıştırılmış olur.

## Sıra Numarası ile Geçmiş Komut Kayıtlarını Görüntülemek

İlgili sıra numarasında hangi komutun yer aldığını görmek için `-p` seçeneğini kullanabiliriz. Çağırma işlemi için ilgili komutun sıra numarasının başında "`!`" ünlem işareti yer alması gerekiyor. Buradaki ünlem işareti `history` komutu için, listeden komut getirmesi gerektiğini belirten özel karakterdir. Hemen denemek için geçmiş listesinde yer alan bir komutu çıktı olarak bastıralım.

```bash
taylan@taylan:~$ history 5
   81  ls
   82  pwd
   83  whoami
   84  echo "deneme metni"
   85  history 5
taylan@taylan:~$ history -p !84
history -p echo "deneme metni"
echo
deneme metni
```

Gördüğünüz gibi daha önce girilmiş olan komut, kayıt numarası üzerinden konsola bastırılmış oldu. Hatta girdiğimiz komuttaki argümanların ayrı ayrı bastırıldığını fark edebiliyoruz. Dilersek özellikle hangi sıradaki argüman basılacağını da belirtmemiz mümkündür. 

```bash
taylan@taylan:~$ history 5
   81  ls
   82  pwd
   83  whoami
   84  echo "deneme metni"
   85  history 5
taylan@taylan:~$ history -p !84:1
history -p "deneme metni"
deneme metni
taylan@taylan:~$
```

Listeden komutları çağırıp konsola bastırma işlemi için kullanmış olduğumuz ünlem işaretini, daha sonra komutları tekrar çağırıp çalıştırmak için de kullanıyor olacağız. Zaten ünlem işaretinin `history` komutu için listeden bulup getirme işlevinde olduğunu belirtmiştik.

## Mevcut Kabuktaki Geçmiş Komutları Geçmiş Dosyasına Eklemek

Normal şartlarda kabuğa girmiş olduğumuz komutlar yalnızca kabuk kapatılırken .bash_history dosyasına kaydoluyor. Kapatmadığımız sürece mevcut kabuktaki geçmiş komutların hepsi geçici olarak tamponda tutuluyor. Durum böyle olunca mevcut kabuk kapatılmadan yeni başlatılan kabuklar üzerinden ilgili geçmiş komutlarına ulaşamıyoruz. Eğer mevcut kabukta girdiğimiz komutlar .bash_history kayıtlarına anında geçsin istersek `history -a` seçeneğini kullanabiliriz. Bu komutun ardından mevcut kabuk üzerindeki geçmiş komutlar kayıt dosyasına(.bash_history) aktarılmış olacak. 

Bu durumu teyit etmek için mevcut kabuğumuza birkaç yeni komut girelim ve yeni bir alt kabuk başlatıp bu kabuk üzerinden en son üç komutu listelemeyi deneyelim.

```bash
taylan@taylan:~$ echo "bu"
bu
taylan@taylan:~$ echo "bir"
bir
taylan@taylan:~$ echo "denemedir"
denemedir
taylan@taylan:~$ bash    #yeni bir alt kabuğa geçiş yaptık.
taylan@taylan:~$ history 3
 1003  whoami
 1004  pwd
 1005  history 3
taylan@taylan:~$
```

Görebildiğiniz gibi bir üst kabukta girmiş olduğumuz komutlar geçmiş kayıtlarına geçmemiş, dolayısı ile yeni bir alt kabuk başlattığımızda bu komutları göremiyoruz. Şimdi aynı örneğini `history -a` komutu ile kayıtların anında geçerli olmasını sağlayarak deneyelim.

```bash
taylan@taylan:~$ echo "bu"
bu
taylan@taylan:~$ echo "bir"
bir
taylan@taylan:~$ echo "denemedir"
denemedir
taylan@taylan:~$ history -a
taylan@taylan:~$ bash     #yeni bir alt kabuğa geçiş yaptık.
taylan@taylan:~$ history 5
 1012  echo "bu"
 1013  echo "bir"
 1014  echo "denemedir"
 1015  history -a
 1016  history -5
```

Çıktılara göz attığımızda `history -a` komutunun tam da tarif ettiğimiz şekilde çalıştığını teyit edebiliyoruz. 

## Geçmiş Dosyasını Yeniden Okumak

Normalde mevcut kabuk üzerindeki geçmiş komutları, kabuk ilk açıldığı anda geçmiş listesinden okunmuş olanlar ve mevcut kabuk üzerinde girilmiş olanlardan ibarettir. Mevcut kabuk üzerinde geçmiş listesinin yalnızca kabuk kapatılırken geçmiş dosyasına eklendiğini biliyoruz. Bu sebeple aslında birden fazla kabukla aynı anda çalışırken farkı kabuklarda girilmiş olan geçmiş komutlara ulaşmamız mümkün olmaz. Eğer diğer kabuklardaki geçmiş komutlara da ulaşmak istersek, ilgili kabuktaki geçmiş kaydını `-w` seçeneği ile geçmiş dosyasına kaydettirmemiz gerekiyor. Daha sonra geçmiş dosyasını yani .bash_history dosyasını, mevcut kabuğun tekrar okuması için de `-n` seçeneğini kullanmalıyız. 

Ayrıca `-r` seçeneği ile de geçmiş dosyasındaki kayıtların mevcut kabuğumuz üzerinde okunup geçerli olmasını sağlayabiliriz. 

## Geçmiş Listesini Silmek

Eğer geçmiş listesinde yer alan bir komutu kaldırmak istersek bunun için `-d` seçeneğini kullanabiliriz. Örneğin ben 1039. sırada yer alan bir kaydı silmek istersem bunun için `history -d 1030` komutunu girmem yeterli

```bash
taylan@taylan:~$ history 4
 1037  ls
 1038  pwd
 1039  whoami
 1040  history 4
taylan@taylan:~$ history -d 1039
taylan@taylan:~$ history 4
 1038  pwd
 1039  history 4
 1040  history -d 1039
 1041  history 4
taylan@taylan:~$
```

Eğer listede yer alan tüm ögeleri silmek istersem `-c` seçeneğini `history -c` şeklinde kullanabilirim.

```bash
taylan@taylan:~$ history 5
 1038  pwd
 1039  history 4
 1040  history -d 1039
 1041  history 4
 1042  history 5
taylan@taylan:~$ history -c
taylan@taylan:~$ history 5
    1  history 5
taylan@taylan:~$
```

Elbette bu yaptığımız işlem mevcut kabuk kapatılırken geçmiş dosyasına yazılacağı için hemen geçerli olmasını istersek `history -w` komutu ile kaydetmemiz gerekiyor

## Geçmiş Listesine Doğrudan Komut Ekleme

Henüz komutu kabukta çalıştırmadan geçmiş listesine eklemek istersek `-s` seçeneğini kullanabiliriz. Örnek olması için geçmiş listesine `echo "yeni ekleme"` komutunu ekleyip test edelim.

```bash
taylan@taylan:~$ history -s echo "yeni ekleme"
taylan@taylan:~$ history 
    1  history 5
    2  echo yeni ekleme
    3  history 
taylan@taylan:~$
```

# Komut Geçmişini Özelleştirme

Mevcut oturumumuzda başlatılan kabuklar, ayarlarını ev dizinimizdeki **.bashrc** dosyasından okuyor. Bu sebeple kabuk üzerinde değişiklik yaparken, ilgili değişiklikleri .bashrc dosyası içerisinde belirtmemiz gerekiyor. Eğer yaptığınız değişiklik yalnızca sizin oturumunuzda değil tüm kullanıcılarda geçerli olsun isterseniz **/etc/bash.bashrc** dosyası üzerinde değişiklik yapmanız gerekir.

Değişikliklerin ardından `source ~/.bashrc` komutuyla ayarların mevcut kabuklar üzerinde geçerli olmasını sağlayabilirsiniz. 

### Zaman Damgası Eklemek

Komut geçmişiyle birlikte tarih ve zaman damgasını görüntülemek istiyorsanız, konfigürasyon dosyasına aşağıdaki ifadeyi ekleyerek yapabilirsiniz: 

```bash
HISTTIMEFORMAT='%c '
```

```bash
taylan@taylan:~$ history 
    1  2020-09-09, 21:20:07 ls
    2  2020-09-09, 21:20:08 pwd
    3  2020-09-09, 21:20:10 whoami
    4  2020-09-09, 21:20:14 echo "test"
    5  2020-09-09, 21:20:16 history 
    6  2020-09-09, 21:20:23 export HISTTIMEFORMAT='%F, %T '
    7  2020-09-09, 21:20:33 history 
taylan@taylan:~$
```

### Geçmiş Kaydının Kapasitesini Genişletmek

Eğer geçmişte girdiğiniz daha fazla komutun tutulmasını isterseniz, geriye dönük kaç adet komutun saklanacağını özellikle belirtebilirsiniz. Bunun için konfigürasyon dosyamız olan ~./.bashrc dosyamızı açalım. Dosya içerisinde yer alana HISTSIZE ve HISTFILESIZE değişkenlerine istediğimiz sayıyı belirtmemiz yeterli. Bu iki değer arasındaki farklar aşağıdaki şekildedir.

**HISTSIZE =** mevcut kabuk oturumumuz devam ederken bellekte saklanabilecek azami geçmiş komutların sayısını belirtir. Bellekteki bu kayıtlar mevcut kabuk kapanırken kalıcı history(varsayılan olarak ~/.basrh_history) dosyasına kaydedilir.

**HISTFILESIZE =** daha sonraki oturumlardan da ulaşılabilecek şekilde history dosyasında(varsayılan olarak ~/.basrh_history) saklanabilecek azami komut sayısını belirtir.

Örneğin mevcut kabuk üzerindeki geçmiş 500 komut bellekte tutulsun ve kalıcı history dosyası içerisinde de en fazla 1000 komut tutulabilsin isterseniz aşağıdaki şekilde belirtebilirsiniz.

```bash
HISTSIZE=500
HISTFILESIZE=1000
```

### Kaydetme Biçiminin Kontrol Edilmesi

Girmiş olduğumuz komutların geçmişe kaydedilme şeklini HISTCONTROL değişkeni aracılığıyla kontrol edebiliriz. Bu değişkene atayabileceğimiz seçenekler aşağıdaki gibidir;

- ignorespace = Boşluk karakteri ile başlayan komutları listeye almaz.
- ignoredups = Tekrarlanan komutları listeye almaz, yalnızca benzersiz komutlar kaydolur.
- ignoreboth = Aynı anda "ignoredups" ve "ignorespace" özelliğini temsil eder.
- erasedups = Geçmiş listesinde tekrar eden komut kayıtlarını siler.

Özellikleri tek kullanabileceğiniz gibi aynı anda birden fazla özellik belirtmek için iki nokta üst üste işaretini de kullanabilirsiniz. Örneğin;

```bash
HISTCONTROL=ignorespace:ignoredups
```

Bunun yerine genellikle tek seferde hem boşlukların geçersiz kılınması hem de komut tekrarından kaçınmak için "**ignoreboth"** seçeneği tanımlanır. 

```bash
HISTCONTROL=ignoreboth
```

### Komut Geçmişinin Kayıt Dosyasını Kaydolması

Eğer yazdığımız komutlar konsola kapanırken geçmiş dosyasına kaydolsun istersek konfigürasyon dosyasına `shopt -s histappend` ifadesini eklememiz gerekiyor. Bu sayede komutlar dosyanın sonuna eklenip kaydoluyor. Eğer yeni komutlar dosyaya eklenmesin, mevcut komutların üzerine yazılsın istersek de `shopt` komutunun ardından kullandığımız "`s`" seçeneğini "`u`" olarak değiştirmemiz yeterlidir. 

Yeni komutlar dosya sonuna eklensin; `shopt -s histappend`

Yeni komutlar önceki kayıtların üzerine yazılsın; `shopt -u histappend`

### Belirli Komutların Geçmişe Kaydolmasını Engellemek

Bizim belirteceğimiz komutların geçmiş kayıtlarında yer almasını engelleyebiliriz. Bunun için **HISTIGNORE** değişkenine, engellenmesini istediğimiz komutları aralarında iki nokta üst üste işareti ile belirtmemiz yeterli. Yine de engelleme işleminin tam olarak komut şablonuna uyan komutlar için çalıştığını da belirtmiş olalım. Denemek için `ls` komutunu engelleyip hem `ls` hem de `ls -a` komutunu girelim ve history kayıtlarında hangi komutların yer aldığına göz atalım.

```bash
HISTIGNORE="ls"
```

```bash
taylan@taylan:~/Belgeler$ ls
dosya  klasör
taylan@taylan:~/Belgeler$ ls -a
.  ..  .dosya  dosya  .klasör  klasör
taylan@taylan:~/Belgeler$ history 5
    2  echo "test"
    3  whoami
    4  pwd
    5  ls -a
    6  history 5
taylan@taylan:~/Belgeler$
```

Görebildiğiniz gibi engellediğimiz "`ls`" komutu geçmiş kayıtlarına eklenmedi fakat "`ls -a`" komutu eklenmiş oldu. Bu sebeple engellenecek komutların spesifik olarak belirtilmesinin önemli olduğunu lütfen unutmayın.

### Geçmiş Komutların Kayıt Olacağı Dosya Konumunun Belirtilmesi

Normal şartlarda geçmiş komutlar varsayılan olarak kullanıcının ev dizini altında .bash_history isimli bir dosyada tutuluyor.(Başındaki nokta işareti dosyanın gizli olmasını sağlıyor.) Eğer komut geçmişleri bizim belirleyeceğimiz bir dosyada tutulsun istersek, "HISTFILE" değişkenine hedef dosya ismini belirtmemiz yeterlidir. Fakat istisnai durumlar dışında bu dosyanın değiştirilmesi önerilmez. Çünkü dosya içeriği sizin geçmişte girmiş olduğunuz hassas bilgi içeren komutları da barındırabileceği için hatalı konumlandırma sonucu güvenlik riskleri ortaya çıkabilir.

### Komut Geçmişinin Kaydını Durdurmak

Eğer geçmiş komutların kaydının tutulmasını engellemek istersek bash kabuğunun history özelliğini devredışı bırakabiliriz. Devredışı bırakmak için aşağıdaki ifadeyi konfigürasyon dosyasına eklememiz yeterlidir.

```bash
set +o history
```

Eğer bu ifade .bashrc dosyasına eklenirse mevcut hesapta açılan hiç bir kabuk, geçmiş kaydı tutmayacaktır.

### Kayıt Tutma Davranışlarını Belirtme

BU KISIM EKSİK, KOMUTLARIN TÜM TERMİNALLERDEN DÜZGÜNCE ULAŞILABİLMESİNİ SAĞLA- BELKİ DE OLMAYABİLİR.. BİRAZ DAHA ARAŞTIRMAYA DEVAM ET..

PROMPT_COMMAND="history -n; history -w; history -c; history -r; $PROMPT_COMMAND"

## Geçmiş Listesindeki Komutların Kullanılması

Buradaki ifadeler "argümanlar" başlığı altında ele aldığımız $_ kullanımından geliyor. Gerekirse buradakileri silip konuyu uygun şekilde bağdaştır.

[9.3 History Expansion](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html#History-Interaction)

- [9.3.1 Event Designators](https://www.gnu.org/software/bash/manual/html_node/Event-Designators.html#Event-Designators)
- [9.3.2 Word Designators](https://www.gnu.org/software/bash/manual/html_node/Word-Designators.html#Word-Designators)
- [9.3.3 Modifiers](https://www.gnu.org/software/bash/manual/html_node/Modifiers.html#Modifiers)

Benzer şekilde uygulayabileceğimiz diğer faydalı komutlar:

- `!$` - bir önceki komutun son argümanı
- `!^` - bir önceki komutun ilk argümanı
- `!!` - bir önceki komutu verir
- `!n` history kayıtlarında yer alan n'inci komutu verir
- `!xyz` - `xyz` ifadesi ile eşleşen en son komutu verir
- `!!:s/X/Y`Son komutta yer alan, `X` ifadesi yerine `Y` ifadesini koyar.
- `!:0` = çalıştırılan son komutun ilk argümanını yani çalıştırılan aracı verir.
- `!:1` = önceki komutun ilk argümanını verir.
- `!:*` = önceki komutun tüm argümanlarını verir.
Ayrıca buradaki kullanımları birleştirerek ihtiyacınıza göre farklı kombinasyonları da kullanabilirsiniz.
- `!233:2` = history kayıtlarında 233. sırada olan komutun 2. argümanı
- `!15:s/X/Y`history kayıtlarında 15. olan komutta yer alan, `X` ifadesi yerine `Y` ifadesini koyar.