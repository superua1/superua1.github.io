# exit Komutu

Mevcut kabuktan çıkılmasını sağlar. `exit` komutuyla birlikte argüman olarak girilen sayısal değer, kabuk kapatıldıktan sonra döndürülecek olan çıkış değerini temsil eder. Normal şartlarda kabuk üzerinden çalıştırmış olduğumuz komutlar çalışır ve çalışma işlemi bittiğinde eğer komut hatasız çalıştıysa 0 çıkış değerini döndürür. Fakat komutun çalıştırılması sonucunda ortaya hata ya da herhangi bir eksiklik çıktıysa çıkış kodları 1 ile 255 arasında bir değer olarak basılır. İşte bizler de `exit` komutu ile duruma göre mevcut sürecin sonlandırılıp, üretilmesi gereken çıkış kodunu özellikle tanımlayabiliyoruz. Özellikle bash programlama yaparken sık kullanılan bir komuttur. 

Hemen denemek için basit bir betik dosyası oluşturup, işlem tamamlandıktan sonra çıkış değeri olarak 111 değerini döndürmesini sağlayalım.

```bash
read -p "Lütfen pozitif bir tam sayı girin:" sayi
if [[ $sayi -lt 0 ]]
        then
                exit 111
        else
                echo $sayi
fi

```

Betik dosyamızın çalışması bittiğinde döndürülmüş olan çıkış konunu konsola `echo $?` komutunu girerek öğrenebiliyoruz. Denemek için hem pozitif hem de negatif tam sayı girildiğinde üretilen çıkış kodlarına bakalım.

```bash
taylan@taylan:~$ bash betik.sh 
Lütfen pozitif bir tam sayı girin:5
5
taylan@taylan:~$ echo $?
0
taylan@taylan:~$ bash betik.sh 
Lütfen pozitif bir tam sayı girin:-5
taylan@taylan:~$ echo $?
111
taylan@taylan:~$
```

Çıktılara göz attığımızda negatif tam sayı koşulu sağlanınca `exit` komutu çalışıp 111 değerini çıkış değeri olarak döndürerek betiğin çalıştığı kabuğun kapatılmasını sağladığını teyit edebiliyoruz.

Çıkış kodlarını bizler tanımlayabiliyoruz ancak yine de sistemimizde önceden tanımlı çıkış kodları da bulunuyor. Her ne kadar tüm sistemlerdeki çıkış kodları aynı olmasa da POSIX kapsamında pek çok ortak çıkış kodu mevcuttur. Konu hakkında biraz daha detay almak için "Argümanlar" kon başlığı altında incelediğimiz "Çıkış Kodları" bölümüne göz atabilirsiniz.