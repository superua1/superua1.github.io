# readonly Komutu

`readonly` komutu değişkenlerin saltokunur yani değiştirilemez hale getirilerek sabitlenmesini sağlıyor. Aynı işlem `declare` komutunun `-r` seçeneği ile de yapılabilir fakat `readonly` komutu ile `declare` komutu arasındaki en temel fark; declare komutunun özellikle `-G` seçeneği ile belirtilmediği sürece fonksiyonlar içerisinde tanımlamış olduğu değişkenin lokal değişken olmasıdır. `readonly` komutu ise varsayılan olarak global sabit değişken tanımlamada kullanılır.

Tek başına kullanıldığında değeri değiştirilmez sabit değişkenler oluşturmamız sağlar.

```bash
taylan@taylan:~$ sabit="ben değişkenim"
taylan@taylan:~$ echo $sabit 
ben değişkenim
taylan@taylan:~$ sabit="ben yeni değişkenim"
taylan@taylan:~$ echo $sabit 
ben yeni değişkenim
taylan@taylan:~$ readonly sabit
taylan@taylan:~$ sabit="ben en yeni olan değişkenim"
bash: sabit: salt okunur değişken
taylan@taylan:~$ echo $sabit
ben yeni değişkenim
taylan@taylan:~$
```

## Fonksiyonları Sabitlemek

Fonksiyonlar da tıpkı değişkenler gibi, aynı isimle yeniden tanımlanabiliyorlar.

```bash
taylan@taylan:~$ sistem(){ echo "Linux";} 
taylan@taylan:~$ sistem 
Linux
taylan@taylan:~$ sistem(){ echo "GNU/Linux";} 
taylan@taylan:~$ sistem 
GNU/Linux
taylan@taylan:~$
```

Eğer tanımlamış olduğumuz fonksiyon değiştirilemesin istersek `readonly -f fonksiyon_adı` şeklinde komutumuzu kullanabiliriz. Bu durumu teyit etmek için aşağıdaki çıktılara bakabilirsiniz.

```bash
taylan@taylan:~$ sistem
GNU/Linux
taylan@taylan:~$ readonly -f sistem
taylan@taylan:~$ sistem(){ echo "GNU/Linux OS";} 
bash: sistem: salt okunur işlev
taylan@taylan:~$ sistem
GNU/Linux
taylan@taylan:~$
```

Fonksiyonumuzu değiştirilmez şekilde ayarladığımız için konsol bize "salt okunur işlev" şeklinde uyarı vermiş oldu.

## Dizileri Sabitlemek

Eğer tanımlamış olduğumuz dizinin sabitlenmesini istersek `readonly` komutunun `-a` seçeneğini kullanabiliriz. Denemek için öncelikle basit bir dizi tanımlayıp, dizi elemanlarının değiştirilip değiştirilmediğini teyit edelim.

```bash
taylan@taylan:~$ dizi=(bir iki üç dört beş)
taylan@taylan:~$ echo ${dizi[*]}
bir iki üç dört beş
taylan@taylan:~$ dizi=(yeni yine yeniden)
taylan@taylan:~$ echo ${dizi[*]}
yeni yine yeniden
taylan@taylan:~$ 
```

Görülebildiği gibi dizi elemanları kolaylıkla değiştirilebiliyor. Bu durumun önüne geçmek için diziyi `readonly -a dizi_adı` şeklinde komut girerek sabitleyebiliriz.

```bash
taylan@taylan:~$ readonly -a dizi 
taylan@taylan:~$ dizi=(sabit1 sabit2 sabit3)
bash: dizi: salt okunur değişken
taylan@taylan:~$ echo ${dizi[*]}
yeni yine yeniden
taylan@taylan:~$
```

Çıktıları inceleyerek dizinin sabitlenmiş olduğunu teyit edebiliyoruz. 

Ayrıca bu kullanım dışında "ilişkisel dizi" olan dizilerinde sabitlenmesi mümkündür. İlişkisel dizi dize değerini bir anahtar yardımıyla kısaca dize elamanı olarak belirtmek için kullanılabilir. Daha net anlamak adına basit bir örnek yapalım.

## Sabit Değişkenleri Listelemek

Yalnızca `readonly` komutunu yazarak ya da `-p` seçeneği kullanılarak sabit olan tüm değişken değerleri listelenebilir. Aşağıdaki çıktılardan bu durumu teyit edebilirsiniz.

```bash
taylan@taylan:~$ readonly 
declare -r BASHOPTS="checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath"
declare -ar BASH_REMATCH=([0]="\$sa" [1]="\$" [2]="" [3]="sa")
declare -ar BASH_VERSINFO=([0]="5" [1]="0" [2]="18" [3]="1" [4]="release" [5]="x86_64-pc-linux-gnu")
declare -ir EUID="1000"
declare -ir PPID="1464"
declare -r SHELLOPTS="braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor"
declare -ir UID="1000"
declare -r sabit="ben yeni değişkenim"
declare -r ye="ben"
taylan@taylan:~$ readonly -p
declare -r BASHOPTS="checkwinsize:cmdhist:complete_fullquote:expand_aliases:extglob:extquote:force_fignore:globasciiranges:histappend:interactive_comments:progcomp:promptvars:sourcepath"
declare -ar BASH_REMATCH=([0]="\$sa" [1]="\$" [2]="" [3]="sa")
declare -ar BASH_VERSINFO=([0]="5" [1]="0" [2]="18" [3]="1" [4]="release" [5]="x86_64-pc-linux-gnu")
declare -ir EUID="1000"
declare -ir PPID="1464"
declare -r SHELLOPTS="braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor"
declare -ir UID="1000"
declare -r sabit="ben yeni değişkenim"
declare -r ye="ben"
taylan@taylan:~$
```

## Sabit Fonksiyonları Listelemek

Sabitlenmiş olan fonksiyonların bilgisini almak için konsola `readonly -f` komutunu girmemiz yeterlidir. 

```bash
taylan@taylan:~$ readonly -f
adınız () 
{ 
    echo "Fonksiyona verdiğiniz argüman: $1"
}
declare -fr adınız
sistem () 
{ 
    echo "GNU/Linux"
}
declare -fr sistem
taylan@taylan:~$
```

## Sabit Dizileri Listelemek

Sabitlenmiş olan dizileri listelemek için `readonly -a` komutunu kullanabiliriz.

Ek olarak, dizi içerisindeki sabitlenmiş değerleri de listelemek için `readonly -A` komutu kullanılabilir.