# pushd dirs popd Komutları

Başlıkta yer alan komutlar birbiri ile yakından ilişkili olduğu için tek bir başlık altında ele almak çok daha doğru olacaktır. 

## `pushd` Komutu

Bu komutun görevi, kendisine argüman olarak verilmiş olan dizin adresini daha sonra hatırlanacak şekilde kaydetmesi ve ardından ilgili dizine geçiş yapmasıdır. Yani `cd` komutuna benzer şekilde çalışır fakat ek olarak olarak hedef ve başlangıç dizinini yığınlar halinde kaydeder.

Örneğin ben ev dizinimde bulunurken(/home/taylan) /etc/apt dizinine geçiş yapmak istersem `cd` ya da `pushd` komutlarını kullanabilirim. Her iki komutu da kullanarak aralarında kıyaslama yapalım.

Öncelikle `cd` komutumuzu kullanalım.

```bash
taylan@taylan:~$ pwd
/home/taylan
taylan@taylan:~$ cd /etc/apt/
taylan@taylan:/etc/apt$ pwd
/etc/apt
```

Gördüğünüz gibi `cd` komutu ile ilgili dizine geçiş yaptık. Şimdi de `pushd` komutunu kullanarak aynı işlemi gerçekleştirelim.

```bash
taylan@taylan:~$ pwd
/home/taylan
taylan@taylan:~$ pushd /etc/apt/
/etc/apt ~
taylan@taylan:/etc/apt$ pwd
/etc/apt
```

Her iki çıktıyı kıyasladığımızda, `pushd` komutunun neticesinde, gitmek istediğimiz hedef dizin ve mevcut bulunduğunuz dizin adresinin çıktı olarak basıldığını fark edebiliyoruz. Bu çıktılar, eğer istersek tekrar `pushd` komutunu kullanarak geldiğimiz dizine geri dönebileceğimizi gösteriyor. İşte tek başında `pushd` komutu kullanıldığında, önceki dizin ile hedef dizin arasında hızlı geçişler yapmamız mümkün oluyor. Aşağıdaki çıktıları inceleyerek bu durumu teyit edebilirsiniz.

```bash
taylan@taylan:~$ pwd
/home/taylan
taylan@taylan:~$ pushd 
/etc/apt ~
taylan@taylan:/etc/apt$ pushd 
~ /etc/apt
taylan@taylan:~$ pwd
/home/taylan
taylan@taylan:~$ pushd 
/etc/apt ~
taylan@taylan:/etc/apt$
```

Elbete bu özellik `cd` komutunda da var. Konsola `cd -` şeklinde komut girerek mevcut ve hedef dizinler arasında hızlı geçişler yapabiliriz. Fakat `pushd` komutunun bu noktada öne çıktığı detay bu girilen dizinlerin sıralı şekilde kaydını tutuyor olmasıdır. Yani birden fazla dizin de daha sonra ulaşılabilecek şekilde `pushd` tarafından yağın olarak saklanır. 

Şimdi tüm işlemleri daha rahat takip edebilmek adına `sudo mkdir -p /bir/iki/üç/dört/beş/` komutu ile yeni bir dizin oluşturalım.

Dizin oluşturma işleminin ardından `pushd` komutu ile alt dizinlere geçiş yapalım. Ben tek tek geçiş yaparak geçtiğim her bir dizinin hatırlandığını sizlere göstermek istiyorum.

```bash
taylan@taylan:~$ pushd /bir/
/bir ~
taylan@taylan:/bir$ pushd /bir/iki/
/bir/iki /bir ~
taylan@taylan:/bir/iki$ pushd /bir/iki/üç/
/bir/iki/üç /bir/iki /bir ~
taylan@taylan:/bir/iki/üç$ pushd /bir/iki/üç/dört/beş/
/bir/iki/üç/dört/beş /bir/iki/üç /bir/iki /bir ~
taylan@taylan:/bir/iki/üç/dört/beş$
```

Çıktıları incelediğimizde geçiş yaptığımız her bir dizinin `pushd` komutu tarafından hatırlandığını çıktılara bakarak teyit edebiliyoruz. Eğer bu dizinlerden herhangi birine hızlıca dönüş yapmak istersek tek yapmamız gereken hafızada tutulma sırasını uygun şekilde belirtmek. Bu işlem için öncelikle hafızada tutulan konumların sırasını `dirs -v` komutu ile öğrenmemiz gerekiyor.

```bash
taylan@taylan:/bir/iki/üç/dört/beş$ dirs -v
 0  /bir/iki/üç/dört/beş
 1  /bir/iki/üç/dört
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
taylan@taylan:/bir/iki/üç/dört/beş$
```

Konsola basılmış olan listenin sol tarafından ilgili dizinin hangi sayı üzerinden tekrar çağırılabileceğini görebiliyoruz. Dizini çağırmak için `pushd` komutuna ek olarak artı ya da eksi işareti ile gitmek istediğimiz dizini temsil eden numarayı girebiliriz.

Eğer `pushd` komutunun ardından;

Artı işareti girilirse, `dirs -v` komutu ile listelenmiş olan dizinlerin yukarıdan aşağıya doğru okunur. Yani örneğin `pushd +4` komutu girilirse 0'dan itibaren yukarıdan aşağı doğru 0 1 2 3 4 şeklinde liste okunup 4. sırada yer alan dizine geçilir. 

```bash
taylan@taylan:/bir/iki/üç/dört/beş$ dirs -v
 0  /bir/iki/üç/dört/beş                                                                                                                                  
 1  /bir/iki/üç/dört                                                                                                                                      
 2  /bir/iki/üç                                                                                                                                           
 3  /bir/iki                                                                                                                                              
 4  /bir                                                                                                                                                  
 5  ~
taylan@taylan:/bir/iki/üç/dört/beş$ pushd +4                                                                                                              
/bir ~ /bir/iki/üç/dört/beş /bir/iki/üç/dört /bir/iki/üç /bir/iki
taylan@taylan:/bir$
```

Eksi işareti kullanılırsa; `dirs -v` komutunun ürettiği liste aşağıdan yukarı doğru okunur. Örneğin `pushd -2` komutunu girersek aşağıdan itibaren 0 1 2 şeklinde liste okunup 2. değere karşılık gelen liste dizinine geçiş yapılır.

```bash
aylan@taylan:/bir$ dirs -v
 0  /bir
 1  ~
 2  /bir/iki/üç/dört/beş
 3  /bir/iki/üç/dört #tersten okunduğu için 2.
 4  /bir/iki/üç      #tersten okunduğu için 1.
 5  /bir/iki         #tersten okunduğu için 0.
taylan@taylan:/bir$ pushd -2
/bir/iki/üç/dört /bir/iki/üç /bir/iki /bir ~ /bir/iki/üç/dört/beş
taylan@taylan:/bir/iki/üç/dört$
```

 Çıktıları dikkatlice incelerseniz aralarındaki farkı rahatlıkla kavrayabilirsiniz. Eğer ilgili dizine geçiş yapmadan yalnızca dizin adresini bu listeye kaydetmek istersek `pushd` komutunun `-n` seçeneğini kullanabiliriz. Denemek için yeni bir dizin yolu belirtip daha sonra kayıtlı dizinleri listeleyelim.

```bash
taylan@taylan:/bir/iki/üç/dört$ pushd -n /etc/apt/apt.conf.d/
/bir/iki/üç/dört /etc/apt/apt.conf.d/ /bir/iki/üç /bir/iki /bir ~ /bir/iki/üç/dört/beş
taylan@taylan:/bir/iki/üç/dört$ dirs -v
 0  /bir/iki/üç/dört
 1  /etc/apt/apt.conf.d/
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
 6  /bir/iki/üç/dört/beş
taylan@taylan:/bir/iki/üç/dört$
```

Çıktılardan da anlaşılabileceği gibi, ilgili dizin adresi listeye eklenmiş olmasına karşın o dizine geçiş yapmadık. İşte sizler de bu şekilde sık kullandığınız uzun isimlere sahip olan dizin adreslerini listeye ekleyip kolayca tekrar ulaşabilirsiniz.

# `dirs` Komutu

Her ne kadar `dirs` komutunu daha önce kullanmış olsa da şimdi birkaç ek kullanım seçeneğinden de bahsedelim.

Eğer tek başına kullanılırsa, herhangi bir sıralama yapmaksızın, kayıtlı olan dizin adreslerini konsola bastırır.

```bash
taylan@taylan:~$ dirs
~ /etc/apt/apt.conf.d/ /bir/iki/üç /bir/iki /bir ~ /bir/iki/üç/dört/beş
taylan@taylan:~$
```

### `-p` Seçeneği

Kayıtlı olan dizin geçmişini tek tek satırlar halinde bastırmak için kullanılır. Bu çıktılarda sıra numarası yer almaz.

```bash
taylan@taylan:~$ dirs -p
~
/etc/apt/apt.conf.d/
/bir/iki/üç
/bir/iki
/bir
~
/bir/iki/üç/dört/beş
taylan@taylan:~$
```

### `-v` Seçeneği

Kayıtlı dizinleri sıra numarasıyla birlikte liste halinde sunar.

```bash
taylan@taylan:/bir/iki/üç/dört$ dirs -v
 0  /bir/iki/üç/dört
 1  /etc/apt/apt.conf.d/
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
 6  /bir/iki/üç/dört/beş
```

### `-l` Seçeneği

Normalde ev dizinimiz kısaca tilde `~` işareti ile temsil edilir. Eğer bu işaret yerine uzun uzadıya ev dizin adresini çıktılarda almak istersek `-l` seçeneğini kullanabiliriz. Standart `dirs` kullanımı ile kıyaslayarak farkı daha net görebilirsiniz.

```bash
taylan@taylan:/bir/iki/üç/dört$ dirs -l
/bir/iki/üç/dört /etc/apt/apt.conf.d/ /bir/iki/üç /bir/iki /bir /home/taylan /bir/iki/üç/dört/beş
taylan@taylan:/bir/iki/üç/dört$ dirs 
/bir/iki/üç/dört /etc/apt/apt.conf.d/ /bir/iki/üç /bir/iki /bir ~ /bir/iki/üç/dört/beş
```

### `-c` Seçeneği

Kayıtlı tutulan tüm dizin bilgilerinin silinmesini sağlar.

```bash
taylan@taylan:~$ dirs
~ /etc/apt/apt.conf.d/ /bir/iki/üç /bir/iki /bir ~ /bir/iki/üç/dört/beş
taylan@taylan:~$ dirs -c
taylan@taylan:~$ dirs
~
taylan@taylan:~$
```

### `+N` ya da `-N` Seçenekleri | Sıra Numarası İle Bastırmak

Eğer kayıtlı bulunan dizinleri sıra numarasına göre bastırmak istersek artı ya da eksi işareti ile ilgili dizinin sıra numarasını belirtebiliriz. Artı işareti listenin başından, eksi işareti ise listenin sonundan itibaren çıktı üretir.

```bash
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç/dört
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
taylan@taylan:~$ dirs +3
/bir/iki
taylan@taylan:~$ dirs -3
/bir/iki/üç
taylan@taylan:~$
```

# `popd` Komutu

Kayıtlı olan dizinleri silmek için kullanılır. Eğer argüman herhangi bir argüman belirtilmezse kayıt listesinin en üstünde yer alan dizin silinir ve en üstte kalan dizine geçilir.

```bash
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç/dört
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
taylan@taylan:~$ popd 
/bir/iki/üç/dört /bir/iki/üç /bir/iki /bir ~
taylan@taylan:/bir/iki/üç/dört$ dirs -v
 0  /bir/iki/üç/dört
 1  /bir/iki/üç
 2  /bir/iki
 3  /bir
 4  ~
taylan@taylan:/bir/iki/üç/dört$
```

### `-n` Seçeneği

Listenin en üstünde yer alan dizini siler ve hiç bir dizine otomatik geçiş yapmaz.

```bash
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç
 2  /bir/iki
 3  /bir
 4  ~
taylan@taylan:~$ popd -n
~ /bir/iki /bir ~
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki
 2  /bir
 3  ~
taylan@taylan:~$
```

### `+N` ya da `-N` Seçeneği | Sıra Numarası İle Dizin Kaydı Silmek

Listede kayıtlı bulunan dizinleri sıra numaraları ile silmek için artı ya da eksi işaretinin ardından sıra numarası belirtebiliriz. Eğer artı işareti kullanılırsa liste baştan itibaren okunurken, eksi işareti kullanıldığında liste sondan itibaren okunur.

```bash
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç/dört
 2  /bir/iki/üç
 3  /bir/iki
 4  /bir
 5  ~
taylan@taylan:~$ popd +3
~ /bir/iki/üç/dört /bir/iki/üç /bir ~
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç/dört
 2  /bir/iki/üç
 3  /bir
 4  ~
taylan@taylan:~$ popd -3
~ /bir/iki/üç /bir ~
taylan@taylan:~$ dirs -v
 0  ~
 1  /bir/iki/üç
 2  /bir
 3  ~
taylan@taylan:~$
```