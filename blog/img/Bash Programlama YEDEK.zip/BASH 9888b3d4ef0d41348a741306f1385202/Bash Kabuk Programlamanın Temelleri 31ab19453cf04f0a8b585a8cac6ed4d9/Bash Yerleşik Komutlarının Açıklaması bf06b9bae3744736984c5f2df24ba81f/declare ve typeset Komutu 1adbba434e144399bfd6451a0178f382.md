# declare ve typeset Komutu

[https://linuxhint.com/bash_declare_command/](https://linuxhint.com/bash_declare_command/)

Değişkenlerin belirli türlerde değer almasını sağlamak için `declare` ya da `typeset` komutlarından birini kullanabiliriz. Her iki komut da aynı işlevi görüyor. Aralarındaki tek fark `typeset` komutunun daha eski sürümlerden beri destekleniyor olup `declare` komutunun daha yeni olmasıdır. Eğer çok eski bash kabuğunda çalıştırılma ihtimali olan kabuk dosyaları oluşturuyorsanız, uyum sorunu yaşamamak için `typeset` komutunu tercih edebilirsiniz. Eski sürümlerde çalışmak gibi bir hedefiniz yoksa, `declare` komutunun bash programlama konusunda daha sık kullanıldığını bilmenizi isterim. Buradaki anlatımları `declare` komutu üzerinden ele alacağız fakat sizler `typeset` komutunu da kullanabilirsiniz. Aşağıdaki tablodan komutun sahip olduğu seçeneklere ve yerine getirebildiği işlevlerine göz atabilirsiniz.

### Temel Seçenekler

`-f` : Tanımlı olan fonksiyonları işlev tanımlarıyla birlikte bastırır.

`-F` : Tanımlı olan fonksiyon isimlerini bastırır.

`-g` : Fonksiyonlar içerisinde kullanıldığında, global değişken tanımlamayı sağlar.

`-p` : Argüman olarak verilmiş ifadelerin değerlerini ve özniteliklerini bastırır. 

Temel seçenekler haricinde, belirli özelliklerde değişkenler tanımlamak istersek, öznitelik seçenekleri ile istediğimiz türde değişken tanımlaması yapabiliriz. 

### Öznitelik Seçenekleri

`-a` : Dizi tanımlama işlevindedir. array(dizi) ifadesinin kısaltmasıdır.

`-A` : İlişkisel dizi tanımlama işlevindedir.

`-i` : Sayısal değişken tanımlama işlevindedir. integer(tam sayı) ifadesinin kısaltmasıdır.

`-l` : Değişken değerinde yer alan ifadelerin hepsinin küçük harflerle değişmesini sağlar.

`-u` : Değişken değerinde yer alan ifadelerin hepsinin büyük harflerle değişmesini sağlar.

`-n` : Argüman olarak verilen değeri referans değişkenin değeri olarak tanımlar.

`-r` : Sabit değişken atama işlevindedir. readonly(yalnızca okunabilir) ifadesinin kısaltmasıdır.

`-t` : Argüman olarak verilen değişkene "takip" özniteliği ekler.

`-x` : Değişkeni export(ihraç) ederek, alt kabuklara aktarma işlevindedir.

`declare` komutunu kullanıyorken; eğer değişkenlere özellik eklemek istiyorsak `-` işaretini, şayet var olan özellikleri çıkarmak istiyorsak da `+` işaretini, eklemek ya da çıkarmak istediğimiz özelliğin kısaltmasını da belirterek kullanmamız gerekiyor. Artı ve eksi işaretlerinin kullanımı başlangıçta ters gibi gelse de kısa sürede kullanımına alışacaksınız. Şimdi örnekler üzerinden anlatımlara devam edelim.

## Sayısal Değişken Tanımlamak

Anlatımlara ilk olarak sayısal değişken tanımlama işlemi ile başlayalım.

Sayısal değişken tanımlamak için konsola `declare -i değişken="sayi_değeri"` şeklinde komutumuzu girmemiz gerekiyor.

Ben **9** değerine sahip **rakam** isimli bir sayısal değişken tanımlamak istediğim için konsola `declare -i rakam="9"` komutumu giriyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/17.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/17.png)

Böylelikle **rakam** isimli sayısal değişkenime **9** rakamını atamış oldum ve bu değişkenim ben aksini istemedikçe yalnızca sayısal ifadeler alan bir değişken olarak sınıflandırılmış oldu. Bu durumu teyit etmek için öncelikle değişkenimin sınıfını sorgulamak üzere `declare` komutunun "**p"** seçeneğini kullanarak `declare -p rakam` komutunu giriyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/18.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/18.png)

Sizlerin de gördüğü gibi konsol bana çıktı olarak `declare -i rakam="9"` şeklinde bir çıktı bastı. Bu çıktı ile değişkenimizin sayısal bir değişken olduğunu teyit etmiş olsak da kesin olarak emin olmak adına, değişkenimize sayısal değerlerin dışında herhangi bir değer atamaya çalışarak bu durumu netleştirelim.

Bunun için konsola `rakam="test"` komutumu girdikten sonra, değişkenimin durumunu sorgulamak üzere `declare -p rakam` komutunu kullanıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/19.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/19.png)

Gördüğünüz gibi çıktıda rakam değişkenimin değeri "**0**" olarak karşıma gelmiş oldu. Bunun nedeni değişkenime sonradan atamaya çalıştığım "**test**" ifadesinin sayısal bir karşılığının olmamasıdır.

Hatırlarsanız değişken tanımlama anlatımlarının başında **rakamlar** isimli değişkene **12345** ifadesini atamış ve bu değişkenimizi bastırmıştık. Şimdi aynı değişkeni atayıp değerini "**test**" ifadesi ile değiştirerek, sayısal değer alma özelliği olan değişkenler ile sıradan değişken arasındaki farkı görelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/20.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/20.png)

Gördüğünüz gibi sayısal özellik atamadığım değişkenin içeriğindeki sayısal veriler kolaylıkla değişmiş oldu. Böylelikle "sayısal değişken" ile "sıradan değişken" tanımlamanın farkını kıyaslayarak görmüş olduk.

Ancak tanımladığımız sayısal değişkenler her zaman sayısal değişken olarak kalmak zorunda da değil. Değişkenimizin sınıfını tekrar eski hale getirmek istersek ekleme işleminde kullandığımız ****eksi işareti yerine bu sefer artı işaretini kullanmamız yeterli oluyor. Yani ben **rakam** isimli sayısal değişkenimin, sayısal değişken tutma özelliğini kaldırmak istersem; konsola `declare +i rakam` şeklinde komut girmem yeterli oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/21.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/21.png)

Bu şekilde, `declare` komutunu kullanarak istediğimiz değişkene "sayısal değişken" özelliğini ekleyip çıkartabiliyoruz.

## Dizi Tanımlamak

Birden fazla değeri tek bir değişken içerisine toparlamak istediğimizde dizileri kullanabiliriz.

Dizi tanımlamak için `declare` komutunun `a` seçeneğini `declare -a dizi=(değer1 değer2 değer3)` şeklinde kullanmamız gerekiyor.

Ayrıca `declare` komutunu kullanmadan, dizide yer alacak ifadeleri parantez içine `dizi=(değer1 değer2 değer3 )` şeklinde alarak da dizi belirtebiliyoruz. Buradaki parantezler o değişkenin bir dizi olduğunu otomatik olarak belirtmiş oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/22.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/22.png)

Dizilerin kullanımına en basit örnek alışveriş listesi olarak verilebilir.

Örneğin ben **liste** isimli bir değişken tanımlayıp, bu değişkenin içerisine istediğim sayıda değer atayabilir ve atadığım değerleri tek tek çağırabilirim. Örnek olması için; konsola `liste=(su süt çay elma ekmek)` şeklinde komutumu girerek, **liste** isimli değişkene birden fazla değer atamış oluyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/23.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/23.png)

Böylelikle her bir değere **0 dan başlayarak** sırasıyla birer index numarası atanmış oldu. Yani örneğin "**su"** ifadesi ilk değer olduğu için "**0"** index numarasını almışken, 3. sıradaki "**çay"** değerinin index numarası "**2"** olmuş oldu.

Bizler de sıralı şekilde atanan bu index değerleri sayesinde istediğimiz değerleri diziden çağırabiliyoruz. Örneğin dizide yer alan ilk değeri çağırmak istersem, konsola `echo ${liste[0]}` komutunu girmem yeterli oluyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/24.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/24.png)

Gördüğünüz gibi "**0"** index numarası ile ilk değerimizi ekran bastırmış olduk.

Dizedeki değerleri bastırma işlemini aynı şekilde tüm değerlerimizi tek tek elde etmek için de kullanabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/25.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/25.png)

Eğer tüm değişkenleri tek seferde bastırmak istersek "yıldız" `*` ya da "et" `@` işaretlerinden birini kullanabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/26.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/26.png)

Tanımlanmış olan dizi elemanının kaç karakterden oluştuğunu öğrenmek için **#** simgesini kullanarak, komutumuzu `echo ${#dizi[değişken indexi]}` şeklinde giriyoruz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png)

Üstelik bu kullanım sadece diziler için değil standart ve sabit değişkenler için de geçerlidir. Sabit değişkenlerin ne olduğundan anlatımın devamında ayrıca bahsediyor olacağız.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png)

Eğer komutumuzda index numarası ile herhangi bir dizi elemanı belirtmezsek varsayılan olarak dizide yer alan ilk eleman işleme alınıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png)

Ayrıca dizi içerisinde kaç tane değişken olduğunu öğrenmek için de `#` simgesini ile birlikte index numarası kısmında `` simgesini kullanmamız yeterli.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png)

Yani anlayabileceğiniz gibi burada yer alan kare işareti mevcut değişken verisini saymakla mükellef.

Ayrıca anlatım sırasında kullanmış olduğumuz süslü parantezler hakkında da kısaca açıklama yapmak istiyorum. Söz konusu değişkenler üzerinde işlem yapmak olduğunda süslü parantezler değişkenler üzerinde işlem yapmayı mümkün kılıyor. Süslü parantezlerin gerekli olup olmadığını anlamak üzere süslü parantez olmadan komut girmeyi deneyebilirsiniz.

Çıktılardan da görebileceğiniz gibi süslü parantez olmadığında değişkenler üzerinde harici işlem yapmamız mümkün olmuyor. Süslü parantezler değişkenin yapılacak işlem kapsamına alınmasını sağlıyor.

## İlişkisel Dizi Tanımlamak

İlişkisel diziler, bizim belirleyeceğimiz ifadeler ile ilişkili dizi elemanları tanımlamamıza olanak sağlarlar. Normalde her bir dizi elemanı yalnızca index numarası ile çağırılabilir. Fakat ilişkisel dizilerde, ilgili elaman ilişkili olduğu ifade ile çağrılabilir. Örnek üzerinden bu duruma açıklık getirmeye çalışalım.

Tanımlama işlemi için dizi elamanı ile eşleştirilecek ifadeyi köşeli parantez içerisinde belirtmemiz yeterli oluyor.

```bash
taylan@taylan:~$ declare -A dizi=( [ad]=ahmet [soyad]=yılmaz [yas]=25 [konum]=istanbul )
taylan@taylan:~$ echo ${dizi[ad]}
ahmet
taylan@taylan:~$ echo ${dizi[yas]}
25
taylan@taylan:~$ echo ${dizi[*]}
istanbul yılmaz ahmet 25
taylan@taylan:~$
```

Biz tek seferde tanımlama yaptık fakat dilersek tek tek de ilişkisel dizi tanımlamamız mümkündür. Tanımlamalarımızın ilişkisel olarak algılanması için öncelikle değişkeni `declare` komutu ile ilişkisel özniteliğe kavuşturuyoruz. Ardından istediğimiz değerleri tanımlamamız mümkün oluyor.

```bash
taylan@taylan:~$ declare -A yeni_dizi
taylan@taylan:~$ yeni_dizi[ilk]=deger
taylan@taylan:~$ yeni_dizi[ikinci]=deger2
taylan@taylan:~$ declare -p yeni_dizi 
declare -A yeni_dizi=([ilk]="deger" [ikinci]="deger2" )
taylan@taylan:~$ echo ${yeni_dizi[ilk]}
deger
taylan@taylan:~$
```

Eğer herhangi bir değişkeni `declare -A` komutuyla ilişkisel dizi olarak özellikle tanımlamazsak, ilgili değişken ilişkisel değerler almayacaktır.

```bash
taylan@taylan:~$ isimler[ilk]=hasan
taylan@taylan:~$ isimler[ikinci]=funda
taylan@taylan:~$ declare -p isimler 
declare -a isimler=([0]="funda")
taylan@taylan:~$ echo ${isimler[ilk]}
funda
taylan@taylan:~$ echo ${isimler[ikinci]}
funda
taylan@taylan:~$ echo ${isimler[*]}
funda
taylan@taylan:~$ isimler=( [ilk]=hasan [ikinci]=funda ) 
taylan@taylan:~$ declare -p isimler 
declare -a isimler=([0]="funda")
taylan@taylan:~$ echo ${isimler[*]}
funda
taylan@taylan:~$
```

Çıktıları incelediğimizde, değişken değerine ilişkisel dizi özniteliği tanımlanmadığı sürece standart bir değişken olarak ele alındığını teyit edebiliyoruz.

## Değişken Değerinin Küçük ve Büyük Karakterlere Dönüştürülmesi

Değişken tanımlandıktan sonra değişkene atanan değerlerin tamamının küçük veya büyük harflerden oluşmasını sağlamamız mümkündür. Küçük harflerden oluşması için ingilizce "lower" ifadesinin kısaltmasını yani `-l` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ declare -l metin
taylan@taylan:~$ metin="Ben Bir DENEME metniyim"
taylan@taylan:~$ echo $metin
ben bir deneme metniyim
```

Benzer şekilde daha sonra atanacak olan değişken değerinin tamamının büyük harflerden oluşması için ingilizce "upper" ifadesinin kısaltmasını yani `-u` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ declare -u metin 
taylan@taylan:~$ metin="Ben Bir DENEME metniyim"
taylan@taylan:~$ echo $metin
BEN BİR DENEME METNİYİM
```

Burada dikkat etmeniz gereken detay ilgili değişkenin küçük ya da büyük harflere dönüştürme özniteliğinin, henüz değişkene değer vermeden yapılmasıdır. Yani eğer mevcut değişkenin sahip olduğu bir değer varsa bu özellikleri değiştirmek ilgili değişkenin sahip olduğu değeri değiştirmez. Aşağıdaki çıktıya bakarak bu durumu kendiniz de teyit edebilirsiniz.

```bash
taylan@taylan:~$ declare -p metin 
declare -u metin="BEN BİR DENEME METNİYİM"
taylan@taylan:~$ declare -l metin 
taylan@taylan:~$ echo $metin 
BEN BİR DENEME METNİYİM
taylan@taylan:~$ declare -p metin 
declare -l metin="BEN BİR DENEME METNİYİM"
```

## Fonksiyon İçerisinde Tanımlanan Değişkenler Hakkında

Fonksiyon içerisinde `declare` komutu ile tanımladığımız tüm değişkenler lokal değişken olarak tanımlanır. Lokal olan değişkenler yalnızca mevcut fonksiyon içerisinde çağırılabilir. Eğer değişkenleri global olarak tanımlamak istersek `declare` komutunun `-g` seçeneğini kullanabiliriz. Bu durumu teyit etmek için öncelikle `-g` seçeneği olmadan fonksiyon içerisinde değişken tanımlayalım ve fonksiyon dışından çağırmayı deneyelim.

```bash
taylan@taylan:~$ fonksiyon(){ declare isim="taylan"; echo $isim; }
taylan@taylan:~$ echo $isim

taylan@taylan:~$ fonksiyon 
taylan
taylan@taylan:~$ echo $isim

taylan@taylan:~$
```

Görüldüğü üzere fonksiyon içerisinde tanımlanmış olan değişkenler yalnızca lokal olarak yani fonksiyon içerisinden çağırılabiliyor. Şimdi benzer örneği global değişken tanımlayarak deneyelim.

```bash
taylan@taylan:~$ fonksiyon(){ declare -g isim="taylan"; echo $isim; }
taylan@taylan:~$ echo $isim

taylan@taylan:~$ fonksiyon 
taylan
taylan@taylan:~$ echo $isim
taylan
taylan@taylan:~$
```

Çıktıları incelediğimizde, fonksiyon çalıştırıldıktan sonra ilgili değişkene global olarak ulaşabildiğimizi teyit edebiliyoruz.

## Hata Ayıklama için Değişkenleri İşaretlemek

Eğer değişkenler özel olarak işaretlenmezse, değişkenlerin hata ayıklama aşamasında takip edilmesi mümkün olmaz. Bu özellik genelde ilgili değişkenin hataya yol açıp açmadığını teyit etmek için kullanılır. TRAP KOMUTUNUN İŞLEVİNİ İYİ BİÇİMDE ELE AL

## Değişkenlere Referans Vermek | Değişkenleri Bağlamak

Mevcut değişkeni başka bir değişkene referans olarak gösterebiliriz. Bu sayede ilgili değişkenin değeri her iki değişken için de bağlantılı şekilde aynı olur. Daha iyi anlamak adına basit bir örnek yapalım.

```bash
taylan@taylan:~$ ref="ben referans"
taylan@taylan:~$ declare -n degisken=ref 
taylan@taylan:~$ echo $ref $degisken 
ben referans ben referans
taylan@taylan:~$ degisken="yeni değer"
taylan@taylan:~$ echo $ref $degisken 
yeni değer yeni değer
taylan@taylan:~$ ref="yeni referans"
taylan@taylan:~$ echo $ref $degisken 
yeni referans yeni referans
```

Görebildiğiniz gibi her iki değişkendeki değişiklikler de aynı anda birbirilerini etkiliyor. Aynı örneği referans göstermeden yani `-n` seçeneği olmadan deneyelim.

```bash
taylan@taylan:~$ ref="referans değeri"
taylan@taylan:~$ declare degisken=ref
taylan@taylan:~$ echo $ref $degisken 
referans değeri ref
taylan@taylan:~$ degisken="yeni değişken"
taylan@taylan:~$ echo $ref $degisken 
referans değeri yeni değişken
taylan@taylan:~$ ref="yeni referans"
taylan@taylan:~$ echo $ref $degisken 
yeni referans yeni değişken
taylan@taylan:~$
```

## Sabit Değişken Tanımlamak

Şimdi ise tanımladığımız değişken değerinin, değiştirilemez şekilde sabit kalmasını nasıl sağlarız bunu görelim. Bu işlem için `readonly` komutunu ya da `declare` komutunun `r` parametresini kullanabiliyoruz.

Örneğin ben **sabit** isimli bir değişkenin değerini sabitlemek üzere konsola `readonly sabit="sabit değer"` şeklinde komutumu giriyorum. Daha sonra atadığım sabit değişkenin özelliklerini bastırarak ve mevcut değerini değiştirmeye çalışarak, değerin gerçekten sabit olup olmadığını teyit etmeye çalışıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/31.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/31.png)

Ve gördüğünüz gibi **sabit** isimli değişkenimin özelliklerinde yer alan `r` ifadesi bu değişkenin değiştirilemez olduğunu açıkça belirtiyor. Ayrıca değeri sabit olduğu için içerisine yeni bir değer ataması da gerçekleştiremedik.

Bu kullanıma alternatif olarak biliyorsunuz ki sabit değer atama işlemini `readonly` komutu yerine, `declare` komutu ile de gerçekleştirebilirdik. Hemen bu şekilde de bir örnek yapmak adına konsola `declare -r sabit1="sabit değer 1"` şeklinde de komutumu girip değişkenimin özelliğini `p` parametresi ile teyit ediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/32.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/32.png)

Son olarak bu değerimi de değiştirmeye çalışarak değişkenimin sabit olup olmadığını teyit ediyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/33.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/33.png)

Ve yine gördüğünüz gibi atadığımız değişken sabit olduğundan yeni bir değer atanamadı.

**Sabit değişken tanımlarken dikkat edilmesi gereken nokta, sabit değişkenlerin bir kez tanımlandıktan sonra kesinlikle silinip değiştirilemeyeceğidir**. Sabit değişken bir kez tanımlandıktan sonra sabit şekilde kalır.
Bu durumu teyit etmek için değişkenimizin sabitlik özelliğini `declare +r` komutu ile kaldırmayı deneyelim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/34.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/34.png)

Komutumuzu girdik ancak gördüğünüz gibi değişken sabit değere sahip olduğundan konsol bu işlemin mümkün olmadığını belirtiyor. Peki ama sabit değişkenler gerçekten sonsuza kadar tanımlandığı şekilde mi kalıyor ?

Aslında bu durum; yalnızca değişkenin tanımlandığı konsol ekranı için geçerli olduğundan, konsol kapatıldığında tanımlanan tüm değişkenlerle birlikte sabit değişkenlerin de sıfırlanmış oluyor. Değişkenlerin tüm kabuklarda geçerli olması için `export` edilmesi gerekiyor bu da ayrı bir konu başlığı elbette.