# fc Komutu

`fc` komutu bash kabuğunda yerleşik(builtin) olarak bulunan komuttur. Geçmiş yani history listesindeki komutları görüntüleme ve düzenleyip çalıştırma imkanı sunar.(Eğer history yapısını bilmiyorsanız ayrıca göz atmanız konuyu takip etmenizi kolaylaştırabilir.) Tek başına kullanıldığında çalıştırılmış olan en son komutu, geçici bir dosya üzerinde açar ve bize bu komutu düzenleme imkanı sunar. Düzenleme işleminin arından editörden dosyayı kaydedip çıkış yaptığımızda düzenlediğimiz komut, kabuk üzerinde çalıştırılır. Komutları düzenleme özelliği, sık kullanılan karmaşık komutların kullanımlarını kolaylaştırır. Burada açılmış olan dosyanın bir önemi yoktur çünkü aslında bu dosya geçici olarak tutulup daha sonrasında otomatik olarak silinecektir. Daha iyi anlamak adına konsola `echo "Deneme metni"` komutunu girip çıktının basılmasını sağlayalım.

Daha sonra `fc` komutunu girelim ve açılmış olan geçici dosya üzerinden komutumuzu istediğimiz şekilde düzenleyelim ve metin editörünü kapatalım. Editör kapatıldığı anda düzenlemiş olduğumuz komutun kabuk üzerinde çalıştırılmış olduğunu görebiliriz. İşte `fc` komutunun en temel kullanım yöntemi bu şekilde. Temel kullanımı dışında alternatif kullanımlarını da sırasıyla açıklamaya çalışalım;

## Geçmiş Kayıtlarında Yer Alan Komuta Dize Üzerinden Ulaşmak

Eğer history kayıtlarında yer alan komuta, komutu girerken kullandığınız ifadeler yani komut dizesi yardımıyla ulaşmak isterseniz `fc` komutunun ardından ulaşmak istediğiniz komutun bir kısmını yazın. Fakat bu kullanımda dikkat etmeniz gereken detay `fc` komutunun bizim yazmış olduğumuz ifadeyi, history kayıtlarının sonunda başına doğru araştırmasıdır. Yani örneğin `echo` komutunu geçmişte birden fazla kez kullandıysanız `fc echo` komutunun ardından en son kullanmış olduğunuz `echo` komut yapısı karşınıza gelecektir. Denemek için `echo "deneme"` ve `echo "test"` şeklinde iki ayrı komut girip, `fc echo` komutunun neticesinde hangisinin getirildiğine göz atabilirsiniz.

## Kullanılabilir Olan Geçmiş Komutların Listesini Almak

Kullanılabilir olan komutları listelemek için `fc -l` komutunu kullanabiliriz. Normal şartlarda karşımıza yalnızca son 15 komut listelenecektir fakat bu aralığı genişletmemiz de mümkündür.

Örneğin 500. kayıttan şimdiye kadar olan tüm geçmiş komutların listesini almak için `fc -l 500` komutunu kullanabiliriz.

Dilersek tam olarak aralık da belirtebiliriz. Örneğin 555 ile 600 arasındaki komutları listelemek için `fc -l 555 600` komutunu kullanabiliriz.

Eğer alacağımız listede komut sırası olmasını istemezsek `-n` seçeneğini de ekleyebiliriz. Örneğin 500 ile 505 arasındaki komutları sıra sayısı olmadan listelemek için `fc -ln 500 505` komutunu girebiliriz.

## Geçmiş Kayıtlarında Yer Alan Komuta Kayıt Sırasını Kullanarak Ulaşmak

Geçmiş kayıtlarını listeleyip kullanmak geçmişten getirmek istediğimiz komutun sıra numarasını `fc sıra_numarası` şeklinde kullanabiliriz. 

```bash
taylan@taylan:~$ fc -l
1367     echo "deneme"
taylan@taylan:~$ fc 1367
#bu sırada metin editörü ile ifadeyi tekrar düzenledim.
echo "düzenlenmiş deneme.."
düzenlenmiş deneme..
taylan@taylan:~$
```

## Düzenlemenin Yapılacağı Aracın Seçilmesi

Normal şartlarda özellikle belirtmediğimiz sürece `fc` komutu, komutların düzenlenebilmesi için sistem üzerinde varsayılan olarak kullanılan editörü kullanır. Eğer biz başka bir metin editörü kullanmak istersek bu durumu `fc -e editör_adı` şeklinde belirtmemiz gerekiyor. Örneğin vim editörü ile düzenleme yapmak istiyorsak `fc -e vim` şeklinde komut girebiliriz.

Benzer şekilde eğer içerisinde "echo" ifadesinin geçtiği en son komutu vim editörü ile düzenleyip çalıştırmak istersek `fc -e vim echo` komutunu girmemiz yeterlidir. 

Ek olarak **FCEDIT** isimli bir değişken tanımlayıp bu değişkene, `fc` aracının varsayılan olarak kullanmasını istediğimiz metin editörünü de belirtebiliriz.  Örneğin her oturum açtığımızda okunan .bashrc dosyasına `export FCEDIT="vim"` komutunu eklersem, hesabımda oturum açtıktan sonra `fc` komutunu vim editörü ile birlikte kullanıyor olurum.(Değişken ve .bashrc dosyası konusunda kafanız karıştıysa ayrıca bu konuların açıklamalarına da göz atabilirsiniz.)

## Düzenleme Yapmadan Komutun Çalıştırılması

Eğer geçmişteki komutları düzenlemeden oldukları gibi kullanacaksak `-e` seçeneğinin ardından kısa çizgi `-` işaretini kullanarak düzenleme yapmayacağımızı belirtmemiz yeterlidir.

```bash
taylan@taylan:~$ echo "deneme"
deneme
taylan@taylan:~$ fc -e -
echo "deneme"
deneme
taylan@taylan:~$
```

Ben en son komut üzerinden örnek verdim fakat komut sırası ya da komut dizesi üzerinden de aynı işlemler yerine getirilebilir.