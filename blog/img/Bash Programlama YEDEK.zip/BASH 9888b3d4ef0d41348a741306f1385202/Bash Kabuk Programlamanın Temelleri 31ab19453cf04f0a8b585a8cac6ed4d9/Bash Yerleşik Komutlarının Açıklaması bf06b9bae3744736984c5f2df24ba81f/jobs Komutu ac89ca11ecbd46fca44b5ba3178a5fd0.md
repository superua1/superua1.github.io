# jobs Komutu

`jobs` komutu mevcut kabuk üzerinde çalıştırılmış olan görevlerin durumlarını listeler. Tek başına kullanıldığında etkin olan durumların bilgisini listeler. 

```bash
taylan@taylan:~$ sleep 101 & #arkaplanda başlattık.
[1] 1881
taylan@taylan:~$ sleep 102
^Z        # Ctrl + Z tuşlamamsıyla duraklattık.
[2]+  Durdu                   sleep 102
taylan@taylan:~$ sleep 103
^C        # Ctrl + C tuşlamasıyla süreci sonlandırdık.
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 101 &
[2]+  Durdu                   sleep 102
taylan@taylan:~$
```

Görebildiğiniz gibi arkaplanda çalışmakta olan ve durdurulmuş olan(beklemede olan) işlemler listelenirken, sonlandırılmış(tamamlanmış) işlem listelenmemektedir.

Eğer ek olarak işlem numaraları(pid) da sunulsun istersek, `-l` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ jobs -l
[1]-  1881 Bitti                   sleep 101
[2]+  1882 Durduruldu              sleep 102
taylan@taylan:~$ jobs -l
[2]+  1882 Durduruldu              sleep 102
taylan@taylan:~$
```

Çıktıları incelediğimizde sol tarafta ilgili işin işlem numarasının da listelenmiş olduğunu görebiliyoruz. Ayrıca fark edebileceğiniz gibi arka plandaki işlemler tamamlandığında bir defaya mahsus bu bilgiyi `jobs` komutu çalıştırıldıktan sonra bize "Bitti" şeklinde iletiyor. 

Eğer daha önce `jobs` komutu ile hakkında bilgi aldığımız komutun değişen bir durumu olup olmadığını teyit etmek istersek `-n` seçeneğini kullanabiliriz. Bu seçeneğinde ardından eğer daha önce `jobs` komutu ile kontrol ettiğimiz bir görevde değişiklik olduysa çıktı alırız, aksi halde hiç bir çıktı basılmaz.

```bash
taylan@taylan:~$ jobs
[2]+  Durdu                   sleep 102
taylan@taylan:~$ bg "%sleep 102" 
[2]+ sleep 102 &
taylan@taylan:~$ jobs -n
[2]+  Bitti                   sleep 102
taylan@taylan:~$
```

Yalnızca işlerin işlem numaralarını almak istersek `-p` seçeneğini kullanabiliriz. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2120
taylan@taylan:~$ sleep 102 &
[2] 2121
taylan@taylan:~$ jobs -p
2120
2121
taylan@taylan:~$ jobs -l
[1]-  2120 Çalışıyor           sleep 101 &
[2]+  2121 Çalışıyor           sleep 102 &
taylan@taylan:~$
```

Yalnızca çalışmakta olan işleri listelemek istersek `-r` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ sleep 201 &
[1] 2328
taylan@taylan:~$ sleep 202
^Z
[2]+  Durdu                   sleep 202
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 201 &
[2]+  Durdu                   sleep 202
taylan@taylan:~$ jobs -r
[1]-  Çalışıyor           sleep 201 &
taylan@taylan:~$
```

Yalnızca durdurulmuş olan işleri listelemek için `-s` seçeneğini kullanabiliriz.

```bash
taylan@taylan:~$ sleep 301 &
[1] 2346
taylan@taylan:~$ sleep 302
^Z
[2]+  Durdu                   sleep 302
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 301 &
[2]+  Durdu                   sleep 302
taylan@taylan:~$ jobs -s
[2]+  Durdu                   sleep 302
taylan@taylan:~$
```

`x` seçeneğini kullanarak; mevcut kabuktaki işlerin işlem numaralarını(pid) alıp başka bir komuta argüman olarak verebiliriz. Örneğin birkaç yeni işlem başlatıp en son işlemin işlem numarasını ekran bastırmayı deneyelim. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2157
taylan@taylan:~$ sleep 102 &
[2] 2158
taylan@taylan:~$ sleep 103 &
[3] 2159
taylan@taylan:~$ jobs
[1]   Çalışıyor           sleep 101 &
[2]-  Çalışıyor           sleep 102 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ jobs -x echo %3 
2159
taylan@taylan:~$ jobs -l
[1]   2157 Çalışıyor           sleep 101 &
[2]-  2158 Çalışıyor           sleep 102 &
[3]+  2159 Çalışıyor           sleep 103 &
taylan@taylan:~$ jobs -x echo %3 
2159
taylan@taylan:~$
```

Biz burada yalnızca işlem numarasını `echo` komutu yardımıyla bastırdık fakat sizler dilediğiniz komuta işlem numaralarını argüman olarak verebilirsiniz. Örneğin `kill` komutuna `jobs -x kill -9 %%` şeklinde argüman olarak verdiğinizde mevcut kabuktaki en son çalıştırılan görev sonlandırılır. Özetle işlem numarası ile çalışabilecek tüm komutlara, mevcut kabuk üzerinde çalıştırılmış olan görevlerin işlem numaralarını iletebilirsiniz.

Mevcut kabuktaki görevleri belirtirken yüzde işareti `%` kullandığımızı fark etmişsinizdir. Bu işaret işi belirtme anlamında yani "jobspec" olarak anılır. İşleri `jobs` komutu ile sıraladığımızda sol tarafta zaten iş numaraları sıralı şekilde listeleniyor. Bu numaraları ya da alternatif kısayolları kullanarak mevcut kabuk üzerindeki işleri kolayca kontrol edebiliriz. Kullanım örnekleri için aşağıya göz atabilirsiniz.

`%iş_numarası` : iş numarası belirtilmiş işlemi kapsar.

`%komut` : tam komut adı belirtilmiş işi kapsar.

`%+` ya da `%%` : her iki kullanım da iş tablosundaki en son işi kapsar.

`%-` : iş tablosundaki sondan bir önceki işi kapsar.

Aşağıdaki çıktılara bakarak bu durumu kendiniz de teyit edebilirsiniz.

```bash
└─$ sleep 201&
[1] 3013
└─$ sleep 202&
[2] 3014
└─$ sleep 203&
[3] 3015
└─$ sleep 204&
[4] 3016
└─$ jobs -l
[1]   3013 Running                 sleep 201 &
[2]   3014 Running                 sleep 202 &
[3]-  3015 Running                 sleep 203 &
[4]+  3016 Running                 sleep 204 &
└─$ jobs -x echo %%
3016
└─$ jobs -x echo %+
3016
└─$ jobs -x echo %-
3015
└─$ jobs -x echo %1
3013
```

Zaten `jobs` komutunun çıktılarında da en son görev için artı ve en sondan bir önceki için eksi işareti açıkça görülebiliyor. Burada jobs komutu için kullandığımız jobspec "%" kısayolları aynen diğer iş kontrol komutları için de geçerlidir. Yani iş kontrolü için kullanılan "bg, fg, kill, jobs, wait, disown, nohup, suspend" komutlarının hepsinde aynı yaklaşımı izleyebilirsiniz.