# enable Komutu

`enable` komutu bash kabuğu içerisinde yerleşik(builtin) olarak bulunan bir komuttur. Bu komutun işlevi yerleşik komutların çalıştırılma önceliğini devredışı bırakmaktır. Normal şartlarda bizler kabuğa bir komut girdiğimizde bu komut ilk olarak yerleşik komutlar içerisinde aranır daha sonra disk üzerindeki diğer komutlara bakılır. Yani eğer yerleşik komut ile aynı isme sahip harici bir araç varsa, bu aracı doğrudan ismini vererek çalıştırmak için yerleşik komutların önceliğini devredışı bırakabiliriz.(Eğer harici aracın adı yerine doğrudan disk üzerindeki tam konumunu belirtirseniz ilgili araç doğrudan açılacaktır, çünkü kabuğun öncelik sırasına göre aranması gerekmez.)

Eğer herhangi bir seçenek ya da argüman olmadan konsola `enable` komutu girilirse, aktif olan yerleşik komutların bir listesini alırız. Buradaki aktiflikten kasıt, üst kısımda açıkladığımız; konsola girilen ifadelerin öncelikle yerleşik olan komutlar üzerinde aranmasıdır. Eğer komut aktifse o komut öncelikli olacak çalıştırılır.

## Yerleşik Komutu Devre Dışı Bırakmak

Yerleşik komutların çalıştırılma önceliğini devre dışı bırakmak istersek `enable` komutunun `-n` seçeneğini kullanabiliriz. Örneğin denemek için yerleşik olan `jobs` komutunu ile aynı isimde bir betik dosyası oluşturup bu betik dosyasının öncelikli olarak çalıştırılmasını sağlayalım. Adım adım ilerleyelim; 

Aynı isimli betik dosyası oluşturuyorum ve dosyama çalıştırma yetkisi verip çalışma durumunu test ediyorum.

```bash
taylan@taylan:~$ echo  "echo 'Ben jobs komutunun yerini aldım'" > jobs
taylan@taylan:~$ chmod +x jobs
taylan@taylan:~$ ./jobs 
Ben jobs komutunun yerini aldım
taylan@taylan:~$
```

Betik dosyamızın çalıştığını teyit ettiğimize göre şimdi konsol üzerinden ismi ile çalıştırılabilmesi için PATH yolu üzerinde bir konuma taşıyalım. 

```bash
taylan@taylan:~$ sudo mv jobs /usr/local/bin/
[sudo] password for taylan: 
taylan@taylan:~$
```

Bu sayede konsola `jobs` yazdığımızda bu betik dosyası çalıştırılacak fakat aynı isimli bir yerleşik komut bulunduğu için betik dosyasından önce yerleşik komut çalıştırılıyor. Bu durumu önlemek için konsola `enable -n jobs` komutunu girmemiz yeterli. Bu sayede `jobs` yerleşik komutu artık önceliğini kaybetmiş oluyor. Aşağıdaki çıktılara göz atarak bu durumu teyit edebilirsiniz.

```bash
taylan@taylan:~$ sleep 101 &
[1] 2307
taylan@taylan:~$ jobs
[1]+  Çalışıyor           sleep 101 &
taylan@taylan:~$ enable -n jobs
taylan@taylan:~$ jobs
Ben jobs komutunun yerini aldım
taylan@taylan:~$
```

Devredışı bırakma durumunu yalnızca `enable` komutunu girip, çıktılarda `jobs` yerleşik komutunun yer almıyor olmasıyla da teyit edebiliriz. Ayrıca bu değişikliğin yalnızca çalışmakta olduğumuz mevcut kabuk üzerinde geçerli olduğunu da unutmayın. Yani kabuğu kapattığımızda ya da yeni bir kabuk açtığımızda bu değişiklik de geçerliliğini yitirmiş olacak.

enable komutunun alabileceği bazı ek seçenekler de mevcut;

### -a

Tüm yerleşik komutları etkin olup olmama durumları ile birlikte liste halinde sunar. Etkin olmayan komutlar liste içerisinde "**enable -n komut_adı**" şeklinde gözükür.

### -p

Aktif olan yerleşik komutların listesini verir. Yalnızca `enable` komutunu kullanıldığında da aynı çıktı elde edilir.

### -s

Yalnızca POSIX uyumlu olan ve devre dışı bırakılmamış yani aktif yerleşik komutların listesini verir.