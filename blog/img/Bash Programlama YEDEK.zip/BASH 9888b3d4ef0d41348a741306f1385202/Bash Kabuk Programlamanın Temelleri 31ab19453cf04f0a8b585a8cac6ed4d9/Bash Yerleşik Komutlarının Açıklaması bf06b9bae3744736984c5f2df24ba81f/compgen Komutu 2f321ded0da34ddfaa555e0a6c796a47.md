# compgen Komutu

OTOMATİK TAMMALAMA NASIL ÇALIŞIR BUNU AYRICA ELE ALIP ALMAYACAĞIN KARAR VER

Bash kabuğunun oldukça kullanışlı özelliği olan otomatik tamamlama özelliğinin doğru şekilde çalışabilmesini sağlar. Bu komut, sistem üzerinde bash tarafından kullanılabilir olan komutların bilgisini tutar ve otomatik tamamlama esnasında bu bilgiler bash kabuğu tarafından kullanılır. Kısacası bash için gerektiğinde ulaşabileceği kategorize bir komut listesi sunar. Bizler bu komutu kullanarak kullanılabilir olan komutların listesini alabiliriz.

## Kullanılabilir Olan Komutları Listelemek | `-c` Seçeneği

Bash kabuğu tarafından kullanılabilir olan tüm komutların listesini almak için konsola `compgen -c` komutunu girmemiz yeterli.

```bash
taylan@taylan:~$ compgen -c
ls if then else elif fi case esac for select while until do done in function ...
```

## Bash Kabuğunun Yerleşik(builtin) Komutlarını Listelemek | `-b` Seçeneği

Bash kabuğu içerisinde varsayılan olarak yüklü gelen "**builtin**" yani "**yerleşik**" komutların hepsini listelemek için `compgen -b` komutunu kullanabiliriz. 

```bash
taylan@taylan:~$ compgen -b
. : [ alias bg bind break builtin caller cd command compgen complete compopt continue declare dirs disown echo enable eval exec exit export false fc fg getopts hash help history jobs kill let local logout mapfile popd printf pushd pwd read readarray readonly return set shift shopt source suspend test times trap true type typeset ulimit umask unalias unset wait
taylan@taylan:~$
```

## Kabuk Üzerinde Tanımlı Olan Takma Adları(alias) Listelemek | `-a` Seçeneği

Mevcut kabuk üzerinde tanımlı bulunan tüm takma adları(alias) listelemek için `compgen -a` komutunu kullanabiliriz. Denemek için yeni bir takma ad tanımlayıp komutumuzu test edelim.

```bash
taylan@taylan:~$ alias deneme="echo 'bu bir takma ad'"
taylan@taylan:~$ deneme
bu bir takma ad
taylan@taylan:~$ compgen -a
deneme
ls
taylan@taylan:~$
```

## Bash Kabuğunun Anahtar Kelimelerini(keyword) Listelemek | `-k` Seçeneği

Bash kabuğu üzerinde tıpkı yerleşik(builtin) komutlar gibi özel olarak tanımlanmış olan çeşitli anahtar kelimeler vardır. Bu kelimeler bash kabuğunun programlanabilmesi için bizlere yardımcı olur. Bash tarafından tanımlanmış olan anahtar kelimeleri görmek için konsola `compgen -k` komutunu girmemiz yeterli.

```bash
taylan@taylan:~$ compgen -k
if then else elif fi case esac for select while until do done in function time { } ! [[ ]] coproc
taylan@taylan:~$
```

## Bash Kabuğu Üzerinde Tanımlı Olan Fonksiyonları Listelemek | `-A function` Seçeneği

Mevcut bash kabuğu üzerinde kullanılabilir olan tüm fonksiyonları listelemek için `compgen -A function` komutunu kullanabiliriz. 

```bash
taylan@taylan:~$ compgen -A function
__expand_tilde_by_ref __get_cword_at_cursor_by_ref __git_eread __git_ps1 __git_ps1_colorize_gitstring __git_ps1_show_upstream __git_sequencer_status __load_completion __ltrim_colon_completions __parse_options __reassemble_comp_words_by_ref _allowed_groups _allowed_users _available_interfaces _bashcomp_try_faketty _cd _cd_devices _command _command_offset _complete _complete_as_root _completion_loader _configured_interfaces _count_args _dvd_devices _expand _export _filedir _filedir_xspec _fstypes _get_comp_words_by_ref _get_cword _get_first_arg _get_pword _gids _have _included_ssh_config_files _init_completion _installed_modules _ip_addresses _kernel_versions _known_hosts _known_hosts_real _longopt _mac_addresses _minimal _modules _ncpus _parse_help _parse_usage _pci_ids _pgids _pids _pnames _quote_readline_by_ref _realcommand _rl_enabled _root_command _service _services _shells _signals _split_longopt _sysvdirs _terms _tilde _uids _upvar _upvars _usb_ids _user_at_host _usergroup _userland _variables _xfunc _xinetd_services dequote quote quote_readline
taylan@taylan:~$
```

Compgen komutunun A seçeneğinin ardından kabuk üzerinde kullanılabilir olan pek çok yapı için istediğimiz seçenekleri kullanabiliriz.

COMP_TYPE: Tamamlama işlemi için basılmış olan tuşun ASCII kodundaki karşılığı basılır. 

Otomatik tamamlamada kabuk kendi değişkenlerini kullanır. normal tamamlanma için 9, belirsiz tamamlamalarla ilgili alternatifleri listelerken 33, menü tamamlama için 37, belirsiz tamamlamalar arasında sekme yaparken 63, kısmi tamamlamadan sonra tamamlamaları listelemek için 64'tür.

BUNLARDAN ÇOK DAHA FAZLASI İÇİN COMPLETE KOMUTUNA BAKK

[https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion-Builtins.html](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion-Builtins.html)

[https://titanwolf.org/Network/Articles/Article?AID=0648ead5-e7b3-4fc1-980b-ebb75f580cef#gsc.tab=0](https://titanwolf.org/Network/Articles/Article?AID=0648ead5-e7b3-4fc1-980b-ebb75f580cef#gsc.tab=0)

[https://blog.bouzekri.net/2017-01-28-custom-bash-autocomplete-script.html](https://blog.bouzekri.net/2017-01-28-custom-bash-autocomplete-script.html)