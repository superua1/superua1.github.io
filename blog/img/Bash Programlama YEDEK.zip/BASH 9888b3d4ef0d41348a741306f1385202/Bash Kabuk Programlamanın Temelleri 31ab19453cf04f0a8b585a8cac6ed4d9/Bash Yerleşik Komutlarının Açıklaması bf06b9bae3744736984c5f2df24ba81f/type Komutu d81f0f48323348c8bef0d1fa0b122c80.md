# type Komutu

`type` komutu, kendisine argüman olarak verilmiş olan komutların türleri hakkında bize bilgi sunar. 

```bash
taylan@taylan:~$ type -p ls
taylan@taylan:~$ type ls
ls `ls --color=auto' için takma addır
taylan@taylan:~$
```

`type` komutuyla birlikte kullanabileceğimiz birkaç seçenek de mevcuttur;

`t` : Eğer komutun geçerli bir türü varsa varsa yalnızca türü yazdır. Çıktı olarak alınabilecek komut türleri aşağıdaki gibidir.

- alias = kabukta tanımlı "takma adlar"
- function = kabukta tanımlı "fonksiyonlar"
- builtin = kabukta "yerleşik" olan komutlar
- file = sistemde yüklü bulunan harici komutlar
- keyword  = kabuğa özel olarak ayrılmış kelimeler

```bash
taylan@taylan:~$ alias yaz="echo 'ben takma ad'"
taylan@taylan:~$ type -t yaz 
alias
taylan@taylan:~$ type -t mkdir
file
taylan@taylan:~$ type -t pwd
builtin
taylan@taylan:~$ type -t if
keyword
taylan@taylan:~$ fonksiyon(){ echo "test fonksiyonuyum"; }
taylan@taylan:~$ type -t fonksiyon 
function
taylan@taylan:~$
```

`a` argüman olarak verilmiş olan komut ismiyle eşleşen tüm tür bilgileri listelenir. 

```bash
taylan@taylan:~$ type -a ls
ls `ls --color=auto' için takma addır
ls /usr/bin/ls'dir
ls /bin/ls'dir
taylan@taylan:~$ type -a echo
echo bir kabuk yerleşiğidir
echo /usr/bin/echo'dir
echo /bin/echo'dir
taylan@taylan:~$
```

`p` yalnızca sistem üzerinde yüklü bulunan harici komut hakkında bilgi sunar. Eğer argüman olarak verilmiş olan komut "harici" komut değilse herhangi bir çıktı basılmaz.

```bash
taylan@taylan:~$ type -p ls
taylan@taylan:~$ type -p mkdir 
/usr/bin/mkdir
taylan@taylan:~$
```

`p` argüman olarak verilmiş olan ifadenin hangi türden olduğuna bakmadan ilgili ifadeyi PATH yolu üzerindeki konumlarda arar. Eğer mevcutsa çıktı olarak dizin adresini basar.

```bash
taylan@taylan:~$ type yaz
yaz `echo 'ben takma ad'' için takma addır
taylan@taylan:~$ type fonksiyon 
fonksiyon bir işlevdir
fonksiyon () 
{ 
    echo "test fonksiyonuyum"
}
taylan@taylan:~$ type -P yaz
taylan@taylan:~$ type -P fonksiyon 
taylan@taylan:~$ type -P pwd
/usr/bin/pwd
taylan@taylan:~$
```