# disown Komutu

`disown` komutu bash kabuğu içerisinde yerleşik(builtin) olarak bulunan bir komuttur. Temel görevi kendisine argüman olarak verilmiş işlemin, kabuk üzerinde tutulan iş kontrolü(job control) listesinden çıkarmaktır. Yani hedef süreç çalışmaya devam eder fakat işlemin iş kontrol(job control) tablosundan çıkarılması sağlanır. Bu sayede konsol kapatılsa dahi işlemin arka planda çalışmaya devam etmesi sağlanır. Normal şartlarda işlemin çalıştırıldığı kabuk kapatılırken **SIGHUP** sinyali ile iş tablosundaki mevcut işler kabukla birlikte kapatılır.(Sinyaller konusundan daha sonra bahsedeceğiz.) Eğer `disown` komutu kullanıldıysa, işlemler iş tablosunda yer almayacağı için SIGHUP sinyaline de doğal olarak maruz kalmazlar.

<aside>
⚠️ Not: Örnekler esnasında kullanılan "gedit" aracı sadece basit bir metin düzenleme aracıdır. Bu araç dışında sizler test etmek için dilediğiniz herhangi bir aracı, yeni işlem başlatmak için kullanabilirsiniz.(Mümkünse grafiksel arayüze sahip bir uygulama seçin çünkü grafiksel arayüze sahip uygulamaların takibi görsel olarak daha kolaydır.) Ayrıca `sleep` komutu da benzer şekilde takip edilebilir yeni bir işlem başlatmak için kullanılmış olan bash kabuğundaki "belirtilen süre kadar bekletme" işlevini sağlayan test amaçlı kullanılmış bir komuttur. (Daha fazla bilgi için komutun açıklama sayfasına göz atabilirsiniz.)

</aside>

En temel kullanımı `disown işlem_numarası` şeklindedir. Elbette bu komutun(`disown`) mevcut kabuk üzerinde yazılabilmesi için ilgili işlemin arka planda başlatılması ya da başlatıldıktan sonra arka plana alınması gerekiyor. Bahsetmiş olduğumuz durumu test etmek için "gedit" isimli metin editörünü `gedit&` komutu ile arka planda başlatalım. Daha sonra konsolu kapatıp "gedit" aracının da kapatılıp kapatılmadığını teyit edelim. Bu işlemin ardından "gedit" aracının konsol yani mevcut kabukla birlikte sonlandırıldığına şahit oluyoruz. 

Bu durumu önlemek için `disown` komutunu kullanabiliriz. Test etmek için tekrar "gedit" aracını `gedit &` komutu ile arkaplanda çalıştıralım ve `jobs -l` komutu ile mevcut kabuk üzerinden çalıştırılmış olan işlerin işlem numaralarını listeleyelim. Daha sonra `disown` komutunun ardından işlem numarasını girip, işlemin iş tablosundan silinmesini sağlayalım. İş tablosundan silinip silinmediğini teyit etmek için tekrar `jobs -l` komutunu kullanabiliriz. Aldığımız çıktıda "gedit" aracı yer almamasına karşın "gedit" işlemi arka planda çalışmaya devam ediyor. Son olarak testi tamamlamak adına mevcut kabuğumuzu da kapatalım. Kabuğu kapattığımızda "gedit" aracının çalışmaya devam ettiğini de teyit edebiliyoruz. İşte `disown` komutu bu şekilde arka plandaki işlemleri iş tablosundan çıkararak kabuğun çıkarken uyguladığı HUB kapatma sinyalinden muaf tutuyor.

**Ek bir bilgi olarak;** eğer bizler işlem numarasını belirtmezsek yani `disown` komutunu tek başına kullanırsak, en son çalıştırılmış olan işlem üzerinde etkili olacaktır. Bu sebeple `gedit & disown` komutunu kullanarak doğrudan gedit aracının arka planda iş tablosuna yazılmadan çalışmasını sağlayabiliriz. 

Örneklerimizi işlem numarası üzerinden yaptık ancak işlem numarası yerine `j`obspec yani % yüzde işareti ile iş numarasını da kullanabiliriz. Örneğin arka planda birden fazla işlem başlatıp bu işlemleri iş numaralarını kullanarak sonlandıralım. 

```bash
taylan@taylan:~$ sleep 101 &
[1] 2660
taylan@taylan:~$ sleep 102 &
[2] 2661
taylan@taylan:~$ sleep 103 &
[3] 2662
taylan@taylan:~$ jobs
[1]   Çalışıyor           sleep 101 &
[2]-  Çalışıyor           sleep 102 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ disown %2
taylan@taylan:~$ jobs
[1]-  Çalışıyor           sleep 101 &
[3]+  Çalışıyor           sleep 103 &
taylan@taylan:~$ 
```

## Bu Komuta Ne Zaman İhtiyacımız Olur ?

Bu komutun kullanım alanı için; örneğin konsol üzerinden kabuğunuza komut vererek bir araç çalıştırdınız. Bir süre sonra konsol ile işiniz bittiğinde konsolu kapatmak fakat çalıştırmış olduğunuz aracın çalışmaya devam etmesini isterseniz `disown` komutunu kullanabilirsiniz. 

Bu temel kullanımı dışında ayrıca `disown` komutunun alabildiği birkaç seçenek de bulunuyor;

## İş Tablosundan Silmeden HUB Sinyaline Karşı Korumak

`disown` komutu ile `-h` seçeneği kullanıldığında işlem iş tablosundan çıkarılmaz fakat SIGHUB sinyaline karşı korunur. Denemek için gedit aracını arka planda başlatalım. Başlattıktan sonra `jobs -l` komutu ile işlemin iş tablosunda yer aldığını teyit edebiliriz. Teyit ettikten sonra `disown -h işlem_numarası` şeklinde komutumuzu girelim ve tekrar iş tablosunu listelemek üzere `jobs -l` komutunu verelim. İş tablosundan gedit işleminin silinmediğini görebiliyoruz. Şimdi testi tamamlamak için mevcut kabuğumuzu kapatalım. Kabuğumuzu kapattığımızda gedit aracı çalışmaya devam ediyor.  Çünkü bizler `disown -h` komutu ile iş listesinden çıkarmadan işlemin HUB sinyali ile kapatılmasını önledik.

## Mevcut Kabuktaki Tüm İşlemleri İş Tablosundan Silmek ve HUB Sinyaline Karşı Korumak

`disown` komutunun, `-a` seçeneği kullanıldığında tüm işlemleri iş tablosundan kaldırarak **SIGHUB** sinyaline karşı korunur. Üstelik iş tablosunda yer alan işlemlerin çalışıyor ya da durdurulmuş olması fark etmez. Hemen denemek için `sleep 101 &` komutu ile arka planda ilk işlemimizi başlatalım, daha sonra `sleep 102` komutunun ardından "**Ctrl + Z"** tuşlaması ile başlatmış olduğumuz ikinci işlemi durduralım. Konsola `jobs -l` komutunu girdiğimizde ilk işlem & işareti sayesinde arka planda çalışmaya devam ederken ikinci işlemin **Ctrl + Z** tuşlaması sayesinde duraklatılmış olduğunu teyit edebiliyoruz. Şimdi tüm bu işlemleri iş tablosundan kaldırmak istersek `disown -a` komutunu girmemiz yeterli. Bu komutun ardından tekrar `jobs -l` komutunu girerek iş tablosunun silinmiş olduğunu görebiliyoruz. Bu da mevcut kabuk kapatılırken bu işlemlerin kapatılmayacağı(kabuk kapatılırken HUB sinyalinden etkilenmezler) anlamına geliyor.

## Mevcut Kabukta Çalışmakta Olan İşlemleri İş Tablosundan Silmek ve HUB Sinyaline Karşı Korumak

Eğer yalnızca arka planda **çalışmakta olan** tüm işlemleri tek seferde `disown` komutu ile kapsamak istersek `-r` seçeneğini kullanabiliriz. Bir üst başlıkta bahsetmiş olduğumuz özelliğe benzer şekilde çalışır fakat bu seçenekte durdurulmuş olan işlemler dahil edilmeden yalnızca çalışmakta olan işlemler dikkate alınır. Denemek için arka planda iki adet işlem başlatıp üçüncü işlemi de **Ctrl + Z** kısayolu(bu kısayol mevcut işleme durdurma sinyali göndermemiz sağlar) ile durduralım. Ve tüm bu süreci `jobs -l` komutu ile teyit edelim.

```bash
taylan@taylan:~$ jobs -l                                                  
taylan@taylan:~$ sleep 201 &
[1] 2247                                                                  
taylan@taylan:~$ sleep 202 &                                             
[2] 2248                                                                  
taylan@taylan:~$ sleep 203
^Z
[3]+  Durdu                   sleep 203
taylan@taylan:~$ jobs -l
[1]   2247 Çalışıyor           sleep 201 &
[2]-  2248 Çalışıyor           sleep 202 &
[3]+  2250 Durduruldu              sleep 203
taylan@taylan:~$
```

Şimdi de yalnızca çalışmakta olan işlemleri kapsamak üzere konsola `disown -r` komutunu girelim. Buradaki `r` ifadesi zaten İngilizce olarak "**r**unning" yani "çalışan" ifadesinin kısaltmasından geliyor. Bu komutun hemen ardından iş tablosuna göz atmak üzere tekrar `jobs -l` komutunu girerek yalnızca çalışmakta olan işlemlerin iş tablosundan silindiğini teyit edebiliriz.

```bash
taylan@taylan:~$ disown -r
taylan@taylan:~$ jobs -l
[3]   2250 Durduruldu              sleep 203
taylan@taylan:~$
```

## HUB Sinyaline Karşı disown Komutu ile Korunmuş Olan İşlemi Sonlandırmak

Bu bölüme kadar `disown` komutunun kabuk kapatılırken çalıştırılan HUB kapatma sinyalinden işlemleri koruyabildiği üzerinde durduk. Fakat kullanıcı istediğinde `disown` komutu ile korunmuş olan işleme özellikle HUB kapatma sinyalini gönderip, işlemin sonlanmasını sağlayabilir. Çünkü `disown` komutunun asıl amacı, kabuk kapatılırken oluşturulan HUB sinyaline karşı işlemi koruyarak kabuk kapatılsa dahi ilgili işlemin devam edebilmesidir. Koruma altındaki işlemi sonlandırmak için `kill -s HUP işlem_numarası` şeklinde komutumuzu girmemiz yeterlidir. Grafiksel arayüze sahip bir araç ile test ettiyseniz, HUB sinyalini gönderdiğinizde aracın kapandığını teyit edebilirsiniz.

## Son Olarak

Eğer işleminiz kullanıcını `kill` komutunu girse dahi yani HUB sinyali özellikle gönderilse dahi sonlandırılsın istemezseniz `nohup` isimli komutu kullanabilirsiniz. `disown` komutu ile `nohup` komutu arasındaki fark, `nohup` ile başlayan işlemin, sinyali kimin gönderdiği fark etmeksizin HUP yani kapatma sinyalini yok saymasıdır. 

Eğer `nohup` komutu hakkında bilgi sahibi değilseniz mutlaka buradan komutun açıklamasına da ayrıca göz atın.

huponexit işlevi shopt komutu ile atnmaışsa davranış farklı oluyor galiba:"[https://unix.stackexchange.com/questions/484276/do-disown-h-and-nohup-work-effectively-the-same](https://unix.stackexchange.com/questions/484276/do-disown-h-and-nohup-work-effectively-the-same)"

[https://unix.stackexchange.com/questions/3886/difference-between-nohup-disown-and](https://unix.stackexchange.com/questions/3886/difference-between-nohup-disown-and)

[https://www.cyberciti.biz/faq/unix-linux-disown-command-examples-usage-syntax/#:~:text=Syntax,-The basic syntax&text=%3D> The disown command on ksh,given job or all jobs](https://www.cyberciti.biz/faq/unix-linux-disown-command-examples-usage-syntax/#:~:text=Syntax,-The%20basic%20syntax&text=%3D%3E%20The%20disown%20command%20on%20ksh,given%20job%20or%20all%20jobs).

This is my understanding about the usage of `&`, `disown` and `nohup`:

- `<command>`: runs the process within the Terminal's current `bash` instance, **in the foreground** (i.e. the process is listed as a `bash` foreground job and `stdin`, `stdout` and `stderr` are still **bound to the terminal**); **not immune to hangups**;
- `<command> &`: runs the process within the Terminal's current `bash` instance, **in the background** (i.e. the process is listed as a `bash` background job and `stdin`, `stdout` and `stderr` are still **bound to the terminal**); **not immune to hangups**;
- `<command> & disown`: runs the process within the Terminal's current `bash` instance, **in the background**, but the process is **detached from the `bash`'s jobs' list** (i.e. the process is not listed as a `bash` foreground / background job and `stdin`, `stdout` and `stderr` are still **bound to the terminal**); **immune to hangups**;
- `nohup <command> & disown`: runs the process within the Terminal's current `bash` instance, **in the background**, but the process is **detached from the `bash`'s jobs' list** (i.e. the process is not listed as a `bash` foreground / background job and `stdin`, `stdout` and `stderr` are **not** still **bound to the terminal**);**immune to hangups**;

So, aside from `nohup <command> & disown` blocking `stdin` and redirecting `stdout` and `stderr` to `nohup.out` by default, it seems to me like it can be considered totally equivalent to `<command> & disown`.

Is the above all correct? Any misconception?

[https://askubuntu.com/questions/611968/differences-between-command-disown-and-nohup-command-disown](https://askubuntu.com/questions/611968/differences-between-command-disown-and-nohup-command-disown)