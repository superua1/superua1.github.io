# export Komutu

export komutu bash kabuğunda yerleşik(builtin) olan komuttur. Mevcut kabuk üzerinde tanımlı olan değişkenleri ve fonksiyonları alt kabuklara aktarma görevini üstlenir. Denemek için mevcut kabuğumuz üzerinde yeni bir değişken tanımlayıp, bir alt kabuktan bu değişkene ulaşıp ulaşamayacağımızı test edelim.

```bash
taylan@taylan:~$ ben="taylan"
taylan@taylan:~$ echo $ben 
taylan
taylan@taylan:~$ bash
taylan@taylan:~$ echo $ben

taylan@taylan:~$
```

Çıktıları incelediğimizde alt kabuktan,(`bash` komutu ile mevcut kabuk altında yeni bir alt kabuk başlatmış olduk.) üst kabukta tanımladığımız değişkene ulaşamadığımızı gördük. Şimdi `export` komutu ile tanımlamış olduğumuz değişkeni alt kabuklara aktarıp aynı işlemi tekrar deneyelim.

```bash
taylan@taylan:~$ export ben="taylan"
taylan@taylan:~$ echo $ben 
taylan
taylan@taylan:~$ bash
taylan@taylan:~$ echo $ben 
taylan
taylan@taylan:~$
```

## Fonksiyonları Alt Kabuklara Aktarmak | `export -f`

Değişkenler dışında dilersek alt kabuklara aktarma işini `export` komutunun `-f` seçeneği ile fonksiyonlar için de uygulayabiliriz. Öncelikle `export` etmeden alt kabuk üzerinden fonksiyonlara ulaşılamadığını teyit edelim.

```bash
taylan@taylan:~$ function adım {
> echo "ben taylan"
> }
taylan@taylan:~$ adım
ben taylan
taylan@taylan:~$ bash
taylan@taylan:~$ adım
bash: adım: komut yok
taylan@taylan:~$
```

Gördüğünüz gibi fonksiyonlar da `export` edilmediği sürece tanımlandıkları kabuklar üzerinde geçerli. Şimdi tanımlamış olduğumuz fonksiyonu `export-f` komutu ile alt kabuklarda da geçerli kılalım.

```bash
taylan@taylan:~$ function adım {
> echo "ben taylan"
> }
taylan@taylan:~$ adım 
ben taylan
taylan@taylan:~$ export -f adım
taylan@taylan:~$ bash
taylan@taylan:~$ adım
ben taylan
taylan@taylan:~$
```

## Alt Kabuğa Aktarmayı İptal Etmek

Eğer `export` ettiğimiz fonksiyon ya da değişkenin artık alt kabuklardan ulaşılmasını istemiyorsak, `export` komutuyla birlikte `-n` seçeneğini kullanabiliriz. Biz örnek olması açısından değişken üzerinden test edelim fakat fonksiyonlar için de aynı şekilde kullanılabilir.

```bash
taylan@taylan:~$ export ben="taylan"
taylan@taylan:~$ bash
taylan@taylan:~$ echo $ben 
taylan
taylan@taylan:~$ exit
exit
taylan@taylan:~$ export -n ben 
taylan@taylan:~$ bash
taylan@taylan:~$ echo $ben

taylan@taylan:~$
```

Çıktıları incelerken fark ettiyseniz `exit` komutu ile alt kabuğu kapatıp üst kabuğa döndüm bu sayede en üstteki kabukta artık bu değişkenin alt kabuklarda geçeli olmayacağını bildirmiş oldum.

## Alt Kabuklara Aktarılmış Fonksiyonları ve Değişkenleri Listelemek

Alt kabuklara aktarılmış yani `export` edilmiş olan fonksiyon ve değişken değerlerini listelemek için `export` komutunun `-p` seçeneğini kullanabiliriz. Ekleme ve çıkarma işlemlerinin geçerli olup olmadığını bu liste üzerinden rahatlıkla teyit edebilirsiniz. 

```bash
taylan@taylan:~$ export -p
declare -x CLUTTER_IM_MODULE="ibus"
declare -x COLORFGBG="15;0"
declare -x DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/1000/bus"
declare -x DESKTOP_SESSION="lightdm-xsession"
declare -x DISPLAY=":0.0"
declare -x GDMSESSION="lightdm-xsession"
declare -x GTK_IM_MODULE="ibus"
declare -x GTK_MODULES="gail:atk-bridge"
declare -x HOME="/home/taylan"
...
..
```

Liste içerisinde gözüken `declare` ifadesi de aslında bash yerleşik komutudur ve kısaca değişkenleri yönetme konusunda bize yardımcı olur. Daha fazla detay almak için açıklama sayfasına ayrıca göz atabilirsiniz.