# getopts Komutu

`getopts` komutu bash kabuğu içerisinde yerleşik olan bir komuttur.

Konsola girdiğimiz komutların davranışlarını değiştiren seçeneklerin tanımlanabilmesini sağlıyor. Burada bahsi geçen seçeneklere örnek vermemiz gerekirse örneğin ls komutunu tek başına kullandığınızda gizli dosyalar listelenmez. Eğer ls komutunun a seçeneğini kullanırsanız gizli dosyalar da listelenir. İşte bizler de kendi yazdığımız bash araçları için seçenek tanımlarken getopts komutunu kullanıyoruz. Bu sayede kullanıcı seçenekleri kullanarak aracımızın davranışlarını yönetebiliyor.

[https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch08lev1sec9.html](https://se.ifmo.ru/~ad/Documentation/Shells_by_Example/ch08lev1sec9.html)