# mapfile ve readarray Komutu

Temelde `mapfile` ve `readarray` komutları aynı görevi üstlenirler. Girdi olarak belirtilmiş olan dosyadaki satırları bir dizi değişkenine aktarır.

## mapfile

Standart girdiden okuduğu satırları, dizi değişkeni olarak sıralar. Kullanım seçenekleri aşağıdaki tablodaki gibidir.

- **-n**  *count*
Okunacak maksimum satır belirtir.  Eğer değer sıfır verilirse tüm satırlar kopyalanır.
- **O** *origin*
Hangi numaradan itibaren dizilerin sıralanacağını belirtir. Varsayılan olarak tüm dizi elemanları sıfırdan itibaren sıralanır.
- **s** *count*
İlk dizme işlemine başlamadan önce *count* satırınına kadar olan bölümü atar.
- **t**
Eğer yeni satıra geçilirse yani newline varsa buradan itibaren diziye böler.
- **u** *fd*
Standart girdi yerine *fd* dosya tanımlayıcısındaki satırları okuyun.
- **C** *callback*
Execute/evaluate a function/expression, *callback*, every time *quantum* lines are read. The default value of *quantum* is **1**, unless otherwise specified with **c**.
- **c** *quantum*
Specify the number of lines, *quantum*, after which function/expression *callback* should be executed/evaluated if specified with **C**.
- *array*
The name of the array variable where lines should be written. If  *array*  is omitted, the default variable  **MAPFILE**  is the target.