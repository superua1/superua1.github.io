# logout Komutu

Mevcut oturum açma kabuğundan çıkmamızı sağlar. `exit` komutuna benzer şekilde çalışır fakat `logout` komutu yalnızca oturum açma kabuklarında etkilidir. Bu komutun hangi durumda kullanılacağını daha net kavrayabilmek için öncelikle kabuk türlerinin neler olduğunu kısaca açıklamamız gerekiyor.

Kabuklar, çalıştıkları modlara göre birkaç farklı şekilde ifade edilebiliyor.

- Login Shell - Giriş Kabuğu
- Unlogin - Giriş Yapılmamış Kabuk
- Interactive Shell - Etkileşimli kabuk
- Non-Interactive Shell - Etkileşimsiz kabuk

### Login Shell - Giriş Kabuğu

Kullanıcı hesabına giriş yapmak için kullanılan kabuktur. Biz bu kabuk üzerinden hesabımızda oturum açabiliyoruz. Örneğin ssh istemcisi ile uzak masaüstüne bağlandığımızda aslında giriş kabuğu(login shell) kullanmış oluyoruz. Bunun dışında elbette sisteme giriş yapmak üzere komut satırı arayüzünü(cli) kullanırken(geçiş için <kbd>Ctrl + Alt + F1</kbd> ya da <kbd>Ctrl + Alt + F2</kbd>,**F3**..**F4**..**F5** kısayollarını kullanabilirsiniz) de aslında giriş kabuğu üzerinde çalışmış oluyoruz. 
Giriş kabuğu üzerinde oturum açtıktan sonra eğer `logout` komutunu girersek, açmış olduğumuz mevcut oturumdan çıkış yapmış oluruz.

Giriş kabukları başlangıçta **~/.bash_profile**, **~/.bash_login**, ve **~/.profile** dosyalarını okuyarak ortam için gerekli olan konfigürasyonlarını bu dosyalara göre yapılandırırlar. Yani giriş kabuğu üzerinde etkili olacak ayarlama yapmak isterseniz, değişikliği bu dosyalardan birinin içerisinde belirttiğinizden emin olun.

Not: Giriş yapmak için grafiksel arayüzü kullandığınızda aslında pencere ve oturum yöneticileri ile çalışmış oluyorsunuz. Yani grafiksel arayüz kullanarak sistem üzerinde oturum açarken giriş kabuğunu kullanıyor olmazsınız.

### Unlogin/Giriş Yapılmamış Kabuk

Giriş kabuğunda oturum açmış olan kullanıcı yeni bir işlem için alt kabuk oluşturduğunda bu kabuğa verilen isimdir. Kullanıcı zaten oturum açtığı için mevcut kullanıcı oturumu altında oluşturulan tüm alt kabuklar bu kategoride sayılırlar. Bu kabuk türü de gerekli ortamı oluşturmak adına öncelikle **/etc/bash.bashrc** dosyasını ve daha sonra her bir kullanıcıya özgü olan ve ana dizinde bulunan **.bashrc** dosyasını okur. Yani gerektiğinde bu kabuk türünü etkileyecek konfigürasyon değişiklikleri ihtiyacınıza göre ilgili dosyaya ekleyebilirsiniz. Sistem genelinde tüm kullanıcılar için **/etc/bash.bashrc**, sadece tek bir kullanıcı içinse kullanıcı ev dizininde yer alan **.bashrc** dosyasını değişikleri geçerli kılmak için kullanabilirsiniz.

### Interactive Shell/Etkileşimli kabuk

Kabuk, kullanıcı ile etkileşim imkanı sunan herhangi bir terminal aracına bağlandığında bu kabuğa etkileşimli kabuk denir. Örneğin grafiksel arayüzü kullanarak çalıştırdığınız bir terminal aracı etkileşimli kabuğa sahiptir. Terminal aracı, bize yani kullanıcıya kabuk ile etkileşime geçme imkanı sağlayan aracı bir katmandır sadece. Çalışmakta olduğunuz ortamın etkileşimli kabuk olup olmadığını anlamak için `echo $-` komutunu girmeniz yeterli. Çıktılarda "i" ifadesi yer alıyorsa bu ifade "**i**nteractive" ifadesinin kısaltmasını yani "etkileşimli" kabuk ortamında çalıştığınızı belirtir.

### Non-Interactive Shell/Etkileşimsiz kabuk

Kullanıcıdan input beklemeyen yani kullanıcı ile etkileşimde bulunmasına gerek olmayan kabuğa verilen genel isimdir. Örneğin sistem üzerinde herhangi bir betik dosyasının otomatik olarak çalışması için zamanlama(crontab) ayarı yaptıysak, betik dosyası terminal aracına ve elbette kullanıcı etkileşimine ihtiyaç duymadan arkaplanda çalışacaktır. İşte bu kabuğa etkileşimsiz kabuk deniyor.

Hemen test etmek üzere `echo $- > sonuc.txt` komutunu bir betik dosyasının içerisine yazıp betik dosyamızı çalıştıralım. Buradaki komut sayesinde betik dosyasının çalıştırıldığı ortamın bilgisi sonuc.txt dosyasına kaydediliyor olacak. Betik dosyası konsol arayüzüne ihtiyaç duymadan çalıştığı için sonuc.txt dosyasına baktığımızda sadece "hB" ifadesinin yer aldığını görüyoruz. Yani etkileşimli kabuk olduğunu belirten "i" ifadesi çıktıda basılmamış. Bu durum da betik dosyasının çalıştırıldığı kabuğun etkileşimsiz kabuk olduğunu kanıtlıyor.

**Not:** Betik dosyaları çalıştırılırken etkileşimli olmayan kabuk üzerinde çalıştırılır ancak kullanıcıdan veri alınmasının gerekli olduğu durumlarda etkileşimli kabuk taklit edilebilir. Yani eğer betik dosyası kullanıcıdan veri girişi alması gerekiyorsa çalıştırıldığı ortam etkileşimsiz olsa da kullanıcı ile etkileşime geçebilir. Bu duruma örnek olarak, betik dosyası içerisindeki bir komutun gerektiğinde terminal aracını çalıştırıp kullanıcıdan veri girişi talep etmesini verebiliriz. 

Aşağıdaki diagram hangi konfigürasyon dosyasının ne hangi kabuk türü tarafından okunduğunu özetliyor.

![https://blog.flowblok.id.au/static/images/shell-startup.png](https://blog.flowblok.id.au/static/images/shell-startup.png)

Kabuk türleri hakkında aşağı bak;

[https://relentlesscoding.com/posts/whats-the-difference-between-a-login-and-a-nonlogin-shell/](https://relentlesscoding.com/posts/whats-the-difference-between-a-login-and-a-nonlogin-shell/)