# Değişken Açıklamaları

## Bash Kabuğunda Tanımlı Olan Değişkenler

[B](https://www.gnu.org/software/bash/manual/html_node/Bash-Variables.html)urada yer alan değişken açıklamaları ihtiyaç duymanız halinde kullanabilmeniz için eklendiğinden, bazı değişkenlerin eğitimin bu aşamasında anlaşılması biraz güç olabilir. Yani eğer eğitimi sırasıyla takip ediyorsanız ve burada yer alan bazı değişken açıklamalarını anlamlandıramıyorsanız hiç bir sorun yok. Buradaki değişkenleri ezberlemeniz ya da her birinin anlamını bu aşamada kavramanız beklenmiyor. Sadece ihtiyaç duydukça göz atmanız için buradalar. Değişken açıklamaları sırasında zaten ilgili değişkenin hangi konu kapsamında olduğuna da atıfta bulunuyor olacağız. Bu sayede kısaca değişkenleri hatırlamanız ve gerektiğinde daha fazla bilgi için ilgili konuya doğrudan ulaşmanız da mümkün olacaktır. Yine de vaktiniz olduğunda buradaki değişkenlerin hepsini gözden geçirmeniz, ileride ihtiyaç duyduğunuzda çağrışım yapması açısından çok iyi olacaktır. Eğitimi tamamladığınızda her bir değişken açıklaması zaten sizler için anlam ifade ediyor olacak. Hatta bu durumu eğitimin sonunda bu bölümü baştan sona kadar okuduğunuzda sizler de fark etmiş olacaksınız. 

**`BASH`**

Bash kabuğunu çalıştırmak için gerekli olan tam dizin adresini verir.

**`BASHOPTS`**

Mevcut kabukta aktif olan ortam seçeneklerinin iki nokta üst üste işareti ile ayrılmış listesini verir. Bahsi geçen ortam seçenekleri `shopt` komutu ile mevcut ortam için tanımlanmış olan özellikleridir. Bu değişken sabittir yani değeri elle değiştirilemez.(Eğer ortam özellikleri değiştirilirse, elbette bu değişkenin değerleri de otomatik olarak değişir. Ancak doğrudan müdahale ile yani tekrar değişken tanımlaması ile değiştirilemez.)

```bash
taylan@taylan:~$ echo $BASHOPTS 
cmdhist:complete_fullquote:expand_aliases:extquote:force_fignore:hostcomplete:interactive_comments:progcomp:promptvars:sourcepath
taylan@taylan:~$ BASHOPTS="yeni değer"
bash: BASHOPTS: readonly variable
```

**`BASHPID`**

Mevcut kullanımda olan bash kabuğunun işlem kimliğini verir. `$$` işareti ile karıştırılmamalıdır çünkü `$$` **ana kabuğun işlem numarasını** verir. Örneğin alt kabuk altında bu iki değişken değeri çağırılırsa; `BASHPID` değişkeni mevcut kabuğun(yani alt kabuğun) süreç numarasını verirken, `$$` değişkeni ana kabuğun işlem numarasını verir. `BASHPID` değişkeni v4.0 ile geldiği için eski sürümlerde bu değişken tanımlı değildir. Bahsi geçen farkı gözlemlemek adına ana kabukta ve alt kabuklarda ilgili değişkenlerin hangi işlem numaralarını verdiğine bakabilirsiniz.

```bash
taylan@taylan:~$ echo $$ $BASHPID #ANA KABUK
2318 2318
taylan@taylan:~$ (echo $$ $BASHPID) #ALT KABUK
2318 2872
taylan@taylan:~$ ( (echo $$ $BASHPID) ) # 2 ALT KABUK(İKİ KAT ALTTAKİ KABUK)
2318 2873
taylan@taylan:~$
```

Fark edebileceğiniz gibi `$$` değişkeni her daim ana kabuğun işlem numarasını verirken, `BASHPID` mevcut kabuğun işlem numarasını veriyor.

**`BASH_ALIASES`**

Üyeleri `alias`yerleşik tarafından muhafaza edildiği şekliyle dahili takma adlar listesine karşılık gelen bir ilişkilendirilebilir dizi değişkeni . ( [Bourne Shell Yerleşiklerine](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html#Bourne-Shell-Builtins) bakınız ). Bu diziye eklenen öğeler diğer ad listesinde görünür; ancak, dizi öğelerinin ayarlanmaması halihazırda takma adların takma ad listesinden kaldırılmasına neden olmaz. Eğer `BASH_ALIASES` ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`BASH_ARGC`**

Değerleri, geçerli bash yürütme çağrı yığınının her çerçevesindeki parametrelerin sayısı olan bir dizi değişkeni. Mevcut alt yordama parametre sayısı (kabuk işlevi veya komut ile yapılan `.`ya da `source`) yığının üst kısmında yer alır. Bir alt rutin yürütüldüğünde, aktarılan parametrelerin sayısı üzerine basılır `BASH_ARGC`. Kabuk `BASH_ARGC`yalnızca genişletilmiş hata ayıklama modundayken [ayarlanır (yerleşik](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin)`extdebug` seçeneğin açıklaması için [Shopt Yerleşikine](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin) bakın `shopt` ). `extdebug`Kabuğun bir betiği çalıştırmaya başladıktan sonra ayarlanması veya `extdebug`ayarlanmadığında bu değişkene referans verilmesi tutarsız değerlere neden olabilir.

**`BASH_ARGV`**

Geçerli bash yürütme çağrı yığınındaki tüm parametreleri içeren bir dizi değişkeni. Son alt yordam çağrısının son parametresi yığının en üstündedir; ilk çağrının ilk parametresi en alttadır. Bir alt rutin yürütüldüğünde, sağlanan parametreler üzerine basılır `BASH_ARGV`. Kabuk `BASH_ARGV`yalnızca genişletilmiş hata ayıklama modundayken [ayarlanır (yerleşik](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin)`extdebug` seçeneğin açıklaması için bkz [. Shopt Yerleşik](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin)`shopt` ). `extdebug`Kabuğun bir betiği çalıştırmaya başladıktan sonra ayarlanması veya `extdebug`ayarlanmadığında bu değişkene referans verilmesi tutarsız değerlere neden olabilir.

**`BASH_ARGV0`**

Başvurulduğunda, bu değişken, kabuğun veya kabuk betiğinin adına genişler (aynıdır `$0`; 0 özel parametresinin açıklaması için bkz. [Özel Parametreler](https://www.gnu.org/software/bash/manual/html_node/Special-Parameters.html#Special-Parameters) ). Atama, `BASH_ARGV0` atanan değerin de atanmasına neden olur `$0`. Eğer `BASH_ARGV0` ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`BASH_CMDS`**

Üyeleri, `hash`yerleşik tarafından sağlanan dahili komutlar tablosuna karşılık gelen bir ilişkilendirilebilir dizi değişkeni (bkz. [Bourne Kabuk Yerleşikleri](https://www.gnu.org/software/bash/manual/html_node/Bourne-Shell-Builtins.html#Bourne-Shell-Builtins) ). Bu diziye eklenen elemanlar hash tablosunda görünür; ancak, dizi öğelerinin ayarlanmaması, komut adlarının karma tablodan kaldırılmasına neden olmaz. Eğer `BASH_CMDS` ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`BASH_COMMAND`**

Kabuk bir tuzağın sonucu olarak bir komutu yürütmedikçe, o anda çalıştırılmakta olan veya yürütülecek olan komut, bu durumda bu, tuzak anında yürütülen komuttur.

**`BASH_COMPAT`**

Değer, kabuğun uyumluluk düzeyini ayarlamak için kullanılır. Çeşitli uyumluluk düzeylerinin ve bunların etkilerinin bir açıklaması için [Shopt Yerleşik](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin) bölümüne bakın . Değer, istenen uyumluluk seviyesine karşılık gelen bir ondalık sayı (ör., 4.2) veya bir tam sayı (ör., 42) olabilir. Eğer `BASH_COMPAT`boş bir dizeye ayarlanmazsa veya kümesidir, uyumluluk düzeyi geçerli sürümü için varsayılan olarak ayarlanır. Eğer `BASH_COMPAT`geçerli uyumluluk seviyelerden birini olmayan bir değere ayarlanır, kabuk bir hata iletisi basar ve geçerli sürümü için varsayılan uyumluluk düzeyi ayarlar. Geçerli uyumluluk seviyeleri `shopt`, yukarıda açıklanan yerleşik tarafından kabul edilen uyumluluk seçeneklerine karşılık gelir (örneğin, *uyumluluk42*4.2 ve 42'nin geçerli değerler olduğu anlamına gelir). Mevcut sürüm de geçerli bir değerdir.

**`BASH_ENV`**

Bash, bir kabuk betiğini yürütmek için çağrıldığında bu değişken ayarlanırsa, değeri genişletilir ve komut dosyası çalıştırılmadan önce okunacak bir başlangıç dosyasının adı olarak kullanılır. [Bash Başlangıç Dosyaları'na](https://www.gnu.org/software/bash/manual/html_node/Bash-Startup-Files.html#Bash-Startup-Files) bakın .

**`BASH_EXECUTION_STRING`**

Komut argümanı c çağrı seçeneği.

**`BASH_LINENO`**

Üyeleri, *FUNCNAME'in* karşılık gelen her üyesinin çağrıldığı kaynak dosyalardaki satır numaraları olan bir dizi değişkeni . `${BASH_LINENO[$i]}`kaynak dosyadaki ( `${BASH_SOURCE[$i+1]}`) `${FUNCNAME[$i]}`çağrılan (veya `${BASH_LINENO[$i-1]}`başka bir kabuk işlevi içinde referans verilmişse ) satır numarasıdır . `LINENO`Mevcut satır numarasını almak için kullanın .

**`BASH_LOADABLES_PATH`**

Kabuğun `enable`komut tarafından belirtilen dinamik olarak yüklenebilir yerleşikleri aradığı, iki nokta üst üste işaretiyle ayrılmış dizin listesi .

**`BASH_REMATCH`**

Üyeleri 'tarafından atanan bir dizi değişkeni= ~`[[`koşullu komuta ikili operatör (bkz. [Koşullu Yapılar](https://www.gnu.org/software/bash/manual/html_node/Conditional-Constructs.html#Conditional-Constructs) ). 0 dizinine sahip öğe, dizenin normal ifadenin tamamıyla eşleşen kısmıdır. *N* indisli eleman , dizenin *n* inci parantezli alt ifade ile eşleşen kısmıdır . Bu değişken salt okunurdur.

**`BASH_SOURCE`**

Üyeleri, dizi değişkenindeki karşılık gelen kabuk işlevi adlarının `FUNCNAME`tanımlandığı kaynak dosya adları olan bir dizi değişkeni. Kabuk işlevi `${FUNCNAME[$i]}`dosyada tanımlanır `${BASH_SOURCE[$i]}`ve`${BASH_SOURCE[$i+1]}`

**`BASH_SUBSHELL`**

Kabuk o ortamda çalışmaya başladığında, her bir alt kabuk veya alt kabuk ortamında bir artar. Başlangıç değeri 0'dır.

**`BASH_VERSINFO`**

Üyeleri, Bash'in bu örneği için sürüm bilgilerini tutan salt okunur bir dizi değişkeni (bkz. [Diziler](https://www.gnu.org/software/bash/manual/html_node/Arrays.html#Arrays) ). Dizi üyelerine atanan değerler aşağıdaki gibidir:**`BASH_VERSINFO[0]`**Ana sürüm numarası ( *sürüm* ).**`BASH_VERSINFO[1]`**Küçük sürüm numarası ( *sürüm* ).**`BASH_VERSINFO[2]`**Yama seviyesi.**`BASH_VERSINFO[3]`**Derleme sürümü.**`BASH_VERSINFO[4]`**Sürüm durumu (ör . *Beta1* ).**`BASH_VERSINFO[5]`**Değeri `MACHTYPE`.

**`BASH_VERSION`**

Kullanımda olan mevcut Bash kabuğunun sürüm numarasını verir.

**`BASH_XTRACEFD`**

Geçerli bir dosya tanımlayıcısına karşılık gelen bir tam sayıya ayarlanırsa, Bash oluşturulan izleme çıktısını 'set -x'bu dosya tanımlayıcısına etkinleştirilir. Bu, izleme çıktısının teşhis ve hata mesajlarından ayrılmasına izin verir. Dosya tanımlayıcısı `BASH_XTRACEFD`ayarlanmadığında veya yeni bir değer atandığında kapatılır . `BASH_XTRACEFD`Boş dizenin ayarının kaldırılması veya atanması, izleme çıktısının standart hataya gönderilmesine neden olur. `BASH_XTRACEFD`2'ye (standart hata dosya tanımlayıcısı) ayarlamanın ve ardından ayarın kaldırılmasının standart hatanın kapatılmasına neden olacağını unutmayın.

**`CHILD_MAX`**

Kabuğun hatırlaması için çıkılan çocuk durumu değerlerinin sayısını ayarlayın. Bash, bu değerin POSIX tarafından yönetilen bir minimumun altına düşürülmesine izin vermez ve bunun aşılamayacağı bir maksimum değer (şu anda 8192) vardır. Minimum değer sisteme bağlıdır.

**`COLUMNS`**

`select`Komut tarafından seçim listelerini yazdırırken terminal genişliğini belirlemek için kullanılır. Otomatik olarak eğer set `checkwinsize`seçeneği etkinleştirildiğinde (bkz [shopt yerleşiği](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin) ) veya alınmasından sonra interaktif bir kabukta `SIGWINCH`.

**`COMP_CWORD`**

`${COMP_WORDS}`Mevcut imleç konumunu içeren sözcüğün indeksi . Bu değişken yalnızca programlanabilir tamamlama araçları tarafından başlatılan kabuk işlevlerinde mevcuttur (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ).

**`COMP_LINE`**

Mevcut komut satırı. Bu değişken yalnızca programlanabilir tamamlama araçları tarafından başlatılan kabuk işlevlerinde ve harici komutlarda mevcuttur (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ).

**`COMP_POINT`**

Geçerli komutun başlangıcına göre mevcut imleç konumunun dizini. Mevcut imleç konumu mevcut komutun sonundaysa, bu değişkenin değeri şuna eşittir `${#COMP_LINE}`. Bu değişken yalnızca programlanabilir tamamlama araçları tarafından başlatılan kabuk işlevlerinde ve harici komutlarda mevcuttur (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ).

**`COMP_TYPE`**

Bir tamamlama işlevinin çağrılmasına neden olan, denenen tamamlanma türüne karşılık gelen bir tamsayı değerine ayarlayın: Normal tamamlanma için *TAB* , '?', birbirini izleyen sekmelerden sonra tamamlamaları listelemek için,'!', kısmi kelime tamamlama alternatiflerini listelemek için,'@', kelime değiştirilmemişse tamamlamaları listelemek için veya'%', menü tamamlama için. Bu değişken yalnızca programlanabilir tamamlama araçları tarafından başlatılan kabuk işlevlerinde ve harici komutlarda mevcuttur (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ).

**`COMP_KEY`**

Mevcut tamamlama işlevini çağırmak için kullanılan anahtar (veya bir tuş dizisinin son anahtarı).

**`COMP_WORDBREAKS`**

Readline kütüphanesinin kelime tamamlama yaparken kelime ayırıcı olarak değerlendirdiği karakter kümesi. Eğer `COMP_WORDBREAKS`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`COMP_WORDS`**

Geçerli komut satırındaki tek tek sözcüklerden oluşan bir dizi değişkeni. Satır, Readline'ın `COMP_WORDBREAKS`yukarıda açıklandığı gibi böldüğü için kelimelere bölünmüştür . Bu değişken yalnızca programlanabilir tamamlama araçları tarafından başlatılan kabuk işlevlerinde mevcuttur (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ).

**`COMPREPLY`**

Bash'in programlanabilir tamamlama tesisi tarafından çağrılan bir kabuk işlevi tarafından üretilen olası tamamlamaları okuduğu bir dizi değişkeni (bkz. [Programlanabilir Tamamlama](https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html#Programmable-Completion) ). Her dizi öğesi bir olası tamamlama içerir.

**`COPROC`**

Adsız bir işlemden çıktı ve giriş için dosya tanımlayıcılarını tutmak üzere oluşturulan bir dizi değişkeni (bkz. [Eş İşlemler](https://www.gnu.org/software/bash/manual/html_node/Coprocesses.html#Coprocesses) ).

**`DIRSTACK`**

Dizin yığınının mevcut içeriğini içeren bir dizi değişkeni. Dizinler, `dirs`yerleşik tarafından görüntülendikleri sırayla yığında görünür . Bu dizi değişkeninin üyelerine atama, halihazırda yığında bulunan dizinleri değiştirmek için kullanılabilir, ancak dizinleri eklemek ve kaldırmak için `pushd`ve `popd`yerleşikleri kullanılmalıdır. Bu değişkene atama, mevcut dizini değiştirmez. Eğer `DIRSTACK`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`EMACS`**

Bash, kabuk değer ile başladığında ortamda bu değişkeni bulursat', kabuğun bir Emacs kabuk tamponunda çalıştığını varsayar ve satır düzenlemeyi devre dışı bırakır.

**`ENV`**

Benzer `BASH_ENV`; kabuk POSIX Modunda çağrıldığında kullanılır (bkz. [Bash POSIX Modu](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html#Bash-POSIX-Mode) ).

**`EPOCHREALTIME`**

Bu parametreye her atıfta bulunulduğunda, Unix Epoch'tan beri mikro saniye tanecikli bir kayan nokta değeri olarak geçen saniye sayısına genişler (Epoch'un tanımı için C kütüphanesi işlevi *süresi* belgelerine bakın ). İçin yapılan atamalar `EPOCHREALTIME`dikkate alınmaz. Eğer `EPOCHREALTIME`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`EPOCHSECONDS`**

Bu parametreye her başvurulduğunda, Unix Epoch'tan bu yana geçen saniye sayısına genişler (Epoch'un tanımı için C kitaplığı işlevi *süresi* belgelerine bakın ). İçin yapılan atamalar `EPOCHSECONDS`dikkate alınmaz. Eğer `EPOCHSECONDS`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`EUID`**

Mevcut kullanıcının sayısal olarak etkin kullanıcı kimliği. Bu değişken salt okunurdur.

**`EXECIGNORE`**

Komut araması kullanılarak yok sayılacak dosya adlarının listesini tanımlayan iki nokta üst üste işaretiyle ayrılmış bir kabuk desenleri listesi (bkz. [Desen Eşleştirme](https://www.gnu.org/software/bash/manual/html_node/Pattern-Matching.html#Pattern-Matching) ) `PATH`. Tam yol adları bu modellerden biriyle eşleşen dosyalar, tamamlama ve `PATH`arama yoluyla komut çalıştırma amaçları için yürütülebilir dosyalar olarak kabul edilmez . Bu davranışını etkilemez `[`, `test`ve `[[` komutlar. Komut hash tablosundaki tam yol adları tabi değildir `EXECIGNORE`. Yürütülebilir bit setine sahip, ancak yürütülebilir dosyalar olmayan paylaşılan kitaplık dosyalarını yok saymak için bu değişkeni kullanın. Desen eşleştirme, `extglob`kabuk seçeneğinin ayarını onurlandırır .

**`FCEDIT`**

Düzenleyici tarafından varsayılan olarak kullanılan e`fc` yerleşik komuta seçenek .

**`FIGNORE`**

Dosya adı tamamlama gerçekleştirilirken göz ardı edilecek son eklerin iki nokta üst üste ile ayrılmış listesi. Soneki içindeki girdilerden biriyle `FIGNORE` eşleşen dosya adı, eşleşen dosya adları listesinden çıkarılır. Örnek bir değer '.o: ~'

**`FUNCNAME`**

Yürütme çağrı yığınında bulunan tüm kabuk işlevlerinin adlarını içeren bir dizi değişkeni. 0 indisli eleman, o anda çalışan herhangi bir kabuk fonksiyonunun adıdır. En alttaki öğe (endeksi en yüksek olan) `"main"`. Bu değişken yalnızca bir kabuk işlevi yürütülürken bulunur. Ödevlerin `FUNCNAME`hiçbir etkisi olmayacak. Eğer `FUNCNAME`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.Bu değişken `BASH_LINENO`ve ile kullanılabilir `BASH_SOURCE`. Her bir elemanı `FUNCNAME`olarak uygun parçalar vardır `BASH_LINENO`ve `BASH_SOURCE`çağrı yığını tarif etmek için. Örneğin `${FUNCNAME[$i]}`, dosyadan `${BASH_SOURCE[$i+1]}`satır numarasına çağrıldı `${BASH_LINENO[$i]}`. `caller`Yerleşik görüntüler bu bilgileri kullanarak mevcut çağrı yığını.

**`FUNCNEST`**

0'dan büyük bir sayısal değere ayarlanırsa, maksimum işlev iç içe geçme düzeyini tanımlar. Bu iç içe geçme düzeyini aşan işlev çağrıları, mevcut komutun iptal edilmesine neden olur.

**`GLOBIGNORE`**

Dosya adı genişletme ile yok sayılacak dosya adları kümesini tanımlayan iki nokta üst üste işaretiyle ayrılmış bir kalıp listesi. Bir dosya adı genişletme örüntüsüyle eşleşen bir dosya adı içindeki kalıplardan biriyle de eşleşirse `GLOBIGNORE`, eşleşme listesinden kaldırılır. Desen eşleştirme, `extglob`kabuk seçeneğinin ayarını onurlandırır .

**`GROUPS`**

Mevcut kullanıcının üyesi olduğu grupların listesini içeren bir dizi değişkeni. Ödevlerin `GROUPS`hiçbir etkisi olmayacak. Eğer `GROUPS`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`histchars`**

Geçmiş genişletme, hızlı değiştirme ve belirteç oluşturmayı kontrol eden en fazla üç karakter (bkz. [Geçmiş Etkileşimi](https://www.gnu.org/software/bash/manual/html_node/History-Interaction.html#History-Interaction) ). İlk karakter, *geçmiş yorumlama* karakteridir, yani normalde bir geçmiş yorumlamasının başlangıcını ifade eden karakterdir '!'. İkinci karakter, normalde bir satırdaki ilk karakter olarak görüldüğünde 'hızlı yer değiştirme' anlamına gelen karakterdir '^'. İsteğe bağlı üçüncü karakter, satırın geri kalanının bir kelimenin ilk karakteri olarak bulunduğunda bir yorum olduğunu belirten karakterdir, genellikle '#'. Geçmiş yorum karakteri, satırdaki kalan sözcükler için geçmiş değiştirmenin atlanmasına neden olur. Kabuk ayrıştırıcısının satırın geri kalanını yorum olarak değerlendirmesine neden olması gerekmez.

**`HISTCMD`**

Geçerli komutun geçmiş numarası veya geçmiş listesindeki dizin. Eğer `HISTCMD`ayarlanmazsa, bunun sonradan sıfırlanır bile, sahip olduğu özel nitelikleri kaybeder.

**`HISTCONTROL`**

Komutların geçmiş listesine nasıl kaydedildiğini kontrol eden iki nokta üst üste işaretiyle ayrılmış değerler listesi. Değerler listesi 'yok saymak', boşluk karakteriyle başlayan satırlar geçmiş listesine kaydedilmez. Bir değer 'görmezden gelinenler'önceki geçmiş girdisiyle eşleşen satırların kaydedilmemesine neden olur. Bir değer 'görmezden gelmek"kısaltmasıdır"yok saymak' ve 'görmezden gelinenler'. Bir değer 'Silinen'geçerli satırla eşleşen önceki tüm satırların, satır kaydedilmeden önce geçmiş listesinden kaldırılmasına neden olur. Yukarıdaki listede olmayan herhangi bir değer göz ardı edilir. Eğer `HISTCONTROL`kaldırılırsa ya da geçerli bir değer içermiyorsa, tüm hatlar değerine kabuk Geçmiş listesinde kayıtlı olan ayrıştırıcı, konuya göre okumak `HISTIGNORE`. Çok satırlı bir bileşik komutun ikinci ve sonraki satırları test edilmez ve değerine bakılmaksızın geçmişe eklenir `HISTCONTROL`.

**`HISTFILE`**

Komut geçmişinin kaydedildiği dosyanın adını tutar. Varsayılan değer kullanıcının ev dizini altındaki geçmiş dosyasına yani ***~/.bash_history*** konumuna işaret eder. Daha fazla detay için X.X.X.X bölümüne bakabilirsiniz.

**`HISTFILESIZE`**

Geçmiş dosyasında bulunan maksimum satır sayısı. Bu değişkene bir değer atandığında, geçmiş dosyası, gerekirse en eski girişler kaldırılarak bu sayıdan fazla satır içermeyecek şekilde kesilir. Geçmiş dosyası da bir kabuk çıktığında yazıldıktan sonra bu boyuta kesilir. Değer 0 ise, geçmiş dosyası sıfır boyutuna kesilir. Sayısal olmayan değerler ve sıfırdan küçük sayısal değerler, kesmeyi engeller. Kabuk, `HISTSIZE` herhangi bir başlangıç dosyasını okuduktan sonra varsayılan değeri olarak ayarlar .

**`HISTIGNORE`**

Geçmiş listesine hangi komut satırlarının kaydedilmesi gerektiğine karar vermek için kullanılan iki nokta üst üste işaretiyle ayrılmış bir kalıp listesi. Her desen, satırın başlangıcına tutturulur ve tüm satırla eşleşmelidir (örtük ''eklenir). Her desen, tarafından belirtilen kontroller `HISTCONTROL` uygulandıktan sonra çizgiye göre test edilir . Normal kabuk kalıbı eşleme karakterlerine ek olarak, '&'önceki geçmiş satırıyla eşleşir. '&'ters eğik çizgi kullanılarak önlenebilir; ters eğik çizgi, bir eşleşmeye teşebbüs etmeden önce kaldırılır. Çok satırlı bir bileşik komutun ikinci ve sonraki satırları test edilmez ve değerine bakılmaksızın geçmişe eklenir `HISTIGNORE`. Desen eşleştirme, `extglob`kabuk seçeneğinin ayarını onurlandırır .`HISTIGNORE`işlevini kapsar `HISTCONTROL`. Bir '&'ile aynıdır `ignoredups`ve' kalıbı '[] *'ile aynıdır `ignorespace`. Bu iki kalıbı birleştirmek, iki nokta üst üste ile ayırmak, işlevselliğini sağlar `ignoreboth`.

**`HISTSIZE`**

Geçmiş listesinde hatırlanması gereken maksimum komut sayısı. Değer 0 ise, komutlar geçmiş listesine kaydedilmez. Sıfırdan küçük sayısal değerler, her komutun geçmiş listesine kaydedilmesine neden olur (sınır yoktur). Kabuk, herhangi bir başlangıç dosyasını okuduktan sonra varsayılan değeri 500 olarak ayarlar.

**`HISTTIMEFORMAT`**

Bu değişken ayarlanmışsa ve boş değilse, değeri, yerleşik tarafından görüntülenen her geçmiş girdisiyle ilişkili zaman damgasını yazdırmak için *strftime* için bir biçim dizesi olarak kullanılır `history`. Bu değişken ayarlanırsa, zaman damgaları geçmiş dosyasına yazılır, böylece kabuk oturumlarında korunabilirler. Bu, zaman damgalarını diğer geçmiş satırlarından ayırmak için geçmiş yorum karakterini kullanır.

**`HOSTFILE`**

Aynı formatta bir dosyanın adını içerir / etc / hostsbu, kabuğun bir ana bilgisayar adını tamamlaması gerektiğinde okunmalıdır. Olası ana bilgisayar adı tamamlamalarının listesi, kabuk çalışırken değiştirilebilir; değer değiştirildikten sonra bir dahaki sefere ana bilgisayar adı tamamlanmaya çalışıldığında, Bash yeni dosyanın içeriğini mevcut listeye ekler. Eğer `HOSTFILE`kümesidir, ancak hiçbir değeri yoktur, ya da okunabilir dosya adı değil, Bash girişimleri okumak / etc / hostsolası ana bilgisayar adı tamamlamalarının listesini almak için. Ayarlanmadığında `HOSTFILE`, ana bilgisayar adı listesi temizlenir.

**`HOSTNAME`**

Mevcut konağın adı.

**`HOSTTYPE`**

Bash'in çalıştığı makineyi açıklayan bir dize.

**`IGNOREEOF`**

`EOF`Tek girdi olarak bir karakter alındığında kabuğun eylemini kontrol eder . Ayarlanırsa, değer `EOF`, kabuk çıkmadan önce bir giriş satırındaki ilk karakter olarak okunabilen ardışık karakterlerin sayısını gösterir . Değişken varsa ancak sayısal bir değeri yoksa veya değeri yoksa, varsayılan değer 10'dur. Değişken yoksa `EOF`, kabuğa girişin sonunu belirtir. Bu yalnızca etkileşimli mermiler için geçerlidir.

**`INPUTRC`**

Readline başlatma dosyasının adı, varsayılanı geçersiz kılar. ~ / .inputrc.

**`INSIDE_EMACS`**

Bash, kabuk başladığında ortamda bu değişkeni bulursa, kabuğun bir Emacs kabuk tamponunda çalıştığını varsayar ve değerine bağlı olarak satır düzenlemeyi devre dışı bırakabilir `TERM`.

**`LANG`**

İle başlayan bir değişkenle özel olarak seçilmemiş herhangi bir kategori için yerel kategoriyi belirlemek için kullanılır `LC_`.

**`LC_ALL`**

Bu değişken, bir yerel ayar kategorisini belirten değerini `LANG`ve diğer tüm değişkenleri geçersiz kılar `LC_`.

**`LC_COLLATE`**

Bu değişken, dosya adı genişletme sonuçlarını sıralarken kullanılan harmanlama sırasını belirler ve aralık ifadelerinin, eşdeğerlik sınıflarının ve sıralama dizilerinin dosya adı genişletme ve desen eşleştirme içindeki davranışını belirler (bkz. [Dosya Adı Genişletme](https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html#Filename-Expansion) ).

**`LC_CTYPE`**

Bu değişken, karakterlerin yorumlanmasını ve karakter sınıflarının dosya adı genişletme ve desen eşleştirme içindeki davranışını belirler (bkz. [Dosya Adı Genişletme](https://www.gnu.org/software/bash/manual/html_node/Filename-Expansion.html#Filename-Expansion) ).

**`LC_MESSAGES`**

Bu değişken, çift tırnaklı dizeleri çevirmek için kullanılan yerel ayarı belirler.$'( [Yerel Çeviriye](https://www.gnu.org/software/bash/manual/html_node/Locale-Translation.html#Locale-Translation) bakın ).

**`LC_NUMERIC`**

Bu değişken, sayı biçimlendirmesi için kullanılan yerel kategoriyi belirler.

**`LC_TIME`**

Bu değişken, veri ve zaman biçimlendirmesi için kullanılan yerel kategorisini belirler.

**`LINENO`**

Halihazırda çalıştırılan kod veya kabuk işlevindeki satır numarası.

**`LINES`**

`select`Komut tarafından, seçim listelerini yazdırmak için sütun uzunluğunu belirlemek için kullanılır. Otomatik olarak eğer set `checkwinsize`seçeneği etkinleştirildiğinde (bkz [shopt yerleşiği](https://www.gnu.org/software/bash/manual/html_node/The-Shopt-Builtin.html#The-Shopt-Builtin) ) veya alınmasından sonra interaktif bir kabukta `SIGWINCH`.

**`MACHTYPE`**

Bash'in üzerinde yürütüldüğü sistem türünü standart GNU *cpu-company-system* biçiminde tam olarak tanımlayan bir dize .

**`MAILCHECK`**

Kabuğun `MAILPATH`veya `MAIL`değişkenlerinde belirtilen dosyalardaki postaları ne sıklıkla (saniye cinsinden) kontrol etmesi gerektiği . Varsayılan 60 saniyedir. Postayı kontrol etme zamanı geldiğinde, kabuk bunu birincil istemi görüntülemeden önce yapar. Bu değişken ayarlanmamışsa veya sıfırdan büyük veya sıfıra eşit olmayan bir değere ayarlanmışsa, kabuk posta denetimini devre dışı bırakır.

**`MAPFILE`**

`mapfile`Değişken adı sağlanmadığında yerleşik tarafından okunan metni tutmak için oluşturulan bir dizi değişkeni .

**`OLDPWD`**

`cd`Yerleşik tarafından belirlenen önceki çalışma dizini .

**`OPTERR`**

1 değerine ayarlanırsa, Bash `getopts`yerleşik komut tarafından oluşturulan hata mesajlarını görüntüler .

**`OSTYPE`**

Bash'in çalıştığı işletim sistemini açıklayan bir dize.

**`PIPESTATUS`**

En son yürütülen ön plan ardışık düzenindeki işlemlerden çıkış durum değerlerinin bir listesini içeren bir dizi değişkeni ( [Diziler'e](https://www.gnu.org/software/bash/manual/html_node/Arrays.html#Arrays) bakın ) (yalnızca tek bir komut içerebilir).

**`POSIXLY_CORRECT`**

Bash başladığında bu değişken ortamdaysa, kabuk , başlangıç dosyalarını okumadan önce POSIX moduna (bkz. [Bash POSIX Modu](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html#Bash-POSIX-Mode) ) girer .-posixçağrı seçeneği sağlanmıştır. Kabuk çalışıyorken ayarlanırsa, Bash , komut gibi POSIX modunu etkinleştirir.`set -o posix`idam edildi. Kabuk POSIX moduna girdiğinde , önceden ayarlanmamışsa bu değişkeni ayarlar.

**`PPID`**

Kabuğun üst sürecinin süreç kimliği . Bu değişken salt okunurdur.

**`PROMPT_COMMAND`**

Ayarlanırsa, değer, her birincil istem ( `$PS1`) yazdırılmadan önce yürütülecek bir komut olarak yorumlanır .

**`PROMPT_DIRTRIM`**

Sıfırdan büyük bir sayıya ayarlanırsa, değer, `\w`ve bilgi `\W`istemi dizesi kaçışlarını genişletirken tutulması gereken sondaki dizin bileşenlerinin sayısı olarak kullanılır (bkz [. İstemi Denetleme](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html#Controlling-the-Prompt) ). Kaldırılan karakterler bir üç nokta ile değiştirilir.

**`PS0`**

Bu parametrenin değeri, *PS1* gibi genişletilir ve bir komut okuduktan sonra ve komut yürütülmeden önce etkileşimli kabuklar tarafından görüntülenir.

**`PS3`**

Bu değişkenin değeri `select`komut istemi olarak kullanılır . Bu değişken ayarlanmadıysa, `select`komut '#? '

**`PS4`**

Bu parametrenin değeri *PS1* gibi genişletilir ve genişletilmiş değer, komut satırı yankılanmadan önce yazdırılan istemdir.xseçeneği ayarlanmıştır (bkz [. Yerleşik Set](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html#The-Set-Builtin) ). Genişletilmiş değerin ilk karakteri, birden çok dolaylama düzeyini belirtmek için gerektiğinde birden çok kez yinelenir. Varsayılan '+ '.

**`PWD`**

`cd`Yerleşik tarafından belirlenen geçerli çalışma dizini .

**`RANDOM`**

Bu parametreye her başvurulduğunda, 0 ile 32767 arasında rastgele bir tamsayı oluşturulur. Bu değişkene bir değer atamak, rastgele sayı üretecini tohumlar.

**`READLINE_LINE`**

Readline satır arabelleğinin içeriği, 'bağlama -x( [Bash Builtins'e](https://www.gnu.org/software/bash/manual/html_node/Bash-Builtins.html#Bash-Builtins) bakın ).

**`READLINE_POINT`**

Ekleme noktasının Readline satır arabelleğindeki konumu, 'bağlama -x( [Bash Builtins'e](https://www.gnu.org/software/bash/manual/html_node/Bash-Builtins.html#Bash-Builtins) bakın ).

**`REPLY`**

`read`Yerleşik için varsayılan değişken .

**`SECONDS`**

Bu değişken, kabuk başlatıldığından beri geçen saniye sayısına kadar genişler. Bu değişkene atama, sayımı atanan değere sıfırlar ve genişletilmiş değer, atanan değer artı atamadan bu yana geçen saniye sayısı olur.

**`SHELL`**

Kabuğun tam yol adı bu ortam değişkeninde tutulur. Kabuk başladığında ayarlanmazsa, Bash ona geçerli kullanıcının oturum açma kabuğunun tam yol adını atar.

**`SHELLOPTS`**

Etkinleştirilmiş kabuk seçeneklerinin iki nokta üst üste ile ayrılmış listesi. Listedeki her kelime geçerli bir argümandır.Ö`set`yerleşik komuta seçenek (bkz [. Yerleşik Set](https://www.gnu.org/software/bash/manual/html_node/The-Set-Builtin.html#The-Set-Builtin) ). Görünen seçenekler `SHELLOPTS`, "açık' tarafından 'set -o'. Bash başladığında bu değişken ortamdaysa, listedeki her kabuk seçeneği herhangi bir başlangıç dosyası okunmadan önce etkinleştirilecektir. Bu değişken salt okunurdur.

**`SHLVL`**

Her yeni Bash örneği başlatıldığında bir artar. Bu, Bash mermilerinizin ne kadar derinlemesine yuvalanmış olduğunun bir sayısı olarak tasarlanmıştır.

**`TIMEFORMAT`**

Bu parametrenin değeri, önceden `time` ayrılmış sözcüğün ön ekine sahip boru hatları için zamanlama bilgilerinin nasıl görüntülenmesi gerektiğini belirten bir biçim dizisi olarak kullanılır . '%'karakteri, bir zaman değerine veya diğer bilgilere genişletilen bir kaçış dizisi sunar. Kaçış dizileri ve anlamları aşağıdaki gibidir; kaşlı ayraçlar, isteğe bağlı bölümleri belirtir.**`%%`**Gerçek bir '%'.**`%[*p*][l]R`**Saniye cinsinden geçen süre.**`%[*p*][l]U`**Kullanıcı modunda harcanan CPU saniye sayısı.**`%[*p*][l]S`**Sistem modunda harcanan CPU saniye sayısı.**`%P`**(% U +% S) /% R olarak hesaplanan CPU yüzdesi.İsteğe bağlı *p* , kesinliği, ondalık noktadan sonraki kesirli basamakların sayısını belirten bir basamaktır. 0 değeri, ondalık basamağın veya kesirin çıkılmasına neden olmaz. Ondalık noktadan sonra en fazla üç basamak belirtilebilir; *p'nin* 3'ten büyük değerleri 3'e değiştirilir. *p* belirtilmezse, 3 değeri kullanılır.İsteğe bağlı `l`, *MM* m *SS* biçiminde dakikalar dahil daha uzun bir biçim belirtir . *FF* s. *P'nin* değeri , kesrin dahil edilip edilmeyeceğini belirler.Bu değişken ayarlanmazsa, Bash değere sahipmiş gibi davranır`$'\nreal\t%3lR\nuser\t%3lU\nsys\t%3lS'`Değer boş ise, zamanlama bilgisi görüntülenmez. Biçim dizesi görüntülendiğinde sondaki satırsonu eklenir.

**`TMOUT`**

Sıfırdan büyük bir değere ayarlanırsa `TMOUT`, `read`yerleşik için varsayılan zaman aşımı olarak kabul edilir (bkz. [Bash Yerleşikleri](https://www.gnu.org/software/bash/manual/html_node/Bash-Builtins.html#Bash-Builtins) ). `select`Komutu (bkz [Şartlı Constructs](https://www.gnu.org/software/bash/manual/html_node/Conditional-Constructs.html#Conditional-Constructs) giriş sonra gelmesi değilse sonlanır) `TMOUT`giriş terminal geliyor zaman saniye.Etkileşimli bir kabukta, değer, birincil komut istemi verildikten sonra bir girdi satırı için beklenecek saniye sayısı olarak yorumlanır. Bash, tam bir girdi satırı gelmezse, bu saniye kadar bekledikten sonra sona erer.

**`TMPDIR`**

Ayarlanırsa, Bash değerini, Bash'in kabuğun kullanımı için geçici dosyalar oluşturduğu bir dizinin adı olarak kullanır.

**`UID`**

Mevcut kullanıcının sayısal gerçek kullanıcı kimliği. Bu değişken salt okunurdur.