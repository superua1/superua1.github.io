# Kullanıcının girebileceği maksimum sayıdaki karakter.

Seçenek: September 1, 2020 7:19 AM