# Girilen karaktere göre veri girişini durdurmayı sağlar.

Seçenek: December 1, 2020