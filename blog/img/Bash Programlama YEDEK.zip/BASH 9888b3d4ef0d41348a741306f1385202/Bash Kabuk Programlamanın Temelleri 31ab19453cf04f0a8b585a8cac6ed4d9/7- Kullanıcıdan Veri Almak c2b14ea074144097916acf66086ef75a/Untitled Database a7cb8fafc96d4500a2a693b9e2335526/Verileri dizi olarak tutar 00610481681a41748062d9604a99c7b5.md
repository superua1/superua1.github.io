# Verileri dizi olarak tutar.

Seçenek: September 1, 2020 9:00 AM