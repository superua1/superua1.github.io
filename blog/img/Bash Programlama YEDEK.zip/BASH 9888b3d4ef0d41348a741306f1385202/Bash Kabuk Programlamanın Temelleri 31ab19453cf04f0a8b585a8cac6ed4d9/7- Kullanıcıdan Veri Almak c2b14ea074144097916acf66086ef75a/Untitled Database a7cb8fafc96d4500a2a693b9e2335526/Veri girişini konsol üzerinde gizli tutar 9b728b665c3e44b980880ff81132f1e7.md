# Veri girişini konsol üzerinde gizli tutar.

Seçenek: September 6, 2020