# Veri girişi için zaman sınırı koyar.

Seçenek: September 1, 2020