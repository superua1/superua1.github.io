# Konsola çıktı basılmasını sağlar.

Seçenek: September 1, 2020 6:00 PM