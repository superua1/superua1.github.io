# Kabuk Yapılandırma Dosyaları

[https://alisezisli.com.tr/shell-script-4-bashin-yapilandirma-dosyalari/](https://alisezisli.com.tr/shell-script-4-bashin-yapilandirma-dosyalari/)