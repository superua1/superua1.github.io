# Çatallama (Fork)

Bir işletim sisteminde çatal, mevcut çalışan bir işlemden yeni bir işlem oluşturmak için bir Unix veya Linux sistem çağrısıdır. Yeni süreç, çağıran üst sürecin alt sürecidir.