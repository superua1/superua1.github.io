# Bash Kabuk Programlamanın Temelleri

![Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kitap_Kapak_1.png](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kitap_Kapak_1.png)

Süper Kitap: [https://learning.oreilly.com/library/view/learning-the-bash/0596009658/apc.html](https://learning.oreilly.com/library/view/learning-the-bash/0596009658/apc.html)

Bash referans kaynağı olarak gözden geçir;[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[0 Önsöz](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/0%20O%CC%88nso%CC%88z%200229398903144a3986240ee2cba3a024.md)

[1. Girizgah: Kabuğu Tanımak](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/1%20Girizgah%20Kabug%CC%86u%20Tan%C4%B1mak%20a893d8e876ac4063b8d830b27fbb0cbd.md)

[2- Gerekli Çalışma Ortamının Kurulması](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/2-%20Gerekli%20C%CC%A7al%C4%B1s%CC%A7ma%20Ortam%C4%B1n%C4%B1n%20Kurulmas%C4%B1%200a72d8af865347288c39cfcd641212e9.md)

[3- Başlarken](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/3-%20Bas%CC%A7larken%203db0c3cc8851441e8c1dfd3bec480789.md)

[13- İşlem(Process) Yönetimi](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%2050d6c969520743e9bcb4fec0478534c3.md)

[Kabuk Komutları](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kabuk%20Komutlar%C4%B1%20299bbdde710245e984a12538dcfd07db.md)

[10. Shell Sentaks](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/10%20Shell%20Sentaks%209ffe44381fdb4723bf4febb3177864ff.md)

[Copy of 10. Shell Sentaks](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Copy%20of%2010%20Shell%20Sentaks%2026ab9af97fc94018bf7cd51ea258d288.md)

[3- Değişkenler](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/3-%20Deg%CC%86is%CC%A7kenler%20e624b5d8ce8a4041b008cd5abbcd418a.md)

[4- Argümanlar](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/4-%20Argu%CC%88manlar%20845339dae7e240a1b207414b4b61267f.md)

[5- Düzenleme Üzerine](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/5-%20Du%CC%88zenleme%20U%CC%88zerine%20b285472fb8034406883d91c2e23c1dc7.md)

[6- Aritmetik İşlemler](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/6-%20Aritmetik%20I%CC%87s%CC%A7lemler%20822ebfca85994de2b2d52802cf3c6143.md)

[Copy of 13- İşlem(Process) Yönetimi](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Copy%20of%2013-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%20372faa9aced8468fbc117be31c86dacf.md)

[15- Yönlendirmeler](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8.md)

[14- Sinyaller](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/14-%20Sinyaller%204a1da2fec9c24c61a2a4d70d3285375b.md)

[Bash Kabuk Ortamı](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Kabuk%20Ortam%C4%B1%204329cc610fd44423bef924c5d92c433b.md)

[7- Kullanıcıdan Veri Almak](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/7-%20Kullan%C4%B1c%C4%B1dan%20Veri%20Almak%20c2b14ea074144097916acf66086ef75a.md)

[8- Metin İşleme ve Genişletme](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/8-%20Metin%20I%CC%87s%CC%A7leme%20ve%20Genis%CC%A7letme%20a70b1e1863a74b12bd53758ce982edb5.md)

[9 Alıntı Mekanizmaları](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/9%20Al%C4%B1nt%C4%B1%20Mekanizmalar%C4%B1%20886cc571fb9a45e38dd69ac594085a87.md)

[9- Sed](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/9-%20Sed%20bcf6c7da24aa4d1ea7502f848aa57fbb.md)

[10- Awk](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/10-%20Awk%20a516f21e3ca64ed5adf565abee782f93.md)

[Döngüler](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Do%CC%88ngu%CC%88ler%203516fb11408f47e69c71c0f663dd223c.md)

[Fonksiyonlar](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Fonksiyonlar%201a440441ec514d349a45d2cf287e044f.md)

[Otomatik Tamamlama](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Otomatik%20Tamamlama%20353a85a9f7854f07b82fcd6bd002f4e4.md)

[SON- Eğitim Bitti Ya Sonra ?](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/SON-%20Eg%CC%86itim%20Bitti%20Ya%20Sonra%20a57c032dfb484ccebabd8565b8167cb1.md)

[Optimizasyon](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Optimizasyon%203b52bd6dee6d4e1ea56b47d40eaa24c5.md)

[Bash Yerleşik Komutlarının Açıklaması](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20bf06b9bae3744736984c5f2df24ba81f.md)

[Bash Shell Kullanım Örnekleri](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Shell%20Kullan%C4%B1m%20O%CC%88rnekleri%20e4dd265ea9ae41f6ad9456db9da7a973.md)

[BASH Güzel Kaynak](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/BASH%20Gu%CC%88zel%20Kaynak%20b32d4ec10a164a7383568788b7f0e66f.md)

[Ekstra Sözlük](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Ekstra%20So%CC%88zlu%CC%88k%2019da18b09f454abf8ee9a79dcce15ef3.md)

[Basit Kabuk Özellikleri | GNU.ORG](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%206e3aba91b45b4101ab5697ae8f0cf9bc.md)

[KAPAK TASARIMI](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/KAPAK%20TASARIMI%20e0bc7c3309bc4039aae3ee76fd922fcc.md)

[Kabuk Yapılandırma Dosyaları](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kabuk%20Yap%C4%B1land%C4%B1rma%20Dosyalar%C4%B1%2075120558fd6b42d39be305c23b3885d5.md)

[Karikatür Önerileri](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Karikatu%CC%88r%20O%CC%88nerileri%202d4019f789384fd0b206ca42ea64f8e3.md)

[Kabuk Hakkında Daha Fazla Detay](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%20865f83987c834b26af31e9c4d29ed9cc.md)

[Kaynakça ve Kullanılan Araçlar](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kaynakc%CC%A7a%20ve%20Kullan%C4%B1lan%20Arac%CC%A7lar%204d3b951543dd46e98bbb13b7cf1fea4e.md)

[İçindekiler | Fihrist](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/I%CC%87c%CC%A7indekiler%20Fihrist%20e6c4037b566e491fbc1d9fbd0d4f51cb.md)

[Eski Yedek](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Eski%20Yedek%20119bd1a156654caa87e5f076b2b8da9d.md)

[Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%207d527e469ebc482d8f499ca76e6b6ade.md)

[Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%201b7d797d68ee46649a27aff127f3cee1.md)

[Bash Kabuğunu Çağırmak](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%207b834252e6df4ce0b5d2576102322d95.md)

[PRATİKLER VE GERÇEK HAYAT ÖRNEKLERİ](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/PRATI%CC%87KLER%20VE%20GERC%CC%A7EK%20HAYAT%20O%CC%88RNEKLERI%CC%87%20d0494e638e1841d7aca89e48b889afbb.md)