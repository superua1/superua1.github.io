# Bash Scripting Dersleri | Ölümlüler için Bash Programlama ?

KİTAP TASARIMLARI İÇİN MİDJOURNEY KULLANABİLİRSİN.

TELİF HAKKINDA UYGUN:[https://medium.com/mlearning-ai/can-you-sell-ai-generated-images-e86117e2890f](https://medium.com/mlearning-ai/can-you-sell-ai-generated-images-e86117e2890f)

Bash referans kaynağı olarak gözden geçir;[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[Önsöz](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/O%CC%88nso%CC%88z%2083efe5d6f999466f9367f292e40b1a59.md)

[Giriş](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Giris%CC%A7%2002bcdcd87b97424fb78fe82d5ac59f36.md)

[1.⚠️ Giriş](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/1%20%E2%9A%A0%EF%B8%8F%20Giris%CC%A7%200253cdea4a1b413890640c2439a00917.md)

[Shell Sentaks](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Shell%20Sentaks%2012387cf55e384a37ac2a68a5e0fc2a7b.md)

[1- Gerekli Çalışma Ortamının Kurulması](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/1-%20Gerekli%20C%CC%A7al%C4%B1s%CC%A7ma%20Ortam%C4%B1n%C4%B1n%20Kurulmas%C4%B1%20721f3d83b6a94e5b8eb36f5cb7f27151.md)

[2- Başlarken](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/2-%20Bas%CC%A7larken%20847d1e878ba94551b2b30105cd4fe8e3.md)

[3- Değişkenler](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/3-%20Deg%CC%86is%CC%A7kenler%20166f5080ac4f460db4f856c87dfbd2ba.md)

[4- Argümanlar](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/4-%20Argu%CC%88manlar%20129afa8835f447e6b9d92f89db0a3800.md)

[5- Düzenleme Üzerine](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/5-%20Du%CC%88zenleme%20U%CC%88zerine%20f6e110b999624e609dc0eaf0d3782b69.md)

[6- Aritmetik İşlemler](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/6-%20Aritmetik%20I%CC%87s%CC%A7lemler%20afa82698ebdf43928c0f412ba99d6abc.md)

[13- Süreç-İşlem(Process) Yönetimi](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/13-%20Su%CC%88rec%CC%A7-I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%20b99b5e20c94243e2b46e6b5ae48bae6d.md)

[15- Yönlendirmeler](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/15-%20Yo%CC%88nlendirmeler%202b2332fe42d74b34840eea7ef3359c5c.md)

[14- Sinyaller](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/14-%20Sinyaller%20ca235f6bd67c417891713c21eb16a5af.md)

[7- Kullanıcıdan Veri Almak](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/7-%20Kullan%C4%B1c%C4%B1dan%20Veri%20Almak%2017b1f69ecadc40ccba79662cf827c784.md)

[8- Metin İşleme ve Genişletme](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/8-%20Metin%20I%CC%87s%CC%A7leme%20ve%20Genis%CC%A7letme%20ffe125fd56b8465cb58ac7e13b0013b9.md)

[Alıntılamak](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Al%C4%B1nt%C4%B1lamak%2022ed39459caa4d8ea0bff980be9c0691.md)

[9- Sed](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/9-%20Sed%20dd4f0976ca824dbaa18a40f284a5fa80.md)

[10- Awk](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/10-%20Awk%202e59789852c7444498bcff5a6332f957.md)

[Koşul İfadeleri](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Kos%CC%A7ul%20I%CC%87fadeleri%20409d1629f8c04c1592a93327b69af936.md)

[Döngüler](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Do%CC%88ngu%CC%88ler%2019d231bf30494273a41883946e929787.md)

[Fonksiyonlar](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Fonksiyonlar%201955076be8394270a8128dea64377a0a.md)

[Otomatik Tamamlama](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Otomatik%20Tamamlama%200f6dbcda1ef64fed95b32d513539c022.md)

[SON- Eğitim Bitti Ya Sonra ?](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/SON-%20Eg%CC%86itim%20Bitti%20Ya%20Sonra%20ff126f7e664b4eacb1df3d733abd55fb.md)

[Optimizasyon](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Optimizasyon%20848b821021d24af59685f6ea5bc9d7ca.md)

[Bash Yerleşik Komutlarının Açıklaması](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%2051d26197f64b48e7be3968eed419aa40.md)

[.bashrc gibi dosyaları tek tek açıkla](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/bashrc%20gibi%20dosyalar%C4%B1%20tek%20tek%20ac%CC%A7%C4%B1kla%20cd5e4cfc6056439880aa0cc04d3b754f.md)

[Bash Shell Kullanım Örnekleri](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Bash%20Shell%20Kullan%C4%B1m%20O%CC%88rnekleri%20e1d9c562de7249d2b06957ca73c6a14c.md)

[BASH Güzel Kaynak](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/BASH%20Gu%CC%88zel%20Kaynak%2087d921650f6a448688a496f0f7b2f953.md)

[Ekstra Sözlük](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Ekstra%20So%CC%88zlu%CC%88k%202808da0b171646bfb9b6d6f7e73b2c8a.md)

[Copy of Süreç-İşlem(Proccess) Yönetimi](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Copy%20of%20Su%CC%88rec%CC%A7-I%CC%87s%CC%A7lem(Proccess)%20Yo%CC%88netimi%202c58ab84264d472ba70d56fb556b78a9.md)

[Süreçler !](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Su%CC%88rec%CC%A7ler%20!%204f3bf816212c4bb6a8f5a039948a0e51.md)

[Ölümlüler için Bash Programlama](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Programlama%2049231e7d8bc7431c94c740a50f803c8d.md)

[Tanımlar](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Tan%C4%B1mlar%20197d739e2ec549369be359b5340e8e59.md)

[Basit Kabuk Özellikleri | GNU.ORG](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20ff17c999e406480bb8dd48cde60e4347.md)

[KAPAK TASARIMI](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/KAPAK%20TASARIMI%200f4ca152cb8f4df8a877be018418e175.md)

[Kabuk Yapılandırma Dosyaları](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/Kabuk%20Yap%C4%B1land%C4%B1rma%20Dosyalar%C4%B1%2040d445fc3f7044dcb3cbb7de7ac5471c.md)

[BASH Çalışma Yapısı](Bash%20Scripting%20Dersleri%20O%CC%88lu%CC%88mlu%CC%88ler%20ic%CC%A7in%20Bash%20Pr%204cc27d2d422a4d2d8677acdbd6628a55/BASH%20C%CC%A7al%C4%B1s%CC%A7ma%20Yap%C4%B1s%C4%B1%208830ce056339469fa64f0732be156111.md)