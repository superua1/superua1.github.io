# Copy of Bash Kabuk Programlamanın Temelleri

![Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kitap_Kapak_1.png](Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kitap_Kapak_1.png)

Süper Kitap: [https://learning.oreilly.com/library/view/learning-the-bash/0596009658/apc.html](https://learning.oreilly.com/library/view/learning-the-bash/0596009658/apc.html)

Bash referans kaynağı olarak gözden geçir;[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[0 Önsöz](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/0%20O%CC%88nso%CC%88z%20aadef76d37bf4a8ea8997f695c4bf952.md)

[1. Girizgah: Kabuğu Tanımak](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/1%20Girizgah%20Kabug%CC%86u%20Tan%C4%B1mak%20dac235f9053f45a79a401c55965b6da0.md)

[2- Gerekli Çalışma Ortamının Kurulması](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/2-%20Gerekli%20C%CC%A7al%C4%B1s%CC%A7ma%20Ortam%C4%B1n%C4%B1n%20Kurulmas%C4%B1%204f916639c3114701b7f87471bee7b420.md)

[3- Başlarken](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/3-%20Bas%CC%A7larken%202239d60f4db24c2b83bde9ea471926c1.md)

[Kabuk Komutları](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Kabuk%20Komutlar%C4%B1%20dd258eba87c44faa8c2453256968b2f1.md)

[10. Shell Sentaks](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/10%20Shell%20Sentaks%20c10ee4560a604ead844e499e1a37252f.md)

[Copy of 10. Shell Sentaks](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Copy%20of%2010%20Shell%20Sentaks%2001e6912ca69149619332b465265b622a.md)

[3- Değişkenler](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/3-%20Deg%CC%86is%CC%A7kenler%2054179082299542b2a8ce69af2b5ce32f.md)

[4- Argümanlar](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/4-%20Argu%CC%88manlar%20b5579e98a2e340f890ea1f74aab74e80.md)

[5- Düzenleme Üzerine](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3.md)

[6- Aritmetik İşlemler](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/6-%20Aritmetik%20I%CC%87s%CC%A7lemler%2010899d1bf4d24781a2ea723127656b98.md)

[13- İşlem(Process) Yönetimi](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/13-%20I%CC%87s%CC%A7lem(Process)%20Yo%CC%88netimi%204a56a068ffd3468898583e39fbb532c3.md)

[15- Yönlendirmeler](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/15-%20Yo%CC%88nlendirmeler%200e92d785d384481dad32fcd77a02ebf2.md)

[14- Sinyaller](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/14-%20Sinyaller%20f81db5fd12134a29a1537c526e69a847.md)

[7- Kullanıcıdan Veri Almak](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/7-%20Kullan%C4%B1c%C4%B1dan%20Veri%20Almak%2026c57905704641988c452d2df68fdde8.md)

[8- Metin İşleme ve Genişletme](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/8-%20Metin%20I%CC%87s%CC%A7leme%20ve%20Genis%CC%A7letme%2061f15a5e3b8b4b8da14db7a06cea6115.md)

[9 Alıntı Mekanizmaları](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/9%20Al%C4%B1nt%C4%B1%20Mekanizmalar%C4%B1%2059f0d0a6ade74e08a10dfb4f0185d471.md)

[9- Sed](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/9-%20Sed%209cd7533f39d24d1fb8a95f312694c691.md)

[10- Awk](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/10-%20Awk%20159596d0dbd34f1389f97fcc23cf73a6.md)

[Döngüler](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Do%CC%88ngu%CC%88ler%206835f71c3575489f8a2f84f3b936953e.md)

[Fonksiyonlar](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Fonksiyonlar%2069ca2f3753934415becaaf457a2a9c28.md)

[Otomatik Tamamlama](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Otomatik%20Tamamlama%20617b8e338b3743f1b51606c835154c9b.md)

[SON- Eğitim Bitti Ya Sonra ?](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/SON-%20Eg%CC%86itim%20Bitti%20Ya%20Sonra%20c9143c21bf6f470f8761d21a8f8f60fd.md)

[Optimizasyon](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Optimizasyon%204fa08668ec7a41c690a59b1957b854f8.md)

[Bash Yerleşik Komutlarının Açıklaması](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa.md)

[Bash Shell Kullanım Örnekleri](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Bash%20Shell%20Kullan%C4%B1m%20O%CC%88rnekleri%2022d0b38177634cb98707a583b838729d.md)

[BASH Güzel Kaynak](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/BASH%20Gu%CC%88zel%20Kaynak%20d2fe7edc8b1c43298b9a2a8e96be7b5b.md)

[Ekstra Sözlük](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Ekstra%20So%CC%88zlu%CC%88k%20c6248636d4b84c5a8e477e4c5bbff1ac.md)

[Basit Kabuk Özellikleri | GNU.ORG](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20baf1e99870dd4a09bce3562c3b9d8eab.md)

[KAPAK TASARIMI](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/KAPAK%20TASARIMI%2075e9c5e1fdb247b2aeab9f997e914988.md)

[Kabuk Yapılandırma Dosyaları](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Kabuk%20Yap%C4%B1land%C4%B1rma%20Dosyalar%C4%B1%20a50a93d069914b2e985a2befce18b71e.md)

[Karikatür Önerileri](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Karikatu%CC%88r%20O%CC%88nerileri%204886e172e2f945318fc9b5ed95a527ba.md)

[Kabuk Hakkında Daha Fazla Detay](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%208129f46b6e2c4327947b1d0ec827003e.md)

[Kaynakça ve Kullanılan Araçlar](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Kaynakc%CC%A7a%20ve%20Kullan%C4%B1lan%20Arac%CC%A7lar%20d0262a7ae8c646ed9276c3701fd5edbb.md)

[İçindekiler | Fihrist](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/I%CC%87c%CC%A7indekiler%20Fihrist%202552d55eebae47d4a04935d5197bf4e4.md)

[Eski Yedek](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Eski%20Yedek%203931ae213000402f94973624e31a5ae1.md)

[Bash Kabuk Ortamı](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Bash%20Kabuk%20Ortam%C4%B1%207030069a8fb24678813eb9f6d4cacfdc.md)

[Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%2046787be067214200818919b9991d05b9.md)

[Copy of Kabuk Modları Ve Okunan Başlangıç Dosyaları](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Copy%20of%20Kabuk%20Modlar%C4%B1%20Ve%20Okunan%20Bas%CC%A7lang%C4%B1c%CC%A7%20Dosyal%20481a3c1980ac459cb77f8ed293862b69.md)

[Bash Kabuğunu Çağırmak](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%2098d89518a9fb411da2a552f91a38562e.md)

[PRATİKLER VE GERÇEK HAYAT ÖRNEKLERİ](Copy%20of%20Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2021b6e61f045b4e598147e2e7174dd16e/PRATI%CC%87KLER%20VE%20GERC%CC%A7EK%20HAYAT%20O%CC%88RNEKLERI%CC%87%20f1580cc332f74250a0f69967029eed7f.md)