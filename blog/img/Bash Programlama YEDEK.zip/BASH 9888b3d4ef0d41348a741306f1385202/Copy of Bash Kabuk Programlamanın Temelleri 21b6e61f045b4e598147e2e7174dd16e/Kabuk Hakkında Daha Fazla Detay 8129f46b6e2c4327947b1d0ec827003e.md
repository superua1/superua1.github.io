# Kabuk Hakkında Daha Fazla Detay

Kabuğun competetive olması ne demek : [https://unix.stackexchange.com/questions/145522/what-does-it-mean-to-be-sh-compatible?noredirect=1&lq=1](https://unix.stackexchange.com/questions/145522/what-does-it-mean-to-be-sh-compatible?noredirect=1&lq=1)

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%20865f83987c834b26af31e9c4d29ed9cc/Untitled.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Kabuk%20Hakk%C4%B1nda%20Daha%20Fazla%20Detay%20865f83987c834b26af31e9c4d29ed9cc/Untitled.png)