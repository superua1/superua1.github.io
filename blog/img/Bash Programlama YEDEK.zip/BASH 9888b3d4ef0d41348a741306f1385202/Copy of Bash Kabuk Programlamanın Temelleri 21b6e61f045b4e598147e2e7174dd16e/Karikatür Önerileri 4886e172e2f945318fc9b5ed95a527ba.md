# Karikatür Önerileri

Bash kabuğunun geçmişten beri varsayılan olarak kullanılmasının nedeni geçmişe yönelik uyumluluktur. Mevcut betiklerin geçerliliğini korumak için yeni bir kabuğa geçilmez. Bu durumu:"aman ali rıza bey tadımız kaçmasın" şeklinde karikatürüze edebilirisin. Ali rıza tekerlekli sandalyede bash programalama yapıyordur. Anladın işte..

Kabuğun teyit edilmesi aşamasında bu karikatür kullanılabilir. Sen bash kabuğunu savundun. SAVUNMADIM! Savundun savunmadım çıkar göster.