# 0 Önsöz

BASH KABUĞUNUN DOĞUŞU VE TARİHÇESİ HAKKINDA BİLGİ SUNMAK İYİ OLABİLİR; [https://barisozdicle.medium.com/unixin-tarihi-boyunca-varolan-kabukların-çeşitlerini-ve-zaman-içerisinde-geçirdiği-b083be1f9e9c](https://barisozdicle.medium.com/unixin-tarihi-boyunca-varolan-kabuklar%C4%B1n-%C3%A7e%C5%9Fitlerini-ve-zaman-i%C3%A7erisinde-ge%C3%A7irdi%C4%9Fi-b083be1f9e9c)

Bu eğitimdeki amacımız bash kabuğunun sahip olduğu temel özellikleri kavrayabilmektir. Bu sayede bash kabuğunu çok daha etkili kullanma ve hakkında çok daha fazla bilgiyi edinebilme kabiliyetini kazanmamızın önü açılacaktır. Eğitim içerisinde pek çok farklı konu başlığı ve bölümlendirme bulunsa da aslında pek çok konu birbiri ile yakından ilişkilidir. Bu sebeple eğitimin bazı bölümlerinde geçmişte bahsedilen kavramlara atıfta bulunabilir ya da aynı konuyu, yeni konuyla birlikte tekrar ele alabiliriz. Bu gibi durumlara eğitimin düştüğü tekrarlardan ziyade, öğrenilen bilgilerin sentezlenmesi olarak bakmak çok daha doğru bir yaklaşım olacaktır.  Ayrıca burada ele alınan tüm konuları hatırlamanızın beklenmediğini, genellikle ihtiyaç duydukça açıp tekrar tekrar bakabileceğiniz bir kaynak olarak görmeniz gerektiğini de belirtmek isterim. Zaten sık ihtiyaç duyduğunuz kavramlar hatırınızda kalacağı gibi, eğitime baştan sonra göz atan kişiler gerektiğinde ihtiyaç duyduğu bilginin eğitimde olup olmadığı kolayca anımsayacaktır.

Sizlerden tek ricam tüm eğitimi sabırla ve uygulama yaparak sıralı şekilde takip etmenizdir. Ayrıca benim örnek olarak sunduğum uygulamalar dışında da mutlaka harici olarak kendiniz de çeşitli alıştırmalar yapmalısınız. Zira her konu için çoklu örnekler vermemiz konuyu gereksiz uzatacağı için bu eğitimde yalnızca konuyu kavramanıza yetecek örnekler yer almaktadır. Daha fazlası sizlerin gayretine bağlıdır.

Eğitime başlamak için daha önceden GNU/Linux sistemlerini profesyonel olarak kullanmış olmanız şart olmamakla birlikte, temel seviye Linux deneyimine sahip kişilerin eğitimi daha rahat takip edebileceği de bir gerçektir. Zorunluluk olmasa da önceki kitabım "GNU/Linux Sistem Yönetiminin Temelleri" gibi temel Linux bilgisi edinebileceğiniz herhangi bir kaynağı okumuş olmanız bu eğitimden alacağınız verimi de oldukça arttıracaktır. Eğitimin geneli bash kabuğunun temelde nasıl çalıştığını anlamayı gaye ediniyor. Ancak yine de üzerinde çalıştığımız ortamı ne kadar iyi tanırsak, potansiyel olarak yazabileceğimiz programların verimliliği de doğru orantılı artacaktır.

Buradaki tüm anlatımlar bash kabuğunun 5.0.18(1) versiyonu üzerinden ele alınmıştır. Sizlerin bu eğitimi takip ettiğiniz kabuk sürümü daha yeni ya da eski bir sürüm olabilir. Eğer öyleyse yalnızca kullandığınız sürümün geçmiş veya gelecek sürümler arasındaki farklarını sürüm notlarına bakarak öğrenmeniz yeterlidir. Zaten pek çok bilgi uzun süredir değişmediği ve değişmesi de öngörülmediği için sürümler arası ufak tefek farklar dışında programlama bakımından sorun yaşamazsınız.

Baştan belirtelim konuları kısa kesmeden, **gerekeni gerektiği kadar** açıklayarak ilerliyor olacağız. 

## 0.1 Neden Basılı Kitap ?

Aslına bakarsanız hızla değişen bilişim dünyasında basılı yani değişmez yazılı kaynak fikri çok da makul bir yaklaşım değildir. Yine de fiziksel olarak kitapları okumanın insan üzerindeki etkisine ek olarak bu kitabın bash programının temellerine değinme gayesinde olduğunuz bilmenizi isterim. Bash oldukça uzun süredir(yaklaşık 31 yıldır) kullanımda olan ve değişiklikleri kolay takip edilebilir yaygın bir kabuk dilidir. Eğer temelde nasıl çalıştığını kavrarsak, sahip olduğu yeniliklere adapte olmamız da oldukça kolaylaşır. Bu kitap da bash kabuğunun temellerini neden sonuç ilişkisi içinde ele alarak sizlere başlangıç noktası olmak amacındadır. 

## 0.2 Bu Kitap Kimler İçin ?

Öncelikli olarak hiç bilmeyen kişiler olmak üzere, halihazırda bash kabuğunu aktif kullanmakta olan kişilerin de bu kitapta bulabilecekleri yeni ya da tekrara değer bilgiler olabilir. Özellikle başlangıç seviyesindekiler için, kullanmakta oldukları mevcut işlevlerin temelinde ne olduğunu ve hatta belki de nasıl farklı yolla yapılabileceğini keşfetmeleri mümkündür. Kısacası Bash kabuğunun yaygın kullanım alanlarından herhangi biri ile keşimi bulunan herkes için derli toplu Türkçe kaynak olduğunu söyleyebiliriz.  

## 0.3 **Bu Kitap Nasıl Okunmalı ?**

Gerekli temel bilgi zeminini oluşturmak, herhangi bir teknik konuyu ele almak için kaçınılmaz bir zorluktur. Herhangi bir yapı bütünün nasıl çalıştığını açıklarken işler *gerçekten* karmaşıklaşabilir. Çok fazla ayrıntı okuyucuyu boğar ve önemli olan yani sık kullanılacak bilgileri kavramayı zorlaştırır. (insan beyni aynı anda pek çok yeni kavramı işleyemez) Aksi olarak çok az ayrıntı yer alması da, okuyucunun mevcut yapı bütününü tam kavrayamamasına ve sonraki anlatımlar için hazırlıksız kalmasına neden olabilir. 

Çoğu bölümü ilk önce en önemli malzemeyi ele almak için tasarladım: ilerlemek için ihtiyaç duyacağınız temel bilgiler. Odaklanmayı sürdürmek için bazı yerlerde işleri basitleştirdim. Bölümler ilerledikçe, özellikle son birkaç bölümde çok daha fazla ayrıntı göreceksiniz. Bu parçaları hemen bilmeniz gerekiyor mu? Çoğu durumda, sık sık belirttiğim gibi hayır. Henüz yeni öğrendiğiniz şeylerle ilgili birçok ekstra ayrıntıyla karşılaştığınızda gözleriniz kaymaya başlarsa, bir sonraki bölüme atlamaktan çekinmeyin veya sadece ara verin. Neticede bilgilerin hepsi, hala orada sizi bekliyor olacak.

## 0.4 Kitabın Formatı | İşleniş Biçimi

Kitap içerisindeki konular birbiri ile bağlantılı olacak şekilde sıralı olarak düzenlenmiştir. Kimi konular içerisinde ileride ele alacağımız bazı konulara atıfta bulunuyor ve kısaca açıklıyor olacağız. Ayrıca bir konu içerisinde birbirinden farklı pek çok kavramın ve komutun açıklanması gerektiğinde öncelikle gerekli olan temel bilgilerin verilmesi amaçlanmıştır. Bölüm sonlarında ilgili kavram ve komutların eksik kalan kısımları ayrıca açıklanmıştır. Bu sayede mevcut konuyu kavrarken dikkatinizin dağılmasını önlediğimiz gibi konu içerisindeki kavram ve komutların ayrıntılı açıklamalarına da ayrıca ulaşmamız mümkün olacaktır. 

Açıklamalar sırasında İngilizce terimlerin mümkün oldukça Türkçe karşılıklarını kullanıp parantez içerisinde İngilizce karşılıklarını belirtiyor olacağız. Ancak yine de İngilizce terimin daha anlaşılır açıklama imkanı sunduğu istisnai durumlarda İngilizce terimler ile de karşılaşacaksınız. 

Ayrıca anlatımlar sırasında "GNU/Linux" ifadesi yerine kısaca belirtmek adına yalnızca "Linux" ifadesini kullanıyor olacağım. Ancak merak etmeyin çekirdekten(Linux) bahsederken ve işletim sistemi bütününden bahsederken(GNU/Linux) hangisini kast ettiğimi anlıyor olacaksınız.

`Komutlar bu şekilde gözükür.`

```bash
Çoklu komutlar 
ve çıktıları 
bu şekilde gösterilir.
```

***Dosya ve klasörler bu şekilde gösterilir.***

<aside>
⚠️ Uyarılar bu şekilde yapılır.

</aside>

<aside>
ℹ️ Açıklama ve ek bilgiler bu şekilde yapılır.

</aside>

## 0.5 Neden Bash Kabuk Programlama Öğrenelim ?

Burada en önemli motivasyon bash kabuğunun *nix sistem türevlerinde son derece yaygın kullanıma sahip olmasıdır. Bu sayede yazdığımız bir program hiç bir ekstra ortam kurulumuna ihtiyaç duymadan pek çok sistem üzerinde çalışabilir. Bu durumun haricinde, bash kabuğunu programlamayı öğrenirken aslında bash kabuğunun temel çalışma yapısı ve sistemle iletişimi hakkında pek çok temel bilgiyi de ediniyor olacağız. Bu sayede programlama dışında bash kabuğunu interaktif şekilde kullanırken gerçekleştirebileceğimiz işlemlerin verimi ve anlamı da biziler için artmış olacak. Ayrıca kabuk dilleri kolayca pek çok farklı aracı ve programlama dillerinin aynı anda kullanılabilmesine de olanak tanıdığından son derece kolay yazılabilir ve güçlü etkilere sahip yapılar ortaya koyulabilir.

Bu kitapta bizler bash kabuğunu programlama için ihtiyaç duyacağımız tüm temel bilgilerine değiniyor olacağız. Buradan edindiğiniz bilgileri uygulama yaparak hayata geçirdiğiniz sürece kalıcı kılabilirsiniz, aksi halde öğrenilen bilgiler unutulacaktır. Ayrıca bu kitabın hedefi bash kabuğunu tanıtmak olduğu için gnu/linux sistemi ile ilgili sahip olduğunuz bilgiler dahilinde programlama yetenekleriniz ve kapasiteniz de artacaktır. Dolayısı ile üzerinde çalıştığınız sistemi ne kadar iyi tanırsanız o kadar verimli projeler ortaya koyabilirsiniz. 

Ek olarak, karmaşık görevler için komut satırının nasıl kullanılacağını öğrenmek, bir işletim sisteminin nasıl çalıştığını daha iyi anlamanızı sağlar. En yetenekli siber güvenlik uygulayıcıları, araçların nasıl kullanılacağını değil, temel düzeyde nasıl çalıştığını anlar.

Bu kitap başlangıç-orta seviye bilgi sunma hedefindedir. İleri seviye detaylar yer almasa da sizlere sunduğu temelin üzerine ileri seviye detayları araştırma konusunda bir dayanak olmak gayretindedir.

## Kaynakça

Kaynak olarak GNU Bash resmi dokümantasyonu POSIX Shell klavuzu referans alınmıştır. Linklerin zaman içinde değişime uğraması ihtimaline karşı doğrudan bağlantı adresi sunmuyorum. Herhangi bir arama motorunu kullanarak saniyeler içinde hem GNU Bash hem de Posix Shell klavuzuna rahatlıklar ulaşabilirsiniz.