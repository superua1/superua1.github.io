# Bash Kabuğunu Çağırmak

[https://zwischenzugs.com/2019/02/27/bash-startup-explained/](https://zwischenzugs.com/2019/02/27/bash-startup-explained/)

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%207b834252e6df4ce0b5d2576102322d95/Untitled.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/Bash%20Kabug%CC%86unu%20C%CC%A7ag%CC%86%C4%B1rmak%207b834252e6df4ce0b5d2576102322d95/Untitled.png)