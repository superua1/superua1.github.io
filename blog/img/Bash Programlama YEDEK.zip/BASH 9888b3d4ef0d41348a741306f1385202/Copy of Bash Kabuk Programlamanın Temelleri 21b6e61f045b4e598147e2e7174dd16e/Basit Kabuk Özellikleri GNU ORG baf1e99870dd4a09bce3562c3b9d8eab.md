# Basit Kabuk Özellikleri | GNU.ORG

[https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents](https://www.gnu.org/software/bash/manual/html_node/index.html#SEC_Contents)

[3.1 Bash Sentaks(syntax) Yapısı](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20baf1e99870dd4a09bce3562c3b9d8eab/3%201%20Bash%20Sentaks(syntax)%20Yap%C4%B1s%C4%B1%20524107f768124aee9f3793a094a386bc.md)

[3.2 Kabuk Komutları](Basit%20Kabuk%20O%CC%88zellikleri%20GNU%20ORG%20baf1e99870dd4a09bce3562c3b9d8eab/3%202%20Kabuk%20Komutlar%C4%B1%203fcc412c530e42248c65a668a31bce5d.md)