# 4- Argümanlar

# Argümanlar: Seçenekler - Parametreler - Alt Komutlar

Bu kısımda bash programlama yaparken sıklıkla kullanacağımız temel kavramların ne anlama geldiklerini açıklıyor olacağız. Kavramların anlamlarını bilerek devam etmek eğitimden maksimum verimi almanızı sağlayacağı için buradaki açıklamalar önemli. Yani bu bölümü atlamak gibi bir niyetiniz varsa buradaki anlatımları en azından gözden geçirmenizi şiddetle tavsiye ederim.

Aslında bizler argüman kavramına yabancı değiliz. Konsol gibi bir araç üzerinden kabuğa gönderilen verilerin tamamı "argüman" olarak kabul ediliyor. Yani aslında kabuk için konsoldan gelen ifadelerin tamamını bir dizi argümandır. Bu ne demek oluyor ? Örnek üzerinden açıkladığımızda tüm kavramlar çok daha net anlaşılacağı için örnek üzerinden devam edelim.

Örneğin ben konsola `ls -la /etc /home/taylan` komutunu girdiğimde, burada yer alan tüm ifadeler kabuk tarafından argüman olarak kabul edilir. Kabuğa ulaşan argümanlar kabuk tarafından değerlendirilerek argüman tiplerine göre işleme alınırlar. Bizim örneğimizde;

1. Argüman: listeleme aracını çalıştıran`ls` komutudur.
2. Argüman: `ls` komutunun özel kullanım seçeneğidir.
3. Argüman: `ls` komutunun, üzerinde işlem yapmasını istediğimiz veriyi belirten parametredir.
4. Argüman: `ls` komutunun, üzerinde işlem yapmasını istediğimiz veriyi belirten parametredir.
(Argüman değerlerini sıfırdan başlayarak tanımlamış olma nedenim kabuk dilinin de bu şekilde kabul ediyor olmasıdır. Yani kabuk dili için başlangıç noktası hep "**0.**" değerdir.)

Eğitim başında kabuğun görevinden ve temel olarak nasıl çalıştığından bahsetmiştik hatırlarsanız. Kabuk dediğimiz yapı, bizlerin yani insanların kolayca ifade edebileceği dilden işlem emirlerini bilgisayarın anlayacağı dile çevirme görevindedir. Bu noktada yaptırmak istediğimiz işlemin doğru şekilde yerine getirilebilmesi için kabuğa iyi bir biçimde ifade edebilmemiz çok önemlidir. İfade biçimi olarak da zaten öğrenmekte olduğumuz kabuk dilini kullanıyoruz. Bu kabuk dilinin de elbette tıpkı insanların konuştuğu dilde olduğu gibi kendine ait dil kuralları bulunuyor. Nasıl ki bizler iletişim kurarken "özne yüklem zarf edat" ve benzeri dil bilgisi kurallarına uyduğumuz ölçüde karşı tarafa derdimizi net biçimde ifade edebiliyorsak, bu durum kabuk dili için de aynen geçerlidir. Bu bahsi geçen sözdizim kurallarının geneline, dilin "sentaksı/syntax" denir. Yapmak istediklerimizi doğru ve verimli bir biçimde kabuğa aktarmak için, kabuğun sahip olduğu dil kurallarına yani sentaks/syntax düzenine de uymamız gerekiyor.

**Örneğimizde yer alan argümanları açıklayacak olursak;**

### 0. Argüman

Kabuk diline göre sıfırıncı yani başlangıçta yer alan ilk argüman her zaman için varsayılan olarak araç çalıştırma emridir. Kabuk bu emri aldığında daha önce bahsettiğimiz şekilde PATH değişkeni ile tanımlanmış yola bakarak, çalıştırılabilir araç dosyalarını arar ve eğer mevcutsa çalıştırır. Bizim örneğimizdeki `ls` komutu da aslında sistem üzerinde yüklü bulunan listeleme işini yapan aracı çalıştırmak için kullandığımız komuttur. Bizler listeleme işini yapan aracı çağırmak istediğimizde, aracımızın ismi olan `ls` komutunu gireriz.

### 1. Argüman

Birinci argüman, çalıştırılan aracın sahip olduğu çalıştırılma seçeneklerini belirtmemizi sağlıyor. Örneğimizdeki `ls` aracı için belirtmiş olduğumuz `l` seçeneği ayrıntılı listeleme yaparken, `a` seçeneği ise gizli dosyalar da dahil tüm dosyaların listelenmesini sağlıyor. Seçenek belirtirken dikkat edilmesi gereken detay, seçeneklerin önüne kısa çizgi eklemektir. Bu sayede ilgili argümanın seçenek argümanı olduğu kabuk tarafından anlaşılabilir. Ayrıca seçenek belirtirken kısaltma kullanmak yerine varsa seçeneğin uzun halini belirtmek üzere çift kısa çizgi kullanmamız gerekir. Yani örneğin seçeneğin kısa halini `ls -a` şeklinde belirtirken, uzun halini `ls --all` şeklinde belirtmemiz gerekiyor. Bu sayede kabuk, ikinci argümanın hangi amaçla girilmiş olduğunu anlamlandırabiliyor.

### 2. ve 3. Argüman

İkinci argüman ise, aracın hangi değer üzerinde işlem yapacağını belirten parametredir. Bizim örneğimizde yer alan ikinci ve üçüncü argüman aslında `ls` aracına verilmiş olan parametrelerdir. Örneğimizde, **/etc/** ve **/home/taylan** dizilerinin listelenmesi için `ls` komutuna özellikle bu dizinleri parametre olarak girdik. Eğer biz parametre belirtmemiş olsaydık, `ls` aracı varsayılan olarak konsolun çalışmakta olduğu konumu basacaktı. Girilen argümanın parametre olarak algınlanması için, elbette çalıştırılacak olan aracın isminden ve araç seçeneğinden sonra girilmesi gerekiyor. Bu sayede araç ve aracın seçenekleri, ilgili argümanı parametre olarak işleyebilir. Bu noktada özel bir durumu da belirtmem gerekiyor. Biliyorsunuz ki seçenekleri belirtirken duruma göre tek ya da çift kısa çizgi kullanmamız gerekiyor. Biz tek ya da çift kısa çizgi kullandığımızda kabuk bunun bir seçenek olduğunu anlamış oluyor. Peki ya parametremizin başlangıcında da tek veya çift kısa çizgi bulunuyorsa ne olacak ? Hemen bir örnek üzerinden bahsedilen durumu görmüş olalım.

Ben örnek olması açısından ilk olarak "-test" ve "--test2" isimli iki adet klasör oluşturmak istiyorum. Bu işlem için konsola `mkdir -test --test2` komutunu giriyorum.

Komutumun ardından konsol bana, `mkdir` aracının "-t" ifadesi ile isimlendirilmiş bir seçeneğinin bulunmadığını bildiriyor. Yani benim dosya ismi olarak girdiğim argüman, başındaki kısa çizgilerden dolayı kabuk tarafından seçenekmiş gibi değerlendiriliyor. Tırnak işareti kullanmadığım için bu hatayı aldığımı düşünebilirsiniz, eğer öyleyse aynı komutu dosya isimlerini tırnak içerisinde yazarak tekrar girmeyi deneyelim.

`mkdir "-test" "--test2"mkdir '-test' '--test2'`

Tırnak işareti kullanmamıza karşın çıktıda yine "t" isimli bir seçenek bulunmadığı belirtiliyor. Yani bu durum da gösteriyor ki, başında tek ya da çift kısa çizgi bulunan argümanlar kabuk tarafından aracın seçeneği olarak algılanıyor. Biz ilgili argümanı parametre olarak yani parametre niyetine girmiş olsak da, başındaki kısa çizgiden dolayı bu argümanlar kabuk tarafından seçenek olarak değerlendiriyor. Bu durumu yaşamamak için parametre girmeden önce çift kısa çizgi ve bir boşluk bıraktıktan sonra parametrelerimizi girmeliyiz. Çıktılara göz atarak ne demek istediğimi çok daha net görebilirsiniz.

```
`mkdir -- -test --test2`
```

Burada belirtmiş olduğumuz çift kısa çizgi işareti, bundan sonraki ifadelerin artık parametre olduğunu kabuğa özellikle belirtmemizi sağlıyor. Bu kullanım da sentaks dediğimiz sözdizim kuralının bir parçasıdır.

### Alt Komutlar

Son olarak alt komut argüman türünü de ele alacak olursak; alt komut, araçların kendine has olan komutlarının aracın yönetimi için kullanılmasıdır. Bu ne denemek oluyor ? Örneğin biz `apt` aracını `apt install figlet` şeklinde kullandığımızda, burada yer alan "figlet" argümanı aslında bir değişkendir. Yani yerine herhangi bir ifade herhangi bir program adı gelebilir. Ancak girilmiş olan argümanlar içerisindeki `install` ifadesi yerine yükleme işlemi için başka bir argüman giremeyiz. Çünkü `apt` aracı `install` ifadesi dışındaki hiç bir ifadenin program kurulum işlemini belirttiğini anlayamaz. Burada yer alan `install` argümanı `apt` aracının kendi içerisinde anlamlı bulduğu alt komuttur. İşte bu türden argümanlara genel olarak alt komut da denebiliyor.

İşte argümanlar bu şekilde programların(araçların) çalışmasına etki eden, programları kullanıcının istekleri doğrultusunda yönlendiren ifadelerdir. Bahsetmiş olduğumuz "argüman", "seçenek", "parametre", "alt komut" gibi kavramların tam olarak ne anlama geldiğini bilmeniz, eğitimi takip edebilmeniz ve dolayısı ile etkili şekilde programlama yapabilmeniz için son derece önemlidir. Yani lütfen buraya kadar ele aldığımız kavramları tam olarak anlayamadıysanız tekrar etmekten çekinmeyin.

## Konumsal Parametreler (Positional Parameters) - Argüman Tutucu Değişkenler

Bizler de programlama yaparken, kullanıcıdan alınacak argümanları program içerisinde işleyebilmek için argüman tutucu değişkenleri yani diğer bir değişle konumsal parametreleri kullanabiliyoruz. Bu değişkenler sistem tarafından tanımlanmıştır ve her birinin kendine has bir işlevi vardır. Kısacası argüman tutucu değişkenler, kabuğa girilen veriler hakkında bilgi sunup, bizlerin bu verileri biçimlendirerek ihtiyacımız olduğu alanlarda kullanabilmemize olanak tanırlar. Bu açıklama yeterli gelmediyse endişelenmeyin, örnekler üzerinden konuyu çok rahat şekilde kavramış olacaksınız.

Şimdilik kısaca hangi özelliğin hangi işlevde olduğunu görmek adına aşağıdaki tabloya göz atabilirsiniz.

[Untitled](4-%20Argu%CC%88manlar%20b5579e98a2e340f890ea1f74aab74e80/Untitled%20Database%20dad88273f46a4b13a3949aa8e71692aa.md)

Şimdi, tabloda yer alan özelliklerin kullanım amaçlarının daha net anlaşılabilmesi için tek tek ele alarak örnekler üzerinden açıklayalım.

## $0

Bu ifadenin kullanımı ile, ifadenin çağrıldığı komut dosyasının ismini öğrenebiliyoruz.

Örneğin konsol üzerinden `echo $0` komutunu girdiğimizde çıktı olarak **bash** ya da **/bin/bash** şeklinde çıktı alıyorken. Bu ifadeyi bir betik dosyasına ekleyip, betik dosyası üzerinden `echo $0` komutunu çalıştırdığımızda çıktı olarak **betik dosyasının ismi** basılıyor. Önceki anlatımlar sırasında, kabuğa girilen argümanların ilkinin kabuk tarafından varsayılan olarak çalıştırılacak araç olarak kabul edildiğini söylemiştik. Buradaki durum da benzer şekilde çalıştırılmış olan aracın adını öğrenmek için ilk argüman olan sıfırıncı pozisyona bakmamız yeterli oluyor. Zaten ilk argüman her daim çalıştırılan aracı temsil ediyor. Konsola girdiğimizde `bash` ya da `/bin/bash` çıktısını alıyor olma nedenimiz de, aslında konsol üzerinde çalışmakta olduğumuz aracın bash olmasından kaynaklanıyor. Sizler de biliyorsunuz ki bizler konsola komut girerken, aslında konsola özel olarak atanmış olan alt kabuğa komutlarımızı yani argümanlarımızı ulaştırmış oluyoruz. Bu noktada anlatımları sırasıyla atlamadan takip etmenin ne kadar önemli olduğunu sizler de fark etmişsinizdir.

## $N

Bu kullanım **N.** pozisyondaki değeri temsil ediyor. Buradaki **N** ifadesi yerine **1**'den **9**'a kadar olan rakamlar kullanılarak **9 adet** pozisyon değeri tanımlanabiliyorken, 0 rakamı ve 9'dan sonraki sayılar pozisyon değeri olarak atanamıyor.

[Untitled](4-%20Argu%CC%88manlar%20b5579e98a2e340f890ea1f74aab74e80/Untitled%20Database%20f9386de2cdad43898c31cf7dc3c3391e.md)

**0 rakamının kullanılamamasının nedeni**; bir önceki kısımda anlattığımız şekilde halihazırda başka bir özelliği(çalıştırılan komut dosyasının adını vermek) temsil ediyor olmasıdır.

**9 rakamından sonraki sayıların kullanılamamasının nedeni ise**; pozisyon parametrelerinin **yalnızca 1 basamaklı pozitif tam sayıları** alabiliyor olmasıdır. Örneğin ben $13 şeklinde bir pozisyon değeri tanımlarsam, bu bash tarafından **1. pozisyon değeri** ve "**3**" ifadesi şeklinde algılanıyor. Ancak merak etmeyin bu durumun da bir çözümü var.

**Şimdilik 1'den 9'a kadar olan kullanımı ele alırsak;**

Betik dosyasında istediğimiz konumlara bu pozisyon değerlerini eklediğimizde, betik dosyası ile birlikte parametre verir gibi yazacağımız sıralı ifadeler bu pozisyon değerlerine otomatik olarak aktarılır. Daha iyi anlamak için aşağıdaki kullanım örneğine göz atın lütfen.

Aşağıdaki örnek üzerinden anlatıma devam edelim.

```
echo "Burası ilk değer girişiniz: $1"

echo "Burası ikinci değer girişiniz: $2"

echo "Burası üçüncü değer girişiniz: $3"

```

Ben yukarıdaki şekilde **[betik.sh](http://betik.sh/)** isimli bir betik dosyası oluşturdum. Daha sonra bu betik dosyamı konsol üzerinden argümanları da belirterek `bash betik.sh değer1 değer2 değer3` şeklinde çalıştırdım. Bu kullanım ile dosyamın içerisinde yer alan pozisyon değişkenleri, betik dosyasının argümanı olarak girilen değerleri sırasıyla alıp uygun pozisyonlarda kullandılar.

Bu örnekte de açık şekilde görüldüğü gibi, konsola girilen **1. 2.** ve **3.** argümanlar **$1 $2 $3** şeklinde tanımlanmış pozisyon değerlerine gönderilerek konsola çıktı olarak bastırılmış oldu.

Her şey iyi hoş ancak, bizler 9 dan daha fazla pozisyon değerine ihtiyaç duyarsak ne olacak ?

Yani örneğin ben ihtiyacım doğrultusunda 11. pozisyon değerini tanımlarsam konsol bana çıktı olarak **1. değer** ve "**1**" ifadesini veriyor. Aşağıdaki çıktıya bakarak bu durumu sizler de teyit edebilirsiniz.

Gördüğünüz gibi, 9 rakamından sonraki sayıları kullanarak yeni pozisyon değerleri tanımlayamıyorum.

Bu gibi durumlarda daha fazla sayıda pozisyon değerini kullanabilmek için `shift` komutunu kullanmamız gerekiyor.

## `shift` Komutu

Esasen `shift` komutu, yeni bir pozisyon değeri tanımlamaktan ziyade var olan değerleri kaydırarak 9'dan daha fazla pozisyon değeri tanımlamamıza olanak tanıyor.

En temel kullanımı ile herhangi bir rakam belirtmeden kullandığımızda; ilgili pozisyon değerini bir birim öteleme işlevindedir.

Örneğin betik dosyası içerisine `echo $1` ifadesini yazıp konsoldan `bash betik.sh değer1 değer2` şeklinde komut girdiğimizde, çıktı olarak yalnızca "**değer1**" ifadesini alırız. Bu durumun nedeni ikinci değeri tutacak olan pozisyon parametresinin betik dosyası içerisinde belirtilmemiş olmasıdır.

Şimdi aynı örneği bir de `shift` komutu yardımı ile ilk pozisyon değerini öteleyerek deneyelim. Bunun için betik dosyama `shift` komutunu ekliyorum.

Daha sonra aynı şekilde konsola `bash betik.sh değer1 değer2` komutunu giriyorum. Ve gördüğünüz gibi bu sefer aldığım çıktı 2. pozisyon değeri olan "**değer2**" ifadesi olmuş oldu. Yani neticede biz, `shift` komutu ile 1. pozisyon parametresini bir birim öteleyerek 2. değeri bastıracak şekilde tanımlamış olduk.

İşte bu şekilde ihtiyacımız kadar ötelemeyi `shift` komutunun ardından gireceğimiz sayı ile belirtebiliyoruz.

Yani örneğin var olan 1. değeri 15 birim öteleyerek 16. değeri alacak şekilde düzenlemek için `shift 15` komutunu aşağıdaki örnekte olduğu şekilde kullanmamız yeterli oluyor.

```
 shift 15 echo $1 

```

Bu örnekten de anlayabileceğiniz gibi `shift` komutu, var olan değişkenin pozisyon değerinin üzerine belirtilen sayıyı ekleme yaparak değişkeni öteliyor. Yani örneğin 5. değişken değerini 21. değişken değerine kadar ötelemek istersek, ekleme işlemini `shift 16 $5` şeklinde kullanmamız gerekecekti.

Aşağıdaki kullanım örnekleri konunun genelini anlamanızda yardımcı olabilir. Lütfen göz atın.

```
echo $1
echo $2
echo $3
echo $4
echo $5
echo $6
echo $7
echo $8
echo $9
shift & echo $9
shift 1 & echo $9
shift 2 & echo $9
shift 3 & echo $8
shift 3 & echo $9

```

## $*

Daha önce de sıklıkla karşımıza çıktığı gibi yıldız işareti tüm değerleri kapsama görevindedir. Yıldız değeri kullanıldığında, 1. değerden var olan son değere kadar tüm pozisyon değerlerini kapsam dahiline alınarak işleme sokulur. Kullanım amacını daha net anlamak adına lütfen aşağıdaki örneği inceleyin.

## $@

Tıpkı yıldız işareti kullanımında olduğu gibi; 1. değerden var olan son değere kadar tüm pozisyon değerlerini kapsama işlevindedir.

## $#

Tüm pozisyonlardaki toplam veri sayısını verir. Örneğin ben betik dosyama 6 veri/argüman girişi yaptığımda girdiğim veri/argüman sayısını **$#** kullanımı sayesinde görebiliyorum.

Bu kullanım gördüğünüz gibi, işleme sokulan kaç adet argüman değeri olduğunun bilgisini veriyor.

## $$

Bu ifadenin kullanımı ile, değişken çağrılırken çalıştırılan komut dosyasının **süreç numarasını** (**PID**) öğrenebiliriz. Bu kullanım da tıpkı **$0** gibi, kullanıldığı daha doğrusu çalıştırıldığı dosya üzerinden işlem yaptığı için; Doğrudan konsol üzerinden bu komut girildiğinde çalışmakta olan bash kabuğunun süreç numarasını veriyorken, eğer bir betik dosyası içerisinde bu komut çalıştırılırsa çıktı olarak betik dosyasının süreç numarasını konsola basıyor. Bu durumu aşağıdaki çıktılara bakarak teyit edebilirsiniz.

## $!

Bu kullanım ile **arkaplanda çalıştırılmış olan en son işlemin** süreç numarasını öğrenebiliyoruz. Kullanım örneği olarak; **leafpad** aracını çalıştırıp süreç numarasını öğrenelim.

Öncelikle **leafpad** aracımı çalıştırıyorum ve süreç numarasını `pgrep` komutu yardımı ile sorguluyorum.

Ardından **leafpad** aracımı **ctrl + z** tuşlaması ile durdurup, `bg leafpad` komutu ile arkaplanda çalışamaya devam etmesini sağlıyorum.

Son olarak da arkaplanda çalışan aracımın süreç numarasını sorgulamak üzere `echo $!` komutunu giriyorum.
Gördüğünüz gibi başlangıçta aldığımız süreç numarası ile en sonunda aldığım çıktıdaki süreç numarası aynı.

Sonuç olarak arkaplanda çalışan en son işlemin süreç numarasını nasıl elde edebileceğimizi görmüş olduk.

## $_

Eğer **en son kullanılan komutun en son argümanını** öğrenmek istersek **$_** ifadesini kullanabiliyoruz.

Örneğin ben bulunduğum konumdaki dosyaların tamamını düzenli şekilde listelemek üzere; konsola `ls -la` komutunu giriyorum. Ardından, en son girmiş olduğum komutun en son argümanını elde etmek üzere `echo $_` komutunu girip durumu test ediyorum.

Gördüğünüz gibi çıktımızda daha önce girmiş olduğum komutun en son argümanı olan "**la**" ifadesi yer alıyor.

Ancak burada önemli bir hatırlatma; bu kullanım yalnızca en son girilen argümanı kapsıyor. Yani bizler komutumuzu `ls -l -a` şeklinde girersek çıktıda yalnızca `a` argümanını alırız.

Bu noktada, eğer argümanların tamamını ya da isteğe bağlı olarak herhangi bir kısmını almak istersek, düzenli ifadeleri ve daha önce `history` komutunu anlatırken değindiğimiz ünlem işaretinden yararlanmamız gerekiyor.

Hatırlarsanız, iki kez kullandığımız ünlem işareti bizim en son kullanmış olduğumuz komutu **history** kayıtlarından çekerek getiriyordu. Aslında kullanılan ünlem işaretinin bu kullanım dışında da pek çok kullanım şekli mevcut.

Örneğin ben konsola `ls -a -A -l -f` şekline komutu giriyorum.

Parametrelerin tamamını çıktı olarak almak istersem komutumu `!*` şeklinde girmem yeterli oluyor.

Benzer şekilde uygulayabileceğimiz diğer faydalı komutlar:

- `!$` - bir önceki komutun son argümanı
- `!^` - bir önceki komutun ilk argümanı
- `!!` - bir önceki komutu verir
- `!n` history kayıtlarında yer alan n'inci komutu verir
- `!xyz` - `xyz` ifadesi ile eşleşen en son komutu verir
- `!!:s/X/Y`Son komutta yer alan, `X` ifadesi yerine `Y` ifadesini koyar.
- `!:0` = çalıştırılan son komutun ilk argümanını yani çalıştırılan aracı verir.
- `!:1` = önceki komutun ilk argümanını verir.
- `!:*` = önceki komutun tüm argümanlarını verir.
Ayrıca buradaki kullanımları birleştirerek ihtiyacınıza göre farklı kombinasyonları da kullanabilirsiniz.
- `!233:2` = history kayıtlarında 233. sırada olan komutun 2. argümanı
- `!15:s/X/Y`history kayıtlarında 15. olan komutta yer alan, `X` ifadesi yerine `Y` ifadesini koyar.
- `!22:*` = history kayıtlarında yer alan 22. komutun tüm argümanlarını verir.

Bu ve bunun gibi pek çok örnek oluşturulabilir ancak bu kadarlık örnek anlatım için yeterli. Sizler de buradan öğrendiğiniz bilgiler sayesinde, ihtiyacınıza göre geçmişte girilen komutlar manipüle edip kullanabilirsiniz.

Ancak bu özelliğin kabuk dosyası içerisinde kullanılabilmesi için, kabuk dosyasının çalıştırıldığı ortamın bu özelliği desteklemesi gerekiyor. Bu ortam özelliğinin adı "histexpand" olarak geçiyor. Anlatımın devamında zaten betik dosyasının çalıştırıldığı ortamın özelliklerini nasıl değiştirebileceğimizi ve ayrıca "histexpand" seçeneğini ele alıyor olacağız. Yani eğer history aracının bu özelliğini şu an için betik dosyanızın içerisinde kullanamıyorsanız hiç bir sorun yok. Anlatımın devamında bu konudan ayrıca tekrar bahsediyor olacağız. Sizler şimdilik history aracının bizlere sağladığı imkanlardan haberdar şekilde eğitime devam etseniz yeterli.

## $?

Mevcut kabukta çalıştırılmış olan **son komutun çıkış durumunu** verir.

Burada bahsi geçen çıkış durumu, verilen komutun sistemden aldığı tepkidir. Örneğin komut başarılı şekilde çalıştırılırsa **0** değeri çıktı olarak dönüyorken, sistemde öyle bir komut bulunmuyorsa **127** değeri çıktı olarak döndürülür. Çıkış kodları, yazdığımız programın hatalarının ayrıştırılmasında ve sistemden aldığı tepkiye göre hareket edebilecek programların geliştirilebilmesi adına oldukça önemlidir.

## Çıkış Kodları

Çıkış kodlarının amacı; yürütülen komutlar neticesinde ortaya çıkan durumun sisteme bildirilmesidir.
Bash üzerinde yer alan çıkış kodlarının standartlaştırılması için geçmişte pek çok girişim olmuşsa da maalesef ki kapsamlı bir standartlaştırma yapılamamıştır. Standartlaştırmanın önündeki en büyük engel, potansiyel olarak sınırsız olan pek çok duruma karşı genel tanımla yapmanın çalışma verimliliği açısından yetersiz olmasıdır.

Yine de genel durumları kapsayan çeşitli çıkış kodları sistemde varsayılan olarak tanımlanmıştır. Bunlar haricindeki çıkış kodlarının programlamayı yapan kişi tarafından, yazmış olduğu betiğin amacına uygun şekilde tanımlaması beklenmektedir. Şimdi sırasıyla sistemde tanımlı olan ve ayrıca bizlerin de tanımlayabileceği çıkış kodlarını ele alalım.

### Varsayılan Olarak Tanımlı Çıkış Kodları

Sistem tarafından tanımlanmış olan temel çıkış kodları aşağıdaki listedeki gibidir.

[Untitled](4-%20Argu%CC%88manlar%20b5579e98a2e340f890ea1f74aab74e80/Untitled%20Database%2085baf723551645be8dc370cd4de0bd1f.md)

Tablodan yola çıkarak varsayılan olarak tanımlanmış çıkış kodlarını kısaca ele alalım.

### 0

İlgili komutun herhangi bir hata meydana gelmeden çalıştırıldığını bildirir.

**Örneğin**

```
root@taylan:~# ls
2                   aquatone  dirsearch  Genel       Masaüstü  renk.sh   sub.sh     test.sh
agilecraft.com.txt  Belgeler  Downloads  gifoeb.git  Müzik     Resimler  Şablonlar  Videolar
root@taylan:~# echo $?
0
root@taylan:~# 

```

`ls` komutu sorunsuzca çalıştığı için çıkış kodu "**0**" oldu.

### 1

Mantıksal anlamda gerçekleştirilmesi mümkün olmayan işlem taleplerinin neticesinde ortaya çıkan genel hata kodudur.

**Örneğin;**
Herhangi bir sayı, sıfır rakamına bölünemeyeceği için "**1**" çıkış kodu döndürülür.

```
root@taylan:~# echo $[0/0]
bash: 0/0: sıfırla bölme (hata belirtisi "0")
root@taylan:~# echo $?
1
root@taylan:~# echo $[3/0]
bash: 3/0: sıfırla bölme (hata belirtisi "0")
root@taylan:~# echo $?
1
root@taylan:~# 

```

Benzer şekilde; argüman alarak çalışan bir komutu argümansız şekilde kullanırsak, komut eksik argümana sahip olacağından "**1**" çıkış değerini döndürür.

```
root@taylan:~# wget 
wget: URL kayıp
Kullanımı: wget [SEÇENEK]... [URL]...

Daha fazla seçenek için `wget --help' yazın.
root@taylan:~# echo $?
1
root@taylan:~# 

```

Bu ve bunlar gibi, komutların doğru olduğu ancak komutlardan istenen işlemlerin gerçekleştirilmesinin mümkün olmadığı her türlü mantıksal hatada "**1**" çıkış kodu döndürülür. Genellikle mantıksal olumsuzlama kullanımında, olumlu çıkış kodu olan 0 kodunun olumsuzunu temsil etmek için kullanılır. Bu oldukça genel bir hata kodu olduğundan hatanın sebebi çok çeşitli olabilir. Hatanın kaynağını anlamak için kullanılan komutun yapısına dikkat etmek gerekir. 

## Mantıksal Olumsuzlama

Mantıksal olumsuzlama herhangi bir işlemin çıkış durumunu; olumlu ise olumsuz, olumsuz ise olumlu şekilde yansıtmak için kullanılır. Bash üzerinde tek ünlem "`!`" işaretinin kullanımı mantıksal olumsuzlama oluşturur. 

Örneğin `whoami` komutu sonucu sorunsuzca döndürdüğü için **0** çıkış kodunu basar. Ancak biz `whoami` komutunun başında ünlem işareti ile çalıştırırsak bu sefer **1** çıkış kodu basılır. 

```bash
└─$ whoami
taylan
└─$ echo $?
0
└─$ ! whoami
taylan
└─$ echo $?
1
```

Benzer durum olumsuz çıkış kodu döndüren yapıların da 0 çıkış kodunu yansıtmasını sağlayabilir.

```bash
└─$ echo $?
127
└─$ ! asdf
-bash: asdf: command not found
└─$ echo $?
0
```

Mantıksal olumsuzlama kullanımı genellikle koşullu durumlarda kullanılır. Bu durumu koşullu durumlardan bahsederken çok daha net görmüş olacaksınız.

### 2

Bash kabuğu için belirlenmiş olan standartların dışındaki kullanımları temsil eder.

Bu standartlar, kabuk programlama yaparken uyduğumuz söz dizimi diğer bir deyişle sentaks(syntax) kurallarıdır. Girilen komutların kabuk tarafından doğru şekilde anlaşılabilmesi için kabuk standartlarınca belirlenmiş olan sıralamalar ve kullanım yapıları dikkate alınmalıdır. Aksi halde komutlar başarısız olur ve "**2**" çıkış kodunu döndürür.

**Örneğin;**
Parantezleri ters açıp ters kapatmak bir söz dizimi(sentaks) hatasıdır.

```
root@taylan:~# echo $("date")
Cts Ara 21 10:49:09 +03 2019
root@taylan:~# echo $)"date"(
bash: beklenmeyen dizgecik `)' yakınında sözdizimi hatası
root@taylan:~# echo $?
2
root@taylan:~# 

```

Yukarıdaki örnek gibi sınırsız sayıda örnek oluşturabiliriz. Buradaki önemli olan nokta, "**2**" çıkış kodunun **mevcut kabuk yapılarının yanlış kullanılması ile** ortaya çıkıyor olmasıdır.

### 126

Yetki sorunları nedeniyle var olan bir komut çalıştırılamıyorsa ya da girilen komut sistem tarafından yürütülebilir bir komut değilse "**126**" çıkış kodu döndürülür.

**Örneğin;**
Test etmek için çalıştırılma yetkisi bulunmayan betik dosyamı çalıştırmayı deniyorum. Ve ardından `echo $?` komutu ile döndürülen değeri kontrol ediyorum.

Gördüğünüz gibi dosyamın çalıştırılma yetkisi bulunmadığından konsol "**126**" değerini döndürmüş.

### 127

İlgili komutun sistemde var olmadığı durumlarda "**127**" çıkış kodu döndürülüyor.

**Örneğin;**
Konsola `asdf` komutunu girip, döndürülen değeri sorgulayalım.

Gördüğünüz gibi böyle bir komut sistemde tanımlı olmadığı için "**127**" değeri çıkış kodu olarak döndürülmüş oldu.

### 128

Mevcut çıkış kodları yerine anlatımın devamında kendimiz de yeni çıkış kodları tanımlıyor olacağız. Elbette çıkış kodunu tanımlarken kodların alabileceği değerlerin de bir kuralı bulunuyor. Örneğin tam sayı dışındaki sayılar çıkış değeri olarak tanımlanamaz. Çıkış değeri tanımlamak için tek yapmamız gereken `exit` ifadesinin yanına çıkış değeri olarak kullanılmasını istediğimiz sayıyı belirtmektir. Bu sayı da kurallar gereği pozitif tam sayı olmak zorundadır. Kurala uygun olmayan bir çıkış kodu tanımlamanın 128 çıkış kodunu döndürdüğünü aşağıdaki çıktıya bakarak gözlemleyebilirsiniz.

```
root@taylan:~# exit 4,55
root@taylan:~# echo $?
128
root@taylan:~#

```

### 128 + n

Hata sinyali "n" olan değeri temsil eder. Peki ama burada bahsi geçen sinyal ifadesi ne anlama geliyor ?
Sinyaller, önemli bir olayın meydana geldiğini göstermek için bir programa gönderilen yazılım kesintileridir. Bu konudan eğitimin devamında ayrıca bahsediyor olacağız. Yine de hazır yeri gelmişken, bir süreci zorla sonlandırma işlevine karşılık gelen "9" sinyal numarası ile basit bir test gerçekleştirelim. Örnek olması açısından çalışmakta olan 1345 süreç numaralı işlemi zorla sonlandırmak üzere `kill -9 1345` komutunu giriyorum. Ve aslında bu komutla birlikte 9 numaralı sinyali çağırmış oluyorum. Bu işlemin neticesinde konsol ilgili süreci zorla sonlandırıp işlemin sonunda 128 + 9 yani 137 çıkış kodunu basmış oluyor. Sinyalin durumuna göre bu sayı 128 sayısının üzerine 128 + n şeklinde eklenmek suretiyle değişiklik gösteriyor elbette.

### 130

Yine sinyal kodlarına bağlı olarak, kabuğun Ctrl + C kombinasyonu ile kapatıldığında döndürülen çıkış kodudur.
Konsolun kapatılması için gereken Ctrl + C kombinasyonu sinyal kodu olarak 2 ye tekabül eder ve 128 değeri üzerine eklenerek 130 çıkış kodunun basılmasını sağlar.

```
root@taylan:~# ^C
root@taylan:~# echo $?
130
root@taylan:~#

```

İşte buradaki örnekler gibi yukarıdaki tabloda yer alan çıkış değerleri, komutların çalıştırılması sonucu ortaya çıkan durumlardan sistemi haberdar etmek üzere otomatik olarak döndürülüyor. Bu değerlerin asıl kullanım amacı, komutun çalıştırılması sırasında meydana gelen olaylardan haberdar olmak ve sorun yaşanması durumda bu değerler üzerinden çözüm için hareket edebilmektir.

### Yeni Çıkış Kodu Tanımlamak

Sistemde varsayılan olarak tanımlanmış olan çıkış kodlarının dışında, tam olarak ihtiyacımıza yönelik çıkış kodları da tanımlayabiliyoruz.

Tanımlama yaparken de elbette dikkat etmemiz gereken hususlar bulunuyor;

- Var olan çıkış kodlarını kullanarak yeni kod tanımlamamak gerekiyor. Tanımlanması halinde kodların kullanımları karışacağından, programın yorumlanması noktasında sorun meydana gelebilir.
- 0 ile 255 sayıları arasında bir kod değeri tanımlamak gerekiyor. 255 den daha yüksek bir sayı, kod değeri olarak atanırsa değerin modu alınarak işleme sokuluyor. Yani örneğin ben kod değeri olarak 370 sayısını tanımlarsam, bu değer bash tarafından 256 sayısına göre modu alınarak 114 değerine dönüştürülüyor. Burada 256 sayısının kullanılmasının nedeni 255 sayısını aşacak her türlü durumu önlemek. Durum böyle olunca, yüksek sayılarla tanımlanmış durum kodlarının modu alındığında var olan sayılara tekabül etmesi ile yine programın yorumlanması noktasında sorunlar oluşabiliyor. Yani özetle 255 den yüksek bir sayı tanımlaması yapmanız önerilmez.
- Ayrıca tanımlamayı negatif sayılar üzerinden yaparsak; örneğin çıkış kodunu **5** olarak tanımlarsak, çıkış değeri olarak **256** sayısından **5** rakamının çıkarılmış hali olan **251** sayısını alırız. Burada kullanılan 256 sayısının amacı da aynı şekilde değerleri 0 ile 255 sayıları arasında tutabilmektir. Eksi sayı çok küçük bir miktarı ise çıkarma işlemi 256 sayısının katlarından yapılır. Yani örneğin "**257**" sayısının exit kod olarak yansıması **255** olarak gözükür. Bu kodun oluşturulması "256-257= -1 + 256= 255" şeklindedir.

Kısacası kendi çıkış kodumuzu tanımlamak için yapmamız gereken tek şey `exit` komutunun ardından **0** ile **255** sayıları arasında daha önce tanımlanmamış bir tam sayı belirtmektir. Örneğin ben `exit 55` komutu ile, çıkış kodu **55** olan bir tanımlama yapmış oluyorum.

Peki tanımladığımız bu çıkış kodlarını nerede ve hangi amaçla kullanacağız ?

Örneğin yazmış olduğunuz betik dosyası çalışmak için harici bir araca ihtiyaç duyuyorsa, ilgili aracın sistemde yüklü olmadığını çıkış kodlarından öğrenip ilgili aracı yüklemesi için kullanıcıya talimat verebilirsiniz. Bu ve bunun gibi pek çok farklı özel duruma göre çıkış kodlarının kullanılması gerekebilir.

Temelde tüm olay bundan ibaret arkadaşlar. Şu an için sizlere önemsiz gibi görünen çıkış kodlarının, aslında ne kadara kullanışlı olabildiğini çok daha kapsamlı projelerde kendiniz de fark edeceksiniz. O yüzden şimdilik anlatımlara devam edelim.

## $-

Bu ifade ise bash kabuğunun ayarları hakkında bizlere bilgi sağlıyor. Kullanım amacını daha iyi anlamak adına hemen `echo $-` komutu ile mevcut kabuğun ayarlarını bastırmayı deneyelim.

Aldığımız çıktı "**himBHs**" şeklinde oldu. İyi, güzel ancak bu ifade ne anlama geliyor ?

Bu ifade bash kabuğunun varsayılan olarak tanımlanmış bir takım ayarlarını bildiriyor. Burada yer alan anlamsız gibi görünen harfler ise ilgili ayarların kısaltmalarını temsil eden karakterler.

Daha önceki kısımlardan öğrendiğimize göre, bir betik dosyasını çalıştırdığımızda aslında yeni bir alt kabuk oluşturularak betik dosyasının bu alt kabukta yürütüldüğünü biliyoruz. İşte bu oluşturulan yeni alt kabuk, betik dosyasının çalıştırıldığı ortamdır. Bu ortamın çalışma durumunu yani ortamın sahip olduğu ayarlarını da `set` komutu yardımıyla ihtiyaçlarımıza göre özelleştirebiliyoruz.

Hatırlarsanız temel linux eğitiminde terminalin aniden kapanmasına engel olmak için `set -o ignoreeof` komutunu kullanmıştık.(Hatırlamıyorsanız ya da dokümantasyonu okumadıysanız buradan ilgili kısıma göz atabilirsiniz.) Bu işlem ile mevcut kabuğun ayarlarında yani çalışmakta olduğumuz ortamın ayarlarında oynama yapmıştık aslında.

İşte bu kısımda ele alacağımız konu da, `set` komutunu kullanarak mevcut kabuğun ayarlarını değiştirmek olacak.
Ayrıca konsol üzerinden çalıştırılan bash ortamının sahip olduğu varsayılan ortam özellikleri ile betik dosyasının çalıştırıldığı ortamın sahip olduğu varsayılan ortam özelliklerinin aynı olmadığını da bilmeniz gerekiyor.

Bu durumu gözlemlemek adına konsola echo $- komutunu girelim.

Gördüğünüz gibi aldığımız çıktı "**himBHs**" şeklinde oldu. Yani konsol üzerinde çalışmakta olan mevcut bash kabuğunun varsayılan olarak sahip olduğu ortam özelliklerinin kısaltması çıktıda gördüğünüz gibi. Şimdi de kıyaslayabilmek adına echo $- komutunu betik dosyamızın içerisinde yazıp, betik dosyamızı çalıştıralım.

Betik dosyamızı çalıştırdığımızda sizlerin de görebileceği gibi aldığımız çıktı "**hB**" şeklinde oldu. Bu çıktı ile önceki çıktıyı kıyaslayarak, konsol üzerinden çalıştırılmış bash ortamı ile betik dosyasının çalıştırıldığı bash ortamının varsayılan olarak aynı ortam özelliklerine sahip olmadığını teyit edebiliyoruz. Bu durumun farkında olmanız yazacağınız betik dosyasının doğru şekilde çalışabilmesi adına önemli. Eğer bizler betik dosyamızın doğru şekilde çalışmasını istiyorsak, elbette betiğin çalışacağı ortamı da ihtiyaçlarımıza göre özelleştirmemiz gerekiyor. İşte bizler de anlatımın devamında bu ortam özelliklerinden ve bu özelliklerin etkilerinden bahsederek betik dosyamızın ihtiyaçlarına uygun olan ortamlar oluşturmayı öğreniş olacağız. Açıklamaya `set` komutu ile devam edelim.

## Set Komutu

`set` komutunun 2 farklı kullanım şekli bulunuyor.

- Ayar ifadelerinin uzun isimlerinin yazılması.
- Ayar ifadelerinin kısaltmalarının yazılması.

### Uzun İsim Kullanımı

Eğer atayacağımız ayarların **kısaltma ifadelerini kullanmayacaksak** , bu ayarları aşağıdaki gibi uzun isimleri ile belirtmemiz gerekiyor.

**Ekleme işlemi için;**

```
set -o eklenecek_ayarın_adı

```

**Çıkarma işlemi için;**

```
set +o çıkarılacak_ayarın_adı

```

Yukarıdaki kullanımlarda yer alan **o** argümanları ingilizce **option-name** yani "**seçenek ismi**" ifadesini karşılıyor. Ayrıca komutların kullanımından da anlayacağınız gibi; **** işareti yeni ayar tanımlarken, **+** işareti ise var olan ayarın kaldırılmasını sağlıyor.

### Kısaltmaların Kullanımı

Eğer atamak istediğimiz ayarın ismini uzun uzadıya yazmak yerine **kısaltmalarını kullanmak** istersek, komutlarımızı aşağıdaki şekillerde kullanmamız gerekiyor.

**Ekleme işlemi için;**

```
set -eklenecek_ayarın_kısaltması

```

**Çıkarma işlemi için;**

```
set +çıkarılacak_ayarın_kısaltması

```

### Özellikler

Aşağıdaki tabloya bakarak bash kabuğuna tanımlayabileceğiniz seçenekleri, kısaltmaları ile beraber görebilirsiniz.

[Untitled](4-%20Argu%CC%88manlar%20b5579e98a2e340f890ea1f74aab74e80/Untitled%20Database%20c1e9570d2dcb489cb58c8f9832300b14.md)

Tablodan yola çıkarak örnekler üzerinden `set` komutunun kullanımını yani çalışma ortamının özelliklerini nasıl değiştirebileceğimizi de pekiştirmiş olalım. Kullanımları ele alırken seçeneklerin mevcut olan kısa ve uzun isimleri başlıkta yer alıyor olacak. Ben anlatımlar sırasında uzun ya da kısa kullanımlardan yalnızca birini tercih etsem dahi, elbette sizler kısa ya da uzun olan kullanımlardan istediğiniz bir tanesini kullanmakta özgürsünüz.

Ayrıca çalışmakta olduğumuz ortamın özelliklerinden bahsederken pek çok alt konuya değineceğimizi de şimdiden belirtmiş olayım. Bu sayede çalıştığımız ortam ve bash programlama adına pek çok yeni bilgiyi birbiri ile bağlantılı şekilde öğrenmiş olacağız.

## set -u | set -o nounset

Bash, var olmayan değişkenlerin hepsini yok sayar.

```
echo $a
echo Metin

```

Yukarıdaki betiği çalıştırdığımızda aşağıdaki şekilde bir çıktı elde ediyoruz.

```
$ bash betik.sh

Metin

```

Fark ettiyseniz ilk değişken tanımlı olmamasına rağmen komut satırı, bir satır boşluk bırakıp ikinci komutun çıktısını basmış oldu.

Bu gibi durumlarda eğer değişken tanımlı değilse betik dosyası çalışmayı durdursun ve bize böyle bir değişken değerinin tanımlı olmadığını bildirsin istersek, betik dosyamızın içine bu ifadeyi eklememiz gerekiyor.

```
#!/usr/bin/env bash
set -u

echo $a
echo Metin

```

Eklediğimizde sonuç aşağıdaki şekilde gözükür.

```
$ bash script.sh
bash: script.sh:行4: a: unbound variable

```

Ayrıca `set -u` ifadesi yerine daha uzun şekilde, `set -o nounset` ifadesini de kullanabileceğimizi biliyorsunuz. Ben anlatım sırasında kısaltmaları tercih ediyor olacağın ancak sizler dilerseniz uzun ifadeleri de kullanabilirsiniz.

## set -x | set -o xtrace

Betik dosyamızı çalıştırdığımızda, konsol ekranında yalnızca komutların üretmiş olduğu çıktıları görüyoruz. Eğer komutların çıktıları ile birlikte, kullanılan komutları da görmek istersek betik dosyasına bu ifadeyi eklememiz gerekiyor.

Gördüğünüz gibi kullanılan komutlar başında artı işareti ile ayırt edici şekilde konsol ekranına basılıyor.

Bu kullanım, karmaşık komut dosyalarında hata ayıklamak(debugging) için gerçekten çok kullanışlıdır. Çünkü hatayı oluşturan komutu, hata satırının bir üst kısmında doğrudan görme imkanınız vardır. Bu sayede hatanın tam olarak hangi noktada meydana geldiğini tespit etmemiz kolaylaşır. Hazır hatalardan bahsetmişken, hata işleme konusu ile anlatıma devam edebiliriz.

## Bash'te Hata İşleme

Betik dosyasında yer alan komutlar içerisinde çalıştırılamayan bir komut varsa (yani çıkış kodu 0 değilse), Bash kabuğu varsayılan olarak hatalı kodları görmezden gelerek sıradaki komutları çalıştırmaya devam eder.

```
#!/usr/bin/env bash

asdf
echo metin

```

Örneğin yukarıdaki betik dosyasını çalıştırdığımızda ilk komut hata verecek ve ikinci komut konsola "**metin**" ifadesini basacak.

Bu durum, yazdığımız betik dosyasının çalışma verimini ve meydana gelen hataların ayıklanmasını olumsuz yönde etkiliyor. Çünkü hata meydana gelse dahi betik dosyası çalışmaya devam ediyor.

Normalde, hata yığılmasını önlemek ve stabil şekilde çalışan betikler ortaya koymak için özellikle geliştirme aşamasında bir hata meydana geldiğinde betik dosyasının durdurulmasını isteriz. Böylelikle olası hataları keşfetme ve henüz geliştirme aşamasında hataları çözümleme fırsatı buluruz. Bu işlem için birden fazla alternatifimiz bulunuyor. Bunlardan ilki, sıklıkla karşılaşabileceğiniz mantıksal operatör kullanımıdır.

## Mantıksal Operatörler

Bash üzerinde yer alan ve komutların birbirine bağlı olarak çalışmasını sağlayan karakterlere **mantıksal operatörler** deniyor. Temel Linux eğitimi içerisinde, bu operatörleri sadece çoklu komutların kullanımı olarak ele aldık. Ancak şimdi biraz daha detaylı şekilde ele almamız gerekiyor.

### Ya da(veya) Operatörü ( || )

"**||**" operatörü kullanıldığında, yalnızca ilk komut başarısız olursa ikinci komut çalıştırılır. Eğer ilk komut başarılı olursa ikinci komut çalıştırılmaz.

**Hatırlatma;** komutun çıkış kodu(exit code) "**0**" değerini döndürüyorsa komut başarılı demektir. "**0**" hariç tüm değerler başarısızlık olarak kabuk edilir.

**İlk komut başarısız olursa;**
İlk komut başarısız olursa bir sonraki komut çalıştırılır. İşlem başarılı komut bulunana kadar bu şekilde devam eder.

```
root@taylan:~# asdf || echo "metin"
bash: asdf: komut yok
metin
root@taylan:~#

root@taylan:~# asdf || xyzt || echo "metin"
bash: asdf: komut yok
bash: xyzt: komut yok
metin
root@taylan:~#

```

**İlk komut başarılı olursa;**
İlk komut başarılı olursa ilk komuttan sonraki hiç bir komut çalıştırılmaz.

```
root@taylan:~# echo "deneme" || echo "metin"
deneme
root@taylan:~# 

    
root@taylan:~# asdf || echo "metin" || echo "test1"
bash: asdf: komut yok
metin
root@taylan:~# 

```

### Ve Operatörü ( && )

"**&&**" operatöründe işlemler, hatalı komut ile karşılaşıncaya kadar devam eder. Diğer bir deyişle, **&&** operatörü kullanıldığında soldaki komut başarılı olursa sağdaki komut çalıştırılır.

```
root@taylan:~# echo "komut" && asdf && echo "test" 
komut
bash: asdf: komut yok
root@taylan:~#

root@taylan:~# asdf && echo "test" 
bash: asdf: komut yok
root@taylan:~# 

```

### Bağımsız Operatör ( ; )

Önceki ya da sonraki komutun çıkış durumundan yani hatalı ya da hatasız olmasından bağımsız olarak, komutların hepsini peş peşe çalıştıran operatördür. Noktalı virgül karakteri ile temsil edilir. Benim deyimimle "**ne olursan ol gel**" operatörüdür :)

```
root@taylan:~# echo "test" ; echo "deneme"
test
deneme
root@taylan:~# echo "test" ; asdf
test
bash: asdf: komut yok
root@taylan:~# asdf ; asdf
bash: asdf: komut yok
bash: asdf: komut yok
root@taylan:~# asdf ; echo "test"
bash: asdf: komut yok
test
root@taylan:~# asdf ; asdf ; echo "test"
bash: asdf: komut yok
bash: asdf: komut yok
test
root@taylan:~#

```

Hatalı bir komut ile karşılaşıldığında betik dosyasının çalıştırılmasını durdurmak için en sık tercih edilen kullanım aşağıdaki şekildedir.

`komut || exit 1`

Bu kullanım, ilk komutun başarısız olması halinde betik dosyasının durdurulmasını sağlıyor. Aksi durumda yani ilk komut başarılıysa zaten ikinci komut olan çıkış komutu çalıştırılmadığı için betik dosyası çalıştırılmaya devam ediyor. Genellikle bu kullanıma, ilgili komutun hata vermesi halinde betik dosyasının çalışamaz hale geleceği durumlarda başvuruluyor. Yani bu kullanım, komutları tek tek kapsayacak şekilde çalışıyor. Ancak bizler bütün komutları kapsayacak bir durdurma operasyonu yürütmek isteyebiliriz. Yani betik dosyası içerisindeki herhangi bir komut hata verdiğinde, işlemin otomatik olarak sonlandırılmasını isteyebiliriz. Bu noktada yardımımıza "errexit" ortam özelliği yetişiyor.

## set -e | set -o errexit

Bu kullanım ile, betik dosyası içerisindeki herhangi bir komutta hata meydana geldiğinde betik dosyası otomatik olarak durduruluyor. Nasıl çalıştığını hemen basit bir örnek üzerinden test edelim.

Gördüğünüz gibi betik dosyasına eklemiş olduğumuz `set -e` ifadesi sayesinde herhangi bir komutta hata meydana geldiğinde betik dosyası otomatik olarak sonlandırılmış oldu.

Ancak bazı durumlarda, yazdığımız betikte yer alan birtakım komutların hatalı çıktılar üretmesini isteyebiliriz. Bu gibi durumlarda yapmış olduğumuz özellik atamasını kısmi olarak kaldırarak, dilediğimiz komutların hatalı çıktılar üretebilmesine olanak tanıma imkanımız da var. Ne demek istediğimi daha iyi anlamak adına aşağıdaki örneği dikkatlice inceleyin lütfen.

```
set -e
komut1
komut2
set +e
komut3
komut4
set -e
komut5
komut6
komut7
komut8
...
..

```

Yukarıdaki örnekte; **komut3** ve **komut4** `set +e` ifadesi sayesinde hata verseler dahi, çalışmayı durdurma özelliğinin dışında tutulmuş oldular.
İşte bu örnekte olduğu gibi `set` komutu ile atamış olduğumuz bash özelliklerini istediğimiz zaman kaldırıp tekrar ekleyebiliyoruz.

Ayrıca özelliği kaldırıp tekrar eklemek istemezseniz aşağıdaki kullanımı da tercih edebilirsiniz.

```
#!/bin/bash
set -e

asdf || true
echo bar

```

Bu kullanım ile `asdf` komutu hata verirse, ikinci komut olan `true` komutu çalışacak ve neticede işlemin sonucu başarılı olacağı için betik dosyası çalıştırılmaya devam edecek.

**Not:** Buradaki "**true**" ifadesi her zaman olumlu sonuçları temsil eder. Ayrıca ihtiyacınız olduğunda "**false**" ifadesi ile de olumsuz sonuçların temsilini sağlayabilirsiniz.

## set -o pipefail

Bir önceki kısımda ele aldığımız **set -e** yani komutların hata vermesi durumunda işlemin sonlandırılması işlevi **pipe( | )** kullanıldığında geçersiz kalabiliyor. Hatta en son örneğimizde `asdf || true` kullanımı ile "errexit" özelliğini atlatabildiğimizi de gördük.

**pipe** karakteri en basit tanımla; bir programın çıktısını başka bir programın girdisi olarak kullanmanızı sağlayan bir aktarıcıdır. Durum böyle olunca pipe işareti ile yapılan veri aktarmaların sonunda, yalnızca en son komut hata verirse komut hatalı sayılıyor.

```
#!/usr/bin/env bash
set -e

asdf | echo "metin"
echo "test"

```

Yukarıdaki örnekte `asdf` komutu hatalı sonuç döndürmesine karşın, işlem devam ederek "**metin**" ve "**test**" ifadelerini konsola basıyor. Bu durumun önüne geçmek için `pipefail` özelliğini atamamız gerekiyor.

```
#!/usr/bin/env bash
set -eo pipefail

asdf | echo "metin"
echo "test"

```

Bu kullanım ile gördüğünüz gibi `asdf` komutunun hata vermesinin ardından **pipe** karakteri yer almasına rağmen işlem otomatik sonlandırılıyor.

## Ara Özet

Bu kısıma kadar set komutu ile atayabileceğimiz en sık ve en temel kullanılan bash özelliklerinin işlevlerini öğrenmiş olduk. Genellikle pek çok betik dosyasında bu temel özellikler tanımlanmış olur.

En sık kullanım şekilleri aşağıdaki gibidir.

```
set -euxo pipefail

```

```
set -eux
set -o pipefail

```

Eğer bash özelliklerini betik dosyası içerisinde `set` komutu ile belirtmediyseniz, bu özelliklerin `bash` komutu üzerinden `bash -euxo pipefail script.sh` şeklinde aktifleştirilmesini de sağlayabilirsiniz. Bu kullanımda, `bash` komutu ile çalışacağımızı ortamı belirtiyor ve o ortamın hangi özellikle başlatılacağını da devamında belirtmiş oluyoruz. Yine de ortam özelliklerini betik dosyası içerisinde `set` komutu ile belirtmek çok daha mantıklı bir yöntem olacaktır. Bu sayede betik dosyasını çalıştıran hiç kimse ortam özelliklerini ayrıca belirtmeye ihtiyaç duymaz.

Şimdiye kadar ele aldığımız sık kullanılan özelliklerin dışında, ihtiyacınız olduğunda kullanabilmeniz için diğer özellikleri de ele alarak anlatıma devam edelim.

## set -o ignoreeof

Bu kullanım sayesinde çalışmakta olan kabuk ortamını **Ctrl + D** tuş kombinasyonu ile kapatılmaya karşı korumuş oluyoruz. Burada bahsi geçen **ignoreeof** kavramı "**ignore**" "**eof**" olarak ayrılıp incelendiğinde;

**ignore** = **reddetmekeof** = **end of the file** = **dosya sonu**

Yukarıdaki ifadelerini temsil ediyor. Peki ama bu "**dosya sonu(eof)**" denilen kavram da ne oluyor?

Aslında dosya sonu demek; "***bu ortamda işim bitti gireceğim tüm verileri girdim, işte burası da girişin sonu***" diyerek çalıştırılan ortamın artık veri girişlerine kapatılması demek. Konsolun **Ctrl + D** tuşlaması ile kapanmasının nedeni de konsola yeni veri girişi yapılmayacağının bu kısayol ile belirtiliyor olmasıdır.

Daha iyi anlamak adına `cat` komutu ile yeni bir dosya oluşturup bu dosya içerisine birtakım ifadeler ekleyelim.

Yazmak istediğimiz ifadeler bittiğinde yani artık `cat` komutuna veri girişi yapmayacağımızda, `cat` komutuna "***benim burada veri girişi işim bitti lütfen artık dosya sonu olduğunu kabul et ve dosyayı kaydederek cat komutu sürecini sonlandır***" demek için **Ctrl + D** tuş kombinasyonunu uygulamamız yeterli oluyor.
Neticede buradaki `cat` komutunun tek amacı bizim oluşturduğumuz dosya içerisine veri girişini sağlamak olduğu için, dosyaya yeni veri girişi yapmayacağımızı bildirdiğimizde `cat` komutunun yapacak bir görevi kalmadığından kapatılıyor. Benzer şekilde üzerinde çalışmakta olduğumuz bash kabuk ortamı da bizlerden komut girişi yani veri girişi beklediği için **Ctrl + D** tuş kombinasyonu, bash kabuğuna artık yeni veri girişi yapılmayacağını bildirip kapatılmasını sağlıyor.

**ignoreeof** ifadesi ise dosya sonunu belirten kısayolu ekarte etmemize olanak tanıyor. Örneğin **ignoreeof** değerini **3** olarak tanımlarsak, konsoldan yapacağımız 3 **Ctrl + D** tuşlaması da **ignoreeof** tarafından bertaraf edilecek.
Bu özelliği, kullanıcıdan veri girişi alıyorken kullanıcının dosyayı tek seferde **Ctrl + D** tuşlaması ile kapatmasına karşı önlem oluşturmak için kullanabilirsiniz.

## set -a | set -o allexport

Bu özellik atandıktan sonra, tanımlanan tüm değişkenler otomatik olarak export edilerek alt kabuklarda da işlenebilmesi sağlanır.

Bu durumu konsol üzerinden test etmek için öncelikle `set -o allexport` ya da daha kısa şekilde `set -a` komutunu girelim. Böylelikle bundan sonra konsola gireceğimiz tüm değişkenler otomatik olarak tüm alt kabuklara da aktarılmış olacak.

Mevcut kabuk üzerinde `test="değer"` şeklinde değişkenimi tanımlayıp konsola bastırıyorum.

Ardından bir alt kabuk oluşturmak üzere `bash` komutunu girip, alt kabuk üzerinden "**test**" isimli değişkenimi çağırıyorum.

Gördüğünüz gibi başlangıçta "**test**" değişkenimi `export` etmemiş olmama rağmen **allexport** özelliği sayesinde `bash` komutu ile oluşturduğum alt kabuktan da erişebildim. Üstelik bu durum çalıştığımız ortamın altında oluşturulacak tüm alt kabuklar için geçerli olan bir özelliktir. Bu durumu kendiniz de test edebilirsiniz.

## set -f | set -o noglob

Konsolun sık kullanılan bir özelliği olan **globbing** yani **joker karakter** kullanımlarını kapatmak istersek bu ayarı `set -o noglob` tanımı ile ya da doğrudan `set -f` komutu ile yapabiliriz.

Örneğin bulunduğum dizindeki başlangıcı "**dosya**" olan tüm dosyaları listelemek üzere `ls dosya*` komutunu girersem tüm "**dosya**" ifadesi ile başlayanlar listelenmiş olacak.

Ancak aynı işlemi `set -f` komutunun yani `globbing kapatma` işleminin ardından denersem, konsol bana böyle bir dosya bulunmuyor diye uyarı verecek.

Çünkü joker karakterini tanıma özelliğini kapattığımızda kabuk, girmiş olduğumuz `ls dosya*` ifadesindeki yıldız joker karakterini sadece dosyanın ismi olarak görüyor. Yani buradaki yıldız işaretinin artık kabuk için özel bir anlamı bulunmuyor.

## set -C | set -o noclobber

Mevcut dosyanın üzerine '**>**', '**>&**', '**<>**' gibi yönlendirme karakterleri ile yeni veri yazılmasını istemezsek, yeni veri yazımını engelleyebiliriz.

Kullanım amacını daha iyi anlamak adına çalışmakta olduğumuz ortamda bu özelliği tanımlayıp yönlendirme karakterleri ile mevcut dosyanın üzerine yeni veri yazmayı deneyelim.

```
root@taylan:~/Masaüstü# set -o noclobber
root@taylan:~/Masaüstü# cat > kritik-dosya
deneme
root@taylan:~/Masaüstü# cat > kritik-dosya
bash: deneme: mevcut dosyanın üzerine yazılamıyor
root@taylan:~/Masaüstü# 

```

Örnekte görebildiğiniz gibi "noclobber" özelliği sayesinde, çalıştığımız kabukta dosyanın üzerine yönlendirme karakteri ile yeni veri yazılamadı. Bu sayede dosyamızı ve dolayısı ile içerisindeki verileri üzerine yazılma işleminden koruyabildik.

## set -v | set -o verbose

Komutların çıktıları ile birlikte girilmiş olan komutun da konsola basılmasını sağlar. Daha önce ele aldığımız `set -x` kullanımına benzer şekilde çalışır fakat burada komutların ayırt edilmesi için başlarında artı işareti yoktur.

Aşağıdaki örneğe bakarak kullanım amacını kavrayabilirsiniz.

## set -t | set -o onecmd

Tek bir komutu okuduktan ve çalıştırdıktan sonra kabuğun kapatılmasını sağlar. Kısaca tanımlamak istersek "-t" argümanını kullanmanız yeterli. Betik dosyası içerisinde kullanacaksak tanımlamayı shebang üzerinden yapmamız gerekiyor. Bu sayede çalıştırılan bash ortamının özelliği tek komutun ardından kapanmak olarak değişmiş olacak. Eğer biz shebang kısmında değil de bash dosyasının içerisinde bu tanımlamayı yaparsak, bu ifadenin tanımlandığı kod satırı okunduğunda betik dosyası doğrudan kapatılır. Bu durumu gözlemlemek adına aşağıdaki iki örnek kullanıma göz atabilirsiniz.

```
#! /usr/bin/env bash -t
mkdir klasor1

```

Bu kullanımın ardından bulunduğum konumda "klasor1" isimli klasör oluştu.

```
#! /usr/bin/env
set -t
mkdir klasor2

```

Bu kullanımın ardından betik dosyası henüz klasör oluşturma aşamasına geçmeden kapatılmış oldu. İşte bu sebeple eğer bu ortam özelliğini kullanacaksak mutlaka shebang kısmında kullanmalıyız. Aksi halde betik dosyasının çalıştıracağı tek komut, bu ortam özelliğini atayıp betiği kapatan `set -t` komut bütünü olacaktır.

## set -H | set -o histexpand

Bu özellik konsol üzerinden çalıştırılan bash kabuğunda varsayılan olarak tanımlıdır ancak betik dosyasının çalıştırıldığı ortamda tanımlı değildir. History kayıtlarında yer alan komutları tekrar çağırabilmemize olanak tanır. Bu ayar belirtilmediyse komut geçmişinden komut çağırmamız mümkün olmaz. Daha iyi anlamak adına aşağıdaki örneğini inceleyebilirsiniz.

```
root@taylan:~# set -H
root@taylan:~# echo "deneme"
deneme
root@taylan:~# !!
echo "deneme"
deneme
root@taylan:~# set +H
root@taylan:~# !!
bash: !!: komut yok
root@taylan:~# 
root@taylan:~# 

```

## set -h | set -o hashall

Bu özelliği açıklamak için öncelikle `hash` komutunun çalışma yapısını kısaca ele almamız gerekiyor.

### hash Komutu

Konsol üzerinden girdiğimiz komutların **PATH** yolu üzerinde arandığını daha önceki deneyimlerimizden biliyoruz. `hash` komutu, her defasında konsola girilen komutların **PATH** yolu üzerinde aranmasını önlemek için vardır. `hash` komutu, konsola girilen komutların çalıştırılabilir dosyalarının konumunu önbelleğine kaydederek her defasında **PATH** yolunun sorgulanmasını önler.

Örnek olması için konsola birkaç farklı komut girip son olarak da `hash` komutunu çalıştıralım.

```
root@taylan:~# ls
root@taylan:~# whoami
root@taylan:~# date
root@taylan:~# hash
eşleşme komut
   1    /usr/bin/whoami
   1    /usr/bin/tput
   1    /usr/bin/date
   1    /usr/bin/ls
root@taylan:~# 

```

Gördüğünüz gibi `hash` komutu sayesinde, çalıştırmış olduğumuz komutların dosya konumları listelenmiş oldu. İşte bu şekilde konsoldan girilen komutların hepsi, kabuk kapatılana kadar `hash` komutunun önbelleğine alınarak tablo halinde saklanır.

Pek sık kullanılmıyor olsa da ben yine de gerektiğinde kullanabilmeniz için`hash` komutunun kullanım detaylarını ele almak istiyorum.

### Hedef Komut Konumunu Bellekten Silmek

Bu işlem için "**d**" parametresini, dosya konumu kayıt altına alınmış komutu da belirterek girmemiz gerekiyor.
Örnek kullanım için aşağıdaki çıktıları inceleyebilirsiniz.

root@taylan:~# hash
eşleşme komut
1 /usr/bin/which
1 /usr/bin/whoami
1 /usr/bin/tput
1 /usr/bin/date
1 /usr/bin/ls
root@taylan:~# hash -d ls
root@taylan:~# hash
eşleşme komut
1 /usr/bin/which
1 /usr/bin/whoami
1 /usr/bin/tput
1 /usr/bin/date
root@taylan:~#

### Tüm Komut Konumlarını Bellekten Silmek

Önbelleğe alınmış olan komutların dosya konumlarının hepsini tek seferde silmek için "**r**" parametresini kullanmamız yeterli.

```
root@taylan:~# hash 
eşleşme komut
   1    /usr/bin/which
   1    /usr/bin/whoami
   1    /usr/bin/tput
   0    /root/date
root@taylan:~# hash -r
root@taylan:~# hash
hash: çitleme tablosu boş
root@taylan:~# 

```

Gördüğünüz gibi silme işleminin ardından tabloyu bastırmak üzere `hash` komutunu girdiğimizde tablonun boş olduğu bilgisi basılıyor. Bu da demek oluyor ki tüm kayıtlı konumlar tek seferde "**r**" parametresi ile silinmiş oldu.

### Çıktıları Düzenli Halde Bastırmak

Bilgileri başka bir program için giriş olarak kullanılabilecek bir biçimde görüntülenmesi yani bir nevi daha okunaklı olması için "**l**" parametresini kullanabiliriz. Bu kullanımda hem çalıştırılan komut hem de komutun dosya konumu yer alır.

Normal `hash` komutu ile `hash -l` komutunun çıktılarını kıyaslayarak aralarındaki farkı gözlemleyebilirsiniz.

### Seçilen Komut Konumlarının Bastırılması

Yalnızca bizim belirttiğimiz komutların dosya konumları bastırılsın istersek "**t**" parametresini bastırılmasını istediğimiz bir veya birden fazla komutları tek tek belirtmemiz gerekiyor.

```
root@taylan:~# hash -t date
/usr/bin/date
root@taylan:~# hash -t date whoami
date    /usr/bin/date
whoami  /usr/bin/whoami
root@taylan:~# 

```

### Komut Dosya Yolunun Belirtilmesi

Herhangi bir komutun çalıştırılabilir dosya yolunu belirtmek için "**p**" parametresini kullanabiliyoruz. Kullanım şeklini görmek için aşağıdaki örneğe göz atın lütfen.

```
root@taylan:~# hash
eşleşme komut
   1    /usr/bin/which
   1    /usr/bin/whoami
   1    /usr/bin/tput
   1    /usr/bin/date
root@taylan:~# hash -p /root/Desktop/tarih.sh tarih
root@taylan:~# hash
eşleşme komut
   1    /usr/bin/which
   1    /usr/bin/whoami
   1    /usr/bin/tput
   0    /root/Desktop/tarih.sh
root@taylan:~# tarih
root@taylan:~# Prş Tem 16 18:45:55 +03 2020

```

Örneğimizdeki kullanımda **[tarih.sh](http://tarih.sh/)** dosyasının doğrudan `tarih`komutu ile çalıştırılabilmesini sağlamış oluyoruz. Daha önce bu işlemi çalıştırılacak dosyayı path yoluna ekleyerek başarmıştık hatırlarsanız. İşte hash komutu da mevcut kabuk üzerinde bizlere bu kolaylığı sağlıyor.

### PATH Konumunun `hash` Üzerinden Öğrenilmesi

Herhangi bir komutu çalıştırmadan, komutun çalıştırılabilir dosyasının PATH yolu üzerinde hangi konumda yer aldığını öğrenmek istersek `hash` komutunun ardından konum bilgisini öğrenmek istediğimiz komutu girmemiz yeterli.

```
root@taylan:~# hash who
root@taylan:~# hash
eşleşme komut
   1    /usr/bin/man
   0    /usr/bin/who
   2    /usr/bin/whoami
   4    /usr/bin/date
   1    /usr/bin/ls
root@taylan:~# 

```

Bu kullanım ile, ilgili komutun çalıştırılmasına gerek kalmadan **PATH** yolu üzerindeki konum bilgisi elde edilebiliyor. Bu kullanım `which` komutuna benzemekle birlikte `which` komutundan farklı olarak; ilgili komut konumunu önbelleğine alarak komut kullanılırken **PATH** yolu üzerinde tekrar aranmasına gerek kalmıyor.

Ayrıca `hash` komutu ile ilgili öğrenmemiz gereken son bilgi; aldığımız çıktıların solunda yer alan rakamların, ilgili komutun kaç kez konsola girildiğini belirtiyor olmasıdır.
Bireysel kullanımda `hash` yapısının performans açısından çok gerekli olmadığını düşünebilirsiniz. Ancak özellikle komut tekrarının çok olduğu büyük çaplı projelerde `hash` yapısı oldukça verimli sonuçlar ortaya koyabiliyor.

Şimdi esas konumuza dönecek olursak; **hashall** özelliği, `hash` komutunun özelliğinin konsol üzerinde geçerli olup olmayacağının belirlenmesini sağlıyor.

Bu özellik bash kabuğunda varsayılan olarak tanımlıdır. Yani genel çalışma verimliliği için kullanılması varsayılan olarak tavsiye edilir. Ancak yazmak istediğiniz programın amacı doğrultusunda yani betik dosyanızın yapısı gereği sürekli **PATH** üzerinde araştırma yapılması ya da daha spesifik bir konfigürasyon gerekiyorsa bu özelliği devredışı bırakabilirsiniz.

Devredışı bırakmak için iki farklı yolu da izleyebilirsiniz;

```
set +o hashall
set +h

```

## set -m | set -o monitor

İş kontrolünün yapılabilmesini sağlar. Kısaca "**m**" parametresi ile de belirtilebilir.

İş kontrolünden kasıt; süreçlerin durdurulması(**Ctrl+Z**), arkaplana(`bg`) alınması, önplana(`fg`) alınması ve süreçlerin durumlarının listelenmesi(`jobs`) gibi fonksiyonlardır.

Daha iyi anlamak adına yeni bir süreç başlatıp bu süreci durdurduktan sonra arkaplana alalım ve son olarak da sürecin durumunu `jobs` komutu ile kontrol edelim.

Gördüğünüz gibi tüm işlemler sorunsuzca yerine getirildi. Bunun nedeni "**m**" yani "**monitor**" özelliğinin bash üzerinde varsayılan olarak tanımlı olmasıdır. Şimdi bu ayarın hangi işlevde olduğunu daha iyi anlamak adına tüm işlemleri "**monitor**" özelliği olmadan tekrar deneyelim.

Gördüğünüz gibi "**monitor**" özelliği olmadığı zaman, iş kontrolü için gereken yapıları kullanamıyoruz.

## set -b | set -o notify

Arkaplandaki süreç sonlandırıldığı anda konsola bu durumu çıktı olarak basar. Kısaca "**b**" parametresi ile de belirtilebilir.

Normalde arkaplandaki süreç sonlandırdıktan sonra konsola bir kez daha herhangi bir veri girişi yaptığımızda, girdiğimiz veri sonucu ile birlikte arkaplandaki uygulamanın da kapatıldığı bilgisi basılır. Eğer biz konsola herhangi bir veri girişi yapmazsak konsol asla kapatılan sürecin kapatılma durumunu konsolda çıktı olarak basmaz. İşte **notify** ayarı ise arkaplandaki herhangi bir süreç kapanır kapanmaz konsoldan herhangi bir veri girişi beklemeksizin bu durumu çıktı olarak basarak bizi haberdar eder. Kullanımı daha iyi anlamak adına basit bir örnek üzerinden gidelim.

`xterm` aracını çalıştırıp bu süreci arkaplana atıyorum, ve daha sonra arkaplandaki `xterm` sürecini sonlandırıyorum. Bu işlemin ardından gördüğünüz gibi konsola herhangi bir çıktı basılmadı.

Çıktı basılması için **enter** tuşuna basarak bir alt satıra geçme işlevini konsola veri girişi olarak veriyorum.
Böylelikle arkaplandaki kapatılmış olan sürecinin kapatılma bilgisi konsola basılıyor.

Aynı işlemi **notify** ayarını tanımladıktan sonra denediğimizde ise; arkaplandaki süreç kapatılır kapatılmaz, konsola çıktı olarak bu durum bilgisi basılıyor.

## set -B | set -o braceexpand

Genişletme ayracı olarak da tasvir edilen, belirttiğimiz aralığa göre çıktı üretilebilmesine olanak tanıyan kıvırcık parantez özelliğinin çalışmasını sağlar. Kısaca "**B**" parametresi ile de belirtilebilir ve bash kabuğunda varsayılan olarak tanımlıdır.

Aşağıdaki basit örneğe bakarak bu özelliğin işlevini kavrayabilirsiniz.

```
root@taylan:~# touch dosya{1..10}
root@taylan:~# ls
abc.com   dirsearch  dosya2  dosya5  dosya8     Genel     Resimler   Videolar
aquatone  dosya1     dosya3  dosya6  dosya9     Masaüstü  sub.sh
Belgeler  dosya10    dosya4  dosya7  Downloads  Müzik     Şablonlar
root@taylan:~# set +B
root@taylan:~# rm dosya{1..10}
rm: 'dosya{1..10}' silinemedi: Böyle bir dosya ya da dizin yok
root@taylan:~# 

```

## set -o

Bu kullanım ile mevcut kabuk üzerine tanımlı olan ayarlar ve bu ayarların hangilerinin aktif hangilerinin kapalı durumda olduğunu listeleyebiliyoruz. Ayrıca yanına yazacağımız uzun seçenek isimleri ile de yeni ortam özellikleri atayabileceğimizi zaten biliyorsunuz.

## set -o emacs

Aslında emacs, uzun süredir sıklıkla kullanılan çok fonksiyonlu bir metin editörünü ifade ediyor. Konsol ayarlarında yer alan "emacs" ifadesi ise bu editörden gelen bir takım özelliklerin kullanılabilmesine olanak tanıyor. emacs özelliği konsol üzerinden çalıştırılan kabuk üzerinde varsayılan olarak tanımlıdır ancak betik dosyasının içerisinde özellikle tanımlamamız gerekiyor.

İşlevini daha iyi anlamak adına öncelikle varsayılan olarak tanımlı olan bu özelliği mevcut kabuk ayarlarından kaldıralım.

Bu ayarı kaldırdıktan sonra konsol üzerinde yukarı aşağı tuşlarını kullanarak önceki ve sonraki komutlara geçmeyi ya da tab tuşu ile yazdığımız komutun otomatik tamamlanmasını deneyebiliriz.

Denemelerin ardından bu işlevlerin geçersiz kaldığını görmüş oluyoruz. Ayrıca emacs özelliğinden gelen kısayollar hakkında daha fazla detay almak isterseniz kısa bir araştırma yapmanız yeterli. Aslında günlük olarak sıklıkla kullandığımız pek çok kısayol emacs özelliğinden geliyor. Eğer betik dosyasını çalıştıran kullanıcıdan veri alacaksanız bu özelliği aktifleştirerek, kullanıcının konsol üzerinden veri girmesini kolaylaştırmış olursunuz.

## set -E | set -o errtrace

Bu konu çıkış kodlarındaki trap işlevi ile bağlantılı henüz bir açıklama getirmedim.

BURAYI DÜZENLE !!

## set -T | set -o functrace

Daha önce bahsetmiş olduğumuz "xtrace" özelliği kullanılarak hata ayıklama yapılırken, fonksiyon yapıları görmezden gelinerek hata ayıklamaya dahil edilmezler. Bunu önlemek için fonksiyonlara özel olan hata ayıklama özelliğini aktifleştirmemiz gerek.

Henüz fonksiyon yapılarını öğrenmedik ancak yine de aşağıdaki basit örneğe bakarak "functrace" özelliğinin işlevini kolaylıklara kavrayabilirsiniz.

Ben örnek olması açısında hatalı şekilde fonksiyon tanımlaması yapıyorum. Tanımlamanın ardından "functrace" özelliği kapalıyken ve bu özellik açıkken betik dosyamı çalıştırıyorum.

Çıktıları kıyaslayarak da kolaylıkla görebileceğiniz gibi "functrace" özelliğinin kapalı olduğu durumda hata ayıklama özelliği olan "xtrace" özelliği açık olsa dahi fonksiyon tanımlama hatalarını görmezden geliyor. Bu sebeple betik geliştirme aşamasında mutlaka betik dosyanızı "functrace" özelliği açıkken de çalıştırıp hata ayıklaması yapın. Zaten geliştirme aşaması hariç bu özelliğin betik dosyasında bulunması gerekmez. Bu özelliği testler sırasında kullanmanız çok daha mantıklıdır.

## set -n | set -o noexec

Bu özellik kullanıldığında betik dosyası içerisindeki komutlar kabuk tarafından okunur ancak çalıştırılmaz.

Bu sayede, sözdizimi hatası geri bildirimlerini komutları yürütmeden alırsınız. Betik dosyası ile sistem üzerinde kritik etkiye sahip bir işlem yapıyorsanız, tüm sözdizimi hataları düzeltilene kadar komut dosyasını çalıştırmak istemeyebilirsiniz.

Özellikle geliştirme aşamasında aracın stabil şekilde çalışması için test gerçekleştirme adına bu ortam özelliğini kullanmak çok makul bir çözüm olabilir. Örneğin çalıştırılacak betik dosyası mevcut bir sistem üzerinde kritik sonuçlara sebep olabilecek bir betik dosyası ise bu dosyanın tam olarak doğru şekilde çalışıp çalışmayacağını henüz komutlar yürütülmeden önce test etme imkanımız var.

Test etmek için [hata.sh](http://hata.sh/) isimli betik dosyası oluşturup içerisine aşağıdaki ifadeyi ekliyorum.

```
set -n #noexec fonksiyonu
echo "Deneme metni'

```

`echo` komutunun devamında yer alan ifade, fark edebileceğiniz gibi çift tırnak ile açıp tek tırnak ile kapatılmış yani söz dizim hatası bulunuyor. Bu hatayı aktifleştirmiş olduğumuz "noexec" özelliği sayesinde henüz komutlar yürütülmeden yani çalıştırılmadan fark etme imkanına sahip oluyoruz.

```
./hata.sh satır 3: ' için eşleşme aranırken beklenmedik dosya sonu
./hata.sh satır 6: ' sözdizimi hatası: beklenmeyen dosya sonu

```

Ancak burada önemli olan detay bu seçeneğin yalnızca sözdizim kuralları yani sentaks(syntax) kurallarına göre değerlendirme yapıyor olmasıdır. Örneğin biz `echo` komutunu "**ehco**" şeklinde yani hatalı yazdığımızda bu bir sentaks hatası sayılmaz.

```
set -n #noexec fonksiyonu
ehco "Deneme metni"

```

Bu betik dosyası çalıştırıldığında konsola herhangi bir çıktı basılmaz. Çünkü buradaki durum sadece kullanmak istediğimiz `echo` aracının isminin yanlış yazılmasıdır. Buradaki kullanımda bash, **ehco** komutunu path yolu üzerinde arar ve bulamayınca bu komutun yani bu aracın sistem üzerinde yüklü bulunmadığını belirtir. Yani araç isminin hatalı yazılması bash dilinin sentaks kurallarına aykırı değildir. Bu sentaks kuralları daha önce de bahsettiğimiz şekilde betiğin yapısını yani çalışmasını tamamen etkileyebilecek söz dizim hatalarıdır. Elbette "noexec" özelliğinin de tıpkı daha önce bahsetmiş olduğumuz hata ayıklama özellikleri gibi istisnai durumlar hariç yalnızca betik yazma yani araç oluşturma sırasında hataların tespiti için kullanılması gerektiğini tahmin edebiliyorsunuzdur.

## interactive-comments

Bu özellik aslında varsayılan olarak aktif olan bir özelliktir. Ve ileride tekrar ele alacağımız yorum satırları olarak geçen özelliğin kullanılmasını sağlar. Yorum satırları, betik dosyası içerisindeki komutları hangi amaçla yazdığımızı komutların yanına belirtebileceğimiz alanlardır. Önüne # kare işaretini koyup yazdığımız her ifade, bash tarafından yorum satırı olarak algılanır ve bu ifadeler komut olarak görülmez. Bizler bu ifadeler sayesinde yazmış olduğumuz betik dosyasının içerisinde açıklama ifadeleri ekleyebiliriz.

Basit bir örnek vermem gerekirse;

```
echo "deneme metni" # buradaki echo komutu ile "deneme metni" ifadesini konsola bastırıyoruz

```

Yukarıdaki kullanım sayesinde betik dosyam çalıştırıldığında yalnızca `echo "deneme metni"`komutu yürütülecektir. Ancak ben bu dosyanın içeriğini açık okuduğumda komutun yanındaki açıklamayı yani yorum satırını görebiliyor olacağım. İşte bu özellik aslında varsayılan olarak aktif olan bir özelliktir. Ancak biz kare işaretinin bash tarafından yorum satırı olarak algılanmasını istemezsek interactive-comments özelliğini kapatabiliriz. Bu özelliği kapattığımızda yorum satırları da bash tarafından yürütülmeye çalışılacaktır. Aşağıdaki örneğe bakarak bu durumu rahatlıkla gözlemleyebilirsiniz.

Peki ama etkileşimli kabuk nedir? diyecek olursanız; daha net anlaşılması adına hazır yeri gelmişken diğer kabuk türlerini de ele alarak açıklayalım.
Kabuklar, çalıştıkları modlara göre birkaç farklı şekilde ifade edilebiliyor.

- Login Shell - Giriş Kabuğu
- Unlogin - Giriş Yapılmamış Kabuk
- Interactive Shell - Etkileşimli kabuk
- Non-Interactive Shell - Etkileşimsiz kabuk

### Login Shell - Giriş Kabuğu

Kullanıcı hesabına giriş yapmak için kullanılan kabuktur. Biz bu kabuk üzerinden hesabımızda oturum açabiliyoruz. Örneğin ssh istemcisi ile uzak masaüstüne bağlandığımızda aslında giriş kabuğu(login shell) kullanmış oluyoruz. Bunun dışında elbette sisteme giriş yapmak üzere komut satırı arayüzünü kullanırken(geçiş için <kbd>Ctrl + Alt + F1</kbd> ya da <kbd>Ctrl + Alt + F2</kbd>,**F3**..**F4**..**F5** kısayollarını kullanabilirsiniz) de aslında giriş kabuğu üzerinde çalışmış oluyoruz. Mevcut kabuğun giriş kabuğu olup olmadığını anlamak için giriş yaptıktan sonra(kabuk üzerinde oturum açtıktan sonra) kabuğa `echo $0` komutunu girebiliriz. Eğer komutun çıktısı "**bash**" şeklinde ise çalışmakta olduğunuz kabuk giriş kabuğudur.
Giriş kabukları başlangıçta **~/.bash_profile**, **~/.bash_login**, ve **~/.profile** dosyalarını okuyarak ortam için gerekli olan konfigürasyonlarını bu dosyalara göre yapılandırırlar. Yani giriş kabuğu üzerinde etkili olacak ayarlama yapmak isterseniz, değişikliği bu dosyalardan birinin içerisinde belirttiğinizden emin olun.

Not: Giriş yapmak için grafiksel arayüzü kullandığınızda aslında pencere ve oturum yöneticileri ile çalışmış oluyorsunuz. Yani grafiksel arayüz kullanarak sistem üzerinde oturum açarken giriş kabuğunu kullanıyor olmazsınız.

### Unlogin/Giriş Yapılmamış Kabuk

Giriş kabuğunda oturum açmış olan kullanıcı yeni bir işlem için alt kabuk oluşturduğunda bu kabuğa verilen isimdir. Kullanıcı zaten oturum açtığı için mevcut kullanıcı oturumu altında oluşturulan tüm alt kabuklar bu kategoride sayılırlar. Bu kabuk türü de gerekli ortamı oluşturmak adına öncelikle **/etc/bash.bashrc** dosyasını ve daha sonra her bir kullanıcıya özgü olan ve ana dizinde bulunan **.bashrc** dosyasını okur. Yani gerektiğinde bu kabuk türünü etkileyecek konfigürasyon değişiklikleri ihtiyacınıza göre ilgili dosyaya ekleyebilirsiniz. Sistem genelinde tüm kullanıcılar için **/etc/bash.bashrc**, sadece tek bir kullanıcı içinse kullanıcı ev dizininde yer alan **.bashrc** dosyasını değişikleri geçerli kılmak için kullanabilirsiniz.

### Interactive Shell/Etkileşimli kabuk

Kabuk, kullanıcı ile etkileşim imkanı sunan herhangi bir terminal aracına bağlandığında bu kabuğa etkileşimli kabuk denir. Örneğin grafiksel arayüzü kullanarak çalıştırdığınız bir terminal aracı etkileşimli kabuğa sahiptir. Terminal aracı, bize yani kullanıcıya kabuk ile etkileşime geçme imkanı sağlayan aracı bir katmandır sadece. Çalışmakta olduğunuz ortamın etkileşimli kabuk olup olmadığını anlamak için `echo $-` komutunu girmeniz yeterli. Çıktılarda "i" ifadesi yer alıyorsa bu ifade "**i**nteractive" ifadesinin kısaltmasını yani "etkileşimli" kabuk ortamında çalıştığınızı belirtir.

### Non-Interactive Shell/Etkileşimsiz kabuk

Herhangi bir terminal aracı ile başlatılmamış olan yani kullanıcı ile etkileşimde bulunmasına gerek olmayan kabuğa verilen genel isimdir. Örneğin sistem üzerinde bu betik dosyasının otomatik olarak çalışması için zamanlama(crontab) ayarı yaptıysak, bu betik dosyası terminal aracına ve elbette kullanıcı etkileşimine ihtiyaç duymadan arkaplanda çalışacaktır. İşte bu kabuğa etkileşimsiz kabuk deniyor.

Hemen test etmek üzere `echo $- > sonuc.txt` komutunu bir betik dosyasının içerisine yazıp betik dosyamızı çalıştıralım. Buradaki komut sayesinde betik dosyasının çalıştırıldığı ortamın bilgisi sonuc.txt dosyasına kaydediliyor olacak. Betik dosyası konsol arayüzüne ihtiyaç duymadan çalıştığı için sonuc.txt dosyasına baktığımızda sadece "hB" ifadesinin yer aldığını görüyoruz. Yani etkileşimli kabuk olduğunu belirten "i" ifadesi çıktıda basılmamış. Bu durum da betik dosyasının çalıştırıldığı kabuğun etkileşimsiz kabuk olduğunu kanıtlıyor.

**Not:** Betik dosyaları çalıştırılırken etkileşimli olmayan kabuk üzerinde çalıştırılır ancak kullanıcıdan veri alınmasının gerekli olduğu durumlarda etkileşimli kabuk taklit edilebilir. Yani eğer betik dosyası kullanıcıdan veri girişi alması gerekiyorsa çalıştırıldığı ortam etkileşimsiz olsa da kullanıcı ile etkileşime geçebilir.

## set -o posix

Bash kabuğu üzerinde POSIX standartlarının geçerli olmasını sağlıyor. Normalde bash kabuğu POSIX uyumlu kabuk olan sh üzerinden geliştirilmiş olmasına rağmen POSIX standartlarına tamamıyla uyumlu yapıda değildir. Ancak ihtiyaç duyduğumuzda bash ayarlarının birtakım istisnalar hariç POSIX standartlarına uygun davranmasını diğer bir deyişle, sh kabuğunun yaptıklarına daha yakın davranmasını sağlayabiliriz.

Örneğin bash kabuğunu posix ayarı ile başlattığımızda, fonksiyon isimleri; harfler, rakamlar ve alt çizgiler dışında karakterler içeremezler veya bir rakamla başlayamazlar.
Bu durumu test etmek için hem normal hem de posix modu aktifken "3.fonksiyon" isimli fonksiyonun çalışıp çalışmadığını görelim.

Posix modu aktif değilken tanımlamayı deneyelim.

```
1fonksiyon(){ echo "fonksiyon çalıştı"; }
1fonksiyon
1fonksiyon çalıştı

```

Aynı örneği bu kez posix özelliğini aktifleştirip deneyelim.

```
set -o posix
2fonksiyon(){ echo "fonksiyon çalıştı"; }
bash '2fonksiyon': geçerli bir belirteç değil
2fonksiyon
bash: 2fonksiyon: komut yok

```

Çıktıları kıyasladığınızda rahatlıkla görebileceğiniz gibi posix standartlarında fonksiyonlar rakam ile başlayamıyor.

Yukarıdaki basit örnekte ele aldığımız gibi diğer standartların da neler olduğunu merak ediyorsanız [buradan](https://www.gnu.org/software/bash/manual/html_node/Bash-POSIX-Mode.html) madde madde bash kabuğunda posix modundayken nelerin değiştiğini görebilirsiniz. Zaten bu özelliğe ihtiyaç duyma ihtimaliniz standart işlemler için oldukça düşük olduğundan pek sık işiniz düşmeyecektir. Yine de bağlantıda yer alan maddelere göz atmanız, daha sonra ihtiyaç duyduğunuzda özelliğe daha kolay ulaşmanıza yardımcı olabilir.

## set -k | set -o keyword

root@taylan:~# bash -c 'echo "$1 $VARIABLE"' bash hello VARIABLE=value
hello
root@taylan:~# set -k
root@taylan:~# bash -c 'echo "$1 $VARIABLE"' bash hello VARIABLE=value
hello value

```
/bin/bash -c 'mkdir "$1"; cd "$1"; touch "$2"' bash dir file

```

## set -P | set -o physical

Sembolik link yerine fiziksel bağlantıyı kullanıyor.

## set -p | set -o privileged

Ayrıcalık modunu temsil ediyor.

## set -o vi

Vi editörü özelliklerinin konsol üzerinde geçeli olmasını sağlıyor. Bu özellik daha önce ele aldığımız emacs özelliğine benzer şekilde çalışıyor.
Vi tarzı bir çizgi düzenleme arayüzü kullanın. Bu ayrıca read-e için kullanılan düzenleme arabirimini de etkiler.

Aşağıdaki rehberden devam et !!
[https://ss64.com/bash/set.html](https://ss64.com/bash/set.html)[https://www.computerhope.com/unix/uset.htm](https://www.computerhope.com/unix/uset.htm)

`bash` scriptleri yazmak ustalık ve dikkat isteyebilir. [Shellcheck](https://github.com/koalaman/shellcheck) gibi araçlar sh/bash scriptlerinizdeki hataları bulmanıza yardımcı olabilirler