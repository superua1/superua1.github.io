# 15- Yönlendirmeler

[https://veriteknik.gitbook.io/linux-yonetimi/standart-girdi-ve-cikti/standart-hata-ve-file-descriptor](https://veriteknik.gitbook.io/linux-yonetimi/standart-girdi-ve-cikti/standart-hata-ve-file-descriptor)

[https://catonmat.net/bash-one-liners-explained-part-three](https://catonmat.net/bash-one-liners-explained-part-three)

## 15 Yönlendirmeler

Hepimizin bildiği üzere; konsola girmiş olduğumuz komutlar kabuk tarafından yorumlanarak konsola, yapılan işlemin olumlu ya da olumsuz sonuçlarını basar. İşte bu kısımda da konsol ile iletişimimizi sağlayan bu temel yapılardan ve gerektiğinde bu çıktıları nasıl yönlendirebileceğimizden bahsedeceğiz. Etkili şekilde kullanabilmek için öncelikle bu yapının temelde nasıl işlediğine değinelim.

Unix sistemlerinde her şey aslında bir dosyadır sözünü mutlaka duymuşsunuzdur. Unix sisteminin çalışma yapısından ilham alınarak geliştirilmiş olan GNU/Linux sistemleri için de aynı durum geçerlidir. Linux’ta aygıtlar (klavye, fare, ekran, yazıcı, vb), TCP/UDP soketler, prosesler, prosesler arası iletişim kurmaya yarayan pipe adı verilen mekanizmalar, vb bütün sistem bileşenleri ya birer dosyadır, ya dosya sistemi (file system) üzerinde dosya gibi görünür ya da bunlara olan erişim bir dosyaya erişimle benzer şekilde tasarlandığı için dosyalar üzerinde yapılan işlemler bu bileşenler üzerinde de yapılabilir. Linux’ta yönetilen bütün kaynaklar bu üç kategoriden birine girdiği için "Linux’ta her şey bir dosyadır" denir.

Her şeyin dosya olmasının en temel nedeni tüm yapıların kolayca denetlenip yönetilebilmesidir. Her şey dosya olduğu için dosyaları okumak, üzerine veri yazmak ve tüm veri akışını farklı dosyalara yönlendirmek de son derece kolaylaşmış olur. Teorik olarak tüm sistem üzerindeki araçları birbirine bağlayarak çalıştırmamız ve yönetmemiz bu yapı ile mümkün olur. Burada bahsi geçen dosyalar arasında veri akışını sağladığımız yapıya "yönlendirme/redirection" deniyor. Yönlendirme işleminde ise çıktıların veya girdilerin hangi dosyaya yönlendirileceğini tam sayılar üzerinden belirtmemizi sağlayan "file descriptor" olarak geçen "dosya tanımlayıcı" yapısı kullanılıyor. Açıklama şu an için yetersiz gelebilir ancak merak etmeyin uygulamalar üzerinden tüm bu bahsettiklerimizi pekiştirmiş olacağız. 

Unix felsefesininde tek bir işi yapıp o işi en iyi şekilde yapmak en temel yaklaşımdır.

Ayrıca geliştirilen araçların interaktif yani kullanıcıdan veri almaya zorlamadan çalışması 

Gerektiğinde girdileri okuyup çıktılarını aktarabiliyor olması

**gibi temel yaklaşımlar vardır. bu yakalaşımlar sayesinde tüm araçlar teorik olarak birbirine bağlanarak çalıştırılabilir. temel görevleri en iyi şekilde yapan pek çok araç ile çok yönlü işler verimli yoldan halledilmiş olur. bu yaklaşım araçların kullanımını kombinasyonlu şekilde sağladığı için yapılabilecek işlerin sayısını da arttırmış oluyor. Tıpkı saatin içindeki dişliler gibi pek çok dişli bir araya gelip ideal sonuca ulaşmamızı sağlıyor.**

Konsola komut girdiğimizde aslında kabuğumuza emir verdiğimizi biliyoruz. Bash kabuğu varsayılan olarak konsoldan gelen emirleri okuyup, sonuçlarını yine konsola çıktı olarak aktarıyor. Bu sayede etkileşimli yani interaktif şekilde bash kabuğunu konsol aracımız üzerinden kullanabiliyoruz. Burada kullandığımız kabuk programı ve konsol aracı da aslında sistem tarafından bir dosya olarak ele alınıyor. Ve neticede iki dosya arasında veri akışı sağlanarak iki aracın birbirine bağlı şekilde çalışması sağlanmış oluyor.

Varsayılan olarak bash kabuğunu konsol üzerinden kullanırken, bash kabuğu girdileri yani emirleri sistem üzerinde konsolun dosya karşılığı olan /dev/tty1(mevcut terminalinizin /dev/tty1 olduğunu varsayıyoruz) dosyasından okur. Bash kabuğunun ürettiği hatalı ve hatasız çıktılar da yine /dev/tty1 dosyasına yönlendirilir. Bu sayede konsol üzerinden bash kabuğuna emirler verip sonuçlarını yine konsol üzerinden görüntüleyebiliyoruz. Tüm bu işlem sırasında, aralarında veri aktarımı yapılacak dosyaların hangi dosyaya aktarım yapacağını "dosya tanımlayıcısı" yapısı söylemektedir. Bash kabuğu varsayılan olarak 3 tür dosya tanımlayıcısı ile başlatılır. Bunlar; 

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled.png)

Çekirdekte her proses için ayrı bir dosya tanımlayıcı tablosu tutuluyor. 

## Standart Girdi: Stdin (0)

Girdiler İngilizce olarak "**standart input**" olarak ifade ediliyor. Standart input ifadesinin anlamı Türkçe olarak "**standart girdiler**" olmakla birlikte genellikle kısaltması olan "**stdin**" ifadesi kullanıyor. Girdilerin yönlendirme işlemlerinde tanımlanmış olan temsili değeri **0** rakamıdır. 

## Standart Çıktı: Stdout (1)

Komutların yani araçların çalıştırılması sonucunda, üretilen hatasız çıktılara "**standart output**" yani "**standart çıktı**" deniyor. Standart çıktılar kısaca "**stdout**" olarak ifade ediliyor. Yönlendirme işlemlerinde **1** rakamı ile temsil ediliyor.

## Standart Hata: Stderr (2)

Standart çıktılardan farklı olarak, bu çıktılar yalnızca hata bildirisinde bulunurlar. Girmiş olduğumuz komutlar neticesinde gerçekleşen hataları, "**standart error**" yani "**standart hata**" adı altında çıktı olarak alabiliriz. Standart hata ifadesi kısaca "**stderr**" olarak geçmektedir. Yönlendirme işlemlerinde **2** rakamı ile temsil edilir.

Bahsetmiş olduğumuz bu üç dosya tanımlayıcısı konsol üzerinden bash kabuğunu kullanırken yani etkileşimli kullanımda varsayılan olarak konsol aracımızı işaret eden dosyaya bağlıdırlar. Terminalinizin /dev/tty0 olduğunu varsayarsak, bash başladığında dosya tanımlayıcı tablosu şöyle görünür:

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%201.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%201.png)

Bash 0 numaralı dosya tanımlayıcısının işaret ettiği /dev/tty1 dosyasını okur ve hatalı hatasız sonuçları yine 1 ve 2 numaralı dosya tanımlayıcısının işaret ettiği şekilde /dev/tty1 dosyasına aktarır.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%202.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%202.png)

[https://effective-shell.com/docs/part-2-core-skills/7-thinking-in-pipelines/](https://effective-shell.com/docs/part-2-core-skills/7-thinking-in-pipelines/)

Eğer istersek dosya tanımlayıcılarının verileri okumak ya da yazmak üzere işaret ettiği dosyaları da ihtiyaçlarımıza göre değiştirmemiz mümkündür. Yani normalde bash kabuğu konsolun dosya karşılığı olan /dev/tty1 dosyasından emirler alıp yine bu dosyaya çıktı gönderiyorken, biz bu dosya yerine istediğimiz dosyadan emir alınmasını ya da çıktıların istediğimiz başka bir dosyaya gönderilmesini sağlayabiliriz.  Dosya tanımlayıcılara istediğimiz dosyaları atamak üzere yönlendirme operatörü olarak geçen büyüktür ve küçük işaretlerini kullanıyoruz. Anlatıma sırasıyla çıktıların aktarılması ile başlayıp devamında girdilerin nasıl alınacağına değinerek devam ediyor olacağız.

# 15.1 Çıktıların Yönlendirilmesi

Eğer herhangi bir komutun çıktısını başka bir dosyaya ya da komuta yönlendirmek istersek büyüktür işaretini kullanabiliyoruz. 

- **Tek büyüktür işareti** kendinden önceki tüm verileri silip üzerine yenilerini yazar.
- **Çift büyüktür işareti** ise var olan verileri koruyarak, verilerin sonuna ekleme yapar.

## 15.1.1 Hatasız Çıktıların Yönlendirilmesi

Konsoldan aldığımız **hatasız çıktıları** yönlendirmek istediğimizde yapmamız gereken hatasız çıktıları temsil eden **1** rakamını, yönlendirme operatörü olan büyüktür işareti ile birlikte kullanmaktır.

Bu kısımda, konsola girilmiş olan bir komutun neticesinde üretilen hatalı ve hatasız çıktıları nasıl yönlendirebileceğimizi ele alacağız. Ancak tek bir komut ile hem hatalı hem de hatasız çıktılar elde etmek her zaman mümkün olmayabiliyor. Bu yüzden hatalı ve hatasız çıktılarımızı tek bir komut neticesinde üretmek üzere kendi hazırladığımız betiği `alias` ile yeni bir komuta tanımlayarak kullanacağız.

Hem hatalı hem de hatasız çıktılar üreten betiğimiz.

```
echo "Sorunsuz bir çıktı"
asdf 
whoami
ls -
echo "Sorunsuz başka bir çıktı daha"

```

Bu betiği `alias komut="bash betik.sh"` komutu ile "**komut**" isimli yeni bir komut olarak atamış oluyoruz.
Ve artık hem hatalı hem de hatasız çıktılar üreten tek bir komutumuz olmuş oldu.

Eğer bu çıktılardan **yalnızca hatasız** olanları bir dosyaya yönlendirmek istersek, komutumuzun sonuna `1> dosya.txt` ifadesini eklememiz yeterli oluyor.

```
komut 1> hatasız.txt
```

Gördüğünüz gibi konsola yalnızca hatalı çıktılar basılırken, hatasız çıktılar bizim yönlendirmemiz ile "**hatasız.txt**" dosyasına kaydedilmiş oldu.

Aslında burada belirtmiş olduğumuz **1** rakamını yazmadan, yalnızca **>** operatörü kullanılarak da hatasız çıktılar dosyaya aktarılabiliyor.

Bunun nedeni > yönlendirme operatörünün varsayılan olarak 1 numaralı dosya tanımlayıcısını temsil ediyor olmasıdır. Biz özellikle farklı bir rakam belirtmedikçe yönlendirme operatörünün alacağı değer **1** rakamıdır. Yani daha önceleri de büyüktür işaretini kullanarak komut çıktılarını dosyalara yönlendirirken, aslında **sadece hatasız çıktıları** yönlendirmiş oluyorduk. Hemen söylediklerimizi teyit edelim.

```bash
komut > hatasız.txt
```

Bu işlem sırasında; bash bizim işaret ettiğimiz şekilde hatasız.txt doyasını açıyor(Eğer ilgili dosya mevcut değilse öncelikle dosyayı oluşturur.) ve hatasız çıktıyı yani stdout çıktısını /dev/tty0 dosyası yerine hatasız.txt dosyasına yönlendiriyor. Bu sayede tüm hatasız çıktılar otomatik olarak hatasız.txt dosyasına yazılıyor.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%203.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%203.png)

## 15.1.2 Hatalı Çıktıların Yönlendirilmesi

Şimdi de yalnızca hatalı çıktıları bir dosyaya aktaralım. Hatalı çıktıların varsayılan olarak 2 numaralı dosya tanımlayıcısı ile ifade edildiğini biliyoruz. 

```
komut 2> hata.txt
```

Çıktılarda gördüğünüz gibi hatalı çıktıları bir dosyaya yönlendirdikten sonra, konsola yalnızca hatasız çıktılar basılmış oluyor.

Bu kullanım ile yani 2 rakamı ile hatalı çıktıların(stderr) dosya tanımlayıcı adresi /dev/tty0 yerine hata.txt dosyası olarak değişmiş oluyor.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%204.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%204.png)

Ayrıca yeri gelmişken belirtelim, tek büyüktür işareti kullandığımızda verilerin yazılacağı dosya içeriğindeki tüm veriler silinip yeni veriler yazılır. Yani tek büyüktür işareti tüm verileri hedefteki dosyanın üzerine yazar. Eğer eski içeriği koruyup yeni verileri eklemek istersek çift büyüktür işareti kullanmamız gerekiyor.

```
komut 1>> hatasiz.txt
komut 2>> hata.txt

```

Tüm bunlara ek olarak elbette hatalı ve hatasız çıktıları tek seferde iki ayrı dosyaya da yönlendirebiliyoruz. 

```
komut > hatasiz.txt 2> hata.txt  #Mevcut dosyaların üzerine yazar.
komut >> hatasiz.txt 2>> hata.txt #Dosya içeriğinin sonuna ekleme yapar.
```

## 15.1.3 Hatalı ve Hatasız Çıktıların Birlikte Yönlendirilmesi

Eğer hem hatalı hem de hatasız çıktıları tek bir dosyaya yönlendirmek istersek, **ampersant**(**&**) işaretini kullanabiliyoruz. Aşağıdaki iki kullanımda geçerlidir ancak ilk kullanım daha sık tercih edilir.

```
komut &> hatalı-hatasız.txt
komut >& hatalı-hatasız.txt
```

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%205.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%205.png)

Ayrıca bu kullanımın dışında alternatif olarak aşağıdaki şekilde çıktıların yönlendirilebilmesi de mümkündür.

```
komut > sonuc.txt 2>&1
komut 2> sonuc.txt 1>&2
```

Bu kullanımda, **ampersant**(**&**) işareti yol gösterici olarak çalışıyor. Bash kabuğunda birden fazla yönlendirme olduğunda solda sağa doğru yönlendirmeleri uygular. Bu bağlamda yukarıdaki örneklerimizde gerçekleşen olayları açıklayalım.

İlk kullanımda yani tek büyüktür işareti ile öncelikle hatasız çıktıları sonuc.txt dosyamıza yönlendirdik.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%206.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%206.png)

Hatasız çıktıların yönlendirileceği dosya konumunu belirttikten sonra, hatalı çıktıların da hatasız çıktıların istikametindeki dosya adresine yönlendirilmesini 2>&1 kullanımı ile söylemiş olduk. Yani 2 numaralı dosya tanımlayıcısına 1 numaralı dosya tanımlayıcısının **mevcut adresini kopyala** demiş olduk.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%207.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%207.png)

Bu sayede 1 numaralı dosya tanımlayıcına verilmiş olan dosya adresi 2 numaralı dosya tanımlayıcısı için de aynı olarak, hem hatalı hem de hatasız çıktılar aynı dosyaya yönlendirilmiş oldu.

İkinci kullanım örneğimizde ise bu durumun sıralaması ters olacak şekilde kullanmış olduk. Yani öncelikle hatalı çıktıları dosyaya yönlendirip, hatasız çıktıların da hatalı çıktıların yöneldiği adresi kopyalayarak bu adrese yönelmesi gerektiğini belirttik. Burada kullanmış olduğumuz **ampersant**(**&**)  işaretine dikkat etmemiz gerekiyor. Bu işaret dosya tanımlayıcıların işaret ettiği adreslere, dosya tanımlayıcı numaralı üzerinden ulaşabilmemizi sağlıyor. 

Okurken biraz karmaşık gelmiş olabilir ancak örneklere ve yapılan açıklamaya biraz daha dikkat ederseniz ne demek istediğimi çok rahat kavrayabilirsiniz.

Hatta netleşmesi adına yanlış kullanım örneği ile işleyişine adım adım bakalım. Örneğin hatalı ve hatasız çıktıları aynı dosyaya yönlendirmek istediğimizde aşağıdaki kullanım yanlış bir yöntemdir. 

```bash
komut 2>&1 > dosya.txt
```

Bash kabuğu soldan sağa doğru yönlendirmeyi uygulamaya çalışır. Henüz hiç bir yönlendirme yapmadan önce varsayılan olarak dosya tanımlayıcı adresleri aşağıdaki şekildedir.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%208.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%208.png)

`2>&1` ifadesine geldiğine hatalı çıktıları hatasız çıktıların işaret ettiği adrese yönlendirilmesini sağlıyor. Elbette bu adres daha önce özellikle değiştirilmediği için varsayılan olarak /dev/tty adresidir. 

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%209.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%209.png)

Son olarak `>` operatörünü gördüğünde hatasız çıktıları "dosya.txt" dosyasına yönlendiriyor. Böylece yönlendirme adresi aşağıdaki görünüme kavuşuyor.

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%2010.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%2010.png)

Bu durumda da açıkça görülebildiği gibi yanlış yönlendirme dolayısıyla hata çıktıları /dev/tty0 yani konsola yönlendirirken, hatasız çıktılar dosya.txt dosyasına yönlendiriliyor. Bu yanlış kullanıma bakarak yönlendirme işleminin bash üzerinde nasıl çalıştığını net bir biçimde kavrayabilirsiniz.

### 15.1.4 Bash Üzerinde Yönlendirme İşleminin Çalışma Yapısı

Bash bir komutu çalıştırdığında, tüm dosya tanımlayıcılarını ana süreçten devralan bir çocuk süreci  çatallar, daha sonra belirttiğiniz yönlendirmeleri soldan sağa doğru okuyup ayarlar ve komutu çalıştırır. Eğer yönlendirme hatalı yapıldıysa tüm komut başarısız olur. Komut çalıştırılmadan önce yönlendirme işlemine bakılır bu sayede eğer yönlendirilme hatalı ise boşuna komut çalıştırılarak kaynak israfı yapılmamış olur. Bu durum hızlı açılıp kapanabilen araçlar için çok önemli olmasa da, açılması uzun süren ve fazla kaynak tüketen uygulamalar eğer yönlendirme yanlışsa boşuna çalıştırılmamış olur. Bu sayede zamandan ve sistem kaynaklarından tasarruf edilmiş olur.

Yönlendirme işleminin öncelikle yapıldığının kanıtı olarak ayrıca aşağıdaki üç kullanımın da aynı olmasını gösterebiliriz.

```
$ cat DENEME > test.txt
$ cat > test.txt DENEME
$ > test.txt cat DENEME
```

Neticede komut çalıştırılmadan önce çıktıların nereye yönlendirileceğine bakıldığı için yönlendirmenin hangi sıralamada yapıldığının önemi kalmıyor.

Bu açıklamayı en başta yapmamış olma nedenim, yönlendirme işleminin pratikte nasıl çalıştığını gördüğünüzde teorik olan işleyiş yapısını daha net kavrayacağınızı düşünmemdir.

## 15.1.5 Çıktıların Yok Edilmesi

Çıktıların hepsini boşluğa göndermek yani konsola veya herhangi bir dosyaya çıktı bastırmadan çıktıları yok etmek istersek, **/dev/null** adresine yönlendirmemiz yeterli. Burada bahsi geçen /dev/null dosyası Linux sistemindeki her şey bir dosyadır felsefesine uygun olarak, boşluğu temsil eden özel bir dosyadır. İlgilenmediğimiz çıktıları bu dosyaya yönlendirerek kurtulabiliriz. 

```
komut &> /dev/null
```

Aynı şekilde yalnızca hata çıktılarını ya da hatasız çıktıları da boşluğa gönderebiliyoruz.

```
komut 1> /dev/null
komut 2> /dev/null
```

Çıktıların boşluğa gittiğiniz teyit etmek için **/dev/null** dosyasını açıp okumayı deneyebilirsiniz. 

## 15.1.6 Yazma Korumalı Dosyalara Yönlendirme İşlemi

Önemli dosyaların üzerine hatalı veri girişi yapılmasını önlemek adına `noclobber` özelliğinin kullanıldığında bahsetmiştik. Eğer hatırlamıyorsanız argümanlar başlığı altındaki ortam özellikleri bölümüne tekrar bakabilirsiniz. Bu kısımda, üzerinde yazma koruması bulunan bu tür dosyalara çıktılarımızı nasıl yönlendirebileceğimizi ele alacağız.

Öncelikle "**yazılamaz.txt**" isimli dosyaya **noclobber** korumasını atayalım.

```
touch yazılamaz.txt
set -o noclobber yazılmaz.txt
```

Yazma korumalı dosyamız oluştuğuna göre şimdi de üzerine yazma işlemi için yönlendirme operatörü ile birlikte **pipe** (**|**) işaretini kullanalım.

```
komut >| yazılamaz.txt
```

Bu kullanım ile hatasız çıktıları yazma korumalı "**yazılamaz.txt**" dosyasına yazdırmayı başardık.

Aynı şekilde hatalı çıktıları yazdırmak için de `2>|` operatörünü kullanmamız yeterli oluyor.

Ancak burada dikkat etmeniz gereken, hem hatalı hem hatasız çıktıları yazma korumalı dosyalara yazdırırken `&>|` kullanımının geçersiz olmasıdır. Bunun yerine hatalı ve hatasız çıktıları aynı anda yönlendirmeye yarayan ikinci kullanım şeklini tercih etmeniz gerekiyor.

```
komut >| yazılamaz.txt 2>&1
komut 2>| yazılamaz.txt 1>&2

```

Peki ama **noclobber** yazma koruması olan dosyaların üzerine veri yazabiliyorsak bu korumanın anlamı nedir ?

Aslında burada yapılan işlem bilinçli olarak dosyanın üzerine yazma işlemi olduğundan teknik olarak bir sorun bulunmuyor. **noclobber** kullanımındaki temel amaç bilinçsizce veri girişini engellemek. Burada **pipe** işaretini kullanarak bu işin bilincinde olduğumuzu, herhangi bir dikkatsizliğin bulunmadığını kabuğa bildirmiş oluyoruz. 

## 15.1.7 Tüm Komut Çıktılarının Yönlendirilmesi

Bu bölüme kadar tek bir komutun ürettiği hatalı ve hatasız çıktıları nasıl yönlendirebileceğimiz üzerinde durduk. Şimdi de konsoldan üretilen tüm çıktıların tek elden yönlendirilmesini ele alalım.

**Örneğin;** Yazmış olduğum bir betik dosyası içerisinde yer alan tüm komutların hatalı ya da hatasız olan çıktılarının özellikle tek bir dosya üzerinde toparlanmasını istersem `exec` komutu ile kalıcı hedef gösterme yapmam gerekiyor.

Yazmış olduğum betik dosyasının içerisine;

- Hatasız çıktıları yönlendirmek üzere; `exec > hatasızlar.txt`
- Hatalı çıktıları yönlendirmek üzere; `exec 2> hatalılar.txt`
- Hem hatalı hem de hatasızları yönlendirmek üzere; `exec &> tum-cıktılar.txt`

Komutlardan herhangi birini ihtiyacıma göre kullanabilirim.

Bu şekilde betik dosyam çalıştırıldığında, betik dosyasının içerisinde yer alan komutların ürettiği tüm çıktılar otomatik olarak ilgili dosyaya yönlendirilmiş oluyor. Yani betik dosyasını çalıştıran kişiden harici olarak bir yönlendirme yapmasını beklemiyor.

Daha iyi anlamak adına basit bir örnek yapalım. Örneğin kullanıcıdan konsola komut girmesini isteyelim ve girdiği komutların hatasız çıktılarını "**hatasızlar.txt**" isimli bir dosyaya yönlendirelim. Neticede kullanıcı konsola potansiyel olarak sınırsız sayıda komut girebileceğin bu işi otomatize etmemiz gerekiyor. Girilen komut her ne olursa olsun hatasız çıktılar oluşturduğunda, "**hatasızlar.txt**" dosyasına yazılması için `exec >> hatasızlar.txt` komutunu kullanalım.

Basit bir `while` döngüsü kuralım ve kullanıcı "**q**" çıkma komutunu girene kadar kullanıcıdan komut istemeye devam edelim.

```
#! /bin/bash
exec >> hatasızlar.txt

while [ "$komut" != "q" ] 
        do
                read -p "Komut girin:" komut
                echo -e "\\e[32mGirdiğiniz komut:\\e[22m" $komut  "\\n-----------------"
                echo -e "\\e[31mKomutun Çıktıları:\\e[0m " $($komut)
        done

```

Bu kullanım ile kullanıcı konsola ne kadar komut girerse girsin, hatasız çıktıları hepsi otomatik olarak "**hatasızlar.txt**" dosyasına kayıt oluyor olacak.

Böylelikle `exec` komutu yardımıyla istediğimiz sonucu elde edebildik. Peki ama `exec` komutu tam olarak hangi işlevde, yani `exec` komutunun çalışma yapısı nasıl ? Şimdi de buna bir göz atalım.

## exec Komutu

`exec` komutu **bash yerini alıyor** ve tıpkı bizlerin bash'e komut girdiği gibi komut alıp komutları yürütebiliyor. Bu tam olarak ne demek oluyor ?

Bizler terminalden komut girerken aslında terminal aracına atanmış olan bash kabuğu üzerinde çalışıyoruz. Terminal aracı sadece bash yani sistemin kabuğu ile bizim etkileşimli olarak iletişim kurmamızı sağlıyor. Yani aslında bizim yazdığımı tüm komutlar, terminale atanmış olan bu kabuk sürecine aktarılarak işlem görüyor.

Eğitim başlarında da bu durumlardan bahsettik. Hatırlarsanız betik dosyası çalıştırıldığında mevcut kabuğun altında bir kabuk başlatılarak, betik dosyasının bu alt kabuk üzerinden yürütüldüğünü söylemiştik. Yani betik dosyası içerisinde yer alan tüm komutlar aslında oluşturulan bir alt kabukta çalıştırılıyor.

İşte `exec` komutu da, çalışmakta olduğu **bash süreci ile yer değiştirerek** tıpkı bash gibi davranıp komutların yürütülmesini sağlıyor.

Daha iyi anlamak adına tüm hatasız çıktıları yönlendirdiğimiz örneği tekrar ele alalım.

1- Betik dosyamızı konsol üzerinden çalıştırdık.

2- Konsol, betik dosyasını çalıştırmak için bir alt bash oluşturdu ve bu alt kabuğu betik dosyasına tanımladı.

3- Betik dosyasına tanımlanmış olan alt bash kabuğu, betik dosyasının içeriğini okumaya başladı.

4- Betik dosyası için atanan bu alt bash kabuğu `exec` komutuna gelince kendi görevini `exec` komutuna devretti. Bu devretme işleminde herhangi bir yeni alt kabuk oluşturulmadı, sadece görev devri yapıldı.

5- Görevi devralan `exec`, betik dosyası üzerindeki tüm komutları çalıştırmaya ve komutlar hakkında bilgi sahibi olmaya başladı. Artık betik dosyası içerisindeki tüm komutlara tek bir `exec` komutu hakimdi ve biz de `exec` komutunda aldığımız verileri tek elden işleyebilir hale geldik.

6- Neticede yazmış olduğumuz betik dosyası içerisinde hangi komut çalıştırılırsa çalıştırılsın `exec` üzerinden çalıştırıldığı için, `exec` komutu ile hatasız çıktıların hepsini tek elden ilgili dosyaya yönlendirebiliyoruz.

Eğer `exec` komutu kullanılmazsa, bu yönlendirmeler betik dosyası başlatılırken `bash betik.sh 2> hatalı-yönlendirme.txt` şeklinde kullanıcı tarafından özellikle belirtilmek zorunda. Çünkü bizim amacımız tüm komutların hatasız çıktılarını tek bir dosyaya yönlendirmek ve tüm komutlar yalnızca **bash** kabuğu üzerinden takip edilebiliyor. Ancak bash süreci betik dosyası açılırken başlatıldığı için, bash sürecine betik dosyası içerisinden müdahale edemiyoruz. Bash sürecine ancak başlatılması esnasında müdahale edebiliriz. İşte `exec` komutu da betik dosyası içerisinden, bash sürecine müdahale imkanı tanıyor.

Ayrıca `exec` komutunu neden betiğin en başında kullandık diyecek olursanız, betik okuma düzeninin yukarıdan aşağıya ve soldan sağa doğru olduğunu hatırlamanız gerekir. Betik yukarıdan aşağıda okunacağı için, üretilen tüm çıktıların betik çalıştırılır çalıştırılmaz hatasızlar dosyasına gideceğini konsola ilk satırlarda bildirmemiz gerekir. İlk satırda bash kabuğunun görevini `exec` komutuna devretmeliyiz ki, sonraki satırdaki komutlar `exec` tarafından çalıştırılsın ve çıktıları da `exec` tarafından yönlendirilebilsin.
Eğer tüm adımları dikkatli bir biçimde takip ettiyseniz `exec` komutunun, yönlendirme örneğimizde ne kadar kritik role sahip olduğunu ve tam olarak hangi işlevde olduğunu anlamışsınızdır

# 15.2. Veri Giriş Yönlendirmesi

Çıktıları yönlendirmeyi ele aldık. Şimdi de girdileri nasıl yönlendirebileceğimizi ele alalım. Veri girişinin hangi şekilde yapıldığına göre kullanmamız gereken yönlendirme operatörü de değişiklik gösteriyor. Şimdi sırasıyla bu operatörlerimizi tanıyalım.

## 15.2.1. Dosyaların Veri Girişi İçin Kullanılması

Dosyadan veri yönlendirmesi yapmak için tek bir küçüktür işareti kullanıyoruz.

```bash
komut < dosya_adı
```

Bunu yaptıktan sonra dosya tanımlayıcı tablosu şu şekilde görünür:

![../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%2011.png](../Bash%20Kabuk%20Programlaman%C4%B1n%20Temelleri%2031ab19453cf04f0a8b585a8cac6ed4d9/15-%20Yo%CC%88nlendirmeler%201d64c100ad9d4f4a8f7b1083d679d7e8/Untitled%2011.png)

Olası kafa karışıklığını önlemek adına kısaca tabloyu da açıklayabiliriz. Gösterimdeki 0 dosya tanımlayıcısı okunun ters olması gerektiğini düşünmüş olabilirsiniz. Ancak burada 0 dosya tanımlayıcısı varsayılan olarak tanımlandığı üzere "okuma" işlevindedir. Kendisine işaret edilen dosyayı okuyacağı dosya olarak kabul eder. Bu sebeple gösterimdeki okun yönü doğrudur.

Hatta bu durumu yani 0 dosya tanımlayıcısının yalnızca okuma yaptığını aşağıdaki çıktıları inceleyerek teyit edebilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "Veri gönderiyorum.." 0> metin.txt
Veri gönderiyorum..
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat metin.txt
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ echo "Veri gönderiyorum.." 1> metin.txt
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat metin.txt
Veri gönderiyorum..
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

0 dosya tanımlayıcısını veri çıkışı operatörü olan büyüktür işaretini kullanarak bir dosyaya yönlendirmeyi denediğimizde başarısız oluyoruz. Çünkü **0** dosya tanımlayıcısı **yalnızca okuma** yani **veri girişi alma** amacıyla tanımlanmıştır.

Bir örnek daha yapalım ve dosyada yer alan standart ifadelerin değişmesini sağlayalım.

Dosya içerisinde geçen tüm "**Ad:**" ifadelerini "**İsim**" ifadesi ile değiştirelim. Ve bu işlemi "**isimler**" dosyasından **veri çekme operatörü** olan **küçüktür karakteri** ile yapalım.

```
sed 's|Ad:|İsim:|' < isimler 

```

Gördüğünüz gibi verileri küçüktür işareti sayesinde isimler dosyasından çekebildik.

Bu operatörün kullanımında dikkat edilmesi gereken, bütün komutların bu yönlendirme operatörünün kullanımı için uygun olmadığıdır. Yani dosyalardan herhangi bir veriyi çekmek istediğinizde işlemin başarılı olabilmesi için kullanmış olduğunuz komutun operatörden gelecek veriyi kabul edecek yapıda olması gerekir.

Örneğin `cat` komutu veri çekme operatörünü tanıyorken, `echo` komutu bu operatörü tanımaz.

Çünkü echo komutu yalnızca kendisine argüman olarak verilmiş olan karakteri işleyip konsola bastırır. Yani stdin olarak geçen dosya tanımlayıcısını okumaz ancak stdout ve stderr dosya tanımlayıcılarına veri gönderir.

Bu durumun nedeni, her bir komutun tanımlandığı görev dahilinde hareket edebilen fonksiyonel programlar olmasıdır. Yani komutların sınırsız özellikleri ya da sezgisel tepkileri yoktur. Bu yüzden veri girişini bu şekilde küçüktür işareti ile yapmak istediğinizde kullanmış olduğunuz komutun bunu desteklediğinden emin olmanız gerekiyor.

## 15.2.2. Satırların Veri Girişi İçin Kullanılması

Eğer dosyadan veri okunması yerine yazacağımız bir grup ifadelerin aktarılmasını istersek çift küçüktür işareti kullanıyoruz. Ancak bu kullanımda dikkat edilmesi gereken nokta, biz sınırları belirtmediğimiz sürece konsolun sonsuza kadar bizden veri girişi bekleyecek olmasıdır. Bu sebeple gireceğimiz verilerin en başında ve en sonunda aynı sınırlayıcı ifadeyi kullanarak veri girişinin kapsamını belirtmeliyiz.

```bash
cat <<EOF 
> Ben ilk satıra yazılanlarım
> ben ikinci satırım
> bu böyle uzar gider..
EOF
```

Burada kullanmış olduğumuz "EOF" ifadesi "end of file" yani dosya sonu anlamına geliyor ve bizim girdiğimiz ifadenin kapsamını belirtmemizi sağlıyor. Bu ifade yalnızca yazacaklarımızın son bulduğunu ifade etmemizi yani kapsam belirtmemizi sağlıyor. EOF yerine herhangi bir ifade de kullanabiliriz ancak geliştiricilerin ortak olarak sınırları belirtmek için kullandığı ifade EOF kısaltmasıdır. Yine de aşağıdaki örnekte olduğu gibi istediğimiz bir sınırlayıcı belirtmemiz mümkün.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat <<SINIR
> ben ilk satırım
> bende ikinci
> ve ben son
> SINIR
ben ilk satırım
bende ikinci
ve ben son
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Benzer şekilde bizlerden sonsuzca kadar veri girişi bekleyecek programları sonlandırmak istediğimizde de bu sonu Ctrl + D kısayolu ile belirtebiliyoruz. Bu kısayolu kullandığımızda "delimiter" yani "sınırlayıcı" mekanizması devreye girip programa, "tamam yazacaklarım bu kadardı artık veri girişi almayı kesebilirsin" demiş oluyor. En basit örneğini yine `cat` komutunu konsol üzerinden çalıştırarak teyit edebilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat
Ben ilk satır
Ben ilk satır
Ben ikinci
Ben ikinci
Ben ise son..
Ben ise son.. #Ctrl + D kısayoluna basarak veri girişini sonlandırdım.
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

## 15.2.3. Tek Bir Satırın Veri Girişi İçin Kullanılması

Eğer herhangi bir komuta yalnızca tek bir satırla veri yönlendirmesi yapmak istersek üç küçüktür işaretini kullanabiliriz. Bu kullanım ardından gelen ifadenin string yani yazı dizisi olduğunu belirtir.

```bash
komut <<< tek_satırda_ileteceklerimiz
```

Örneğin `cat` komutunu etkileşimli olarak kullanmadan tek seferde çıktı elde etmek için bu yönlendirmeyi kullanabiliriz. Normalde `cat` komutu argüman olarak dosya ismi bekler. Dosya içeriğini okumak ya da dosya içerisine veri yazmak üzere `cat` komutunu kullanabiliriz. Eğer dosya yerine doğrudan metin içeriğini vermek istersek bu yönlendirmeyi kullanabiliriz. Aşağıdaki çıktıları inceleyerek kullanım amacını kavrayabilirsiniz.

```bash
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat metni-yazdır
cat: metni-yazdır: No such file or directory
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ cat <<< metni-yazdır
metni-yazdır
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$
```

Aslında burada gerçekleşen işlem bizim üç küçüktür işaretinden sonra girmiş olduğumuz metin dizesinin geçici bir dosya oluşturulup o dosya üzerinden 0 dosya tanımlayıcısına yani giriş olarak komuta iletilmesidir. Bu durumu gözlemlemek adına aşağıdaki komutun çıktılarını inceleyebilirsiniz.

```bash
└─$ ls -la /proc/self/fd/ <<< "DENEME"
total 0
dr-x------ 2 taylan taylan 0 Dec 28 18:19 .
dr-xr-xr-x 7 taylan taylan 0 Dec 28 18:19 ..
lr-x------ 1 taylan taylan 0 Dec 28 18:19 0 -> 'pipe:[20]'
lrwx------ 1 taylan taylan 0 Dec 28 18:19 1 -> /dev/tty1
lrwx------ 1 taylan taylan 0 Dec 28 18:19 2 -> /dev/tty1
lr-x------ 1 taylan taylan 0 Dec 28 18:19 3 -> /proc/21/fd
```

Çıktılarda gözüken pipe tanımı "DENEME" ifadesinin geçici olarak bu pipe üzerinden aktarıldığını belirtiyor. Kimi sistemlerde geçici dosya için /tmp dizini altında geçici bir dosya oluşturulur.

[https://askubuntu.com/questions/172982/what-is-the-difference-between-redirection-and-pipe](https://askubuntu.com/questions/172982/what-is-the-difference-between-redirection-and-pipe)

# 15.3 Özel Dosya Tanımlayıcısı Açmak

Şimdiye kadar standart olan 0 1 ve 2 numaralı dosya tanımlayıcılarını kullandık. İhtiyaç olması halinde bunlar dışında dosya tanımlayıcıları açıp kullanmamız da mümkündür. Yeni bir dosya tanımlayıcısı oluşturmak, dosya adreslerinin numaralar üzerinden ifade edilmesini sağlar. 

## 15.3.1 Özel Dosya Tanımlayıcısı ile Yazılacak Dosya Konumu Belirtmek

Örnek olması için 3 numaralı yeni bir dosya tanımlayıcısı belirtelim. Bunun için yine exec komutunu kullanacağız. 

```bash
└─$ exec 3> dosya.txt
```

Böylelikle girdi olarak belirtmiş olduğumuz "dosya.txt", 3 numaralı dosya tanımlayıcısının yönlendirildiği dosya olmuş oldu. Burada yer alan exec komutu mevcut bash ortamı standart olarak üç dosya tanımlayıcısı(0 1 2) ile başladığı için yeni tanımladığımız dosya tanımlayıcısıyla birlikte mevcut ortamı tekrar başlatır.

Örneğin standart çıktıların 3 numaralı dosya tanımlayıcısına aktarılmasını sağlarsak dosya.txt dosya içerisine veri yazılmış olacak.

```bash
└─$ echo "deneme" >&3
└─$ cat girdi.txt
deneme
└─$
```

### 15.3.2 Özel Dosya Tanımlayıcısı Açarak Okunacak Dosya Konumu Belirtmek

Yeni bir dosya tanımlayıcısı oluşturup, veri girişi olarak kullanılacak dosya adresi belirtmemiz de mümkündür. Örneğin ben giriş.txt isimli bir dosya oluşturuyorum ve bu dosya için 7 numaralı dosya tanımlayıcısını açıyorum.

```bash
└─$ exec 7< giriş.txt
```

Bu sayede artık veri girişi alan tüm araçlara "giriş.txt" dosyasındaki verileri 7 numaralı dosya tanımlayıcısı üzerinden aktarabiliyor olacağım.

Örneğin giriş.txt dosyası içerisinde "Merhaba" ifadesi buluyor. Ben cat komutuna `cat <&7` komutunu verdiğimde **giriş.txt** dosya içeriği `cat` komutuna girdi olarak gönderilecektir.

```bash
└─$ cat <&7
Merhaba
```

Bu kullanımda dikkat etmeniz gereken detay, yönlendirmede yer alan dosya içeriğinin bir kez okunduktan sonra tekrar okunmadığıdır. Bu durumu teyit etmek için tekrar aynı komutu girebiliriz.

```bash
└─$ cat <&7
```

Görebildiğiniz gibi hiç bir çıktı almadık çünkü `cat` komutu ilk kullandığımızda yönlendirmede yer alan ***giriş.txt*** dosyasını bastırmak için sonuna kadar okudu. Dosya tanımlayıcılarının yapısı gereği; biz özellikle kapatana ya da kabuk sonlandırılana kadar açık kalacağı için dosya tamamen okunmuş durumda bekletilir. Dosya tamamen okunduğu için de ikinci kullanımda `cat` komutu dosyanın sonuna bakıp hiç bir veri olmadığından çıktı basamadı. Eğer dosyanın sonuna veri eklemesi yaparsak bu sefer yalnızca en son eklediğimiz verilere ulaşabiliriz.

```bash
└─$ cat >>&7
ben yeni eklemeyim
ben en yenisiyim..
└─$ cat <&7
ben yeni eklemeyim
ben en yenisiyim..
```

Görebildiğiniz gibi yalnızca dosyanın en sonuna eklenen yani veriler okunabildi çünkü dosya daha önce bu kısıma kadar okunmamıştı. Ama artık yeni eklenen kısıma kadar da okunduğu için bu ifadelere tekrar aynı şekilde ulaşamayız.

```bash
└─$ cat <&7
```

Bu noktada konsoldan girilen komutların /dev/tty dosyasından okunduğunu düşününce kafanız karışmış olabilir. Ancak buradaki farklılığın asıl sebebi /dev/tty dosyasının sanal bir dosya olup bizim tanımladığımız giriş.txt dosyasının diskte yer alan gerçek bir dosya olmasıdır. Konsolu temsil eden /dev/tty dosyası kullanıcının klavyesini sürekli olarak dinleyen sanal bir dosyadır. Yani aslında bu dosyanın içerisine veri kayıt olmaz, geçici olarak ram de tutulur ve gerektiğinde hedef alıcısına aktarılır. Böylece /dev/tty dosya içeriği hiç tükenmez çünkü sürekli klavyeden gelen girdileri aktarır. Hatta bu durumu teyit etmek için cat komutu ile /dev/tty dosyasını okumayı deneyebilirsiniz. Dosyayı ilk açtığınızda içeriği boştur ancak siz veri girdikçe çıktılarını yine size yansıtır.  Dosyayı kapatıp tekrar okuduğunuzda ise hiç bir verinin kayıt olmadığını teyit edebilirsiniz. 

```bash
└─$ cat /dev/tty
deneme
deneme
metni yazıyorum..
metni yazıyorum..
└─$ cat /dev/tty
```

Bizim oluşturduğumuz gerçek dosya(örneğimizdeki giriş.txt dosyası) ise içerisindeki verileri diske kaydedip diskten okunmasını sağladığı için içeriği tek okumada tüketiliyor. Eğer ilgili dosya tekrar baştan itibaren okunsun istersek, dosya tanımlayıcıyı yeniden açmamız gerekir. Yeniden açma için dosya tanımlayıcı açma işlemini tekrar etmemiz gerekiyor.

```bash
└─$ exec 5< input.txt
└─$ cat <&5
File contents
└─$ cat <&5
└─$ exec 5< input.txt
└─$ cat <&5
File contents
└─$
```

Eğer yeniden tanımlamak yerine kapatmak istersek de eksi adresine yönlendirilerek kapatabiliriz. Yani bizim örneğimiz için aşağıdaki komutu girmemiz yeterli.

```bash
exec 7>&-
```

### 15.3.3 Hem Yazmak Hem De Okumak için Dosya Belirtmek

Hem okuma hem de yazma işlemi için küçüktür ve büyüktür işaretlerini birlikte kullanabiliyoruz. Görünüşü itibari ile elmas operatörü olarak da ifade edilebiliyor.

```
$ exec 8<>kaynak.txt
```

Bu kullanım şekli bir önceki kısımda değinmiş olduğumuz dosyanın sonuna gidip beklenilmesi durumunu çok net açıklayabilir. Dosya tanımlayıcıları açık olan dosyaların en son hangi kısmını okuduğunu ya da yazdığını kapatılana kadar kayıt altında tutar. Bu durumu tekrar kesin olarak teyit etmek için açmış olduğumuz dosya tanımlayıcısına veri gönderip bu verileri okumayı deneyelim.

```bash
└─$ cat >&8
ben ilk
ben de ikinci satırım
└─$ cat <&8
└─$ cat kaynak.txt
ben ilk
ben de ikinci satırım
```

Burada gerçekleşen işlem biz ilk olarak veri gönderdikten sonra dosyanın sonuna ulaşan dosya tanımlayıcısı, dosyayı okumak istediğimizde dosyanın sonunda olduğu için çıktı üretmiyor. Ancak dosya içeriğine verilerin yazıldığını kaynak.txt dosyasını okuyarak teyit edebiliyoruz.

Dosya tanımlayıcıların dosyanın sonuna gidip bu konumu kayıtlı tuttuğunun bir diğer kanıtı aşağıdaki örnektir.

```bash
└─$ cat kaynak.txt
ben ilk
ben de ikinci satırım
└─$ cat >&8
bu yeni satır
bu en yeni..
└─$ cat kaynak.txt
ben ilk
ben de ikinci satırım
bu yeni satır
bu en yeni..
```

Normalde dosya sonuna ekleme işlemi için çift büyüktür işareti kullanmamız gerekirken, tek büyüktür işareti zaten dosyanın sonunda olduğumuz için yeni verileri dosyanın sonuna eklemiş oluyor.

Kaputun altındaki olayı merak ediyorsanız, dosya tanımlayıcısı dosyanın hangi kısmına kadar okuduğunun bilgisini ***/proc/self/fdinfo/dosya_tanımlayıcı_numarası*** konumunda tutuyor.

Buradaki ***/proc*** klasörü çalışmakta olan proseslerin bilgilerini tutan sanal bir dosya sistemidir. ***/self*** klasörü ise çalışmakta olduğumuz mevcut süreci temsil ediyor. Bunun yerine çift dolar işareti `$$` de kullanabilirdik. ***fdinfo*** dosyası ise dosya tanımlayıcısına ait bilgi sunan sanal dosyadır. Bu kullanım ile mevcut kabuk üzerinde açılmış olan dosya tanımlayıcısı hakkında bilgi alabiliyoruz.

Yeni bir örnek üzerinden de bu durumu gözlemleyebiliriz. 

```bash
└─$ exec 9<> dosya.txt                                                                                      
└─$ cat /proc/self/fdinfo/9
pos:    0
flags:  0100002
mnt_id: 27
```

Burada "pos" olarak geçene kısım İngilizce "position" kelimesinin kısaltması olarak, dosyanın hangi konumunda bulunduğunun yani pozisyonunun bilgisini tutuyor. Henüz bir yazma ya da okuma işlemi yapılmadığı için bu değer sıfır. Şimdi veri ekleyip değişin durumunu kontrol edelim.

```bash
└─$ cat >&9
veri girişi 
yapılıyor..
└─$ cat /proc/self/fdinfo/9                                                                                 
pos:    27
flags:  0100002
mnt_id: 27
```

Görebildiğiniz gibi veri eklendiğinde değerimiz değişmiş oldu. Teyit işlemini devam ettirmek adına yeni veri ekleyip tekrar kontrol edelim.

```bash
└─$ cat >&9
ben de yeni satırım..
└─$ cat /proc/self/fdinfo/9                                                                                 
pos:    51
flags:  0100002
mnt_id: 27
```

Sizlerin de görebildiği gibi değer yükselmiş ve dosyanın en son işlenin pozisyon durumunu değiştirmiş oldu. Artık 9 numaralı dosya tanımlayıcısı kapatılana kadar bu pos/pozisyon değerinin sonrasında okuma ya da yazma yapıyor olacak. Kabuk henüz bu değeri sıfırlamak için yani dosyanın başına gitmek için dosya tanımlayıcıyı yeniden açmak dışında alternatif sunmuyor.

Yazma ya da okuma işlemi için açılmış olan dosyanın en son konumundan itibaren işlem yapılacağından, açtığınız dosya tanımlayıcıları bu durumu da göz önünde bulundurarak kullanmalısınız.

## Dosya Tanımlayıcılarını İsimlendirmek

Normalde dosya tanımlayıcıları pozitif tam sayılar ile temsil edilir. Ancak dilersek metinsel bir isimlendirme yaparak, dosya tanımlayıcısının numarasının sistem tarafından otomatik olarak atanmasını sağlayabiliriz. Tanımlama yaparken dikkat etmemiz gereken detay Türkçe karakter kullanmadan yalın bir isimlendirme yapmaktır. Örnek olması için "yaz" isminde bir dosya tanımlayıcısı açıyorum.

```bash
└─$ exec {yaz}> yazılar.txt
┌──(taylan㉿DESKTOP-E4TGC85)-[~]
└─$ ls -la /proc/self/fd/
total 0
dr-x------ 2 taylan taylan 0 Dec 30 17:19 .
dr-xr-xr-x 7 taylan taylan 0 Dec 30 17:19 ..
lrwx------ 1 taylan taylan 0 Dec 30 17:19 0 -> /dev/tty1
lrwx------ 1 taylan taylan 0 Dec 30 17:19 1 -> /dev/tty1
l-wx------ 1 taylan taylan 0 Dec 30 17:19 10 -> /home/taylan/yazılar.txt
lrwx------ 1 taylan taylan 0 Dec 30 17:19 2 -> /dev/tty1
lr-x------ 1 taylan taylan 0 Dec 30 17:19 3 -> /proc/51/fd
```

Görebildiğiniz gibi bizim isimlendirmiş olduğumuz dosya tanımlayıcısının numarası sistem tarafından boşta bulunan uygun bir numara ile ilişkilendirilmiş. Açmış olduğumuz isimli dosya tanımlayıcısını kullanırken tıpkı değişken çağırırken olduğu gibi isminin başında dolar işareti kullanmamız gerekiyor.

```bash
└─$ whoami >&$yaz
└─$ cat yazılar.txt
taylan
```

Görebildiğiniz gibi `whoami` komutunun çıktısı "**yaz**" ismi ile temsil edilen dosya tanımlayıcısının işaret ettiği "***yazılar.txt***" dosyasına yönlendirilmiş oldu.

İsimlendirme metodunun kullanımı genellikle mevcut kabuk üzerinde açık bulunan dosya tanımlayıcıları ile bizim açacaklarımızın çakışmaması için kullanılan bir yöntemdir. Biz bir betik dosyasını çalıştırdığımızda mevcut kabuk işlemi çatallanır ve kendi bünyesinde bulunan açık dosya tanımlayıcı bilgilerini de alt işleme iletir. Eğer isimlendirme ile dosya tanımlarsak 10'dan itibaren boşta bulunan bir numara atanacağı için çakışma yaşanmaz. Esasen bash kabuğunun geliştiricileri 9'dan büyük olmadığı sürece dosya tanımlayıcı numarası kullanabileceğimizi belirtiliyor. Buradaki sınır, kabuğun otomatik olarak dosya tanımlayıcı numarası tanımlarken 10'dan itibaren kullanılabilir olan numaraları seçmesidir. Yine de üst işlemden aktarılan dosya tanımlayıcıları düşünüldüğünde isimlendirme daha güvenli bir yöntem olabilir. 

Dosya tanımlayıcı bilgilerinin alt işlemlere aktarıldığını teyit etmek isterseniz alt işlemde `ls -la /proc/self/fd/` komutunu çalıştırabilirsiniz.

```bash
└─$ echo "İşlem No:$BASHPID" ; ls -la /proc/self/fd
İşlem No:107
total 0
dr-x------ 2 taylan taylan 0 Dec 30 18:18 .
dr-xr-xr-x 7 taylan taylan 0 Dec 30 18:18 ..
lrwx------ 1 taylan taylan 0 Dec 30 18:18 0 -> /dev/tty2
lrwx------ 1 taylan taylan 0 Dec 30 18:18 1 -> /dev/tty2
l-wx------ 1 taylan taylan 0 Dec 30 18:18 10 -> /home/taylan/yazılar.txt
lrwx------ 1 taylan taylan 0 Dec 30 18:18 2 -> /dev/tty2
lr-x------ 1 taylan taylan 0 Dec 30 18:18 3 -> /proc/160/fd
└─$ ( echo "İşlem No:$BASHPID" ; ls -la /proc/self/fd )
İşlem No:161
total 0
dr-x------ 2 taylan taylan 0 Dec 30 18:18 .
dr-xr-xr-x 7 taylan taylan 0 Dec 30 18:18 ..
lrwx------ 1 taylan taylan 0 Dec 30 18:18 0 -> /dev/tty2
lrwx------ 1 taylan taylan 0 Dec 30 18:18 1 -> /dev/tty2
l-wx------ 1 taylan taylan 0 Dec 30 18:18 10 -> /home/taylan/yazılar.txt
lrwx------ 1 taylan taylan 0 Dec 30 18:18 2 -> /dev/tty2
lr-x------ 1 taylan taylan 0 Dec 30 18:18 3 -> /proc/162/fd
```

## Birden Fazla Komutun Çıktısını Aynı Dosyaya Yönlendirmek

Daha önce alt kabukları nasıl oluşturabileceğimize değinmiştik. Eğer ihtiyacımız olursa alt kabukta yürüttüğümüz birden fazla komutun çıktısını tek bir dosyaya yönlendirebiliriz.

```
$ (command1; command2) >file

```

Burada açıklanması gereken özel bir durum yok. Sadece daha önce öğrendiğimiz yöntem ile farklı bir bakış açısı sunmak için bu örneği de ele aldık.

## İşlem İkamesi ile Farklı İşlemlere Çıktı Göndermek

İşlemleri açıklarken değinmiş olduğumuz "işlem ikamesi" yani `>(...)` operatörünü kullanarak

```
$ command > >(stdout_cmd) 2> >(stderr_cmd)

```

This one-liner uses process substitution. The `>(...)` operator runs the commands in `...` with stdin connected to the read part of an anonymous named pipe. Bash replaces the operator with the filename of the anonymous pipe.

So for example, the first substitution `>(stdout_cmd)` might return `/dev/fd/60`, and the second substitution might return `/dev/fd/61`. Both of these files are named pipes that bash created on the fly. Both named pipes have the commands as readers. The commands wait for someone to write to the pipes so they can read the data.

The command then looks like this:

```
$ command > /dev/fd/60 2> /dev/fd/61

```

Now these are just simple redirections. Stdout gets redirected to `/dev/fd/60`, and stderr gets redirected to `/dev/fd/61`.

When the command writes to stdout, the process behind `/dev/fd/60` (process `stdout_cmd`) reads the data. And when the command writes to stderr, the process behind `/dev/fd/61` (process `stderr_cmd`) reads the data.

Bashte soket açmayla ilgili güzel örnekler;

[https://www.xmodulo.com/tcp-udp-socket-bash-shell.html](https://www.xmodulo.com/tcp-udp-socket-bash-shell.html)

[Copy of KAYNAK](15-%20Yo%CC%88nlendirmeler%200e92d785d384481dad32fcd77a02ebf2/Copy%20of%20KAYNAK%20cea454f188cb499bb864926fbb433faf.md)

[Copy of FD Dosya Tanımlayıcı Nasıl Çalışır](15-%20Yo%CC%88nlendirmeler%200e92d785d384481dad32fcd77a02ebf2/Copy%20of%20FD%20Dosya%20Tan%C4%B1mlay%C4%B1c%C4%B1%20Nas%C4%B1l%20C%CC%A7al%C4%B1s%CC%A7%C4%B1r%2074ea0b85119242b1896b8f6458dab629.md)

[İşlemler Arası İletişim | Pipe ve Fifo ](15-%20Yo%CC%88nlendirmeler%200e92d785d384481dad32fcd77a02ebf2/I%CC%87s%CC%A7lemler%20Aras%C4%B1%20I%CC%87letis%CC%A7im%20Pipe%20ve%20Fifo%20bde1542b7f51406eade4bf0df2727b2c.md)