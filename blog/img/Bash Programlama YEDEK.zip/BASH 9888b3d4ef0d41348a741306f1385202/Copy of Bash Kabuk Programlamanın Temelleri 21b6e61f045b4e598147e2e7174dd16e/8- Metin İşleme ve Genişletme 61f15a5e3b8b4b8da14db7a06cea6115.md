# 8- Metin İşleme ve Genişletme

PATTERN MATCH ÜZERİNE:[http://mywiki.wooledge.org/BashGuide/Patterns](http://mywiki.wooledge.org/BashGuide/Patterns)

# Wildcards(Globbing) Regex Genişletme Kavramları Üzerine

Regex Türkçe Anlatım: [https://www.youtube.com/watch?v=bF_zEzFQZuA&ab_channel=kablosuzkedi](https://www.youtube.com/watch?v=bF_zEzFQZuA&ab_channel=kablosuzkedi)

[https://appcodelabs.com/advanced-wildcard-patterns-most-people-dont-know](https://appcodelabs.com/advanced-wildcard-patterns-most-people-dont-know)

[https://www.shell-tips.com/bash/wildcards-globbing/](https://www.shell-tips.com/bash/wildcards-globbing/)

Expansion olarak geçen "karakter genişletme konusu"

Kaynak; [https://linuxcommand.org/lc3_lts0080.php#:~:text=We have seen a couple,the shell acts upon it](https://linuxcommand.org/lc3_lts0080.php#:~:text=We%20have%20seen%20a%20couple,the%20shell%20acts%20upon%20it).

[https://www.gnu.org/software/bash/manual/html_node/Shell-Expansions.html#Shell-Expansions](https://www.gnu.org/software/bash/manual/html_node/Shell-Expansions.html#Shell-Expansions)

# Kabuk Üzerinde Genişletme

Bash kabuğuna vermiş olduğumuz komutlar çalıştırılmadan önce metinsel olarak anlamlandırılmak üzere işlenir ve gerekiyorsa genişletilirler. Peki burada bahsi geçen "genişletme" tam olarak ne anlama geliyor? 

Sanırım bu durumu en açık şekilde `echo` komutu ile açıklayabiliriz. Örneğin biz kabuğa `echo merhaba` yazarsak, çıktı olarak "***merhaba***" ifadesini alırız. Aynı örneği `echo *` şeklinde uyguladığımızda ise, bu kez çıktı olarak mevcut konumumuzda yer alan dosya ve dizinlerin listesini alırız. Bu durumun nedeni ikinci örneğimizde kullanmış olduğumuz yıldız(asterix) işaretinin bash üzerinde özel bir anlam taşıyor olmasıdır. Yıldız işareti özel anlam taşıdığı için bash kabuğu yalnızca yıldız karakterini bastırmak yerine yıldız karakterini genişletip asıl özelliğinin çalışmasını sağladı. Normalde yıldız joker karakteri her şeyi kapsama işlevindedir ve bu örneğimizde de tüm dosya ve dizinlerin bilgisini `echo` komutuna aktarmış oldu.

Neticede bizim kabuğa vermiş olduğumuz tüm komutlar metinsel girişlerdir. Kabuk bizden aldığı emirleri doğru şekilde algılayabilmek için metin içerisindeki özel anlam taşıyan ifadeleri bulup uygun şekilde çalıştırmayı dener. Ayrıca kabuk aracılığı ile çalıştırılan harici araçlar da kendi bünyesinde bulunan kurallar dahilinde girilen metinleri yorumlar. İşte "genişletme" olarak bahsettiğimiz durum tam olarak budur. Anlatım devamında bu genişletme kuralının detaylarına ve gerektiğinde bu genişletmeden nasıl kaçınabileceğimize değiniyor olacağız.

### Bash Kabuğu Dahilindeki Genişletme Türleri

Elbette kabuk aracılığı ile çalıştırılan harici araçların farklı genişletme özellikleri olsa da Bash kabuğunda aşağıdaki listede sıralanan 7 türde genişletme bulunur. Yani bash kabuğu kendisine verilen metinsel komutları aşağıdaki kapsam dahilinde değerlendirecektir. Harici araçların genişletme davranışları için araçların yardım saylarına göz atmak gerekir. Bu konuya ayrıca değineceğimiz için şimdi bash kabuğundaki genişletme türlerini açıklayarak devam edelim.

- Süslü(Kıvırcık) Parantez Genişletmesi
- Tilde Genişletmesi
- Parametre Genişletmeleri
- Komut İkamesi
- Aritmetik Genişletme
- İşlem İkamesi(Eğer sistem tarafından destekleniyorsa.)
- Kelime Ayırma-Bölümleme
- Dosya Adı Genişletmesi

Genişletme türleri listelediğimize göre artık tam olarak ne ifade ettiklerine daha yakından bakabiliriz.

### Süslü(Kıvırcık) Parantez-Küme Ayracı Genişletmesi

Süslü(kıvırcık) parantez içerisinde virgülle ayrılarak belirtilmiş olan aralıklar, bash kabuğunda özel anlam taşır ve taşıdıkları anlama göre de genişletilirler. Süslü parantezin kullanım alternatiflerinden anlatımın devamında "düzenli ifadeler" başlığı altında ayrıca bahsediyor olacağız. Yine de bash kabuğunun süslü parantez içerisindeki kurallara göre rastgele dizeler üretebileceğini şimdiden bilmeliyiz. Bu mekanizma tıpkı "dosya adı genişletmesi" gibidir. Arasındaki fark burada genişleme ile üretilen dosya isimlerinin daha önceden var olması gerekmez. Birden fazla kullanım seçeneği olsa da en temelde aşağıdaki şekilde çok çeşitli genişletmeler elde edebiliriz.

```bash
taylan@taylan:~$ echo a{d,l,t}a
ada ala ata
```

Sizlerin de fark edebileceği gibi genişletme işlemi süslü parantez içerisindeki sıraya uygun şekilde soldan sağa doğru gerçekleştirilir. 

Süslü parantez yani küme ayracı sayesinde istediğimiz türde sıralı dizeler üretebiliyoruz  Süslü parantez içerisinde virgüllerle ayırarak belirtilmiş olan aralıklar, bash kabuğunda özel anlam taşır ve taşıdıkları anlama göre de genişletilirler. Çalışma yapısını gözlemlemek adına basit örnekler üzerinden ilerleyelim.

Başlangıcında ve sonunda standart ifadeler bulunan ancak ortadaki ifadelerin değiştiği bir örnek;

```bash
└─$ echo a{n,s,b}i
ani asi abi
└─$ echo a{nn,ss,bb}i
anni assi abbi
└─$ echo 0{3,5,7}9
039 059 079
```

Çıktıyı incelediğimizde virgülle ayırmış olduğumuz karakterlerin tıpkı tanımlandıkları sıralamaya yani soldan sağa doğru genişletildiğini teyit edebiliyoruz. Burada biz doğrudan genişletilecek tüm karakterleri belirttik. Eğer genişletilecek karakterlerin hepsini yazmak yerine bir aralık belirtmek istersek; iki nokta yan yana olacak şekilde `{başlangıç..bitiş..artış_oranı}` yapısını kullanabiliyoruz. Aşağıdaki örnekler kullanımı net şekilde ortaya koyuyor.

```bash
└─$ echo {a..z}
a b c d e f g h i j k l m n o p q r s t u v w x y z
└─$ echo {a..z..2}
a c e g i k m o q s u w y
└─$ echo {a..z..3}
a d g j m p s v y
└─$ echo {0..15}
0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
└─$ echo {0..15..2}
0 2 4 6 8 10 12 14
└─$ echo {0..15..3}
0 3 6 9 12 15
```

Farklı bir örnek olması adına, dizi belirtip rakamların binary karşılığını bastırabiliriz. Neticede dizi elemanlarının sıra numarası, 0 ve 1 ile üretilen 8 basamaklı sayıya karşılık gelecektir.

```bash
ikili=({0..1}{0..1}{0..1}{0..1}{0..1}{0..1}{0..1}{0..1})
└─$ echo ${ikili[3]}
00000011
└─$ echo ${ikili[33]}
00100001
└─$ echo ${ikili[99]}
01100011
```

Her ne kadar çok kullanışlı bir yol olmasa da genişletme kavramı için dikkate değer bir örnek. Üstelik dizi elemanlarını çağırırken kullandığımız ${dizi[sıra-no]} yapısı da "parametre genişletmeye" örnektir. Tek bir örnek ile iki farklı genişletmeyi de deneyimlemiş olduk. Parametre genişletme ile anlatıma devam edelim.

### Tilde Genişletmesi

Tilde yani yaklaşık `~` (Türkçe Q klavyede "*AltGr+ü" tuşlaması ile oluşturulur.*) işareti tek başına kullanıldığında mevcut oturum açmış kullanıcı ismi sayesinde mevcut kullanıcının ev dizinini temsil eder. Örneğin ben taylan kullanıcısı olarak oturum açtıysam ve tilde işaretini kullandıysam, tilde işareti ***/home/taylan*** ifadesine genişletilir. Teyit etmek için `echo ~` komutunu kullanabiliriz.

```bash
$ echo ~
/home/taylan
```

Eğer farklı bir kullanıcı hesabında oturum açarsak bu çıktı da elbette farklı olacaktı.

```bash
$ echo ~
/home/ali
```

Benzer şekilde herhangi bir kullanıcının ev adresi için `~kullanıcı_adı` kullanımı yeterlidir. Örneğin ali kullanıcısı ile oturum açmışken taylan kullanıcı hesabının ev dizinini sorgulayabilirim.

```bash
$ echo ~taylan
/home/taylan
```

Ayrıca her kullanıcının ev dizini /home klasörü altında olmak zorunda da değil. Örnek olması için "torvalds" isimli kullanıcının ev dizinini "/usr/share/" dizini altında belirtelim. Ve tekrar bu kullanıcının ev dizinini tilde işareti üzerinden elde etmeyi deneyelim.

```bash
$ sudo useradd torvalds --home-dir /usr/share/torvalds
$ echo ~torvalds
/usr/share/torvalds
```

Çıktıdan da anlaşılacağı üzere farklı konumlarda olsa bile, tilde işareti ilgili kullanıcının ev dizini bulup o adrese genişletiliyor. Zaten tilde işaretinin kullanılmasının en temel nedeni de budur. Yani farklı konumlarda bulunması muhtemel ev dizinine her koşulda ulaşabilmemizi sağlar. Örneğin yazmış olduğunuz program kullanıcıların ev dizininin /home klasörü altında olduğunu varsayarak çalışıyorsa ve gerçekte kullanıcı ev dizini farklı konumdaysa nasıl bir şenlik olur ? İşte bu sebeple tilde işaretinin genişletilmesi işlerimizi kolaylaştırır. Üstelik yazımı da son derece kısa ve pratiktir.

Tilde işaretine ek olarak artı işareti eklenirse, PWD değişken değerine yani mevcut bulunduğumuz konuma genişletilir. Eksi işareti kullanılırsa da OLDPWD yani bir önceki dizin adresimize genişletilir. Aşağıdaki çıktılara bakarak bu durumu teyit edebilirsiniz.

```bash
taylan@DESKTOP-E4TGC85:/home/ali$ cd
taylan@DESKTOP-E4TGC85:~$ echo $PWD
/home/taylan
taylan@DESKTOP-E4TGC85:~$ echo ~+
/home/taylan
taylan@DESKTOP-E4TGC85:~$ echo $OLDPWD
/home/ali
taylan@DESKTOP-E4TGC85:~$ echo ~-
/home/ali
taylan@DESKTOP-E4TGC85:~$
```

Tilde işaretinin diğer bir genişletilme seçeneği ise, tıpkı `dirs` komutu gibi davranabilmesidir. `dirs` komutunu ayrıca ele alıyoruz ancak yine de kısaca bir değinmemiz gerekirse, dizin adreslerinin yığınlar halinde tutulmasını sağlar. Bizler de bu yığınlar içerisinden istediğimiz dizine kısayoldan erişebiliriz. Aşağıdaki şekilde olan tilde kullanımları `dirs` komutunun kullanımlarına eşdeğer olarak genişletilir.

`~N` : `dirs +N` kullanımı ile aynıdır.

`~+N` : `dirs +N` kullanımı ile aynıdır.

`~-N` : `dirs -N` kullanımı ile aynıdır.

Kullanımını anlamak için lütfen `dirs` komutunun açıklamasına gözatın. 

# Parametre Genişletmeleri

[https://wiki.bash-hackers.org/syntax/pe#use_a_default_value](https://wiki.bash-hackers.org/syntax/pe#use_a_default_value)

Parametrelerin ne olduğunu daha önce örnekler üzerinden irdelemiştik. Özetle parametre, değerleri depolayan yapıya verilen genel isimdir. Söz konusu parametre olduğunda pek çok farklı parametre genişletmesinin bulunduğunun farkında olmalıyız. Parametre genişletmesinin uygulanabilmesi için dolar işaretini ve duruma göre dolar işareti ile süslü parantezi birlikte kullanmamız gerekiyor. Burada bahsi geçen genişlemeye uğrayacak parametreler; isim, numara ya da özel semboller ile gerçek değerin temsil edildiği yapılardır. Bu yapıları aşağıdaki şekilde özetleyebiliriz.

- Değişkenler ve diziler, isimleri ile çağırılan parametrelerdir. ( `$degisken` `${degisken}` `${dizi}` )
- Girilen argümanları veren pozisyon parametreleri de parametre genişletilmesinin ürünüdür. (`$0` `$1` `$2` .. `$9`)
- Dolar işareti ile kullanılan birtakım özel semboller de parametre genişletmesine tabidir.  (`$*` `$@` `$$` `$?` `$!` `$-` `$#`)

Önceki anlatımlarda "pozisyon parametreleri" ve "özel parametre sembolleri"nden detaylıca bahsetmiştik. Bu parametreler kullanıldığında önceden tanımlandıkları özellikleri yerine getirecek şekilde genişletiliyor. Yani pozisyon parametrelerini veya özel parametre sembollerini kullanırken aslında "parametre genişletmesi" gerçekleştiriyordu fakat biz bunun farkında değildik. Artık farkındayız ve nasıl genişletildiğini daha önce deneyimlediğimiz için tekrar etmeyeceğiz. 

Anlatımlarımıza, "değişken" ve "dizi"ler üzerindeki parametre genişletmelerinden bahsederek devam ediyor olacağız. Anlatım biraz uzun gelebilir ancak en azından bir kez olsun gözden geçirmenizi tavsiye ederim. Bu sayede genişletmelerin nasıl uygulandığını ve gerektiğinde ihtiyacınız olan genişletme sonucuna nasıl ulaşabileceğiniz konusunda fikir sahibi olabilirsiniz. 

## Standart Kullanım

### Değişken

Tanımlamış olduğumuz değişken değerlerini çağırırken ilgili değişkeni, başında dolar işareti olacak şekilde kullanırız. Buradaki dolar işareti değişken isminin değişken değerine genişletilmesini sağlar.

```bash
└─$ linux="çekirdek"
└─$ echo $linux
çekirdek
```

Bu temel kullanım amacına ulaşıyor olsa da bazı durumlarda değişken ismini keskin şekilde belirtmemiz gerekir. Genişletilecek parametrenin sınırlarını kıvırcık parantez içerisine alarak belirtebiliyoruz. Aşağıdaki örneğe bakarak bu durumu gözlemeyebilirsiniz.

```bash
└─$ echo $linuxdur
└─$ echo ${linux}tir
çekirdektir
```

Zaten bu durumdan değişkenleri ele alırken kısaca bahsetmiştik. Şimdi dolar işareti başta olacak şekilde kıvırcık parantez içerisine yazılan ifadelerin "parametre genişletmesine" tabi olduğunun farkına vardık.

### Dizi

Diziler konusunu ele alırken tanımlanmış olan dizileri başta dolar işareti olan süslü parantez `${dizi}` ile çağırmıştık. Buradaki işlem de aslında parametre genişletmesidir. Hatırlamak adına çıktılara göz atabilirsiniz. 

```bash
└─$ linux=(Linux aslında çekirdektir)
└─$ echo ${linux}
Linux
└─$ echo ${linux[*]}
Linux aslında çekirdektir
└─$ echo ${linux[2]}
çekirdektir
```

## Indirection: Dolaylı Genişletme

Genişletilecek parametrenin en başına konulan ünlem işareti, ilgili parametrenin **işaret ettiği** değişkenin değerini bastırır. Yani ilk genişletilen parametrenin değeri, tekrar genişletilecek olan parametre olarak ele alınır. Aşağıdaki örneklere bakarak kullanım amacını kavrayabilirsiniz.

```bash
$ degisken="deger"
$ deger=81
$ echo ${!degisken}
81
$ echo ${degisken}
deger
```

Buradaki örnekte `${!degisken}` genişletilip, `${deger}` halini aldı ve tekrar genişletilip "deger" isimli değişkenin "81" olan değerini bastırmış oldu. 

<aside>
ℹ️ `${!degisken}` → `${deger}` → 81

</aside>

Burada yapılan işlem bir değişken değerinin, başka bir değişkenin ismi olarak işaret edilmesidir. Kısacası dolaylı yoldan değişken değerine ulaşılır. Çıktılara baktığınızda **ünlem işareti olamadan** aynı örneği tekrar ettiğimizde **dolaylı değere ulaşılmadığını** görebilirsiniz.

Değişkenler dışında diziler üzerinde de dolaylı genişletme işleminin uygulanması mümkündür. 

```bash
└─$ ben="taylan"
└─$ dizi=(ben bir diziyim)
└─$ echo ${dizi[0]}
ben
└─$ echo ${!dizi[0]}
taylan
```

Gerçekleştirilen genişletme özetle aşağıdaki şekildedir;

<aside>
ℹ️ `${!dizi[0]}` → `${ben}` → taylan

</aside>

Dizileri ele alırken "ilişkisel diziler" konusundan da bahsetmiştik. Dolaylı genişletmeyi ilişkisel diziler üzerinde de kullanmamız mümkündür.

```bash
declare -A dizi=( [ad]=ahmet [soyad]=yılmaz [yas]=25 [konum]=istanbul )
└─$ ahmet=insan
└─$ echo ${dizi[ad]}
ahmet
└─$ echo ${!dizi[ad]}
insan
```

İlişkisel dizide "ad" kısmına karşılık gelen "ahmet" ifadesi, "ahmet" değişkeninin "insan" değerine kadar dolaylı yoldan genişletilmiş oldu.

<aside>
ℹ️ `${!dizi[ad]}` → `${ahmet}` → insan

</aside>

Ayrıca değişken isimlerini bastırırken uyguladığımız yaklaşımı dizi elemanlarının ilişkili olduğu ifadeleri öğrenmek için de uygulayabiliriz. 

```bash
└─$ declare -p dizi
declare -A dizi=([konum]="istanbul" [ad]="ahmet" [soyad]="yılmaz" [yas]="25" )
└─$ echo ${dizi[*]}
istanbul ahmet yılmaz 25
└─$ echo ${!dizi[*]}
konum ad soyad yas
```

Bu kullanımın dışında tanımlı değişken ya da dizi isimlerini de bu yolla elde edebiliriz. 

```bash
└─$ P_DIZISI1=(bir iki uc)
└─$ P_DIZISI11=(1 2 3)
└─$ P_DEGISKENI1="ben degisken1"
└─$ P_DEGISKENI11="ben degisken on bir"
└─$ echo ${!P*}
PATH PIPESTATUS PPID PS1 PS2 PS4 PWD P_DEGISKENI1 P_DEGISKENI11 P_DIZISI1 P_DIZISI11
```

İstediğimiz sonuca ulaştık çünkü; ünlem işareti kullanıldığında ilgili parametrenin(değişken ya da dizinin) tanımlı olup olmadığı kabuk tarafından kontrol edilip, ilgili parametre isimlerine genişletilmiş oldu. Bu durumu teyit etmek için ünlem işareti olmadan aynı örneği tekrar edebiliriz

```bash
└─$ echo ${!P*}
PATH PIPESTATUS PPID PS1 PS2 PS4 PWD P_DEGISKENI1 P_DEGISKENI11 P_DIZISI1 P_DIZISI11
└─$ echo ${P*}
-bash: ${P*}: bad substitution
```

### Fonksiyon Argümanlarına Genişletme

Fonksiyon yapısı içinde kullanıldığında, fonksiyona argüman olarak verilen değerleri dolaylı yoldan genişletebiliriz.

```
└─$ fonk() { echo ${!1}; }
└─$ fonk deneme
deneme
```

Biz bu fonksiyonu "deneme" argümanı ile çalıştırdığımızda konsola "deneme" ifadesi basılmış oluyor. Burada ünlem işareti ile, fonksiyona verilen 1 argüman değerine ulaşmış olduk.

Aynı işlemi elbette pozisyon parametre genişletmesi ile de yapabilirdik.

```bash
└─$ fonk() { echo $1; }
└─$ fonk deneme
deneme
```

Peki neden doğrudan pozisyon parametresi kullanabilecekken dolaylı genişletme ile 1. pozisyondaki argümanı almaya çalıştık ? Sebebi, ilgili argüman üzerinde istediğimiz şekilde düzenleme yapabilmektir.

Ünlem işaretinin nasıl bir etkiye sahip olduğunu birkaç farklı şekilde deneyimlemiş olduk. Dolaylı genişletmenin kullanım alanı kısıtlı olsa da karşılaşmanız ve ihtiyaç duymanız halinde artık biliyor olacaksınız.

Pointer mevzuu [http://mywiki.wooledge.org/BashFAQ/006](http://mywiki.wooledge.org/BashFAQ/006)

Dolaylı genişletme için oku; [http://ahmed.amayem.com/bash-indirect-expansion-exploration/](http://ahmed.amayem.com/bash-indirect-expansion-exploration/)

declare -n var=x kullanımına da değinmek lazım

doğrudan parametre genişletmesi ile ilgili olmasa da dolaylı 

Baştan sonra oku; [https://www.linuxjournal.com/content/whats-new-bash-parameter-expansion](https://www.linuxjournal.com/content/whats-new-bash-parameter-expansion)

DAHA FAZLA GERÇEK HAYATTAN ÖRNEK VERMEYE ÇALIŞ TÜM KİTABI BU EKSENDE DÜZENLEMEYE ÇALIŞMAN İYİ OLUR

## Durum Değişikliği

Genişletilecek metinsel ifadenin küçük ya da büyük karakterlere göre genişletilmesini sağlamak mümkün. Düzenleme için aşağıdaki yapıları kullanıyoruz;

- İlk harfin büyük olması için: `^`
- Tüm harflerin büyük olması için: `^^`
- İlk harfin küçük olması için: `,`
- Tüm harflerin küçük olması için: `,,`
- İlk harfleri mevcut durumlarının tersine çevirmek için: `~`
- Tüm harfleri mevcut durumlarının tersine çevirmek için: `~~`

Değişkenler ya da diziler üzerinde de uygulanabilir.

```bash
└─$ echo ${metin_d}
Ben SADECE metnim
└─$ echo ${metin_d^}
Ben SADECE metnim
└─$ echo ${metin_d^^}
BEN SADECE METNIM
└─$ echo ${metin_d,}
ben SADECE metnim
└─$ echo ${metin_d,,}
ben sadece metnim
└─$ echo ${metin_d~}
ben SADECE metnim
└─$ echo ${metin_d~~}
bEN sadece METNIM
```

```bash
└─$ echo ${metin_dizi[*]}
Ben SADECE dizeyim
└─$ echo ${metin_dizi[*]^}
Ben SADECE Dizeyim
└─$ echo ${metin_dizi[*]^^}
BEN SADECE DIZEYIM
└─$ echo ${metin_dizi[*],}
ben sADECE dizeyim
└─$ echo ${metin_dizi[*],,}
ben sadece dizeyim
└─$ echo ${metin_dizi[*]~}
ben sADECE Dizeyim
└─$ echo ${metin_dizi[*]~~}
bEN sadece DIZEYIM
```

## Genişletmenin Sınırlandırılması

Eğer genişletme işleminde belirli bir kalıptan öncesini veya sonrasının sınırlandırılmasını istersek duruma göre aşağıdaki yapıları kullanabiliyoruz;

**Baştan itibaren şablonun eşleştiği kısımları silmek için;**

İlk eşlenen bölüme kadarını olan kısmı silmek üzere: `#`

Tüm eşlenen bölüme kadarını olan kısmı silmek üzere: `##`

```bash
└─$ echo ${varlik}
olmak ya da olmamak
└─$ echo ${varlik#*ol}
mak ya da olmamak
└─$ echo ${varlik##*ol}
mamak
```

**Sondan itibaren şablonun eşleştiği kısımları silmek için;**

İlk eşlenen bölüme kadar olan kısmı silmek üzere: `%`

Tüm eşlenen bölüme kadar olan kısmı silmek üzere: `%%`

```bash
└─$ echo ${varlik%ol*}
olmak ya da
└─$ echo ${varlik%%ol*}
```

Biz değişkenler üzerinden örnekledik ancak aynı şekilde diziler üzerinde de kullanılabilir.

### Bul Değiştir İşlemi

Aradığımız kalıba uygun olan ifadelerin dilediğimiz yeni ifadeler ile değiştirilerek genişletilmesi de mümkündür.

## Değişken Değerinin Uzunluğunu Öğrenmek

Eğer değişkenlerin sahip olduğu değerlerin karakter uzunluklarını öğrenmek istersek kare işareti başta olacak şekilde değişken ismini belitebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/27.png)

Üstelik bu kullanım sadece diziler için değil standart ve sabit değişkenler için de geçerlidir. Sabit değişkenlerin ne olduğundan anlatımın devamında ayrıca bahsediyor olacağız.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/28.png)

Eğer komutumuzda index numarası ile herhangi bir dizi elemanı belirtmezsek varsayılan olarak dizide yer alan ilk eleman işleme alınıyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/29.png)

Ayrıca dizi içerisinde kaç tane değişken olduğunu öğrenmek için de `#` simgesini ile birlikte index numarası kısmında `` simgesini kullanmamız yeterli.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/30.png)

Yani anlayabileceğiniz gibi burada yer alan kare işareti mevcut değişken verisini saymakla mükellef.

## Değerin Bir Kısmını Bastırmak

Değişkene atanmış olan değerin belirli bir kısmını almak istersek, çıktı değeri olarak almak istediğimiz kadarlık kısmı **${degisken:başlangıç:uzunluk}** şeklinde belirtmemiz gerekiyor.

**Başlangıç :** Seçme işleminin başlanacağı yeri temsil eder. Boş bırakılırsa en baştan itibaren seçilir.

**Uzunluk :** Seçme işleminin ne kadar uzunlukta olacağını belirtir. Bu kısım boş bırakılırsa seçme işlemi otomatik olarak değerin sonuna kadar yapılır.

### Örnekler;

Kullanım farklarının daha kolay anlaşılabilmesi için tek bir örnek üzerinden ilerlemek üzere, **deneme** isimli değişkene "**123456789**" değerini atıyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/40.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/40.png)

**" ${deneme::3} "** = değişken değerinin ilk 3 karakteri.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/41.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/41.png)

**" ${deneme:2} "** = değişken değerinin 2. karakterinden sonra hepsi.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/42.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/42.png)

**" ${deneme:2:4} "** = değişken değerinin 2. karakterinden sonraki 4 karakter.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/43.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/43.png)

## Değişken Değerlerini Silmek

Değişkenimizin basılacak olan değerini silmek için iki farklı kullanım metodu bulunuyor.

Bunlardan ilki, değerleri **başlangıçtan itibaren** silen **#** işareti, ikincisi ise tersi şekilde değeri **sondan itibaren** silen **%** işaretidir.

Bu işaretlerin birer kez kullanılmasıyla, hedef ile eşleşen yalnızca ilk kısım siliniyor. Eğer yalnızca ilk kısım değil de eşleşen tüm kısımlar silinsin istersek bu işaretleri iki kez kullanmamız gerekiyor. Durumu daha net anlamak adına lütfen okumaya devam edin.

Öncelikle tek bir referans örnek üzerinden ilerlemek üzere `silinecek=(sil silindi silinmişti)` şeklinde değişkenimizi tanımlayalım. Bu kısımda anlatımın daha kolay anlaşılabilmesi için dizi değişkenleri üzerinden ilerleyeceğiz ancak burada anlatılanların diğer değişken türleri için de geçerli olduğunu lütfen unutmayın.

**Baştan itibaren verilerin silinmesi;** Bu işlem için kare(**#**) işaretini kullanmamız gerekiyor.
**Sondan itibaren verilerin silinmesi;** Bu işlem için yüzde(**%**) işaretini kullanmamız gerekiyor.

### İlk Eşleşen İfadeye Kadar Olan Kısmın Silinmesi

### Baştan itibaren silmek için;

Örnekte tanımlamış olduğumuz değişken değerlerinin **başından** başlayarak **sadece ilk eşleştiği kısma kadar** olan ifadeleri silmek için;

Komutumuzu `${silinecek[@]#*silinecek_ifade}` şeklinde kullanıyoruz.

### Sondan itibaren silmek için;

Örnekte tanımlamış olduğumuz değişken değerlerinin **sondan** başlayarak **sadece ilk eşleştiği kısma kadar** olan ifadeleri silmek için;

Komutumuzu `${silinecek[@]%silinecek_ifade*}` şeklinde kullanıyoruz.

Örnek üzerinde kullanmış olduğumuz komutların içerisinde yer alan kısımları açıklayacak olursak;

Örneğimizi diziler üzerinden yürüttüğümüz için dizi elemanlarının kapsamını özellikle belirtmemiz gerekiyor.**[@]** şeklinde belirtilen kısım dizideki tüm elemanları kapsıyor.(Bu ifade yerine yıldız(asterix) `` işaretini de kullanabilirdik.)

Kullandığımız kare (**#**) ya da yüzde(**%**) işaretleri baştan veya sondan itibaren **yalnızca ilk eşleşen hedefe kadar olan kısmı** silme işlevinde.

Ayrıca silinecek ifadenin geri kalan kısmının otomatik olarak eşleşebilmesi için yıldız işaretini, duruma göre başta ya da sonda olacak şekilde kullanıyoruz.

**Kare işaretini** kullanırken, **değerin başından** itibaren arama yaptığımız için istediğimiz yani hedeflediğimiz değere ulaşana kadarki kısımda yer alan baştaki herhangi bir değeri temsil etmesi adına **yıldız karakterini başta** kullanıyoruz.

Benzer şekilde **yüzde işareti** ile **değerin sonundan** itibaren arama yaptığımız için istediğimiz yani hedeflediğimiz değere ulaşana kadarki kısımda yer alan herhangi bir değeri temsil edebilmesi için **yıldız karakterini sonda** kullanmamız gerekiyor.

Burada kullanılan yıldız karakterinin neden önemli olduğunu anlamak adına, yıldız karakteri olmadan aynı işlemi tekrar etmenizi öneririm.

### Eşleşen Tüm İfadelere Kadar Olan Kısmın Silinmesi

Eğer hedeflediğimiz karakterlerin geçtiği tüm kısımlar kapsam dahilinde olsun istersek kare ya da yüzde işaretlerini **iki kez** yazmamız gerekiyor. Durumu daha iyi anlamak adına bir kıyaslama yapalım.

Üzerinde işlem yapacağımız kelime "**silinmişti**" olsun.
Kelime içerisindeki hedefimiz de "**i**" karakteri olsun.

Kare ya da yüzde işareti tek sefer kullanıldığında, karşılaşılan ilk "**i**" ifadesinden sonra işlem duracak ve kelime içerisinde yer alan diğer "**i**" karakterleri dikkate alınmayacaktır. Bu durumu zaten daha önceki örneğimizde görmüştük.

Eğer kare ya da yüzde işaretini iki kez kullanırsak; kelime içerisinde geçen tüm hedef "**i**" karakterleri işleme alınacaktır.

İki kullanım arasındaki farkı, çıktıları kıyaslayarak rahatlıkla görebilirsiniz.

Ayrıca söz konusu dizi değişkenleri olunca; tüm ifadeleri tek seferde kapsamak yerine, özel olarak bir ifadeyi de hedefleyebileceğimizi biliyorsunuz.

Örneğin dizide yer alan 3. değerde yer alan **c** harflerine kadar olan kısmı silmek için komutumu `${silinecek[2]#*c}` şeklinde kullanabilirim.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/47.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/47.png)

Eğer bu örneği anlamakta güçlük çektiyseniz, daha önce ele aldığımız dizi değişkenleri konusuna tekrar göz atmanız gerekecektir.

<hr>

Bu kısımdaki örneklerimizi dizi değişkenleri üzerinden yapmış olsak da aslında tüm değişken tipleri için uygulanabilir olduğunu unutmayın lütfen.

Hemen basit birkaç örnek üzerinden bu durumu da teyit etmiş olalım.

```
dizi=(sil silindi silinmişti)

standart="silinmişti"

readonly sabit="silinmişti"

echo  "Dizi çıktısı:"  ${dizi[*]#*i}

echo "Dizi çıktısı:" ${dizi[*]##*i}

echo "Dizi çıktısı:" ${dizi[*]%i*}

echo "Dizi çıktısı:" ${dizi[*]%%i*}

echo "Standart değişken çıktısı:" ${standart[*]#*i}

echo "Standart değişken çıktısı:" ${standart[*]##*i}

echo "Standart değişken çıktısı:" ${standart[*]%i*}

echo "Standart değişken çıktısı:" ${standart[*]%%i*}

echo "Sabit değişken çıktısı::" ${sabit[*]#*i}

echo "Sabit değişken çıktısı::" ${sabit[*]##*i}

echo "Sabit değişken çıktısı::" ${sabit[*]%i*}

echo "Sabit değişken çıktısı::" ${sabit[*]%%i*}

```

Bu kullanımları daha iyi anlamak adına lütfen kendiniz de buradaki örnekler haricinde bol bol alıştırma yapın. Pratik yaptıkça aslında kullanımın ne kadar kolay olduğunu sizler de bizzat deneyimlemiş olacaksınız.

## Değişken Değerinin Değiştirilmesi(Bul-Değiştir İşlemi)

Değişkenlerin konsola basılan değerlerini dilediğimiz başka değerler ile değiştirmek için iki farklı metot bulunuyor.

Örnek çalışma yürütebilmek adına, içerisinde birden fazla "**Linux**" ifadesinin geçtiği basit bir metin kullanıyor olacağız.

Eğer **yalnızca ilk eşleşmede** yer alan ifadeyi değiştirmek istersek komutumuzu **tek slash**(**/**) ile `${degisken/aranan/değiştirilecek}` şeklinde kullanmamız gerekiyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/49.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/49.png)

Şayet **eşleşmelerde yer alan tüm ifadeleri** değiştirmek istersek, **çift slash**(**//**) ile komutumuzu `${degisken//aranan/değiştirilecek}` şeklinde kullanmamız gerekiyor.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/50.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/50.png)

Çıktılarda yer alan ifadeleri kıyasladığınızda tek ve çift slash kullanım farkını çok daha net kavrayabilirsiniz. Ayrıca fark ettiyseniz daha önce de bahsettiğimiz **küçük büyük harf duyarlılığı bu kullanım için de geçerli** olduğundan, yalnızca aradığımız "**linux**" ifadesi bulunup "**çekirdek**" ifadesi ile değiştirilmiş oldu.

Bunun dışında değişiklik yapmak istediğiniz ifade, ille de bir kelime bütünü olmak zorunda değil. Dilersek yalnızca tek bir harfi dahi değiştirebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/51.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/51.png)

## Varsayılan Değerin Kullanılması

Eğer farklı koşullar altında varsayılan olarak tanımlanmış değerin kullanılmasını istersek birkaç farklı şekilde istediğimizi yerine getirebiliriz. Anlatımları öncelikle değişkenler daha sonra diziler üzerinde ele alacağız.

[https://wiki.bash-hackers.org/syntax/pe#use_a_default_value](https://wiki.bash-hackers.org/syntax/pe#use_a_default_value)

## Geçici Varsayılan Değer

### Değişken Tanımlı Değilse Ya Da Boş Değere Sahipse

Eğer değişkenin hiç tanımlanmadığı ya da tanımlanıp da değerinin boş bırakıldığı durumlarda ilgili değişkene bir değer atamak istersek `${DEGISKEN:-DEGER}` genişletmesini kullanabiliyoruz. Bu genişletme değişken üzerinde kalıcı bir değişiklik yapmıyor. Yalnızca o anlık değişken tanımlı değilse ya da boş ise bizim belirttiğimiz değere genişletilmesini sağlıyor.

İlk örnekte tanımlanmamış, ikinci örnekte ise değeri boş olan değişkenin istenilen değişken değerine sahip olduğunu görebilirsiniz. Ayrıca değişkenler üzerinde kalıcı bir değişik meydana gelmediğini değişkeni tekrar bastırmaya çalışarak teyit edebiliyoruz.

```bash
└─$ declare -p degisken
-bash: declare: degisken: not found
└─$ echo ${degisken:-deger}
deger
└─$ echo $degisken
#Çıktı yok..
└─$ degisken=""
└─$ echo ${degisken:-deger}
deger
└─$ echo $degisken
#Sadece boşluk var..
```

İlgili değişkenin değeri boş olmasaydı yani değişken değeri ile tanımlanmış olsaydı, sahip olduğu değeri koruyacaktı. 

```bash
└─$ degisken="ben bir degiskenim"
└─$ echo ${degisken:-deger}
ben bir degiskenim
```

Bu kullanıma; mevcut değişkenin sahip olduğu değeri korumak, değişkenin bulunmadığı ya da değeri olmadığı durumlarda ise varsayılan bir değer tanımlamak için ihtiyacımız olur.

### Yalnızca Değişken Tanımlı Değilse

Eğer değişkenin **yalnızca hiç tanımlı olmadığı durumlarda** varsayılan bir değere sahip olmasını istersek daha önce kullandığımız iki nokta üst üste işaretini kaldırmamız yeterli.

```bash
└─$ declare -p degisken1
bash: declare: degisken1: not found
└─$ echo ${degisken1-deger}
deger
└─$ degisken1=""
└─$ echo ${degisken1-deger}
```

Değişken boş da olsa bir değer sahip olduğu için yalnızca eksi işareti ile genişletme yapıldığında, varsayılan değer kullanılmıyor.

### Dizilerde Geçici Varsayılan Değer Kullanımı

Dizilerde de tıpkı değişkenlerde olduğu gibi benzer işleyiş vardır. Yalnızca toplu şekilde tüm dizi elemanlarının kapsandığı durumlara dikkat etmek gerekir. Çünkü değişkenlerde tek bir değişken üzerinden tanımlanmamış olma ya da boş olma durumu sorgulanarak varsayılan değer tanımlanıyor. Dizi ise birden fazla elemana sahip olduğu için koşulun tüm dizi elemanlarında geçerli olması gerek. Aşağıdaki birkaç farklı yaklaşımı inceleyerek dizi üzerindeki etkisini gözlemeyebilirsiniz.

Dizi tanımlı değilken;

```bash
└─$ unset dizi
└─$ echo ${dizi[*]:-Ben bir diziyim}
Ben bir diziyim
└─$ echo ${dizi[*]-Ben bir diziyim}
Ben bir diziyim
```

Dizi tanımlı fakat elemanı bulunmadığında;

```bash
└─$ dizi=()
└─$ echo ${dizi[*]:-Ben bir diziyim}
Ben bir diziyim
└─$ echo ${dizi[*]-Ben bir diziyim}
Ben bir diziyim
```

Dizi tanımlı ve boş bir elemanı varken;

```bash
└─$ dizi=("")
└─$ echo ${dizi[*]:-Ben bir diziyim}
Ben bir diziyim
└─$ echo ${dizi[*]-Ben bir diziyim}
```

Dizi, boş ve bir adet geçerli elemana sahipken;

```bash
└─$ dizi=("" "eleman")
└─$ echo ${dizi[*]:-Ben bir diziyim}
eleman
└─$ echo ${dizi[*]-Ben bir diziyim}
eleman
```

Tüm bu genişletmelerin geçici olduğunu yani asıl dizi üzerinde etkisi olmadığını zaten biliyorsunuz. Kalıcı değişiklik için okumaya devam edin lütfen.

## Kalıcı Varsayılan Değer Tanımlamak

Daha önce ele aldığımız şekilde anlık olarak etki eden genişletmelerden ziyade ilgili değişken ya da dizi üzerinde kalıcı değişiklik yapan genişletmede bulunmak istersek anlatımın devamındaki metodu uygularız.

### Değişken Tanımlı Değilse Ya Da Boş Değere Sahipse

Bu, varsayılan değerlerin kullanılması gibi çalışır, ancak verdiğiniz varsayılan metin yalnızca genişletmekle kalmaz, aynı zamanda ayarlanmamışsa veya boşsa tam olarak belirtildiği şekilde yeniden tanımlar.

Değişken tanımlı değişken;

```bash
└─$ declare -p yok
bash: declare: yok: not found
└─$ echo ${yok:=DEGER}
DEGER
└─$ echo $yok
DEGER
```

Değişken değeri boşken;

```bash
└─$ bos1=""
└─$ echo ${bos1:=DEGER2}
DEGER2
└─$ echo $bos1
DEGER2
```

Çıktıları incelediğimizde genişletme işleminin değişken üzerinde kalıcı etkisi olduğunu teyit edebiliyoruz.

### Yalnızca Değişken Tanımlı Değilse

Değişken değeri boşken değil de yalnızca hiç tanımlı olmadığı durumda bir değişken adı ve değeri tanımlamak istersek yalnızca eşittir işaretini kullanmamız yeterli.

```bash
└─$ declare -p yok2
bash: declare: yok3: not found
└─$ echo ${yok2=YENIDEGER}
YENIDEGER
└─$ echo $yok2
YENIDEGER
└─$ bos2=""
└─$ echo ${bos2=YENIDEGER}
#boşluk..
└─$ echo $bos2
#boşluk..
```

### Dizilerde Varsayılan Değer Tanımlamak

Diziler üzerinde kalıcı genişletme sınırlı şekilde yapılabilir. Kalıcı genişletme tek bir dizi elemanı için kullanılırsa sorunsuzca çalışır. Ancak toplu şekilde tüm elemanlar üzerinde kalıcı değişiklik denemesi, dizilerin yapısı gereği mümkün değildir.

Tanımlı olmayan diziye eleman tanımlamak;

```bash
└─$ unset dizi
└─$ echo ${dizi[0]:=ELEMAN}
ELEMAN
└─$ declare -p dizi
declare -a dizi=([0]="ELEMAN")
```

Bu şekilde boş olan ya da hiç tanımlanmamış olan dizi elemanlarını tanımlamamız mümkündür. Eğer belirttiğimiz index numarasında ilgili eleman varsa elbette herhangi bir değişiklik olmayacaktır. Çünkü bu kullanımlar elamanın olmadığı ya da boş olduğu durumlar için geçerlidir.

Boş eleman yerine yeni dizi elemanı tanımlamak;

```bash
└─$ bosdizi=("")
└─$ declare -p bosdizi
declare -a bosdizi=([0]="")
└─$ echo ${bosdizi[0]:=DOLDUR}
DOLDUR
└─$ declare -p bosdizi
declare -a bosdizi=([0]="DOLDUR")
```

Elemanın bulunması halinde yeni eleman eklenemez;

```bash
└─$ declare -p bosdizi
declare -a bosdizi=([0]="DOLDUR")
└─$ echo ${bosdizi[0]:=YENI}
DOLDUR
└─$ declare -p bosdizi
declare -a bosdizi=([0]="DOLDUR")
```

### Yalnızca Dizi Tanımlı Değilse

Dizi hiç eleman içermiyorsa ya da hiç tanımlanmadıysa tanımladığımız şekilde genişletilmesi için yalnızca eşittir işaretini kullanmamız gerekir.

```bash
└─$ dizi3=()
└─$ echo ${dizi3[0]=EKLE}
EKLE
└─$ declare -p dizi3
declare -a dizi3=([0]="EKLE")
└─$ unset dizi3
└─$ echo ${dizi3[0]=EKLE}
EKLE
└─$ declare -p dizi3
declare -a dizi3=([0]="EKLE")
```

Gördüğünüz gibi dizi elemansızken veya hiç tanımlı değilken eşittir işareti ile istenilen değere genişletilmiş oldu. Bu kullanım dizinin boş da olsa bir elemanı varsa onu korumak için uygulanır. Nitekim aşağıdaki örnekte boş elemanı olan dize bu yöntem ile korunmuştur.

```bash
└─$ bosdizi2=("")
└─$ declare -p bosdizi2
declare -a bosdizi2=([0]="")
└─$ echo ${bosdizi2[0]=EKLE}
#Sadece Boşluk..
└─$ declare -p bosdizi2
declare -a bosdizi2=([0]="")
```

## Alternatif Değer Kullanımı

Eğer değişken ya da dizi tanımlanmış ve sahip olduğu değerler varsa, bunlar yerine bizim belirteceğimiz alternatif değerlerin kullanılmasını sağlayabiliriz. Bu yapacağımız genişletme değişken üzerinde kalıcı olmayacaktır.

## Değişkenler Üzerinde Alternatif Kullanım

Çalışma yapısını kavramak adına öncelikle hiç tanımlı olmayan değişken üzerinden alternatif değer tanımlayamaya çalışalım.

```bash
└─$ unset yok
└─$ echo ${yok:+DEGER}
#Boşluk..
└─$ echo ${yok+DEGER}
#Boşluk..
└─$ declare -p yok
bash: declare: yok: not found
```

İlgili değişken halihazırda tanımlı olmadığı için alternatif değişken değeri de kullanılamadı. Bu durum yerine değişenin boş değere sahip olduğu duruma örnek verelim.

```bash
└─$ bos=""
└─$ echo ${bos:+DEGER}
#Boşluk..
└─$ echo ${bos+DEGER}
DEGER
└─$ echo $bos
#Boşluk..
```

Çıktıları incelediğinizde yalnızca artı işaretinin bulunduğu genişletmenin boş değişken değeri üzerinde genişletme etkisine sahip olduğunu teyit edebilirsiniz. Teyit işlemini ilerletmek adına bu sefer değere sahip olan değişken üzerinde anı işlemi uygulayalım.

```bash
└─$ degisken="ben degiskenim"
└─$ echo ${degisken:+DEGER}
DEGER
└─$ echo $degisken
ben degiskenim
└─$ echo ${degisken+DEGER}
DEGER
└─$ echo $degisken
ben degiskenim
```

Neticede var olan değişkenler yerine alternatif değişken değerlerine genişletme yapmak için artı işaretini kullanabileceğimizi görmüş olduk. 

### Dizilerde Alternatif Değerin Kullanılması

Tek bir dizide birden fazla dizi elemanı bulanabileceği için alternatif değerlerin kullanımı noktasında dikkat etmemiz gereken detaylar var. Dizide tek bir eleman olduğunda tıpkı değişkenlerde olduğu gibi benzer kullanım söz konusudur. Eğer dizi içeriği boş da olsa bir elemana sahipse yalnızca artı işareti kullanımı ile bu boşluğa alternatif olan bir genişletme uygulanabiliyor. Bunun haricinde eğer dizide hiç eleman tanımlı değilse elbette, alternatif genişletme de uygulanamıyor. Çünkü alternatif genişletme yapısı gereği bir değerin "alternatifi" olmak üzere kullanılır. Tek elemanlı diziler değişkenler ile aynı olduğu için örnekler ile uzatmaya gerek yok.

Söz konusu birden fazla elemanı bulunan diziler olduğunda ve bunların hepsini kapsayarak işlem yapmak istediğimiz de:

- Yalnızca boş öge olamayan dizi elemanlarını genişletmek için :+ kullanılır.
- Minimum bir dizi elemanı boş öge değilken :+ ya da + genişletmesi kullanılabilir.

## Genişletme Hatası Döndürmek

Değişken ya da dizi elemanı tanımlanmışsa veya boş bir değere sahip değilse sorunsuzca kendi değerine genişletilir. Eğer tersi şekilde boş değere sahipse ya da hiç tanımlanmamışsa bizim istediğimiz bir hata çıktısını döndürebilir.

```bash
└─$ degisken="ben bir degiskenim"
└─$ echo ${degisken:?HATA-MESAJIM}
ben bir degiskenim
└─$ bos=""
└─$ echo ${bos:?HATA-MESAJIM}
bash: bos: HATA-MESAJIM
└─$ unset yok
└─$ echo ${yok:?HATA-MESAJIM}
bash: yok: HATA-MESAJIM
```

İki nokta üst üste işareti olmadan kullandığımızda ise, boş ögeler de hata çıktısına sebep olmaz.

```bash
└─$ echo ${yok?HATA-MESAJIM}
bash: yok: HATA-MESAJIM
└─$ echo ${bos?HATA-MESAJIM}
```

Bu kullanım değişken ya da dizilerin varlığını veya sahip olduğu değerleri sorgulayıp yokluğunda hata üretmemizi sağlar. Değişkenler üzerinden örnek verdik ancak dizilerde de aynı şekilde çalışır. Çoklu elemana sahip olan dizilerde tek bir elemanın bulunması, tüm dizi bu şekilde genişletildiğinde hata mesajı döndürülmesine engel olmaya yeter. Aşağıdaki çıktıları dikkatlice incelemeniz diziler üzerindeki etkisini anlamaya yetecektir.

```bash
└─$ dizi=("" "" ELEMAN)
└─$ echo ${dizi:?HATA-MESAJIM}
bash: dizi: HATA-MESAJIM
└─$ echo ${dizi?HATA-MESAJIM}
#Buradası boşluk çünkü ilk eleman da boştu.
└─$ echo ${dizi[*]:?HATA-MESAJIM}
ELEMAN
└─$ echo ${dizi[*]?HATA-MESAJIM}
ELEMAN
```

### Genişletme Operatörlerinin Kullanımı

Parametrelerin ardından `@` işaretiyle birlikte kullanabileceğimiz genişletme operatörleri bulunuyor.

Kullanımı  `**${parametre@operator}`** şeklindedir. Kullanılabilir olan operatörler;

- `U` : Tüm harflerin büyük karakteri ile genişletilmesi.
- `u` : İlk harfin büyük karakter ile genişletilmesi.
- `L` : Büyük harflerin küçük harfler ile genişletilmesi.
- `Q` : Genişletmenin girdi olarak kullanılabilecek şekilde alıntılı çıktı üretmesi.
- `E` : Ters eğik çizgi de dahil olacak şekilde genişletilmesi.
- `P` : Çıktının bilgi istemi şeklinde genişletilmesi. [https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html](https://www.gnu.org/software/bash/manual/html_node/Controlling-the-Prompt.html)
- `A` : Declare aracı ile yeniden kullanılabilecek şekilde genişletilmesi.
- `K` : Endekslenmiş ve ilişkilendirilebilir dizilerin değerlerini, tırnak içine alınmış anahtar-değer çiftleri dizisi olarak genişletir.

## Komut İkamesi (Command substitution)

"Komut ikamesi", bir komutu çalıştırmanıza ve bu komutun çıktısının komut metninin yerini almasına(yerine koymanıza) izin veren kabuk dili özelliğinin adıdır. Dolar işaretinden sonra parantez içinde yazdığımız ya da ters tırnak içerisine aldığımız tüm ifadeler bu kapsamda değerlendirilir. Bu özellik komut çıktılarının metinsel olarak tekrar işlenebilmesi veya çıktıların bir başka komuta argüman olarak iletilmesi için sık kullanılır. Eski sürüm bash kabuğunda `$(komut)` yerine ters tırnak ``komut`` kullanıyordu. Ancak ters tırnağın okunması ve iç içe kullanımı karmaşaya sebep olduğu için eski sürümlerde çalışmak zorunda olmadıkça tercih edilecek bir alternatif değildir. Yani özellikle eski sürümde çalışmayacaksa komut ikamesi için ters tırnak kullanmayın. 

[http://www.compciv.org/topics/bash/variables-and-substitution/#:~:text=Command substitution allows the output,with any trailing newlines deleted](http://www.compciv.org/topics/bash/variables-and-substitution/#:~:text=Command%20substitution%20allows%20the%20output,with%20any%20trailing%20newlines%20deleted).

Üstelik komut ikamesinin yürüttüğü komut bir alt kabukta yürütülür, yani ana kabuğun ortamını etkilemeyecek kendi ortamı vardır. Bash komut ikamesi içindeki komutu alt kabukta çalıştırıp standart çıktılarını komutun kendisi ile değiştirir. Zaten bu sebeple genişletmenin adı "komut ikamesi" olarak geçiyor. Örneğin bir dosya içeriğini okumak istediğinizde aşağıdaki şekilde konsola çıktı bastırabiliriz.

[https://stackoverflow.com/questions/51937702/what-is-the-difference-between-cat-file-file-and-read-file-f](https://stackoverflow.com/questions/51937702/what-is-the-difference-between-cat-file-file-and-read-file-f)

- `line=$(cat input)` is the POSIX way of reading the entire file. It requires a fork.
- `line=$(< input)` is a marginally more efficient Bashism for reading the entire file. It also forks, but doesn't have to execve.
- Not mentioned but `mapfile`/`readarray` are significantly more efficient Bashisms for reading the entire file line-by-line into arrays. No forks.
- `IFS= read -r line < input` is the POSIX way of reading a single line without a subshell. No forks.

The reason why you only see the latter opening the file is simply that the others do it in a subshell, and you haven't specified `-f` to trace child processes.

Gerektiğinde komut ikamesini iç içe de kullanabiliriz. Aşağıda hem yeni hem de eski yöntem ile komut ikamesinin iç içe kullanıldığı örnek bulunuyor.

```bash
~ → echo sonuc: $(echo ilk $(echo ikinci $(echo üçüncü $(echo son))))
sonuc: ilk ikinci üçüncü son
~ → echo sonuc: `echo ilk \`echo ikinci \\\`echo üçüncü \\\\\\\`echo son\\\\\\\`\\\`\``
sonuc: ilk ikinci üçüncü son
```

Sanırım çıktıları incelediğinizde eski metodun yani ters tırnağın özellikle iç içe kullanılmasının oluşturabileceği karmaşa konusunda bana hak vermişsinizdir. Buradaki örnek kolay anlaşılır olabilmesi adına son derece basit tutuldu. En içten başlayarak tüm çıktılar bir üst komut ikamesinin yerini aldı ve en sonunda ana komut ikamesi tüm komutların çıktıları ile beraber genişletilmiş oldu.

Her ne kadar verilen örnek basit olsa da sizler bu şekilde iç içe istediğiniz komutların çalıştırılıp, komut çıktılarının bir üst komut için argüman olarak kullanılmasını sağlayabilirsiniz.

Ayrıca eğer ikame çift tırnak ile sonuç veriyorsa, sonuçlarda kelime bölme ve dosya adı genişletme yapılmaz. Çünkü çift tırnak bir bütün halindeki metinsel veriyi temsil eder.

## Aritmetik Genişleme

Aritmetik genişleme, bir aritmetik ifadenin değerlendirilmesine ve sonucun ikame edilmesine izin verir. Aritmetik genişletme biçimi şu şekildedir:

```bash
$(( expression ))
```

İfade, çift tırnak içindeymiş gibi ele alınır, ancak parantez içindeki çift tırnak özel olarak ele alınmaz. İfadedeki tüm simgeler, parametre ve değişken genişletmeye, komut ikamesine ve alıntı kaldırmaya tabi tutulur. Sonuç, değerlendirilecek aritmetik ifade olarak kabul edilir. Aritmetik genişletmeler yuvalanmış olabilir.

Değerlendirme, aşağıda listelenen kurallara göre gerçekleştirilir (bkz. Kabuk Aritmetiği). İfade geçersizse, Bash, standart hatanın başarısız olduğunu belirten bir mesaj yazdırır ve hiçbir değişiklik yapılmaz.

Bu listeyi aritmetik işlemler bölümünde ele al ve buradan oraya atıfta bulun.

# **Kabuk Aritmetiği**

Kabuk, aritmetik ifadelerin, kabuk genişletmelerinden biri olarak veya `((`bileşik komut, `let`yerleşik veya-ben`declare`yerleşik seçeneği .

Değerlendirme, taşma kontrolü olmaksızın sabit genişlikli tam sayılarla yapılır, ancak 0'a bölme yakalanır ve bir hata olarak işaretlenir. Operatörler ve bunların önceliği, ilişkilendirilebilirliği ve değerleri C dilindekilerle aynıdır. Aşağıdaki işleç listesi, eşit öncelikli işleç düzeylerine göre gruplandırılmıştır. Seviyeler, azalan öncelik sırasına göre listelenmiştir.

***`id*++ *id*--`**değişken artış sonrası ve azaltma sonrası**`++*id* --*id*`**değişken ön artış ve ön azaltma**`- +`**tekli eksi ve artı**`! ~`**mantıksal ve bitsel olumsuzlama**`**`**üs alma**`* / %`**çarpma, bölme, kalan**`+ -`**toplama çıkarma**`<< >>`**sol ve sağ bitsel kaymalar**`<= >= < >`**karşılaştırma**`== !=`**eşitlik ve eşitsizlik**`&`**bitsel AND**`^`**bit düzeyinde özel VEYA**`|`**bitsel VEYA**`&&`**mantıksal AND**`||`**mantıksal VEYA**`expr ? expr : expr`**koşullu operatör**`= *= /= %= += -= <<= >>= &= ^= |=`**Görev**`expr1 , expr2`**virgül

Kabuk değişkenlerine işlenenler olarak izin verilir; ifade değerlendirilmeden önce parametre genişletme gerçekleştirilir. Bir ifade içinde, kabuk değişkenlerine, parametre genişletme sözdizimi kullanılmadan adla da başvurulabilir. Boş olan veya ayarlanmayan bir kabuk değişkeni, parametre genişletme sözdizimi kullanılmadan adla başvurulduğunda 0 olarak değerlendirilir. Bir değişkenin değeri, başvurulduğunda aritmetik bir ifade olarak veya '' kullanılarak *tamsayı* özniteliği verilen bir değişkene göre değerlendirilir. beyan -ibir değer atanır. Boş değer 0 olarak değerlendirilir. Bir kabuk değişkeninin bir ifadede kullanılması için *tamsayı* özniteliğinin açık olması gerekmez.

Tamsayı sabitleri, son ekler veya karakter sabitleri olmadan C dili tanımını takip eder. Başında 0 olan sabitler sekizlik sayılar olarak yorumlanır. Bir lider '0x'veya'0X'onaltılı gösterir. Aksi takdirde, sayılar [ *taban*`#` ] *n* biçimini alır; burada isteğe bağlı *taban* , aritmetik tabanı temsil eden 2 ile 64 arasında bir ondalık sayıdır ve *n* , bu tabandaki bir sayıdır. Eğer *temel*`#` atlanırsa, o zaman temel 10 kullanılır. *N* belirtirken , rakam olmayan bir rakam gerekliyse, 9'dan büyük rakamlar küçük harflerle, büyük harflerle temsil edilir, '@', ve '_', bu sırayla. Eğer *taban* az ya da 36, küçük harf ve harfler 10 ile 35 arasındaki sayıları temsil etmek için birbirinin yerine kullanılabilir büyük eşittir.

Operatörler öncelik sırasına göre değerlendirilir. Parantez içindeki alt ifadeler önce değerlendirilir ve yukarıdaki öncelik kurallarını geçersiz kılabilir.

## İşlem İkamesi

İşlem ikamesi, parantez içerisinde yazılmış olan komutların sonuçlarını dışarı aktarmayı ya da dışarıdan parantez içindeki komuta veri aktarmayı mümkün kılar. 

`<(komutlar..)` kullanımı ile parantez içindeki komutların çıktılarını, öncesindeki komuta argüman olarak aktarır.

`>(komutlar..)` kullanımı ise kendisinden önce girdi sağlanırsa, alınan girdiler parantez içindeki komutlara argüman olarak iletilir.

`<>(komutlar..)` kullanımı ile girdiler ve çıktılar iletilir.

Bu konu altkabuk kavramı ile yakından ilişkili.

İşlem ikamesi isimli boruların yani fifo ya da /dev/fd dosya tanımlayıcısı yöntemini destekleyen sistemlerde kullanılabilir. Buradaki işlem ikamesi ilgili komutun dosya adı olarak geçmesini sağlar. Böylelikle dosya gibi okunup gerektiğinde dosyaya aktardığımız şekilde verileri aktarabiliriz.

Eğer aynı anda kullanılırsa; işlem ikamesi parametre ve değişken genişletme, komut ikamesi ve aritmetik genişletme ile eşzamanlı olarak gerçekleştirilir.

## Sözcük Bölme

Normalde kabuğumuz, emir olarak vermiş olduğumuz komutları aralarındaki tek boşluk karakteri sayesinde kelime guruplarına ayırır ve bu şekilde işler. Kelime guruplarının boşluk karakteri ile ayrılması gerektiğini IFS değişkeni belirtir. Eğer bu değişkenin değeri başka bir kuralı tanımlayacak şekilde değiştirilirse, kabuk kelimeleri bu kurala göre gruplamaya çalışır.  Sözcük bölme işlemi çift tırnak içindeki veriler üzerinde uygulanmaz çünkü tırnak içindeki verilerin hepsi tırnak sayesinde tek veri olarak ele alnınır.

## Dosya Adı Genişletme

## Alıntı Kaldırma

Sözcüklerin alıntı karakterleri bazı durumlarda otomatik olarak kaldırılır. Örneğin `echo "test metni"` yazdığımızda, konsola yalnızca ***test metni*** ifadesi basılır. Çünkü burada eklemiş olduğumuz çift tırnaklar yalnızca kelime bütününü doğru şekilde ifade etmek için kullanılmıştır. Eğer konsola çıktı olarak çift tırnak bastırmak istersek, kaçış karakteri ile bu durumu özellikle belirtebiliriz. Zaten bu durumdan echo komutunu ele alırken bahsetmiştik. Burada bilmeniz gereken detay, kimi durumlarda tırnak işaretinin kabuk tarafından otomatik olarak kaldırılacağıdır. Ayrıca burada bahsi geçen "alıntı" yani tek ve çift tırnak kullanımının da genişletme biçimi açısından farklı fonksiyonları vardır.

## Tek ve Çift Tırnak Kullanımının Genişletmeye Etkisi

Alıntı yapmak

Artık kabuğun genişletmeleri kaç şekilde gerçekleştirebileceğini gördüğümüze göre, onu nasıl kontrol edebileceğimizi öğrenmenin zamanı geldi. Örneğin alın:

[me @ linuxbox me] $ **`echo this is a     test`**
bu bir testtir

veya:

[me @ linuxbox me] $ **`[me@linuxbox ~]$ echo The total is $100.00`**
Toplam 00.00

İlk örnekte, kabuk tarafından sözcük bölünmesi, echo komutunun argümanlar listesinden fazladan boşlukları kaldırdı. İkinci örnekte, parametre genişletme, tanımsız bir değişken olduğu için "$ 1" değerinin yerine boş bir dizeyi değiştirdi. Kabuk, istenmeyen genişletmeleri seçici olarak bastırmak için alıntı adı verilen bir mekanizma sağlar .

# İkili alıntı

Bakacağımız ilk alıntı türü çift tırnaktır. Metni çift tırnak içine koyarsak, kabuğun kullandığı tüm özel karakterler özel anlamlarını kaybeder ve sıradan karakterler olarak değerlendirilir. İstisnalar "$", "\" (ters eğik çizgi) ve "" "(ters tırnak) şeklindedir. Bu, sözcük bölme, yol adı genişletme, yaklaşık işareti genişletme ve küme ayracı genişletmesinin bastırıldığı, ancak parametre genişletme, aritmetik genişletme ve komut ikamesinin hala yürütüldüğü anlamına gelir. Çift tırnak kullanarak, gömülü boşluklar içeren dosya adlarıyla baş edebiliriz. Denilen bir dosyanın talihsiz kurbanı olduğumuzu hayal edin `two words.txt`. Bunu komut satırında kullanmaya çalışırsak, kelime bölme, bunun istenen tek bağımsız değişken yerine iki ayrı bağımsız değişken olarak değerlendirilmesine neden olur:

[me @ linuxbox me] $ **`ls -l two words.txt`**
ls: iki kişiye erişilemiyor: Böyle bir dosya veya dizin yok ls: word.txt'ye erişilemiyor: Böyle bir dosya veya dizin yok

Çift tırnak kullanarak, kelime bölmeyi durdurabilir ve istenen sonucu alabiliriz; ayrıca hasarı onarabiliriz:

[me @ linuxbox me] $ **`ls -l "two words.txt"`**
-rw-rw-r-- 1 me me 18 2020-02-20 13:03 iki word.txt [me @ linuxbox me] $**`mv "two words.txt" two_words.txt`**

Orada! Şimdi bu sinir bozucu çift tırnakları yazmaya devam etmemize gerek yok. Unutmayın, parametre genişletme, aritmetik genişletme ve komut ikamesi hala çift tırnak içinde gerçekleşir:

[me @ linuxbox me] $ **`echo "$USER $((2+2)) $(cal)"`**
me 4 Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29

Çift tırnağın komut ikamesi üzerindeki etkisine bakmak için biraz zaman ayırmalıyız. Önce, kelime bölmenin nasıl çalıştığına biraz daha derinlemesine bakalım. Önceki örneğimizde, sözcük bölmenin metnimizdeki fazladan boşlukları nasıl kaldırdığını gördük:

[me @ linuxbox me] $ **`echo this is a     test`**
bu bir testtir

Varsayılan olarak, sözcük bölme boşlukların, sekmelerin ve satırsonu satırlarının (satır besleme karakterleri) varlığını arar ve bunları sözcükler arasındaki sınırlayıcılar olarak ele alır. Bu, tırnaksız boşlukların, sekmelerin ve yeni satırların metnin parçası olarak kabul edilmediği anlamına gelir. Sadece ayırıcı görevi görürler. Kelimeleri farklı argümanlara ayırdıklarından, örnek komut satırımız bir komut ve ardından dört farklı argüman içerir. Çift tırnak eklersek:

[me @ linuxbox me] $ **`echo "this is a     test"`**
bu bir testtir

sözcük bölme bastırılır ve gömülü boşluklar sınırlayıcı olarak değerlendirilmez, bunun yerine argümanın bir parçası olurlar. Çift tırnaklar eklendiğinde, komut satırımız bir komut ve ardından tek bir argüman içerir. Satır satırlarının kelime bölme mekanizması tarafından sınırlayıcı olarak kabul edilmesi, komut ikamesi üzerinde ince de olsa ilginç bir etkiye neden olur. Aşağıdakileri göz önünde bulundur:

[me @ linuxbox me] $ **`echo $(cal)`**
Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 [me @ linuxbox me ] $  **`echo "$(cal)"`**
Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29

İlk durumda, alıntılanmamış komut ikamesi otuz sekiz argüman içeren bir komut satırı ile sonuçlandı. İkincisinde, gömülü boşlukları ve yeni satırları içeren bir bağımsız değişken içeren bir komut satırı.

# Tek Alıntılar

Tüm genişletmeleri bastırmamız gerektiğinde tek tırnak kullanırız. İşte tırnaksız, çift tırnak ve tek tırnakların karşılaştırması:

[me @ linuxbox me] $ **`echo text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER`**
text /home/me/ls-output.txt ab foo 4 me [me @ linuxbox me] $ **`echo "text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER"`**
text ~ / *. txt {a, b} foo 4 me [me @ linuxbox me] $ **`echo 'text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER'`**
metin ~ / *. txt {a, b} $ (echo foo) $ ((2 + 2)) $ USER

Gördüğümüz gibi, birbirini izleyen her alıntı düzeyinde, genişlemelerin sayısı gittikçe daha fazla bastırılıyor.

## Genişletme Sırası

Genişletme işlemi yapılırken anlam kaybı yaşanmaması için tıpkı matematik işlemlerinde olduğu gibi uyulması gereken bir sıralama vardır. Bash kabuğu kendisine emir olarak verilmiş olan metin dizesini aşağıdaki sıraya uygun şekilde genişleterek anlamlandırmaya çalışır.

Bash kabuğundaki genişletmeler **soldan sağa doğru** olacak şekilde aşağıdaki sıralama ile gerçekleştirilir: 

1- Tilde genişletme, parametre genişletme, komut ikamesi ve aritmetik genişletme aynı anda uygulanır. Ayrıca eğer mevcut sistem destekliyorsa işlem ikamesi de bu aşamada genişletilir.

2- Alan bölme, IFS yani kelimeler arası boşluğun türünü belirten değişken boş olmadığı sürece, 1. adımda oluşturulan alanların kısımlarında gerçekleştirilecektir.

3- Dosya adı genişletmesi, `set -f` yani **noglob** özelliği aktif değilse uygulanır.

4- Tüm genişletmeler uygulandıktan sonra yani en son tırnak işaretleri kaldırılır.

[https://unix.stackexchange.com/questions/270274/how-to-understand-the-order-between-expansions](https://unix.stackexchange.com/questions/270274/how-to-understand-the-order-between-expansions)

Genişletme sıralaması, genişletmelerin nasıl çalıştığını öğrendikten sonra çok daha anlaşılır olacaktır.

Genişletme sırlamasını kavramak için aşağıdaki basit örneğe göz atabilirsiniz.

```bash
└─$ x=3; echo $x$((x=9))$x
399
```

Soldan sağa doğru genişletme yapıldığı için ilk x değişkeninin değeri 3 olarak genişletiliyor. Daha sonra aritmetik genişletme x in değerini 9 olarak genişletiyor. Değeri genişletilerek değiştirilen x değişkeni de neticede 399 sayısını veriyor.

Tilde genişletmesi tırnak içinde sonuç verdiği için /home/foo bar şeklinde bir ev dizini kelime bölücü tarafından foo ve bar olarak ayrılmaz. Zaten dikkat edecek olursanız genişletme sıralaması da tilde işaretinin ilk olarak genişletilmesine uygun yapıdadır. Tilde tırnak içinde ev dizinine genişletilir. Kelime bölücü tırnak içinde olduğu için foo bar kelimesini tek bir kelime olarak bırakır. En son tırnak işareti kaldırılarak tilde genişletmesi sorunsuzca uygulanmış olur. Zaten tüm genişletme sıralaması makul ve kullanılabilir bir genişletme deneyimi için tasarlanmıştır.

taylan@DESKTOP-E4TGC85:~$ echo "$USER"
taylan
taylan@DESKTOP-E4TGC85:~$ echo '$USER'
$USER
taylan@DESKTOP-E4TGC85:~$

[https://sysadmins.nl/abs/regexp.html](https://sysadmins.nl/abs/regexp.html)

[https://ceaksan.com/tr/wildcards-kullanimi](https://ceaksan.com/tr/wildcards-kullanimi)

Bash kabuğu diğer pek çok programlama dilinin aksine "regex(Regular Expressions)" yani "düzenli ifadeleri" desteklemez. Bunun yerine kendi bünyesinde globbing olarak isimlendirdiği joker karakterleri(wildcards) kullanır. Normal şartlarda düzenli ifadeler çok daha geniş kullanım seçeneği sunsa da, bash kabuğunu için joker karakterlerin kullanımı yeterli oluyor. Çünkü zaten bash kabuğu üzerinde temel olarak dosya ve dizinleri bulmak yeterli oluyor. Metin işleme söz konusu olduğunda bash kabuğu haricinde pek çok alternatif program kullanabiliyoruz. Ve bu programlar da düzenli ifadeleri destekliyor. 

Globbing olarak geçen joker karakterler bash kabuğu üzerinde kullanılırlar. Regular Expressions olarak geçen düzenli ifadeler ise genellikle metin işlemede kullanılırlar. 

# Düzenli İfadeler Ve Karakter Sınıfları

## Ölümlüler için Düzenli İfadeler (Regular Expressions (Regex))

Regular exp bash üzerinde desteklenme kapsamı hakkında süper kaynak; [https://medium.com/introduction-into-bash/bash-scripts-regular-expressions-7d1a0473a902](https://medium.com/introduction-into-bash/bash-scripts-regular-expressions-7d1a0473a902)

Düzenli ifadeler, özellikle programlama yaparken verilerin aradığımız niteliklere göre sınırlandırılması ve sınırlandırılan verilerin istenildiği şekilde çekilmesi adına bizlere yardım eder.

Ayrıca anlatımlarda; düzenli ifadelerin daha önce temel linux eğitimde değinmiş olduğumuz **joker karakterleri** de içerisinde barındırdığını ve joker karakterlere benzer ancak daha kapsamlı seçenekler sunduğunu da görmüş olacağız. Lafı daha fazla uzatmadan örnekler üzerinden düzenli ifadelerin işlevlerine göz atalım.

Başlamadan evvel, burada yer alan bilgilerin ve kullanımların tam anlaşılabilmesi için buradaki örneklerin haricinde sizlerin de pek çok alıştırma yapması gerektiğini lütfen unutmayın. Bilgilerin kalıcı olması adına lütfen buradaki örneklerin dışına çıkarak, bolca alıştırma yapın.

# **[]**

Kullanımı, iki köşeli parantez arasına ulaşmak istediğiniz hedefteki ayırt edici karakterleri yazmak üzerinedir.

Örnek olması açısından "**dosya**" isimli belgelerden sadece sonunda **2,3,4** olanları kapsayacak bir komut olması için konsola `ls -l [234]` komutunu verdim.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/6.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/6.png)" width="875">

Bir örnek daha verelim.

**[Dd]osya[Aa]dı** şeklinde bir belirtme; **DosyaAdı, Dosyaadı, dosyaAdı, dosyaadı** şeklindeki bütün isimleri kapsayacaktır. Bu sayede ilgili dosyalar için tüm küçük büyük harf kombinasyonu kolaylıkla sağlanmış olur.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/7.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/7.png)" width="875">

Ayrıca kullanım şekillerine çok fazla örnek verilebilir ancak burada birkaç örnek daha vererek keşfi size bırakıyorum.

**Not** : Burada belirtilen **x y z** temsili değerleri ifade etmektedir !

**[0-9] :** 0'dan 9'a kadar olan rakamları kapsar.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/8.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/8.png)" width="875">

**[x,y,z] :** belirtilen değerlerle eşleşenleri basar.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/9.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/9.png)" width="875">

**[x-z] :** x ile z değerleri arasındaki karakterlerle eşleşir.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/10.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/10.png)" width="875">

**[xyz] :** belirtilen değerlerle eşleşenleri basar.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/11.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/11.png)" width="875">

**[!xyz] :** Belirtilen karakterlerin dışındakileri diğer tüm karakterleri basar.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/12.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/12.png)" width="875">

**[!x-z] :** Verilen x ile z değeri arasındaki değerler haricindeki karakterler basar.

<img src="[https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15- Joker Karakterler/13.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/15-%20Joker%20Karakterler/13.png)" width="875">

# **{}**

Kıvırcık parantez de köşeli paranteze benzer şekilde içerisine girilen ifadelere göre çalışır.

Çalışma yapısını anlamak için aşağıdaki örneklere göz atabilirsiniz.

**{x,y,z} :** içerisinde virgüller ile ayrılmış ifadeleri tek tek basar.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/kvr0.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/kvr0.png)" width="875">

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/kvr1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/kvr1.png)" width="875">

**{x..y} :** iki ifade arasına koyulan **iki nokta**(**..**) sayesinde otomatik olarak başlangıç karakterinden son karaktere gelinceye kadar sıralı çıktılar elde edebiliyoruz. Tam kullanımı `{başlangıç_ifadesi..bitiş_ifadesi}` şeklindedir.

**Kullanım örnekleri;**
Rakam ya da harflerin istenildiği yerden başlayıp istenildiği kısıma kadar sıralanması sağlanabilir.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/kvr2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/kvr2.png)" width="875">

Üstelik bu sıralama birer birer artmak zorunda da değil. İstenilen aralıkta artışın yapılması `{başlangıç_ifadesi..bitiş_ifadesi..artış_aralığı}` şeklindeki kullanım ile sağlanabilir.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/kvr3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/kvr3.png)" width="875">

# **nokta(.)**

Noktanın bulunduğu yere gelebilecek herhangi bir karakteri temsil eder.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/1.png)" width="875">

# **^**

Satır başını temsil eder.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/2.png)" width="875">

# **$**

Satır sonunu temsil eder.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/3.png)" width="875">

# **[^..]**

Kümede belirtilen karakterler haricindeki tüm karakterleri kapsar. Ayrıca şapka işareti yerine **ünlem işareti(!)** de kullananabiliriz.

Şimdi birkaç farklı örnek ile kullanımı ele alalım;

Örneğin sonunda rakam bulunan dosyaları listelemek istemezsek komutumuzu `ls *[^0-9]` şeklinde girebiliriz. Bu sayede `ls` komutu başlangıcı ne olursa olsun sonunda rakam yer alan dosyaları liste dışı bırakıyor.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/4.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/4.png)" width="875">

Daha net anlaşılması adına bir örnek daha; * işaretinin sona koyulması ile hariç tutma durumu, başlangıcında rakam yer alan dosyalar için de uygulanabilir.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/5.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/5.png)" width="875">

Ayrıca örneklerde ele aldığımız hariç tutma durumunu, ihtiyacımıza göre rakamlar yerine harfler ya da özel karakterler için de kullanabiliyoruz.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/6.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/6.png)" width="875">

# **\\{x\\}**

Kendisinden önceki karakterin **tam olarak x** kez tekrar edildiğiniz belirtir.

Örneğin **2 kez a** harfinin geçtiği tüm kelimeleri listelemek istersek, `grep` komutu yardımı ile `a\\{2\\}` düzenli ifadesini kullanabiliriz.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/7.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/7.png)" width="875">

# **\\{x,\\}**

Kendisinden önceki karakterin **en az x kez** tekrar edildiğiniz belirtir.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/8.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/8.png)" width="875">

# **\\+**

Kendisinden önceki karakterin **1 ya da daha fazla** olduğunu, diğer bir deyişle **en az 1 kez** bulunduğu durumları belirtir.
<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/10.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/10.png)" width="875">

# **\\?**

Kendisindne önceki karakterin 0 ya da 1 kez oldğunu belirtir.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/11.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/11.png)" width="875">

# **\\|**

Kendisindne bir önceki veya bir sonraki karaktere denk gelir.
<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/12.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/12.png)" width="875">

# **xyz\\<**

xyz ile başlayan satırları kapsar.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/13.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/13.png)" width="875">

# **xyz\\>**

xyz ile biten satırları kapsar.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/14.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/14.png)" width="875">

# **\\**

Özel karakterlerin normal karakterler olarak algılanmasını sağlarlar.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/15.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/15.png)" width="875">

**Kullanım Örnekleri**

## Karakter Sınıfları

Karakter sınıflarını; bir önceki kısımda ele aldığımız düzenli ifadelerin sıklıkla kullanılan özelliklerinin kalıplaşmış kısayol hali olarak düşünebilirsiniz. Bu ne demek oluyor ?

**Açıklayalım;**

Örneğin biz yalnızca noktalama işaretleri içeren verileri almak istediğimizde düzenli ifadeler ile bunları tek tek tanımlamamız gerekiyorken, bunun yerine daha önceden tanımlanıp sınıf haline getirilmiş olan **punct** karakter sınıfını kullanabiliriz.

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/16.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/16.png)" width="875">

Kısacası karakter sınıfları sık kullanılan filtreleme seçeneklerinin bir araya getirildiği düzenli ifade demetleridir. Eğer filtreleyeceğimiz veri, bu sık kullanılan düzenli ifade demetine dahil ise, uzun uzadıya yazmak yerine yazdığımız kodun daha derli toplu olması adına karakter sınıfını kullanabiliriz. Ancak filtreleyeceğimiz veri çok daha spesifik ise düzenli ifadeleri kullanmamız gerekir.

Anlatmak istediğim konuyu en iyi örnekler açıklayacaktır.

Öncelikle kullanabileceğimiz temel sınıflara aşağıdaki tablo ile göz atalım.

[Untitled](8-%20Metin%20I%CC%87s%CC%A7leme%20ve%20Genis%CC%A7letme%2061f15a5e3b8b4b8da14db7a06cea6115/Untitled%20Database%2080ca6d8190e14e8abe2b89c5187ea5fe.md)

Tablodan da anlayacağınız gibi belirli özellikler için sınırlandırılmış ifadeler bulunuyor. Bu ifadelerin kullanım örneklerine aşağıdaki görsellerden bakabilirsiniz.

# digit

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/17.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/17.png)" width="875">

# lower

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/18.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/18.png)" width="875">

# upper

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/19.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/19.png)" width="875">

# alpha

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/20.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/20.png)" width="875">

# alnum

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/21.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/21.png)" width="875">

# punct

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/22.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/22.png)" width="875">

# graph

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/23.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/23.png)" width="875">

# blank

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/24.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/24.png)" width="875">

# space

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/25.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/25.png)" width="875">

# print

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/26.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/26.png)" width="875">

# xdigit

<img src="[https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/Düzenli İfadeler/27.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/D%C3%BCzenli%20%C4%B0fadeler/27.png)" width="875">

Her seferinde bir komut satırı yazıp enter tuşuna bastığımızda, bash komutumuzu yerine getirmeden önce metin üzerinde birkaç işlem gerçekleştirir. Basit bir karakter dizisinin, örneğin "*", kabuk için ne kadar çok anlamı olabileceğine dair birkaç durum gördük. Bunu gerçekleştiren sürece genişleme denir . Genişlemeyle bir şey yazıyoruz ve kabuk üzerine etki etmeden önce o başka bir şeye genişletiliyor. Bununla ne demek istediğimizi göstermek için **`[echo](https://linuxcommand.org/lc3_man_pages/echoh.html)`**komuta bir göz atalım . **`echo`**çok basit bir görevi yerine getiren bir kabuk yerleşiktir. Metin bağımsız değişkenlerini standart çıktıya yazdırır:

[me @ linuxbox me] $ **`echo this is a test`**
bu bir testtir

Bu oldukça basit. Aktarılan herhangi bir bağımsız değişken **`echo`**görüntülenir. Başka bir örnek deneyelim:

[me @ linuxbox me] $ **`echo *`**
Masaüstü Belgeleri ls-output.txt Müzik Resimleri Genel Şablonlar Videolar

Peki ne oldu? Neden **`echo`**"*" yazmadı ? Joker karakterlerle yaptığımız çalışmalardan hatırladığımız gibi, "*" karakteri bir dosya adındaki herhangi bir karakterle eşleşmek anlamına gelir, ancak orijinal tartışmamızda görmediğimiz şey kabuğun bunu nasıl yaptığıydı. Basit cevap, **`echo`**komut yürütülmeden önce kabuğun "*" karakterini başka bir şeye genişletmesidir (bu örnekte, geçerli çalışma dizinindeki dosyaların adları) . Enter tuşuna basıldığında, komut gerçekleştirilmeden önce kabuk komut satırındaki tüm niteleyici karakterleri otomatik olarak genişletir, böylece **`echo`**komut "*" karakterini hiçbir zaman görmez, yalnızca genişletilmiş sonucu görür. Bunu bilerek, **`echo`**beklendiği gibi davrandığını görebiliriz .

# Yol Adı Genişletme

Joker karakterlerin çalıştığı mekanizmaya yol adı genişletmesi denir . Daha önceki derslerimizde kullandığımız tekniklerden bazılarını denersek, bunların gerçekten birer açılım olduğunu görürüz. Şuna benzeyen bir ana dizin verildiğinde:

[me @ linuxbox me] $ **`ls`**
Desktop ls-output.txt Belgeler Müzik Resimleri Genel Şablonlar Videolar

aşağıdaki genişletmeleri yapabiliriz:

[me @ linuxbox me] $ **`echo D*`**
Masaüstü Belgeleri

ve:

[me @ linuxbox me] $ **`echo *s`**
Belgeler Resimler Şablonlar Videolar

ya da:

[me @ linuxbox me] $ **`echo [[:upper:]]*`**
Masaüstü Belgeleri Müzik Resimleri Genel Şablonlar Videoları

ve ana dizinimizin ötesine bakmak:

[me @ linuxbox me] $ **`echo /usr/*/share`**
/ usr / kerberos / paylaşım / usr / yerel / paylaşım

# Tilde Genişletme

**`cd`** Komuta girişimizden hatırladığımız gibi , tilde karakterinin ("~") özel bir anlamı vardır. Bir sözcüğün başında kullanıldığında, adı verilen kullanıcının ana dizininin adına veya herhangi bir kullanıcı adlandırılmamışsa, geçerli kullanıcının ana dizinine genişler:

[me @ linuxbox me] $ **`echo ~`**
/ home / ben

"Foo" kullanıcısının bir hesabı varsa, o zaman:

[me @ linuxbox me] $ **`echo ~foo`**
/ home / foo

# Aritmetik Genişleme

Kabuk, aritmetiğin genişletme yoluyla gerçekleştirilmesine izin verir. Bu, kabuk komut istemini bir hesap makinesi olarak kullanmamıza izin verir:

[me @ linuxbox me] **`echo $((2 + 2))`**
4 $

Aritmetik genişletme şu biçimi kullanır:

```
$ ((ifade))
```

burada ifade, değerlerden ve aritmetik operatörlerden oluşan aritmetik bir ifadedir.

Aritmetik genişletme yalnızca tam sayıları destekler (tam sayılar, ondalıklar yok), ancak pek çok farklı işlem gerçekleştirebilir.

Aritmetik ifadelerde boşluklar önemli değildir ve ifadeler iç içe olabilir. Örneğin, beşin karesini üçe çarpmak için:

[me @ linuxbox me] **`echo $(($((5**2)) * 3))`**
75 $

Birden çok alt ifadeyi gruplamak için tek parantezler kullanılabilir. Bu teknikle, yukarıdaki örneği yeniden yazabilir ve iki yerine tek bir genişletme kullanarak aynı sonucu alabiliriz:

[me @ linuxbox me] **`echo $(((5**2) * 3))`**
75 $

Bölme ve kalan operatörlerin kullanıldığı bir örnek aşağıda verilmiştir. Tam sayı bölmesinin etkisine dikkat edin:

[me @ linuxbox me] $ **`echo Five divided by two equals $((5/2))`**
Beş bölü ikiye eşittir 2 [me @ linuxbox me] $ **`echo with $((5%2)) left over.`**
, 1 tane kaldı.

# Brace Genişletme

Belki tuhaf genişleme denir ayracı genişleme . Bununla birlikte, kaşlı ayraç içeren bir desenden birden çok metin dizisi oluşturabiliriz. İşte bir örnek:

[me @ linuxbox me] $ **`echo Front-{A,B,C}-Back`**
Ön-A-Arka Ön-B-Arka Ön-C-Arka

Desenler olarak adlandırılan bir ön kısım içerir, genişletilmiş bağ olduğu giriş ve adı verilen bir arka kısım dipnot . Ayraç ifadesinin kendisi virgülle ayrılmış bir dizi listesi veya bir tam sayı veya tek karakter aralığı içerebilir. Kalıp, gömülü boşluk içeremez. İşte tam sayı aralığı kullanan bir örnek:

[me @ linuxbox me] $ **`echo Number_{1..5}`**
Number_1 Sayı_2 Sayı_3 Sayı_4 Sayı_5

Ters sırada bir dizi harf:

[me @ linuxbox me] $ **`echo {Z..A}`**
ZYXWVUTSRQPONMLKJIHGF EDCBA

Küme ayracı genişletmeleri iç içe olabilir:

[me @ linuxbox me] $ **`echo a{A{1,2},B{3,4}}b`**
aA1b aA2b aB3b aB4b

Peki bu ne için iyidir? En yaygın uygulama, oluşturulacak dosya veya dizinlerin listelerini yapmaktır. Örneğin, bir fotoğrafçıysak ve yıllar ve aylar halinde düzenlemek istediğimiz geniş bir resim koleksiyonumuz olsaydı, yapabileceğimiz ilk şey sayısal "Yıl-Ay" biçiminde adlandırılmış bir dizi dizin oluşturmaktır. Bu şekilde, dizin adları kronolojik sıraya göre sıralanacaktır. dizinlerin tam bir listesini yazabiliriz, ancak bu çok fazla iş ve hataya da açık. Bunun yerine şunu yapabiliriz:

[me @ linuxbox me] $ **`mkdir Photos`**
[me @ linuxbox me] $ **`cd Photos`**
[me @ linuxbox Fotoğrafları] $ **`mkdir {2017..2019}-{01..12}`**
[me @ linuxbox Fotoğrafları] $ **`ls`**
2017-01 2017-07 2018-01 2018-07 2019-01 2019-07 2017-02 2017 -08 2018-02 2018-08 2019-02 2019-08 2017-03 2017-09 2018-03 2018-09 2019-03 2019-09 2017-04 2017-10 2018-04 2018-10 2019-04 2019-10 2017-05 2017-11 2018-05 2018-11 2019-05 2019-11 2017-06 2017-12 2018-06 2018-12 2019-06 2019-12

Oldukça şık!

# Parametre Genişletme

Bu derste parametre genişletmeye yalnızca kısaca değineceğiz , ancak daha sonra onu ele alacağız. Doğrudan komut satırından ziyade kabuk betiklerinde daha kullanışlı olan bir özelliktir. Yeteneklerinin çoğu, sistemin küçük veri yığınlarını saklama ve her bir parçaya bir ad verme becerisiyle ilgilidir. Daha doğrusu değişkenler olarak adlandırılan bu tür pek çok parça incelememiz için mevcuttur. Örneğin, "USER" adlı değişken kullanıcı adımızı içerir. Parametre genişletmeyi çağırmak ve USER içeriğini ortaya çıkarmak için şunu yapacağız:

[me @ linuxbox me] $ **`echo $USER`**
me

Mevcut değişkenlerin bir listesini görmek için şunu deneyin:

[me @ linuxbox me] $ **`printenv | less`**

Diğer genişletme türlerinde, bir kalıbı yanlış yazarsak, genişletme gerçekleşmez ve echo komutu yanlış yazılan kalıbı gösterir. Parametre genişletme ile, bir değişkenin adını yanlış yazarsak, genişletme yine de gerçekleşecek, ancak boş bir dizeyle sonuçlanacaktır:

[me @ linuxbox me] $ **`echo $SUER`**
[me @ linuxbox ~] $

# Komut Değiştirme

Komut ikamesi , bir komutun çıktısını bir genişletme olarak kullanmamıza izin verir:

[me @ linuxbox me] $ **`echo $(ls)`**
Masaüstü Belgeleri ls-output.txt Müzik Resimleri Genel Şablonlar Videolar

Zeki biri şöyle bir şey yapar:

[me @ linuxbox me] $ **`ls -l $(which cp)`**
-rwxr-xr-x 1 kök kök 71516 2007-12-05 08:58 / bin / cp

Burada sonuçlarını **`which cp`**bir argüman olarak **`ls`**komuta ilettik , böylece **`cp`**tam yol adını bilmeden programın listesini aldık . Sadece basit komutlarla sınırlı değiliz. Tüm ardışık düzenler kullanılabilir (yalnızca kısmi çıktı gösterilmiştir):

[me @ linuxbox me] $ **`file $(ls /usr/bin/* | grep bin/zip)`**
/ usr / bin / bunzip2: / usr / bin / zip: GNU / Linux 2.6 için ELF 32-bit LSB çalıştırılabilir, Intel 80386, sürüm 1 (SYSV), dinamik olarak bağlı (paylaşılan kütüphaneleri kullanır) .15, stripped / usr / bin / zipcloak: ELF 32-bit LSB çalıştırılabilir, Intel 80386, sürüm 1 (SYSV), dinamik olarak bağlı (paylaşılan kütüphaneleri kullanır), GNU / Linux 2.6.15 için, soyulmuş / usr / bin / zipgrep : POSIX kabuk komut dosyası çalıştırılabilir / usr / bin / zipinfo: ELF 32-bit LSB çalıştırılabilir, Intel 80386, sürüm 1 (SYSV), dinamik olarak bağlantılı (paylaşılan kütüphaneleri kullanır), GNU / Linux 2.6.15 için, soyulmuş / usr / bin / zipnote: ELF 32-bit LSB çalıştırılabilir, Intel 80386, sürüm 1 (SYSV), dinamik olarak bağlantılı (paylaşılan kütüphaneler kullanır), GNU / Linux 2.6.15 için, soyulmuş / usr / bin / zipsplit: ELF 32-bit LSB çalıştırılabilir, Intel 80386, sürüm 1 (SYSV), dinamik olarak bağlı (paylaşılan kitaplıklar kullanır), GNU / Linux 2.6.15 için, çıkarılmış

Bu örnekte, boru hattının sonuçları dosya komutunun argüman listesi haline geldi. Eski kabuk programlarında da desteklenen komut ikamesi için alternatif bir sözdizimi vardır **`bash`**. Dolar işareti ve parantezler yerine ters tırnak kullanır:

[me @ linuxbox me] $ **`ls -l `which cp``**
-rwxr-xr-x 1 kök kök 71516 2007-12-05 08:58 / bin / cp

# Alıntı yapmak

Artık kabuğun genişletmeleri kaç şekilde gerçekleştirebileceğini gördüğümüze göre, onu nasıl kontrol edebileceğimizi öğrenmenin zamanı geldi. Örneğin alın:

[me @ linuxbox me] $ **`echo this is a     test`**
bu bir testtir

veya:

[me @ linuxbox me] $ **`[me@linuxbox ~]$ echo The total is $100.00`**
Toplam 00.00

İlk örnekte, kabuk tarafından sözcük bölünmesi, echo komutunun argümanlar listesinden fazladan boşlukları kaldırdı. İkinci örnekte, parametre genişletme, tanımsız bir değişken olduğu için "$ 1" değerinin yerine boş bir dizeyi değiştirdi. Kabuk, istenmeyen genişletmeleri seçici olarak bastırmak için alıntı adı verilen bir mekanizma sağlar .

# İkili alıntı

Bakacağımız ilk alıntı türü çift tırnaktır. Metni çift tırnak içine koyarsak, kabuğun kullandığı tüm özel karakterler özel anlamlarını kaybeder ve sıradan karakterler olarak değerlendirilir. İstisnalar "$", "\" (ters eğik çizgi) ve "" "(ters tırnak) şeklindedir. Bu, sözcük bölme, yol adı genişletme, yaklaşık işareti genişletme ve küme ayracı genişletmesinin bastırıldığı, ancak parametre genişletme, aritmetik genişletme ve komut ikamesinin hala yürütüldüğü anlamına gelir. Çift tırnak kullanarak, gömülü boşluklar içeren dosya adlarıyla baş edebiliriz. Denilen bir dosyanın talihsiz kurbanı olduğumuzu hayal edin `two words.txt`. Bunu komut satırında kullanmaya çalışırsak, kelime bölme, bunun istenen tek bağımsız değişken yerine iki ayrı bağımsız değişken olarak değerlendirilmesine neden olur:

[me @ linuxbox me] $ **`ls -l two words.txt`**
ls: iki kişiye erişilemiyor: Böyle bir dosya veya dizin yok ls: word.txt'ye erişilemiyor: Böyle bir dosya veya dizin yok

Çift tırnak kullanarak, kelime bölmeyi durdurabilir ve istenen sonucu alabiliriz; ayrıca hasarı onarabiliriz:

[me @ linuxbox me] $ **`ls -l "two words.txt"`**
-rw-rw-r-- 1 me me 18 2020-02-20 13:03 iki word.txt [me @ linuxbox me] $**`mv "two words.txt" two_words.txt`**

Orada! Şimdi bu sinir bozucu çift tırnakları yazmaya devam etmemize gerek yok. Unutmayın, parametre genişletme, aritmetik genişletme ve komut ikamesi hala çift tırnak içinde gerçekleşir:

[me @ linuxbox me] $ **`echo "$USER $((2+2)) $(cal)"`**
me 4 Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29

Çift tırnağın komut ikamesi üzerindeki etkisine bakmak için biraz zaman ayırmalıyız. Önce, kelime bölmenin nasıl çalıştığına biraz daha derinlemesine bakalım. Önceki örneğimizde, sözcük bölmenin metnimizdeki fazladan boşlukları nasıl kaldırdığını gördük:

[me @ linuxbox me] $ **`echo this is a     test`**
bu bir testtir

Varsayılan olarak, sözcük bölme boşlukların, sekmelerin ve satırsonu satırlarının (satır besleme karakterleri) varlığını arar ve bunları sözcükler arasındaki sınırlayıcılar olarak ele alır. Bu, tırnaksız boşlukların, sekmelerin ve yeni satırların metnin parçası olarak kabul edilmediği anlamına gelir. Sadece ayırıcı görevi görürler. Kelimeleri farklı argümanlara ayırdıklarından, örnek komut satırımız bir komut ve ardından dört farklı argüman içerir. Çift tırnak eklersek:

[me @ linuxbox me] $ **`echo "this is a     test"`**
bu bir testtir

sözcük bölme bastırılır ve gömülü boşluklar sınırlayıcı olarak değerlendirilmez, bunun yerine argümanın bir parçası olurlar. Çift tırnaklar eklendiğinde, komut satırımız bir komut ve ardından tek bir argüman içerir. Satır satırlarının kelime bölme mekanizması tarafından sınırlayıcı olarak kabul edilmesi, komut ikamesi üzerinde ince de olsa ilginç bir etkiye neden olur. Aşağıdakileri göz önünde bulundur:

[me @ linuxbox me] $ **`echo $(cal)`**
Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 [me @ linuxbox me ] $  **`echo "$(cal)"`**
Şubat 2020 Su Mo Tu We Th Fr Sa 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29

İlk durumda, alıntılanmamış komut ikamesi otuz sekiz argüman içeren bir komut satırı ile sonuçlandı. İkincisinde, gömülü boşlukları ve yeni satırları içeren bir bağımsız değişken içeren bir komut satırı.

# Tek Alıntılar

Tüm genişletmeleri bastırmamız gerektiğinde tek tırnak kullanırız. İşte tırnaksız, çift tırnak ve tek tırnakların karşılaştırması:

[me @ linuxbox me] $ **`echo text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER`**
text /home/me/ls-output.txt ab foo 4 me [me @ linuxbox me] $ **`echo "text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER"`**
text ~ / *. txt {a, b} foo 4 me [me @ linuxbox me] $ **`echo 'text ~/*.txt {a,b} $(echo foo) $((2+2)) $USER'`**
metin ~ / *. txt {a, b} $ (echo foo) $ ((2 + 2)) $ USER

Gördüğümüz gibi, birbirini izleyen her alıntı düzeyinde, genişlemelerin sayısı gittikçe daha fazla bastırılıyor.

# Kaçan Karakterler

Bazen sadece tek bir karakterden alıntı yapmak isteriz. Bunu yapmak için, bu bağlamda kaçış karakteri olarak adlandırılan ters eğik çizgiye sahip bir karakterin önüne geçebiliriz . Bir genişletmeyi seçici olarak önlemek için genellikle bu, çift tırnak içinde yapılır:

[me @ linuxbox me] $ **`echo "The balance for user $USER is: \$5.00"`**
Kullanıcının bakiyesi: 5,00 $

Dosya adındaki bir karakterin özel anlamını ortadan kaldırmak için kaçış kullanmak da yaygındır. Örneğin, dosya adlarında normalde kabuk için özel bir anlamı olan karakterleri kullanmak mümkündür. Bunlar "$", "!", "&", "" Ve diğerlerini içerir. Bir dosya adına özel bir karakter eklemek için bunu yapabiliriz:

[me @ linuxbox me] $ **`mv bad\&filename good_filename`**

Ters eğik çizgi karakterinin görünmesine izin vermek için, "\\" yazarak ondan kaçının. Tek tırnak içinde ters eğik çizginin özel anlamını yitirdiğini ve sıradan bir karakter olarak değerlendirildiğini unutmayın.

# Daha Fazla Ters Eğik Çizgi

[GNU projesi](http://www.gnu.org/)**`man`** tarafından yazılan herhangi bir programın sayfalarına bakarsak, bir tire ve bir harften oluşan komut satırı seçeneklerine ek olarak, iki tire ile başlayan uzun seçenek adlarının da olduğunu göreceğiz. Örneğin, aşağıdakiler eşdeğerdir:

ls -r ls - ters

Neden ikisini birden destekliyorlar? Kısa biçim, komut satırındaki tembel yazarlar içindir ve uzun biçim çoğunlukla komut dosyaları içindir, ancak bazı seçenekler yalnızca uzun biçimde kullanılabilir. Bazen, seçenek belirsiz olduğunda veya bir seçeneğin ne olduğunu daha net bir şekilde belgelemek istediğimizde uzun bir seçenek kullanmak daha iyidir. Bu, özellikle maksimum okunabilirliğin istendiği senaryolar yazarken kullanışlıdır ve ayrıca, kendimizi man sayfasına bir yolculuktan kurtarabildiğimiz her zaman iyi bir şeydir.

Şüphelenebileceğimiz gibi, uzun biçim seçeneklerini kullanmak tek bir komut satırını çok uzun hale getirebilir. Bu problemle mücadele etmek için, kabuğun aşağıdaki gibi bir satırsonu karakterini yok saymasını sağlamak için ters eğik çizgi kullanabiliriz:

ls -l \ --reverse \ --insan-okunabilir \ --tam zamanlı

Ters eğik çizgiyi bu şekilde kullanmak, komutumuza yeni satırlar eklememize olanak tanır. Bu numaranın çalışması için, satırsonu satırının ters eğik çizgiden hemen sonra yazılması gerektiğini unutmayın. Ters eğik çizgiden sonra bir boşluk koyarsak, satırsonu değil boşluk yok sayılır. Ters eğik çizgiler, metnimize özel karakterler eklemek için de kullanılır. Bunlar ters eğik çizgi kaçış karakterleri olarak adlandırılır . Yaygın olanlar şunlardır:

[Untitled](8-%20Metin%20I%CC%87s%CC%A7leme%20ve%20Genis%CC%A7letme%2061f15a5e3b8b4b8da14db7a06cea6115/Untitled%20Database%201b8a025853ec457dae1452d023c5b72f.md)

Ters eğik çizgi kaçış karakterlerinin kullanımı çok yaygındır. Bu fikir ilk olarak C programlama dilinde ortaya çıktı. Günümüzde kabuk, C ++, Perl, python, awk, tcl ve diğer birçok programlama dili bu kavramı kullanmaktadır. **`echo`**Komutu -e seçeneğiyle kullanmak, şunu göstermemizi sağlayacaktır:

[me @ linuxbox me] $ **`echo -e "Inserting several blank lines\n\n\n"`**
Birkaç boş satır ekleniyor [me @ linuxbox me] $ **`echo -e "Words\tseparated\tby\thorizontal\ttabs."`**
Yatay sekmelerle ayrılmış kelimeler [me @ linuxbox me] $ **`echo -e "\aMy computer went \"beep\"."`**
Bilgisayarım "bip" sesi verdi. [me @ linuxbox me] $ **`echo -e "DEL C:\\WIN2K\\LEGACY_OS.EXE"`**
DEL C: \ WIN2K \ LEGACY_OS.EXE