# 5- Düzenleme Üzerine

ALINTILAR VE TEK ÇİFT TIRNAK ÜZERİNE 

[https://wiki.bash-hackers.org/syntax/quoting](https://wiki.bash-hackers.org/syntax/quoting)

# Düzenleme Üzerine

Bu kısımda konsol çıktılarının ve betik dosyasının düzeninden bahsediyor olacağız.

Anlatımlara, değişkenler konusunun sonunda bolca yer verdiğimiz `echo` komutunun detaylarına değinerek başlayalım.

`echo` komutunun parametre ve argümanlarına hızlıca göz atmak için aşağıdaki tabloya bakabilirsiniz. Ya da konsola `man echo` komutunu da girebilirsiniz.

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%20de0ff7e4d2b1411dad228d9b24cd6d79.md)

---

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%20d857fb29e346479692d235df27ee4f91.md)

Parametreler `echo` komutunun hemen ardından kullanılırken, argümanlar bastırılacak olan ifadenin içerisinde kullanılmalıdır. Şimdi sırasıyla işlevleri örnekler üzerinden açıklayarak devam edelim.

## e

`echo` komutunun ardından gireceğimiz **ters slash** işaretli özel argümanlarının doğru şekilde yorumlanabilmesini sağlar. Yani `echo` komutunun farklı bastırma seçeneklerini diğer bir deyişle argümanlarını kullanmak istiyorsak mutlaka **e** parametresini kullanmamız gerekiyor. Bu durumu anlatımın devamında yer alan örnekler üzerinden çok daha net kavramış olacaksınız.

## n

Satır sonu atlanmasını engeller. Yani satır bitiminde echo komutunun varsayılan olarak uyguladığı bir alt satıra geçme işlevini devre dışı bırakır. İşlevini anlamak için aşağıdaki iki çıktıyı dikkatlice incelemeniz yeterlidir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo0.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo0.png)

## \n

Kullanıldığı yerden sonra, bir alt satıra geçerek çıktıları bastırır. Yani bir satır atlamış olur.

Örnek olması açısından **"test metni"** ifadesini alt alta basılacak şekilde ayarlamayı deneyelim.
Bunun için `echo` komutunun ardından **e** parametresini kullanıp bir alt satıra geçmek istediğim kısıma **\n** ifadesini ekliyorum.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo1.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo1.png)

Gördüğünüz gibi **metni** ifadesinin hemen öncesinde kullanmış olduğum **\n** argümanı, "**metni**" ifadesinin bir alt satıra basılmasını sağladı. Aynı işlemi **e** parametresi olmadan yapmaya çalışsaydık, `echo` komutu **\n** argümanının işlevini algılayamayacağından, "**metni**" ifadesini bir alt satıra basmayacaktı. Bu durumu aşağıdaki çıktıya bakarak gözlemleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo2.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo2.png)

## \b

Kullanıldığı yerin solundaki bir karakteri silme işlevindedir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo3.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo3.png)

## \e

Kullanıldığı yerin sağındaki bir karakteri silme işlevindedir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo4.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo4.png)

## \c

Kullanıldığı yerin sağında yer alan tüm karakterleri silme işlevindedir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo5.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo5.png)

Gördüğünüz gibi sağ tarafta yer alan her şey silindiğinden, varsayılan olarak her çıktıda yer alan bir alt satıra geçme işlevi de siliniyor. Dolayısıyla çıktı ile yeni komut girişi, tıpkı **n** parametresini kullandığımızda olduğu gibi aynı satırda gözüküyor. Bu çıktıdan da anlayacağınız üzere aslında `echo` komutu her satır sonuna varsayılan olarak gizli bir **\n** argümanı ekleyerek satır sonun atlanmasını sağlıyor.

## \r

Bu argümandan sonra gelen tüm ifadeler satır başına taşınarak, satın başındaki ifadelerin üzerine yazıyor.

Yani örneğin **12345 abcd** ifadesi için kullanırsak;

Eğer **abcd** ifadesinden hemen önce **\r** argümanını eklersem, dört karakterden oluşan **abcd** ifadesi, satın başındaki beş karakterli **12345** ifadesinde yer alan 4 karakterin üzerine yazılıyor.

Bu açıklamadan bir şey anlamadıysanız aşağıdaki çıktılara dikkatli şekilde bakarak ve komutu bizzat uygulayarak ne demek istediğimi rahatlıkla anlayabilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo6.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo6.png)

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo7.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo7.png)

Boşluk karakterini de hesaba katarak işlem yapmanız oldukça önemli. Zira kimi zaman boşluk karakterinin de geçerli bir karakter ifadesi olduğu unutulabiliyor.

## \t

Kullanıldığı kısımdan sonrası için tab tuşuna basıldığında ortaya çıkan geniş boşluğu sağlar. Yani bir nevi tab tuşu görevi görür de diyebiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo8.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo8.png)

## \v

Kullanıldığı kısımdan sonrasını aynı hizada bir alt satırda basar, bir nevi dikey tab görevi görür.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo9.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo9.png)

## Ters Slash

Eğer bastıracağımız ifadenin içerisinde **ters slash** geçiyorsa bunun **e** parametresinin özellikleri dışında algılanabilmesi için ya **3** ya da **4**'lü şekilde kullanılması gerekiyor. **e** parametresini kullanmadığımızda zaten ters slash ifadesi özel bir anlam kazanmadığından elbette bu kadar çok yazmamız gerekmiyor. Ancak tek bir ifade içerisinde hem **e** parametresinin sağlayacağı avantajları kullanmak hem de ters slash işaretin bastırılmasını isteyebiliriz. İşte bu gibi durumlarda, ters slash karakterinin çoklu kullanımı şarttır.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo10.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo10.png)

## \a

Basılan ifade ile birlikte eğer konsol destekliyorsa uyarı sesinin çıkmasını sağlar, bir nevi zildir.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo11.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo11.png)

## $(komut) ya da 'komut'

**Dolar** işaretinden sonra **parantez içerisinde** yazacağımız komutla ya da **ters tırnak**(<kbd>Alt Gr + ,</kbd>) içerisinde yazacağımız komut ile `echo` komutu üzerinden konsol komutlarını bastırabiliriz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo12.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo12.png)

Dikkat ettiyseniz `echo` komutu üzerinden konsol komutlarını bastırırken her seferinde **çift tırnak** kullandık. Bunun nedeni `echo` komutu ile kullanılan tek tırnak ifadesinin komutları yorumlamıyor olmasıdır. Bu durumu aşağıdaki çıktılara bakarak gözlemleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo13.png](https://raw.githubusercontent.com/taylanbildik/bash_script_dersleri/master/img/De%C4%9Fi%C5%9Fkenler/echo13.png)

Ayrıca hatırlatmak isterim ki; aldığımız çıktılardan da görebileceğiniz gibi, `echo` komutu üzerinden konsol komutlarını çalıştırdığımızda, renklendirme ve içerik düzeni gibi bash kabuğunun sahip olduğu pek çok işlevsel özellik de kayboluyor. Bu sebepten, bu kullanımı temel komut çıktıları elde etmek için kullanmak daha mantıklıdır.

## Printf Komutu

[https://wiki-dev.bash-hackers.org/commands/builtin/printf.#syntax](https://wiki-dev.bash-hackers.org/commands/builtin/printf.#syntax)`echo` komutundan uzun uzadıya bahsettik. Şimdi de `echo` komutuna oranla çok daha fazla işlevi bulunan ve diğer geliştiricilerin betik dosyalarını incelediğinizde sıklıkla karşılaşabileceğiniz `printf` komutunu ele alalım.

`printf` komutu **C** dilinde yer alan aynı isimli fonksiyona benzer işlevi yerine getirerek, argüman olarak aldığı değerleri biçimlendirilmiş çıktılar üretmek için kullanılıyor. Komutunun ismi "**print f**ormatted" yani "biçimlendirilmiş yazdırma/baskı" ifadesinden geliyor.

`printf` komutu ile çıktı alırken, üç tür çıktı biçiminden bahsedebiliyoruz.

- Üzerinde değişiklik yapılmamış, olduğu gibi basılan **standart** çıktılar.
- Kaçış karakteri yani ters eğik çizgi ile yani **özel yorumlama biçimleri ile** düzenlenmiş çıktılar.
- Çıktıların dönüştürülmesini sağlayan **dönüşüm özellikleri ile** değişikliğe uğramış çıktılar.

### Standart Çıktılar

`printf` komutu ile elimizdeki ifade üzerinde herhangi bir değiklik yapmadan, olduğu gibi bastırmak için ifadeyi tırnak işareti içerisinde yazmamız yeterli oluyor. Standart çıktı elde etmek için tek ya da çift tırnak kullanımı da uygundur.

```
printf "Deneme Metni"
printf 'Deneme Metni'

```

### Yorumlama Karakterleri

Basılacak ifadeler ile birlikte kullanıldığında, özel olarak yorumlanarak işlevlerini yerine getiren özel karakterlerdir. Bu karakterlerin başına **ters slash** ve **%b** dönüşüm belirteci eklenerek, özellikle bu karakterlerin yorumlama karakteri olduğunu `printf` komutuna belirtmemiz gerekiyor.

Aşağıdaki tabloya bakarak hangi karakterin hangi işlevde olduğunu görebilirsiniz.

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%200b0c1e2585944421b08d847ea55f9ebb.md)

# \\"

`printf` komutunu kullanıyorken, bastıracağımız ifadeleri çift tırnak içerisinde belirtiyorsak ve ayrıca çıktı olarak da çift tırnak işaretini basılmasını istiyorsak özel bir kullanıma ihtiyacımız var.

Örneğin `printf` komutunun çıktısında **Bu Bir "Deneme" Metni** ifadesini bastırmak istersem, `printf %b "Bu Bir \\"Deneme\\" Metni"` komutunu kullanmam gerekiyor.

Normalde çift tırnak işareti, `printf` komutu ile bastırılacak olan ifadenin kapsamını yani nerede başlayıp nerede bittiğini belirtir. Burada kullanmış olduğumuz **ters slash**(**\**) işaretleri, yanında bulunan tırnak ifadesinin özel bir anlamının olmadığını ve sadece konsola çıktı olarak bastırılmak istendiğini belirtiyor.
Bastırılacak tırnak işaretlerinden önce ters slash kullanılmazsa, `printf` tırnak işaretinin işlevsel fonksiyonunu dikkate alacağı için çıktı olarak basmayacaktır.
Aşağıdaki kullanım örnekleri de ne demek istediğimi çok daha iyi anlayabilirsiniz.

Ayrıca ifadeleri tek tırnak içerisinde yazdıysak, zaten metin içerisindeki çift tırnak sorunsuzca basılacaktır.

Buradaki esas mesele, kabuğa kendimizi doğru ifade edebilmek adına metnin nerede başlayıp nerede bittiğini düzgün şekilde belirtmektir.

# \\\

Çift tırnak işaretine benzer şekilde, eğer ters slash ifadesini de çıktı olarak almak istersek iki kez kullanmamız gerekiyor. İlk kullandığımız ters slash, ikinci ters slash karakterinin bir işlevinin olmadığını ve sadece çıktı olarak bastırılmak istendiğini belirtiyor. Aşağıdaki örnek çıktılara bakarak tam olarak ne demek istediğimi anlayabilirsiniz.

# \a

`echo` komutunu anlatırken **a** karakterinin bir nevi uyarı sesi(alarm sesi) çıkardığını söylemiştik. `printf` komutunda da aynı şekilde **\a** karakteri çıktı ile birlikte alarm sesi oluşturmayı sağlıyor. Tabi bu özelliğin çalışması için mevcut sistemde destekleniyor olması gerektiğini zaten biliyorsunuz.

# \ b

Tıpkı backspace tuşu gibi bir önceki karakteri silme işlevindedir.

# \c

Konsola herhangi bir çıktı bastırmaz. Bir nevi çıktıların değerlerini siler.

# \f

Çıktıları bir satır atlayarak basar. Echo komutunda ele aldığımız şekilde dikey tab görevi görür. Yani çıktıları bir alt satıra mevcut bulunduğu sütun konumuna göre hizalı şekilde basar.

# \n

`echo` komutunda varsayılan olarak bulunan satır sonu atlama işlevi `printf` komutunda bulunmaz. Eğer satır sonunu atlamak istersek bunun için **n** karakterini kullanmamız gerekiyor.

# \r

Yine echo komutunda ele aldığımız "satır başı" fonksiyonunu yerine getirir. Yani bu karakterin kullanıldığı satırın solundaki tüm ifadeler silinerek, karakterin sağındaki ifadeler satır başına alınmış olur.

# \t

Yatay olarak boşluk bırakılmasını sağlar.

# \v

Tıpkı \f karakterinde olduğu gibi çıktıları bir alt satıra mevcut bulunduğu sütun konumuna göre hizalı şekilde basılmasını sağlar. Bir nevi çıktıyı bir alt satıra hizalı şekilde kaydırma görevi görür.

### Dönüşüm Karakterleri

Dönüşüm karakterleri, printf aracına verilmiş olan tüm argümanların tek tek istenilen formda çıktısının alınmasını sağlar. Dönüşüm özellikleri **%** işareti başta olacak şekilde tırnak işareti içerisinde "%donüşüm_karakteri" şeklinde ilk argüman olarak printf komutuna veriliyor. Kullanabileceğimiz dönüşüm karakterlerini ve özelliklerini aşağıdaki tablodan inceleyebilirsiniz.

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%2067823cd082e249838912e7c8a0b5cb78.md)

Dönüşüm karakterlerinin kullanım amacını daha net kavramak adına basit bir örnek yapalım.

### %s

Argümanların tek tek dize olarak ele alınıp yazdırılmasını sağlar.

Örneğin `printf` komutuna argüman olarak girdiğim her bir ifadenin sonuna istediğim başka bir ifadeyi eklemek istiyorsam komutumu aşağıdaki şekilde kullanmam yeterlidir.

```
prinft "%s kişi " birinci ikinci üçüncü
birinci kişi ikinci kişi üçüncü kişi

```

Benzer şekilde her argümanın sonunda bir satır atlamak istersem dönüşüm özelliğinin ardından \n kaçış karakterini girmem yeterli oluyor.

```
prinft "%s kişi\\n" birinci ikinci üçüncü
birinci kişi 
ikinci kişi 
üçüncü kişi

```

Sizlerin de açıkça görebildiği gibi dönüşüm özellikleri mevcut argümanları tek tek işleyerek istenilen şablon forma dönüştürmeyi sağlıyor. Zaten özelliğin "dönüşüm" olarak isimlendirmesi de buradan geliyor. Bu özellik sayesinde eldeki veriyi tek seferde istenilen formda düzenlenmiş çıktı olarak alabiliyoruz. Benim örnekte kullanmış olduğum "s" dönüşüm karakteri yalnızca argümanları dize elemanı alarak tek tek ele alıp işlenmesini sağlıyor. Ancak bu karakterin dışında ayrıca farklı amaçlar için kullanabileceğimiz alternatif dönüşüm karakterleri de tabloda yer alıyor.

### %b

Argümanlar içerisinde geçen kaçış karakterlerinin de yorumlanmasını sağlar.

Örneğin işlenecek olan argümanlar içerisinde kaçış karakterleri geçiyorsa ve biz bu karakterin yorumlanmasını istersek "s" karakteri yerine "b" karakterini kullanabiliriz. Hemen denemek adına basit bir test gerçekleştirelim
Öncelikle "s" karakteri ile argümanlar içerisinde yer alan kaçış karakterlerinin yorumlanıp yorumlanmadığını test edelim.

```
prinft "%s kişi " "birinci\\t" "ikinci\\t" "üçüncü\\t"
birinci\\t kişi ikinci\\t kişi üçüncü\\t kişi

```

Çıktıdan da anlaşıldığı üzere "s" karakteri kaçış karakterlerini yorumlamadan sadece bir dize karakteri olarak bastırdı. Şimdi aynı örneği bu kez "b" dönüşüm karakteri ile deneyelim.

```
prinft "%b kişi " "birinci\\t" "ikinci\\t" "üçüncü\\t"
birinci		kişi ikinci		kişi üçüncü		kişi

```

Aldığımız çıktı ile "b" dönüşüm karakterinin argümanlar içerisindeki kaçış karakterlerini de yorumladığını teyit etmiş olduk.

### %q

Bu karakterimiz ise argümanlar içerisinde geçen tüm özel karakterin önüne kaçış işareti olan ters slash koyarak ilgili karakterin geçersiz olmasını sağlıyor. Özel karakterden kasıt, bash için anlamı olan boşluk, yıldız, soru işareti ve benzere karakterlerdir. Basit örnek için aşağıdaki çıktılara göz atabilirsiniz.

```
printf "%q\\n" "soru?" "yıldız*" "'tek tırnak'"
soru\\?
yıldız\\*
\\'tek\\ tırnak\\'

```

### %%

Eğer yüzde işaretinin her argüman üzerinde geçerli olacak şekilde belirtilmesini istersek çift yüzde işareti kullanmamız gerekiyor. Aşağıdaki örneğe göz atarak bu durumu net bir biçimde görebilirisniz.

```
printf "%%%s\\n" elli yetmiş yüz
%elli
%yetmiş
%yüz

```

Ayrıca **%** ile dönüşüm karakteri arasında aşağıdaki belirteçler de kullanılabilir.

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%209068901215344fbc93f005431aeb7b59.md)

Belirteçlerin kullanımı da oldukça kolay. Örneğin her bir satır arasında soldan itibaren 10 karakter genişliği bırakmak istersek komutumuzu aşağıdaki şekilde kullanabiliriz.

```
printf "%10s\\n" "bir" "iki" "üç"
       bir
       iki
      üç

```

Burada dikkat etmeniz gereken detay, belirtmiş olduğumuz boşluk genişliğine, mevcut argümanın sahip olduğu karakter sayısının da dahil olmasıdır. Biz buradaki kullanım ile her bir satırdaki toplam karakter genişliğini belirtmiş oluyoruz. Argümanın sahip olduğu karakter sayısı dışındaki geri kalan kısımlar boşluk karakteri ile otomatik olarak tamamlanıyor.

Boşluk bırakma işini sağdan sola doğru yani tersten yapmak istersek ilgili sayının başında tire işaretini kullanabiliriz.

```
printf "%-10s" bir iki üç
bir       iki       üç      

```

Eğer bastırılacak karakter sayısına sınırlama getirmek istersek nokta belirtecini kullanabiliriz.

```
printf "%.5s\\n" 1234567890
12345

```

Eğer her bir argümana özel olarak ne kadar boşluk bırakılacağını belirtmek istersek bu kez argümanlardan önce ne kadar boşluk bırakılacağını belirtmemiz gerekiyor. Argümanlardan önce belirttiğimiz sayılar yıldız belirteci tarafından alınarak tek tek işlenecektir. Buradaki yıldız belirteci daha önce de öğrendiğimiz gibi herhangi bir değeri karşıma görevinde olan belirteçtir. Örneğe dikkatlice bakarsanız ne demek istediğimiz çok daha net kavrayabilirsiniz.

```
 printf "|%*s\\n" 5 bir 10 iki 15 üç
|  bir
|       iki
|           üç

```

Benzer şekilde bu özelliğinde de tersten işlemesi için yani boşluğun sağdan sonra bırakılması için tire işaretini kullanabiliriz.

```
printf "%-*s|" 5 bir 10 iki 15 üç
bir  |iki       |üç           |

```

Düz çizgileri eklemiş olma nedenim, bırakılan boşlukları daha kolay ayırt edebilmeniz içindir.

Aslında burada verdiğimiz örneklerin dışında da sayısız örnek oluşturmak mümkün ancak, buradaki örnekler temel kullanımını kavramanıza yetecektir. Elbette kullanımlarını iyi bir biçimde öğrenmek adına sizler de kendi kendinize pek çok farklı deneme yapın mutlaka. Neticede `printf` komutunun çıktıları bastırma konusunda ne kadar işlevsel olabileceğini basit örnekler üzerinden görmüş olduk.

## Çıktıların Renklendirilmesi

Konsol çıktılarımızı renklendirmek istersek, bash üzerinde tanımlı olan renk kodlarını satır içerisinde kullanmamız yeterli oluyor. Elbette renklerin doğru şekilde bastırılabilmesi için, betik dosyasının çalıştırıldığı konsol aracının da renklendirmeyi destekliyor olması gerektiğini unutmayın lütfen. Ayrıca burada yer alan renk kodlarını ezberlemeye çalışmanın mantıklı olmayacağını da şimdiden belirtmiş olalım. Zira pek çok renk var ve bu kodların hepsine hem internet hem de dokümantasyon üzerinden dilediğiniz zaman ulaşabilmeniz mümkün. Yaygın olarak kullandığınız renk kodları zaten aklınızda kalacaktır, ancak özellikle tümünü ezberlemeye çalışmak şahsi fikrime göre zaman kaybıdır. İhtiyaç duyduğunuzda ilgili rengin koduna ulaşmanız mümkün.

Renk kodlarının kullanıldığını belirtmek için kodların başında aşağıdaki üç ifadeden birini yazmamız gerekiyor.

- **\e[**
- **\033[**
- **\x1B[**

Temel kullanım örneği;

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%205318b38096794947b6ded9d74ae6bba9.md)

Yukarıdaki örnekler ile "**Deneme**" ifadesini pembe renge boyayıp "**Metni**" ifadesini standart renginde bırakmış olduk.
Herhangi stil düzenleme kodunu girdiğimizde o kodu sıfırlayacak olan **0m** karakterini kullanmazsak belirttiğimiz stil ifadelerin sonuna kadar devam eder. Yukarıdaki örneklerde kullandığımız **0m** kodu olmasa tüm çıktıların renkleri pembe olacaktı.

## Biçim Stilleri

Temel kullanımı öğrendiğimize göre şimdi çeşitli stil özellikleri üzerinde durabiliriz. Stillerin uygulanabilmesi için terminal uygulamasının stil özelliklerini destekliyor olması gerekir. Yani uyguladığınız stil özelliği konsola yansıtılmıyorsa, stil özelliği kullanmakta olduğunuz konsol tarafından desteklenmediği için olabilir.

### Biçim Stili Atama

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%2070d57778e1454ebe9a4d7b2a1d8acc70.md)

### Biçim Stili Sıfırlama

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%203dc7da5cc0164d2597d79e1a082eed7b.md)

Fark ettiyseniz biçim stili sıfırlama işlemlerin, atanan stil numarasının başına 2 rakamı getirilerek stil sıfırlanabiliyor. Bu basit kod düzeni sayesinde kolay kullanılabilir ve akılda kalıcı bir yapı var. Hepsini birden sıfırlama işlevi varken tek tek stil sıfırlama işlemi neden gerekli diyecek olursanız, hemen basit bir örnek verelim.

Örneğin ben yazdığım ifadenin yalnızca ilk kelimesi yanıp sönsün ve bu ifadelerin tamamı kırmızı renkli olsun istersem komutumu aşağıdaki şekilde kullanabiliyorum.

```
echo -e "\\e[5m\\e[31mDeneme\\e[25m Metni"

```

Bu kullanım ile;

- **\e[5m** kodunu kullanarak yanıp sönme işlevini atadım,
- tüm ifade kırmızı renkte olsun istediğim için **\e[31m** kodunu kullandım,
- ikinci kelimenin yanıp sönmesini istemediğim için **\e[25m** kodu ile yalnızca yanıp sönme stilini sıfırladım,
- böylelikle her iki kelime de kırımızı renkte olup sadece ilk kelime yanıp sönüyor.

## Temel Renk Stilleri

### Metin Rengi

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%207d525e204499457ab74a5857110fde59.md)

### Arka Plan Rengi

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%20ac716ae460934471bf20083a841895a6.md)

## Nitelik Kombinasyonları

Aynı anda pek çok stil özelliği belirtmek istediğimizde, stil özellikleri arasında noktalı virgül kullanmamız yeterli oluyor.

[Untitled](5-%20Du%CC%88zenleme%20U%CC%88zerine%20343e852bea7a49aba3669cfb85618ea3/Untitled%20Database%20898085787c8c4a0daf3e6f13f7e8fa51.md)

Burada örneklerimizin hepsini `echo` komutu üzerinden gerçekleştirdik ancak `printf` komutu ile de aynı sonuçları alabilirsiniz. Yani renk kodları `printf` aracı için de aynen geçerlidir.

```
printf  "\\e[5m\\e[31mDeneme\\e[25m Metni"

```

Ayrıca burada yer alan temel renkler dışında, kullanmakta olduğunuz konsolun desteklemesi halinde 256 renge kadar kullanmanız mümkün.

Bu renklerin hepsinin tarifini burada tek tek yapmak pek verimli bir yol değil. Bunun yerine aşağıdaki basit betik dosyasını çalıştırarak, konsoldan elde edebileceğiniz renkleri ve renklerin kodlarını sıralı şekilde görebilirsiniz.

```
for fgbg in 38 48 ; do # Foreground / Background
    for color in {0..255} ; do # Colors
        # Display the color
        printf "\\e[${fgbg};5;%sm  %3s  \\e[0m" $color $color
        # Display 6 colors per lines
        if [ $((($color + 1) % 6)) == 4 ] ; then
            echo # New line
        fi
    done
    echo # New line
done
 
exit 0

```

Betik dosyası içerisinde yer alan ifadeleri tam olarak anlamamış olabilirsiniz, bu çok normal. İlerleyen aşamalarda konuları öğrendikçe, aslında ne kadar basit bir betik dosyası olduğunu görmüş olacaksınız. Şimdilik sadece renk kodlarının bilgisini elde etmek için kullanmanız yeterlidir.

## Yorum satırlarının belirtilmesi

Yazılan betiğin kolay okunabilir olması ve yürütülen çalışmaların düzenli tutulması adına yazdığımız komutların arasına açıklamalar ekleyebiliyoruz. Kod satırları arasına eklenen ve çalıştırılmayan bu açıklama alanlarına yorum satırları deniyor.

Özellikle karmaşık ve geniş çaplı projelerde, yazılmış olan kodların hangi amaca hizmet ettiğini kısa sürede anlama adına yorum alanları inanılmaz önemli olabiliyor.

Yorum belirtmek için yorumun başına kare (**#**) işaretini ekleyerek yazmanız yeterli. Kare işaretinden sonra yeni satıra geçinceye kadar girilen tüm karakterler yorumdan sayılacaktır. Aşağıda yer alan örnek üzerinde, kullanım şeklini görebilirsiniz.

```
echo "Merhaba" #Bu kısım echo komutu yardımı ile "Merhaba" ifadesinin basılmasını sağlar.

```

Yorum özelliği etkileşimli kabuk üzerinde `shopt -o interactive_comments` ya da `set +o interactive-comments` komutları ile kapatılabilir. 

```jsx
~ → echo bu bir #yorum
bu bir
~ → set +o interactive-comments
~ → echo bu bir #yorum
bu bir #yorum
```

Ancak etkileşimsiz bir kabuk üzerinde yorum özelliğinin kapatılması mümkün değildir. Yani örneğin betik dosyanızın içerisinde `shopt -o interactive_comments` ya da `set +o interactive-comments` komutlarından herhangi birini ekleseniz dahi # işaretinden sonraki karakterler yorumdan sayılacaktır. 

İşte bizler bu şekilde, yazılmış olan herhangi bir betiğin kaynak kodlarını incelerken, hangi komutun hangi amaçla kullanıldığını bir çırpıda öğrenebiliyoruz.

Özellikle açık kaynak hareketinin bir parçası olarak pek çok insanın yazdığı betikleri paylaştığı düşünüldüğünde, yazılan kodların herkes tarafından rahatlıkla okunabilmesi adına yorum alanlarının kullanımı oldukça önemli.

Bir önceki kısımda renkler konusunu ele alırken basit bir betik dosyası paylaşmıştım. Bu betik dosya içeriğini incelediyseniz, içerisinde her komutun işlevinin yorum satırları ile açıklandığını da görmüş olmalısınız.

Kısacası yorum alanlarının kullanımı zorunlu olmasa da çalışma verimini arttıracak önemli bir alışkanlıktır. Bu alışkanlığı kazandıktan sonra, ilerleyen zamanlarda eski projelerinize baktığınızda ne kadar önemli olduğunu sizler de bizzat göreceksiniz.