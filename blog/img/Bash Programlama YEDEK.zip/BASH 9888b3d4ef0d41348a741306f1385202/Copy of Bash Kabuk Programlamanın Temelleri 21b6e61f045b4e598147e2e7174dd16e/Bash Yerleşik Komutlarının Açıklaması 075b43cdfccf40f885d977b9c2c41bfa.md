# Bash Yerleşik Komutlarının Açıklaması

YÜKLENEBİLİR YERLEŞİKLER DİYE BİR KAVRAM VAR

Kendi ihtiyaçların doğrultusunda derlemiş olduğun araçları, kabuğun yerleşikleri içerisine dahil ederek verimli şekilde çalışmasını sağlayabilirsin. Bash kaynak kodunda /examples/loadable/ klasörü altında yüklenebilir yerleşik komut örnekleri vardır. Yeni sürümlerde bu örnekler değişebilir. Bash v2.0 dan beri bu özellik destekleniyor.

```bash
.../bash-4.0$ CC=whatever ./configure
.../bash-4.0$ make
.../bash-4.0$ exec ./bash
.../bash-4.0$ cd examples/loadables/
.../loadables$ make
.../loadables$ enable -f finfo finfo
.../loadables$ help finfo
```

Bu bölüm altında sıralı şekilde bash kabuğuyla birlikte gelen yerleşik araçların kullanımlarını açıklayalım.

Yerleşik olarak geçen komut setleri; yalnızca kabuğa dahil olarak verimli ve doğru şekilde çalışabilecek olan araçları tanımlar. Kabuk ile gelen standart yerleşik araçlar vardır. 

Yerleşik, Bash araç setinde yer alan ve kelimenin tam anlamıyla yerleşik bir komuttur. Bu, ya performans nedenlerinden ötürüdür - yerleşikler, genellikle ayrı bir işlemin çatallanmasını [1] gerektiren harici komutlardan daha hızlı çalışır - veya belirli bir yerleşik kabuk iç bileşenlerine doğrudan erişim.

[https://tldp.org/LDP/abs/html/internal.html](https://tldp.org/LDP/abs/html/internal.html)

Bash yerleşik komutlarının neler olduğunu öğrenmek için konsola `compgen -b` komutunu girmemiz yeterlidir. Burada kullanmış olduğumuz `compgen` komutu yani `compgen` aracı da aslında bash yerleşik araçlarından biridir. Görevi ise tab tuşuna basıldığında mevcut komutlara yönelik kısmi parametrelerin ve seçeneklerin tamamlanması için sistem üzerindeki araçlara ait bilgi sunmaktır. Yani daha sonra ayrıca ele alacağımız  `complete` aracıyla birlikte bash kabuğunun sahip olduğu tab tuşu ile otomatik tamamlama özelliğini mümkün kılar. Sırası geldiğinde tüm yerleşik komutları(araçları) açıklamış olacağız. O zaman bu aracın işlevini çok daha net anlayacaksınız.

Yerleşik yardımcı programlar, -n seçeneğiyle birlikte enable komutu kullanılarak devre dışı bırakılabilir.

enable -n kill komutu kill yerleşik komutunun mevcut kabuk üzerinde devredışı bırkılmasını sağlar.

[`.` (nokta) & `source` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/(nokta)%20&%20source%20Komutu%207a6208c004e044cf832fc733d53e9139.md)

[`:` (iki nokta üst üste) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/(iki%20nokta%20u%CC%88st%20u%CC%88ste)%20Komutu%20845887a2d89940cf92b002be1eccc394.md)

[[ ] (Köşeli Parantez) Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/%5B%20%5D%20(Ko%CC%88s%CC%A7eli%20Parantez)%20Komutu%20542138407b824d179eb6c4bdb63afe6b.md)

[`alias` ve `unalias` Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/alias%20ve%20unalias%20Komutu%204c2d520ff6674c839c8ece087c54374c.md)

[bg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/bg%20Komutu%2060f20184e7b1445e8d81488be2f3adc6.md)

[bind Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/bind%20Komutu%20c7f255ce022c4778b26bbf627c592df4.md)

[break Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/break%20Komutu%20075f7ad775ff493885f83fb869505ccc.md)

[builtin Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/builtin%20Komutu%20688947ab65724b53a915f53ff5f837e2.md)

[caller Komutu ! EKSİK !](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/caller%20Komutu%20!%20EKSI%CC%87K%20!%20c7ab27f4658441bc95fc1d07005838b1.md)

[cd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/cd%20Komutu%20656cf3d28e10416982918a49ee56dea2.md)

[command Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/command%20Komutu%2053d9e46b7c42421686b51a9312023885.md)

[compgen Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/compgen%20Komutu%2055840a8550fb48349241fc132d560887.md)

[complete Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/complete%20Komutu%201974a20b486b4ac1af15dd04047ecee7.md)

[compopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/compopt%20Komutu%2094959f588f9f48e4849d31512c0be4f9.md)

[continue Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/continue%20Komutu%20edf95f13d0994dd29784a6dda0eac117.md)

[declare ve typeset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/declare%20ve%20typeset%20Komutu%20a37929c433b84119bde4131fdab17b3d.md)

[`pushd` `dirs` `popd` Komutları](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/pushd%20dirs%20popd%20Komutlar%C4%B1%20e17932bf4a094fec80cb01df358dd63a.md)

[disown Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/disown%20Komutu%2097380f17572a49e888ce6d9389367e3a.md)

[nohup Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/nohup%20Komutu%20fa3cc366fc5c4b17ae631aced9860eb4.md)

[echo Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/echo%20Komutu%20586a7856bfd448d6a88a9ba4a7569a18.md)

[enable Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/enable%20Komutu%20233d2df66e72402aa871d9220800e646.md)

[eval Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/eval%20Komutu%2050d7206e015441aab3ce355e25e6d334.md)

[exec Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/exec%20Komutu%20dfa7628e7bae49e4a4e41bff87fb7c5d.md)

[exit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/exit%20Komutu%20715b9d579aa74cbc93a7940fd3fd132c.md)

[export Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/export%20Komutu%2012ee84d6c3c645838257d84bc3d5662e.md)

[false & true Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/false%20&%20true%20Komutu%20c87c87eea6f449f69bc1bf84c136dd3a.md)

[fc Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/fc%20Komutu%20276291d98a954e25a3b5e5774e73c448.md)

[fg Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/fg%20Komutu%2016940b4a93254ecb983400a706a0fe30.md)

[getopts Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/getopts%20Komutu%206c328dd61d0344ffb0b436ecb3a8a73d.md)

[hash Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/hash%20Komutu%200aa4ff344c964b6da4fe0423fac9d87d.md)

[help Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/help%20Komutu%20b44b0bfa917b40cd8baa5a71f248775a.md)

[history Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/history%20Komutu%20961b74bbd5854693a7bd897047ad95a8.md)

[jobs Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/jobs%20Komutu%204c3d3e58c6e14ccb8fc946c8687f5dc9.md)

[kill Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/kill%20Komutu%20dc9989ca0d1741c09137352b22b6b987.md)

[let Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/let%20Komutu%20f6565d376c314bffb73e44807828815f.md)

[local Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/local%20Komutu%20da79a9b34fc34503ba79e3ce0cfdbbdd.md)

[logout Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/logout%20Komutu%20e0ef71322118426c8fc8434024a15abd.md)

[mapfile ve readarray Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/mapfile%20ve%20readarray%20Komutu%201b1e5a35bdde401ea1163e5a89698d52.md)

[suspend Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/suspend%20Komutu%20249831c7597b4716bb6261d909aeb985.md)

[pwd Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/pwd%20Komutu%20f440485cb2f64f748053cf421b5f8c59.md)

[return Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/return%20Komutu%208b4396c4d3d94004a7ccf54ff072fe0f.md)

[type Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/type%20Komutu%20978d53013eff4585bcfaa93122d8056c.md)

[readonly Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/readonly%20Komutu%206d0c52b989874c1f98fac86ad6e7215c.md)

[unset Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/unset%20Komutu%2023cb3f2b06e449cd926f04a7bd1c28bc.md)

[shopt Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/shopt%20Komutu%20bdde0cf5039c4f2cb1e280a36d3a0fbd.md)

[times Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/times%20Komutu%20d0535987234344bf9dea6c172402ec33.md)

[trap Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/trap%20Komutu%207f04c8241fd0418a9e0067fa0b4af51a.md)

[ulimit Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/ulimit%20Komutu%20fcf33baad3f449ce9573e768e356b64f.md)

[umask Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/umask%20Komutu%2049d68af8b0124283bb21580b19067fe0.md)

[wait Komutu](Bash%20Yerles%CC%A7ik%20Komutlar%C4%B1n%C4%B1n%20Ac%CC%A7%C4%B1klamas%C4%B1%20075b43cdfccf40f885d977b9c2c41bfa/wait%20Komutu%20c101db9b3f0f48ec984e393e7bd5ed9a.md)