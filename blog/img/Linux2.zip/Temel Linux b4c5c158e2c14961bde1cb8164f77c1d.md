# Temel Linux

[0- Girizgah](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/0-%20Girizgah%20255fbab87f844fbc995551b61ba7e487.md)

[Linux Nedir ?](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Linux%20Nedir%20b4647d7160d24ec89383e7070bf9349b.md)

[Gerekli Çalışma Ortamının Kurulması](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Gerekli%20C%CC%A7al%C4%B1s%CC%A7ma%20Ortam%C4%B1n%C4%B1n%20Kurulmas%C4%B1%202aeff407fde24f0a852301b1a580c384.md)

[Sistem Mimarisine Giriş](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Sistem%20Mimarisine%20Giris%CC%A7%2035e14641416849b7a0d189a58df5537e.md)

[Kabuk Nasıl Çalışır ?](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Kabuk%20Nas%C4%B1l%20C%CC%A7al%C4%B1s%CC%A7%C4%B1r%20731aaae1bdaf453bb3661b9efffb5c22.md)

[Kısayollar](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/K%C4%B1sayollar%204038d496337c44258b6de9fadf4b0077.md)

[Yardım Alma Komutları](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Yard%C4%B1m%20Alma%20Komutlar%C4%B1%20e134a633825947839b82f60a19527c96.md)

[Dizinlerde Gezinmek](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Dizinlerde%20Gezinmek%206507e1b823ff4a02b02b40012fc417c3.md)

[Kabuk Genişletmeleri | Joker Karakterler](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Kabuk%20Genis%CC%A7letmeleri%20Joker%20Karakterler%203ea7fe4658b84c85854bc74c9a4c8f71.md)

[Metinsel Verileri İşlemek & Dosya İşlemleri](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Metinsel%20Verileri%20I%CC%87s%CC%A7lemek%20&%20Dosya%20I%CC%87s%CC%A7lemleri%2006d66c2d7fe746edb8dabb8e16e5f741.md)

[Metin Editörü Kullanımı | Nano & Vi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Metin%20Edito%CC%88ru%CC%88%20Kullan%C4%B1m%C4%B1%20Nano%20&%20Vi%203a32218c897948b48f7b1455655cabbe.md)

[Arşivleme ve Sıkıştırma İşlemleri](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Ars%CC%A7ivleme%20ve%20S%C4%B1k%C4%B1s%CC%A7t%C4%B1rma%20I%CC%87s%CC%A7lemleri%2080d2a25029a1427da48cbdb1877e65e0.md)

[Bilgi Alma Komutları](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Bilgi%20Alma%20Komutlar%C4%B1%20f8e72f03bcf343b89d45f680b79391b9.md)

[Paket Yönetimi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Paket%20Yo%CC%88netimi%2087cca218c904420788759c7934310703.md)

[Kullanıcı ve Grup Yönetimi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Kullan%C4%B1c%C4%B1%20ve%20Grup%20Yo%CC%88netimi%20819c22e9cb1444a2896d21aff81c5ec5.md)

[Linux Dosya Sistemi Hiyerarşisi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Linux%20Dosya%20Sistemi%20Hiyerars%CC%A7isi%2090722633ccb64e8b9c563dfb866086ae.md)

[Disk Yönetimi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Disk%20Yo%CC%88netimi%204ccaf52a8bca424299a1c2bfaed5622f.md)

[İşlem Yönetimi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/I%CC%87s%CC%A7lem%20Yo%CC%88netimi%2018e0a9876b19470d8a56ff205b372cdf.md)

[Servis Yönetimi](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Servis%20Yo%CC%88netimi%20e1bf5c97411f47728df50237ca41a188.md)

[Temel Ağ Komutları](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Temel%20Ag%CC%86%20Komutlar%C4%B1%2099ecf1d605fe42ecb00eaaf783973c5e.md)

[Eğitimin Sonu](Temel%20Linux%20b4c5c158e2c14961bde1cb8164f77c1d/Eg%CC%86itimin%20Sonu%20c1685a02f7904db2aa725e9111eeee57.md)