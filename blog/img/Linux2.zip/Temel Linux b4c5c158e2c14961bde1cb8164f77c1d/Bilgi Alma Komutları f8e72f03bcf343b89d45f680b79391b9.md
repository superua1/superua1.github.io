# Bilgi Alma Komutları

Genel olarak sistemdeki tarih takvim araçlar dosyalar ayarlar kayıtlar ve benzeri pek çok yapı hakkında konsol üzerinden kolayca bilgi edinebilmek için kullandığımız komutlara bilgi alma komutu diyebiliyoruz. Esasen tüm eğitim boyunca kullandığımız ve kullanmaya da devam edeceğimiz pek çok komutu bilgi alma komutları sınıfında değerlendirmemiz mümkün. Çünkü hepsi, kendi görevleri özelinde pek çok bilgi sunma kabiliyetine sahip araçlar. En basit örnek olarak, ls komutu bile tek başına kullanıldığında mevcut dizinimizdeki içerikler hakkında bilgi almamızı sağlıyor. -

Yine de eğitimin geri kalanında değinmek için uygun bölümleri bulunmayan ama haberdar olmamızın faydalı olacağı bazı araçlardan “bilgi alma bölümü” altında çok kısaca bahsetmek istiyorum. Burada bahsettiklerim dışındakiler tüm eğitim boyunca kullandığımız komutlar olduğu için tekrar bilgi alma başlığı altında değinmek istemiyorum. Zaten bu bölümdeki komutları da ihtiyaç duyabileceğimiz temel özellikleri dolayısıyla çok kısaca ele alıyor olacağız. 

Anlatımlarımıza öncelikle takvim ve saat gibi temel bilgileri nasıl edinebileceğimizle başlayabiliriz. 

# Tarih ve Saat Hakkında Bilgi Edinme

# date Komutu

Eğer grafiksel arayüz kullanıyorsanız zaten mutlaka tarih ve saati kolayca öğrenebileceğiniz bir ortama sahipsinizdir. Pek çok grafiksel arayüzde, tıpkı bende de olduğu gibi sistem saati masaüsütü ortamında yönetim çubuğunda gözüküyor. Eğer saatin üzerinde tıkarsak takvim bilgisine de kolayca erişebiliyoruz gördüğünüz gibi. 

Tarih bilgisini komut satırından edinmek istediğimizdeyse date komutunu kullanabiliyoruz. Zaten date ifadesi tarih anlamına geldiği için hatırlaması kolay bir komut. Hemen komutumuzu girelim.

Bakın date komutu tek başına kullanıldığında gördüğünüz gibi sırasıyla, haftanın gününü, ayı, ayın gününü, saati, saat dilimini ve yılı içeriyor. Yani mevcut bulunduğumuz günün tüm tarihi temel bilgilerini date aracıyla öğrenebiliyoruz. Tabii ki aracımızın sağladığı tek bilgi mevcut günümüz de değil. Diğer seçenekleri görmek için date —help komutu ile yardım sayfasını bastıralım. Bakın ne kadar çok bilgi bastırıldı. Bu çıktılardan date aracının çok esnek kullanım özellikleri bulunduğunu görmek zor değil. Ancak bu kadar çok seçenek olması gözünüzü korkutmasın, çünkü temelde date aracının yalnızca sistem tarihini öğrenmek için kullanıyoruz. Mesela tüm tarih bilgisini değil de yalnızca saat bilgisini almak istersek buradaki %r parametresini kullanabiliriz. Ben yalnızca saat bilgisini almak için date +%r şeklinde komutumu giriyorum. Bakın yalnızca saat bastırıldı. Benzer şekilde diğer parametreleri kullanarak date aracından dilediğiniz formda çıktı alabilirsiniz. Bu özelliğe genellikle kabuk programlamada ihtiyaç duyuyor olsak da artık bildiğinize göre ihtiyaç duyduğunuzda yardım sayfasını açıp tekrar hatırlayıp rahatlıkla kullanabilirsiniz..  

Ayrıca date aracı ile tarihi değiştirmemiz de mümkün fakat tarihi değiştirmek için sistem servislerini kullanmak çok daha sağlıklı bir yaklaşım. Çünkü date komutu yalnızca mevcut sistem saatini değiştiriyor fakat “rtc time” olarak geçen entegre devredeki donanımsal gerçek zamanlı saati değiştirmiyor. Bunu değiştirmek için bir araç daha kullanmamız gerekiyor. Zamanı değiştirmemizi sağlayan serviste ise otomatik olarak her ikisini de değiştirmiş oluyoruz. 

Lütfen şimdilik buradaki servis kavramına çok takılmayın. İleride servisleri ayrıca ele alacağız. O zaman servisten kastımın ne olduğunu net biçimde anlamış olacaksınız. Şimdilik date komutunun bize mevcut tarih bilgisini sunduğunu bilmemiz yeterli.

Şimdi bir sonraki bilgi edinme komutu olan cal komutundan bahsederek devam edelim.

# cal Komutu

cal aracı komut satırımız üzerinden takvim bilgisi sunan basit bir araç. Kimi sistemlerde varsayılan olarak yüklü bulunmasa da aslında çoğu dağıtımda mevcut oluyor. Örneğin benim şu an kullandığım kali linux dağıtımında cal aracı varsayılan olarak yüklü gelmiyor, fakat sizin kullandığınız sürüm veya dağıtıma göre sisteminizde yüklü olması mümkün.

Öğrenmek için tek yapmamız gereken konsolumuza cal komutunu girmek. Bakın böyle bir komut olmadığı, eğer istersek bu araçla ilişkili olan ncal paketinin kurulabileceği belirtiliyor. Buradaki komutu y ile onaylayarak ya da kendimiz de buradaki sudo apt install ncall komutunu girerek kurulumu yapabiliriz. Eğer size bu şekilde sorulmadıysa ve sisteminizde yüklü değilse, debian tabanlı dağıtımınıza kurmak için siz de buradaki komutu kullanabilirsiniz. Ben yes ile aracın kurulumunu onaylıyorum ve kullanıcı hesabımın parolasını girip kurulumu başlatılıyorum.

Bakın aracım kuruluyor. Zaten çok küçük bir paket olduğu için hemen kurulacak. Tamamdır, aracım kuruldu. Şimdi aracımızı çalıştırmak için cal komutunu tekrar girelim. 

Bakın mevcut ayın takvim bilgisini sorunsuzca konsola bastırmış olduk. Bu komutun dışında eğer takvimde gün isimlerinin bastırılmasını ve bizim hangi günde olduğumuzun belirtilmesini istersek ncal komutunu da kullanabiliriz. Bakın sol tarafta gün isimleri sırasıyla yazıyor. Takvim de bu günlerin sıralamasına uygun şekilde basılmış oldu. Bakın pazara denk gelen günler bunlarmış örneğin. Ayrıca bu günün tarihi de gördüğünüz gibi özellikle aydınlatılmış şekilde burda belirtiliyor. 

Eğer mevcut ayı değil de geçmiş ya da gelecek bir tarihten takvim bilgisine bakmak istersek cal ya da ncal komutunun ardından ay ve yılı belirterek tam istediğimiz tarihteki takvim bilgisine de ulaşabiliriz. Ben örnek olarak 2000 yılının ocak ayının takvimini bastırmak üzere ncal 1 2000 şeklinde komutumu giriyorum. Bakın 2000 yılının ocak ayı  takvimi getirildi. Benzer şekilde ileri tarih de belirtebiliriz. Ben 2025 yılının 6 ayı için takvim bilgisini istiyorum. Bakın bu takvim de bastırıldı. İşte ihtiyacınız olduğunda sizler de konsol üzerinden takvim bilgisine bu şekilde kolayca ulaşabilirsiniz. Komutun ismi calendar yani takvimden geldiği için hatırlaması da kolay aslında. Yine de unutursanız örneğin yardım sayfalarını apropos calendar komutu ile kurcalayabilirsiniz mesela. Bakın takvimle ilgili olan komutlar ve açıklamaları listelendi.

Neticede takvimi öğrenebileceğimiz bir komut olduğunu bildiğimiz sürece, ilgili komutun ismini bulmak için yardım sayfalarını kolayca kullanabiliyoruz gördüğünüz gibi.

# Dosyalar Hakkında Bilgi Edinme

# which Komutu

which komutunu çalıştırdığımız araçların dosya konumlarını öğrenmek için kullanabiliyoruz.  

Örneğin sizler de biliyorsunuz ki; ben konsola ls yazdığımda kabuk öncelikle ls isminde bir yerleşik komutu var mı diye bakıyor, eğer yoksa path yolu üzerinde bu isimde bir dosya var mı diye araştırmaya giriyor ve eğer bulabilirse bu dosyayı çalıştırıyor. Zaten bu durumdan eğitimin en başında bahsettik. İşte bash komutunun bulup çalıştırmasına benzer şekilde, which komutu da kendisine argüman olarak belirtilmiş olan isimdeki aracın tam dosya konumunu bize bildiriyor. Yani aslında which komutu da path yoluna bakarak argüman olarak verdiğim aracı araştırıyor. Dolayısıyla path yolunda olmayan araçların dosya konumları which komutu tarafından bastırılamıyor. 

Hemen ls komutunun tam dizin adresine bakalım. Bakın ls aracı tam olarak /usr/bin/ls dizini içindeymiş. hatta istersek which aracının kendi dosya adresine de bakabiliriz. bakın which aracı da /usr/bin/which dizini içindeymiş. İşte bu şekilde path yolu üzerindeki araçların tam dizin adreslerini öğrenebilirsiniz. Bu komut özellikle bir aracın çalıştırılabilmesi için tam dizin adresinin girilmesi gereken durumlarda bize dizin bilgisini sunması bakımından önemli. Örneğin eğer hatırlıyorsanız, varsayılan kabuğumuzu bash olarak değiştirme işleminden bahsederken, bash kabuğunun dosya konumunu da which komutu sayesinde bulmuştuk. which komutu, özellikle bash kabuk programlamada sıklıkla kullanıldığı için, ileride karşılaşmanız ve ihtiyaç duymanız olası. Yani hemen şimdi aktif olarak kullanmayacak olsanız bile bu komutu gördüğünüzde hangi amaca hizmet ettiğini artık biliyorsunuz.

# type Komutu

type komutu, isminden de anlaşılabileceği gibi kabuğa girdiğimiz komutların tipiyle türleriyle ilgili bilgileri görüntülemek için kullandığımız bir araçtır. Diğer bir deyişle kabuğa verdiğiniz komutların kabuk tarafından nasıl algılandığını görmenizi sağlıyor. Bu komut özellikle sistemde yüklü bulunan araçların isimleri ile aynı isimde takma isimler yani aliaslar tanımlandığında, kabuğun bizim girdiğimiz komutu nasıl gördüğünü anlamak için kullanışlı bir bilgi edinme aracıdır.

Ben denemek için konsola type ls yazıyorum. Bakın kabuğa ls komutunu verdiğimde aslında kabuğun ls komutunu bir takma isim olarak kabul edip buradaki komutu çalıştırdığını öğrendik. Normalde standart ls aracı yani biz ls komutunu girdiğimizde çalıştırılan dosya /usr/bin/ls dosyası. Ama ls komutu ile aynı isimde yeni bir takma isim tanımlandığı için kabuk bizim girdiğimiz ls komutunu öncelikli olarak takma isim olarak dikkate alıyor ve buradaki takma isim tanımlamasından dolayı ls —color=auto komutunu çalıştırıyor.

Takma isimler dışında eğer kabuğun yerleşik bir komutunu girersek örneğin type cd şeklinde sorgulama yaparsak, gördüğünüz gibi bu komutun bir kabuk yerleşiği olduğu bilgisini aldık.

Ayrıca mesela type bash komutunu da girebiliriz. Bakın bu kez bash kabuğunun dosya konumunu aldık çünkü biz bash komutunu girdiğimizde mevcut kabuk bu dizindeki dosyayı çalıştırıyormuş. Bash kabuğu yerleşik bir araç olmadığı için veya bu isimde bir takma isim tanımlanmadığı için bu şekilde doğrudan çalıştırılan dosyanın konumu kabuk tarafından kullanılıyor.

Özetle bakın type komutu sayesinde bizim girdiğimiz komutlardaki araç isimlerinin kabuk tarafından nasıl algılandığını öğrenebiliyoruz. 

Peki bizim girdiğimiz komutların kabuk tarafından nasıl algılandığının neden bilmemiz gerekiyor ? 

Bu bilgi önemli çünkü, tıpkı ls komutunda olduğu gibi yerleşik ve path yolundaki harici komutlarla aynı isimde takma isimler tanımlı olabiliyor. Takma isimler yerleşik ve harici komutlardan daha öncelikli değerlendirildiği için de, girdiğimiz komutlar bizim normalde beklediğimizden daha farklı sonuçlar verebiliyor.

Örneğin ben alias ls="echo 'ben takma isimim!'" şeklinde yani var olan bir komutla aynı isimde bir takma isim tanımlarsam ne olur ? Hemen deneyelim. Ben ls isminde yeni bir takma isim tanımladım ve buradaki echo komutunu takma ismin çalıştıracağı komut olarak verdim. Şimdi konsolumuza yalnızca ls yazıp ne olacağına bir bakalım. Bakın ls komutunun neticesinde dizin içeriğini listelemek yerine "ben takma isimim" çıktısını aldık. Çünkü kabuğa girdiğimiz komutlarda ilk olarak eğer komutla eşleşen bir takma isim varsa kabuk bunu dikkate alıyor. Nitekim çıktıdan da bu durumu teyit ettik. İşte girdiğimiz komutun beklediğimizden farklı sonuçlar verdiği durumlarda type komutu ile kabuğun bakış açısından girdiğimiz komutu sorgulayabiliyoruz. Bu sayede girdiğimiz komutun neden beklenmedik şekilde çalıştığına dair çözüm için fikir sahibi olmamız mümkün oluyor. 

Örneğin benim ls takma ismi örneğinde komutumu command ls şeklinde girmem gerekiyor. Bakın bu şekilde girdiğimde, ls ifadesinin bir komut olduğunu belirtmiş oluyorum. Benim burada kullandığım command komutu sayesinde kabuk takma ismi görmezden gelip normla şekilde önce yerleşik komutlara daha sonra ls isminin geçtiği PATH yolundaki dizinlere bakıyor ve /usr/bin/ls dosyasını bulup çalıştırabiliyor. Yani buradaki command komutu ls komutunun doğrudan çalıştırılacak komut olarak kabul edilmesini sağlıyor.

Aynı durum yerleşik komutlar için de geçerli. Örneğin cd yerleşik komutu ile aynı isimde bir alias tanımlarsak cd komutunu kullandığımızda takma ismin karşılığındaki komut çalıştırılıyor olacak. Denemek için alias cd=”echo ben cd komutuyum” şeklinde yazıp onaylayalım. Tamamdır, şimdi de cd / komutu ile kök dizine geçiş yapmaya deneyelim. Bakın cd komutu asıl işlevi olan dizin geçişi işlemi yerine bizim tanımladığımız takma ismi kullanılıp konsol çıktı bastırılıyor. Hatta type cd komutu ile de teyit edebiliriz. Bakın cd komutu kabuk tarafından artık bir takma isim olarak algılanıyormuş.

Eğer biz bu takma isim yerine command cd  / veya builtin cd / şeklinde yazarsak, kabuk buradaki cd ifadesini ile tanımlı olan takma ismi görmezden gelip cd komutunun asıl işlevini yerine getiriyor olacak. Ben öncelikle command cd / şeklinde komutumu giriyorum. Bakın bu kez cd aracı yerleşik komutlar içinde bulunduğu için kök dizine sorunsuzca geçiş yaptık. Ayrıca girdiğimiz komutun bir yerleşik komut olduğunu özellikle belirtmek için builtin komutunu da kullanabiliyoruz.

Denemek için cd komutu yerleşik yani builtin bir komut olduğu için komutumuzu tekrar builtin cd ~ şeklinde girebiliriz. Bakın doğrudan ev dizine geçiş yapabildim çünkü buradaki builtin komutu sayesinde kabuk buradaki cd komutunu doğrudan bir yerleşik komut olarak ele aldı.

Fakat dikkat edin builtin komutu yalnızca yerleşik komutları niteliyorken, command komutu tüm komut türlerinde takma isimlerin görmezden gelinmesini sağlıyor.

Bu durumu test etmek için yerleşik komut olmayan ls komutunu builtin ls komutu ile doğrudan çalıştırmayı deneyebiliriz. Bakın ls in bash kabuğunun yerleşik aracı olmadığı konusunda hata çıktısı bastırıldı. 

Takma ismin görmezden gelinmesi için command ls şeklinde girebiliriz. Bakın bu kez ls aracı için takma isim görmezden gelinip bu isim doğrudan PATH yolundaki ilgili dosyayı çalıştırmış oldu.

Sanırım bu örneklerle birlikte, neden type komutunu kullanma ihtiyacı duyabileceğimiz ve kabuğun bizim girdiğimiz komutlara bakış açısı hakkında temel düzeyde de olsa fikir sahibi olabildik.

type komutu hakkında dikkat etmeniz gereken detay, type aracının bütüncül olarak girdiğiniz çok argümanlı komutları değerlendirmek için kullanılmadığı. Yalnızca çalıştırılacak olan araçları temsil eden komutların kabuk tarafından nasıl ele alındığını görmemizi sağlıyor.

Yani örneğin ls komutunun -l seçeneğiyle birlikte bu komutun tipini sorgulamaya çalışacak olursak, bakın ls in takma isim olduğu ama -l ifadesinin bulunamadığı belirtilmiş. Tırnak içinde yazmayı da deneyebiliriz. Ben komutumu tekrar çağırıp tırnak içine alıp onaylıyorum. Bakın bu kez de ls -l komutunun bulunamadığı hatasını aldık.

Yani bizzat buradaki örnekler üzerinden de teyit ettiğimiz gibi buradaki type aracı yalnızca ona verdiğimiz argümanlardaki araç isimlerin kabuk tarafından nasıl ele alınıp çalıştırılacağı konusunda bilgi sunuyor. Mesela type ls echo cd nano şeklinde birden fazla argüman verip, birden fazla aracı temsil eden komutların kabuk tarafından nasıl ele alındığını görebiliriz. Bakın bu komutlar kabuk tarafından çalıştırılırken buradaki tipleri dahilinde ele alınıp çalıştırılıyorlarmış.

En nihayetinde type komutunun bizlere kabuğun bakış açısından komutları görebilme imkanı tanıdığı görmüş olduk. Artık ihtiyacınız olduğunda komutların kabuktaki tip karşılığını nasıl öğrenebileceğinizi biliyorsunuz.

# file Komutu

`file` aracını dosyaların türleri hakkında bilgi almak için kullanabiliyoruz.

Özellikle dosya uzantısı bulunmayan ve türünü bilmediğimiz dosyalar hakkında hızlıca bilgi edinmek için file aracını kullanabiliyoruz. Daha önce sıkıştırmış olduğumuz arşiv dosyasının türünden emin olmak için kullanmıştık hatırlıyorsanız. Tekrar hatırlayacak olursak örneğin file ~/.bashrc komutu ile .bashrc dosyasının türünü sorgulayabiliriz. Bakın bu dosya aslında text dosyasıymış.

Başka bir örnek olarak arşiv dosyasını sorgulayabilirim. Bakın bu arşiv dosyasının, hangi tür arşiv olduğu burada kısaca belirtiliyor. Bu şekilde istediğiniz dosyaları sorgulayıp türleri hakkında bilgi alabilirsiniz. Tek tek tüm dosyalar üzerinde denememize gerek yok. file aracına argüman olarak belirttiğiniz dosyalar hakkında bu şekilde kısa bilgi alabiliyoruz. Eğer aldığınız çıktıdaki dosya türünü bilmiyorsanız internet üzerinde araştırıp gerekli bilgiye ulaşabilirsiniz.

Son bir örnek olarak sistemde yüklü bulunan araçların dosyalarını da sorgulayabiliriz. Ben file /usr/bin/ls komutu ile ls aracının dosya türünü sorguluyorum. Gördüğünüz gibi tür olarak ELF basıldı.  Bu kısaltma Executable and Linkable Format ifadesinin kısalmasıdır. En genel hali ile yürütülebilir dosyaları temsil ediyor. İşte tıpkı sorguladıklarımız gibi, sistem üzerinde pek çok farklı türde dosya bulunuyor. file komutu sayesinde de gerektiğinde dosyaların türleri hakkında bilgi edinebiliyoruz. 

# stat Komutu

Şimdiye kadar ls komutu ile boyut tarih ve isim gibi kriterlere göre filtreleme yaparken de bizzat gördüğümüz gibi sistemimizdeki dosya ve klasörlerin kendine ait "isim" "boyut" "dizin adresi" "erişim yetkileri" ve türü gibi pek çok öznitelik detayını temsil eden metaverileri bulunuyor. Stat komutu da dosya veya klasörlerin sahip olduğu öznitelikler yani metaveriler hakkında detaylı bilgi sunan bir komuttur. 

Ben denemek için hemen touch yeni-dosya komutuyla yeni bir dosya oluşturmak istiyorum. Şimdi bu bu dosyanın bilgilerini görmek için stat komutuna bu dosyayı argüman olarak verebiliriz.

Bakın dosyayla ilgili pek çok detay konsolumuza bastırıldı.

Dosyanın tam ismi, boyutu ve dosya tipi gibi detaylar burada gözüküyor. Örneğin bu dosya içerisi boş standart bir dosya olduğu için regular empty file şeklinde çıktı aldık.  

Bunun dışında ileride sembolik ve kati link bölümünde ele alacağımız inode ve links bilgisini de buradan görebiliyoruz. Şimdilik sizin için bir anlam ifade etmese de ileride buradaki bilgiler anlamlı gelecek. Dosyanın erişim izinlerini ve sahiplik bilgilerini de buradan görebiliyoruz. Burası dosyanın yetkilerini, sahibini ve grubunu bize bildiriyor. Bu kavramlardan da daha sonra bahsedeceğiz.

Ayrıca bakın burada dosyanın en son erişim, düzenleme ve değişim tarihleri detaylı şekilde basılmış. Biz dosyayı yeni oluşturduğumuz için hepsi aynı oldu ama aslında:

Erişim tarihi; dosyanın en son erişilen tarihi belirtiyor. Örneğin dosyanın okunması veya çalıştırılması gibi bir erişim.

Düzenleme tarihi; dosya içeriğinin en son ne zaman değiştirildiğini belirtiyor. 

Değişim tarihi; dosyanın meta verilerinin en son ne zaman değiştirildiğini belirtiyor. Örneğin dosyanın ismi değiştirildiyse bu tarih de değişecektir. 

Ayrıca bakın birth yani dosyanın ilk oluşturulduğu ile ilgili bir satır daha bulunuyor. 

Neticede gördüğünüz gibi stat komutu sayesinde dosyaların meta verilerini detaylı şekilde görüntüleyebiliyoruz. 

# Sistem Hakkında Genel Bilgi Edinme

# lsb_release

lsb_release komutu sayesinde mevcut dağıtım hakkında çeşitli bilgiler edinebiliyoruz. Komutumuzda yer alan lsb ifadesi Linux Standard Base ifadesinin kısalmasından geliyor. Linux Standard Base kısaca (LSB), Linux sistem yapısını standartlaştırmak için Linux Vakfı'nın organizasyon yapısı altında yürütülen bir projedir. LSB' projesinin en temel amacı, Linux dağıtımları arasındaki uyumluluğu sağlamak için bir dizi açık standart geliştirmek ve bunların kullanımını teşvik etmektir. İşte biz de lsb_release komutu ile mevcut dağıtımımızın bu standartlar dahilindeki ismi ve sürümü gibi detayları öğrenebiliyoruz. Tüm bilgileri listelemek için lsb_release -a komutunu kullanabiliriz. Bakın çıktılarda, dağıtıcı kimliği, kullandığım dağıtım, sürümü, kodadı gibi detaylar bastırıldı. Bu bilgiler mevcut dağıtım hakkında standart düzende bilgiler sunuyor. Buradaki bilgiler sayesinde mevcut dağıtımın tam olarak hangi sürüm olduğunu anlayabiliyorum.

Buradaki lsb modülü bulunamadı hatasına takılmayın. Bu hata lsb_release aracının kurulu olduğu ama çekirdek modülünün kurulu olmadığını söylüyor. Şart değil ama dilerseniz lsb çekirdek modülünü nasıl kurabileceğinizi araştırıp kolayca kurulum yapabilirsiniz.

Ayrıca `lsb_release —help` komutu ile yardım bilgilerinde de görebileceğimiz gibi aslında yalnızca -a seçeneği yok. Çeşitli bilgileri ayrı ayrı bastırmamızı sağlayan farklı seçenekler de var. Eğer kabuk programlama sırasında bu bilgilere ayrı ayrı ihtiyacınız olan bir durumla karşılaşırsanız kullanabilirsiniz. Bunun dışında ben yalnızca gerektiğinde mevcut dağıtım bilgisini edinmek için `lsb_release -a` komutunu kullanıyorum.

# uname

uname komutu mevcut işletim sistemi ve donanımı hakkında temel bilgiler sağlayan komut. Tüm temel bilgilerin hepsini tek seferde öğrenmek için -a seçeneğiyle birlikte kullanabiliyoruz. Ben uname -a şeklinde komutumu giriyorum. Bakın buradaki çıktılara bakarak sırasıyla; çekirdek adını, hostname bilgisini yani mevcut cihazımızın ağ üzerinden iletişim kurarken kullandığı adı, sistemin çekirdek sürümünü, tam çekirdek versiyonunu, makinenin donanım mimarisini ve son olarak da işletim sisteminin adını öğrenebiliyoruz.

Mevcut bulunduğumuz sistemi tanımak için yeteri kadar bilgi burada sunuluyor.

Ayrıca isterseniz tek seferde bastırdığımız tüm bu bilgileri ayrı ayrı da bastırabilirsiniz. Seçenekleri görmek için uname —help komutunu girelim. Örneğin bakın yalnıza çekirdeğin adını bastırmak istersem -s seçeneğini kullanmam yeterli. Neticede gördüğünüz gibi uname komutu üzerinden mevcut sistemimiz hakkında kolayca bilgi  edinebiliyoruz.

# uptime Komutu

uptime ifadesi Türkçe olarak çalışma süresi anlamına geliyor. 

Adından da anlaşılabileceği gibi uptime aracı, sistemin ne kadar süredir çalıştığı konusunda bilgi almamızı sağlayan bir araç. Hemen komutumuzu girip sonuçları üzerinden konuşalım. 

uptime komutunu tek başına seçenek belirtilmeden kullandığımızda bakın, 

öncelikle mevcut sistem saatini veriyor,

daha sonra sistemin ne kadar süredir açık olduğu burda belirtiyor 

ayrıca burada mevcut sistemde açık olan kullanıcı oturumu sayısı da belirtiliyor

ve en sondaysa sistemdeki son 1, 5 ve 15 dakikanın sistem yük ortalamalarını veriyor.

Buradaki yük ortalaması, sistemin 1 5 ve 15 dakikalık son periyottaki meşguliyetini ifade ediyor. Bu çıktılarda sizin sisteminizde yakın zamanda yani son 15 dakikadan son 1 dakikaya doğru yük miktarın arttığı görülüyorsa sistem yükünün artmakta olduğunu düşünebilirsiniz. 

Şu anda benim sistemin yük altında olmadığı için yani çoğunlukla bekleme modunda olduğu için buradaki değerler sıfıra yakın gözüküyor. Örneğin yük durumunu gözlemlemek echo {1..999999} şeklinde komutumuzu girip sistemi suni olarak biraz daha yük altında bırakabiliriz. Bakın 1 den bu sayıya kadar tüm sayılar tek tek üretildiği için sistemimizi biraz yük altında bırakıyoruz. İşlem tamamlandı, şimdi  uptime komutu tekrar girip sistemin son durumunu kontrol edelim. Bakın yakın zamandaki yük oranı uzak zamana göre artış gösteriyor. Bu çıktı bize, yakın zamanda sistemin daha fazla yük altına girdiğini haber veriyor. 

Burada dikkat etmeniz gereken detay Linux'ta yük ortalamaları yalnızca CPU'lara değil, disk kaynaklarına olan talebi de yansıtıyor olması. Yani disk üzerindeki okuma yazma da sistem yükü ortalamasını etkiliyor. Elbette bu konu çok daha detayı barındırıyor ancak temel seviye için bu detaylar gerekli değil. Yine de daha fazla detay için ders kaynaklarında da paylaştığım bu blog yazısını da okuyabilirsiniz. [https://www.brendangregg.com/blog/2017-08-08/linux-load-averages.html](https://www.brendangregg.com/blog/2017-08-08/linux-load-averages.html)

Yine de özetleyecek olursak, eğer sizdeki çıktılarda sistem yükü benim ilk aldığım çıktıda olduğu gibi düşük veya 0 olarak gözüküyorsa, bu durum sisteminizin bu kısa periyotta genellikle beklemede olduğunun bilgisini veriyordur. Eğer yakın zaman aralığında artış görülüyorsa da bu sisteminizin gittikçe daha fazla yük altında kaldığına işaret ediyordur. 

Eğer uptime komutundaki bu gibi detayları görmek istemezsek yani bu çıktı yerine yalnızca sistemin ne kadar süredir açık olduğunu daha okunaklı şekilde görmek istersek pretty ifadesinin kısalması olan p seçeneğini de kullanabiliriz. 

Bakın yalnızca sistemin ne kadar süredir açık olduğunu daha güzel yani okunaklı şekilde bastırmış olduk.

Eğer tarih olarak sistemin ne zaman başlatıldığını yani ilk açılış zamanı görmek istersek since ifadesinin kısaltması olan -s seçeneğini kullanabiliyoruz. 

Bakın sistemin ne zaman başlatıldığı tam tarih ve saat olarak bastırılmış oldu.

uptime komutu sistemin çalışma durumunu kontrol etmek için kullandığımız basit ama bilgi verici güzel bir araç. uptime hakkında bahsetmemiz gereken ekstra bir detay da bulunmuyor. Zaten yalnızca -p ve -s olmak üzere iki işlevsel seçeneği var. Unutmanız halinde yardım sayfasından seçeneklerin işlevlerini saniyeler içinde tekrar hatırlayabilirsiniz. Önemli olan uptime yani çalışma süresi komutunu biliyor olmanız. Zaten ismi de tam olarak işlevini tanımladığı için kolay kolay da unutmazsınız.

# free Komutu

`free` aracı, mevcut bellek kullanımı hakkında bilgi almak için kullandığımız bir araç. Herhangi bir seçenek olmadan doğrudan free komutunu kullandığımızda, mevcut bellek ve takas ile ilgili bilgileri kilobayt olarak konsola bastırıyor. Hemen komutumuzu girelim.

Bakın fiziksel ve takas alanı için sütunlar halinde pek çok detay bastırıldı. Zaten sütun başlıklarında buradaki miktarların tam olarak neyi temsil ettiği de açıkça belirtiliyor. Buradaki büyüklük birimleri kilobayt cinsinden. Eğer kilobayt yerine daha okunaklı şekilde çıktıları bastırmak istersek human readable dan gelen h seçeneğini kullanabiliriz. Komutumu free -h şeklinde tekrar giriyorum. Bakın tüm çıktılar çok daha okunaklı büyüklük birimleriyle bastırılmış oldu. 

Neticede gördüğünüz gibi `free` komutu sayesinde toplam bellek ve takas alanı hakkında ve ayrıca anlık olarak kullanılan ve boştaki bellek miktarları hakkında kolayca bilgi alabiliyoruz. 

Eğer tek seferliğine değil de belirli bir aralık belirterek bu istatistikleri görmek istersek -s seçeneği ile kaç saniyede bir bu değerlerin bastırılacağını da özel olarak belirtebiliriz. Ben denemek için free -s 3 komutu ile 3 saniyelik aralık belirtiyorum.

Bakın 3 saniyede bir en son bellek miktarı bastırılıyor. Biz ctrl + C ile bu işlemi durdurana kadar 3 saniyede bir bu çıktılar basılmaya devam edecek. Ben ctrl c ile durduruyorum. Eğer istersek buradaki gibi yalnızca saniye aralığı belirtmek yerine basılma sayısını da tam olarak belirtebiliriz. Yani biz durdurana kadar değil bizim önceden belirttiğimiz sayı kadar çıktı basılır. Bunun için count yani sayma anlamındaki ifadenin kısaltmasından gelen c seçeneği kullanabiliriz. Ben `free -s 2 -c 4` komutu ile 2 saniye aralıkla 4 kez çıktıların bastırılmasını istiyorum.

Bakın 2 saniye aralıkla yalnızca 4 kez bellek kullanımı hakkındaki son durum bastırılmış oldu.

Bu seçenekler dışında free komutunun yardım sayfasında yer alan seçenekler de zaten standart kullanımdaki çıktıları sınırlamak veya genişletmek için kullanılan ek özelliklerdir. Dilerseniz buradaki seçenekler ile çıktıları istediğiniz formda bastırabilirsiniz.

Ayrıca buradaki shared sütunu eskiye dönük uyumluluk için mevcut olan ve günümüzde geçerli kullanımı olmayan bir sütun. Buffer ve cache kavramlarının ne ifade ettiğini bilmiyorsanız ayrıca araştırıp öğrenebilirsiniz. Tam anlaşılmaları derste tam olarak açıklanamayacak kadar uzun sürebileceği için bu araştırma işini size bırakıyorum. Eğer profesyonel anlamda sistem yönetimiyle ilgili değilseniz bu detay sizin için zaten önemli değil. Diğer sütunlardaki veriler de oldukça açık şekilde toplam, kullanılan ve boştaki bellek miktarları hakkında bilgi sunuyor.

# du Komutu

du komutu "disk usage" yani "Disk kullanımı" ifadesinin kısaltmasından geliyor. Bu araç sayesinde dosyalar veya dizinler tarafından kullanılan tahmini disk alanını öğrenebiliyoruz. Büyük miktarda disk alanı kaplayan dosya ve dizinleri bulmak için kullandığımız pratik bir araç.

du komutu herhangi bir seçenek veya argüman olmadan çalıştırıldığında, mevcut dizindeki ve alt dizinlerdeki tüm dosya ve klasörlerin disk kullanımını bayt cinsinden konsola bastırıyor. Ben şu an kendi ev dizinimdeyim. Denemek için yalnızca du yazıp komutumu onaylıyorum.

Bakın çıktılarda alt dizinler de dahil tüm dizinlerdeki klasörler basıldı ve en altta toplam disk boyutu bastırıldı. Fark ettiyseniz klasörlerdeki dosyaların isimli bastırılmadı ama tabii ki bu dosyaların boyutları bulundukları klasörler aracılığıyla burada belirtiliyor. Bu sayede çıktılar çok uzamadan mevcut dizin altındaki tüm klasörlerin büyüklüklerini listeleyebiliyoruz.

Yine de ev dizinimde çalıştırdığım için aldığımız bu çıktılar uzun olduğu için size karmaşık gelmiş olabilir. Daha yalın bir çıktılar üzerinden konuşsak daha iyi olacak.

Örneğin ben burdaki arşiv dosyasının disk üzerindeki boyutunu öğrenmek için du arşiv-dosyası şeklinde komutumu giriyorum. Bakın dosyanın kaç kilobayt disk alanı kapladığı bastırıldı. Dilersek birden fazla dosyanın boyutuna da kolayca bakabiliriz. Hatta -h seçeneğini eklersek büyüklüklerin gösterimi bakımından daha okunaklı çıktılar da elde edebiliriz. 

Bakın dosyanın tam dizin adresini belirttiğimiz sürece sorunsuzca istediğimiz dosyaların boyutlarını öğrenebiliyoruz. Dosya üzerinde kullanımı gayet basit ve yalın. Birde klasörler üzerinde gözlemleyelim. Ben gözlemleyebilmek için içerisinde web sitesinin dosyalarını ve iç içe klasörler barındıran ev dizinimdeki Downloads klasörünün disk üzerinde kapladığı alanı `du ~/Downloads` komutu ile sorguluyorum.

Şimdi çıktılara bakalım. Bakın en altta klasörün içindeki tüm dosya ve klasörlerle birlikte diskte kapladığı toplam disk alanı basılmış. Sonda başa doğru da alt klasörlerin disk üzerindeki boyutları yer alıyor. Her dizin yalnızca kendi içindeki dosya ve klasörlerin toplam boyutunu veriyor, bu şekilde içe içe olan tüm dizinlerin boyut bilgisi sırasıyla bastırılmış oluyor. Neticede gördüğünüz gibi du komutu sayesinde bir klasör içinde tüm dizinlerin disk üzerinde toplam kapladıkları alan hakkında kolayca bilgi alabildik. Fakat dikkatinizi çektiyse dosyaların diskte kapladığı alan toplam alana ekleniyor olsa da dosya isimleri yine bastırılmadı. Eğer klasörler ile birlikte dosyaların da bastırılmasını istersek -a seçeneği ile tüm içeriğin bastırılmasını söyleyebiliriz. Ben komutumu çağırıp, a seçeneği ekleyip tekrar giriyorum. Bakın bu sefer klasörün içindeki tüm dosya ve dizinlerin disk üzerinde kapladıkları alanın bilgisini kolayca bu çıktıdan öğrenebiliyoruz.

İlgili dizindeki tüm içeriği bastırmak dışında ayrıca dilersek yalnızca belirttiğimiz klasörün boyutunu öğrenmek için summarize yani özetlemek ifadesinin kısalmasından gelen -s seçeneğini de kullanabiliriz. Ben yine Downloads klasörü üzerinde denemek istiyorum. Bakın yalnızca bu klasörün toplam boyutunu bastırdım.

Bunlar dışında eğer istersek spesifik olarak belirttiğimiz birden fazla dosya ve klasörün toplam disk boyutunu da öğrenebiliriz. Normalde örneğin ben ev dizinimde ismi büyük D ile başlayan tüm içeriklerin du aracı ile boyut bilgisini sorgularsam hepsinin ayrı ayrı büyüklükleri bastırılacak. Hemen denemek için özet ve okunaklı çıktı almak üzere du -sh ~/D* şeklinde komutumuzu girelim. Bakın büyük d karakteri ile başlayan içeriklerin hepsinin ayrı ayrı büyüklükleri konsola bastırıldı. Eğer bu içeriklerin toplam boyutlarının da bastırılmasını istiyorsak komutumuza c seçeneğini de ekleyebiliriz. Ben komutumu tekrar çağırıp, c seçeneğini de ekliyorum.

Bakın bu kez en alt satırda, tüm içeriklerin toplam boyutu da özellikle bastırılmış oldu.

Neticede farklı örnekler üzerinden de bizzat teyit ettiğimiz gibi dosya ve klasörlerimizin disk üzerinde kapladıkları alan bilgisini öğrenmek için du komutunu çok kolay şekilde kullanabiliyoruz. Ayrıca tabii ki ben du aracının tüm özelliklerinden yani tüm seçeneklerinden bahsetmedim. Eğer du komutunun yardım sayfasına bakacak olursak daha fazla kullanım seçeneği olduğunu da görebiliyoruz. Ancak benim ele aldıklarım dışındaki diğer seçenekler pek sık tercih edilmediği için ve artık du aracının temel çalışma yapısını öğrendiğiniz için ben tüm seçenekleri tek tek açıklama gereği duymuyorum tabii ki. Dilerseniz zaten temelde nasıl çalıştığını bildiğiniz için buradaki ek seçenekleri keşfedebilirsiniz. Sizin de bildiğiniz gibi yardım sayfaları hep bir komut uzağınızda.

Ben son olarak sistemimize bağlı bulunan bazı aygıtları listelememizi sağlayan birkaç bilgi alma komutundan da bahsedip bu bölümü sonlandırmak istiyorum.

# lsusb & lspci & lshw

Sistemimize bağlı bulunan usb aygıtları listelemek istersek, lsusb komutun kullanabiliyoruz. Zaten komutun ismi, işlevini gayet iyi biçimde açıklıyor. Hemen lsusb şeklinde komutumuzu girelim.

Bakın benim sisteminde şu anda bu aygıtlar usb ile bağlı gözüküyor. Ben sanal makine üzerinden çalıştığım için çok aygıt listelenmedi ancak normalde usb ile bağlı olan aygıtlar burada listeleniyor. Örneğin usb üzerinden harici bir wifi kartı taktığınızda aygıt hakkında buradan bilgi alabilirsiniz. USB wifi aygıtınız sistem tarafından tanınmıyorsa, aygıtınızı takıp lsusb komutu ile bu liste üzerinden aygıtın buradaki ID sine bakabilirsiniz. Bu id üzerinden internette araştırma yaparak uygun aygıt sürücüsü olup olmadığını sorgulayabilirsiniz. Kullanmakta olduğunu dağıtıma kurmak için forumlarda mutlaka daha önce pek çok kişi soru sorup yanıt almıştır. Eğer sorulmadıysa siz de sorabilirsiniz. Ayrıca github gibi harici kaynaklardan da aygıt sürücülerini araştırabilirsiniz.

Neticede lsusb komutu sayesinde gerektiğinde sistemimize bağlı olan usb aygıtları hakkında bilgi almamız mümkün oluyor.

Benzer şekilde pci veriyolu üzerinden sistemimize bağlı aygıtları görüntülemek için de lspci komutunu kullanabiliyoruz. Bakın lsusb komutuna benzer şekilde bu kez pci bağlantısı olan aygıtlar listelenmiş oldu.

Eğer sisteme bağlı bulunan bütün aygıtları listelemek istersek de lshw komutunu kullanabiliyoruz. Buradaki hw ifadesi hardware yani “donanım” ifadesinin kısaltmasından geliyor. Komutumuzu girip sonuçlar üzerine tekrar konuşalım. Bakın benim sistemimde bu araç yüklü değişmiş. Kurmak için buradaki komutu girebilirim. Ben sudp apt install lshw -y şeklinde komutumu giriyorum.

Tamamdır aracım kuruldu. Şimdi tekrar lshw komutu ile tüm donanımları listelemeyi deneyelim.

Bakın farklı kategoriler altında bilgisayarımıza bağlı bulunan tüm aygıtlar hakkında bilgiler bastırıldı. Eğer burda aldığınız çıktılar eksikse, aracınızı sudo lshw komutuyla yetkili şekilde çalıştırmayı deneyebilirsiniz. Bakın bu kez daha fazla donanım bilgisi alabildik. Tabii ki bu bilgiler sürekli olarak ihtiyacımız olacak türden bilgiler de değil. Yalnızca aygıtınızla ilgili sorun çözmemiz gerektiğinde size bilgi vermesi için veya belki forumlarda destek isterken kullanabileceğiniz basit işlevsel bir araç yalnızca. 

En nihayetinde bence komut satırı üzerinden mevcut sistemin aygıtları hakkında bilgi almak için bu bahsetmiş olduğumuz komutlar çoğu durumda yeterli. 

Ben özellikler değinmeyeceğim ama hem bu bahsetmiş olduğumuz komutların ek seçenekleri hem de ayrıca bir çok aygıt hakkında bilgi sunan ek komutlar da mevcut. Merak ediyorsanız biraz araştırma ile diğer komutları ve seçeneklere kolayca ulaşabilirsiniz. Örneğin bizim bahsetmiş olduğumuz komutların yardım sayfalarına bakarak diğer seçenekler hakkında bilgi sahibi olup, sonuçlarını bizzat test ederek gözlemleyebilirsiniz. 

Bu bölümde ele aldığımız komutlar genel bilgi alma komutları olduğu için çok fazla üzerine düşüp uzun açıklamalar yapmak istemedim çünkü pek çok farklı türde bilgi sunan komutları ele aldığımız için detaylıca bahsetmeye kalksaydık bu bölüm çok uzun sürebilirdi. Üstelik çoğu ek araç temel sistem yönetimi için bilmenizin şart olmadığı ek bilgi araçları. Ben sadece en temel bilgi alma komutlarının en temel işlevlerini odaklandım. Bu sayede daha fazlası için gerektiğinde yardım sayfaları ve internet araştırması ile tüm sorularınıza yanıt bulabilirsiniz.