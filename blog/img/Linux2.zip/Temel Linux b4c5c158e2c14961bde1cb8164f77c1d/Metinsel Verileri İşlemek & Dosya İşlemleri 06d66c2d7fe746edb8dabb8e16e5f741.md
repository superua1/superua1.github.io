# Metinsel Verileri İşlemek & Dosya İşlemleri

VERİ BİLİMİNDE KULLANIMINA VE BAYT AKIŞINA DAHA FAZLA VURGU YAP.

DAHA DÜZGÜN ÖRNEKLER İLE ELE ALABİLİRSİN YA DA DAHA FAZLASI İÇİN ARAŞTIRMA YAPMAYA SEVK ET.

# Her Şey Bir Dosyadır | Her Şey Bir Bayt Akışıdır

Artık sizin de çok iyi bildiğiniz gibi sistemimizi komut satırı arayüzünden yönetiyorken iletişim dili için yazıyı diğer bir deyişle metinsel verileri kullanıyoruz. Yani komutlarımızı yazılı şekilde girip, sonuçlarını da yine yazılı şekilde takip ediyoruz. Dolayısıyla sistemi etkili şekilde yönetmek için de bu metinsel verileri rahatça görüntüleyip gerektiğinde ihtiyaçlarımıza göre düzenleyip kullanabilmemiz şart. Görüntüleme ve düzenleme işlemleri için de komut satırı üzerinde kullanabileceğimiz çok çeşitli araçlar mevcut. Bu bölümde temel bazı araçlardan bahsediyor olacağız. Fakat bundan önce genel işleyişten haberdar olmak için bahsetmemiz gereken birkaç temel konu var.

Eğer daha önce az çok Linux ile haşır neşir olduysanız ve biraz da meraklıysanız “Linux üzerinde her şey bir dosyadır” sözünü mutlaka duymuşsunuzdur. 

Her şey bir dosyadır tanımı, klavyenizin, dosyaların, dizinlerin, aygıtların ve benzeri tüm yapıların birer dosya olarak tanımlanıp, çekirdekteki sanal dosya sistemi katmanı üzerinde soyutlanmış olan dosya tanımlayıcılar ile temsil edildiğini belirtmek için kullanılıyor. Yani "Her şey bir dosyadır" ifadesi, işletim sisteminin genel mimari yaklaşımını özetliyor. Muhtemelen bu söylediklerimden hiç bir şey anlamadınız, çünkü henüz bahsetmediğimiz kavramları kullanarak açıklamış oldum. Ancak merak etmeyin anlatımın devamında açıklamalarım sizin için de netleşmiş olacak.

Linux çekirdeğinin yapısı gereği, sistem üzerindeki tüm yapıların dosya gibi ele alındığından bahsettik. Bu yaklaşımın tercih edilme nedeni dosyalar üzerinde işlem yapmanın herkes için çok kolay olması. Siz standart bir kullanıcı olarak yetkiniz olan istediğiniz bir dosyayı okuyabilir veya dosyaya yeni veriler ekleyebilirsiniz. Yani dosya okumak veya dosyaya veri eklemek çok kolay. Tüm yapılar dosya gibi ele alındığında da hepsini dosya yönetir gibi esnek ve kolay şekilde yönetme imkanına sahip oluyoruz. Aslında bu yaklaşım sayesinde tüm sistemdeki yapıları ve araçları yönetebileceğimiz ortak bir iletişim yolu da ortaya çıkmış oluyor. 

Yani özünde tüm mesele bayt akışını kontrol etmekten ibaret. Araçların ürettiği çıktıları ve alacakları girdileri ihtiyaçlarımıza göre yönettiğimizde işlerimizi komut satırı üzerinden yerine getirebiliyoruz. Örneğin ben X isimli bir aracın ürettiği çıktıları Y isimli bir araca girdi olarak kolaylıkla bağlayabilirim ve bunu istediğim sayıda aracı birbirine bağlayacak şekilde kullanabilirim. Ya da bir aracın talep ettiği girdileri bir dosyadan yönlendirip, aracın bu dosyadaki verileri işlemesini sağlayabilirim. Hatta daha deneyimli bir kullanıcıysam, sistem üzerindeki çeşitli dosyaları inceleyerek sistemin mevcut durumu hakkında bilgi almam da mümkün çünkü sistem üzerinde her şey bir dosya gibi temsil ediliyor. Özetle Linux çekirdeğimiz donanımlar ile gereken alt seviyeli iletişimi kendisi sağlayıp bize sade ve okunaklı şekilde sanal dosyalar sunduğu için pek çok aracı ve yapıyı rahatlıkla denetleyip yönetebiliyoruz. 

Söz konusu dosya içeriklerini yönetmek olduğunda da her şey en temelde bayt akışını nasıl kontrol ettiğimize kalıyor. Bir aracın çıktılarını başka bir araca girdi olarak iletebilmek için bu bayt akışını ilgili araca yönlendirebiliyor olmamız gerekiyor. Bir sonraki derste burada bahsi geçen yönlendirme mekanizmasından bahsederek devam edelim. 

## Yönlendirmeler

Linux üzerinde baytları bir kaynaktan diğerine iletmek için yönlendirme mekanizmasından faydalanabiliyoruz. 

Yönlendirme işlemi için Linux üzerinde standart şekilde her bir dosyanın, girdileri okuduğu ve çıktılarını ürettiği uç noktaları bulunuyor. Bu uç noktalara da “dosya tanımlayıcıları” deniyor. Ve temelde 3 tür dosya tanımlayıcı bulunuyor. Söylediklerim hala size anlamlı gelmiyorsa lütfen biraz daha sabırlı olun çünkü aslında son derece basit bir yapı.

Bir dosyaya veri girişi yapmak istiyorsak o dosyanın standart girdisi olarak temsil edilen 0 numaraları dosya tanımlayıcısına verileri yönlendirmemiz gerekiyor.

Eğer bir dosyanın hatasız standart çıktılarını başka bir yere yönlendirmek istiyorsak bu çıktıları 1 numaralı dosya tanımlayıcısı üzerinden okumamız gerekiyor.

Eğer bir dosyanın yani örneğin bir aracın ürettiği hatalı çıktılarını başka bir yere yönlendirmek istiyorsak da bunun için  2 numaralı dosya tanımlayıcısını kullanmamız gerekiyor.

Hemen somut bir örnek üzerinden görelim. Ben test edebilmek için aynı anda hem hatalı hem de hatasız çıktılar üreten basit bir betik dosyası oluşturmak istiyorum. 

Bunun için cat > [test.sh](http://test.sh) komutunu girelim.

Şimdi ben öncelikle hatasız çıktı üretilmesi için echo “Bu hatasız bir çıktı” şeklinde yazıyorum ve alt satıra iniyorum. Şimdi bir de hatalı çıktı üretilebilmesi için gerçekte var olmayan yani benim sistemimde bir karşılığı olmayan asdf komutunu girebilirim. Tamamdır veri girişinin tamamlandığını belirtmek için  ctrl d ile dosyamızı kapatalım. 

Şimdi bu dosyanın çalıştırabilmesi için daha önce de yaptığımız şekilde chmod komutu ile çalıştırma yetkisi vermemiz gerekiyor. Ben chmod +x [test.sh](http://test.sh) şeklinde komutumu giriyorum. Yetkimizi de tanımladık. hemen ./test.sh komutu ile betik dosyamızı çalıştırıp test edelim. Bakın hem hatasız hem de hatalı çıktılar almış olduk. Biz bu çıktıları özellikle herhangi bir adrese yönlendirmediğimiz için bu çıktılar konsolumuza bastırıldı. Ben bu çıktıları konsola bastırmak yerine istediğim isimde bir dosyaya yönlendirmek istiyorum.

Öncelikle hatasız çıktıları yönlendirmeyi deneyebiliriz. Hatasız çıktılar standart çıktı olarak ifade ediliyor ve 1 numaralı dosya tanımlayıcısı ile temsil ediliyor. Örneğin ben bu betik dosyasının üreteceği hatasız olan çıktıları hatasız.txt isimi dosyaya yönlendirmek istersem komutumu ./test.sh 1> hatasız.txt şeklinde girebilirim. Bakın şimdi konsola yalnızca hatalı olan çıktılar bastırıldı çünkü ben hatasız olan çıktıları bu hatasız.txt dosyasına yönlendirdim. Dolayısıyla konsola bastırılacak bir çıktı da kalmadı. Şimdi cat komutu ile hatasız dosyasını okuyup içeriğine bakalım. Bakın hatasız çıktı da bu dosyaya kaydolmuş.

Biz burda hatasız olan çıktıları yönlendirmek için 1> operatörünü kullandık ama aslında standart çıktılar varsayılan olarak yalnızca tek bir büyüktür işareti ile de yönlendirilebiliyor. Hemen deneyelim. Ben ./test.sh > hatasız2.txt şeklinde komutumu giriyorum. Bakın yine yalnızca hatalı olan çıktılar konsola bastırıldı. Yeni oluşturduğumuz dosyanın içeriğini de kontrol edelim. Bakın tek büyüktür işareti ile de tıpkı 1> operatöründe olduğu şekilde hatasız olan çıktıları istediğimiz adrese yönlendirmeyi başardık. Yani standart çıktıları temsil eden 1 numaralı dosya tanımlayıcıyı özellikle belirtmeden yalnızca büyüktür operatörü ile de standart çıktıları istediğimiz yere yönlendirebiliyoruz.

Yalnızca hatasız olan çıktıları yönlendirdik. Ben şimdi hatalı olan çıktıları da istediğim bir dosyaya yönlendirmek istiyorum. Nasıl ki üretilen hatasız çıktılar standart çıktı olarak isimlendiriliyorsa, üretilen hatalı çıktılar da  standart hata çıktıları olarak ifade ediliyor ve 2 numaralı dosya tanımlayıcı ile temsil ediliyor. 

Yani örneğin ben betik dosyasının ürettiği hatalı çıktıları bir dosyaya yönlendirmek istersem büyüktür yönlendirme operatörü ile 2> şeklinde özellikle belirtmem gerekiyor. Hemen denemek için ./test.sh 2> hatalı.txt şeklinde komutumuzu girelim. Bakın hatalı çıktıları bu dosyaya yönlendirdiğimiz için bu kez da konsola yalnızca hatasız olan çıktılar bastırıldı. Yönlendirme yaptığımız dosyanın içeriğini de kontrol edelim. Bakın dosyada yalnızca hatalı çıktı bulunuyor çünkü ben betik dosyasının ürettiği hatalı çıktıları 2 numaralı dosya tanımlayıcı ve buradaki büyüktür yönlendirme operatörü ile bu dosyaya yönlendirdim.

İşte neticede ihtiyacımıza göre hatasız ve hatalı olan çıktıları istediğimiz bir dosyaya yönlendirebiliyoruz. Mesela özellikle araçların ürettiği hatalı çıktıları görmek istemediğimizde, yalnızca hatalı çıktıları yok etmek için bunları /dev/null dosyasına yönlendirebiliyoruz. /dev/ dizini altındaki null dosyası, kendisine gönderilen tüm verileri yutmak için çekirdek tarafından sağlanan sanal bir dosya. Biz buraya çıktı yönlendirdiğimizde ilgili çıktı hiç bir yere kaydolmuyor, yani aslında çıktıları boşluğa yönlendirmiş oluyoruz. Bu sayede araçların ürettiği hatalı çıktılardan kolayca kurtulmamız da mümkün oluyor.

Denemek için ./test.sh 2> /dev/null şeklinde komutumuzu girebiliriz. Bakın konsola yalnızca hatasız olan çıktı bastırıldı çünkü hatalı olanları /dev/ dizini altındaki null dosyasına yönlendirdik. Şimdi hatalı çıktılara ne olduğunu görmek için çıktıları yönlendirdiğimiz  /dev/null dosyasının içeriğini okumayı deneyebiliriz. Ben cat /dev/null komutu ile bu dosyayı okumayı deniyorum. Bakın dosya içeriği tamamen boş çünkü aslında bu dosya verileri boşluğa göndermek için kullanılan sanal bir dosya. Yani biz yönlendirsek de içerisinde hiç bir veri tutmuyor çünkü bu dosya bizim bildiğimiz standart dosyalardan değil. Daha önce linux üzerinde her şeyin bir dosya gibi ele alından bahsetmiştik. İşte bu dosya da bu yaklaşımın bir sonucu. Siz de istemediğiniz tüm verileri /dev/null dosyasına yönlendirip onlardan kurtulabilirsiniz. Bu dosya disk üzerinde yer alan gerçek bir dosya olmadığı için disk üzerinde okuma yazma yükü oluşturmaz. Bu ve benzeri dosyalar çekirdek tarafından sanal olarak oluşturulan ve bellek yani geçici hafıza üzerinden çalıştırılan sözde dosyalardır. Bu yaklaşım sayesinde disk üzerinde yük oluşturma durumundan da endişe etmemize gerek kalmıyor.

Tekrar asıl konumuza dönecek olursak, hatalı ve hatasız çıktıları ayrı ayrı nasıl yönlendirebileceğimizden açıkça bahsettim. Fakat kimi zaman ayrı ayrı yönlendirmek yerine tüm çıktıları tek bir adrese yönlendirmek de isteyebiliriz.  Bu işlem için yönlendirme operatöründen önce “ve &” işaretini yani ampersant işaretini ekleyip &> operatörünü kullanabiliyoruz. Buradaki ampersant olarak da bilinen “ve” işaretini hem hatalı ve hem de hatasız çıktıları temsil ediyor gibi düşünebilirsiniz. Ben denemek için ./test.sh &> sonuc şeklinde komutumu giriyorum. Bakın konsolumuza herhangi bir çıktı bastırılmadı çünkü tüm çıktılar bu dosyaya yönlendirildi. Görmek için cat komutu ile okuyalım. Bakın tüm çıktılar bu sonuc dosyasına eklenmiş. Yani hatalı ve hatasız çıktıların &> operatörü sayesinde tek bir adrese yönlendirilebildiğini bizzat teyit etmiş olduk. 

Söz konusu hatalı ve hatasız çıktıları yönlendirmek olduğunda burada bahsettiğim yöntem en kolayı. Yani aynı işlem için alternatif yöntemler de var fakat bahsedip kafanızı karıştırmak istemiyorum. 

En nihayetinde hem ayrı ayrı hem de birleşik şekilde hatalı ve hatasız çıktıları nasıl yönlendirebileceğimizi örnekler üzerinden ele aldık. Anlatımın devamında girdileri nasıl yönlendirebileceğimizden de kısaca bahsedeceğim ama öncelikle çıktıların yönlendirilmesiyle ilgili konuşmak istediğim birkaç detay daha var. 

Biz örneklerimiz sırasında hep tek büyüktür karakterini kullanarak yeni bir dosya oluşturulmasını ve içerisine ilgili verinin yönlendirilmesini sağladık. 

Biz yönlendirme yapmak için tek büyüktür işareti kullandığımızda aslında kabuğumuza, eğer bu yönlendirme işaretinden sonra gelen bu dosya isimde bir dosya yoksa yeni dosya oluştur, eğer bu isimde bir dosya varsa da yönlendirilen verileri bu dosyanın üzerine yaz demiş oluyoruz. Yani biz tek büyüktür operatörünü kullandığımızda aynı isimli bir dosya varsa o dosyanın içeriği silinip en son yönlendirilen veriler kaydediliyor. Dolayısıyla eski dosyanın tüm içeriği yok edilmiş oluyor. 

Denemek için içerisinde hatalı ve hatasız çıktılar olan sonuc isimli dosyamıza tekrar yalnızca hatasız çıktımızı yönlendirmek üzere ./test.sh > sonuc şeklinde komutumuzu girebiliriz. Tamamdır. Şimdi dosyamızı tekrar cat ile okuyalım. Bakın önceki hatalı ve hatasız çıktılar silinmiş, bunlar yerine en son yönlendirmiş olduğum hatasız çıktılar eklenmiş. İşte tıpkı bu örnekte olduğu gibi biz tek büyüktür işaretini kullandığımızda hedefte aynı isimli bir dosya varsa bu dosya içeriğinin üzerine yönlendirilmiş olan veriler yazılıyor. Eğer amacınız tam olarak bu değilse, tek büyüktür yönlendirme operatörünü kullanarak önemli dosyaların içeriklerinin yok olmasına sebep olabilirsiniz. 

Üzerine yazma işlemi yerine, mevcut verilerin sonuna eklemek istediğimizi belirtmek için de çift büyüktür işaretini kullanabiliyoruz. Hemen deneyip sonucu gözlemleyebiliriz. Ben bir önceki komutumu çağırıp, bu kez çift büyüktür ile yine hatasız çıktıların bu dosyanın sonuna eklenmesini istiyorum. Dosyaya bakalım. Bakın dosyanın sonuna yani aynı hatasız çıktıların eklendiğini görebiliyoruz çünkü çift büyüktür işareti sayesinde ekleme yapılması gerektiğini belirtmiş olduk. Testi devam ettirmek içinin ben ./test.sh 2>> sonuc komutu ile yalnızca hatalı olan çıktıların da dosyanın sonuna eklenmesini istiyorum. Tekrar cat ile dosya içeriğini kontrol edelim. 

Bakın bu çıktılarım da dosyanın sonuna eklendi. Son olarak tek seferde hem hatalı hem de hatasız çıktıları dosyanın sonuna eklemek istersek ./test.sh &>> sonuc şeklinde komut girmeyi deneyebiliriz. Bakın dosyayı okuduğumuzda, bu çıktılar da dosyanın sonuna eklenmiş olduğunu görebiliyoruz. 

Yani örneklerimizle birlikte tek büyüktür işaretinin verilerin üzerine yazdığını ve çift büyüktür işaretinin de var olanlara ekleme yaptığını bizzat teyit etmiş olduk. 

Ayrıca mesela daha önce var olmayan bir dosyayı oluşturmak için de çift büyüktür işaretini kullanabiliriz. Ben denemek için sondaki komutumu çağırıp, dosya ismini yeni-sonuc şeklinde değiştiriyorum. Dosyamızı cat ile okumayı deneyelim. Bakın çift büyüktür işareti sayesinde belirttiğimiz isimde dosya oluşturuldu ve bu çıktılar da bu dosyaya yönlendirildi. Tamamdır bence çıktıları yönlendirmeyle ilgili temelde bilmemiz gerekenlerden bahsettik. 

Şimdi bir de girdileri yönlendirmek için kısaca standart girdiden bahsedelim. 

Standart girdiden veri kabul eden tüm araçlara küçüktür yönlendirme operatörü ile doğrudan veri girişinde bulunabiliyoruz.  Örneğin ben sonuc isimli dosyayı okumak için cat < sonuc şeklinde komutumu girebilirim. Buradaki küçüktür yönlendirme operatörü cat aracına bu dosyanın içeriğini yönlendirip bunun konsola bastırılmasını sağlıyor. Normalde doğrudan cat sonuc komutu ile de okuyabileceğimiz için belki bu örneğimiz size çok mantıklı gelmemiş olabilir ancak merak etmeyin ileride farklı araçlar üzerinde kullanırken daha anlamlı hale gelecek. Fakat biraz önce de belirttiğim gibi bir araca bu şekilde yönlendirme operatörü ile veri iletmek için o aracın standart girdiden veri kabul ediyor olması gerekiyor. Eğer o araç standart girdiye bakmıyorsa yani buradan veri kabul etmiyorsa yönlendirmiş olduğunuz hiç bir veri bu araç tarafından işlenmez.

Bu duruma örnek olarak echo aracını ele alabiliriz mesela. echo aracının tek görevi kendisinde sonra yazılmış olan argümanları bastırmaktır. Yani echo aracı standart girdiden veri kabul etmiyor, yalnızca kendisinden sonra yazılmış olan argümanları alıp konsola bastırıyor yalnızca. Dolayısıyla eğer biz echo aracının standart girdisine veri gönderirsek echo aracı hiç bir tepki vermeyecek. 

Bizzat denemek için sonuc isimli dosyanın içeriğini echo aracına yönlendirmek üzere komutumuzu echo < sonuc şeklinde girebiliriz. Bakın herhangi bir çıktı almadık çünkü echo aracı standart girdiden veri okumuyor. Dolayısıyla bizim veri yönlendirmiş olmamız echo için hiç bir şey ifade etmiyor. 

Ek bir örnek daha vermemiz gerekirse örneğin tıpkı echo aracı gibi klasör oluşturmamızı sağlayan mkdir aracı da standart girdiden veri okuması yapmıyor. Bu sebeple eğer biz klasör oluşturmak istiyorsak, klasör ismini mkdir aracına argüman olarak vermemiz gerekiyor. Ben denemek için mkdir aracına mkdir < sonuc komutu ile yine sonuc dosyasının içeriğini girdi olarak yönlendirmeyi deniyorum. Bakın komutumuz hata verdi çünkü mkdir aracı standart girdiye bakmıyor. Yani ben mkdir < sonuc şeklinde yazdım ama mkdir aracına oluşturması gereken klasör için hiç bir argüman iletilmedi. Yani mkdir < sonuc komutunu girmemle yalnızca mkdir komutunu girmem aslında aynı şey. Hatta bakın ben mkdir komutunu girdiğimde yine aynı hatayı alıyorum çünkü mkdir aracına klasör ismini iletmemiş oluyorum.

İşte bizzat örnekler üzerinden de teyit ettiğimiz gibi standart girdiden veri okumayan araçların standart girdilerine veri yönlendirmesi yapmamız anlamsız çünkü standart girdilerini okumuyorlar. Örnekler sırasında ele aldığımız araçlar gibi yalnızca argümanlarla çalışabilen araçlara dosyalardan veri yönlendirmesi yapmak için alternatif çözüm var fakat bu çözümden daha sonra ayrıca bahsediyor olacağız.  

Şimdi burada odaklanmanız gereken tek detay standart girdi yönlendirmesinin yalnızca standart girdiden veri kabul eden araçlar üzerinde etkili olduğu. Peki hangi aracın standart girdiden veri alıp hangisinin argümanlar üzerinden çalıştığını nerden bileceğiz diye soracak olursanız.

Hangi araçların standart girdiden veri kabul ettiğini manual sayfalarındaki açıklamalara göz atarak öğrenebileceğiniz gibi zaten zaman içinde hangi aracın ne şekilde çalıştığını da anımsıyor olacaksınız. Örneğin kullandığınız aracın yardım sayfasında bu duruma dair bir açıklama yoksa standart girdiden veri yönlendirmeyi deneyip bizzat kendiniz de test edebilirsiniz. 

Benim yönlendirmelerle ilgili bahsetmek istediklerim şimdilik bu kadar. Bence temel eğitim için bu kadarlık detay seviyesi yeterli. Tabii ki eğer isterseniz daha fazlasını öğrenmek için araştırma yapmakta özgürsünüz. 

Biz şimdi metinsel veriler üzerinde çalışmamıza yardımcı olan temel araçlardan bahsederek devam edebiliriz. Ben bir sonraki derste, şimdiye kadar sıklıkla kullandığımız cat aracından bahsederek devam etmek istiyorum.

# cat Komutu

cat aracının ismi "bağlamak, birleştirmek veya sıralamak" anlamlarında olan İngilizce "concatenate" kelimesinden geliyor. Zaten ismi de aracın görevini net biçimde ifade ediyor aslında.

cat komutunun en temel işlevi, kendisine argüman olarak verilen dosyaların içeriklerini konsola yönlendirerek bastırmaktır. Yani aslında temelde cat aracı dosyaların içeriklerini konsol üzerinden okuyabilmemize olanak tanıyan basit bir araçtır. Var olan bir dosyayı okumak için tek yapmamız gereken, cat komutunun ardından dosyanın ismini girmek. Ben örnekler sırasında kullanmak için mevcut bulunduğum dizindeki dosya ve klasör isimlerini bir dosyaya kaydetmek istiyorum. Bunun için ls > liste komutunu girebilirim. Buradaki büyüktür yönlendirme operatörü sayesinde ls komutunun çıktıları “liste” dosyasına yönlendirilmiş olacak. Bir de ls /usr > liste2 komutu ile usr dizini altındakileri de liste2 dosyasına kaydedelim. 

Örneğin oluşturduğumuz ikinci dosyanın içeriğini konsola bastırmak istersek cat liste2 şeklinde komutumuzu girebiliriz. Bakın dosyanın içeriği konsola bastırıldı.  Dilersek, aynı anda birden fazla dosyayı da okuyabiliriz. Denemek için diğer dosyanın ismini de giriyorum.

Bakın komutta soldan sağa doğru verdiğim tüm dosyaların içerikleri, sırasıyla yukarıdan aşağıya doğru konsola bastırılmış oldu. Yani aslında isminde olduğu şekilde cat aracı birden fazla dosyanın içeriğini sırasıyla birleşik şekilde konsolumuza bastırmış oldu. Bu şekilde istediğimiz kadar dosyanın birleştirilmesini sağlayabiliyoruz. 

Birden fazla dosya içeriğinin cat aracı sayesinde sıralı şekilde birleştirilebiliyor olması size bir fikir verdi mi ? 

Evet, pek çok kişinin tahmin ettiği gibi, eğer istersek birden fazla dosyanın içeriğini tek bir dosyaya yönlendirebiliriz. Yani birden fazla dosyayı tek bir dosyada birleştirebiliriz. Ben liste ve liste2 dosyasını birleştirip nihai-liste isimli bir dosya oluşturmak istiyorum. Bunun için cat liste liste2 > nihai-liste şeklinde komutumu girmem yeterli. Oluşturulan nihai-dosya içeriğini cat komutu ile bastıralım. Bakın iki dosyanın içeriği, tam olarak komutta belirttiğim sıralama ile yani ilk olarak liste dosyası daha sonra liste2 dosyası olacak şekilde birleştirilip tek bir dosya haline gelmiş oldu.

Bu örnek cat komutu ve yönlendirme operatörleri ile yapabileceklerimize dair çok basit bir örnek.

Bahsettiğimiz basit kullanım dışında dilersek cat komutunun -n seçeneğini kullanarak bastırılan çıktıların kaç satırdan oluştuğunu da öğrenebiliriz. Buradaki n seçeneği ingilizce number ifadesinin kısaltmasından geliyor. Zaten bu seçeneğin uzun yazılışı da —number şeklinde. Teyit etmek için cat —help şeklinde yazıp yardım bilgilerini görüntüleyebiliriz. Bakın seçeneğin kısa veya istersek uzun halini kullanabileceğimizi buradan teyit edebiliyoruz. Ben genelde kısa seçenekleri tercih ettiğim için zorunda kalmadıkça seçeneklerin uzun hallerini kullanmıyorum. Sadece hazır yeri gelmişken seçeneklerin uzun hallerini de kullanabileceğimize bir kez daha dikkat çekmek istedim. Neyse, neticede yardım sayfasından da teyit edebildiğimiz üzere -n seçeneği ile tüm satırları numaralandırılmış şekilde bastırabiliyoruz. 

Ben örnek olarak ilk önce liste dosyasının içeriğini okumak istiyorum.

Gördüğünüz gibi satır numaraları ile birlikte liste dosyasının tüm içeriği bastırıldı. Ayrıca eğer istersek, birden fazla dosya ismini argüman olarak verip, tek seferde tüm dosya içeriklerinin toplam satır sayısını da buradan görebiliriz. Ben denemek için bu kez liste2 dosyasının ismini de ekliyorum.

Bakın girdiğim komut sayesinde dosya içerikleri peş peşe sıralandığı için, satır numaraları da tek bir dosya içeriği gibi sıralı ve kesintisiz şekilde bastırılmış oldu. Neticede dosya içeriklerini sırasına uygun şekilde birleştirmiş ve numaralandırmış olduk. Zaten cat komutunun "concatenate" açılımının "bağlamak, birleştirmek veya sıralamak" anlamına geldiğinden bahsetmiştik, bu çıktılar da bu durumu kanıtlıyor. İstersek bu çıktıları da tek bir dosyaya yönlendirebiliriz. Mesela cat liste liste2 > sıralı-liste komutu ile aktarabiliriz. Dosya içeriğini cat komutu ile teyit ettiğimizde, gördüğünüz gibi numaralandırılmış çıktıların dosyaya kayıt olduğunu görebiliyoruz. Zaten cat aracı bu çıktıları üretip konsola yönlendiriyordu. Biz sadece cat aracının standart çıktılarını konsol yerine bir dosyaya yönlendirdik. 

Numaralandırmaya ihtiyaç duyduğumuzda işte cat komutunun n seçeneğini kullanabiliyoruz. Ayrıca numaralandırma işlemi sırasında, boş satırların görmezden gelinmesini de sağlayabiliriz. 

Benim örnekler sırasında kullandığım dosyalarda boş satırlar bulunmuyordu. Eğer dosya içeriğinde boş satırlar bulunuyorsa, cat komutu bu satırları da numaralandırmaya dahil ediyor. Eğer boş satırların numaralandırılmasını istemezsek "blank" yani "boşluk" ifadesinin kısaltmasından gelen "b" seçeneğini kullanabiliyoruz. Teyit etmek için öncelikle içerisinde boş satırları olan bir dosya oluşturmamız lazım. Ben dosya oluşturmak için yine cat aracını kullanacağım. Dosya içeriğinde birkaç kelime ve belirgin şekilde birkaç boş satır yeterli olacaktır. Tamamdır Ctrl + D ile veri girişini sonlandıralım. 

Öncelikle yeni oluşturduğumuz bu dosyayı cat komutu ile bastırarak boş satırların da bastırıldığını teyit edebiliriz. Bakın dosya içeriğine nasıl eklediysem aynen boş satırlar da bastırıldı. Dosya satırlarını numaralandıracak olursak yine aynı durum geçerli olacak. Hemen -n seçeneğini ekleyip komutumuzu tekrar girelim. Bakın boş olan satırların da numaralandırıldığını görebiliyoruz. Eğer n seçeneği yerine yalnızca b seçeneğini kullanırsak, görebildiğiniz gibi boş olan satırlar atlanıp, yalnızca içerisi dolu olan satırlar numaralandırılmış oluyor. 

İşte cat komutunun en temel ve sık kullanılan özellikleri bunlar. Zaten daha önce yönlendirmeleri kullanarak yeni dosyalar oluşturup içerisine nasıl veri ekleyebileceğimizden defaatle uygulamalı olarak söz ettiğimiz için cat komutu ile söyleyeceğim ek bir detay bulunmuyor. 

Şimdiye kadar kullanma sıklığımızdan da tahmin ettiğiniz gibi cat komutu en sık kullanacağımız komutların başında geliyor. cat aracı hatırlanması ve kullanımı basit ancak metinsel verileri okuma birleştirme ve yenilerini oluşturma gibi en temel konularda etkili bir araç. cat komutunu kullanarak ihtiyaçlarınıza uygun çözümler üretmek tamamen sizin yönlendirmeleri ve cat komutunun çalışma yapısını ne kadar iyi anladığınıza bağlı. Daha iyi anlamak adına birkaç örnek yapabiliriz. 

Örneğin cat aracını bir dosyanın içeriğini kopyalamak için kullanabiliriz mesela. Bunun için `cat kopyalanacak_dosya > dosyanın_kopyası` şeklinde komut girmemiz yeterli oluyor. Mesela ben liste dosyasını kopyalamak istersem cat liste > liste3 komutuyla bu dosya içeriğinin liste3 isimli dosyaya kopyalanmasını sağlayabiliyoruz. cat liste3 komutu ile üretilen kopya dosyayı okuyalım, bakın liste dosyasının içeriği kopyalanarak liste3 isimli dosya oluşturup bu dosyaya aktarılmış.

Burada gerçekleşen işlemi temel olarak açıklamamız gerekirse; Girmiş olduğumuz komut sayesinde cat aracı kopyalanacak dosyanın içeriğini okuyor ve buradaki büyüktür işareti sayesinde bu içeriği standart çıktıya yönlendiriyor. Normalde biz özellikle belirtmediğimiz sürece standart çıktı bizim konsolumuza bağlı olduğu için biz cat aracının çıktılarını konsolda görüyoruz. Ama ben burada standart çıktıyı büyüktür operatörü ile liste3 isimli dosyaya yönlendirdiğim için çıktılar bu dosyaya aktarılıyor. Bu sayede liste dosyasının içeriğiyle aynı içeriğe sahip liste3 isimli dosya oluşturuluyor. Yani bir nevi liste dosyasını kopyalamış oluyoruz.

Elbette benim ele aldığım temel kullanımı dışında cat komutunun daha birçok seçeneği mevcut. Bu seçeneklere göz atmak için tekrar cat —help şeklinde komutumuzu girebiliriz. Doğrusunu söylemek gerekirse ben etkileşimli kabuk kullanımında n ve b seçeneği dışında buradaki hiç bir seçeneği kullandığımı hatırlamıyorum. Muhtemelen ya ihtiyacım olmamıştır, ya da daha etkili veya benim kullanımına alışık olduğum alternatif araçları tercih etmişimdir. Sizlerin de ihtiyacı olacak elzem seçenekler olduklarını düşünmediğim için geri kalan seçeneklerden bahsetmeyeceğim. Ancak dilerseniz buradaki açıklamalı okuyup, tüm seçenekleri test edebilirsiniz. Buradaki help çıktısındaki açıklamalar yeterince açık gelmezse, internet üzerindeki rehber anlatımlara da kolaylıkla ulaşabilirsiniz. Zaten tüm eğitim boyunca tekrar ettiğim ve edeceğim gibi, bu eğitimdeki amacım temel kavramlardan bahsedip daha fazlasını nasıl öğrenebileceğimiz üzerinde durmak. Dolayısıyla tüm konulardan, tüm araçlardan veya araçların tüm seçeneklerinden bahsetmemi bekliyorsanız, üzgünüm bu gerçekleşmeyecek. Nitekim anlatıcı tarafında olmama karşın benim de henüz bilmediğim, hiç kullanmadığım için unuttuğum veya hiç karşılaşmadığım pek çok konu, kavram, araç ve seçenek bulunuyor. Ancak temel kavramların farkında olduğumuzda ve yeni bilgileri nasıl araştırıp bulabileceğimizi bildikten sonra zaten zaman içinde bilmemiz gereken tüm bilgi birikimini adım adım inşa edebiliyoruz. Yani özetle önemli olan iyi bir temel ve bu temele dayandırılan araştırma yetkinliği kazanabilmek. Anlatımlarımıza gelin cat komutunu tersi şekilde çıktılar sunabilen tac aracından bahsederek devam edelim.

# tac Komutu

Hatırlıyorsanız, ls komutunu ele alırken tüm çıktıları tersine çevirebilen reverse yani r seçeneğinden bahsetmiştik. Bu seçenek sayesinde ihtiyacımız olduğunda, listelerin ve sıralamaların tam tersi şekilde bastırılması mümkün oluyordu. İşte cat komutu ile okuduğumuz dosya içerikleri için de benzer bir ihtiyacımız olabilir. Örneğin cat komutu ile okuduğumuz bir dosya içindeki alfabetik olarak sıralanmış satırlara, ters alfabetik olarak ihtiyaç duyabiliriz. Bu durumda, cat aracının ismen de tersi olan tac aracını kullanabiliyoruz. 

Tac komutunu test edebilmek için öncelikle yeni bir dosya oluşturalım. Ben bulunduğum dizindeki tüm içerikleri ayrıntılarıyla birlikte büyükten küçüğe doğru okunaklı şekilde sıralayıp, çıktıları liste.txt isimli bir dosyaya aktarmak istiyorum. Bunun için ls -lhS > liste.txt şeklinde komutumu giriyorum. Çıktıların dosyaya aktarıldığını teyit etmek için cat komutu ile dosya içeriğini okuyabiliriz. Bakın dosya ve dizinlerin büyükten küçüğe doğru sıralanmış listesini görebiliyoruz. Eğer aynı dosyayı tac komutu ile okursak listenin tam tersi şekilde olması gerekiyor. Hemen deneyelim. Bakın tam olarak beklediğimiz gibi tüm çıktılar tam tersi şekilde oldu. Yani tüm satırları ters sıralama ile küçükten büyüye olacak şekilde görüntüleyebildik. İşte tac komutu tam olarak bu amaçla kullanılıyor. Satırları sondan başa doğru bastırmak istediğimizde tac aracını kullanabiliyoruz.

Belki bu örnekte kullandığımız ls komutunun zaten kendine ait terse çevirme işlevi yani -r seçeneği olduğu için, tac komutunun kullanımı size çok gerekli gibi gelmemiş olabilir ancak lütfen buradaki ls komutuna takılmayın. ls sadece kolay gözlemlenebilir dosya içeriği oluşturmak için kullandığımız basit bir örnek. Komut satırını kullanırken, sürekli metinsel veriler üzerinde çalıştığımız için, herhangi bir dosyadaki verilerin tersten sıralamasına ihtiyaç duyacağımız durumlar ile karşılaşmamız kaçınılmaz. Komut satırında çalışırken temelde her şeyi bayt akışından ibaret olduğunu unutmayın lütfen. Dosya içeriklerinden veya çeşitli araçlardan gelen verileri yani üzerinde çalıştığımız baytları istediğimiz doğrultuda manipüle edebildiğimiz sürece komut satırının gücünden faydalanabiliriz. Verileri manipüle etmenin önemini ileride daha iyi anlayacaksınız. Çünkü eğitimin devamında, pipe mekanizmasını kullanarak bir aracın ürettiği çıktıları başka bir araca yönlendirerek kompleks sorunlara basit çözümler sağlamış olacağız. Araçların bir arada çalışabilmesi için de gerektiğine akış halindeki verilerin bir sonraki araca uygun şekilde değiştirilerek aktarılması gerekecek. Her neyse dediğim gibi verileri istediğimiz şekilde değiştirebiliyor olmanın önemini ileride daha net anlayacaksınız. 

Ayrıca ben tek bir dosya ile örnek yaptım ama cat komutunda olduğu gibi tac komutuyla da birden fazla dosyayı aynı anda ters sıralama ile okuyabiliriz. Ben örnek olarak sırala harfler ve sayılar içeren iki dosya oluşturmak istiyorum. Kolayca oluşturmak için daha önce öğrendiğimiz süslü parantez genişletmesini kullanabiliriz. A dan z ye kadar olan karakterleri `echo -e "\n"{a..z} > harf.txt` komutu ile harf.txt dosyasına kaydedebiliriz. Buradaki echo komutu ile kullandığımız -e seçeneği tırnak içinde yazdığımız "yeni satıra geçeme" yani \n ifadesinin çalışmasını sağlıyor. Bu sayede a dan z ye kadar her satıra bir karakter basılıyor. Merak etmeyin echo komutunu kullanırken bu konudan tekrar bahsedeceğiz. Şimdilik ihtiyacımız olan dosyayı oluşturmak için kullanabiliriz. Benzer şekilde 1 den 30 a kadar olan sayıları satır satır sıralamak için de komutumuzu `echo -e "\n"{1..30} > sayi.txt` şeklinde düzenleyip girebiliriz. Evet neticede içinde istediğimiz türde veriler bulunan iki dosyamızı kolayca oluşturabildik. İçeriklerini görüntülemek için aynı anda iki dosyayı da cat komutu ile açabiliriz.

Bakın, verdiğim dosya sırlamasına uygun şekilde tek seferde dosya içerikleri sıralı şekilde bastırıldı. Aynı dosyaları tac komutu ile de bastırabiliriz. Bakın yine verdiğim dosya sırlamasına uygun ancak bu kez dosya içerikleri tersten sıralanmış şekilde bastırıldı. Böylelikle tac komutunun, satırları tersten bastırdığını birden fazla dosya üzerinde de uygulayarak tekrar teyit etmiş olduk.

Neticede tac komutu cat komutu kadar kolay hatırlanabilir basit bir komut. tac komutunun tersten yazılmış hali olması zaten işlevi hakkında unutulmaz bir hatırlatıcı. Hazır terslikten bahsetmişken bir sonraki derste rev komutundan da kısaca bahsederek devam edebiliriz.

# rev Komutu

Eğer mevcut satırların sırlanmasını değil de doğrudan satırdaki karakterleri tersine çevirmek istersek rev aracını kullanabiliyoruz. rev aracının ismi ingilizce "reverse" yani "ters" ifadesinin kısaltmasından geliyor. Kullanımı son derece kolay, rev komutunun ardından satırlarındaki karakterlerini tersine çevirmek istediğiniz dosyayı yazmanız yeterli oluyor.

Nasıl bir etkisi olduğunu test etmek için hemen basit bir metin dosyası oluşturmayı deneyebiliriz. Ben bunun için cat > metin.txt komutunu girip,

```bash
cat > metin.txt 
bu basit

bir metin

dosyasıdır
```

şeklinde  yazıp ctrl d ile veri girişini sonlandırıp dosyanın kaydedilmesini sağlıyorum. 

Aradaki farkı daha net gözlemleyebilmek için öncelikle dosyayı tekrar cat komutu ile bi okuyalım. Bakın dosyanın standart hali bu şekilde. Şimdi aynı dosyayı bir de rev komutu ile tekrar okumayı deneyelim. Bakın bu kez tüm satırlardaki karakterler tersine dönmüş oldu. Yani tek tek tüm satırlarda yer alan sondaki karakter başa, baştaki de sona gidecek şekilde bir terslik elde edebildik. Neticede pek alışılmadık ama gerektiğinde lazım olabilecek bir çıktı elde etmiş olduk. Bu çıktıyı istediğiniz bir dosyaya veya araca yönlendirip, verilerin ters şekilde kaydolmasını veya işlenmesini sağlayabilirsiniz. 

Esasen rev komutu tac komutu kadar sık kullanılmasa da ismi dolayısıyla hatırlaması en kolay komutlardan. Satırlardaki karakterleri terse çevirmeye nadiren ihtiyacımız oluyor. Yine de söz konusu verilerin manipülasyonu olduğunda rev aracımız da bize kolaylık sunan bir diğer araç. Ve ne zaman ihtiyacımız olacağı hiç belli olmaz. Neticede artık bu komutun varlığından ve işlevinden haberdarsınız. İhtiyaç duyduğunuzda kısa sürede hatırlayıp kullanabilirsiniz.

# touch Komutu

[https://linuxize.com/post/linux-touch-command/](https://linuxize.com/post/linux-touch-command/)

Biz daha önce yeni boş dosyalar oluşturmak üzere touch aracını kullanmıştık. Bu işlevinin yanında aslında touch aracı var olan dosyaların tarih bilgilerini değiştirmek için kullanılan bir araç. 

Daha önce ls komutunun ayrıntılı çıktılarında ve bu çıktıları tarihlere göre sıralarken zaten dosya ve klasörlerin tarih bilgisinin tutulduğunu söylemiştik.

Şimdi özellikle bu konu üstünde duracak olursak sistem üzerinde oluşturulan tüm dosyaların oluşturulma, değiştirilme ve güncellenme tarihleri olmak üzere temelde üç zaman etiketi bulunuyor. Biz istersek touch aracı sayesinde bu tarihleri değiştirebiliyoruz. 

Fakat öncelikle bu bilgileri görmek için stat komutunu kullanalım. stat komutu sayesinde dosya ve dizinler hakkında çeşitli öznitelik bilgilerini görüntüleyebiliyoruz. Ben test edebilmek için daha önce test isimli dosya oluşturmuştum. Attributes olarak geçen öznitelik bilgisini öğrenmek için stat test şeklinde komutumu girebilirim. Bakın dosya hakkında pek çok bilgi bastırıldı. Burada şu an yalnızca tarih bilgileriyle ilgileniyorum. 

Buradaki erişim tarihi, bu dosyanın en son herhangi bir araç ile açıldığı okunduğu yani erişildiği tarihi veriyor. Örneğin cat ile bu dosyayı okuduğunuzda erişim tarihi değişecektir. Hemen denemek için yeni bir konsol açalım. Şimdi test dosyamızı cat veya herhangi bir araç ile açarsak buradaki erişim tarihi değişmiş olacak. Ben cat test komutu ile dosyamı okuyorum. Bakın dosya içeriği konsola bastırıldı. Şimdi önceki konsolumuzda tekrar stat test komutu ile güncel tarih bilgisini öğrenelim. 

Bakın önceki çıktı ile kıyasladığımızda, yalnızca erişim tarihinin değişmiş olduğunu görebiliyoruz. 

Diğer tarih bilgisine bakacak olursak, düzenleme tarihi, bu dosya içeriğinin değiştirilmiş olduğu tarihi veriyor. Örneğin yeni bir veri eklediyseniz veya var olan verileri sildiyseniz dosyanızın düzenlenme tarihi değişiyor. Ben denemek için echo “yeni veri” >> test komutu ile yeni bir veri eklemek istiyorum. Şimdi tekrar stat test komutu ile tarih bilgisine bakalım. 

Bakın düzenleme tarihi düzenlemeyi yaptığımız tam tarih olarak değişmiş. Ayrıca bakın burada değişim tarihinin de aynı şekilde değiştiğini görebiliyoruz. 

Değişim tarihi de değişti çünkü buradaki değişim tarihi bilgisi, dosyanın özniteliklerin ya da dosya içeriğinin değiştirilme tarihini ifade ediyor. Yani örneğin siz dosyanın ismini, yetkisini, bulunduğu dizini veya dosya içeriğini değiştirdiğiniz bu tarih de değişiyor.

Dolayısıyla bir dosyanın içeriğini değiştirirseniz hem düzenleme hem de değişme tarihi değişiyor. Fakat yalnızca dosyanın ismi, konumu veya yetkileri gibi özniteliklerini değiştirdiğinizde sadece değişme tarihi güncelleniyor. Bu durumu teyit etmek için dosyamızı mv komutu ile aynı dizinde yeni bir isimle kaydedebiliriz. Yani dosyamızın ismini değiştirmeyi deneyebiliriz. Ben bunun için mv test test2 şeklinde komutumu giriyorum. Bakın mv komutundan sonra girdiğim ilk argüman taşınacak dosyayı ikincisi ise hangi dizine taşınacağını belirtiyor. Ben harici olarak ekstra bir dizin adresi belirtmediğim için göreli yol gereği mevcut dizinde burada belirttiğim isimde kaydediliyor. Yani dosyamın ismini güncellemiş oluyorum. ls komutu ile de teyit edebiliriz. Bakın dosyamın ismi değişmiş. Şimdi tekrar stat test2 komutu ile tarih bilgisine bakalım.

Bakın dosyayı taşıyarak ismini değiştirdiğimiz için yalnızca değişme tarihi güncellenmiş. Dosya içeriğinde düzenleme yapmadığımız için düzenleme tarihinde bir değişiklik yok. İşte buradaki temel tarih bilgileri ve bunların değişme koşulları bizzat burda örnekler üzerinden teyit ettiğimiz şekilde çalışıyor.

Ayrıca bakın burada dosyanın oluşturulma tarihi de mevcut. 

Bu bilgi tüm dosya sistemlerinde desteklenmediği için tüm sistemlerde göremeyebilirsiniz. Yine de güncel mimariye sahip bir sistemde çalışıyorsanız yeni dosya sistemleri dolayısıyla dosyanın oluşturulma tarihi de tutuluyordur mutlaka. 

Neticede bakın benim sürekli öznitelik olarak bahsetmiş olduğum bu meta veriler üzerinden dosya hakkında çeşitli tarih bilgilerini öğrenebiliyoruz. Sistem yönetimi sırasında özellikle sırlama ve denetleme gibi işlevleri yerine getirirken bu bilgilerden faydalanabiliyoruz.

touch komutu da erişim ve düzenleme tarihlerinin doğrudan değiştirilmesi konusunda bize yardımcı oluyor. 

Örneğin ben dosyanın erişim tarihini güncellemek istersem access yani erişim ifadesinin kısaltmasından gelen a seçeneği ile touch -a dosya ismi şeklinde dosyanın erişim tarihini şimdiki tarih ile değiştirebilirim. 

Bakın erşim tarihi bu komutu girdiğim zaman olarak değişmiş.

Benzer şekilde yalnızca düzenlenme tarihini değiştirmek istiyorsam modify ifadesinin kısaltmasından gelen m seçeneğini de kullanabilirim. Hemen tekrar teyit etmek için stat komutuyla dosyamızın düzenlenme tarihine bakalım. Bakın düzenlenme tarihi de şimdi olarak değişmiş. 

Bu iki seçenek de kullanıldıklarında, sistemimizin mevcut tarih bilgisine göre erişim ve düzenlenme saatlerini değiştiriyor.

Eğer biz mevcut saatimiz yerine spesifik bir tarih belirtmek istersek date ifadesinin kısaltmasından gelen -d seçeneğini kullanarak tam tarih bilgisini yazmamız gerekiyor.

Ben denemek için 2015 yılının 1 haziran gününde saat tam 12 33 yi hem erişim hem de düzenleme tarihi olarak tanımlamak istediğim için komutumu touch -d “1 Jun 2015 12:33” test şeklinde giriyorum. Bakın burada gün ay yıl ve saat ile dakikayı parantez içinde belirttik. Şimdi stat komutuyla tekrar sorgulayalım. Bakın hem erişim hem de düzenlenme tarihi değişmiş.

Ayrıca yalnızca her ikisini de aynı anda değiştirmek zorunda değiliz. Ben yalnızca düzenlenme saatini değiştirmek istediğim için en son girmiş olduğum komutu tekrar çağırıp bu kez “m” seçeneğini de ekliyorum. Ve düzenlenme tarihi olarak da ocak ayını ifade etmek için Jan yazıyorum. 

Tamamdır şimdi stat komutu ile kontrol edelim. Bakın bu kez de yalnızca düzenlenme tarihi tam olarak benim belirtmiş olduğum tarih olarak değişmiş oldu.

İşte touch aracının en temel kullanımı bu şekilde. Yani artık touch aracının yalnızca boş dosya oluşturmak için değil, aslında tarih bilgilerini düzenlemek için kullanıldığını biliyoruz. Tarih değişimine pek ihtiyaç duymasanız da ihtiyaç duyduğunuzda bu aracın kullanımını anımsıyor olacaksınız. Zaten kullanımı çok basit olduğu için seçenekleri unutmuş olsanız bile touch —help komutuyla kontrol edebilirsiniz. 

# echo Komutu

Daha önce örneklerimizde echo komutunu sıklıkla kullandık. echo ifadesi sizin de bildiğiniz gibi Türkçe olarak "yankılanmak, yansıtmak" anlamına geliyor. Günlük hayatta ses yankılandığında eko yaptığını söylüyoruz ya işte bu komutta buna ithafen bu şekilde isimlendirilmiş. Zaten komutun işlevi de tam olarak bu. Kendisine argüman olarak verilenleri konsola veya yönlendirildiği yere yansıtıyor. En basit haliyle echo komutundan sonra yazacağımız tüm ifadeler, echo tarafından konsola bastırılıyor. Ben örnek olarak echo merhabalar yazıyorum. Gördüğünüz gibi merhabalar çıktısı konsola basıldı. Dilersek konsola bastırmak yerine herhangi bir dosyaya da yönlendirebiliriz. Örneğin echo "hello" > hello.txt komutunu girersem, hello ifadesi hello.txt dosyasına yazılmış olacak. Zaten daha önce de echo komutunu bu şekilde yönlendirmelerle birlikte kullanmıştık. Bakın dosyamız oluşturulmuş ve içerisine hello verisi de eklenmiş.

Ayrıca echo komutunu yalnızca tek satırlık veriler için kullanmak zorunda da değiliz. Eğer yazacaklarımız birden fazla satır tutacaksa, tırnak işaretini kapatmadan satır satır yazmak istediklerimizi yazabiliyoruz. Ben örnek olarak echo "deneme yazıp enter ile bir alt satıra geçiyorum. Normalde tırnağı kapatmış olsaydım "deneme" ifadesi doğrudan konsola basılacaktı. Tırnağı kapatmadığım için kabuk, hala girecek verilerim olduğunu biliyor ve ben tırnağı kapatana kadar bekliyor. Ben alt alta yeni ifadeler ekliyorum. Son olarak eğer bu veriler konsola basılsın istersem, tırnağı kapatıp enter tuşuna basmam yeterli. Bu sayede kabuk benim veri girişini sonlandırdığımı anlayıp bu verileri echo aracına argüman olarak iletmiş olacak. echo aracı da bunları tekrar konsola yönlendirip çıktı olarak görmemizi sağlayacak.

Bakın bu şekilde alt alta satırları da bastırmış olduk.

Eğer konsola bastırmak yerine bu yazdıklarımı bir dosyaya yönlendirmek istersem tırnağı kapattıktan sonra yönlendirme operatörü ile ilgili dosyayı belirtip enter ile işlemi onaylayabilirim. Ben denemek için yine echo şeklinde komutumu girip, tırnak işaretini koyduktan sonra alt alta birkaç satır ekliyorum. Şimdi eğer bu çıktılar konsola bastırılsın istersem tırnağı kapatıp enter ile komutumu onaylayabilirim. Ama ben bu çıktıların sonuclar isimli bir dosyaya yönlendirilmesini istediğim için tırnağı kapattıktan sonra yönlendirme operatörü ile bu dosyaya yönlendiriyorum ve enter ile komutumu şekilde onaylıyorum.

Bu sayede echo komutuyla alt alta yazmış olduğum tüm satırlar artık “sonuclar” dosyasının içerisinde. Bakın cat komutu ile dosya içeriğini okuyarak, girdiğim verilerin satır satır dosyaya yönlendirilmiş olduğunu teyit edebiliyorum.

echo komutunun çıktılarını bir dosyaya sorunsuzca yönlendirebildik ancak daha önce de bizzat deneyimlediğimiz gibi echo komutunun standart girdiden veri okumadığına tekrar dikkatinizi çekmek istiyorum. Bu durumu tekrar teyit etmek istersek, örneğin biraz önce echo komutu ile içine satırlar eklediğimiz sonuc.txt dosyasını echo komutu aracılığı ile konsola bastırmak üzere echo < sonuclar şeklinde komutumuzu girebiliriz. Normalde buradaki yönlendirme operatörü sayesinde sonuclar dosyasının içindeki veriler echo komutunun standart girdisine yönlendiriliyor olacak. Hemen komutumuz onaylayıp sonucu gözlemeyelim. Bakın, gördüğünüz gibi konsola herhangi bir çıktı basılmadı. Çünkü echo komutu standart girdiden veri okumuyor. Biz göndersek de echo komutu standart girdiden veri kabul etmediği için echo komutuna aslında yankılayabileceği hiç bir şey vermemiş olduk. Dolayısıyla konsola hiç bir şey bastırılmadı. echo komutu çalışma yapısı gereği yalnızca kendisine argüman olarak verilmiş olan ifadeleri konsola yankılıyor yani bastırıyor. 

Zaten help echo komutu ile yardım sayfasına göz atacak olursak, bakın yardım bilgisinin en üstünde echo komutunun argümanları standart çıktıya yazdırdığı açıkça yazıyor. Ayrıca gördüğünüz gibi standart girdiden veri kabul ettiğine dair herhangi bir açıklama da bulunmuyor. Burada kast edilen argüman yapısının ne olduğunu zaten biliyorsunuz. 

Özetle echo yalnızca kendisine argüman olarak aktarılanları standart çıktı aracılığı ile konsola veya özellikle belirtildiyse başka bir hedefe yönlendirmekle mükellef bir araç. Eğer hatırlıyorsanız, ben yönlendirmelerden bahsederken kimi araçların standart girdiden veri almayabileceğinden de bahsetmiştim. İşte echo aracı da bahsi geçen bu araçlardan biri. Kimi araçlar yalnızca argümanları işlemek için tasarlandıklarından, standart girdiden veri kabul etmiyorlar. 

Hatta echo komutunun argümanları yankıladığına dair basit bir örnek vermek gerekirse echo * komutunu kullanabiliriz. Biliyorsunuz buradaki yıldız işareti kabuk için tüm dosya ve dizin isimleriyle eşleşen bir genişletme karakteri. Dolayısıyla bu karakterin olduğu yere kabuk tarafından mevcut dosya ve dizin isimlerinden uygun olan tüm karakterler getirilebiliyor. Kabuk echo komutunu gördüğünde bu aracı çalıştırması gerektiğini anlıyor, daha sonra yıldız simgesini görüyor. Yıldız işareti bash kabuğu için dosya ismi genişletmesi anlamına geldiği için kabuğumuz bu genişletmeyi uyguluyor. Yani yıldız işretinin yerini, mevcut dizindeki dosya ve klasörlerin isimleri alıyor. Dolayısıyla echo komutuna da argüman olarak dosya ve dizinlerin isimleri verilmiş oluyor. echo komutu da argümanlarını konsola çıktı olarak yansıtıyor yani standart çıktılarını konsola yönlendiriyor. 

İşte sizlerin de görebildiği gibi, kabuğun çalışma yapısını ve temel özelliklerini bildiğimizde, bu örnekte olduğu gibi komut verme konusunda inanılmaz esnekliğe sahip olabiliyoruz. Ben sadece dikkat çekici bir örnek olması için tekrar bu örneği ele aldım. 

Tıpkı bu örnekte olduğu gibi echo komutu da dahil tüm komutların pek çok esnek kullanım imkanları var. Yeter ki biz temelde nasıl çalıştıklarını bilelim.

Ayrıca şu ana kadar ele aldığımız kullanımlar dışında echo komutun pek çok ek seçeneği bulunuyor. Bunları görmek için tekrar help echo komutunu kullanabiliriz.

Bakın burada pek çok özel karakter bulunuyor. Hepsine tek tek değinmemize gerek yok. Ama kısaca bir göz atalım.

Normalde echo komutunun ardından yazdığımız ifade konsola bu şekilde basılıyor. Burada dikkat etmemiz gereken detay, aslında bizim girdiğimiz ifadeden sonra echo komutunun otomatik olarak yeni satıra geçme karakteri gizlice kullanıyor olması. Bu durumu teyit etmek için otomatik olarak yeni satıra geçme özelliğini kapatmak üzere -n seçeneğini kullanabiliriz. N seçeneği newline yani yeni satır ifadesinin kısaltmasından geliyor. Bu şekilde aklınızda daha kolay kalabilir.

Bakın -n seçeneğini kullandığımız için bir alt satıra geçilmedi, dolayısıyla prompt olarak ifade edilen bu komut girdisi alanı hemen aynı satırda bizden komut beklemeye başladı. Böylelikle echo komutunun aslında, gizli yeni satır eklediğini öğrenmiş olduk. Tekrar yardım sayfasını görüntüleyecek olursak, bakın burada pek çok biçimlendirme özelliği bulunuyor. Yani örneğin bakın echo komutu buradaki ters slash ile başlayan ifadeleri gördüğünde onların özel anlamlarına göre çıktıyı biçimlendiriyor. Fakat bu ifadeleri doğrudan kullanamıyoruz. Bu biçimlendirme ifadelerini kullanırken echo komutunun -e seçeneğini kullanarak, echo komutuna bu karakterlere özel anlamlarına göre muamele yapması gerektiğini özellikle belirtmemiz lazım. Aksi halde buradaki ifadeleri kullansak bile bunlar echo komutu için sıradan karakterlerden ibaret olacak. Hemen deneyelim. Ben yeni satıra geçmeyi sağlayan \n ifadesini kullanacağım. Komutumu echo "merhaba \n dünya" şeklinde giriyorum.  

Bakın çıktılarda \n ifadesi de olduğu gibi duruyor ve yeni bir satıra da geçilmemiş. Aynı örneğini bu kez -e seçeneği varken tekrar deneyebiliriz. Komutumuza -e seçeneğini de ekleyelim. Bakın bu kez \n ifadesi echo komutu tarafından dikkate alındı ve ikinci kelimemiz bir alt satırda bastırıldı. Dikkat ettiyseniz tırnak içinde yazdım. Çünkü biçimlendirme özelliklerinin doğru şekilde çalışması için tırnak içinde yazmamız gerekiyor. Daha önce tek ve çift tırnak kullanımı arasındaki farklardan bahsetmiştik. Bu doğrultuda tek veya çift tırnak kullanma seçimi size ait.

Ayrıca hatırlıyorsanız daha önce echo komutunu ve süslü parantez genişletmelerini kullanarak sıralı karakterleri alt alta olacak şekilde biçimlendirmiştik. Şimdi tekrar aynı komutu kullanıp sonuçlarına bakabiliriz. Ben aynı örneği gerçekleştirmek için `echo -e "\n"{a..z}` şeklinde komutumu giriyorum. Bakın bu komutta da echo komutunun -e seçeneğinden ve \n şeklinde yazılan yeni satır biçimlendirme özelliğinden faydalanıyoruz. Burada yeni satıra geçme işareti yani \n biçimlendirme karakterinin etkisini görmek için komutumuzu tekrar çağırıp bu biçimlendirme karakterini silip tekrar çalıştırmayı deneyebiliriz. Bakın yeni satıra geçme karakteri olmayınca tüm veriler aynı satırda bastırıldı. Bu örnek bu biçimlendirme karakterlerinin gerektiğinde oldukça kullanışlı olabildiğini gösteren çok basit bir örnek. 

İşte sizler de benim bu örnek üzerinden ele aldığım gibi, yardım sayfasında yer alan diğer tüm biçimlendirme özelliklerini -e seçeneği ile birlikte echo komutu üzerinden kullanabilirsiniz. 

Tabii ki buradaki seçeneklerin hepsini ezberlemek zorunda değilsiniz. Hatta hiç birini ezberlemeyin. Çünkü ezberlemeniz gerekmiyor, kullandıkça bu ifadeleri zaten hatırlıyor olacaksınız. Hatırlayamadığınız zaman yardım sayfasından kısa sürede tekrar bakabilirsiniz. Zaten kısaltmaların, temsil ettiği biçimlendirme özellikleri ile uyumlu olduğunu da göz önünde bulundurduğumuzda, pratik yaptıkça sık kullandığınız seçeneklerin hemen aklınıza geldiğini sizler de fark edeceksiniz. Ayrıca buradaki biçimlendirme ifadeleri, çoğu araçta benzer şekilde olduğundan bir kez öğrendiğinizde sistem üzerindeki metin biçimlendirme araçların pek çoğunda aynı ifadeleri kullanabiliyor olacaksınız.

Yani özetle benim bahsetmediğim diğer seçeneklerin açıklamasına bakarak, tam olarak nasıl bir biçimlendirme uyguladığını bizzat test etmeniz yeterli. Hem bu sayede pratik yapmış olursunuz. 

Örneğin bakın burada dikey tab biçimlendirmesi var. Acaba nasıl bir çıktı verecek ? Hemen deneyelim. echo -e "linux \v dersleri" şeklinde komutumu giriyorum. Bakın dikey tab bu şekilde bir biçimlendirme uyguluyormuş. Tıpkı bu örneğimizde olduğu gibi diğer bahsetmediğimiz biçimlendirme karakterini keşfetmek için artık tek yapmanız gereken geri kalan biçimlendirme özellikleri üzerinden pratik yapmak.

Şimdilik bahsetmiş olduğumuz bu temel bilgiler eğitime devam edebilmemiz için yeterli. Ancak bu dersi sonlandırmadan önce echo komutunun kara gün dostu olduğunu bilmenizi isterim. Echo komutu bash kabuğunun yerleşik bir komutu olduğu için bash kabuğunun bulunduğu her ortamda echo komutunu kullanabiliriz. 

Özetle, echo komutu göründüğünden daha önemli olabilir. Lütfen echo komutu için azami özeni gösterin. Basit bir komuttur ama tabii ki bu önemsiz olduğu anlamına gelmiyor.

Anlatımlarımıza paste komutu ile devam edebiliriz.

## paste Komutu

İleride dosya içeriklerini değiştirip dosyaların değişimlerini kıyaslamak için yan yana bastırmak istediğimiz örneklerle karşılaşacağımız için ilk olarak paste aracından bahsetmek istedim. Normalde cat komutu ile birden fazla dosyayı okurken dosyaların içerikleri peşi sıra alt alta bastırılıyorken, paste aracı ile bu çıktıların yan yana bastırılmasını sağlayabiliriz. Yani cat aracı satırların birleştirilmiş çıktılarını üretirken, paste aracı sütunların birleştirilmiş çıktılarını sunuyor.

Ben denemek için önceden oluşturduğum şehir harf ve rakam isimli dosyaları yan yana bastırmak istiyorum. Ama bundan önce cat komutu ile farkını daha rakat gözlemleyebilmek adına bu dosyaları okumak üzere cat harf sehir rakam şeklinde komutumu giriyorum.

Bakın tam da beklediğimiz gibi tüm dosyalardaki satırlar alt alta birleşik halde bastırıldı. Şimdi bunları yan yana bastırmak için paste harf sehir rakam şeklinde tekrar komut girmeyi deneyelim.

Bakın bu kez dosyalardaki satırlar üç farklı sütunda yan yana bastırılmış oldu. İşte bakın paste aracının bize sunduğu kolaylık tam olarak bu.

Burada dosya içeriklerinin kolay ayırt edilebilmesi için sütunlar arasında boşluklar yer alıyor. Fakat dilersek, bastırılan sütunlar arasında boşluk yerine özel bir işaret yani özel bir sınırlayıcı karakter de ekleyebiliriz. Örneğin ben her bir sütun arasına kısa dikey çizgi eklemek istiyorum. Paste aracına sütunları nasıl ayıracağını belirtmek için de ingilizce “delimiter” yani “sınırlayıcı” ifadesinin kısalmasından gelen -d seçeneğinin ardından sınırlayıcı karakteri yazabiliriz.

Ben dikey çizgiyi dosya içerikleri arasındaki sınırlayıcı olarak belirtmek için -d seçeneğinin ardından sınırlayıcı karakteri yani dikey çizgiyi tırnak içinde yazıyorum. Ve yan yana bastırmak istediğim dosyaların adını tekrar peşi sıra giriyorum. 

```bash
paste -d "|" rakam harf sehir
```

Bakın, tüm sütunların arasında dikey çizgi yer alıyor, çünkü ben sınırlayıcı karakter olarak buradaki dik çizgi karakterini tanımlamıştım. Tabii ki sizler dilediğiniz bir karakteri sınırlayıcı olarak kullanabilirsiniz. Hatta birden fazla sınırlayıcı karakter de belirtebilirsiniz. Örneğin dikey çizgi ve kısa çizgi karakterlerini sınırlayıcı olarak kullanırsak, sırasıyla iki sınırlayıcı da dosya içeriklerini sınırlamak için kullanılıyor olacak. Bu durumu daha net gözlemeyebilmek adına daha fazla dosyayı yan yana bastırsak daha iyi olur. Ben aynı dosyaları tekrar tekrar yan yana bastırmak istiyorum. Yani komutumu:

```bash
paste -d "|-" rakam harf sehir rakam harf sehir
```

Şeklinde giriyorum.

Bakın, gördüğünüz gibi sırasıyla hem dikey çizgi hem de kısa çizgi karakterleri sütunlar arasındaki sınırlayıcı olarak kullanılmış. İşte sizler de bu şekilde sütunları istediğiniz sınırlayıcı karakterle birbirinden ayırabilirsiniz. Birden fazla sınırlayıcı belirttiğimizde tıpkı burada aldığımız çıktıda da olduğu gibi bu karakterler sırasıyla soldan sağa doğru tekrar eden bir örüntü gibi kullanılıyor olacak. İhtiyacınız doğrultusunda tek ve birden fazla sınırlayıcı karakter belirtebilirsiniz. Hatta sınırlayıcı olarak tırnak içinde hiç bir karakter belirtmezseniz doğrudan boşluk olmadan dosyaların birbirine yapıştırılmasını da sağlayabilirsiniz. Ben bunun için sınırlayıcı değeri olarak tırnağın içinde hiç bir karakter yazmadan  `paste -d "" rakam harf sehir` şeklinde komutumu yazıyorum. Bakın tırnağı açıp doğrudan kapattım. Yani içinde boşluk bile bulunmuyor. Şimdi komutumuzu girelim.

Bakın, dosyalardaki tüm satırlar aralarında boşluk olmadan sütunlarda birleştirilmiş. İşte tıpkı bu örnekte olduğu gibi ihtiyacınıza yönelik şekilde sınırlayıcı karakter belirtmekte özgürsünüz.

Ayrıca sınırlama işareti dışında eğer her bir satırı yan yana değil de alt alta eşleşecek şekilde sıralamak istersek -s seçeneğini de kullanabiliyoruz. 

Ne demek istediğimiz daha net görmek adına öncelikle s seçeneği olmadan dosyaları bastıralım. Bakın dosyalarda yer alan tüm satırlar yan yana bastırıldı. Şimdi de -s seçeneğini kullanarak komutumuzu girelim.

Görebildiğiniz gibi normalde satırlar yan yana basılırken şimdi dosyalardaki her bir satır alt alta gelmiş şekilde basılmış oldu. 

Sizler ihtiyacınıza göre paste aracını kullanarak istediğiniz sayıda dosyanın satırlarını birebir yan yana ya da alt alta birleştirebilirsiniz. Eğer birden fazla dosya içeriğinin yan yana birleştirilmiş hali lazımsa komutunuzun sonuna yönlendirme işareti ekleyip çıktıları yeni bir dosya olarak kaydedebilirsiniz. Ben en son girdiğim komutun sonuna > paste-sonucları ekleyip çıktıları dosyaya kaydediyorum.

Bakın çıktılar dosyama kaydolmuş. Neticede paste aracını kullanarak mevcut dosyaları yan yana veya dikey olarak nasıl birleştirebileceğimizi de ele almış olduk. Ayrıca ben yönlendirmek için tek büyüktür yine yeni bir dosya oluşturmayı tercih ettim ama siz diğer yönlendirme alternatiflerini biliyorsunuz. 

Zaten artık hatırlatmama gerek yok. Sizler yönlendirmeler ile ilgili bilmeniz gereken tüm temel altyapıya sahipsiniz. İhtiyaçlarınıza göre sistem üzerinde tüm araçlarda kullanabilirsiniz. Özellikle veri bilimi gibi alanlarda çalışırken, bu şekilde birden fazla kaynaktan alınan verilerin istenildiği şekilde derlenebilmesi çok kullanışlı olabiliyor. Tüm mesele elimizdeki verileri ihtiyaçlarımıza göre düzenleyip kullanabilmek.

# sort Komutu

Özellikle düzensiz haldeki büyük veriler üzerinde çalışıyorken sort gibi araçlar yardımıyla bu verileri düzenlememiz gerekebiliyor. Tahmin edebileceğiniz gibi zaten buradaki sort aracının ismi de Türkçe olarak sıralamak-sınıflandırmak ifadelerine karşılık geliyor.

sort aracı sayesinde elimizdeki düzensiz verileri, belirli özelliklere göre kolayca sınıflandırabiliyoruz. 

Verileri sıralayıp düzenli hale getirebilmek için sort aracının kullanılabilecek pek çok özelliği olmasına karşın, eğer herhangi bir seçenek belirtmeden doğrudan karışık satırları sort aracına iletirsek;

Öncelikle tüm satırlardaki ilk karakterlere bakıp sırasıyla sayılar, daha sonra harfler ve son olarak eğer aynı harfler varsa küçük harfler öncelikli olacak şekilde sıralanıyorlar. Ve bu sıralama işlemi tüm satırlardaki tüm karakterler sıralanıncaya kadar tekrar tekrar devam ediyor. 

Yani ilk olarak tüm satırlardaki karakterlere bakılıp tüm satırlar buradaki kural dahilinde sıralanıyor. Daha sonra ilk karakteri aynı olan satırlar ikinci karaktere göre kendi içlerinde bir daha sıralanıyor ve bu işlem satırlardaki tüm karakterler bitine kadar bu şekilde gerçekleştiriliyor. Bu şekilde tüm satırlarda yer alan tüm karakterleri baştan sonra kendi standart kuralı dahilinde sıralamış oluyor.

Uygulamalı olarak daha net anlaşılacağı için hemen bir dosya üzerinde test edelim. Ben örnek olarak içerisinde küçük büyük harfler ve rakamlar bulunan bir şablon kullanacağım. Bakın benim kullanacağım şablon bu. İçerisinde düzensiz veriler bulunan bu şablonu kullanıyorum çünkü biraz önce bahsetmiş olduğumuz tüm sıralama kurallarını net biçimde görmemiz mümkün olacak. 

```bash
b3
ba
B3
3B
a2
A1
a1
2a
1b
3b
```

Görebildiğiniz gibi kullanacağımız bu şablon, içerisinde küçük büyük harfler ve rakamlar bulunan son derece düzensiz bir içeriğe sahip. Şimdi bu dosyanın ismini sort komutundan sonra argüman olarak yapıp düzenli bir listenin nasıl göründüğüne bakalım. Evet dosyanın içindeki tüm satırlar uygun şekilde sıralandı.

```bash
1b
2a
3b
3B
a1
A1
a2
b3
B3
ba
```

Aldığımız çıktıyı inceleyecek olursak. Bakın öncelikle tüm satırlardaki ilk karakterlere bakılmış ve bunlar sayısal olarak sıralanmış. Daha sonra alfabetik olarak sıralanmış. a karakteri b den önce geldiği için küçük büyük harf fark etmeksizin ilk harfinde a olan tüm satırlar ilk karakterinde b olanlardan önce sıralanmış. Alfabetik sıralamadan sonra da aynı karaktere sahip olan satırlarda küçük karakterler büyüklerden önce sıralanmış. Bakın küçük a karakterleri büyüklerden önce geliyor. Fakat bakın burada A1 satırı başında küçük a olasına rağmen a2 den önce gelmiş. Bu durumun nedeni ikinci karakterdeki 2 rakamı aslında. sort aracı sıralama işlemini tüm karakterleri tek tek sıralayıp tekrar tekrar sıralama yaptığı için bu şekilde çıktı aldık. Yani aslında sort aracı tıpkı bu örneğimizde olduğu gibi öncelikle sırasıyla tek tek karakterlere bakarak sıralama yapıyor olsa da tüm karakterlerin kendisine göre hesapladığı ağırlık değerlerine göre yeniden sıralanmasını sağlıyor.

Yani aslında sort aracı ilk turda yalnızca buradaki ilk karaktere bakarak listeyi şu şekilde sıralıyor. 

```bash
1b
2a
3b
3B
a1
a2
A1
b3
ba
B3
```

Daha sonra sıra ikinci karaktere bakmaya geliyor. Bu durumda ilk karakteri aynı olanları ikinci karaktere bakarak sıralıyor. Buradaki A1 satırındaki 1 rakamı a2 satırındaki 2 rakamından küçük olduğu için daha fazla öncelik kazanıyor. Dolayısıyla baştaki a karakterinin büyük küçük olması bu sıralamayı değiştirmiyor. Aslında buradaki çıktılar küçük büyük harf duyarlılığı görmezden gelindiği için bu şekilde sıralandı. Ne demek istediğimi anlamak için çok kısaca yerelleştirme konusunda bahsetmek istiyorum.

İşletim sisteminde hangi dilin hangi karakter şemasının kullanılacağını özellikle belirtebiliyoruz. Bu işleme de yerelleştirme deniyor. Dolayısıyla kullandığınız sistemdeki varsayılan karakter şeması bu sıralamanın nasıl yapılacağını da etkiliyor. Örneğin bakın Amerikan İngilizcesi için kullanılan aschii tablosu bu şekilde gözüküyor. Bakın tablodaki tüm karakterler sırasıyla numaralandırılmışlar. Örneğin bu tabloda büyük A harfi 65 numaralı karakter iken küçük “a” karakteriyse 97 numaralı karakter olarak gözüküyor. Dolayısıyla eğer sıralama işlemi için bu tablodaki sıralama dikkate alınacak olursa büyük A karakterinin küçük a karakterinden önce gelmesi ve diğer tüm temel karakter için de buradaki sıralama kurallarına dikkat edilmesi gerekiyor. 

İşte biz özellikle belirtmediğimiz sürece sort aracı bu tabloya göre sıralamayı dikkate almayacak. Eğer siz bu standart karakter şemasına göre sıralama yapılmasını istiyorsanız geçici olarak mevcut kabuğunuzdaki karakter şemasını “C” olarak geçen bu standart tablo ile değiştirmeniz yeterli. Aslında burada bahsi geçen bu yerelleştirme işlemleri ve karakter tabloları konumuzu biraz aşıyor fakat yine de ben çıktıları bir kez de bu şekilde sıralayıp size göstermek istiyorum.

Bunun için öncelikle mevcut kabuğumdaki karakter şemasını değiştirmek üzere export LC_ALL=C şeklinde değişkenimi tanımlıyorum. Tamamdır. Şimdi komutumuzu tekrar girelim.

Bakın bu kez karakterler tıpkı bu aschii şemasındaki sıralamaya uygun olarak önce sayılar daha sonra büyük karakterler ve sonra da küçük karakterle olacak şekilde sıralandı. Bu sayede biraz daha anlaşılır bir çıktı elde etmiş olduk. 

Burada bahsetmiş olduğumuz yerelleştirmelerden ve karakter şemalarından ayrıca bahsetmeyeceğim fakat buradaki anlatımlar yeterince açık olmadıysa ayrıca araştırma yapabilirsiniz. Aslında ben sadece sıralama için uyulması gereken karakter şemasını belirttim yalnızca. Bu sayede şemadaki sıralama ile aynı düzlemde çıktılar oluşturmuş olduk. 

Başta biraz kafa karıştırıcı gibi geliyor fakat çok farklı bir işleyiş değil. 

Ben standart sıralama kurallarının ve karakter şemasının değiştiğinde neler olduğunun kolay anlaşılabilmesi için şablonda anlamlı kelimeler kullanmadım, nitekim bu şablon üzerinden standart sıralama kurallarını net bir biçimde görebiliyoruz. Şablona ders kaynaklarından siz de erişebilirsiniz. Ya da kendiniz için daha farklı bir şablon da oluşturabilirsiniz. Elbette size daha basit gelecekse, şehir ya da insan isimleri yaşları gibi listeler üzerinden de sırlama çalışmaları yapabilirsiniz.

İlk örnekte tek bir dosyadaki satırları sıraladık ancak dilersek birden fazla dosyayı da tek seferde sort komutu ile sıralayabilirsiniz. Hem bu sayede birden fazla dosya içeriğini sıralı şekilde birleştirmiş oluruz. Tıpkı cat komutun olduğu gibi ancak bu veriler sıralanmış olacak.

Ben denemek için cat > sayi komutuyla yeni bir dosya açıyorum, içerisine de düzensiz şekilde tek ve çift basamaklı sayılar ekliyorum. Tamamdır, şimdi bir de harf diye bir dosya oluşturalım içerisine de yine küçük büyük harfleri düzensiz şekilde ekleyelim. 

```jsx
a
g
F
z
D
g
O
p
l
k
S
C
E
n
M
h
t
N
```

Bu da tamam. Öncelikle dosyalarımızı ayrı ayrı sıralayalım. sort harf şeklinde komutumu giriyorum. Bakın biraz önce karakter seti olarak C şeklinde ayarladığım için yine büyük harfler başta olacak şekilde tüm dosya içeriği alfabetik olarak sıralandı. Şimdi bir de sayıları sıralayalım. Sayılar da sıralandı. Ama sanki aldığımız çıktı biraz tuhaf gibi. Normalde sayıların sıralanması deyince insanın aklına iki basamaklıklar da dahil tüm hepsinin küçükten büyüğe doğru sıralanması gerektiği geliyor. Ama önceki açıklamalarımıza dikkat ettiyseniz sort komutu her bir satırın yalnızca tek bir karakterini sıralıyor. Dolayısıyla sıralama yapılırken aslında sayılar değil 0 dan 9 a kadar olan rakamlar arasında sıralama yapılıyor. Bakın buradaki ilk karakter olan yani ilk basamakta yer alan tüm rakamlar zaten matematiksel olarak küçükten büyüğe doğru sıralanmış. İlk karakterler sıralandıktan sonra da ilk karakteri yani ilk basamağı aynı olan rakamların da ikinci basamakları kendi içlerinde tekrar sıralanmış. 

Yani bizzat örnek üzerinden gördüğümüz gibi sort komutu tam olarak bu şekilde çalışıyor. Yani aldığımız çıktıda herhangi bir problem yok. Sort komutu buradaki sayıların bütüncül matematiksel büyüklüğüne bakmıyor, tek tek her bir satırdaki birer karakterlere bakıp ona göre sıralıyor. 

Eğer dosya içeriğinin matematiksel büyüklüğü dikkate alınarak sıralansın istersek bunu numerical yani sayısal ifadesin kısaltması olan -n seçeneği ile özellikle belirtmemiz gerekiyor. Şimdi sayi dosyasını -n seçeneğini de kullanarak tekrar sıralayalım. Bakın bu kez dosya içeriğindeki veriler matematiksel büyüklüklerine göre sıralandı. Yani eğer sayısal sıralama yapacaksınız n seçeneğini kullanmanız gerektiğini unutmayın lütfen. Ya da unutun, tekrar yardım sayfasına bakıp hatırlayabilirsiniz zaten. Sadece yeri gelmişken bahsetmek istedim. Her neyse, neticede dosyalarımızı ayrı ayrı sıralamayı başardık. 

Şimdi tek seferde iki dosyayı birden sıralamayı deneyebiliriz. Bunun için komutumu dosyaların isimlerini belirterek yani `sort harf sayi` şeklinde giriyorum.

Bakın, öncelikle rakamlar, daha sonra alfabetik olarak büyük harfler ve küçük harfler olacak şekilde iki farklı dosya tek bir dosyaymışçasına sıralanmış oldu. Böylelikle gördüğünüz gibi birden fazla dosya içeriğini tek seferde kolayca sıralayabiliyoruz. Bir de bu arada sort komutuna verdiğimiz dosyaların isimlerinin sıralamasının bir önemi yok. Çünkü zaten hepsini aynı sıralama kuralına tabii olduğu için ilk veya son dosya olması bir şeyi değiştirmiyor. Sort komutu tüm içeriği tarayıp en son sıralama yapıyor. Dilerseniz dosya isimlerinin sıralamasını değiştirip komutumuzu tekrar girebiliriz. Bakın yine aynı sıralamayı elde ettik. Bu sıralanmış verileri de istersek yönlendirme operatörü ile başka bir dosyaya kaydedebiliriz. Ben komutumu bu kez sort rakam harf > siralama.txt şeklinde giriyorum. Bu sayede birden fazla dosyadan veri alıp sıralanmış hallerini tek bir dosyaya yani siralama.txt dosyasın kaydetmiş oldum. Bakın dosya içeriğinde sıralanmış olan tüm veriler bulunuyor.

## Sıralamayı Tersine Çevirmek

Eğer sort komutunun sıraladığı satırları tersine çevirmek istersek, "reverse" yani "ters" ifadesinin kısaltması olan "r" seçeneğini kullanabiliyoruz.

Rahatça kıyaslayabilmek için öncelikle seçenek olmadan sort komutunu kullanalım. Ben yine şablon dosya içeriğini sıralamak istiyorum. Bakın standart sort komutunun kuralları dahilinde dosya içeriği sıralandı.

Şimdi de -r seçeneğini ekleyip tersten sıralayalım. Bakın iki çıktıyı kıyasladığımızda, satırların tam tersi şekilde sıralandığını görebiliyoruz. Sizde bu seçenek sayesinde elinizdeki verileri ters alfabetik ya da ters numerik şekilde sıralayabilirsiniz. 

## Sütunlar Özel Sıralama

Biliyorsunuz, sort komutu en baştan başlayıp tüm satırlardaki karakterleri tek tek sıralıyor. Fakat biz her zaman satırların en başındaki karaktere bakılmasını istemeyebiliriz. Yalnızca her satırın en başındaki karaktere göre sıralama yapmak yerine eğer mevcutsa, diğer sütunlara göre sıralama yapılmasını da sağlayabiliriz.

Örnek olarak şehirler ve plakaları olan bir şablon kullanabiliriz. Bakın dosya içeriği bu şekilde birkaç şehri ve ikinci sütunda şehirlerin plakalarını içeriyor.

istanbul 34

Kocaeli 41

İzmir 35

erzincan 24

Edirne 22

Eğer seçenek kullanmadan yalnızca sort komutunu kullanırsak, en baştaki karakterlere göre sıralanacak. Hemen deneyelim. Bakın çıktılar ilk sütundaki ilk karakterlere göre sıralandı.

Şimdi sort komutuna yalnızca 2 sütuna bakarak sıralama yapmasını söyleyelim. Bunun için -k seçeneğini kullanabiliyoruz. Hangi sütuna göre sıralanacağını belirtmek için -k seçeneğinden sonra sütun sayısını girmemiz gerekiyor. Ben 2. sütuna göre sıralanmasını ve matematiksel büyüklüğe göre sıralanmasını istediğim için komutumu sort -nk 2 dosya adı şeklinde giriyorum. Buradaki n seçeneğinin sayısal sıralama yaptığını zaten daha önce bizzat deneyimlemiştik. 

Gördüğünüz gibi girmiş olduğum -k seçeneği sayesinde bu kez 2. sütuna yani plaka sayılarına göre sıralama yapıldı. İşte sizler de içerisinde birden fazla sütun bulunan bu gibi dosyaların, hangi sütunlarına göre sıralanması gerektiğini -k seçeneği ile özellikle belirtebilirsiniz.

### Yalnızca Benzersiz Olanları Bastırmak

Eğer sort komutuna verilen girdide birbirini tekrar eden satırlar varsa bunları tek bir satır olarak bastırabiliriz. sort komutunda bu filtrelemeyi uygulamak için ingilizce unique yani benzersiz ifadesinin kısaltması olan u seçeneğini kullanabiliyoruz.

Ben denemek için basit bir isim soyisim dosyası kullanacağım.

Bakın burada isim kısmı aynı olan satırlar ve isim soy isim aynı olan satırlar var. sort -u komutunu çalıştırıp nasıl bir çıktı elde edeceğimize bakalım.

Bakın isimler kısmı aynı olmasına rağmen satırlar basıldı. Fakat birebir aynı olan satırlar yani isim ve soy isimin aynı olduğu satırlardan yalnızca bir tanesi basıldı. Yani gördüğünüz gibi bu şekilde birebir tekrar eden satırları -u seçeneği ile tek bir satır basılacak şekilde sıralayabiliyoruz.

Benzersiz satırları bastırdık bu harika fakat burada ek bir detay var o da küçük büyük harf farklılığı. Benim kullandığım dosya içeriğinde büyük harf yok, ama eğer dosya içeriğinde aynı satırların büyük harfleri farklı olan aynı ifadeler varsa u yani uniq seçeneği bunları filtrelemez. Ne demek istediğimi uygulama üzerinden daha net anlayabiliriz. Şimdi ben dosyamın sonuna cat >> komutu ile yeni veriler ekleyeceğim. Ben bu sondaki ifadenin birebir aynısını büyük harfler ile yazıyorum. Bir de başlangıç harfi büyük olacak şekilde yazıyorum ve verileri ctrl d ile kaydediyorum. Şimdi dosya içeriğini tekrar bir cat komutu ile inceleyelim. Bakın sondaki satılar birebir aynı yalnızca küçük büyük harfleri farklı. Hadi şimdi sort -u komutunu kullanıp filtrelemenin nasıl olacağına bakalım. Bakın birebir aynı ifade olmasına karşın küçük büyük harfleri farklı olduğu için bunlar da bastırıldı. Eğer küçük büyük harf duyarlılığını kaldırmak istersek bunun için -f seçeneğini kullanabiliriz. Nasıl bir etkisi olacağını görmek için komutumuzu -f seçeneğini de ekleyerek sort -uf şeklinde girelim.

Bakın bu kez küçük büyük harfleri farklı olsa da tekrar eden ilgili ifadeler ayrı ayrı basılmadı. İşte sizler de bu şekilde gerektiğinde küçük büyük harfe duyarlı veya duyarsız şekilde satıların benzersiz olanlarını listeleyebilirsiniz. Özellikle büyük verileri işlerken tekrar eden satırların görmezden gelinmesi çok işinize yarayabilir.

Komutu nasıl kullanacağınız tamamen sizin o anki ihtiyaçlarına bağlı olacağı için temel seçeneklerden haberdar olmanız çok önemli. Yani örneğin küçük büyük harf duyarlılığının kaldırılması için -f seçeneğinin kullanıldığını unutursanız böyle bir seçeneğin var olduğundan haberdar olduğunuz için yardım sayfasını açıp tekrar bu seçeneği hangi karakterle kullanabileceğinizi hatırlayabilirsiniz. Yani eğer araçların birden fazla seçeneğini ele aldığımızda hatırlama veya öğrenme konusunda kaygı yaşıyorsanız, bu yersiz bir kaygı. Komutun temelde nasıl çalıştığı ve yetenekleri yani yapabilecekleri hakkında anımsama düzeyinde bilgi sahibi olduğunuzda yardım sayfasından komutu tekrar kolayca hatırlayabilirsiniz. Zaten merak etmeyin sık kullandığınız komutları hatırlamak gibi bir kaygınız da olmayacak. Bu sebeple çeşitli araçları anlatırken, hepsini olmasa da mümkün oldukça işimize yarayacak olan seçenekleri ele alıyor olacağım. 

Örneğin sort komutunun tüm seçenekleri benim bahsettiklerimle sınırlı da değil. Burada ele aldıklarımız dışında sort komutunun birkaç özelliği daha bulunuyor. Ancak ben geri kalan özelliklerden, başka araçları kullanarak da faydalanabileceğimizi bildiğim için sort komutunu için bu kadarlık bilginin yeterli olduğunu düşünüyorum. Merak ediyorsanız sort —help komutunun çıktılarına göz atabilirsiniz.

Elimizdeki düzensiz verileri nasıl sınıflandırıp sıralayabileceğimizden bahsettik. Bir sonraki dersimizde de düzenli verilerin sıralamasını nasıl karıştırabileceğimizden bahsederek devam edelim. 

# shuf

shuf aracının ismi ingilizce “shuffle” yani “karıştırmak” ifadesinden geliyor.

shuf aracı sayesinde mevcut satırların rastgele olacak şekilde karıştırılmasını sağlayabiliyoruz. Örneğin cat komutu ile liste1 dosyasını okuyacak olursam, bakın içinde 1 den 10 a kadar sıralı şekilde satırlar bulunuyor. Eğer ben bu dosyamın satır sıralamalarını karıştırmak istersem shuf komutunu kullanabilirim. Denemek için shuf komutundan sonra dosyamızın ismini girelim. Bakın bu kez rastgele sıralanmış şekilde satırlar bastırıldı. Komutumuzu her kullandığımızda, gördüğünüz gibi satırların sıralaması rastgele olacak şekilde karıştırılıyor. Tabii ki biz özellikle yönlendirme yapmadığımız sürece buradaki karıştırma işlemi kaynak dosyayı etkilemiyor. Shuf komutu kaynak dosyadan okuyup karıştırdığı satırları konsolumuza bastırıyor. Yani orijinal dosyada bir değişiklik olmuyor. Teyit etmek için tekrar cat komutu ile “liste” dosyamızı okuyabiliriz. Bakın dosyanın içeriğinde herhangi bir değişiklik olmamış. Çünkü dediğim gibi shuf komutu yalnızca okuduğu satırları rastgele karıştırıp standart çıktıya yönlendiriyor. Eğer biz bu karışık listeyi bir dosyaya kaydetmek istersek, yönlendirme operatörü ile istediğimiz bir dosyaya yönlendirebiliriz. Ben bunun için komutun sonuna > karisik.txt şeklinde ekliyorum. Paste komutu ile dosyalarımızı yan yana bastırarak son duruma bakabiliriz. Bakın kaynak dosyada hiç bir değişiklik yok ve yönlendirme operatörü sayesinde standart çıktıyı yönlendirdiğimiz karisik.txt dosyasının içeriği de istediğimiz gibi karışık satırlardan oluşuyor.

Bu basit kullanım dışında eğer isterseniz tüm satırlar yerine belirli sayıda satırların bastırılmasını da sağlayabilirsiniz. Örneğin ben 10 satırdan oluşan bu listenin karıştırılıp, yalnızca 3 satırın bana çıktı olarak verilmesini istiyorum. Bunun için -n seçeneğinin ardından istediğim satır sayısını yazmam yeterli. Yani komutumuzu shuf -n 3 liste1 şeklinde girebiliriz. Bakın rastgele 3 satır bastırıldı. Komutumu tekrar tekrar girdiğimizde, yalnızca 3 satır olacak şekilde rastgele satırların bastırıldığını görebiliyoruz. 

Eğer karıştırılacak veriler dosyadan okunmayacaksa, -e seçeneğinin ardından arasında boşluk bırakarak yazdığınız tüm verilerin karıştırılmasını da sağlayabilirsiniz. Ben shuf -e 1 2 3 4 5 şeklinde yazıp komutumu onaylıyorum. Bakın girdiğim rakamlar rastgele olacak şekilde sıralandı. 

Benzer şekilde eğer doğrundan standart girdiden verilerin okunmasını istersek yalnızca shuf komutunu yazıp onaylayabiliriz. Bakın shuf komutu şu anda bizden girdi bekliyor. Buraya satır satır veri girip son olarak ctrl d ile standart veri girişini sonlandırdığımızda shuf aracı bu girdiğimiz satıları karıştırıp karşımızı getirecek.

Ben örnek olması için ilk satıra bu ilk satır, ikinci satıra “bu iki”, üçüncü satırda “bu üç” ve son olarak da “bu dört” şeklinde yazıp enter ile bir alt satıra geçtikten sonra ctrl d ile veri girişini sonlandırıyorum. Bakın shuf komutu benim girdiğim satıların sıralamasını rastgele değiştirmiş oldu. Fark ettiyseniz satırlar içinde girdiğim boşluk karakterlerine değil, doğrudan satırların kendisine bakılarak karıştırma işlemi yapıldı. Shuf komutunun -e seçeneğini kullandığımızda boşluklara bakılarak karıştırma işlemi yapılıyor. Dosya içeriğinden veya standart girdiden okunan verilerde satırlar referans alınıyor. Bu duruma dikkat ederek komut girerseniz, beklentileriniz doğrultusunda doğru sonuçlar elde edebilirsiniz.

Ayrıca buradaki örneğimizde standart girdiden veri okunması için shuf komutuna herhangi bir argüman vermedik ama aslında örneğin -n seçeneğini kullanarak karıştırılan satırlardan yalnızca kaç tanesini istiyorsak o kadarının bastırılmasını da sağlayabilliriz.

Ben denemek için shuf -n 2 şeklinde yazıp komutumu onaylıyorum. Bakın standart girdiden veri bekleniyor. Şimdi basit olması için 1 den 5 e kadar rakamları satır satır girip, ctrl d ile veri girişini sonlandıralım. Bakın 5. satırdan sonra yalnızca iki rastgele satır bastırılmış oldu. Burası bizim standart girdiye veri gönderdiğimiz alan, burası da shuf aracının ürettiği standart çıktı. İşte bizzat görebildiğimiz gibi standart girdiden veri okunurken de shuf aracının uygun seçeneğini kullanabiliyoruz. 

Neticede artık elinizdeki verileri karıştırmak istediğinizde shuf aracını nasıl kullanabileceğinizi biliyorsunuz. shuf aracının diğer seçeneklerini merak ediyorsanız shuf —help komutu ile yardım bilgisine göz atıp, kendiniz keşfedebilirsiniz.

Örneğin bakın hazır yeri gelmişken burada de geçen ve sıklıkla karşılaşabileceğiniz kısa çizgi ile standart girdiden veri okunmasına da değinmek istiyorum. Önceki örneğimizde shuf aracına herhangi bir argüman vermeden olduğu gibi kullandığımızda standart girdiden verileri okuyup işlevini yerine getirdiğini gördük. Dilersek bunun yerine shuf - yazıp aynı şekilde standart girdiden verilerin alınmasını da sağlayabiliriz. Bakın shuf aracı şu anda bizden veri girişi bekliyor. Hemen birkaç satır ekleyip, ctrl d ile veri girişini sonlandıralım. Gördüğünüz gibi, burada kullandığımız kısa çizgi işareti sayesinde shuf aracı standart girdi olarak bizim konsolumuzdan verileri alıp karıştırdı ve sonuçları yine bize aktarabildi. Benzer şekilde komutumuzu shuf -n 3 - şeklinde de girebilirdik. Şu an bizden veri girmemiz bekleniyor, yine sıralı şekilde rakamlar ekleyelim ve ctrl d ile girişi sonlandıralım. Bakın kısa -n seçeneğine ek olarak kısa çizgi kullandığımızda shuf aracı standart girdiden veri okuyabiliyor. İşte buradaki kısa çizgi işaretinin kullanımı ile başka araçlarda da karşılaşabilirsiniz. Standart girdiden veri kabul eden pek çok araç yalnızca ismi ile çalıştırıldığında standart girdiyi okuyor olsa da, kimi zaman kısa çizgi işaretinin kullanıldığı durumlarla karşılaşabilirsiniz. Özellikle internet üzerindeki rehber anlatımlarda standart girdiden veri okunacağının ayırt edici biçimde belirtilmesi için genellikle kısa çizginin kullandığını kendiniz de göreceksiniz. Yani siz standart girdiden verileri göndermek için her zaman kısa çizgiyi kullanmayacak olsanız bile artık haberdar olduğunuz için gördüğünüzde ne anlama geldiğini de biliyor olacaksınız. 

# nl Komutu

Eğer satırların başına satır numaralarını eklemek istersek numbering line yani satır numaralandırma ifadesinin kısalmasından gelen nl komutunu kullanabiliyoruz. Özellikle çok fazla verinin tek bir satıra sığdırıldığı yoğun içerikli dosyalarda içeriği daha rahat okuyabilmek için numaralandırma bize kolaylık sunabiliyor. 

Ben denemek için daha önce oluşturmuş olduğum sehir dosyasını kullanacağım. Satırları numaralamak için nl sehir şeklinde dosyamızın ismini argüman olarak verebiliriz. Bakın sırasıyla tüm satırların başında numara bulunuyor.

Ayrıca mesela eğer birden fazla dosyayı argüman olarak girersek, girdiğimiz sıralmaya göre bu dosya içerikleri birleştirilip o şekilde numaralandırılıyor. Ben denemek için nl harf sehir şeklinde iki tane dosya ismini giriyorum.

Bakın öncelikle harf dosyasının içeriği daha sonra sehir dosyasının içeriği birleştirilmiş ve birleşik şekilde bu satırlar numaralandırılmış. İşte nl aracını kullanarak satırları numaralandırmak bu kadar kolay. 

nl komutunun da tıpkı diğer pek çok araç gibi elbette birden fazla ek seçeneği bulunuyor. Eğer nl —help komutunu kullanırsak, seçenekleri görebiliriz. Ancak açıkçası ben bu kadar seçenekle şu an ilgilenmiyorum. İleride gerekirse tekrar dönüp bakabilirim. 

Ayrıca ben nl aracından özellikle bahsettim fakat aslında benim ihtiyacımı cat komutunun n seçeneği de yeterince iyi görüyor. Örneğin aynı dosyayı cat -n seçeneği ile de numaralandırabilirim. Buradaki çıktıda boş satırlar da numaralandırıldı. Hatta eğer boş satırları istemezsem cat komutunun -b seçeneğini de kullanabilirim. Zaten kullanımından daha önce bahsettim.

Peki madem cat komutu ile aynı işi yapabiliyoruz neden bir daha nl komutunu ele aldım ? nl komutunu ele aldım, çünkü kullanımı ile sık karşılaşabilirsiniz. nl komutunu sunduğu ek özellikler için özellikle kabuk programlamada sıklıkla tercih ediliyor. Ben sadece sık kullanıldığı için nl komutundan da haberdar olmanızı istedim. Hangi iş için hangi komutu kullanacağınız tamamen sizin alışkanlıklarınıza bağlı. Aklınıza ilk nl komutu geliyorsa, bu aracı kullanabilirsiniz. Pek çok farklı aracın benzer özellikler için farklı seçenek tanımları bulunduğu için aslında nl gibi spesifik olarak tek bir işi yapan aracı bilmek bir avantaj. Zaten nl aracının ismi ana işlevini çağrıştırdığı için hatırlaması çok kolay. Yoksa değdiğim gibi aynı işi yapabilecek pek çok alternatif araç bulabiliriz. İşte bu durumda aynı özellik için farklı araçların farklı seçeneklerini hatırlamak yerine tek bir aracı hatırlayıp o iş için bu aracı kullanabiliyoruz. Elinizdeki verileri numaralandırmak mı istiyorsunuz, nl aracını kullanabilirsiniz. 

Eğer nl aracı sizin için hatırlanması ve kullanması daha kolay geldiyse aracın diğer seçeneklerine de göz atabilirsiniz.

# wc komutu

wc aracı en temel haliyle kelimeleri saymamızı sağlayan işlevsel bir araçtır. wc komutunun ismi de word count yani kelime sayma ifadesinin kısaltmasından geliyor. Ben kelime dedim ama yalnızca kelimeleri değil, karakterleri, satırları ve ayrıca baytları saymak için de kullanabiliyoruz. Eğer komutu ek bir seçenek olmadan wc aracına okuması gereken dosyayı argüman olarak verirsek wc aracı, sırasıyla kaç satır, kelime ve karakter olduğunu ve okunan dosyanın ismini bastırıyor. Hemen deneyelim. Ben denemek şehirleri ve plakaları içeren dosyam üzerinde kullanıyorum.

Buradaki ilk sayı dosya içeriğinin kaç satır olduğunu, ortadaki sayı toplam kaç kelime olduğunu ve son sayı ise toplam kaç karakter olduğunu bildiriyor. 

İstersek bu çıktıların hepsini almak yerine yalnızca ihtiyacımız olan çıktıları da bastırabiliriz. Örneğin ben yalnızca satırların basılmasını istersem ingilizce lines yani satırlar ifadesinin kısaltması olan -l seçeneğini kullanabilirim. Bakın bu kez yalnızca kaç satır olduğunu öğrendik. Bu arada dosya içeriğinde boş satırlar olduğunda bu satırların da sayıldığını unutmayın lütfen.

Satır sayısı yerine kelime sayısını öğrenmek için de yine ingilizce karşılığı word yani kelime olan -w seçeneğini kullanabiliyoruz. Ben teyit etmek için bu kez de yalnızca w seçeneği ile dosyamı okuyorum. Bakın bu sefer de yalnızca kelime sayısı bastırıldı.

Yalnızca karakter sayısını öğrenmek istersek, c seçeneğini kullanabiliriz. Ben yine aynı dosyamı bu kez de c seçeneği ile belirtiyorum. Bakın yalnızca bayt sayısı da bastırmayı başardık. 

Ayrıca tüm seçenekleri tek tek kullanabileceğimiz gibi elbette aynı anda da kullanabiliriz. Ancak dikkat etmeniz gereken detay, alacağınız çıktıların komutun en başında bahsettiğimiz standart sıralamasında olacağıdır. Yani seçenekleri hangi sıralamada vermiş olursak olalım, aldığımız çıktılar, soldan sağa doğru; satır, kelime, karakter sayısı ve dosya adı şeklinde olacak. Denemek için ben wc -wl dosya adı şeklinde yani kelimelerin ve satırların hesaplanacağı şekilde komutumu giriyorum. Şimdi birde seçeneklerin sıralamasını değiştirip tekrar girmeyi deneyelim.

Bakın iki çıktıdaki sayıların sıralaması da aynı. Yani bizim verdiğimiz seçenek sıralamasının wc komutu için bir önemi yok. Her koşulda, çıktılar kendi standartlarında varsa satır daha sonra kelime sayısı ve son olarak karakter sayısını verecek şekilde oluyor oluyor. Karakter sayısı da dahil bastırmak için tüm seçenekleri kullanabiliriz. Bakın aldığımız bu çıktıdaki sıralama da yeni satır, kelime, karakter, ve dosya adı şeklinde oldu. Bu çıktı sıralamasını aklınızda tutamıyorsanız sorun yok. Çünkü man wc komutunu kullanıp, komut açıklamasındaki sıralama tanımına bakabilirsiniz. Bakın burada sıralamadan bahsediliyor. Öncelikle satırlar daha sonra kelimler ve son olarak da byte olarak geçen karakter uzunluğu. Ben şimdiye kadar hep karakter uzunluğu dedim ama aslında kast ettiğim şey karakterlerin bayt uzunluğuydu. Zaten burada da bu sebeple byte şeklinde yazıyor. Neticede bakın sıralamayı unuttuğunuz zaman 10 saniyede man sayfası üzerinden tekrar öğrenebilirsiniz. İyi ki yardım sayfaları var, haksız mıyım ?

Ayrıca ben şimdiye kadar hep tekil dosyalar üzerinden örnek verim fakat istersek birden fazla dosya ismi de belirtebiliriz. Hemen denemek için birkaç dosya daha ekleyerek komutumuzu girelim. Bakın ayrı ayrı tüm dosyaların istatistikleriyle birlikte son satırda toplam sayılar da bize sunulmuş. Bu şekilde ister tek isterseniz de birden fazla dosyanın istatistiklerini kontrol edebilirsiniz. 

Ben şimdi daha fazla araçtan bahsetmeden önce pipe yapısından bahsedip, araçlar arasında nasıl veri yönlendirmesi yapabileceğimizi ele almak istiyorum.

# Pipe Kullanım Örnekleri

# pipe Hakkında

Şimdiye kadar sistem üzerindeki yapıların dosya olarak ele alındığından ve dolayısıyla dosya içeriklerini yani baytları istediğimiz gibi manipüle edilip yönlendirebilmenin neden çok önemli olduğundan pek çok kez söz ettik. Yani her şeyin aslında bir bayt akışı olduğunu vurguladık hep. Vurgulamaya da devam edeceğiz. Özetle sistemi komut satırı üzerinden yöneten kişi olarak bizim işimiz gücümüz hep bayt akışlarını kontrol etmek.

Hep birlikte dosya içeriklerinde birtakım değişiklikler yapabileceğimiz bazı araçları tanıdık. Başka araçlardan da bahsedeceğiz ancak devam etmeden önce birden fazla aracı birbirine bağlayarak çalıştırmamıza yardımcı olan pipe yani boru mekanizmasından bahsetmem gerekiyor. 

Yönlendirme işlemleri sırasında girdileri ve çıktıları istediğimiz şekilde nasıl aktarabileceğimizi öğrendik. Sizlerin de bildiği üzere yönlendirme sırasında bir aracın çıktıları bir dosyaya veya bir dosyadaki verileri de bir araca girdi olarak aktarabiliyoruz.

Peki ya bir aracın çıktısını doğrudan başka bir araca girdi olarak aktarmak istediğimizde ne yapmamız gerekiyor ? Yani örneğin ben history komutu neticesinde üretilen çıktıları sort aracına aktarıp sıralamak ve daha sonra oradan da uniq aracına aktarıp benzersiz olanları ayrıştırmak istersem mümkün müdür ? 

Evet pipe yapısı sayesinde mümkün.

Eğer dosyalar yerine anlık olarak işlemler arasında veri aktarmak istersek pipe mekanizması tam olarak ihtiyacımız olan çözümü sağlıyor.  Pipe yapısına ihtiyaç duymamızdaki en temel iki sebep; hızlı çalışması ve aynı anda paralel şekilde işlemler arasında aktarım yapılabilmesi.

Burda bahsi geçen pipe mekanizmasını dik çizgi | operatörü sayesinde kullanabiliyoruz. Pipe mekanizmasında, bu dik çizgi işaretinden önceki komutun çıktıları üretildikleri sıralamaya uygun şekilde bu çizgiden sonraki komuta girdi olarak aktarılıyor. 

Yani veriler, ilk işlemin ürettiği sıraya uygun şekilde tek yönlü olarak bir sonraki işleme aktarılıyor. Daha iyi anlamak adına çalışma yapısına daha yakından bakalım.

Basit bir örnek üzerinden gidecek olursak; Diyelim ki ben find komutu ile sonu .jpg uzantısıyla biten dosyaları araştırmak, bulunan dosyaları isimlerine göre alfanümerik olarak sıralamak ve daha sonra numaralandırmak istiyorum. Bu işi yapacak tek bir araç var mı varsa da hangi seçenekleri kullanmalıyım tam olarak bilmiyorum. Ancak her birini yapan ayrı ayrı üç araç biliyorum. find sort ve nl araçları ilk aklıma gelenler. Sizin şu anda find aracını bilmediğinizin farkındayım, ancak merak etmeyin ileride bu aracımızı da ayrıca ele alacağız. Şimdi pipe yapısının çalışma mekanizmasını ele alabilmek için vereceğim örneğe odaklanmanız yeterli. Neticede ihtiyacım olan sonuca ulaşabilmek için bu üç aracı bir arada kullanabilirim. 

Öncelikle sonu jpg uzantısı ile biten dosyaların bulunabilmesi için find / -name *.jpg -type f komutunu giriyorum. Bu komut sonu jpg ile biten dosyaları listeleyecek. find aracının çıktılarını sıralamak istediğim için de bu çıktıları sort aracına aktarmam gerekiyor. Aktarmak için pipe kullanabilirim. Pipe çubuk simgesi ile kullanılıyor. Sıralama işleminden sonra da, sıralanmış çıktıları numaralandırmak için de sort aracının çıktılarını nl aracına aktarabilirim. Neticede birden fazla aracı peşi sıra tek bir amaç için kullanmak üzere komutumuzu girmiş olduk. Şimdi komutumuzu onaylayarak çıktılara göz atalım. Bakın, gördüğünüz gibi yetkimiz olan dizinlerdeki sonu .jpg ile biten dosyalar kısa sürede klasör isimlerine göre sıralanmış ve numaralandırılmış şekilde bastırılmış oldu.

Peki bu çıktıyı tam olarak nasıl elde ettik yani pipe tam olarak nasıl çalışıyor ?

Bizim girdiğimiz komutta bulunan üç farklı araç aynı anda üç ayrı işlem olarak başlatıldı. İlk aracın standart çıktısı ikinci aracın standart girdisine bağlandı. İkinci aracın standart çıktısı da üçüncü aracın standart girdisine bağlandı. Üçüncüsü de özellikle başka bir yere yönlendirilmediği için çıktılarını konsola bastırmış oldu.

Yani bizim ele aldığımız örnekte find komutu sonu .jpg ile biten dosyaları araştırıp bulduğu sonuçları pipe sayesinde sort aracına girdi olarak aktardı. sort aracı da aldığı verileri sıralayıp anında yine pipe üzerinden nl aracına aktardı. Böylelikle tek bir görevi yerine getirmek için birden çok aracı birbirine pipe ile bağlayarak çalıştırmış olduk.

Elbette bu işlemi her bir komutun çıktılarını bir dosyaya aktarıp ilgili dosyadan diğer araçların verileri okumasını sağlayarak da yapabilirdik fakat bu komutu yazmak hem daha uğraştırıcı olacaktı hem de araçlarımız pipe kullanımına oranla daha verimsiz çalışacaktı. Hemen bu durumu gözlemleyelim.

Aynı işlemi bu kez dosyalara yönlendirme ile denmek istiyorum. Öncelikle komutu yazayım, daha sonra açıklayacağım.

```jsx
find / -name *.jpg -type f > bul ; sort < bul > sırala ; nl < sırala
```

Bu girdiğimiz komutta önce find komutu çalıştırılacak ve işini tamamladığında çıktılarını “bul” isimli dosyaya aktaracak. Daha sonra sort komutu bul isimli dosyayı okuyacak ve içeriğindeki verileri sıraladıktan sonra sırala isimli dosyaya aktaracak. En son nl komutu sırala isimli dosyadaki içeriği okuyup numaralandıracak ve çıktısını konsolumuza basacak. İşte girdiğimiz komutun çalışma yapısı tam olarak bu. Buradaki noktalı virgül karakteri tek satırda belirtmiş olduğumuz bu komutların sırasıyla çalıştırılmasını sağlıyor. İleride bu konudan da ayrıca bahsedeceğiz.

Bakın pipe yerine kullandığımız bu yönlendirme alternatifini yazması ve açıklaması bile gereğinden uzun sürdü. 

Çalışma hızı ise pipe a oranla daha yavaş olacak çünkü bu kullanımda komutlar sırasıyla disk üzerindeki dosyalara veri yazıp okuyarak çalıştırılıyor. Dolayısıyla soldan sağa doğru bir komut çalışmasını tamamlamadan bir sonraki komut çalıştırılmıyor. Pipe kullanımında ise tüm komutlar ayrı işlem olarak aynı anda paralel şekilde çalıştırılıyor. Her bir aracın ürettiği çıktı da üretilir üretilmez boru hattındaki diğer işlemlere disk üzerine veri yazılıp okunmasına gerek kalmadan aktarıldığı için veriler çok daha hızlı işlenmiş oluyor.  Bir komut çıktı üretir üretmez, çıktının üretilme sıralaması korunarak bir sonraki işlem aktarıyor, bu sayede tüm veriler sırasıyla işlenmiş oluyor. Tabii ki bizim örneğimizde ilk aracın ürettiği çıktıların hepsinin alındıktan sonra sıralaması gerektiği için sort aracı find aracının çıktılarını bitirmesini bekledi aslında. Yani araçlar paralel çalışıyor olsalar da çıktıların gönderilme ve okunma durumlarına bağlı olarak birbirlerini de bekliyorlar. Yine de pipe mekanizması disk üzerindeki dosyalara okuma yazma yapmadığı ve araçları paralel olarak aynı anda çalıştırabildiği için çok daha verimli bir yaklaşım. Üstelik basit örnek üzerinden de görebildiğiniz gibi birden fazla aracı birbirine bağlayacak çalıştırmak istediğimizde pipe ile komut girmek çok da daha kolay ve kısa.

Ayrıca örnek üzerinde peşi sıra pipe kullandığımız bu komutun bütününe de pipeline yani boru hattı deniyor. Neticede birden fazla pipe yani boru kullanarak ikiden fazla aracı birbirine bağladığımız için boru hattı oluşturmuş oluyoruz. 

Tıpkı burdaki örneğimizde olduğu gibi ihtiyacımıza yönelik spesifik çözüm için bildiğimiz birden fazla aracın basit özelliklerini pipe yardımıyla bir arada kullanabiliyoruz. 

Bu yaklaşım sayesinde pek çok işlevi olan tek bir karmaşık araç yerine, basit işlevleri olan pek çok aracı farklı kombinasyonlar ile birlikte kullanıp sınırsız çeşitlilikte çözüm üretebiliyoruz. Zaten zaman içinde pipe yapısını ister istemez ne kadar sık kullandığınıza bizzat şahit olacaksınız. Pipe mekanizmasının en temel kullanımı bu şekilde. Bir sonraki dersimizde standart girdiden veri okumayan araçlara nasıl pipe ile veri yönlendirebileceğimizden bahsederek devam edebiliriz. 

# xargs Komutu

Pipe yapısından bahsederken, pipe’ın önceki işlemden gelen standart çıktıları sonraki işleme standart girdi olarak aktardığını söylemiştim. Eğer pipe ile veri yönlendirmek istediğiniz araç yalnızca argüman alarak çalışıyorsa yani standart girdiden veri kabul etmiyorsa tabii ki ilgili veriler araç tarafından alınıp işlenmiyor. Dolayısıyla pipeline olarak ifade ettiğimiz boru hattı tıkanmış oluyor.

İşte bu duruma çözüm olarak da xargs isimli aracı kullanabiliyoruz.

`xargs` aracı, standart girdiden okuduğu verileri kendisinden sonraki komutun argümanı olarak iletebiliyor. Bu sayede standart girdiden veri kabul etmeyen araçları, tıpkı biz elle o araca argümanlar girmişiz gibi çalıştırabiliyoruz. xargs aracının isminin açılımı da zaten "e**X**tended **ARG**ument**S**" yani genişletilmiş argümanlar ifadesinden geliyor. 

Bu aracın çok fazla seçeneği var ama şimdilik temel kullanımı hakkında bilgi sahibi olmamız yeterli.

Ben çok basit bir örnek vermek istiyorum. Bunun için öncelikle içerisinde veri bulunan dosyamı oluşturmak üzere echo “dosya1 dosya2 dosya3” > oku-beni şeklinde komutumu giriyorum. cat komutu ile dosyamızı okuyup kontrol edelim. Bakın buraya yazmış olduğum ifadeler dosyama kaydolmuş. Şimdi ben bu dosyada geçen ifadelerin kullanılarak yeni dosyalar oluşturulması için touch aracına bu dosyadan veri yönlendirmek istiyorum. 

Bunun için cat oku-beni komutuyla dosyanın okunup pipe ile bu çıktıların touch aracına yönlendirilmesini sağlayabiliriz. Bakın cat aracı bu dosyanın içeriğini standart çıktıya yani bu durumda pipe a yönlendirecek, pipe da bu verileri touch aracının standart girdisine yönlendirmeye çalışacak. Hemen komutumuzu girelim.

```bash
└─$ cat oku-beni | touch 
touch: missing file operand
Try 'touch --help' for more information.
```

Bakın gördüğünüz gibi touch komutu oluşturulacak dosya isimleri argüman olarak iletilmediği için hata verdi. Bu hatanın argüman eksikliğinden kaynaklandığını teyit etmek istersek tekrar yalnızca touch komutunu girebiliriz. Bakın yine aynı hatayı aldık çünkü touch aracına herhangi bir dosya ismini argüman olarak iletmedik.

touch aracı yalnızca kendisine argüman olarak iletilen verileri işleyip standart girdiden veri okumadığı için pipe ile ilettiğimiz oku-beni dosyasının içeriği touch aracı tarafından işlenmedi. Bu durumda bu çıktıları önce xargs aracına yönlendirip oradan da touch aracına argüman olarak iletilmelerini sağlayabiliriz.

Ben bunun için komutumu bu kez cat oku-beni | xargs touch şeklinde yazıyorum. Bakın buradaki xargs aracı pipe üzerinden gelen verileri buradaki touch aracına argüman olarak iletmiş olacak. Hemen komutumuzu onaylayalım. Bakın bu kez herhangi bir hata almadık. Teyit etmek için ls komutu ile mevcut dizinimizi listeleyelim. Bakın tam olarak dosyada bulunan veriler ile aynı isimde yeni dosyalar oluşturulmuş. Yani xargs aracının standart girdiden okuduğu verileri hemen yanındaki komutun argümanı olarak çalıştırdığını bizzat teyit etmiş olduk. xargs aracı kendisine girdi olarak verilerin tüm verileri standart şekilde boşluklarından parçalara ayırıp bunların her birini hemen yanındaki komuta ayrı ayrı argüman olarak iletiyor. Zaten bu sebeple benim bu dosyada aralarında boşluk bırakarak yazdığım tüm verilerim argüman olarak touch aracına iletildi.

İşte bu yaklaşım sayesinde standart girdiden veri kabul etmeyen yani yalnızca argüman olarak çalışan araçlara kolaylıkla veri yönlendirmesi yapabiliyoruz. Neticede xargs aracının en temel kullanımı bu şekilde. Artık en temel kullanım amacını bildiğiniz için geri kalan tüm detaylar için yardım sayfalarına göz atmanız yeterli. 

# tee

Biz pipe yapısını kullandığımızda verilerimiz yalnızca tek yönlü şekilde aktarılıyor. Eğer biz hem bir sonraki işleme hem de bir dosyaya aynı verilerin yazılmasını istiyorsak, bu işlem için tee aracını kullanmamız gerekiyor. Çünkü pipe mekanizması tek başına bunu desteklemiyor.  Pipe mekanizmasını düz boru olarak düşünecek olursak buradaki tee aracı da bildiğiniz t boru görevi görüyor. İlk işlemden aldığı çıktıyı okuyor, istenilen dosyaya ve aynı zamanda bir sonraki işlemin standart girdisine yönlendiriyor.

Ben denemek için ls /etc/ komutu ile etc dizini altındaki dosyaları listeliyorum. Bu komut neticesinde pek çok dosya ve dizin listelendi. Eğer yalnızca ilk 10 satırı listelemek istersem pipe ile verileri head komutuna aktarabilirim. Buradaki head aracı, aldığı verilerin yalnızca ilk 10 satını çıktı olarak iletildiği için kullandık. İleride bu araçtan ayrıca bahsediyor olacağız. Şimdi komutumuzu girip deneyelim.

Bakın yalnızca ilk 10 içerik listelenmiş oldu. Ben ls komutunun tüm çıktılarının bir dosyaya kaydedilmesini hem de head komutu ile ilk 10 satırını okumak istiyor da olabilirim. Bunun için tee komutunu kullanabilirim. Komutumu ls /etc/ | tee liste.txt | head şeklinde yazıyorum. Bu komut sayesinde ilk olarak ls aracı /etc dizini altındaki tüm içeriği listeleyip pipe ile tee aracına aktaracak. tee aracı da aldığı çıktıyı buradaki “liste.txt” isimlide dosyaya kaydedecek ve ayrıca aynı verileri head aracına pipe ile yönlendirecek. Head aracı da aldığı verilerden yalnızca ilk 10 satırı konsola çıktı olarak bastıracak. Komutumuzu onaylayalım. 

Bakın ilk 10 satır konsola basılmış oldu. Şimdi liste dosyasının içeriğine bakalım. Gördüğünüz gibi ls komutunun tüm çıktıları da bu listeye kaydedilmiş. Yani tee komutu ls komutunun  çıktılarını hem dosyaya hem de bir sonraki işlem olan head işlemine iletmiş oldu. Burada fark ettiyseniz tee aracı kendisine verilen tüm verileri hem dosyaya hem de bir sonraki araca eksiksiz şekilde iletiyor. İşte tee komutu pipeline üzerinde bu amaçla sıklıkla kullanılıyor. 

Mesela ls /etc | head | tee liste.txt şeklinde komut girecek olursak size nasıl bir çıktı alırız ?

Tabii ki ls komutunun çıktıları pipe ile önce head aracına iletilecek, head aracı ilk 10 satırı filtreleyip bu çıktıları da yine pipe ile tee aracına iletecek. tee aracı ise standart girdiden aldığı bu verileri hem buradaki liste.txt isimli dosyaya kaydedecek hem de konsolumuza bastıracak. Hemen komutumuzu onaylayıp teyit edelim.

Bakın tam da beklediğimiz gibi konsola yalnızca ilk 10 satırı bastırıldı. Şimdi bir de dosyanın içeriğine cat komutu ile bakalım. Bakın dosyaya da 10 satır bastırılmış.

Bence buradaki iki örnek tee aracının nasıl çalıştığını gayet iyi biçimde özetliyor.  

Yine de bu temel yaklaşım dışında eğer istersek dosya isimlerini yan yana yazarak birden fazla dosyaya yazılmasını da sağlayabiliriz. Ben denemek için aynı komutu çağırıp, bir dosya ismi daha belirtiyorum ve komutumu bu şekilde onaylıyorum. Şimdi paste komutu ile her iki dosyayı da yan yana bastırabiliriz. Bakın iki dosyaya da aynı veri kaydolmakla birlikte head aracına da bu çıktılar aktarıldığı için konsola ilk 10 satır bastırıldı.

Ayrıca örneğin çıktıların hem konsola hem de dosyaya yazdırılmasını istersek de tee komutunu kullanabiliriz. Normalde eğer bir komutun çıktısını bir dosyaya yönlendirirsek konsola bir çıktı basılmaz. Hemen teyit etmek için ls > liste şeklinde komutumuzu girelim. Bakın ls komutunun çıktısı konsola basılmadı çünkü ls komutunun çıktıları belirttiğim dosyaya yönlendirildi. cat komutu ile de bu durumu teyit edebiliriz.

Şimdi aynı örneği tee komutunu ile tekrarlayalım. ls | tee ls-dosyasi şeklinde komutumu giriyorum. Bakın konsola çıktılar basılmış oldu. Hemen dosyanın içeriğini de kontrol edelim. Bakın ls komutunun çıktıları konsola bastırılmakla birlikte dosyaya da kaydedilmiş. Eğer ben tee aracından sonra bir pipe daha kullanıp bir araç ismi yazsaydım tee aracının elindeki veriler bu araca yönlendirilecekti. Fakat tee aracından sonra bir araç ismi girmediğim için tee aracı elindeki verileri dosyaya yazmasının yanı sıra standart çıktı adresi olan konsola da bastırmış oldu.

tee aracının kullanımı gördüğünüz gibi son derece kolay olduğu için daha fazla örneğe gerek yok. Yine de son olarak birkaç kullanım detayını daha bilmenizde fayda var. Normalde tee komutu aynı isimde bir dosya varsa onun üzerine yazar. Yani o dosyanın içeriğini yok edip, elindeki verileri o dosyaya yazar. Eğer aynı isimli dosya varsa dosya içeriğinin sonuna yeni verilerin eklenmesini istersek append yani ekleme ifadesinin kısalması olan -a seçeneğini kullanabiliriz.

Ben denemek için echo "deneme" | tee deneme.txt komutunu giriyorum. cat deneme.txt komutuyla dosyanın içeriğini okuyalım. Bakın veri kaydolmuş.

Şimdi aynı dosyaya bu kez farklı veri göndermek için echo “test” | tee deneme.txt şeklinde aynı dosyanın ismini de yazıp komutumuzu girelim. Bakın tee aracı bir önceki araç olan echo aracından aldığı test ifadesini konsola bastırdı. Aynı zamanda tabii ki deneme.txt dosyasına da bu ifadeyi yönlendirdi. Teyit etmek için cat komutu ile deneme.txt dosyasını da okuyalım. 

Bakın dosyanın eski içeriği silinip tee aracının en son yönlendirdiği veri eklenmiş. Bizzat gördüğümüz gibi tee aracına özellikle belirtmediğimiz sürece tıpkı tek yönlendirme operatörü kullandığımızdaki gibi hedefteki dosya içeriğinin üzerine yazılıyor.

Ben verileri dosyanın sonuna eklemek istediğim için append yani ekleme ifadesinin kısaltmasından gelen -a seçeneği ile komutumu tekrar girmek istiyorum. Bu kez tee aracına test2 verisini yönlendireceğim. Bakın tee aracın echo aracından test2 ifadesini aldığı için bunu konsola bastırdı. Ayrıca -a seçeneğini de eklediğimiz için bu veriyi deneme.txt dosyasının sonuna eklemiş olması gerekiyor. Hemen cat komutu ile deneme.txt dosyasının içeriğine bakalım. Bakın tam da istediğimiz gibi  a seçeneği sayesinde dosya içeriğine ekleme yapıldığını görebiliyoruz. Kısacası tıpkı yönlendirme operatörlerinde bir dosyanın sonuna yeni veri eklemek için çift operatör kullandığımız gibi tee komutu için de a seçeneğini kullanmamız gerekiyor. Aksi halde tee aracı aynı isimli dosyanın üzerine yeni verileri yazıp eskilerini yok ediyor.

Son olarak hazır tee komutundan bahsetmişken pratik bir kullanımından da bahsetmek istiyorum. Diyelim kim yetkimiz olmayan bir dosyaya örneğin /etc/apt/sources.list  dosyasına ekleme yapmak istiyoruz. 

Normalde yetki gerektiren bir görevi yerine getirmek için komutumuzun en başına sudo ifadesini yazıp eğer yetkimiz uygunsa çalıştırabiliyoruz. Yani örneğin normalde /etc/apt/sources.list  dosyasını düzenlemek için yetkimiz yok fakat en yetkili kullanıcı gibi davranmak için komutumuzun başına sudo yazı işlemi yerine getirmeyi deneyebiliriz.

Yani örneğin sudo echo "eklenecek veri" >> /etc/apt/sources.list şeklinde komutumuzu girebiliriz. Ancak gördüğünüz gibi yetki hatası aldık. Halbuki ileri de ayrıca ele alacağımız sudo komutu bizim yetkili şekilde bu dosyaya veri ekleyebilmemizi sağlamalıydı. 

 Burada sudo komutu işe yaramadı çünkü yönlendirmeler üzerinde sudo komutunun etkisi bulunmuyor. Yani yönlendirmeyi yine mevcut yetkisiz kullanıcımız yapmış oluyor. Dolayısıyla sudo komutunu kullansak dahi yönlendirme operatörü ile, ilgili dosyaya veri yazma yetkisi kazanamayız. Fakat bunun yerine tee komutunu sudo ile yetkili şekilde çalıştırabiliriz. Hadi hemen deneyelim. Ben echo "yeni satır" | sudo tee -a /etc/apt/sources.list şeklinde komutumu yazıyorum. Buradaki a seçeneğini unutmayın aksi halde bu çok önemli dosyasının tüm içeriğinin silinmesine neden olabilirsiniz. 

Ben yetkili olduğumu kanıtlamak için parolamı girip onaylıyorum. Ve gördüğünüz gibi herhangi bir yetki hatası almadım. cat komutuyla dosya içeriğine de bakalım. Bakın dosyanın en sonuna yeni satır ifadesi eklenmiş.

Böylelikle yönlendirme operatörlerinin sudo ile yetki kazanamadığından ve alternatif olarak tee komutu sayesinde yetkili şekilde dosya içeriğine veri ekleyebileceğimizden de haberdar olduk. Tee aracını ele aldığımız örnekleri de dikkate aldığımızda tee aracını tıpkı T boru gibi düşünmek bence oldukça mantıklı. Konsol üzerinde hem standart çıktıya hem de bir dosyaya yönlendirme yapmak istediğinizde veya bir yönlendirme işlemini yetkili şekilde yapmak istediğinizde tee aracını kullanabiliyoruz. Mesela ben en son girmiş olduğum komutta konsola çıktı bastırılmadan yalnızca dosyaya veri yönlendirmek isteseydim standart çıktıları /dev/null dizinine de yönlendirebilirdim. Ben denemek için en son komutumu çağırıp bu kez sonuna > /dev/null şeklinde yazıyorum ve komutumu bu şekilde onaylıyorum.

Bakın konsola herhangi bir çıktı bastırılmadı çünkü standart çıktıyı /dev/null dosyasına yönlendirerek yok etmiş oldum. Şimdi dosya içeriğine göz atalım. Bakın yine tee sayesinde ilgili veri bu dosyaya sorunsuzca eklenmiş. Siz de bu şekilde pipe üzerinden gelen verileri bir dosyaya yazmak istediğinizde bu yaklaşımı kullanabilirsiniz.

Ayrıca örneklerimiz sırasında kullandığımız bu dosya sistemin paket yönetimi için önemli bir dosya. O sebeple sudo nano ile bu dosyayı tekrar açıp, eklediğiniz gereksiz verileri silmenizi öneriyorum. Aksi halde paket yönetimi konusunda sorun yaşabilirsiniz.

# grep

grep aracının ismi global regular expression print ifadesinin kısaltmasından geliyor. Ve tam olarak isminde de olduğu şekilde regex sayesinde verileri filtreleme konusunda çok yetenekli bir araç. Bu sebeple zaten sıklıkla kullanıyor olacağız. 

Grep aracı standart girdiden veya kendisine argüman olarak verilmiş olan dosyadan veri okuyup filtreleyebiliyor. 

Hemen bizzat görmek için en temel kullanımıyla başlayabiliriz.

Ben denemek için /etc/passwd dosyasında kaç kez nologin ifadesinin geçtiğini öğrenmek üzere grep komutundan sonra araştırmak istediğim kelimeyi ve daha sonra da hangi dosyada araştırılacağını grep nologin /etc/passwd şeklinde giriyorum.

Bakın içerisinde nologin ifadesi bulunan tüm satırlar listelendi. Benzer şekilde aslında standart girdiden alınan veriler de grep tarafından işlendiği için komutumuzu cat /etc/passwd | grep nologin şeklinde de girebilirdik. 

Bakın yine aynı sonucu elde ettik çünkü cat aracı passwd dosyasının içeriğini pipe ile grep aracına aktardı, grep de benim istediğim doğrultusunda içinde nologin ifadesi geçen satıları filtreleyip standart çıktıya yani konsola yönlendirdi. İşte grep aracının en temel kullanımı bu şekilde. İster dosyadan isterseniz de standart girdiden grep aracına veri yönlendirip verilerin okunmasını sağlayabilirsiniz.

Şimdi ben grep aracının birkaç farklı kullanım özelliğinden daha bahsetmek istiyorum. 

## Ters Arama

Aradığımız kelime ile eşleşen verileri nasıl filtreleyebileceğimizi ele aldık. Eğer tersi şekilde aradığımız ifadenin geçmediği bölümleri istersek bulun için grep aracının hariç tutma özelliğini kullanabiliriz. Hariç tutma özelliğini kullanmak için de kısaca -v seçeneğini kullanabiliyoruz.  

Yani örneğin ben passwd dosyasının içinde nologin ifadesinin geçmediği satırları listelemek istersem grep -v nologin /etc/passwd şeklinde komutumu girebilirim. 

Bakın nologin ifadesinin geçtiği satırlar hariç tüm içerikler konsola bastırıldı.

 Ben yalnızca tek bir dosya üzerinde filtreleme yaptım ancak istersek birden fazla dosyanın tüm içeriğinde de filtreleme yapabiliriz. Ben denemek için etc passwd ve etc group dosya içeriklerinde “root” ifadesinin aranmasını istiyorum. Bunun için grep “root” /etc/passwd /etc/group şeklinde komutumu giriyorum. 

Bakın eşleşmiş olan satırlar hangi dosyada bulundukları da belirtilerek filtrelenmiş oldu. Yani gördüğünüz gibi istersek aynı anda çoklu şekilde dosyalar üzerinde de çalışabiliyoruz. Çoklu dosyalarla çalışmanın yanında dilersek alt dizinlerdekiler de dahil bir dizin içindeki tüm içeriklerin grep aracı tarafından filtrelenmesini sağlayabiliriz. Bunun için özyineleme yani recursive seçeneğinin kısalması olan -r seçeneğini kullanabiliyoruz.

## Özyinelemeli Araştırma

Ben kendi ev dizinimde, içinde “test” ifadesi geçen tüm dosyaların filtrelenmesini istiyorum. Bunun için grep -r “test” /home/taylan şeklinde komutumu giriyorum. Buradaki -r seçeneği benim hedef gösterdiğim bu dizinden başlayıp tüm alt dizinler de dahil olmak üzere tüm dosyalarda “test” ifadesinin geçtiği yerleri filtreleyip bana sunacak. Komutu onaylayalım.

Bakın sırasıyla tüm dizinlerde geziniliyor ve test ifadesi eşleşen satırlar ilgili dosyanın ismi de başta olacak şekilde bize sunuluyor. Yani -r seçeneği sayesinde benim belirttiğim bu dizin atlındaki tüm alt dizinler tek tek işleniyor. Bu sayede kapsamlı şekilde istediğimiz spesifik kelime ile eşleşen dosyaları bulmamız mümkün oluyor.

Mesela eğer tam olarak hangi satırda aradığımız ifadeyle eşleşen veriler olduğunu görmek yerine yalnızca dosya isimlerinin bastırılmasını istersek -l seçeneğini de kullanabiliriz. Ben denemek için en son girmiş olduğum komutu tekrar çağırıyorum ve buraya -l seçeneğini de ekliyorum. Komutumuzu onaylayalım. 

Bakın bu kez yalnızca içerisinde benim aradığım ifadeyi bulunduran dosyaların isimleri bastırılmış oldu. Çok daha derli toplu bir çıktı elde etmiş olduk.

Şimdi ben grep aracının diğer özelliklerinden bahsetmek için elimdeki yaklaşım 5000 satırlı isim listesini kullanmak istiyorum. Ders kaynağına da bu dosyayı eklemiş olurum isterseniz indirip siz de bu dosya üzerinden test edebilirsiniz.

Ben öncelikle tırnak kullanımına değinmek istiyorum. Mesela ben isimler.txt dosyasında tam olarak ahmet can ifadesinin geçtiği satırları aramak istiyorum. Bunun için konsola grep ahmet can isimler.txt şeklinde komut girmeyi deneyebiliriz.

Bakın yalnızca ahmet can ifadesi yerine başlangıcında ahmet olan tüm satırlarla eşleşme sağlandı. Ben burda tırnak içinde ahmet can ifadesinin aranacak bütüncül kelime olduğunu özellikle belirtmediğim için bu şekilde filtrelendi. Ben tam olarak ahmet can ifadesini filtrelemek için bu kez grep “ahmet can” isimler.txt şeklinde giriyorum.

Bakın bu kez tam olarak tırnak içinde yazmış olduğum ifadeyi içeren satır getirilmiş oldu. Bizzat bu basit örneğimiz üzerinden teyit ettiğimiz gibi tırnak kullanımı önemli. Zaten hatırlıyorsanız daha önce kabuk genişletmelerinden bahsederken, grep ile regex kullanmak için de tırnak içinde yazmıştık. Tırnaklar sayesinde kesin olarak isteklerimizi iletmemiz mümkün oluyor.

Ayrıca tırnak içinde yazmaya ek olarak fark ettiyseniz burada aldığımız çıktıların hepsi küçük büyük harf duyarlılığı dahilinde tam olarak benim yazdığım ifadeyle eşleşenlerden oluşuyor. Eğer filtreleme yapılırken küçük büyük harf duyarlılığının görmezden gelinmesini istersek -i seçeneğini kullanabiliyoruz. Buradaki i seçeneği insensitive yani duyarsız ifadesinin kısaltmasından geldiği için küçük büyük harf duyarsızlığı için i seçeneğini kullanıyoruz. Pek çok araç da aynı şekilde küçük büyük harfin görmezden gelinmesi için i seçeneğini kullanmamızı istiyor.

Şimdi ben test etmek için en son girmiş olduğum komutu tekrar çağırıp, buraya i seçeneğini de ekliyorum.

Bakın bu kez küçük büyük harf demeden ahmet can ifadesi ile eşleşen tüm satırlar getirilmiş oldu. Neticede hepsi ahmet can ifadesiyle eşleşiyor ama küçük büyük harf farkları var. Siz de i seçeneği sayesinde bu şekilde filtreleme yapılırken küçük büyük harflerin görmezden gelinmesini sağlayabilirsiniz. 

Küçük büyük harf duyarlılığı dışında, satırlarda yer alan verilerin bir kısmı yerine spesifik olarak bizim aradığımız kelimeyle eşleşenleri istediğimiz durumlarda word ifadesinin kısaltmasından gelen -w seçeneğini de kullanabiliyoruz.

Ne denemek istediğimi daha net göstermek adına ben grep “ali” isimler.txt şeklinde komutumu giriyorum. Bakın çıktılarda yalnızca ali ifadesi değil, satırın herhangi bir noktasında ali ifadesi geçenler de bastırılmış oldu. Eğer ben bu şekilde herhangi bir noktada değil de tek başına ali ifadesini arıyorsam aynı komutumu bu kez -w seçeneğiyle birlikte kullanabilirim. Ben komutumu çağırıp, w seçeneğini ekliyorum.

Bakın bu kez yalnızca tam olarak ali kelimesinin tem başına bulunduğu satırlar filtrelenmiş oldu. 

Bu özellikler dışında eğer istersek burada aldığımız çıktıları daha okunaklı hale getirebiliriz. Mesela eğer n seçeneğini eklersek, satır numaralarını da görmemiz mümkün. Ben en son girmiş olduğum komutu çağırıp n seçeneğini de ekliyorum.

Bakın bu kez bu ifadelerin tam olarak hangi satırda geçtiği satırın en başında yazıyor.

Ayrıca satır numarası yerine istersek toplamda kaç eşleşme olduğunu öğrenmek için count ifadesinin kısaltmasından gelen c seçeneğini de kullanabiliriz. Ben yine en son komutumu çağırıp w yerine c seçeneğimi girmek istiyorum. Komutumuzu bu şekilde onaylayabiliriz. 

Bakın toplam kaç eşleşme olduğu burada yazıyor. Benim dosyamda tam olarak 24 kere tamamı küçük harfli ali kelimesi geçiyormuş. Tamamdır bence temel grep kullanımı için bu kadar bilgi yeterli.

Ben son olarak grep ile temel düzeyde regex kullanımından da bahsedip anlatımı noktalamak istiyorum. 

grep aracımız basit, genişletilmiş ve perl uyumlu olmak üzere üç tür genişletme özelliğini destekliyor olmasına karşın varsayılan olarak basit genişletmeyi kullanıyor.

Biz basit olanla başlayacak olursak, eğer spesifik olarak belirli bir ifadeyle başlayan satırları filtrelemek istersek şapka ya da düzeltme işareti olarak da bilinen ^ bu işareti kullanabiliyoruz. 

Örneğin ben “ay” ifadesiyle başlayanları filtrelemek istersem grep “^ay” isimler.txt şeklinde komutumu yazabilirim. Bakın burada tırnak içinde yazığım şapka işareti ve peşindeki ay karakteri, ay ile başlayan satırların filtrelenmesini sağlayacak olarak regex tanımı. Hemen komutumuzu onaylayalım.

Bakın yalnızca başlangıç harfi ay olanlar bastırılmış oldu.

Tersi şekilde eğer sondaki karakterleri bizim istediğimiz karakterlerle eşleşenleri filtrelemek istersek de dolar işaretini kullanabiliyoruz. Ben sonu “az” ifadesiyle bitenleri filtrelemek için grep “az$” isimler.txt şeklinde giriyorum.

Bakın yalnızca sonunda az ifadesi olanlar bastırıldı. Bu tanımı yazarken dolar işaretini sona eklemiz gerektiğine dikkat edin lütfen. Eğer dolar işaretini bu şekilde sonda değil de başta yazacak olursak. Bakın satırı sonunda burada belirtmiş olduğumuz ifadeler listelenmedi çünkü dolar işaretinden önce filtrelenmesi gereken spesifik bir karakter belirtilmemiş oldu. Sondaki verileri filtreleyecekseniz dolar işaretinden önce bunları yazmanız gerekiyor.

Diğer basit regex tanımıyla devam edecek olursak, nokta işareti sayesinde tek bir karakter ile eşleşecek şekilde tanımlama yapmamız mümkün.

Denemek için grep “a.” isimler.txt şeklinde komutumuzu girelim. Bakın a karakteri ve devamında küçük büyük olması fark etmeksizin herhangi bir karakteri barındıran tüm veriler filtrelenmiş oldu. Mesela a karakteri ve devamında herhangi bir karakter bulunan peş peşe ifadeler olduğu için bu şekilde sonuçlar da aldık. Eğer biz spesifik olarak yalnızca a ile başlayıp devamında herhangi bir karakter olan kelimeleri arıyorsak komutumuzu tekrar çağırıp -w seçeneğini ekleyebiliriz.

Bakın bu kez yalnızca birleşik olmayan tekil kelimeler filtrelenmiş oldu. Mesela bir nokta daha eklersek, herhangi bir karakter daha ekleneceği için a ile başlayıp devamında herhangi iki karakteri barındıranlar filtrelenecek.

Bakın tam olarak beklediğimiz gibi a ile başlayan ve devamında herhangi iki karakteri barındıran tüm satırılar filtrelendi. 

Eğer rastgele karakterler yerine spesifik olarak bizim istediğimiz bazı karakterlerin bulunduğu verileri filtrelemek istersek köşeli parantez kullanabiliriz.

Örneğin ben a karakterinden sonra yalnızca k l  ve r karakterlerinden birini barındıran verileri filtrelemek istediğim için grep “a[klr]” isimler.txt şeklinde komutumu giriyorum. Bakın tam olarak a karakterinden sonra köşeli parantez içinde belirttiğimiz karakterlerden birini barındıran tüm veriler filtrelendi. Eğer tekil olarak bu kalıba uyan kelimeleri arıyorsak yine komutumuzu çağırıp -w seçeneğini ekleyebiliriz.

Bakın yalnızca a karakterini ve devamında k l r karakterlerinden birini barındıran tüm bağımsız kelimeler bastırılmış oldu. Tersi şekilde eğer köşeli parantez içindeki karakteri hariç tutup bunlar dışındaki herhangi karakterleri kapsamak istersek de köşeli parantezin en başında şapka işaretini kullanabiliyoruz.

Ben en son girmiş olduğum komutu çağırıp parantezin en başına şapka işaretini ekliyorum. Bakın bu kez a karakterinden sonra k l r karakterleri içermeyen kelimeler bastırıldı. Buradaki büyük L karakteri küçük l haricinde olduğu için bastırıldı. Yani gördüğünüz gibi şapka işareti sayesinde buradaki karakterleri hariç tutarak filtreleme yapabiliyoruz. Örneğin yalnızca bağımsız kelimler yerine serbest şekilde filtreleme yapmak istersek komutumuz tekrar çağırıp buradaki w seçeneğini kaldırabiliriz. Bakın buradaki çıktıların hepsi a karakterinden sonra k l ve r karakterlerini içermeyen veriler.

Burada dikkat ettiyseniz bizim köşeli parantez içinde yazdığımız karakterler yalnızca tek bir karakter ile eşleşme sağlıyor. Örneğin ben a karakterinden sonra k l r karakterlerini bulundurmayan ama a b ve c karakterinden birini bulunduran veriyi filtrelemek istersem komutumu grep a[^klr][abc] isimler.txt şeklinde girebilirim. Bakın tam olarak a karakterinde sonra k l r karakterini barındırmayan ama üçüncü karakterinde a b ve c karakterlerinden herhangi birini barındıran tüm veriler filtrelenerek renklendirilmiş oldu.

Yani gördüğünüz gibi köşeli parantez sayesinde spesifik olarak tek bir karakterin nasıl olması veya olmaması gerektiğini belirtebiliyoruz. Ve tabii ki peş peşe burada olduğu gibi köşeli parantez kullanarak da hangi karakterin ne şekilde olabileceğini de spesifik olarak sınırlayabiliyoruz. 

İşte basit regex genişletmeleri bu şekilde.

Basit regex dışında bir de genişletilmiş regex kalıplarını kullanmamız da mümkün. Fakat ben bunların detaylarına girmek istemiyorum. Çünkü genişletilmiş regex yapılarını kullanmak için regex özelliklerini biliyor olmak lazım. Eğer genişletilmiş regex karakterlerini kullanmak istiyorsanız, önce regex yapısını nasıl kullanabileceğinizi öğrenmeniz gerekiyor. İnternet üzerinde bu konuda yerli yabancı pek çok kaynak var. Zaten burda asıl önemli olan nokta bu karakterlerin grep üzerinde nasıl kullanılabileceği. Yoksa internet yardımıyla da istediğiniz filtreleme biçimi için gereken regex kuralını bulabilirsiniz. 

Ben yalnızca örnek olması için genişletilmiş regex kullanımına bir tane örnek vermek istiyorum. Regex yapısını öğrenen arkadaşlar bu şekilde grep üzerinden tüm regex karakterlerini kullanabilirler.

Örneğin regex için ya da anlamına gelen dik çizgi işaretini kullanarak filtreleme yapmayı deneyebiliriz. 

Ben ahmet can ayse isimlerinden birini barındıran satırları filtrelemek istersem grep “ahmet|can|ayse” isimler.txt şeklinde komutumu girebilirim.

Bakın bu şekilde girince bir çıktı almadık çünkü buradaki kullandığımız dikey çizgi karakteri regex in ya da anlamında kullandığı karakter olarak temsil edilmedi. Bunun yerine komutumuza -E seçeneğini eklersek bu karakter beklendiği şekilde çalışacak. Hemen denemek için komutumuzu çağırıp büyük E seçeneğini ekleyelim.

Bakın bu kez ahmet can veya ayse ifadelerini barındıran satırların filtrelenmesini sağlamış olduk. Buradaki büyük E seçeneği ****Extended**** yani genişletilmiş ifadesinin kısaltmasından gelen seçeneğimiz. Bu seçenek sayesinde tıpkı buradaki dikey çizgi gibi doğrudan regex karakteri olarak algılanmayan regex karakterlerinin kullanılabilmesi de mümkün oluyor. Eğer regex kullanımını biraz daha detaylıca araştırırsanız, verilerinizi filtrelemek için sınırsız çeşitlilikte regex tanımlamaları yapabileceğinizi görmüş olursunuz. Ben referans olması için size ders kaynağında regex için rehber websitesi de eklemiş olurum. Harici olarak isterseniz yerli ve yabancı kaynaklardan regex karakterlerinin işlevleri ve kullanımları hakkında daha fazla bilgi edinebilirsiniz.

Benim şimdilik regex ve grep aracı hakkında bahsetmek istediklerim bu kadar. Zaten temelde bilmemiz gerekenlerden bahsettik. Daha fazlası için hem grep aracının yardım sayfasına hem de regex için harici kaynaklara bakmanız yeterli.

REGEX kaynakları:

Türkçe Doküman: [https://github.com/ziishaned/learn-regex/blob/master/translations/README-tr.md](https://github.com/ziishaned/learn-regex/blob/master/translations/README-tr.md)

[https://github.com/gkandemi/regex#regular-expressions--regex--düzenli-i̇fadeler](https://github.com/gkandemi/regex#regular-expressions--regex--d%C3%BCzenli-i%CC%87fadeler)

Türkçe Video Rehber: [https://www.youtube.com/watch?v=bF_zEzFQZuA](https://www.youtube.com/watch?v=bF_zEzFQZuA)

İnteraktif Eğitim Serisi: [https://regexone.com/lesson/introduction_abcs](https://regexone.com/lesson/introduction_abcs)

İnteraktif Eğitim Serisi: [https://regexlearn.com/learn](https://regexlearn.com/learn)

# find

find aracı, açıkça isminde de anlaşılabileceği gibi sistem üzerindeki dosya ve klasörleri arayıp, konumlarını bulmamıza yardımcı olan bir araç. En yalın kullanımı find komutundan sonra hangi dizinde araştırıma yapılacağını belirtip daha sonra -name seçeneğinin ardından araştırılacak olan dosya ya da klasör isminin girilmesi şeklinde. 

Ben denemek için öncelikle touch ~/Documents/bulbeni şeklinde komutumu girip, Documents dizini altında boş bir dosya oluşturuyorum. Şimdi bir de klasör oluşturmak için mkdir ~/Pictures/bulbeni şeklinde komutumuzu girebiliriz. 

Tamamdır. Aynı isimli dosya ve klasörümüzü farklı dizinlerde oluşturmuş olduk.

Şimdi find komutumuzu bu dosya ve klasörleri bulmak için kullanabiliriz. Ben şu an ev dizinimdeyim, bulunduğum dizinden itibaren tüm alt dizinlere bakılıp aradığım kelime ile eşleşen dosya ya da klasör ismi var mı diye bakmak için find . yazıyorum burada . bulunduğum dizini temsil ediyor. Aslında nokta yazmasam bile find komutu ekstra bir hedef belirtmediğimiz sürece mevcut dizinimizde araştırma yapıyor ama biz daha anlaşılır olması için mevcut dizinimizi nokta ile hedef gösterebiliriz. Yani find komutuna benim bulunduğum dizinin altına bak demiş oluyorum. Yazacağım kelimeyle eşleşen dosya ve klasörleri bulmak için de -name seçeneğinin ardından aradığım kelimeyi giriyorum.

Bakın isimle eşleşen hem klasör hem de dosya, tam konumlarıyla birlikte listelenmiş oldu.

Bu find komutunun en yalın kullanımı bu şekilde. Tabii ki tüm kullanım imkanı bundan ibaret değil. Araştırma yapılırken filtreleme yapılabilmesi için aranacak dosya veya klasörün özelliklerine göre kullanabileceğimiz birden fazla seçenekler bulunuyor. Hemen kısaca bunlardan söz edelim.

Eğer yalnızca dosyaları filtrelemek istiyorsak type seçeneğinin ardından file yani dosya ifadesinin kısaltmasından gelen f parametresini yazmamız gerekiyor. Eğer klasörleri filtrelemek istersek de directory yani klasör ifadesinin kısaltmasından gelen d ifadesini kullanabiliyoruz. Hemen örneğimiz üzerinden deneyelim. 

Ben öncelikle bulbeni isimli dosyayı araştırmak istediğim için find . -type f -name “bulbeni” şeklinde yazıyorum. Bakın burada aldığımız çıktı yalnızca dosyanın konumunu veriyor. pipe xargs ls -l komutuyla bu çıktıyı ls aracına argüman olarak verip bu durumu teyit edebiliriz. Bakın find komutunun çıktısında verilen bu dizin bu isimdeki dosyanın dizin adresini belirtiyormuş. 

Benzer şekilde yalnızca klasörü bulmak için d seçeneği ile araştırma yapabiliriz. 

find . -type d -name “bulbeni” şeklinde araştıralım. 

Bakın bu çıktı da klasörün konumuna işaret ediyor. Bu adresin dizin adresi olduğunu teyit etmek istersek yine | xargs ls -ld komutuyla kontrol edebiliriz. Bakın burada bulbeni isimli bir klasör mevcutmuş.

Yani bakın bizzat teyit ettiğimiz gibi find ile araştırma yapılırken bu şekilde dosya ve klasör olma durumuna göre yani tipine göre filtreleme yapabiliyoruz. 

Mesela ben yalnızca mevcut bulunduğum dizinde araştırma yaptım ama aslında istediğim bir dizin altında araştırma yapılmasını sağlayabilirim. denemek için bu kez etc dizini atlında sonu .conf ile biten tüm içerikleri bastırmak istiyorum. Bunun için find /etc/ -name “*.conf” şeklinde komutumu yazıp onaylıyorum. Bakın etc dizini atlında isminin sonu conf ile biten tüm dosya ve dizinler filtrelenmiş oldu. Eğer yalnızca etc dizini altında değil de tüm sistem genelinde araştırma yapmak istersek araştırılacak dizin yerine yalnızca slash karakterini yazmamız da yeterli. Tabii ki bu işlem tüm sistem hiyerarşisinin kontrol edilmesini gerektirdiği için biraz vakit alabilir. Ancak neticede gördüğünüz gibi istediğimiz bir dizin altında aradığımız isimle eşleşen dosya ve dizinleri belirtebiliyoruz. 

Ben burada yazmadım ama tabii ki istersek bu çıktıları da yalnızca dosya veya klasörlere göre filtrelemek için yine type seçeneğini de kullanabiliriz. 

Şimdi diğer filtreleme özelliklerinden bahsederek devam edecek olursak tip seçeneğini belirtmek dışında dilersek, boyutuna göre araştırma da yapabiliriz. Boyuta göre filtreleme yapmak için size seçeneğini kullanmamız gerekiyor. Örneğin bulunduğumuz dizin altındaki 1 megabayttan büyük olan tüm dosyaları getirmek için find . -type f -size +1M şeklinde komutumuzu kullanabiliriz. 

Bakın buradaki tüm dosyalar 1 megabayttan büyük olan dosyalar. Eğer küçük olanları istersek artı yerine eksi işaretini girebiliriz. Bakın bu aldığımız çıktılar da 1 megabayttan küçük olanlar.

Boyutu farklı girmek isterseniz bayt için b kilobayt için k megabayt için büyük M ve gigabayt için büyük G kullanabilirsiniz. 

Ayrıca erişim, değişim ve düzenleme tarihlerine göre de filtrelemeniz de mümkün. Zaten bu tarihlerin neyi ifade ettiğini daha önce açıklamıştık.

Örneğin düzenlenme tarihi için mtime kullanılıyorken, değişim tarihi için ctime, erişim tarihi için de atime parametrelerini kullanabiliyoruz.

işte atime mtime veya ctime seçeneğinin arından kaç gün önce veya kaç gün sonra olduğunu eksi veya artı işareti ile belirtebiliyoruz. Ayrıca tam gün sayısı belirtmek için de artı ve eksi olmadan doğrudan günü yazmamız yeterli.

Eğer ben mevcut bulunduğum dizinde tam olarak 5 gün önce düzenlenmiş içerikleri görmek istersem find -mtime 5 şeklinde komutumu girebilirim.

Bakın buradaki içerikler tam olarak 5 gün önce düzenlenmiş dosya ve klasörler.

Eğer 5 günden daha kısa bir süre önce düzenlenmişleri öğrenmek istersek -5 ile beş günden öncesini belirtebiliriz. Bakın bunlar bu gün dün veya 2 3 4 ve 5 gün önce düzenlenmiş olan içerikler. Eğer düzenleme süresi 5 günden daha önceki içerikleri görmek istersek de find -mtime +5 şeklinde düzenlenme tarihinden 5 günden daha fazla zaman geçmiş olacağını belirtebiliriz.

Yada örneğin son 24 saatte düzenlenmiş olanları filtrelemek için find -mtime -1 şeklinde girebiliriz. Buradaki -1 bir günden önce zaman aralığını belirttiği için son 24 saatten şu ana kadar düzenlenmiş içerikler filtreleniyor. 

Ben örnekler sırasında düzenlenme tarihleri için mtime seçeneğini kullandım ama siz değişim tarihleri için ctime, erişim tarihleri için de aynı şekilde atime seçeneklerini kullanarak arama sonuçlarını filtreleyebilirsiniz.

Ayrıca ben hep günler üzerinden ele aldım ancak aslında dakika üzerinden de bu filtrelemeyi yapmamız mümkün. Örneğin son 50 dakika içinde düzenlenmiş olanları filtrelemek için find -mmin -50 şeklinde komutumu girebilirim. Bakın bunlar son 50 dakika içerisine düzenlenmiş olanlar. Günleri belirtirken mtime şeklinde yazıyorken, dakikaları belirltmek için minutes ifadesinin kısaltmasından gelen min seçeneğini kullanıyoruz. Yani düzenlenme dakikası için mmin, değişim dakikası için cmin, erişim dikaksı için de amin, seçeneklerinin ardından dakikayı belirtebiliyoruz. Ben burada -50 şeklinde yazdığım için son 50 dakika içerisindekileri kapsadım. Örneğin +50 yazacak olursam, düzenlenme tarihi 50 dakikadan daha önce olan tüm içerikleri kastetmiş oluyorum.

Örneğin ben son 1 saat içerisinde hiç açmadığım yani erişmediğim içerikleri listelemek istersem, find -amin +60 şeklinde komutumu girebilirim. Bakın burada listelenmiş olan içeriklerin hiç birisine son 1 saat içerisinde erişim sağlamamışım. Tersi şekilde son bir saat içerisinde erişim sağladıklarımı görmek için de buradaki +60 ı -60 yapabilirim.

Bakın bunlar da son bir saat içerisinde erişim sağlanmış olanlar. Bence kullanımı son derece kolay. Biraz pratik yaparsanız tam olarak kullanımına alışırsınız zaten.

Ayrıca tüm bu bahsettiklerimiz dışında eğer man find şeklinde yazarsanız, aslında ne kadar çok filtreleme seçeneği olduğunu kendiniz de görebilirsiniz. Ancak ben hepsine değinmeyeceğim. İhtiyacınız olduğunda manuel sayfasından açıp bakabilirsiniz.

Henüz daha öğrenmediğimiz için yetkilere ve sahipliğe göre filtrelemeden bahsetmek istemiyorum. Ama zaten aynı şekilde find aracının yardım bilgilerinde belirtilen tüm seçenekleri ihtiyacınıza göre kullanabilirsiniz. Örneğin içerikleri yetkilerine göre filtrelemek için perm seçeneğini kullanıyorken, sahipliğine göre filtrelemek için de user seçeneğini kullanabiliyoruz. Ve bunlar gibi yardım sayfasında görebileceğiniz çeşitli filtreleme seçenekleri mevcut. İhtiyaç duyduğunuzda açıp yardım bilgisinden hangi seçeneği kullanmanız  gerektiğini öğrenebilirsiniz.

Ben dediğim gibi yetki ve sahip kavramlarından henüz bahsetmediğimiz için kafanızın karşımasını istemiyorum, zaten aynı şekilde tek yaptığımız bu özelliklere göre filtreleme yapmak. Bu konuları öğrendiğinizde dönüp find ile bu kriterlere göre filtreleme yapmakta özgürsünüz.

Ben son olarak aldığımız tüm çıktıları tersine çeviren -not seçeneğinden bahsetmek istiyorum.

Örneğin ben find -name “*.png” komutuyla mevcut dizinim altındaki sonu png ile biten tüm içerikleri filtrelersem, gördüğünüz gibi tam istediğim gibi bu adresleri öğrenebiliyoruz. Eğer ben bu komutumu tekrar çağırıp, tersini kullanmak istediğim seçenekten hemen önce -not seçeneğini ekleyecek olursam yani find -not -name “*.png” şeklinde komut girersem bakın bu kez sonunda png ismi olanlar hariç tüm içerikler bulunup konsola bastırılmış oldu.

İşte burada benim yalnızca isim seçeneği üzerinden gösterdiğim bu not seçeneği sayesinde tüm filtrelerin tersi şekilde çalışmasını sağlayabilirsiniz. Örneğin ben bir gün önce düzenlenmiş içerikleri filtrelemek için find -mtime 1 şeklinde komut girdiğimde bakın, tam olarak bir gün önce düzenlenmiş içerikler listeleniyor. Eğer buradaki mtime seçeneğinden önce not seçeneğini ekleyecek olursak, bakın bu kez tam tersi şekilde yani 1 gün önce oluşturulmamış olan tüm içerikler bastırılmış oldu.

Tamamdır, benim find komutu hakkında bahsetmek istediğim tüm temel bilgiler bu şekilde. Tabii ki yardım sayfasından da görebileceğimiz gibi aslında find aracının çok daha fazla özelliği mevcut ancak temel seviye için ilk aşamada bunların hepsi fazla gelebilir. Eğer merak ediyorsanız zaten buradan ve kısa internet araştırması ile diğer özellikleri hakkında bilgi edinebilirsiniz.

Ben şimdi araştırma yapma konusunda bir diğer alternatifimiz olan locate aracından bahsederek devam etmek istiyorum.

# locate

locate komutu sayesinde sistemdeki dosya ve dizinleri isimleriyle araştırabiliyoruz.

locate komutu daha önce ele aldığımız find aracından farklı olarak araştırma işlemi sırasında tüm dosya sistemine değil daha önceden oluşturulmuş veri tabanını kullanıyor. Bu sayede isimler üzerinden yaptığımız araştırmada, find aracından çok daha hızlı şekilde sonuç verebiliyor.

Aracımızın en temel kullanımı locate aranacak-isim şeklinde. Fakat dediğim gibi locate aracı kendisine ait olan veritabanı üzerinden araştırma yaptığı için araştırmalarımız sırasında daha sağlıklı çıktılar elde edebilmek adına bu veritabanını güncellememiz gerekiyor.

Ben hemen test etmek için bir önceki derste find aracıyla bulmak için oluşturduğum farklı konumlardaki bulbeni isimli dosya ve klasörleri locate bulbeni komutuyla sorgulamak istiyorum. Bakın herhangi bir çıktı almadık. Biz bu dosya ve klasörü yeni oluşturduğumuz için locate aracının kullandığı veritabanına bu dosya ve klasörün dizin adresi eklenmedi. Dolayısıyla bu isimde bir eşleşme olmadı. 

locate veritabanını güncellemek için sudo updatedb şeklinde komutumuzu girebiliriz. Ben parolamı girip işlemi onaylıyorum. Yeni dizinlerin eklenmesini bir süre bekleyelim. Tamamdır prompt satırımıza tekrar döndük. Şimdi dosya sistemindeki en son değişikliklerin vertibanına eklenmiş olması gerekiyor. Tekrar etmek için locate bulbeni şeklinde komutumuzu girebiliriz. 

Bakın bu kez anında aradığım kelimeyle eşleşen dosya ve dizinlerin adresi konsola bastırıldı. İşte gördüğünüz gibi locate aracı hızlı çalışıyor olmasına rağmen, veritabanı updatedb komutu ile güncellenmediyse sistemde mevcut olan yeni dosya ve dizinleri bulamıyor. Dolayısıyla locate aracını kullanmadan önce sağlıklı çıktılar almak istiyorsanız mütlaka updatedb komutuyla güncelleme yapın. Normalde her gün düzenli olarak bu veritabanı otomatik olarak güncelleniyor ancak dediğim gibi kullanmadan önce stabil çıktılar istiyorsanız updatedb komutunu çalıştırmanız şart.

Eğer aradığınız dosya isminde küçük büyük harf duyarlığının görmezden gelinmesini isterseniz komutunuza -i seçeneğini de ekleyebilirsiniz.

Ben denemek için locate ABC şeklinde yazıp içerisinde tamamı büyük harflerden oluşan ABC karakterlerini barından dosya ve klasör isimlerini listelemek istiyorum. Bakın buradaki çıktıların hepsinde yalnızca tamamı büyük olan ABC ifadesi geçiyor. Eğer küçük büyük harf duyarlılığını kaldırmak istersek komutumuzu tekrar çağırıp i seçeneğini ekleyebiliriz. Bakın bu kez küçük büyük harf fark etmeksizin tüm dosya ve klasörler listelenmiş oldu.

Kaç tane eşleşme olduğun saymak istersek count ifadesinin kısaltmasından gelen c seçeneğini ekleyebiliriz. Bakın kaç eşleşme olduğunu görebiliyoruz. Ya da mesela regex kullanmak istediğimizde bunu özellikle —regex seçeneğiyle belirtmemiz gerekiyor. Ben denemek için öncelikle locate "(\.rar|\.zip)” şeklinde regex tanımıyla eşleşme sağlamak üzere komutumu giriyorum. Bakın herhangi bir çıktı almadık çünkü regex çalışmadı. Bu girmiş olduğumuz tanımın özellikle genişletilmiş regex kuralları dahilinde değerlendirilmesi için —regex seçeneğini eklememiz gerekiyor. Komutumuzu çağırıp bu kez —regex şeklinde ekleyelim ve onaylayalım.  

Bakın bu kez tama olarak isminin herhangi bir noktasında .rar veya .zip geçen tüm içerikler bastırılmış oldu. Ayrıca mesela regex —help komutuyla bir bakacak olursak bakın genişletilmiş regex kuralları yerine basit regex kuralları için de r seçeneğini kullanabileceğimiz belirtilmiş. Benim en son girmiş olduğum tanımlama genişletilmiş regex dahilinde. Zaten daha önce grep aracını açıklarken basit ve genişletilmiş regex kurallarına çok kısaca değinmiştik. İşte eğer ben buradaki tanımlamayı genişletilmiş regex yerine basit regex ile çalıştırmayı denersem buradaki çıktıyı alamam. Denemek için komutumuzu çağırıp, —regex yerine yalnızca -r seçeneğini yazıp komutumuzu onaylayalım. Bakın herhangi bir çıktı bastırılmadı çünkü benim buraya yazdığım tanımlama basit değil genişletilmiş regex dahilinde. Tamamdır en nihayetinde benim locate aracı hakkında bahsetmek istediklerim bunlar. Tabii ki bakın buradaki yardım bilgisi üzerinden de görebildiğimiz gibi ek seçenekleri yani benim bahsetmediğim ek özellikleri de bulunuyor. Eğer isterseniz kurcalayıp işlevlerini öğrenebilirsiniz. Bence temel eğitim için bahsetmiş olduklarımız yeterli.

Ayrıca son olarak locate ile find arasındaki farkı vurgulamak istiyorum.

Find komutu ile dosyaları özniteliklerine göre filtreleyebildiğiniz için daha fazla seçeneğe sahibiz. Zaten find komutunu ele alırken dosyaların çeşitli özelliklerine göre nasıl filtreleme yapabileceğimizi ele aldık. İşte locate komutu yalnızca dosya isimleri ile eşleşme yaptığı için find komutu ile kullanabileceğiniz dosya özelliklerini filtreleme gibi işlevleri kullanamazsınız. Yalnızca dosya isimleri üzerinden hızlıca araştırma yapmak istediğimizde locate aracını kullanabiliriz. Tabii ki araştırmadan önce updatedb komutuyla veritabanını güncellemeyi de unutmamız gerekiyor.

# cut

[https://linuxize.com/post/linux-cut-command/](https://linuxize.com/post/linux-cut-command/)

cut komutu, satırların istenilen bölümlerinin kesilmesini sağlayan bir araçtır. Zaten isminde geçen cut ifadesi Türkçe olarak kesmek anlamına geliyor. Ben örnekler sırasında basit bir metin dosyası üzerinde çalışıyor olacağım ancak siz okunabilir formatta olan tüm metinsel verilerinizi cut komutu ile kesip biçimlendirebilirsiniz.

Öncelikle dosya içeriğini cat komutu ile görüntüleyelim. Bakın boşluklarla ayrılmış pek çok sütun bulunuyor. Normalde tabii ki daha anlamlı veriler üzerinde çalışıyor olacaksınız fakat ben komutun anlaşılması için yani bölümleri etkilediğini daha rahat görebilmemiz için dosya içerisine satır1sutun1 satı1sutun2 veya satır2sutun1 şeklinde tek tek eklenmesini sağladım. 

```bash
satir1sutun1 satir1sutun2 satir1sutun3 satir1sutun4 satir1sutun5
satir2sutun1 satir2sutun2 satir2sutun3 satir2sutun4 satir2sutun5
satir3sutun1 satir3sutun2 satir3sutun3 satir3sutun4 satir3sutun5
satir4sutun1 satir4sutun2 satir4sutun3 satir4sutun4 satir4sutun5
satir5sutun1 satir5sutun2 satir5sutun3 satir5sutun4 satir5sutun5
satir6sutun1 satir6sutun2 satir6sutun3 satir6sutun4 satir6sutun5
satir7sutun1 satir7sutun2 satir7sutun3 satir7sutun4 satir7sutun5
satir8sutun1 satir8sutun2 satir8sutun3 satir8sutun4 satir8sutun5
```

Şimdi cut aracının kullanımına geçecek olursak, örneğin ben bu dosyadaki tüm sütunları değil de yalnızca 1 ila 3. sütunları istiyorsam cut komutuna bu durumu izah edebilirim. Bu işlem için cut komutuna bu verileri neye bakarak ayıracağını bildirmemiz gerekiyor. Tıpkı kabuğun komutları yorumlaması gibi cut aracı da elindeki verilerin hangi parçalardan oluştuğunu anlamak için bir delimiter yani sınırlayıcı karakter belirtmemizi istiyor. Bunun için cut komutundan sonra -d seçeneğinin hemen ardından sınırlayıcı karakteri yazmamız lazım. Örneğin benim dosyamda boşluk karakteri sütunları birbirinden ayırdığı için ben tırnak için “ “ boşluk karakterinin sınırlayıcı olduğunu belirtiyorum. Şimdi son olarak hangi sütunların, yani aslında burada da belirttiğimiz şekilde hangi bölümlerin kalmasını istiyorsak, bunu fields yani alanlar-bölümler seçeneğinin kısalması olan -f seçeneğinin hemen ardından belirtebiliyoruz. Ben 1 ila 3. bölümleri almak istediğim için 1-3 şeklinde yazıyorum ve işlenecek verilerin bulunduğu dosyanın ismini de ekleyip komutumu onaylıyorum.

Bakın yalnızca 1. den 3. bölüme kadar olan sütunlar bastırıldı. Hatta emin olmak için tekrar cat dosya-ismi şeklinde komutumu giriyorum. Bakın normalde 5. sütuna yani 5. bölüme kadar olan içerikler cut komutu sayesinde 3. bölüme kadar kesilmiş oldu. cut komutu ona söylediğimiz gibi dosya içeriğini okuyup dosyadaki boşluk karakterinin bulunduğu tüm bölümleri birbirinden ayırdı ve bizim belirttiğimiz bölümleri de filtreleyip bize sundu. Burada önemli olan, bölümleri birbirinden ayıran boşluk karakterinin cut komutuna bildirilmesi. Hatta bu durumda emin olmak için ben aynı içeriğin boşluk yerine virgüllerle ayrılmış sürümü üzerinden cut komutunu tekrar kullanmak istiyorum. Öncelikle dosya içeriğini kontrol etmek için cat komutu ile virgüllü dosyayı okuyalım. Bakın buradaki tüm bölümler virgülle birbirinden ayrılmış durumda. Şimdi biz bu verileri kesmek istersek virgüllerin sınırlayıcı değer olduğunu özellikle belirtmemiz gerekiyor. Bu durumu bizzat teyit etmek için virgülü belirtmeden önceki komutumuzu yani boşluk karakterini sınırlayıcı olarak belirttiğimiz komutumuzu bu dosya üzerinde de uygulamayı deneyebiliriz. Bakın herhangi bir kesme işlemi uygulanmadı. Şimdi buradaki delimiter yani sınırlayıcı karakteri olarak tırnak için virgül karakterini ekleyip komutumuzu bu şekilde çalıştıralım. “,” Bakın virgül karakteri sayesinde birbirinden ayrıştırılan bölümler cut komutu tarafından işlenip tam olarak istediğim bölüm aralığı sunuldu. Bu örnek üzerinden de görebildiğimiz gibi elimizdeki verinin türüne göre sınırlayıcı olan değeri doğru şekilde belirtmezsek, kesme işlemi de uygulanamıyor. Eğer cut komutuna herhangi bir sınırlayıcı karakter belirtmezsek, cut varsayılan olarak tab boşluklarına göre bölümleme yapıyor. Hemen denemek için herhangi bir sınırlayıcı karakter veya dosya ismi belirtmeden cut -f 3 şeklinde komutumu giriyorum. Bu komut sayesinde bakın cut komutu bizden veri girmemizi bekliyor. Biz buraya verileri girip enter ile onayladığımızda girdiğimiz verilerdeki 3. bölümde yer alan bölümü bize çıktı olarak tekrar sunacak. Çünkü ben burada -f 3 seçeneği ile 3. bölümdeki verilerin bastırılmasını talep ettim. Hemen denemek için aralarında yalnızca boşluk karakteri bulunacak şekilde 1 2 3 4 şeklinde komutumuzu girelim. Bakın 3. rakamını değil, doğrudan tüm girdiğimiz verileri çıktı olarak geri aldık. Çünkü cut komutu boşluk karakterini varsayılan sınırlayıcı karakter olarak görmüyor. Bunun yerine 1 tab 2 tab 3 tab 4 tab 5 şeklinde tekrar veri girişi yapıp enter ile onaylayabiliriz. Bakın bölümleri tab tuşu ile ayırdığım için bu kez yanıt olarak yalnızca 3. bölümdeki 3 rakımını almış olduk. Böylelikle bu örnek üzerinden cut komutunun varsayılan sınırlayıcı değer olarak tab boşluğunu kabul ettiğini, ve spesifik olarak dosya ismi belirtilmediğinde doğrudan standart girdiden yani bizim örneğimizde konsolumuzdan verileri alıp işleyebileceğini görmüş olduk. Ayrıca -f seçeneğinin ardından belirttiğimiz tek bir sayı ile spesifik olarak istediğimiz tek bir bölümü filtreleyebileceğimizi de görmüş olduk.

Birkaç kullanım biçiminden daha bahsedecek olursak, tek bir bölüm yerine spesifik olarak birden fazla bölümü seçmek için de virgüllerle bölümleri belirtebiliriz. Ben 1 3 ve 5. bölümü istediğim için field seçeneğinin ardından 1,3,5 şeklinde komutumu giriyorum. Bakın tam olarak belirttiğim bölümler karşıma getirildi. 

Farklı bir kullanım biçimi olarak örneğin 3 e kadar olan bölümleri elde etmek için filed seçeneğinin ardından -3 şeklinde yazabiliriz. Buraya yazdığım eksi işareti “e kadar” anlamına geliyor. Yani örneğin -5 şeklinde yazıldığında 5 de dahil 5 e kadar olan bölümler demiş oluyorum. Hemen sonucu görmek için komutumuzu onaylayalım. Bakın tam olarak belirttiğim şekilde -3 ifadesi sayesinde 3. bölüme kadar bölümleri bastırmayı başardık. Benzer şekilde 3 den sonrası için de 3- şeklinde komutumuzu düzenleyebiliriz. Bakın şimdi de 3. bölüm de dahil 3 den sonraki tüm bölümler bastırıldı. Eğer işlediğimiz verilerde kaç bölüm olduğundan emin değilseniz bu şekilde aralık belirtip aralıktaki tüm bölümlerin kapsanmasını sağlayabilirsiniz. Zaten örneğin 3-5 şeklinde yazdığımızda da 3 den 5 e kadar değiş oluyoruz. Aralığı spesifik olarak başlatmadığımızda veya bitirmediğimizde cut komutu elindeki verilere göre aralığa uygun bölümlerin hepsini işliyor. 

Aslında cut komutun başka seçenekleri de bulunuyor ancak diğer seçeneklerin detaylarına girmeyi düşünmüyorum. Zaten temel çalışma yapısını anladığınız için cut —help komutu ile elde edeceğiniz buradaki tüm açıklamaları rahatlıkla anlayıp uygulayarak test edebilirsiniz. Örneğin bakın complement seçeneği, bizim belirttiğimiz bölümlerin haricindeki bölümleri bastıran bir seçenekmiş. Bu durumu görmek için en son girdiğimiz komutu tekrar girelim. Şimdi bir de bu komuta —complement seçeneği ekleyip tekrar girelim. Bakın ilk komutta tam olarak belirttiğimiz bölümler bastırılırken, complement seçeneğini kullandığımızda belirttiğimiz bölümlerin haricindekiler bastırıldı. 

İşte bu şekilde sütunları filtrelemek istediğimizde yani istediğimiz sütunları kesmek istediğimizde cut aracını kullanabiliyoruz. Diğer özellikleri için aynen burda olduğu gibi yardım sayfasına ya da internet üzerindeki harici kaynaklara bakabilirsiniz. Fakat temelde sütunları kesmek için bizim bahsetmiş olduklarımız yeterli.

# tr Komutu

tr komutunun ismi translate yani "çevirmek-dönüştürmek" ifadesinden geliyor. Temelde mevcut veriler içindeki karakterleri değiştirmek veya silmek için bu aracımızı kullanabiliyoruz. Küçük ve büyük harf değişimi, tekrar eden karakterlerin silinmesi, özel karakterlerin silinmesi ve bulup değiştirme gibi pek çok işlevi var. Biz temel birkaç işlevinden bahsediyor olacağız. 

tr komutu standart girdiden veri okuduğu için pipe ile veri aktarmak en sık tercih edilen kullanım yöntemidir. Ben kolay bir örnek olması için küçük i ve küçük e karakterlerini büyükleri ile değiştirmek üzere echo "linux dersleri" | tr "ie" "IE" şeklinde komutumu giriyorum. Yani ilk argüman olarak değiştirilecek karakterleri sırasıyla belirtirken, ikinci argümana da ilk argümandaki karakterlerin yerine hangilerinin geçeceğini sırasıyla belirtiyoruz. Burada girmiş olduğum argümanların sıralaması çok önemli. Çünkü tr komutu sıralamaya uyarak yani ilk argümanın ilk karakterini, ikinci argümanın ilk karakteri ile ve ilk argümanın ikinci karakterini de ikinci argümanın ikinci karakteri ile değişecek şekilde işlem yapıyor. 

Bakın aldığım çıktı, belirttiğim sırlamaya uyuyor. Şimdi sırlamayı değiştirip deneyelim. 

Bakın bu çıktı da komutta belirttiğim sırlama dahilinde yani küçük i için büyük E küçük e için de büyük i karakteri şeklinde oldu.

Örneğin tüm küçük harfleri büyük harflere dönüştürmek istersek aralık belirterek komut girebiliriz. Hemen deneyelim. Ben tekrar echo "linux dersleri" | tr komutunu giriyorum, şimdi tüm küçük harfli karakterleri kast etmek için a-z yazıyorum. Burada yazdığım a-z argümanı a dan z ye kadar olan tüm karakterler demek oluyor. Yerine geçecek karakterler için de yani ikinci argüman olarak da büyük şekilde A-Z yazıyorum. Böylelikle tüm küçük karakterler büyükleri ile eşleşip değiştirilecek.

Bakın tüm karakterler büyükleri ile otomatik olarak yer değiştirdi.

Ayrıca kullanabileceğimiz bazı özel kalıplar da bulunuyor. Bunları görmek için tr —help komutunu kullanabiliriz. Gördüğünüz gibi kullanabileceğimiz çeşitli özel karakterler yardım bilgisinde belirtilmiş. Örneğin bakın buradaki lower kalıbı küçük harfli olan tüm karakterleri kapsıyor, benzer şekilde upper da tüm büyük harfleri kapsıyor. Denemek için gelin bu kalıpları kullanarak küçük harfleri tekrar büyüğe dönüştürelim.

echo "Linux Dersleri" | tr [:lower:] [:upper:] şeklinde komutumu giriyorum. 

Gördüğünüz gibi tüm küçük harfli karakterler büyük harfler ile değiştirilmiş oldu. Tabii ki istersek tersi şekilde komut girerek, büyük harflerin küçük harfler ile değiştirilmesini de sağlayabiliriz. Bakın tüm büyük harfli karakterler küçükleriyle değişmiş oldu. Sizler de bu listeye göz atıp, ihtiyacınız olan kalıpları kolayca kullanabilirsiniz. 

Bir örnek daha yapalım ben PATH değişkenin çıktıların yer alan iki nokta karakterini yeni satır karakteri ile değiştirmek istiyorum. Öncelikle standart şekilde nasıl göründüğüne bakmak için echo $PATH komutu ile değişkeni konsola bi bastıralım.

```bash
taylan@virtualbox:~/arsiv$ echo $PATH
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
```

Bakın PATH yoluna ekli olan her bir dizin birbirinden iki nokta üst üste karakteri ayrılmış. Şimdi bu çıktı bana biraz karışık geldiği için her bir path dizinini yeni bir satırda görmek istiyorum. Bunu yapmak için iki nokta üst üste karakterini yeni satır karakteri ile yani bakın buradaki listede de görülen \n karakteri ile değiştirebiliriz. Hemen deneyelim. Ben komutumu echo $PATH | tr “:” “\n” şeklinde giriyorum.

```bash
taylan@virtualbox:~/arsiv$ echo $PATH | tr ":" "\n"
/usr/local/sbin
/usr/local/bin
/usr/sbin
/usr/bin
/sbin
/bin
/usr/games
/usr/local/games
/snap/bin
```

Bakın, her bir path dizinini ayrı ayrı satırlarda bastırmayı başardık. Bu şekilde tam istediğim gibi daha okunaklı bir çıktı elde etmiş oldum. Bence bu yaptığımız örnek, tr aracının kullanımına ve ayrıca yeni satıra geçilmesini sağlayan \n gibi kalıplara da iyi bir örnek oldu.

Yardım çıktısında yer alan buradaki kalıplar üzerinde pratik yaptığınız zaman zaten kolay hatırlanır isimleri dolayısıyla kolayca anımsayıp bu kalıplardan faydalanabilirsiniz. Ayrıca hatırlamadığınız durumda tabii ki bu şekilde yardım sayfası üzerinden de tekrar öğrenebilirsiniz. Zaten hatırlarsanız burada ters slash ile belirtilen karakterler echo komutunda da geçerliydi. Yani pek çok araç zaten benzer standardı izlediği için zaman içinde bu tür kalıplar aklınızda yer edecektir.

Bu ifadeler dışında biraz da seçeneklerinden bahsedebiliriz.

### Peş Peşe Tekrar Eden Karakterlerin Sadeleştirilmesi

Eğer peş peşe tekrar eden karakterlerden yalnızca bir tane kalmasını istersek, -s seçeneğini kullanabiliriz. Buradaki s seçeneği squeeze yani sıkmak, sıkıştırmaktan aklınıza gelebilir. Ben denemek için echo "www.deneme...com" şeklinde yazıyorum. Eğer buradaki noktaları silmek istersem, tr -s "." şeklinde komut girmem yeterli. Bakın peş peşe tekrar eden noktalar yerine yalnızca 1 tane nokta basıldı. 

```bash
└─$ echo www.deneme...com | tr -s "."                                                    
www.deneme.com
```

Benzer şekilde eğer tekrar eden w karakterinin de tek bir tane olacak şekilde değiştirilmesini istersem, bu w karakterini de ekleyebilirim. 

```bash
└─$ echo www.deneme...com | tr -s ".w"                                              
w.deneme.com
```

Bakın w karakteri de teke düşürüldü.

Hatta istersem bastırılabilir olan tüm tekrar eden karakterlerin otomatik olarak filtrelenmesini de sağlayabilirim. Bunun için öncelikle tekrar tr komutunun yardım sayfasına göz atalım. Bakın [:graph:] seçeneği boşluklar hariç bastırılabilir tüm karakterler için kullanılabiliyormuş. Deneyelim. Ben komutumu echo "www.deneme...com" | tr -s “[:graph:]” şeklinde giriyorum.

Gördüğünüz gibi peş peşe tekrar eden tüm karakterler teke düşürülmüş oldu. Dikkat ettiyseniz peş peşe tekrar etmesi önemli, nitekim buradaki deneme ifadesinde “e” karakteri üç kez geçmesine rağmen bu karakterler aynen kaldı çünkü peşi sıra tekrar etmiyorlardı. Benzer şekilde burada tekrar eden sayılar olsaydı da aynı şey geçeli olacaktı. Deneme için echo komutunun sonuna 1111 şeklinde ekleyip, komutumuzu tekrar çalıştırabiliriz. Bakın tekrar eden rakamlar da dahil tüm tekrar eden karakterler -s seçeneğine verdiğimiz [:graph:] kalıbı sayesinde teke düşürülmüş oldu.

Yani bu örnek üzerinden de gördüğümüz gibi aslında spesifik olarak belirtmemiz gereken karakterler yoksa, tr —help komutunun çıktısında yer alan ifadeler ve kalıplar zaten pek çok tanımı karşılıyor. Örneğin yalnızca tekrar eden sayıları mı düzenlemek istiyorsunuz, bakın buradaki digit tanımı kullanılabilir. Hemen komutumuzdaki graph kalıbı yerine digit kalıbını ekleyip tekrar girelim.

Bakın digit kalıbı sayesinde yalnızca peş peşe tekrar eden sayılar teke indirilmiş oldu.

İşte sizler de gerektiğinde yardım sayfasından göz atıp, bu ifadeleri kolayca kullanabilirsiniz. 

Her neyse, neticede s seçeneğinin art arda tekrar eden karakterleri teke düşürdüğünü teyit etmiş olduk. 

### Karakterlerin Silinmesi

Ayrıca tabii ki tr aracını her zaman tekrar eden karakterleri sadeleştirmek veya mevcut bir karakteri bir diğeri ile değiştirmek için kullanmak istemeyebiliriz. Doğrudan karakteri bulup silmek için de tr aracını kullanmamız mümkün. Bunun için delete yani silme ifadesinin kısaltması olan d seçeneğini kullanabiliyoruz. Ben denemek için web adresindeki noktaları silmek istiyorum. Tek yapmam gereken tr aracının -d seçeneğini kullandıktan sonra silinmesini istediğim karakteri belirtmek.

```bash
taylan@virtualbox:~/arsiv$ echo "www.deneme...com" | tr -d "."
wwwdenemecom
```

Bakın gördüğünüz gibi yalnızca belirttiğim şekilde nokta karakterleri silinmiş. Bu şekilde metin içinde silinmesini istediğiniz tüm karakterleri belirtebiliyoruz. Fakat burada yazdığını karakterlerin yalnızca tek bir karakteri işaret ettiğini unutmayın lütfen. Yani örneğin ben aynı komutta -d seçeneğinden sonra “de” yazarsam, “d” ve “e” karakterinin hepsi bulunup silinecek. Yalnızca bütünleşik olan de kalıbını silmeyecek yani. Komutumuzu onaylayalım. 

```bash
taylan@virtualbox:~/arsiv$ echo "www.deneme...com" | tr -d "we"
.dnm...com
```

Bakın yazdığım tüm karakterler ayrı ayrı ele alındı ve eşleşen karakterler kaldırıldı. Yani doğrudan “de” ifadesini aranmadı, d ve e karakterleri ayrı ayrı aranıp bulunduğunda teker teker silindiler. tr aracının yalnızca birer karakter üzerinde çalıştığını şimdiye kadarki örneklerimiz üzerinde de tekrar tekrar gördük zaten. Yine de tr aracının bu şekilde çalıştığına dikkatinizi çekmek istediğim için ek olarak belirtmek istedim. Eğer bitişik yapıdaki birden fazla karakteri kapsayacak değişiklikler istiyorsanız ileride ele alacağımız sed veya awk gibi araçlardan yararlanabilirsiniz. tr aracı yalnızca bir karakter ile başka bir tanesini değiştirme silme veya tekrar edenleri sadeleştirmek gibi işler için kullanılıyor.

Ayrıca son olarak, biz tr aracının kullanım örneklerinde verileri hep pipe üzerinden tr aracına yönlendirdik. İstersek yönlendirme operatörü ile de tr aracının standart girdisine veri aktarabiliriz. Ben denemek için echo “www.deneme…com” >> site komutuyla dosyanın içerisine buradaki ifadeyi ekliyorum. Tamamdır. Şimdi tr aracına bu dosyayı girdi olarak yönlendirelim.

Ben peş peşe tekrar eden karakterlerin tr komutu ile teke düşürülmesi için yönlendirme operatörü ile dosyayı tr komutuna aktaracağım. Bunun için tr -s [:graph:] komutundan sonra tr aracının standart girdisine veri iletmek için < site şeklinde dosyasının ismini giriyorum.

```jsx
bubirosboxes@osboxes:~$ cat > site
www.deneme...com
osboxes@osboxes:~$ tr -s "[:graph:]" < site 
w.deneme.com
```

Bakın gördüğünüz gibi yönlendirmiş olduğumuz dosyadaki veri tr komutu tarafından okunup, filtrelenmiş oldu. Yani bizzat teyit ettiğimiz gibi tr komutunu yalnızca pipe ile kullanmak zorunda değiliz. tr aracı verilerini standart girdiden okuyor. Dolayısıyla standart girdisine verileri yönlendirdiğimiz sürece tr aracı ilgili verileri işleyip çıktıları standart çıktıya yani biz aksini belirtmediğimiz sürece konsolumuza yönlendiriyor olacak.

Eğer bu çıktıları bir dosyaya kaydetmek istersek örneğin aynı komutun sonuna > kaydet  şeklinde yazabiliriz. Bakın çıktılar kaydet isimli dosyaya yönlendirildiği için konsola herhangi bir çıktı bastırılmadı. Şimdi kaydet isimli dosyamızı okuyup kontrol edelim.

Bakın tr aracı tarafından işlenmiş çıktılar bizim burada kullandığımız yönlendirme operatörü sayesinde kaydet isimli dosyamıza sorunsuzca yönlendirilmiş.

Benim tr aracı hakkında bahsetmek istediklerim bu kadar. Aslında iki tr aracının -c ve -t kısaltmaları ile temsil edilen iki seçeneği daha bulunuyor ancak ben bu seçeneklerin işlevlerini öğrenmeyi meraklı ve araştırmacı olan arkadaşlara bırakıyorum.

sed ?

awk ?

# Konsol Üzerinde Okunaklı Çıktılar Elde Etmek

Şimdiye kadar nasıl dosya oluşturabileceğimizi, dosyaları nasıl okuyup, içeriklerini istediğimiz gibi değiştirebileceğimizi öğrendik. Şimdi de konsol üzerinden verileri okumak istediğimizde bizlere kolay okuma imkanı sunan araçlardan bahsedelim istiyorum. Komut satırı üzerinde çalışıyorken, araçların ürettiği çıktıları yine komut satırımız üzerinde yazılı şekilde takip ediyoruz. Fakat sizin de bildiğiniz gibi komut satırının da bir görüntüleme sınırı var. Eğer grafiksel arayüzdeki bir komut satırında çalışıyorsak, zaten terminal aracı çıktıların konsola sığmayan kadarını görebilmemizi sağlayan kaydırma çubuğu gibi özellikler sunuyor. Yani örneğin ben konsol aracını pencereli şekilde kullanıyorsam ve bu şekilde küçük bir pencere ise, cat /etc/passwd komutu ile uzun içeriğe sahip dosyamı okurken tüm çıktılar bu konsolun görünen kısmına sığmayacak. Hemen denemek için komutumuzu girelim. Bakın şu anda yalnız dosya içeriğinin sonunu görebiliyorum. Önceki çıktıları ulaşmak için buradaki çubuğu kullanarak yukarı doğru kaydırabilirim. Ayrıca bakın uzun veriler barındıran satırların da zaten otomatik olarak pencere boyutuna göre kırpılıp alt satırdan devam ettirildiğini de görebiliyoruz. Eğer pencere boyutunu büyütecek olursak, bu çıktıların da büyüklüğe göre hizalandığını görebiliyoruz. İşte bizzat test ettiğimiz gibi grafiksel arayüzdeki bu konsol aracımız, çıktıların tamamını bu pencere içerisinde tek seferde gösteremiyor olsa da, tamamını görebilmemiz için bize birkaç kolaylık sağlıyor. Fakat komut satırı arayüzündeki tty konsollarında çalışırken, önceki çıktılara dönme gibi bir imkanımız olmuyor. Dolayısıyla uzun çıktılar üreten araçların tüm çıktılarını yalnız komut satırı arayüzünün bulunduğu tty konsollarında tam şekilde görüntüleyemiyoruz. 

Denemek için komut satırı arayüzüne geçiş yapıp, burada oturumumuzu açalım. Tamamdır. Şimdi test etmek için ben bu kez daha önce oluşturmuş olduğum uzun isim listesini okumak üzere cat isimler.txt komutunu girmek istiyorum. Bakın yine ekrana sığmadığı için çıktıların yalnızca bir kısmını alabildik. Önceki çıktıları görmek için faremizin sroll tuşu ile yukarı kaydırmayı deneyebiliriz. Fakat gördüğünüz  gibi herhangi bir reaksiyon alamıyoruz çünkü komut satırı arayüzdeki bu tty konsolları üzerinde bu işlev sağlanmıyor. 

İşte bu duruma çözüm olarak araçların çıktılarını bize parça parça sunabilecek ek araçlara ihtiyacımız var. Ben de anlatımın devamında bize bu imkanı tanıyan more less head ve tail araçlarından bahsedip, komut satırı arayüzündeki hakimiyetimizi arttırmak istiyorum.

## more Komutu

more aracı, kendisine yönlendirilmiş olan verilerin en başından itibaren ekrana sığan kadarlık kısmını sırasıyla parça parça bize sunuyor. Örneğin bir dosya içeriğinin ilk 10 satırı ekranımıza sığıyorsa, ilk olarak 10 satırı daha sonra bir sonraki 10 satırı ve bir sonraki 10 satırı gösterecek şekilde tüm içerik bitene kadar baştan sonra tüm verileri parça parça bize sunuyor.

Zaten more ismi de buradan geliyor. Biz istedikçe verilerin geri kalanını yani daha fazlasını bize parça parça sunduğu için more ismi verilmiş. 

Ben örnek olması için /etc dizinin içeriğini listeleyip, tüm listeye parça parça bakmak istiyorum. Örneğin ls -l /etc şeklinde komutumu girdiğimde bakın, çıktıların tamamını göremiyorum çünkü epey bir içerik listeleniyor. Bu sorunu çözmek içim bu çıktıları pipe ile more aracına yönlendirip çıktılara parça parça bakabiliriz. Ben pipe dan sonra more komutunu da ekliyorum. Bakın bu kez, içerik listesinin en başından itibaren yalnızca ekranıma sığan kadarlık kısmını görüyorum ve altta “more”  ifadesi var. Bu ifade, ileride daha fazla verinin olduğuna işaret ediyor. Eğer bir satır sonrasını görmek istersem enter ile satır satır daha fazla içeriğe ulaşabilirim. Bakın ben enter a bastıkça yeni satırlarda sonraki veriler gözüküyor. Eğer satır satır değil de, doğrudan ekranıma sığacak kadarlık yeni içerikleri görmek istersem de doğrudan space tuşunu kullanabilirim. Bakın ekranıma sığacak kadar yeni veriler karşıma getirildi. Üstelik bakın hala veriler olduğu için more ifadesi gözükmeye devam ediyor.  Ben yine space ile ekranıma sığacak kadar sayfa sayfa yeni çıktıları görüntülüyorum ve en nihayetinde tüm veriler bittiğinde more ifadesi kaybolup, tekrar komut girebileceğim promt satırına ulaşıyorum.

Gördüğünüz gibi tamamı konsol ekranımıza sığmayacak kadar olan tüm verileri, more aracına yönlendirip, bu araç vasıtasıyla ekranımıza sığan kadarlık kısmını parça parça veya satır satır ileriye doğru görüntüleyebiliyoruz. Fark ettiyseniz özellikle ileriye doğru dedim çünkü more aracı önceki çıktılara dönmemizi sağlamıyor. Tek yönlü şekilde yani hep daha fazlası için en baştan en sona doğru verileri görüntüleyebiliyoruz. Örneğin space ile geçtiğiniz önceki parçaya dönmek isterseniz bu more aracı ile mümkün değil. Bu duruma çözüm olarak bir sonraki derste ele alacağımız less aracı var. Fakat bu araca geçmeden önce more aracının dosyalar üzerinde de kullanılabileceğini belirtmek istiyorum. Ben denemek için more komutundan sonra içeriğini görmek istediğim isimler.txt dosyasını yazıyorum. Bakın ekranımıza sığan kadarlık kısmı bastırıldı. Hatta alt tarafta dosya içeriğin yüzdelik olarak ne kadarlık kısmının görüntülendiği de belirtiliyor. Enter ile satır satır ilerledikçe de buradaki yüzde artıyor çünkü dosya içeriğinin daha fazlasını görüntülüyoruz. En nihayetinde dosyanın sonuna geldiğimizde de görüntüleme işlemi sonlanıyor.

Yani bizzat test ettiğimiz gibi more aracı standart girdiden veri almasına ek olarak, kendisine argüman olarak verilmiş olan dosya içeriğini de parça parça konsol üzerinden görüntüleyebilmemize olanak tanıyor.

Hatta dilersek more aracı ile birden fazla dosyayı da aynı anda açıp okuyabiliriz. Ben denemek için son komutumu çağırıp sonuma bir de /etc/passwd dosyasını da okumasını söylüyorum. Bakın satırın en başında şu anda hangi dosyanın içeriğinin görüntülendiği belirtiliyor. Space ile devam edelim. isimler.txt dosyasının sonuna geldik. Eğer devam edecek olursak, sıradaki dosyanın /etc/passwd dosyası olacağı da burada açıkça belirtiliyor. Ben devam ediyorum. Bakın satırın en başında, hangi dosya içeriğini görüntülendiği yazıyor. Yani böylelikle more aracı ile birden fazla dosyanın içeriğini peşi sıra parça parça konsolumuz üzerinden görüntüleyebileceğimizi de deneyimlemiş olduk.

Ayrıca eğer more aracını kullanırken içeriğin sonuna gelmeyi beklemeden aracı sonlandırmak isterseniz q tuşuna basmanız yeterli. Bakın ben dosyanın geri kalanını okumadan yalnızca q tuşuna bastığım için more aracı kapandı ve komut girebileceğim promt satırına geri döndüm. 

# less Komutu

more aracının verileri yalnızca ileriye doğru bastırdığını gördük. Yani more aracı ile önceden görüntülediğimiz verilere dönmemiz mümkün olmuyor. Bu duruma çözüm olarak more ile benzer işlevi olan ancak geriye dönme özelliğini de destekleyen less aracını kullanabiliyoruz.

More aracının çıktılarda geriye doğru kaydırma yapamamasından bıkan başka bir geliştirici "az çoktan fazladır" a atıfta bulunarak less aracını geliştirmiştir. 

less komutu more komutundan farklı olarak dosya içeriğinde aşağı yukarı, sağa ve sola doğru kaydırma hareketlerine imkan tanıyor. 

Test etmek için yine etc dizinini listeleyip çıktıları less aracına yönlendirebiliriz. Bakın yine ekranımıza sığacak kadarlık kısım karşıma geldi. Devamında veri olduğunu buradaki iki nokta üst üste karakterinden anlayabiliyorum. 

Eğer bir satır aşağı inmek istersem klavyemdeki aşağı yön tuşunu kullanabilirim. Benzer şekilde bir üst satıra çıkmak için de klavyemdeki yukarı yön tuşunu kullanmam yeterli. Ayrıca more komutunda olduğu şekilde enter ile de bir satır aşağı inip, space ile birer sayfa ileriye atlayabiliyoruz. 

Space tuşu haricinde bir sayfa ileri gitmek için forward yani ileri ifadesinin kısaltması olan f tuşunu da kullanabiliyoruz. Bir sayfa geri gelmek için de backward yani geriye ifadesinin kısaltması olan b tuşunu kullanabiliyoruz. Okuma işimiz bittiğinde aracı kapatmak için q tuşuna basmamız yeterli. Bakın aracım kapandı ve normal komut satırına geri döndüm.

Ben yalnızca standart girdideki verileri less aracına aktardım ancak tabii ki less aracı ile dosya içeriklerini de görüntüleyebiliyoruz. Okumak istediğiniz dosyaların isimlerini less aracına argüman olarak vermeniz yeterli. Ben denemek için less /etc/passwd komutu ile dosyamı okumak istiyorum.

Bakın şu anda görüntülediğim dosyanın ismi burada yazıyor. Ayrıca less aracıyla, satırların geri kalanını okumak için sağ sol yön tuşlarını da kullanabiliyoruz. More aracında bu şekilde satırları geniş biçimde görüntüleyip, kaydırma hareketi yapamıyoruz. Less aracı her yönde daha esnek bir kullanım sağlıyor.

Ayrıca şimdiye kadar ele aldığımız temel kullanım özelliklerine ek olarak aslında less aracının pek çok ekstra özelliği mevcut. Bunları görmek için less —help komutunu girebiliriz. Bakın burada yön tuşlarına ek olarak arama yapma, dosyalar arasında geçiş yapma ve benzer pek çok özelliğin açıklaması bulunuyor. Birçok özelliği olmasına karşın biz yine de temelde aşağı yukarı hareket ederek dosya içeriğini görüntülemek için kullanacağımız için bu kadarlık bilgi bence yeterli. Yine de arama yapma ve dosyalar arasında geçişten de çok kısaca bahsetmek istiyorum. Bunun için tekrar less aracı ile dosya okumayı deneyebiliriz. Ben bu kez iki tane dosyayı okumak üzere less /etc/passwd /etc/group komutunu giriyorum. Bakın ilk yazdığım passwd dosyasının açıldığı aşağıda belirtiliyor. Örneğin ben şu an görüntülenmekte olan bölümden sonraki içeriklerde araştırma yapmak istiyorsam, slash işareti koyup araştırmak istediğim ifadeyi yazabilirim. Ben kali ifadesini araştırmak istiyorum. Bakın içeriğin devamında kali ifadesi geçtiği için eşleşen yere atladım ve bu eşleşme de aydınlatılmış şekilde belirtiliyor. Benzer şekilde eğer mevcut bulunduğum konumdan geriye doğru araştırma yapmak istersem de soru işaretinden sonra araştırmak istediğim ifadeyi yazmam gerekiyor. Ben root şeklinde aratıyorum. Bakın üstteki içeriklerden root ifadesi ile eşleşen yere atamış oldum. Eğer aramayı sürdürmek istersem küçük N karakteri ile geriye doğru gidebilirim. Ya da bir önceki araştırmaya dönmek için de büyük N karakterini kullanabilirim. Bakın önceki ve sonraki eşleşmeler arasında küçük ve büyük N karakteri sayesinde geçiş yapabiliyorum. Bu hızlı geçiş yöntemini hem ileri hem de geriye dönük araştırma yaparken kullanabiliyoruz. 

Bunun dışında şu anda passwd dosyasını okuduğumuzu biliyorsunuz. Dosyasının sonuna geldiğimizde, more aracında olduğu gibi bir sonraki dosyaya geçişmiyor. Geçiş için iki nokta üst üste karakterini girip daha sonra next yani sonraki ifadesinin kısaltmasından gelen n tuşuna basmamız gerekiyor Bakın bir sonraki dosya olan group dosyasına geçtim. Eğer bir önce dosyaya dönmek istersem de aynı şekilde iki nokta üst üste karakterini oluşturduktan sonra p tuşuna basmam yeterli. Bakın şimdi de önceki dosyaya dönmüş oldum.

Bence less aracı hakkında bu kadarlık bilgi yeterli.  Daha fazlasını öğrenmek veya unuttuğunuzda hatırlamak için less —help komutunu kullanıp less aracının yardım sayfasından faydalanabilirsiniz.

# head Komutu

İsminin de çağrışım yaptığı gibi head komutu kendisine yönlendirilen içeriğin başından itibaren okunabilmesini sağlıyor. Herhangi bir seçenek belirtmediğimizde head aracı ilk 10 satırı konsola bastırıyor. Ben denemek için head /etc/passwd komutu ile dosyamı okumak istiyorum. Bakın 

Dosya içeriğinin yalnızca ilk 10 satırı bastırılmış oldu.

Birden fazla dosya okunmasını da sağlayabiliriz. Eğer aynı anda birden fazla dosya okunuyorsa her bir dosyanın ilk 10 satırını bastırıyor. Hemen deneyelim. Ben en son girmiş olduğum komutu çağırıp /etc/group dosyasını da argüman olarak veriyorum.

Bakın en başta hangi dosya olduğunu da açıkça belirtilerek her iki dosyanın da ilk 10'ar satırı bastırılmış.  

Bu temel kullanım dışında eğer kaç satır bastırılmasını gerektiğini belirtmek istiyorsak, -n seçeneğinin ardından kaç satır basılacağını da yazabiliyor. Ben denemek için dosyanın ilk 5 satırını bastırmak üzere head -n 5 dosya_adı şeklinde komutumu giriyorum. Bakın dosyamın yalnızca ilk 5 satırı bastırıldı. Ayrıca bu kullanım dışında doğrudan head -5 dosya_adı komutu ile de aynı şekilde ilk 5 satırın bastırılmasını sağlayabiliyorum. Yani bakın, n seçeneği olmadan doğrudan tire işaretinden sonra kaç satır bastırılmasını gerektiğini de bu şekilde belirtebiliyoruz. Aynı çıktıyı aldık.

Tahmin ettiğiniz gibi tabii ki yalnızca dosyalar üzerinde çalışmak zorunda da değiliz. Örneğin ls -l /etc komutunu çıktılarını pipe ile head aracına yönlendirip ilk 10 satırın bastırılmasını sağlayabiliriz. Bakın yalnızca 10 satırı bastırıldı. Mesela bastırılan satır sayısını teyit etmek için pipe ile nl aracını da kullanabiliriz. Bakın ls komutunun çıktıları head aracına iletildi ve 10 satırla sınırlandıktan sonra bu çıktılar nl aracı sayesine numaralandırılmış oldu.

Ayrıca head aracının başka seçenekleri de var fakat diğer seçeneklerine neredeyse hiç ihtiyaç duymayacağınız için bahsetmiyorum. Merak ediyorsanız, head —help komutunu kullanabilirsiniz.

# tail Komutu

Tail ifadesi türkçe kuyruk anlamına geliyor. İsminden de kolayca anlaşılabileceği gibi tail komutu dosyaların sondaki satırlarının bastırılmasını sağlıyor. Yani tail aracını head aracının tersten çalışan versiyonu olarak düşünebilirsiniz. tail, ekstra bir seçenek kullanılmadığında varsayılan olarak ilgili dosyanın sondan 10 satırını bastırıyor. Hemen denemek için /etc/passwd dosyasını okumayı deneyelim.

Bakın dosya içeriğinin sondan 10 satırı bastırıldı. Dilersek kaç satır bastırılacağını -n seçeneğinin ardından belirtmemiz de mümkün. Ben son 6 satırı bastırmak için tail -n 6 /etc/passwd şeklinde komutumu giriyorum.

Bakın yalnızca sondan 6 satır bastırılmış. 

Ayrıca tıpkı head komutunda olduğu gibi elbette birden fazla dosyayı da aynı anda açabiliriz. Ben passwd ve group dosyalarının sondan 3 satırını bastırmak için tail -n 3 /etc/passwd /etc/group komutunu giriyorum. Bakın sırasıyla her iki dosyanın da sondan 3 er satırı bastırıldı.

Dosya içeriklerinin okunması yerine standart girdiden alınan verilerin kullanılması da mümkün. Ben ls /etc/ komutu ile dizin içeriğinin listelenip, pipe ile bu çıktıların tail aracına aktarılmasını istiyorum.

Bakın bu sayede gördüğünüz gibi etc dizin içeriğinin sondan 10 satırı konsola bastırılmış oldu.

Bu basit kullanımlar dışında, tail aracının -f seçeneği sayesinde sürekli güncellenen verilerin takip etmemiz de mümkün oluyor. Bu -f seçeneği, özellikle log dosyalarındaki en son değişikliklerin takibi için sıklıkla kullanıyor. Ben test etmek için yeni bir konsol açıyorum. Bu konsoldayken cat > yeni.txt komutunu giriyorum şimdilik dosyaya herhangi bir veri eklemeyeceğim. Önceki konsola geçip tail -f yeni.txt komutunu girelim. Konsolları yan yana getirip, değişimi daha rahat gözlemeyebiliriz. Şimdi ben cat komutunu girdiğim konsola dönüp merhabalar yazıp enter ile bir alt satıra iniyorum. Bakın anında tail -f komutunu yazdığım çıktıyı okuyup konsola bastırdı. Neticede bizzat teyit ettiğimiz şekilde okunan dosyadaki tüm yeni veri girdileri, tail -f komutu sayesinde anlık olarak konsola bastıracak. Yeni veri girmeye devam edebiliriz.

Bakın ne kadar yeni veri girersem, tail -f komutu o kadar veriyi bastırıyor. Bu komut özellikle log dosyalarını okumak için kullanıyor zaten. 

İleride log kayıtları ile uğraşırken tail -f komutunu sizler de sıklıkla kullanıyor olacaksınız. Eğer bu tail komutunun f seçeneğini kullanmazsak, dosyalardaki en son değişiklikler yerine yalnızca o dosyayı açtığımız andaki verilere ulaşabiliyoruz. tail -f komutu anlık olarak dosya içeriğindeki verileri takip etmemizi sağlıyor. Ayrıca bakın bu şekilde sürekli yeni veri var mı diye beklendiği için aracı kapatmak için ctrl c ile durdurmamız gerekiyor. Bakın ctrl c yaptığım için promt satırına dönmüş oldum.

Böylelikle temel olarak tail aracının işlevinden ve kullanımından da haberdar olduk. Tabii diğer seçenekleri için yardım sayfalarına göz atabilirsiniz.

Ayrıca ben özellikle ele almadım ancak pipe mekanizmasının da yardımıyla ihtiyacınıza yönelik olarak bu bölümde öğrenmiş olduğunu uygun yapıdaki tüm araçları birbirine bağlayarak çalıştırabileceğinizi zaten biliyorsunuz. Ben yalnızca araçların temel kullanımlardan bahsettiğim için özellikle birden fazla aracın birlikte kullanıldığı farklı durumlara örnekler verme fırsatım olmadı ama siz kendiniz pratikler yaparak deneyimleyebilirsiniz. Mesela ben basit bir örnek olarak yine tail -f yeni.txt | nl komutuya dosyamı anlık olarak okuyup satırları numaralandırmak istiyorum. Şimdi diğer konsola geçip yeni veriler eklemeye devam edebiliriz. Bakın eklemiş olduğum her satır, burada anlık olarak numaralandırılmış şekilde yazıyor. İşte bu ve bunun gibi ihtiyacınıza yönelik çözümler için pipe ile tüm araçları birbirine bağlayarak çalıştırabilirsiniz.

# Dosya Kopyalama - Taşıma - Silme İşlemleri

Şimdiye kadar dosya oluşturma ve düzenlemeye dair pek çok araçtan söz etmiş olduk. Anlatımın devamında dosyalarla ilgili birkaç ayrıntıdan daha bahsediyor olacağız. Fakat diğer ayrıntılardan bahsetmeden önce belki de en temel işlevler olan kopyalama taşıma ve silme işlevlerini yerine getirebileceğimiz araçlarından bahsetmeden istiyorum.

# cp Komutu

Komut satırı üzerinden dosya veya dizinleri kopyalamak istediğimizde cp aracını kullanabiliyoruz. Zaten cp aracının ismi de, copy yani kopyalama ifadesinin kısaltmasından geliyor. Aracın kullanımı çok kolay.

Ben denemek için öncelikle “orijinal” isminde bir dosya oluşturup, içerisine "ben dosyayım" yazıp kaydediyorum. Bakın dosyam sorunsuzca kaydedildi. 

Eğer bu dosyayı bulunduğum dizine farklı bir isimle kopyalamak istersem cp orijinal dosya dosyanın_kopyası şeklinde komut girebilirim. Dosyaları listeleyelim bakın orijinal dosya ve onun kopyası listede bulunuyor. Her iki dosyayı da cat komutu ile okumamak için yan yan isimlerini girelim. Bakın orijinal dosya ile kopyalamış olduğum dosyanın içeriği birebir aynı. Tek fark kopyalanırken oluşturulan dosya isminin benim istediğim şekilde olması. cp komutunun en temel kullanımı bu şekilde. 

Eğer mevcut bulunduğumuz dizine değil de istediğimiz farklı bir dizine dosya veya dizin kopyalamak istersek tek yapmamız gereken kopyanın tam olarak hangi dizine hangi isimle kaydolacağını belirtmek. Ben orijinal dosyasını, kendi ev dizinimdeki Documents klasörünün altına aynı isimde kopyalamak istiyorum. Bunun için cp orijinal ~/Documents şeklinde yazıyorum. Bakın burada ilk olarak orijinal dosyanın yani kopyalanacak dosyanın ismini girip, daha sonra kopyanın tam olarak nereye kaydolması gerektiğini belirtebiliyoruz. Burada klasör isminden sonra özellikle bir dosya ismi belirtmediğim için orijinal dosyanın ismi de birebir kopyalanıp bu dizine kaydolmuş olacak. Komutumuzu onaylayıp sonuç üzerine konuşalım. Teyit etmek için cat ~/Documents/orijinal komutu ile kopya dosyanın içeriğini okumayı deneyebiliriz. Ayrıca ls ~/Documents/ komutu ile klasörün içeriğini de listeleyebilirim. Neticede bakın dosyamın aynı isimle, benim hedef gösterdiğim dizine kaydedilmiş olduğunu buradaki çıktılardan kesin olarak görebiliyoruz. Eğer dosyayı farklı bir isimle kopyalamak isteseydim, dizin adresinden sonra dosyanın ismini belirtebilirdim. Örneğin cp orijinal ~/Documents/kopya şeklinde komut girebilirim. Yine cat komutunu kullanarak dosyamın istediğim isimle kopyalanmış olduğunu teyit edebilirim. Bakın istediğim dizine tam olarak istediğim isimde dosyamı sorunsuzca kopyalayabildim. Tabi ki ben yalnızca mevcut bulunduğum dizindeki bir dosyayı başka bir dizine kopyalamak üzere örnekler gösterdim ama yetkiniz olduğu sürece istediğiniz dizindeki dosyayı istediğiniz başka bir konuma kopyalayabilirsiniz. Örneğin ben cp ~/Documents/orijinal  /tmp/ komutu ile Documents dizini altındaki orijinal isimli dosyayı /tmp dizini altında kopyalayabilirim. cat /tmp/orjinal komutu ile kontrol edelim, bakın dosyam sorunsuzca kopyalanmış. 

Ayrıca ben hep tek bir dosayı kopyalamayı ele aldım ama aslında birden fazla dosyayı da aynı anda kopyalayabiliriz. Örnek olması için öncelikle `touch a b c d` komutu ile a b c ve d isimli dosyalar oluşturmak istiyorum. Tamamdır. Şimdi bu dosyalarımı tek seferde Document klasörüne kopyalamak istersem komutumu `cp a b c d ~/Documents/` şeklinde girmem yeterli. `ls ~/Documents/` komutu ile dizin içeriğini kontrol edelim. Bakın tek seferde birden fazla dosyamızı istediğimiz dizine kopyalamayı başarmışız.

Bu çoklu kopyalama işleminden sonra muhtemelen cp aracının girdiğimiz argümanlardan hangilerinin kopyalanacak dosyalar, hangisinin dosyaların kopyalanacağı dizin olduğunu nasıl anladığını merak etmiş olabilirsiniz. Aslında çok basit, birden fazla dosya ismi belirtildiği durumda en sondaki argümanın bu dosyaların kopyalanacağı adres olması zorunlu. Yani cp aracı bu beklenti ile komutumuzu okuyor. Dolayısıyla girdiğimiz komuttaki en son argüman cp aracı için, bu argümandan önceki tüm dosyaların kopyalanacağı dizini temsil ediyor.

Neticede birden fazla dosyamızı tek seferde başarılı şekilde kopyalamayı başardık. Bu harika fakat bazen kopyalama işlemini kontrollü şekilde gerçekleştirmek de isteyebiliriz. Çünkü özellikle çoklu şekilde dosyaları bir yerden başka bir yere kopyalarken, hedef gösterdiğimiz dizinde bizim kopyaladığımı dosyaları ile aynı isimde dosyalar bulunabiliyor. Eğer özellikle önlem almazsak, kopyalama emri verdiğimiz için kopyaladığımız dosyalar aynı isimli dosyaların üzerine yazılıyor. Yani ilgili dizindeki aynı isimli dosyaların içerikleri tahrip ediliyor. Dediğim gibi özellikle çoklu şekilde dosyaları kopyalarken bu durumun farkında olamayabiliyoruz. Bu duruma çözüm olarak, üzerine yazılma durumu varsa cp aracının bizi uyarıp bizden izin istemesini talep edebiliriz. Bunun için -i seçeneğini kullanmamız yeterli.

Örneğin daha önce Documents dizinine kopyaladığım dosyalar ile aynı isimli yeni dosyaları yine aynı dizine kopyalamak istersem, yeni kopyalanan dosyalar eskilerinin üzerine yazılacak. Denemek için ben öncelikle cat > yeni-dosya komutu ile yeni bir dosya oluşturup içerisine de “bu bir dosyadır” yazıp ctrl d ile dosyamı kaydediliyorum. Şimdi cp -i a b c yeni-dosya şeklinde komutumuzu girelim. Bakın hedef gösterdiğimiz dizinde a dosyası ile aynı isimde dosya bulunduğu için üzerine yazmaya karşı cp aracı bizi uyarıyor. Eğer üzerine yazma işlemini onaylamak istiyorsak y yazıp enter ile devam edebiliyor ya da reddetmek için n ile üzerine yazmayı iptal edebiliriz. Bakın sırasıyla Documents dizininde aynı isimde bulunan a b ve c dosyaları için tek tek bu sorular bana soruldu, ama bu dizinde bulunmayan yeni-dosya isimli dosya için böyle bir soru sorulmadı. Çünkü bu isimde daha önce bir dosya yoktu, dolayısıyla üzerine yazma gibi işlem hakkında da uyarıya gerek kalmadı.

Dediğim gibi özellikle çoklu şekilde dosyaları kopyalarken, olası üzerine yazma risklerine karşı tek tek bize sorulmasını istersek i seçeneğini kullanabiliyoruz. Aslında bu seçeneğin dışında topluca tüm üzerine yazma işlemlerini reddeden -n seçeneği de bulunuyor. Ancak biz kimi zaman bazı dosyaların üzerine yazılmasını, bazılarının da üzerine yazılmamasını isteyebiliriz. Bu durumda -i seçeneğini kullanarak tek tek seçim yapmak mantıklı. Eğer tek tek seçim yerine toptan tüm üzerine yazma işlemlerinden korunmak isterseniz komutunuza -n seçeneğini de ekleyebilirsiniz.

Denemek için içerisinde veri bulunan yeni-dosya isimli dosyayı tekrar aynı konuma kopyalamayı deneyebiliriz. Öncelikle Documents dizini altındaki dosyanın içeriğini görmek için cat ~/Documents/yeni-dosya komutu ile dosyanın içeriğini konsola bastıralım. Bakın dosyada “bu bir dosyadır” yazıyor. Şimdi cat > yeni-dosya komutunu girip “test test” ifadesini yazalım ve ctlr d ile dosyayı kaydedlim. 

Eğer ben bu dosyayı tekrar documents dizinine kopyalarsam, documents dizinindeki aynı isimli dosyanın üzerine yazılacak yani o dosyadaki veriler silinmiş olacak. Bu durumu önlemek için -n seçeneğini kullanabiliriz. Komutumuzu öncelikle -n seçeneği ile kullanalım daha sonra -n seçeneği olmadan kullandığımızda ne olacağını da bakarız. Ben cp -n yeni-dosya ~/Documents/ komutu ile dosyamı kopyalamak üzere komutumu giriyorum. Herhangi bir çıktı almadık. Şimdi cat ~/Documents/yeni-dosya komutu ile ilgili dosyanın içeriğini kontrol edelim. Bakın dosyanın içeriğinde herhangi bir değişiklik olmamış. Şimdi bir de -n seçeneği olmadan komutumuzu girelim. Yani aynı isimli dosyanın üzerine yazılmasına izin verelim. Tamamdır. Şimdi cat komutu ile tekrar dosyamızı okuyup kontrol edebiliriz. Bakın -n seçeneği olmadığı için yani üzerine yazma işlemi otomatik olarak reddedilmediği için aynı isimli dosyanın üzerine yazılmış.

İşte bizzat teyit ettiğimiz gibi üzerine kopyalama sonucu ortaya çıkan dosyaların, hedef dizindeki dosyaların üzerine yazılma ihtimallerini önlemek için -n seçeneği kullanabiliyoruz. Özellikle toplu şekilde dosyaları taşırken, hedef dizinde mevcut bulunan aynı isimli dosyaların üzerine yazmaktan otomatik olarak kaçınmak için -n seçeneği büyük kolaylık sağlıyor. Eğer tek tek seçim yapıp hangisinin üzerine yazılıp hangisinin yazılmayacağına karar vermek istiyorsanız -i seçeneğini de kullanabileceğinizi zaten biliyorsunuz.

Şimdiye kadar hep dosyalar üzerinde çalıştık ancak dilersek dizinleri de kopyalayabiliyoruz. Fakat dizinler kendi içlerinde alt dizinler ve dosyalar barındırabileceği için bir dizini kopyalarken alt dizinlerin de kopyalanması için recursive yani özyinelemeli kopyalama seçeneğini de komutumuzu eklememiz gerekiyor. Buradaki özyineleme ifadesi, dizin altındaki tüm alt dizinlere teker teker bakıp, tüm dosya ve klasörlerin otomatik olarak seçilip kopyalanabilmesini sağlıyor. Zaten linux üzerinde dizinlerle çalışırken içi dolu olan dizinler üzerinde işlem yapmak için istisnalar hariç hep recursive yani özyineleme seçeneğini özellikle aktifleştirmemiz gerekiyor. Şimdiye kadar bu durumu zaten bizzat tekrar tekrar deneyimledik. Şimdi tekrar cp aracına dönecek olursak, öncelikle herhangi bir seçenek belirtmeden bir dizini kopyalamayı deneyebiliriz. Ben denemek için kendi ev dizinimdeki masaüstü dizinini yine ev dizinim altındaki documents klasörünün içine kopyalamak istiyorum. Bunun için cp ~/Desktop ~/Documents/ şeklinde komutumu girmeyi deneyebilirim.

Bakın komut hata verdi ve hata çıktısında -r seçeneğini kullanmadığım için Desktop dizinin kopyalanamadığı belirtilmiş. Şimdi aynı komutumuzu çağırıp bu kez -r seçeneğini de ekleyip tekrar deneyelim.

Herhangi bir hata almadık. Kopyalama işlemini teyit etmek için ls ~/Documents/Desktop/ şeklinde komutumuzu da girelim. Bakın Desktop dizinin tüm içeriği olduğu gibi Documents dizini altına kopyalanmış. Hatta emin olmak istersek ls ~/Desktop/ komutunun çıktıları ile de kıyaslayabiliriz. Bakın birebir aynı içerikler kopyalanmış. Bizzat gördüğünüz gibi recursive yani özyineleme seçeneği, dizinlerin tüm içerikleriyle birlikte taşınması için şart.

Hazır dizin kopyalama işleminden bahsetmişken isteyebileceğiniz bir diğer duruma da değinmek istiyorum. Bazen kopyaladığımız dizinin ana klasörü hariç yalnızca dizin içerisindeki dosya ve klasörleri kopyalamak isteyebiliyoruz. Yani örneğin ben yalnızca Desktop klasörünün içindekileri kopyalayıp Desktop klasörünü hariç tutmak isteyebilirim. Bunun için büyük T seçeneğini kullanmamız yeterli. Tabii ki yine tüm alt dizin içeriklerini kopyalayacağımız için recursive seçeneği de dahil ederek komut girmemiz gerekiyor. Ben denemek için yalnızca masaüstü dizindeki içerikleri Pictures klasörüne kopyalamak istiyorum. Bunun için cp -rT ~/Desktop ~/Pictures şeklinde komutumuzu girebiliriz. Tamamdır şimdi ls ~/Pictures komutu ile dizin içeriğini listeleyelim. Bakın Desktop klasörü bulunmuyor ancak Desktop klasörünün içeriği buraya kopyalanmış durumda. Bu yaklaşıma ihtiyacınız olursa, büyük T seçeneğini doğrudan hatırlamasanız bile cp —help komutu ile yardım bilgilerini listeleyip, listenden bu seçeneğe bakarak kolaylıkla hatırlayabilirsiniz.

Ayrıca yardım çıktılarından da görebildiğiniz gibi, cp aracının benim ele almadığım daha pek çok özelliği bulunuyor. Benim bahsettiklerim en temel kullanım için bilmemiz gerekenler. Geri kalan seçenekler için yardım sayfasına göz atabilirsiniz. 

# mv Komutu

Dosya veya dizinleri kopyalamak yerine taşımak yani yerini değiştirmek istediğimizde ingilizce move yani taşıma ifadesinin kısaltmasından gelen mv aracını kullanabiliyoruz. mv aracının kullanımı da tıpkı cp aracı gibi oldukça kolay. Zaten her iki aracın da hemen hemen pek çok seçeneği ortak kısaltmalar ile tanımlandığı için rahatlıkla kullanabiliyoruz. Gelin örnekler üzerinden temel kullanımını ele alalım.

Taşımak istediğimiz dosyayı mv dosya_adı tanışanacağı_yeni_konum şeklinde belirtmemiz yeterli oluyor. Ben örnek olarak kullanabilmek için touch tasinacak komutu ile  “tasinacak” isimli bir dosya oluşturmak istiyorum. Ayrıca klasör taşımayı da ele alacağımız için mkdir tasinacak-klasor komutu ile yeni bir klasör oluşturalım. Bakın dosya ve klasör oluşturuldu. Şimdi ben yeni oluşturduğum bu dosyayı, yeni oluşturduğum klasörün içine taşımak istiyorum.  Bunun için `mv tasinacak tasinacak-klasor` şeklinde komutumu girebilirim. Tamamdır, dosyamın şimdi taşınmış olması gerekiyor. Teyit etmek için öncelikle mevcut dizinimizi tekrar ls komutu ile listeleyebiliriz. Bakın tasinacak isimli bir dosya yok. Şimdi bir de klasörün içeriğini listelemek için ls tasinacak-klasor şeklinde komutumuzu girelim. Bakın dosyam tam da benim istediğim gibi bu klasöre taşınmış. 

Dosya yerine dilersek aynı şekilde klasörleri de taşıyabiliriz. Klasör taşırken içerisinin dolu olup olmaması önemli değil. Tek yapmamız gereken, hangi klasörü nereye taşıyacağımızı belirtmek. Ben örnek olması için bu yeni oluşturduğum ve içinde dosya bulunan tasinacak-klasor isimli klasörünü masaüstüne taşımak istiyorum. Bunun için mv tasinacak-klasor ~/Desktop şeklinde komut girmem yeterli. ls komutu ile mevcut dizini listeleyelim. Bakın bu klasör artık burada değil. Bir de ls ~/Desktop komutu ile masaüstü dizinini listeleyelim. Gördüğünüz gibi ls komutunun neticesinde klasörün sorunsuzca taşındığını teyit edebiliyoruz. 

Benzer şekilde istersek aynı anda birden fazla klasörü veya dosyayı da taşıyabiliriz. Ben denemek için birkaç tane yeni dosya ve klasör oluşturmak istiyorum. Daha önceden a b c d dosyaları mevcuttu birde birkaç tane klasör oluşturalım. Tamamdır. Şimdi test etmek için yine masaüstündeki tasinacak-klasör isimli klasöre bu dosya ve klasörlerin hepsinin aynı anda taşınması için komutumuzu girmeyi deneyelim. Bunun için tek yapmamız gereken taşınacak dosya ve klasörlerin isimlerini yazıp, son olarak hangi dizine taşınacağını belirtmek. Komutumuzu onaylayalım. Şimdi ls ile mevcut dizinimizi listeleyecek olursak, bakın ilgili dosya ve klasörler burada gözükmüyor. Bir de taşıdığımız dizinine bakalım. Bakın görebildiğiniz gibi dosya ve klasörlerimi kolayca tek seferde istediğim dizine taşımış oldum. İşte mv aracının kullanımı bu kadar kolay.

Ben örnekler sırasında dosya veya klasörlerin isimlerini değiştirmek istemediğim için yalnızca taşınacakları adresleri belirttim. Bunun yerine taşındıkları konumda hangi isimle kaydedilmeleri gerektiğini de spesifik olarak belirtebiliyoruz aslında. Örnek olması için touch test komutu ile test isminde bir dosya oluşturalım. Şimdi bu dosyanın örneğin masaüstü dizinine yeni-test ismiyle kaydolmasını istersem komutumu mv test ~/Desktop/yeni-test şeklinde girebilirim. Bakın masaüstü dizininde bu isimde bir klasör olmadığı için taşımak istediğim “test” isimli dosya doğrudan masaüstüne “yeni-test” ismiyle taşınmış olacak. Sonucu görmek için masaüstü dizinini ls komutu ile listeleyebiliriz. Bakın yeni-test isimli dosya burada bulunuyor. İsim değiştirebilme özelliği süper ama isim değiştirmek için mv komutunu kullanırken, o dizinde daha önceden yeni tanımladığınız isimde bir klasör olmamasına mutlaka dikkat edin. Aksi halde mv komutu isim değiştirmek yerine, o isimdeki klasörün içerisine taşır.

Yani örneğin ben komutumu mv test ~/Desktop/yeni-test ifadesi yerine mv test ~/Desktop/tasinacak-klasor şeklinde girmiş olsaydım tabii ki mv komutu benim test dosyasının ismini değiştirme yerine bu dosyayı bu klasör altına taşımak istediğimi düşünecekti. Zaten bu durumu tahmin etmek zor değil ancak, yine de dikkat etmeniz için özellikle vurgulamak istedim.

Ayrıca tahmin edebileceğiniz gibi dosya ve klasörleri başka bir dizine taşırken isimlerini değiştirebiliyorsak, başka bir dizine taşımadan mevcut dizinlerinde yalnızca isimlerini değiştirmek için de mv aracını kullanabiliriz. Yani mv aracını doğrudan dosya veya klasörlerin isimlerini değiştirmek için de kullanabiliyoruz.

Ben yine örnek olması için touch test komutu ile test isminde bir dosya oluşturmak istiyorum. Şimdi bu dosyanın ismini güncellemek istersek tek yapmamız gereken, mv komutu ile bu dosyayı mevcut bulunduğu dizine yeni ismiyle taşımak. Yani ben dosyanın ismini yeni-isim yapmak istersem komutumu mv test yeni-isim şeklinde girmem yeterli. ls komutu ile mevcut dizini listeleyelim. Bakın dosyamın ismi yeni-isim olarak değişmiş. İşte isim değiştirme işlemi bu kadar kolay.

Benzer şekilde aynı işlemi klasör isimlerini değiştirmek için de kullanabiliriz. Örnek olması için ben daha önce masaüstüne taşıdığım klasörün ismini değiştirmek istiyorum. Örneğin bu klasörün ismi şu an tasinacak-klasor, ben yeni isim olarak yalnızca klasor ifadesi olmasını istiyorum. Bunun için mv ~/Dekstop/tasinacak-klasor ~/Desktop/klasor şeklinde komutumu girmem yeterli. ls komutu ile desktop dizinini listeleyelim. Bakın klasör ismini de sorunsuzca değiştirmeyi başardık. İşte mv aracının en temel kullanım özellikleri bu şekilde. 

Ayrıca olası veri kayıplarını önlemek adına daha önce cp aracını ele alırken de bahsetmiş olduğum üzerine yazma durumlarından da kısaca bahsetmek istiyorum. Örneğin çoklu şekilde dosya veya klasörleri taşıyorsak daha önce cp komutunda olduğu gibi her adımda bizden onay alınmasını talep edebiliriz. Hemen basit bir örnek olması için mkdir test komutu ile yeni bir klasör oluşturalım. Şimdi bir de touch a b c komutu ile üç yeni dosyayı oluşturalım. Tamamdır. Bu dosyaları test klasörüne taşımak istersek bildiğiniz gibi mv a b c test/ şeklinde komutumuzu girmemiz yeterli. ls test/ komutu ile dizin içeriğini listeleyip kontrol edelim. Bakın dosyalar bu dizine taşınmış. Şimdi ben tekrar aynı isimlerde dosya oluşturup bu dosyaları yine aynı klasöre taşımak istersem ne olur ? Görmek için touch a  b c komutu ile dosyaları oluşturalım. Ve mv a b c test/ komutu ile tekrar klasörün içine taşıyalım. Bakın ls komutu ile teyit ettiğimizde dosyaların mevcut konumda bulunmadığını görebiliyoruz, yani taşınmışlar. Ama dikkat ettiyseniz taşıdığımız dizindeki aynı isimde tutulan dosyaların üzerine yazılacağına dair herhangi bir uyarı almadan bu dosyalar da taşınmış oldu. Yani dosyalar üzerine yazılmış oldular. Bu durumu önlemek için özellikle topluca taşıma yaparken -i seçeneğini kullanıp taşınacak dosya veya klasörlerden hangilerinin hedefteki dizinlerin üzerine yazılacağına dair bilgi edinip seçim yapabiliriz. Ben denemek için touch a b c d e komutu ile 5 yeni dosya oluşturuyorum. Şimdi a b c dosyaları ile aynı isimde dosyalar test klasörü içinde mevcut bulunuyor ama d v e isimli dosyalar yok. -i seçeneğinin nasıl çalışacağını görmek için komutumuzu mv -i a b c d e test/ şeklinde girelim. Bakın bana a dosyasının test klasörü alında mevcut olduğunu, dolayısıyla yeni dosyanın eskisinin üzerine yazılacağını belirten bir çıktı aldım. Eğer üzerine yazma işlemini onaylıyorsak y, onaylamıyorsak da n yazıp enter ile bir sonrakine geçiş yapabiliriz. Bu şekilde bakın sırasıyla üzerine yazılacak tüm dosyalar hakkında bizden izin istendi ama gördüğünüz gibi test klasöründe olmayan d ve e dosyaları yani yeni dosyalar hakkında herhangi bir izin istenmedi. İşte bu şekilde üzerine yazma ihtimalinden korunmak için gerektiğinde kritik dosya ve klasörler için -i seçeneğini de komutunuza dahil edebilirsiniz.

Özellikle toplu şekilde taşıma yapıyorken bazı dosyaların üzerine yazılmasını diğerlerin korunmasını istediğimiz durumda -i seçeneği tam olarak istediğimiz çözüm. Fakat her zaman tek tek belirtmek de istemeyebiliriz. Örneğin bir yerdeki dosyaları başka bir yere taşırken, eğer aynı isimde dosya varsa üzerine yazma demek için doğrudan -n seçeneğini de kullanabiliyoruz. Hatırlıyorsanız aynı seçenek cp komutunda da mevcuttu. Biz n seçeneğini kullandığımızda bize sorulmadan, eğer o dizinde aynı isimde dosyalar varsa bu dosyalar kesinlikle ilgili dizine taşınmıyor oldukları yerde kalıyorlar. Hemen denemek için touch a b 1 2 komutu ile a b 1 ve 2 dosyalarını oluşturalım. 

Şimdi, ls test/ komutu ile de teyit edebileceğimiz gibi test dizininde a ve b isimli dosyalar bulunuyor fakat 1 ve 2 isimli dosyalar bulunmuyor. Ben yalnızca benzersiz olan dosyaların test klasörüne taşınmasını istersem komutumu mv -n a b 1 2 test/ şeklinde girebilirim. Burada belirttiğim -n seçeneği sayesinde birden fazla dosyayı taşıyor olsam da yalnızca benzersiz olanlar test dizinine taşınacak. Komutumuzu onaylayalım. Şimdi mevcut bulunduğumuz dizini listeleyebiliriz. Bakın burada yalnızca a ve b dosyaları duruyor çünkü taşımak istediğimiz dizinde bu dosyalar ile aynı isimli dosyalar zaten mevcuttu. Dolayısıyla bunlar taşınmadan oldukları yerde kaldılar. Şimdi ls test/ komutu ile test klasörünün içeriğine de göz atalım. Bakın 1 ve 2 isimli dosyaların buraya taşınmış olduğunu görebiliyoruz. Böylelikle, -n seçeneği sayesinde yalnızca benzersiz olan dosyaların taşınmasının sağlandığını bizzat teyit etmiş olduk. Eğer taşıdığınız dosyaların, aynı isimli eski dosyaların üzerine yazılarak verileri yok etmesini istemiyorsanız -n seçeneğini kullanabilirsiniz.

Ben hızlıca örnek vermek için içi boş dosyalar kullandım ancak dilerseniz içi dolu olan dosyaları kullanarak, mv aracının taşıma işlemi yaparken aynı isimde dosyaların üzerine yazma işlemi yaptığını görebilirsiniz. Örnek olması için cat > test/a komutunu girip bu dosyanın içine de “ben ilk dosyayım” yazıp ctrl d ile dosya içeriğini kaydediyorum. 

Şimdi aynı isimde ama farklı içeriğine sahip bir dosya daha oluşturmak için cat > a şeklinde komutumuzu girip, içine de “ben ikinci dosyayım” şeklinde yazabiliriz. Tamamdır. Eğer ben mv komutuna -i veya -n gibi bir seçenek ekleyip üzerine yazmaya engel olacak bir önlem almazsam, buradaki “a” dosyasını test dizinine taşıdığımda, test dizini altındaki a dosyasının içeriği yok olacak. 

Denemek için mv a test/a şeklinde komutumuzu girebiliriz. Tamamdır. Şimdi test dizindeki a dosyasını cat komutu ile okuyup son durumu görelim. Bakın a dosyasının içeriği yeni taşıdığımız dosyanınkiyle değiştirilmiş. Yani yeni taşıdığımız aynı isimdeki dosya eski dosyanın üzerine yazılmış.

Bence mv komutu hakkında temelde bilmemiz gerekenler bunlar. Kendi kendinize biraz daha kurcalarsanız ne kadar kolay kullanılabilir olduğunu bizzat deneyimleyebilirsiniz. Ben kendimi tekrar etmek istemediğim için çok fazla örnek vermedim ama siz kendi kendinize hem dosya hem de dizinleri taşıyarak alıştırmalar yapıp mv aracının kullanımını iyi biçimde kavrayın. Ayrıca her zaman olduğu gibi elbette daha fazlası için mv —help komutu ile diğer seçenekleri ve özellikleri görüntüleyebilirsiniz.

# rm Komutu

Kopyalama ve taşıma araçlarından ve bunların temel kullanımlarından bahsettik. Şimdi bir diğer temel işlev olan silme işlevinden de bahsetmek istiyorum. Daha önce de çok kısaca bahsettiğimiz gibi mevcut dosya ve klasörleri komut satırı üzerinden silmek istediğimizde rm aracını kullanabiliyoruz. rm aracının ismi ingilizce "remove" yani "silme/kaldırma" ifadesinin kısaltmasından geliyor. Tıpkı cp ve mv aracında olduğu gibi rm aracının kullanımı da son derece kolay.

İstersek tek bir dosyayı istersek de aynı anda birden fazla dosyayı silmek için tek yapmamız gereken, silmek istediğimiz dosyaların isimlerini rm komutundan sonra yazmak. Test amaçlı silinecek dosyalar oluşturmak için touch a b c d e komutu ile birden fazla dosya oluşturabiliriz. Tamamdır. 

Ben öncelikle denemek için tek bir dosya silmek istiyorum. Örneğin a isimli dosyayı silmek için rm a şeklinde komutumu girebilirim. Mevcut dizinimizi listeleyelim. Bakın a isimli dosya artık bulunmuyor. 

Eğer birden fazla dosyayı silmek istersem isimlerin peş peşe yazmam yeterli. rm komutundan sonra diğer dosyaların isimlerini de yazarak deneyebiliriz. Tekrar ls komutu ile mevcut dizini listeleyelim.

Bakın dosya isimlerini göremiyoruz yani biraz önce oluşturduğum tüm dosyaları rm aracı yardımıyla kolaylıkla silmiş oldum. Ben bulunduğum konumdaki dosyaları sildim. Ancak elbette sistem üzerinde yetkinizin bulunduğu tüm dosyaları tam dizin adreslerini belirterek silebiliyoruz. Örneğin ben test isimli dosyanın içine bazı dosyaları taşımıştım. Bunları silmek için rm test/ dosya ismi şeklinde spesifik olarak silinecek dosyanın konumunu ve adını belirtebilirim. Ben a isimli dosyayı silmek üzere komutumu giriyorum. Tamamdır, şimdi ls test/ komutu ile dosya ismini listeleyelim. Bakın ismini girmiş olduğum dosya silinmiş. İşte dosyaları tekil veya çoklu şekilde silmek bu kadar kolay. Tek yapmanız gereken silmek istediğiniz dosyanın tam olarak konumunu belirtmek.

Ayrıca ben üzerinde özellikle durmadım ama fark ettiyseniz toplu şekilde dosya silerken bizden ekstra bir onay alınmadan tek seferde tüm dosyalar silinmişti. Bu durum kimi zaman istenmeyen sonuçlara yol açabilir. Önlem olarak eğer istersek silmeden önce her dosya için bizden onay istenmesini sağlayabiliriz. Bu sayede toplu silme işlemlerinde yanlış dosyaları silmekten de kaçınmış mümkün olabilir. Örnek senaryomuzda, bir dizin içinde tüm dosyaları silmek üzere konsola rm * komutunu girdiğimizi farz edelim. Bu durumda kabuk yıldız işareti sayesinde bulunduğumuz dizindeki tüm dosyaları kapsayacağı için tüm dosyaların silinmesi emrini vermiş oluyoruz. 

Örneğin daha önce oluşturduğum test dizini altındaki dosyaları toplu şekilde silmek için rm test/* şeklinde komutumu girebilirim. Fakat ben tüm dosyaları silmek istemiyorum, bazılarını eleyip geri kalanları silmek istiyorum. Bunun için cp ve mv komutuyla da kullandığımız -i seçeneğini kullanabiliriz. Denemek için komutumuza -i seçeneğini de ekleyip bu şekilde girelim. 

Bakın silme işlemi için onay isteniyor. Onaylamak için yes ifadesinin kısalması olan y, reddetmek için no ifadesinin kısalması olan n karakterini kullanmalıyız. Elbette kullandığınız işletim sisteminin diline göre onay ifadeleri de değişebilir. Örneğin türkçe için evet in e si hayır ın h si kullanılıyor. Ancak kursun başında da belirtiğim şekilde sistem dilini varsayılan yani ingilizce olarak kullanmanızı tavsiye ettiğim için ben ingilizce olduğunu varsayarak anlatıma devam edeceğim. 

Dosyalardan birine silinmesi için onay vermiyorum. Şimdi tekrar listeleyelim. Gördüğünüz gibi onay vermediğim dosya silinmemiş, geri kalan tüm dosyalar benim onaylımla silinmiş oldu.

Neticede i seçeneği sayesinde tüm silme işleminin adım adım bizden onay alınarak gerçekleştirilmesini sağlamış olduk. Ayrıca tek tek sorulması yerine eğer toplu şekilde silinmeden önce son bir kez onay alınsın isterseniz büyük I (L değil büyük ı karakteri ) seçeneğini de kullanabiliriz. Hemen denemek için touch a b c d e komutu ile yine sıralı dosyalarımı oluşturalım. Şimdi bu dosyaları silmek için rm {a..e} şeklinde komutumu yazabilirim. Bu komutu onaylarsam, a dan e ye kadar olan karakterler ile eşleşen dosyaların tamamı silinecek. Ben silmeden önce son kez bana sorulmasını da istediğim için büyük -I seçeneğini de ekleyip komutumu bu şekilde çalıştırıyorum.

Bakın, silineceklerin adeti belirtilerek silmeden önce son bir kez emin olmamız için soruluyor. Onay verirsem yani y yazarsam hepsi silinecek. Onay veriyorum. ls komutu ile mevcut dizinimizi listeleyelim, gördüğünüz gibi dosyalar benden onay alınarak silinmiş oldu.

Tamamdır bence dosyaları silmekle ilgili tüm temel bilgilerden bahsettik. Şimdi klasörleri nasıl silebileceğimizi örnekler üzerinden ele alalım.

## Klasörlerin Silinmesi

Normalde rm komutunu ekstra bir seçenek belirtmeden kullandığımızda rm aracı yalnızca kendisine argüman olarak verilmiş olan dosyaları siliyor. Yani aynı isimle eşleşen klasörleri silmiyor. Klasörleri silmesi için silinecek şeyin özellikle klasör olduğunu ingilizce directory yani klasör ifadesinin kısaltmasından gelen -d seçeneği ile belirtmemiz gerekiyor.

Hemen deneyelim. Ben test etmek için mkdir sil-beni komutu ile yeni klasör oluşturuyorum. Şimdi rm komutu ile oluşturduğumuz bu dosyayı silmeyi deneyebiliriz. Bakın aldığımız çıktıda, klasör olduğu için silinemediği konusunda uyarıldık. Eğer directory yani klasör ifadesinin kısaltması olan d seçeneğini kullanırsak silebileceğiz. Hemen deneyelim.

Gördüğünüz gibi d seçeneği sayesinde klasörüm sorunsuzca silinmiş oldu. 

Dosyalara benzer şekilde klasörleri de çoklu şekilde silebiliriz. Denemek için hemen mkdir x y z komutu ile yeni birkaç klasör oluşturalım. Silmek üzere klasör isimlerini peş peşe girmemiz yeterli. Eğer silinmeden önce  bizden tek tek onay alınsın istersek elbette i seçeneği de kullanabiliriz. Gördüğünüz gibi klasörlerin silinmesi için tek tek bizden onay bekleniyor. Ben hepsine onay vereceğim. ls komutu ile silinip silinmediklerini kontrol edelim. Bakın klasörleri toplu şekilde silebildik.

Şu ana kadar klasörleri silerken hiç bir problem yaşamadık, çünkü klasör içerikleri boştu. Eğer klasörlerin içinde başka dosyalar ve klasörler bulunuyorsa, rm -d komutu ile silmemiz mümkün değil. Hemen deneyelim. 

Mesela teyit etmek için daha önceden oluşturduğum documents dizini altındaki klasörümü silmeyi deneyebilirim. Silmek için rm -d ~/Documents/klasor şeklinde komutumuzu girelim. Gördüğünüz gibi dizin boş olmadığı için silinemediği konusunda uyarıldık. İçerisi dolu dizinleri silmek için -r seçeneğini kullanmamız gerekiyor. Buradaki r seçeneği ingilizce recursive yani özyinelemeli ifadesinin kısaltmasından geliyor.

 Bu seçenek sayesinde klasörün içinde iç içe birden fazla klasör ve dosya olsa da tüm dosyaların ve klasörlerin silinebilmesi mümkün oluyor. Hatırlıyorsanız klasör içeriklerini kopyalarken de bu şekilde recursive seçeneğini eklemiştik. En alt dizine kadar bakılıp silmesi özyineleme özelliğini temsil ediyor yani. Hatta recurisve yani özyineleme seçeneğini yalnızca klasörler üzerinde kullandığımız için aslında rm aracına ek olarak -d seçeneğini de girmemiz gerekmiyor. Yani rm -r silinecek-klasör ismi şeklinde komutumuzu girdiğimizde, belirttiğimiz dizin tüm içeriğiyle birlikte siliniyorum. Hemen komutumuzu onaylayalım. Şimdi tekrar listeleyelim. Bakın yalnızca -r seçeneğini kullanarak içi dolu klasörü silmeyi başardım.

Ayrıca ben kullanmadım ancak özellikle iç içe klasörler ve dosyalar barındıran klasörleri silerken, i seçeneğini ekleyerek yanlış bir dosyayı veya klasörü silmediğinizden emin olmanızı önerebilirim. Yine de klasörden tek seferde kurtulmak istediğinize eminseniz elbette i seçeneğini kullanmak zorunda değilsiniz.

Ayrıca hatırlıyorsanız, boş dizinleri silmek için daha önce rmdir aracını kullanmıştık. İşte rm -d komutu rmdir aracı ile aynı işlevi görüyor. İçerisi dolu olan dizinleri silmek için de rm -r komutunu kullanıyoruz. Dolayısıyla emin olmadığınız sürece rm -r komutunu kullanmanız önermem. Yine de elbette klasörü içeriğiyle birlikte silmek istediğinizden eminseniz kullanabilirsiniz.

Son olarak eğer, tüm silme adımlarının ayrıntılarını da takip etmek isterseniz verbose yani ayrıntılı ifadesinin kısaltması olan v seçeneğini de kullanabilirsiniz. Toplu şekilde klasör silerek kullanımı teyit edebiliriz. Ben çabucak test etmek için mkdir {1..9} komutuyla yeni klasörler oluşturuyorum. Şimdi de toplu şekilde silmek ve silme işlemiyle ilgili ayrıntıları da öğrenmek için rm -dv {1..9} şeklinde komutumuzu girebiliriz. Bakın tüm silme işlemi adım adım bastırıldı. Bu şekilde silme işlemlerini takip etmek istiyorsanız v seçeneğini de kullanabilirsiniz.

Neticede rm komutu hakkında bilmemiz gereken tüm temel yaklaşımlardan bahsettik. Diğer seçenekleri görmek için yardım sayfasına göz atabilirsiniz. Ben bir sonraki derste dosyaları nasıl geri döndürülemez şekilde yani kalıcı olarak silebileceğimizden bahsetmek istiyorum.

# shred Komutu | Dosyaları Geri Döndürülemez Şekilde Silmek

Geri döndürülemez yani kalıcı silme kavramından bahsetmeden önce silme işlemlerinin temelde nasıl işlediğinden bahsetmek istiyorum. Bu sayede kalıcı silmeden kastın ne olduğu daha net anlaşılabilir. 

Eğer herhangi bir dosyayı sildiğinizde o dosyanın tamamen yok olduğunu düşünüyorsanız kesinlikle yanılıyorsunuz. Kısaca özetlemek gerekirse işletim sistemleri dosya silme emri aldığında o dosyayı gerçekten diskten silmek yerine, dosyaya ulaşmanızı sağlayan yolun bilgisini silerler. Yani aslında dosya hala disk üzerinde mevcut olmasına rağmen, sadece dosyaya giden bağlantı siliniyor. Bu yöntemin kullanılma nedeni dosyayı gerçekten silmeye oranla çok daha hızlı sonuç vermesidir. Peki ama gerçek silme işleminden kastımız tam olarak ne ?

Gerçek silme işlemi dediğimiz kavram; disk üzerinde yer kaplayan her türlü verinin ancak üzerine yeni veriler yazılması ile ortadan kaldırılabilecek olmasını ifade ediyor. Çünkü üstüne yeni veri yazılarak tahrip edilmeyen her türlü verinin tekrar kurtarılma ihtimali var. Adli bilişim alanında bu iş için kullanılan pek çok yazılımsal ve harici olarak fiziksel kurtarma yöntemi bulunuyor.

İşin özü eğer bir dosyadan geri döndürülemez şekilde kurtulmak istiyorsak o dosyayı silerken üzerine birden fazla kez rastgele veri yazılmasını sağlamamız gerekiyor. Pek çok işletim sisteminde bu üzerine yazma işlemi için harici yazılımlar yükleyip kullanmamız gerekebiliyor. Ancak söz konusu Linux olduğunda pek çok dağıtımda varsayılan olarak yüklü gelen shred isimli aracı kullanabilme kolaylığa sahibiz. 

Zaten shred ifadesi Türkçe olarak "parçalamak" anlamına geliyor. Eğer herhangi bir arama motoruna yazarsanız, karşınıza parçalanmış kağıt görselleri çıkacaktır. Bu aracı kullanarak, dosyaların üzerine veriler yazılarak tahrip edilmesini sağlayabiliyoruz. Dosya içeriği tahrip olduktan sonra da dosyayı güvenle sıradan şekilde silebiliyoruz çünkü dosya geri getirilse bile orijinali tahrip edildiği için gerçek içeriğine ulaşılamıyor.

Silme mekanizmalarından bence yeterince bahsettik. Şimdi lafı daha fazla uzatmadan shred komutunun kullanımından bahsederek devam edelim.

shred komutunu herhangi bir ek seçenek belirtmeden kullandığımızda varsayılan olarak kendisine argüman olarak verilmiş olan dosyanın üzerine 3 kez rastgele bitler yazılmasını sağlıyor. Eğer daha fazla kez yazılmasını istersek, -n seçeneğini kullanıp kaç kez yazılması gerektiğini özellikle de belirtebiliyoruz.. Ayrıca -v seçeneğini ekleyerek verbose yani ayrıntılı çıktı vermesini de sağlayabiliriz. Bu sayede tüm adımları konsoldan takip edebiliriz.

Ben denemek için yeni bir dosya oluşturmak istiyorum. Bunun için cat > oku-beni komutunu giriyorum, ve “bu bir dosyadır” ifadesini ekleyip ctrl d ile dosyanın içeriğini kaydediyorum. Öncelikle dosya içeriğimin okunaklı olduğunu cat komutu ile teyit edelim. Bakın içeriği sorunsuzca okuyabiliyoruz. Şimdi shred aracını kullanarak dosya içeriğine rastgele bitler yazılmasını sağlayabiliriz. Ben varsayılan şekilde yani 3 kez rastgele bitler yazılması için shred aracına özellikle bir sayı vermek istemiyorum ama işlem adımlarını takip etmek için verbose yani ayrıntılı çıktı seçeneğini ekleyeceğim. Komutumu shred -v oku-beni şeklinde giriyorum. Bakın 3 kez rasgele verilerin bu dosya üzerinden geçirildiğine dair çıktılarımızı aldık. Dosya içeriğini görmek için cat komutu ile dosyamızı okuyalım. Bakın dosyanın içeriği tamamen okunamaz halde. Artık bu dosyayı rm komutu ile gönül rahatlığıyla silebiliriz çünkü dosya geri getirilse bile içeriğindeki verilere ulaşılması pek olası değil. Çünkü içerisine 3 kez rastgele veriler yazıldı.

İşte shred aracının kullanımı bu kadar kolay. 

Ayrıca daha önce de bahsettiğim şekilde istersek kaç kez rastgele veri yazılacağını da -n seçeneğinin ardından özellikle belirtebiliyoruz. Örneğin ben 5 kez rastgele veri yazılmasını istersem shred -n 5 dosya-adı şeklinde komutumu girebilirim. Hatta sayıyı belirtmeye ek olarak rastgele yazma işleminden hemen sonra bu dosyanın silinmesini de sağlayabiliriz. Dosyanın silinmesi için de -u seçeneğini eklememiz yeterli oluyor. 

Ben denemek için bu oku-beni dosyasının üzerine 5 kez rastgele veri yazılıp daha sonra silinmesini için komutumu girmek istiyorum. Tabii tüm işlem adımlarını takip edebilmek için bir de -v seçeneği ile ayrıntıların da bastırılmasını istiyorum. Bunun için shred -uvn 5 oku-beni şeklinde komutumu giriyorum. Bakın öncelikle dosya içeriğine rastgele 5 kez veriler yazılmış, daha sonra dosya silinmiş ve son olarak dosyanın isminin de silinmesi için dosya ismi de adım adım sıfırlar ile doldurularak yok edilmiş. Bu yaklaşım sayesinde dosyanın isminin dahi disk üzerinden kurtarılması pek olası değil.

Hatta teyit etmek için ls komutu ile mevcut dizinimizi listeleyebiliriz. Bakın gördüğünüz gibi dosyamız işlem sonunda otomatik olarak silinmiş.

Ayrıca benim örnekler üzerinde kullandığım dosyanın içeriği çok küçük olduğu için tüm işlem çok kısa sürede tamamlandı ancak bu durum her zaman böyle olmayabilir. Yani üzerine yazma işlemi, üzerine yazılacak olan dosyanın boyutuna göre değişken uzunlukta sürebilir, sabırla işlem tamamlanana kadar beklemelisiniz. Benim dosya boyutum çok küçük olduğu için işlem çok kısa sürede tamamlandı. 

Neticede sizler de kalıcı olarak istediğiniz dosyalarınızı bu yaklaşım sayesinde güvenli şekilde silebilirsiniz. Hazır silme işlemlerinden bahsetmişken bir sonraki bölümde Linux sistemlerinde geri dönüşüm kutusu hakkında da çok kısaca bilgi vermek istiyorum.

# Linux geri dönüşüm kutusu ?

Komut satırı üzerinden bir dosyayı sildiğimizde, normalde grafiksel arayüzde olduğu gibi sildiğimiz dosya çöp kutusuna gönderilmiyor. Yani çöp kutusu olarak geçen dizin yalnızca grafiksel arayüzdeki dosya silme işlemlerinde kullanılan sembolik bir dosya yolu.

Denemek için grafiksel arayüzdeyken bir dosyanın üzerine tıklayıp delete tuşu ile dosyayı silebiliriz. Bakın dosyam silindi. Şimdi masaüstünde bulunan çöp kutusu olarak temsil edilen bu dizini açıp bakalım. Bakın silmiş olduğumuz dosya burada bulunuyor. Şimdi denemek için touch deneme komutu ile yeni bir dosya oluşturalım. Ve bu dosyayı rm komutu ile silelim. Bakın komut satırı üzerinden silme işlemi gerçekleştirdiğimiz için çöp kutusuna herhangi bir dosya eklenmedi. Zaten komut satırı üzerinden sildiğimizde buradaki çöp kutusuna geliyor olsaydı önceki silme işlemlerinin kalıntılarını burada görüyor olmamız gerekiyordu. 

Komut satırından silinen dosyaların burada gözükmüyor olmasına ek olarak windoows sisteminden de aşina olduğumuz gibi grafiksel arayüzdeyken shft delete tuşlaması ile bir dosya veya klasörü sildiğimizde bu dosya veya klasör bu çöp dizinine gelmeden komut satırında olduğu şekilde siliniyor. Tabii ki shift delete tuşlaması bizim shred komutu ile sildiğimiz gibi silmiyor ancak en azından sadece çöp dizinine de taşımış olmuyor. 

Komut satırından veya shfit delete ile grafiksel arayüzden sildiğiniz dosyaları geri getirmek isterseniz de testdisk gibi harici veri kurtarma yazılımları ile ilgili dosyalarınızı kurtarabilirsiniz. Tabii ki daha önce de belirttiğim şekilde eğer shred aracı ile dosya içeriklerini tahrip ettiyseniz yani kalıcı olarak sildiyseniz kurtarma yazılımları ile ilgili dosyaları kurtarmanız pek olası değil. 

İşte tüm bahsetmiş olduğumuz silme yaklaşımlarının bilincinde olarak silme ve geri kurtarma planlarınızı bilgileriniz dahilinde yerine getirebilirsiniz.

# Sembolik ve Katı Link | Hard Link & Soft Link

Bu derste çok kısaca sembolik ve katı linklerden de bahsetmek istiyorum. 

Fakat sembolik ve katı linklerden bahsetmeden önce, link yapısını yani aslında buradaki link ifadesinden kastımızı anlamak için öncelikle "inode" kavramı üzerinde durmamız gerekiyor. Merak etmeyin çok ayrıntıya girmeyeceğiz. 

Dosya sistemindeki veriler depolama birimlerimizde yani diskte bloklar halinde tutuluyorlar. Dosyalarla ilişkili olan verilerin hangi bloklarda olduğunun bilgisini de bizlere index node yani kısaca inode olarak isimlendirilen yapı haber veriyor. 

Örneğin ben metin.txt isimli bir dosyanın içerisine merhabalar yazıp kaydettiğimde, merhabalar ifadesi diskte belirli bir bloğa kaydediliyor. Ve bu verinin disk üzerinde tam olarak bulunduğu bloğun veya blokların bilgisi de inode olarak isimlendirilen benzersiz sayısal bir değere atanıyor. Metin.txt dosyası ise bu inode değerine link olarak bağlanıyor. Bu sayede biz metin.txt dosyasının içeriğini okumak istediğimizde aslında arkaplanda metin.txt dosyasının bağlı olduğu inode değerine bakılıyor. inode değerinin disk üzerinde işaret ettiği bloklardan da bu veriler getiriliyor. Neticede biz metin.txt ismiyle ilişkili olan "merhabalar" verisine disk üzerinde kaydedildiği yerden tekrar ulaşmış oluyoruz. Yani aslında buradaki metin.txt dosyası yalnızca benzersiz bir inode değerine bağlı olan linktir. inode değeri de ilgili verinin diskteki yerini bildiği için metin.txt linki üzerinden bu veriye ulaşabiliyoruz.

İşte tıpkı bu örneğimizde olduğu gibi dosya sistemindeki benzersiz olan her bir dosya ve klasörün de benzersiz bir inode değeri bulunuyor. Bizim gördüğümüz dosya ve klasör isimleri de yalnızca bu inode değerlerine yönlendirme yapan linkler aslında. Dosya veya klasör isminden inode değerine, inode değerleri üzerinden de disk üzerinde depolanmış olan verilere kolayca erişebiliyoruz. Buradaki linkler yalnızca biz insanların disk üzerindeki verilere kolay erişebilmesi için okunaklı isimlerden oluşan bağlantı noktaları aslında. 

Tamam temel seviye için inode ve link kavramı hakkında bu kadarlık bilgi yeterli.

Şimdi esas konumuz olan link kavramlarından bahsedecek olursak, linux üzerinde sembolik ve katı olmak üzere iki link çeşidi bulunuyor. Gelin öncelikle sembolik linkten bahsederek başlayalım.

## Sembolik Link

Ben sembolik link diyor olacağım ancak farklı kaynaklarda soft link olarak ifade edildiğini de görebilirsiniz. Bu şekilde duyarsanız şaşırmayın, burda bahsedeceğimiz sembolik linki kast ediyorlardır. Sembolik linkleri windows sisteminden de alışık olduğumuz sıradan kısayollara benzetebiliriz. Sembolik linklerin görevleri yalnızca orijinal dosya içeriğine yönlendirme yapmaktır.

Daha anlaşılır olması için gerçek bir örnek üzerinden devam edebilmek adına öncelikle nasıl sembolik link oluşturabileceğimizi öğrenelim.

Link oluşturmak için link ifadesinin kısaltmasından gelen `ln` komutunu kullanıyoruz. Sembolik link oluşturmak için de symbolic ifadesinin kısalması olan `s` seçeneğini kullanmamız gerekiyor.

Ben test ortamı hazırlamak için öncelikle kendi ev dizinimde mkdir linkler komutuyla linkler isimli bir klasör oluşturuyorum. Şimdi bir de echo “deneme” > linkler/metin komutuyla, bu dizin altında metin isimli dosyaya deneme ifadesini ekleyelim. Tamamdır.

cat ile kontrol edecek olursak bakın dosyam sorunsuzca oluşturulmuş. Test ortamımız hazır. Şimdi bu dosyanın sembolik linkini oluşturmayı deneyelim. 

Sembolik link oluştururken dosya ve klasörlerin tam dosya dizin adreslerini mutlaka belirtmemiz gerekiyor. Çünkü sembolik dosyaları sistem üzerinde herhangi bir dosya konumunda kullanabiliriz. Tam dizin adresini belirtmezsek doğru şekilde çalışmaz. Ben bu dizindeki dosyanın sembolik linkini mevcut bulunduğum dizinde oluşturmak için ln -s linkler/metin sembolik_metin şeklinde komutumu giriyorum. Teyit etmek için ls -l komutuyla listeleyelim. Bakın burda sembolik_metin dosyasının oluşturulduğunu görebiliyorum. Hatta bakın dosya ismi renkli şekilde basıldı ve orijinal dosyaya ok ile işaret ediyor. Buradaki çıktının anlamı sembolik_metin isimli dosyanın metin dosyasının sembolik bir bağlantısı olduğu. Bunlar dışında çıktıların en solunda yani dosya türünün belirtildiği bölümde L karakteri bulunuyor. Buradaki L ifadesi sembolik link anlamına geliyor. Dolayısıyla her iki şekilde de başarılı şekilde sembolik linkimizi üretmeyi başardığımızı teyit etmiş olduk.

Hemen sembolik linkin nasıl bir işlevi olduğunu görmek için birkaç basit örnek yapalım. Öncelikle oluşturduğumuz sembolik link üzerinden orijinal dosyanın içeriğini okumayı deneyebiliriz. Ben bunun için cat sembolik-metin şeklinde komutumu giriyorum. Bakın konsola deneme ifadesi bastırıldı. Yani sembolik link üzerinden orijinal dosyamızın içeriğine ulaşmış olduk.

Şimdi orijinal dosyaya yeni veri ekleyerek bu durumu tekrar test edelim. Ben yeni veri eklemek için echo “yeni” >> linkler/metin şeklinde komutumu giriyorum. Tamamdır. Orijinal dosyaya yeni verimizi ekledik. Hatta cat komutu ile okuyalım. Bakın yeni veri orijinal metin dosyasına kaydedilmiş. Şimdi birde sembolik dosyamızı okumak için cat sembolik-metin şeklinde komutumuzu girelim. Bakın orijinal dosyadaki değişikliğe bu dosya üzerinden de erişebiliyoruz. Neticede sembolik linkler aslında orijinal dosyaların kısayolları görevinde olduğu için tek yaptığı orijinal dosyaya yönlendirme yapmak. Dolayısıyla orijinal dosya içeriğindeki değişikliklere sembolik link dosyaları üzerinden de aynen ulaşabiliyoruz.

Şimdi tersini deneyelim. Yani sembolik dosyanın üzerine yeni veri ekleyip orijinal dosyaya etki edip etmeyeceğini görelim. Ben yeni veri eklemek üzere echo “sembolik ekleme” >> sembolik-metin şeklinde komutumu giriyorum. Tamamdır, şimdi orijinal dosyamızı okumak için cat linkler/metin komutunu girelim. 

Bakın sembolik bağlantıdaki değişiklik orijinal dosyada da geçerli olmuş. Peki ama nasıl ?

Biz burada bu dosyaya veri eklemek üzere komutumuzu girdiğimizde, bu sembolik linke yönlendirmiş olduğumuz veriler orijinal dosyaya yönlendirilip, bu dosya üzerinden diskteki verilere ekleme yapılması sağlanıyor. Bu sayede tıpkı orijinal dosya üzerinden ekleme yapmışız gibi değişiklikler geçerli oluyor.

Yani bizzat teyit ettiğimiz gibi sembolik bağlantılar aslında orijinal dosyaya yönlendirme yapan kısayol dosyaları. Bu sebeple örneğin orijinal dosya silinirse, sembolik linkler üzerinden diskteki verilere ulaşmamız mümkün olmuyor. Çünkü dediğimiz gibi sembolik linkler yalnızca orijinal dosyaya yönlendirme yapıyor, bu orijinal dosya da zaten disk üzerindeki verilere ulaşmamızı sağlayan bir bağlantı. Eğer bu bağlantı kesilirse, diskteki veriler silinmemiş bile olsa o verilere ulaşmamız mümkün olmuyor. Zaten biz standart şekilde dosya sildiğimizde arkaplanda yalnızca diskteki o verilere giden bu bağlantı adresi silinmiş oluyor. Yani diskte veriler mevcut olsa da o verilere ulaşmamızı sağlayan bağlantıyı kaybettiğimiz için ulaşamıyoruz. Bu sebeple standart şekilde silinen ve üzerine veri yazılamayan verilerin diskten kurtarılması mümkün oluyor.

Teorik olarak açıkladık. Şimdi bu durumu bizzat deneyimlemek için ben orijinal dosya olan linkler klasörü içerisindeki metin dosyasını silmek üzere rm linkler/metin şeklinde komutumu giriyorum. Tamamdır. Şimdi cat sembolik-metin komutunu girip sembolik link üzerinden dosya içeriğini okumayı deneyebiliriz. 

Bakın böyle bir dosya veya dizin yok hatası alıyoruz. ls -l komutu ile listeleyelim. Bakın sembolik link dosyası gözüküyor ama orijinal dosya silindiği için bu sembolik link kırmızı renkle listelenmiş oldu. Zaten sembolik link bizi bu dosyaya yönlendirdiği için ama bu dizinde böyle bir dosya olmadığı için bu hatayı aldık.

Yani benim cat sembolik-metin komutunu girmemle, cat linkler/metin komutunu girmem aynı şey. Bakın yine böyle bir dosya ve dizin yok şeklinde cat komutu bize hata döndürdü. İşte gördüğünüz gibi sembolik linkler yalnızca orijinal dosyalara yani aslında orijinal linklere yönlendirme yapan kısayollar. Orijinal bağlantılar olmazsa, disk üzerindeki verilere ulaşmamız mümkün olmuyor.

Aynı şekilde klasörler için de sembolik linkeler oluşturabilirsiniz. Ben denemek için ln -s linkler linkler-sembolik komutu ile yeni sembolik klasörümü oluşturmak istiyorum. ls -l komutuyla listeleyelim. Bakın tıpkı sembolik dosyada olduğu gibi sembolik klasör de bağlı olduğu klasöre yönlendirme yapıyor. Sembolik klasörler de tıpkı dosyalar gibi yalnızca orijinal klasöre yönlendirme yaptığı için orjinal klasör silinirse sembolik link çalışmaz.

Ben sembolik linki test etmek için cd linkler-sembolik komutunu giriyorum. Tamamdır bakın şu anda bu sembolik klasör içerisinde gözüküyorum. İçeriği listelemek için ls komutunu girelim. Gördüğünüz gibi orijinal linkler klasörünün içeriğini bu sembolik klasör üzerinden de görebiliyorum. Aynı şekilde eğer bir üst dizine gelip, cat linkler-sembolik/metin komutunu girecek olursam, bakın orijinal dosya içerisindeki dosyaya yine bu sembolik link üzerinden ulaşmam mümkün oluyor. 

Ben örnekler sırasında birer tane sembolik dosya ve klasör oluşturdum. Ancak istiyorsanız tek bir dosya veya klasör için birden fazla sembolik link de oluşturabilirsiniz. Zaten sembolik linkler kısayol görevinde olduğu için kısayol yapısına ihtiyaç duyulan her yerde kullanılabilir.

Sembolik link dosyalarını silmek için de doğrudan silmek istediğiniz sembolik link dosyasının ismini rm komutuna argüman olarak verebilirsiniz. Örneğin ben oluşturduğum bu sembolik linki silmek istediğim için rm semoblik-metin şeklinde komutumu giriyorum.

Bakın dosyam sorunsuzca silindi.

## Katı Link

Şimdi katı linklerden bahsedecek olursak. Sembolik linklere soft link denilmesi gibi, katı linklere de hard link denebiliyor. Katı link oluşturmak için doğrudan ln komutunu seçenek belirtmeden kullanabiliyoruz. 

Ben denemek için yine echo “orijinal dosyayım” >> linkler/metin şeklinde komutumu giriyorum.

Şimdi bu dosya için bir katı link oluşturmak üzere ln linkler/metin kati-metin şeklinde komutumuzu girebilir. ls -l komutuyla listeleyip dosya oluşturulmuş mu diye bakalım.

Şimdi bakın dosyam oluşturulmuş fakat bu dosyanın bir link dosyası olduğuna dair burada bir emare yok. Halbuki sembolik linkte açıkça link dosyası olduğu ve hangi dosyaya bağlı olduğu buradaki çıktılarda belirtiliyordu.

Burada katı linke dair özel bir çıktı almadık çünkü aslında katı link dediğimiz kavram sistemimiz üzerindeki tüm standart dosya ve dizinleri temsil ediyor. Yani benim oluşturduğum orijinal metin dosyası da disk üzerindeki verilere yönlendirme yapan bir katı link. 

Ben burada kati-metin isimli yeni bir katı link oluşturduğumda, tıpkı orijinal dosya gibi doğrudan beni diskteki verilere yönlendiren bir bağlantı adresi oluşturmuş oldum. 

Sembolik linkte nasıl oluyordu. Sembolik linkler, orijinal linklere yani aslında katı linkli dosyalara yönlendirme yapıyordu, oradan da disk üzerindeki verilere ulaşabiliyorduk.

Katı linkte ise hem orijinal dosya hem de yeni oluşturduğumuz katı link dosyası aynı disk verisinin yerini biliyor ve bizi oraya yönlendirebiliyor. 

Dolayısıyla ben orijinal veya bu yeni oluşturduğum katı link dosyasında değişiklik yaptığımda diskteki bu veri değiştiği için bu değişikliğe her iki dosya üzerinden de ulaşabiliyorum. Hatta orijinal dosya silinse bile yeni oluşturduğum katı link dosyası verilerin disk üzerinde tam olarak hangi bloklarda olduğunu bildiği için benim o verilere ulaşmam mümkün oluyor.

Hemen bu durumu bizzat teyit etmek için öncelikle basit bir test olarak yeni oluşturduğumuz katı link dosyası üzerinden yeni veri eklemeyi deneyebiliriz. 

Ben denemek için echo “yeni veri” >> kati-metin şeklinde komutumu giriyorum.

Tamamdır. Şimdi cat linkler/metin komutuyla orijinal dosyamızı okuyalım. Bakın eklediğim değişiklik burada da gözüküyor. Benzer şekilde echo “orijinal ekleme” >> linkler/metin şeklinde tekrar orijinal dosya üzerinden veri eklemeyi de deneyebiliriz. 

Hemen cat kati-metin komutu üzerinden kontrol edelim. Bakın orijinal dosya üzerindeki değişiklik bu dosyayı da aynen etkiliyor. Şimdi ben son olarak orijinal dosyayı sildiğimde bu diskteki bu verilere ulaşıp ulaşamayacağımı test etmek için rm linkler/metin komutunu girip orijinal dosyamı siliyorum.

Tamamdır. Ben kontrol etmek için cat kati-metin şeklinde yazıyorum. Bakın orijinal dosya silinmiş olmasına rağmen hala disk üzerindeki aynı verilere erişmeye devam edebiliyorum.

En nihayetinde gördüğünüz gibi aslında sistemiz üzerindeki standart dosya ve klasörler disk üzerindeki veri bloklarına yönlendirme yapan bağlantı adresleri. Biz bu bağlantı adresleri yani linkler sayesinde kolay okunabilir isimlerle diskteki verilerimizi düzenle tutup tekrar tekrar erişebiliyoruz.

Yeni katı link oluşturma yaklaşımı sayesinde disk üzerinde tekrar aynı veriler için fazladan depolama alanı harcanmasına gerek kalmadan, dosyaların yedeklerinin alınması mümkün oluyor. Daha önce de silme işleminin aslında verilere ulaşmamızı sağlayan bağlantıların silinmesinden ibaret olduğunu söylemiştik. Eğer verilere ulaşmamızı sağlayan birden fazla katı link olursa, bir katı link silinse bile diskimiz üzerindeki verilere ulaşmaya devam edebiliyoruz. Katı link yaklaşımı tam olarak bu amaçla kullanılıyor. Ve disk üzerinde fazladan depolama alını işgal etmeden yedeklemek için harika bir çözüm.

Tabii ki katı linkler örneklerimiz üzerinden bizzat teyit ettiğimiz gibi mevcut verilerin üzerine yazılmasına engel olmuyor. Yalnızca ilişkili verilere giden yolun silinmesi ihtimali için yedekleme imkanı tanıyor. Yani eğer üzerine veri yazılması konusunda endişe duyduğunuz verileriniz varsa tabii ki bunları başka bir dizine kopyalayıp tekrar aynı verilerin diskte farklı bloklarda yedeklenmesini sağlamanız gerekiyor. 

Son olarak dosya sisteminin yani hiyerarşik dizin yapısı gereği, klasörler için katı link oluşturmayacağımızı da belirtmek istiyorum. İnanmıyorsanız ln linkler/ linkler-kati komutuyla yeni bir tane oluşturmayı deneyebiliriz. Bakın dizinler için hard link yani katı linkler kabul edilmiyormuş. 

Umarım sembolik ve katı linklerin farkları ve kullanım biçimleri net bir biçimde anlaşılmıştır. Biraz pratik yaparsanız ve gerekiyorsa bu dersi baştan dikkatlice tekrar dinlerseniz aslında ne kadar kolay olduğunu zaten göreceksiniz. 

Ve artık böylelikle dosya işlemleri için bilmemiz gereken temel araçları tanıdığımıza göre bu bölümü sonlandırabiliriz.