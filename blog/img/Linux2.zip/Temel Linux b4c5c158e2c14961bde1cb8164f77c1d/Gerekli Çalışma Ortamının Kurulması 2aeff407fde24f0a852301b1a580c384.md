# Gerekli Çalışma Ortamının Kurulması

Bir önceki bölümde, neden Debian tabanlı bir dağıtım üzerinden ilerlememiz gerektiğini ele aldık. Eğitim boyunca ben Kali Linux üzerinden ilerleyeceğim için ben de yalnızca Kali Linux kurulumunu ele alacağım. Ancak merak etmeyin, eğer bu eğitimi Kali haricindeki bir dağıtım üzerinden takip edecekseniz benzer kurulum adımlarını izleyerek sizler de kullanmak istediğiniz dağıtımı kolaylıkla kurabilirsiniz. Ayrıca söz konusu kurulum olduğunda youtube üzerinde en güncel sürüm üzerinden ele alınan çok çeşitli video rehberler bulunuyor. Kurulum videolarına ulaşmak için kullanmak istediğiniz dağıtım özelinde kısa bir araştırma yapmanız yeterli. Yani lütfen bu kurstaki kurulum adımları ile sınırlı kalmayın, alternatifler için youtube dan faydalanın.

Profesyonel veya kişisel kullanım da dahil olmak üzere anlatımların herkese hitap edebilmesi için ben eğitim süreci boyunca grafiksel arayüzlü Kali Linux versiyonu üzerinden ilerleyeceğim. Zaten eğitim içerisinde ana odağımız komut satırı kullanımı olacağı için, Linux u temel düzeyde öğrendikten sonra ister grafiksel arayüzlü isterseniz de komut satırı arayüzlü sistemleri rahatlıkla yönetebiliyor olacaksınız. Ben şimdi kurulum yapacağımız ortamı belirlememize yardımcı olabilmesi için birkaç farklı kurulum alternatiften kısaca bahsetmek istiyorum.

# **Kurulum Alternatifleri Hakkında**

Söz konusu Linux olduğunda, çok fazla kurulum ve kullanım alternatifimiz bulunuyor. Ben sadece içlerinde bilmediğiniz bir alternatif seçenek olması ihtimaline karşı genel olarak bu kullanım yöntemlerinden bahsetmek istiyorum. Öncelikle kurulum metotlarını listeleyelim. Daha sonra zaten bu metotların avantaj ve dezavantjlarından da ayrıca bahsederek kısaca açıklıyor olacağım. Bu sayede hangi metodun size daha uygun olduğuna karar verebileceksiniz. Şimdi metot çeşitliliğinden haberdar olmak için yöntemleri listeleyecek olursak; 

## **Kurulum ve Kullanım Metotları**

- Sanal olarak kurulum (Vmware & Virtualbox)
    - Vmware veya virtulabox gibi sanallaştırma araçlarını kullanarak Linux u sanal olarak mevcut işletim sistemimiz üzerinden kurup kullanmamız mümkündür.
- İkincil işletim sistemi olarak kurmak (Dualboot)
    - Bilgisayarımızın sabit diskine tekil işletim sistemi olarak kurabileceğimiz gibi, mevcut sabit diski bölümleyerek ya da ikincil harici bir diske kurulum yaparak Linux’u ikincil işletim sistemi olarak kullanabiliriz.
- Live versiyon olarak kullanmak.
    - Tüm dağıtımlarda varsayılan olarak desteklenmese de yaygın kullanıma sahip dağıtımları herhangi bir kurulum yapmadan usb ya da dvd disk gibi aygıtlar üzerinden live yani canlı modda kullanmamız mümkündür.
- Linux VPS aracılığı ile kullanmak.
    - İstediğimiz özellikteki sunucuyu kiralayıp bu sunucu üzerinden de Linux işletim sistemini kullanabiliriz.
- WSL veya WSL2
    - WLS olarak geçen özellik sayesinde Windows üzerinden de yaygın kullanıma sahip çeşitli dağıtımları kullanmamız mümkündür.

Evet en genel haliyle tüm temel kullanım alternatifleri ve kısa açıklamaları bu şekilde. Kurulum alternatiflerinden haberdar olduk. Şimdi de sizin için hangi kurulum metodunun daha uygun olduğuna karar verebilmeniz için anlatımlarımıza biraz da bu metotların avantaj ve dezavantajlarından bahsederek devam etmek istiyorum. Hadi gelin sanal kullanımın avantaj ve dezavantajlarından bahsederek başlayalım.

---

### **Sanal Olarak Kullanmak;**

Profesyonel kullanımda farklı yaklaşımlar söz konusu olsa da s**anallaştırma işlemi kısaca;** kurmak istediğiniz yeni bir işletim sistemini, diske kalıcı kuruluma ihtiyaç duymadan, mevcut işletim sistemi üzerinden sanallaştırma teknolojisi ile çalıştırabilmeniz anlamına geliyor. Sanallaştırma teknolojisi sayesinde, kullanmakta olduğunuz işletim sisteminden çıkmadan, tıpkı program çalıştırır gibi; herhangi bir işletim sistemini sanal olarak çalıştırabilirsiniz. Sanallaştırma işlemini; bu iş için geliştirilmiş olan **vmware** ve **virtualbox** gibi çeşitli özel yazılımlar sayesinde kolayca uygulayabiliyoruz. Sanallaştırma işleminin avantajlarından bahsedecek olursak;

### **Avantajları**

- Sistemin yedeğini alarak, büyük bir sorun ile karşılaştığımızda aldığımız yedeği kolaylıkla geri yükleyebiliriz.
- Snapshot yani anlık görüntü özelliği sayesinde sistem çalışırken herhangi bir çalışma anını kaydedip, daha sonra istediğimiz zaman bu anlık görüntüyü kullanarak sistemi aynen en son anlık görüntüsü alındığı andan devam edecek şekilde kullanabiliyoruz. Bu durumu oyunlardaki checkpoint sisteminin çok daha esnek bir hali gibi de düşünebilirsiniz.
- Diske kalıcı kurulum gerektirmez, ve sanallaştırma yazılımını çalıştıran ana işletim sisteminin dosyalarına kesinlikle müdahale etmez. Tıpkı herhangi bir programı çalıştırırmış gibi sanal işletim sistemini kullanmanız mümkündür. Üstelik sanal işletim sisteminin sistem dosyaları kalıcı diske kurulumdaki gibi seçilmiş disk bölümüne yayılmaz. Sanal işletim sistemin disk üzerindeki tüm varlığı yalnızca sanallaştırma yazılımın okuyup çalıştırabildiği birkaç dosyadan ibarettir. Bunlar da sanallaştırma yazılımı için oluşturulmuş olan ilgili klasörün altında düzenli şekilde tutulur. Yani sanal sistemler disk üzerindeki mevcut sisteme hiç bir zarar vermeden sanal olarak çalışır. Herhangi bir programı çalıştırmak kadar kolay ve risksizdir.
- Eğer bilgisayarın donanım kaynakları müsaitse sanallaştırma sayesinde aynı anda birden çok işletim sistemini çalıştırabilir.
- Kendinize göre ayarladığınız sanal makineyi kopyalayıp istediğiniz bilgisayarda aynı şekilde çalıştırabilirsiniz. Yani oluşturduğunuz sanal çalışma ortamını taşınabilirdir aynı zamanda.

**Kısacası;** sanallaştırma, Linux’u yeni öğrenmeye başlayan kişiler için ideal bir test ortamı görevi görür. Örneğin snapshot ve yedekleme özellikleri sayesinde hatalardan kolaylıkla geri dönülmesi mümkündür. Eğer; mevcut sistemime zarar vermeden gönül rahatlığı ile sanallaştırma üzerinden Linux’u kurcalayayım, deneme yanılma ile öğreneyim derseniz "sanal olarak kullanım" sizin için biçilmiş kaftandır. Bizler de zaten tam olarak bu sebeple eğitim boyunca Linux işletim sistemini sanallaştırma yazılımı üzerinden kullanacağız. Ancak elbette tüm bu avantajlarının yanında elbette birkaç belirgin dezavantajı da bulunuyor. Kısaca bunlardan da bahsederek olası olumsuzluklardan da haberdar olalım.

### **Dezavantajları**

Esasen sanallaştırmanın sağladığı avantajların yanında, dezavantajlarının sayısı ve etkisi çok büyük sayılmaz. Yine de dezavantaj sayacak olursak;

- Sanal sistem mevcut işletim sistemi üzerinde çalıştığı için performans sorunları yaşanabilir. Elbette bu performans sorunları bilgisayarınızın sahip olduğu donanım gücüne ve sanal sistem için ne kadar kaynak ayırdığınıza göre değişiklik gösterir. Sahip olduğunuz donanıma göre sanal makinenin kaynaklarını doğru şekilde ayırdığınızda ortalama sistemlerde dahi sanal kullanım çok büyük performans sorunlarına neden olmaz.
- Performans sorunu dışında bir de belki diskte çok fazla yer kaplama sorunu ile karşılaşabilirsiniz. En nihayetinde sanal olarak da olsa, çalıştırdığınız dosya aslında bir işletim sisteminin sahip olduğu tüm bilgileri içeriyor. Dolayısıyla sanal dosyalar da bir işletim sistemi kadar yer kaplarlar. Özellikle sanal işletim sistemine çok fazla program veya dosya yükleyip bir de bu sanal sistemin birden fazla yedeği alındığında fiziksel disk üzerinde çok sayıda dosya olmasa da var olan dosyaların boyutları fazlaca yer kaplayabilir. Ayrıca bu duruma ek olarak örneğin birden fazla sanal makine oluşturulduğunda da doğal olarak disk alanı ve çalışma organizasyonunuz kötü etkilenebilir. Yine de sahip olduğunuz temel organizasyon becerisi ve yeterli disk kapasitesi ile bu da pek önemli bir sorun sayılmaz. Yani fiziksel diskinizdeki boş bulunan alana göre yedekleme ve yeni sanal makine kurulumlarını planlarsanız sanallaştırma dosyalarının boyutları da sizin için çok sorun olmayacaktır.

Tamamdır, en nihayetinde sanallaştırmanın avantajlarından ve dezavantajlarından tek tek bahsettik. Şimdi sanallaştırma teknolojisini nasıl yani hangi yazılımlar aracılığı ile kullanabildiğimizden de biraz söz edelim. Esasen söz konusu sanallaştırma olduğunda çeşitli alternatif yazılımlar bulunsa da bizler en sık tercih edilen "Vmware" ve "Virtualbox" araçlarından kısaca bahsedebiliriz. İlk olarak vmware yazılımından bahsedecek olursak:

***Vmware;*** içerisinde pek çok özelliği barındıran ücretli bir sanallaştırma yazılımıdır. Burada bahsi geçen özellikler genellikle işletmelerin işine yarayacak türdendir çözümler sunuyor. Eğer bireysel bir kullanıcıysanız muhtemelen bir çok ekstra özelliği hiç kullanmanız gerekmeyecektir. Ayrıca vmware aracının ücretsiz sürümü de bulunuyor ancak bu sürüm de genel olarak çok kısıtlı özellikle sahip olduğu için bireysel kullanımda dahi pek de verimli bir çalışma ortamı sunmayabilir. Örneğin ücretsiz sürümü yedekleme ve snapshot gibi özellikler sunmuyor. Ki bu özellikle öğrenme aşaması için gerçekten de çok önemli.

***Virtualbox:*** ise tamamen ücretsiz, vmware yazılımın ücretli sürümü ile hemen hemen aynı özelliklere sahip açık kaynaklı bir sanallaştırma yazılımıdır. Üstelik "Windows", "MacOS" ve "Linux" platformlarının hepsi üzerinden rahatlıkla kullanılabiliyor. Eğer bireysel bir kullanıcıysanız; virtualbox yazılımını tercih etmenizi öneririm. Vmware yazılımının ücretsiz sürümüne oranla virtualbox daha fazla işlevsel özellik sunuyor. Özellikle öğrenim aşamasındaki her türden bireysel kullanıcı için bence virtulbox yazılımı en ideal tercih.

Ben de bu eğitimde herkes tarafından kolay ulaşılabilir olması için yalnızca virtualbox aracı üzerinden sanal işletim sistemi kurulumunu ele alacağım. Ancak vmware aracının kullanımı da aşağı yukarı virtualbox ile benzer olduğu için kısa sürede kurcalayarak vmware aracının kullanımını da keşfedebilirsiniz. Anlatıma sabit diske kurulumdan bahsederek devam edebiliriz.

---

### **İkincil İşletim Sistemi Olarak Kullanmak**

Normalde standart şekilde bilgisayarımızdaki sabit diskte tekil olarak Linux kurup kullanabiliriz. Ancak bu her kullanıcı için uygun olmayabilir. Bazı durumlarda tek bir bilgisayarda birden fazla işletim sistemini kullanmamız gerekebilir. Bunun için diskinizde yeteri kalan alan varsa diskinizi bölümlendirerek mevcut işletim sistemini bozmadan yeni işletim sistemleri yükleyebilirsiniz. Örneğin windows kurulu bir bilgisayara ikincil işletim sistemi olarak Linux kurabilirsiniz.

Özetle b**u yöntem;** mevcut işletim sisteminin kurulu olduğu diskte yeni bölüm oluşturup, bu bolüme ikincil sistem olarak linux işletim sistemini kurmaktır. Bu kurulumun ardından sistem, başlangıçta hangi işletim sistemini kullanmak istediğinizi sorar ve seçiminize göre ilgili sistemi başlatır. Bu sebeple zaten bu yöntem dualboot olarak da biliniyor. Bu yöntemin avantajlarından bahsedecek olursak;

### **Avantajları**

- Sanal kuruluma oranla performans açısından oldukça verimlidir. Çünkü aynı anda hem ana işletim sistemi hem de sanal olmak üzere iki işletim sisteminin çalıştırılması gerekmiyor. Böylece bilgisayarın tüm kaynakları o an kullanılmakta olan tek bir sistem için ayrılabiliyor.
- Var olan sistemi silmeden ikincil bir sistem olarak yanına kurduğunuz için, ihtiyacınız olduğunda bilgisayarınızı yeniden başlatıp diğer sisteme de kolaylıkla geçiş yapabilirsiniz. Yani tek bir işletim sistemini kullanmak zorunda da değilsiniz. İhtiyaçlarınıza göre kolayca bir diğerine geçiş yapabilirsiniz.

Kısaca dezavantajlarından da bahsedecek olursak;

### **Dezavantajları**

- Sistem yedeğini almak ve ilgili yedeğe dönmek, sanal kullanıma oranla daha zahmetlidir.
- Snapshot özelliği olmadığından sistemde herhangi bir kritik hata meydana geldiğinde, sistemi onarması çok daha uzun sürebilir. Bu durum özellikle yeni öğrenmeye başlayan kullanıcılar için gerçekten heves kırıcı ve göz korkutucu olabilir.
- Kurulum işlemi ve kurulum sonrası sistem ayarlarının yapılandırılması, diğer kurulum işlemlerine oranla biraz daha uğraştırıcı olabilir. Ayrıca hatalı yapılandırma sonucu, diskte yer alan diğer işletim sisteminin dosyalarına zarar verebilme ihtimali de vardır.

Bu dezavantajları ele aldığımızda yeni başlayan kullanıcılar için Linux’u tekil veya ikincil bir sistem olarak kullanmak pek de mantıklı olmayacaktır. 

Öğrenme aşamasında, kullanıcıların hata yapması çok doğal bir durumdur. Zaten etkili öğrenim için sizlerin de bildiği üzere pratik yaparak ilerlemek gerekiyor. Pratiklerimiz esnasında sürekli deneme yanılma yöntemiyle sistemi bozmaktan korkmadan ilerlemek eğitimin verimi için çok önemli. Bu yolla edinilen bilgiler de zaten çok daha kalıcı oluyor. Sistemin kullanımı sırasında meydana gelebilecek olası hatalar, yeni başlayan kullanıcıların öğrenme şevkini kırarak öğrenme sürecini sekteye uğratabilir. Bu sebeple eğer Linux işletim sistemini ilk defa kullanacaksınız, daha hızlı ve etkili öğrenebilmek için bu yöntemi yani “İkincil İşletim Sistemi” alternatifini sizlere önermiyorum. Özellikle kurulum aşamasında deneyimsizlik ve olası uyumsuzluklardan dolayı pek çok sorun çıkabileceği için ben bu yöntemi ele almayacağım. Çünkü var olan sisteminize de zarar vermenizi veya henüz eğitimin başında sorunlarla boğuşup şevkinizin kırılmasını istemiyorum. Özellikle sabit diske kurulum sırasında oluşabilecek sorunlar konusunda sorumluluk almak istemediğim için bu eğitimde sabit diske kurulumu ele almayı planlamıyorum. Ancak sanal olarak kullandığınızda sistem performansı sizin için çok sorun oluyorsa, yani eğitime devam edemeyeceğiniz kadar sorun oluşturuyorsa elbette sabit diskinize kurulum yaparak da Linux'u kullanabilirsiniz. Kurulum işlemi için Youtube gibi harici bir kaynağı kullanarak tüm adımları dikkatlice tamamlamanızı önerebilirim. Yine de yeni başlayan kullanıcıların bu kullanım yönteminden önce diğer kullanım alternatiflerini de değerlendirmesi faydalı olacaktır. Bu sebeple lütfen kurulum alternatiflerini ele aldığımız bu açıklamaların tamamını dinleyip sizin için en ideal olan yönteme kendiniz karar verin. Şimdi anlatımımıza live yani canlı kullanımdan bahsederek devam edelim.

---

### USB üzerinden **Live Versiyon Olarak Kullanmak**

Live olarak kullanmak; Linux işletim sistemini USB diskimiz üzerine kurup, sistemi bu USB disk ile başlatıp kullanabildiğimiz alternatiftir. Bu kullanım alternatifinde tüm dosyalar geçici olarak tutuluyor, sistemi kapattığımızda tüm veriler sıfırlanıyor. Zaten canlı mod denmesinin nedeni de budur. Geçici işlerimiz için veya sistemleri sabit diske kurmadan önce deneyimleyip tanımak için kullandığımız bir yöntemdir. Üstelik söz konusu USB üzerinden Linux kullanmak olduğunda aslında yalnızca Live olarak bahsettiğimiz bu kullanım metoduyla da sınırlı değiliz. Uygun dağıtımlarda doğru ayarlamalar yapıldığında sistem kapatılırken usb üzerinden dosyaların silinmediği yani kalıcı olarak Linux sistemini kullanabileceğimiz alternatifler de bulunuyor.

Usb üzerinden kullanma seçeneğini, sanal kullanımda eğitime devam edemeyecek kadar performans sorunu yaşayanlara ve sabit diskine kurmak istemeyenlere önerebilirim. Kısaca USB üzerinden kullanımın avantajlarına değinecek olursak;

### **Avantajları**

- Sabit diske kurulum gerektirmez, yalnızca USB disk yeterlidir. Bu sayede sabit diskinizde ek alan ayırmak zorunda kalmazsınız.
- Farklı amaçlarla kullanılabilmesi için kendi içinde canlı, kalıcı ve şifreli olmak üzere birden fazla kullanım modu vardır.
- Usb disk taşınabilir olduğu için pek çok farklı bilgisayardan kuruluma gerek kalmadan Linux sistemini kullanmaya devam edebilirsiniz. Sabit disklerden ziyade usb diskler daha taşınabilir ve kolay takılabilir olduğu için her zaman yanınızda taşıyabileceğiniz Linux sistemine sahip olabilirsiniz.

Biraz da dezavantajlarına değinmemiz gerekirse;

### **Dezavantajları**

- Usb üzerinden kullanımda verim alabilmek için USB diskinizin en az 8 GB lık depolama kapasitesi olması gerekiyor. Ve ayrıca mümkünse okuma yazma hızı yüksek olan bir usb aygıtı kullanmalısınız. Eğer kullanacağınız USB aygıtın okuma yazma hızı düşükse sistem performansı oldukça kötü etkilenebiliyor. Çünkü okuma yazma hızı düşük olan bir depoloma birimi kullanıldığında, ram ve cpu gibi bileşenlerin iyi olması okuma yazma hızının oluşturacağı darboğaz dolayısıyla sistem performansına olumlu katkı sunamıyor maalesef. Yani aslında okum yazma hızı dolayısıyla standart usb diskler ile sabit diske kurduğumuzdaki kadar verimli bir sistem elde edemeyiz.
- Diğer bir dezavantaj ise sistemi usb disk üzerinden başlatmak için bir kaç ön hazırlığın gerekmesidir. USB diskin kullanılacağı sistemin bios ayarlarından bu usb diskin sorunsuzca boot edilebilmesi için değiştirilmesi gereken ayarlar vardır. Yine de ne yaptığınızı biliyorsanız bu durumda büyük bir zorluk sayılmaz.
- Belki de en kritik olan dezavantaj ise eğer bilinçsizce hareket ederseniz usb diski bağladığınız bilgisayardaki disklerden verilerin silinmesine sebep olabileceğinizdir. Çünkü usb diski doğrudan bilgisayara bağlayıp kullanıyor olacaksınız. Eğer farkında olmadan usb diski bağladığınız bilgisayardaki sabit disk üzerinde işlemler yaparsanız verilerin silinmesine sebep olabilirsiniz. Elbette ne yaptığının bilincinde olan kullanıcılar için bu gibi bir hata pek olası olmasa da henüz öğrenme aşamasının başındaki kişilerde özellikle de disk işlemleri yapılırken bu gibi hataların yapılması olasıdır. Bu bakımdan usb üzerinden kullanım tıpkı sabit diske kurulumda da olduğu gibi sanal olarak kullanım kadar izole değildir.

Genel olarak usb üzerinden kullanımın avantajları ve dezavantajları bu şekilde. Şimdi VPS kullanımından bahsederek devam edelim. 

### **VPS Üzerinden Kullanım**

VPS ifadesi virtual private server ifadesinin kısaltmasıdır. VPS sunucular en basit tabirle; fiziksel bir sunucunun sanallaştırma yazılımları ile birden fazla alt sanal sunucuya bölündüğü yapıdır. Her bir sanal sunucu birbirinden bağımsızdır ve kendisine ayrılmış kaynak kadar tüketimde bulunabilir. İşte bizler de çeşitli servis sağlayıcılarına kirasını ödeyerek istediğimiz özelliklerdeki sanal sunuculara uzak bağlantı ile bağlanıp istediğimiz yerden yönetebiliyoruz. VPS servisleri özellikle kesintisiz hizmet vermeyi gerektiren websitelerin ve servislerin barındırılması gibi işler için kullanılsa da, elbette kişisel amaçlarımız için de istediğimiz şekilde kullanabiliriz. Yani özetle bu servisler sayesinde fiziksel olarak sahip olmadığımız bilgisayarları, uzaktan bağlanıp yönetebiliyoruz. Bu yöntemde ister bilgisayar ister telefon isterseniz de internete bağlanabilen başka bir araç ile kiraladığınız sunucuya bağlanıp sisteminizi kolayca yönetebilme esnekliğine de sahip oluyorsunuz.

Fiziksel olarak iyi özelliklere sahip olan bir bilgisayarınız olmadığında kira bedelini karşılayabilecekseniz google cloud aws digitalocean, linode veya alternatif yerel hizmet sağlayıcılar üzerinden istediğiniz özelliklerde VPS kiralayabilirsiniz. Hangi servisi tercih ederseniz edin servisleri incelerken zaten ubuntu centos ve benzeri pek çok dağıtımın seçenek olarak sunulduğunu göreceksiniz. Siz dilediğiniz bir dağıtımı seçip, dilediğiniz sistem kaynakları ile bu sistemi uzaktan yönetebilme imkanına sahipsiniz. Bu eğitimi mümkünse ubuntu, eğer değilse debian ya da redhat tabanlı dilediğiniz bir dağıtım üzerinden uzaktaki sunucuya bağlanarak takip edebilirsiniz. Ben doğrudan bir hizmet sağlayıcı önerisinde bulunmuyorum. Biraz araştırırsanız kendinize uygun olana karar verebilirsiniz. Kimi servisler geçici süreli ücretiz deneme imkanları da sunuyor. Ayrıca kullandığınız kadarını ödediğiniz için çok cüzi maliyetler ile istediğiniz özellikte sistemler kiralayabilirsiniz.

Aslında açıklama esnasında az çok değinmiş olsak da bir kez daha kısaca VPS kullanım avantajlarından madde madde bahsedelim.

### **Avantajları**

- Mevcut donanımınızın çok güçlü olması gerekmez. Tek ihtiyacınız olan uzak sunucuya bağlanıp komut girebileceğiniz basit özellikteki cihazdır.
- İstenilen yerden ve istenilen cihazdan(*pc, laptop, tablet, telefon..*) uzak sunucudaki sisteme komut verilebilir. Cihaz bağlamında esneklik sunuyor yani.
- Kullandığınız servise göre değişiklik gösterse de servis sağlayıcının sunduğu imkanlar dahilinde sistem yedeği alma ve üst düzey sistem performansı imkanına sahip olabiliyorsunuz. Sunucu özelliklerine bakarsanız, kullanılan disk tipi gibi donanımsal tercih imkanlarınız olduğunu da görebilirsiniz. Hız için ssd disklerin tercihi gibi imkanlarını da var yani.

### **Dezavantajları**

- Bu hizmetler ücretlidir. Eğer ihtiyacınızdan fazla özelliklerde hizmetler kiralarsanız gereksiz harcamalara sebep olabilirsiniz.
- Servislerin kullanımı her ne kadar kolay olsa da Linux ile yeni tanışan kullanıcılar için öncelikli olarak tercih edilecek bir yöntem değildir. Çevrimdışı olarak erişememe dezavantajının yanında, gerektiğinde yüksek sistem kaynakları ve test için disk ekleme gibi ek faaliyetler gerekeceği için eğitimi VPS üzerinden takip etmekte zorlanabilirsiniz.

# WSL ve WSL2

WSL ifadesi windows subsystem for linux ifadesinin kısaltmasından geliyor. WSL özelliği herhangi bir sanallaştırma aracı kullanmadan windows üzerinde linux işletim sistemini entegre şekilde kullanabilmemize olanak sağlayan özelliktir. Bu özellik sayesinde Microsoft’un mağaza uygulaması üzerinden ubuntu kali fedora gibi yaygın kullanıma sahip birkaç farklı dağıtımın indirilip kullanılması mümkündür. Sanallaştırma yazılımına gerek kalmadığı için windows üzerinden istediğiniz zaman açıp kullanabileceğiniz kullanışlı ve nispeten sanallaştırmaya oranla daha performanslı bir alternatiftir. Yine de ben yeni başlayan kullanıcılara zorunda olmadıkça ilk aşama için bu kullanım yöntemini pek önermiyorum. Çünkü sanallaştırmanın sağladığı yedekleme kolaylıklarından mahrum kalınıyor. Ve ayrıca wsl kullanırken mevcut sistemin dosyalarına zarar verme ihtimaliniz diğer seçeneklere oranla daha yüksektir. 

Bu durumlar Linux sistemini yeni öğrenen kişilerin hata yapmaktan kaçınarak sistemi yeterince kurcalayıp hakkıyla öğrenememesine neden olabilir. İşletim sistemini etkili kullanma yetisi, sistemi kurcalayıp gerektiğinde bozmak ve bozuk sistemi tekrar onarmaya çalışmakla edinilen tecrübelerden gelir. Dolayısıyla hata yapmaktan korkacağınız bir ortamda verimli çalışamazsınız. Elbette temel eğitimden sonra dilerseniz WSL yöntemini de kullanabilirsiniz. Özellikle windowsa sık ihtiyaç duyuyorsanız ama linux da kullanmanız gerekiyorsa wsl gerçekten çok verimli bir alternatif. Ben sadece Linux u yeni öğrenmeye başlayacak kişilere sanallaştırma üzerinden çalışmanın daha özgür bir çalışma ortamı sunacağını düşündüğüm için wsl kullanmanızı önermiyorum. Yine de kullanmak istiyorsanız ve kendinize de güveniyorsanız wsl üzerinden de bu eğitimi pekala takip edebilirsiniz. Size tavsiye ettiğim sanallaştırma ortamının kullanımını, ilk kez bisiklete binen çocukların bisikletlerini destek tekerlekleri ile yani 4 tekerlekli şekilde kullanması ve kendilerini hazır hissettiklerinde 2 tekere geçmesi olarak düşünebiliriz. Düşme kalkma aşamasında başımıza gelenlerin bizi Linux sisteminden soğutmasına izin verirsek, kaybeden biz oluruz. 

Evet en nihayetinde genel olarak tüm kullanım alternatiflerinden kısaca bahsetmiş olduk. 

Ben eğitimi herkesin kolaylıkla takip edebilmesi ve en azından öğrenme aşamasında güvenli bir ortamda çalışabilmek için sanal olarak kurulumu ele alacağım. Ancak sizler dilerseniz diğer alternatif kurulum yöntemleri için internet üzerinde sayısız yerli ve yabancı kaynak bulabilirsiniz. Ben eğitim boyunca çalışma ortamı olarak açık kaynaklı virtualbox sanallaştırma yazılımı üzerinden Kali Linux dağıtımını kullanacağım. Sizler kendiniz için uygun olan alternatif ortamları kullanabilirsiniz. Ancak sizleri şimdiden temin ederim, eğitimin sonunda temel linux bilgisine sahip olacağınız için tüm alternatif kurulum yöntemleri sizler için son derece basit ve anlaşılır olacaktır. Bu sebeple ben eğitimin başında hepsine tek tek değinerek vakit kaybetmek istemiyorum. Alternatiflerini kullanmak isteyen arkadaşlar internetten araştırıp bulabilirler. Zaten Linux kullandığınız sürece genellikle kendi başınızın çaresine bakmanız gerekeceğinden kendi kendinize internet üzerinden araştırma yapıp aradıklarınızı bulabilme yetisine sahip olmanız veya geliştirmeniz şart. Ancak bu sayede sürekli gelişebilir ve karşınıza çıkan her türlü problemin üstesinden gelebilirsiniz. Her neyse lafı çok uzattım. Şimdi öncelikle virtualbox sanallaştırma yazılımının kurulumunu ele alarak başlayalım. Daha sonra virtualbox üzerinden Kali Linux’u sanal olarak sistemimize kurmayı ele alacağız.