# Disk Yönetimi

/dev/null gibi sanal dosyalar geleneksel dosyalar gibi değildir. /dev/ dizini, devfs (device-filesystem- Cihaz Dosya Sistemi) sözde pseudo-filesytem dosya sistemi için bir bağlama noktasıdır. Devfs biçimini kullanmak, her cihazı bir dosya olarak görüntüleyen bir cihaz yöneticisi görevi görür. Bu sözde/sanal dosya sistemi sabit sürücüde değil. Hafızadadır. /dev'deki dosyalar, cihazlara yazılım ve işlem erişimi sağlamak için çekirdek tarafından oluşturulur. /dev/dizinindeki boş dosyanın boyutu yoktur, oluşturulma tarihi sistemin açılış zamanı ile aynıdır ve tüm kullanıcılar için okuma ve yazma izinlerine sahiptir.

[https://superuser.com/questions/1065731/does-writing-to-dev-null-or-nul-affect-the-hard-drive](https://superuser.com/questions/1065731/does-writing-to-dev-null-or-nul-affect-the-hard-drive)

RAID (Redundant Array of Inexpensive Disks) Linux sistemlerde birden fazla diskin birlikte kullanılmasını sağlar. RAID seviyeleri olarak adlandırılan farklı tasarımlar mevcuttur ve her seviye farklı amaçlar için kullanılır. Örneğin, RAID 0 veri hızlandırma amacına yönelikken, RAID 1 veri güvenliği amacına yöneliktir.

RAID 0 (Striping): Veri birden fazla disk arasında eşit olarak bölünür ve yazılır. Bu seviye veri hızlandırma sağlar ancak tek bir disk arızası halinde tüm veriler kaybolur.

RAID 1 (Mirroring): Veri birden fazla disk üzerine aynı şekilde yazılır. Bu seviye veri güvenliği sağlar ancak veri hızlandırma sağlamaz.

RAID 5 (Parity Striping): Bu seviye verinin bir kısmı bir diskte yedek olarak saklanır. Bu sayede tek bir disk arızası halinde veriler geri yüklenebilir.

RAID 6 (Double Parity): RAID 5'e benzer şekilde verinin bir kısmı bir diskte yedek olarak saklanır ancak bu seviye iki disk arızasına karşı da dayanıklıdır.

Linux sistemlerde RAID yapılandırması genellikle mdadm (Multiple Device Administrator) adlı bir araç kullanılarak yapılır.