# Temel Ağ Komutları

[https://gelecegiyazanlar.turkcell.com.tr/konu/egitim/temel-network-egitimi/temel-network-egitimi-hakkinda](https://gelecegiyazanlar.turkcell.com.tr/konu/egitim/temel-network-egitimi/temel-network-egitimi-hakkinda)

Bu bölüm içerisinde ağ hakkında çok temel düzeyde bilgi almamızı sağlayan bazı araçlardan bahsedeceğiz. Ancak tabii ki ağ konusu başlı başına öğrenilmesi gereken bir konu olduğu için bu bölümde ben network temellerine değinmeyeceğim. Eğer network konusunda temel seviye bilginiz yoksa, ücretli ve ücretsiz pek çok temel eğitim kaynağı var. Bu eğitim standart linux kullanıcılarını da kapsadığı için ben yalnızca herkesin işine yarayabilecek bazı ağ araçları hakkında çok kısaca bilgi vermeyi planlıyorum. 

Network konusunu başlı başına bir uzmanlık alanı olduğu için ve mevcut eğitimin herkese hitap edebilecek düzeyde olması için ben çok kısaca birkaç konudan bahsediyor olacağım. Öncelikle en temel araçlardan biri olan ip aracından bahsederek başlayabiliriz.

# ip Komutu

ip komutu ağ arayüzlerini yapılandırmak için kullanabildiğimiz çok kullanışlı bir araç. Aracımızın çok fazla seçeneği olduğu için öncelikle sahip olduğu seçenekleri görmek için yalnızca ip komutuyla listeleyelim.

Bakın burda komutun temel kullanım şablonu açıklanmış. ip komutundan sonra ilgili seçeneği ve objeyi belirtebiliyoruz. Seçeneklerin ve objelerin yani aslında yönetmek istediğimiz nesnelerin hangileri olduğu burada gözüküyor.

Örneğin bakın link ile mevcut ağ arayüzlerini görüntüleyip düzenleme yapabiliyoruz.

Benzer şekilde address ile ip adreslerini görüntüleyip düzenleme imkanımız da var.

Buradaki her bir nesne özel amaca hizmet eden işlevlerin temsilleri.

ssh

scp

wget

ip 

ifconfig - interface config 

ipconfig -ip config windows

As a Linux system administrator, there are several key concepts and technologies related to networking that you should be familiar with.

- IP addresses and subnetting: You should have a solid understanding of IP addresses and how they are used to identify devices on a network. You should also be familiar with subnetting, which is the practice of dividing a larger network into smaller subnetworks.
- Network interfaces and routing: You should be familiar with the various network interfaces that are available on Linux systems, such as Ethernet, WiFi, and virtual interfaces. You should also be familiar with routing, which is the process of forwarding data between networks.
- TCP/IP stack: The Transmission Control Protocol/Internet Protocol (TCP/IP) stack is the foundation of modern networking. You should be familiar with the different layers of the stack, such as the application layer, transport layer, network layer, and data link layer, and how they interact to transmit data.
- Network services and protocols: You should be familiar with the common network services and protocols that are used on Linux systems, such as DNS, DHCP, FTP, SSH, and SMTP. You should also be familiar with firewalls and security protocols, such as iptables and OpenVPN, to secure your network.
- Network troubleshooting: As a system administrator, you will likely be responsible for troubleshooting network issues. You should be familiar with common network troubleshooting tools, such as ping, traceroute, netstat, and tcpdump, and know how to use them to diagnose and resolve problems.
- Network monitoring and performance tuning: You should be familiar with tools and techniques for monitoring network performance, such as sar, netstat, iostat, and vmstat. You should also be familiar with various network performance tuning techniques, such as adjusting buffer sizes, increasing the maximum number of connections, and adjusting the size of the routing table.
- Virtualization and Cloud networking: With the increasing adoption of virtualization and cloud, it is important for a Linux administrator to have knowledge on virtual networking and cloud networking. Understanding concepts such as VLANs, VPN, VXLAN, Cloud load balancer etc.

It's important to note that networking is a vast field with many sub-topics. It's a good idea to start with basics and gradually learn more advanced topics as you gain more experience.