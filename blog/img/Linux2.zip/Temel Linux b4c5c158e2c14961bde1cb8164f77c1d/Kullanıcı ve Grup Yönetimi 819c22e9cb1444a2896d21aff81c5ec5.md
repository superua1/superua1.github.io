# Kullanıcı ve Grup Yönetimi

# Kullanıcılar

Bu bölüm içerisinde Linux sistemindeki kullanıcı ve grup yönetimi gibi kavramlara değinip yetkiler üzerine konuşacağız. 

Sistem kaynaklarına erişimi olan ve sistemini yetkileri dahilinde yönetenlere genel olarak kullanıcı diyoruz. Linux'ta "süper(**SuperUser**
)", "sistem(System User)" ve "normal(Normal User)" olmak üzere üç tür kullanıcı bulunuyor. Şimdi sırasıyla bu kullanıcıları açıklayacak olursak.;

Süper Kullanıcı: Süper kullanıcı aslında daha çok root yani kök kullanıcı olarak bilinen, sistem üzerindeki tüm haklara sahip olan en yetkili kullanıcı hesabına verilen bir isim. Yani biz root hesabını kullanıyorken, sistemdeki en yetkili olan süper kullanıcı hesabını yönetiyor olacağız. 

Sistem Kullanıcısı: Yazılım veya uygulamalar tarafından oluşturulan ve yönetilen kullanıcılara da sistem kullanıcısı deniyor. Örneğin sistemimizde saatin senkronize edilmesini sağlayan ntp isimli bir araç yüklüyse bu aracın görevini yerine getirmek için kendisine ait bir sistem kullanıcı hesabı bulunuyordur. Bu sayede gerektiğinde bu kullanıcı hesabı üzerinden görevlerini yerine getirebilir. Tabii ki tüm araçların kendilerine ait kullanıcı hesapları olmasa da işte tıpkı ntp aracında olduğu gibi sistemdeki çeşitli yazılımların, işlerini görmek için kendi kullanıcı hesapları olabiliyor. Bu hesaplar insanların değil yazılımların sistemi yönetmek için kullandığı türden hesaplardır. Bu sebeple bu tür hesaplara sistem kullanıcı hesabı deniyor. Bu kullanıcıların yetkileri yalnızca görevlerini yerine getirebilecekleri düzeyde olduğu için doğrudan yetkileri olmayan işler yapamazlar.

Normal Kullanıcı: Normal olarak geçen kullanıcı hesapları kök kullanıcısının oluşturduğu standart kullanıcı hesaplarıdır. İnsanların sistemi kullanması ve yönetmesi için oluşturulan hesaplardır. Bu tür hesapları insanlar kullanacağı için normal kullanıcılar kendi ev dizinlere sahiptir. Yani genellikle home dizini altında kullanıcı isimleriyle oluşturulmuş olan bir klasörde kişisel dosyalarını barındırmaları için bir ev dizinleri vardır. Ev dizini insanların kişisel dosyalarını düzenli şekilde tutabilmeleri ve kendi kullanıcı hesaplarına yönelik kişiselleştirilmiş çalışma ortamına sahip olabilmeleri için önemli bir yaklaşım. Ev dizinin ne olduğunu biliyorsunuz zaten. Örneğin yazılımların kullanımı için oluşturulan sistem kullanıcılarının ev dizini yoktur. Çünkü yazılımların insanlar gibi kişisel dosyalarını barındırmak için ev dizinine ihtiyaçları yoktur.  

Ev dizinleri dışında tabii ki normal kullanıcılara da sahip oldukları yetkiler dahilinde sistemdeki araçları kullanabilirler. Yetkileri düşük veya yüksek olmasına göre sistem üzerinde yetkileri dahlinde hareket edebilirler. 

# Sudo Komutunu Anlamak

Sistemde en yetkili kullanıcının root olduğunu öğrendik. Sistemi yönetirken de yetki gerektiren işlemler yapmamız gerebilir. Bu durumda görevi yerine getirmek için root hesabına geçiş yapabiliriz. Ancak root hesabındayken, tüm yetkilere sahip olacağınız için, hatalı şekilde kritik dosyaları silmenizi önleyecek veya sistemin işleyişine zarar verecek bir eyleminizde sizi uyaracak hiç bir mekanizma yoktur. Çünkü root hesabını yalnızca gerektiğinde kullandığınız ve ne yaptığınızı bildiğiniz varsayılır. root hesabını kullanmak tehlikeli olabileceği için çoğu sistemde root hesabı pasif şekilde gelir. Siz aktifleştirmediğiniz sürece root hesabı kullanılamaz. Buna karşın root hesabı aktif olmasa bile yetki gerektiren işlerimiz için geçici olarak root  yetkileri ile hareket edebilmemizi sağlayan sudo komutunu kullanabiliyoruz. sudo sayesinde root hesabı aktif değilken veya root aktifse bile root hesabının şifresini bilmeden yönetici ayrıcalıkları ile işlerimizi yürütmemiz mümkün oluyor. Elbette hangi kullanıcıların hangi ayrıcalıklara erişebileceğini belirlemek için yapmamız gereken konfigurasyonlar bulunuyor. Fakat daha net anlaşılabilmesi için ileride sudo komutuna birkaç kavramı açıkladıktan sonra tekrar değineceğiz. Şimdilik sudo komutunun kullanıcıya işlemleri yetkili şekilde gerçekleştirebilme imkanı tanıdığını bilmemiz yeterli. Hatta hemen basit bir örnek olarak root kullanıcısının ev dizini görüntülemeyi deneyebiliriz. Ben görüntülemek için ls /root komutunu giriyorum. Bakın erişim hatası aldık. Şimdi aynı komutu sudo komutu başta olacak şekilde tekrar girelim. Buraya kendi hesabımın parolasını girmem gerekiyor. Güvenlik için parola yazarken gözükmüyor, gözükmese de yazmaya devam edin lütfen.

Parolamı doğru yazdığım için bakın yetkili şekilde /root dizinin içeriğini görüntüleyebildim. İşte sudo komutunun en temel kullanımı bu şekilde. şimdilik bu kadarlık bilgi de yeterli. Gelin nasıl yeni bir kullanıcı hesabı oluşturabileceğimizden bahsederek devam edelim.

# Kullanıcı Hesabı Oluşturmak

Yeni bir kullanıcı hesabı oluşturmak istiyorsak, kullanıcı hesabı oluşturabilecek yetkimizin olması gerekiyor. Ben daha önce yalnızca root hesabının yani en yetkili kullanıcının yeni hesap oluşturabileceğini söylemiştim. Bu durumun bir istisnası bulunuyor. Eğer normal bir kullanıcı root hesabının bulunduğu yetki grubuna dahil edildiyse bu kullanıcı root gibi davranarak yetki gerektiren işlemleri yapabilir. Bir işlemi yetkili şekilde yerine getirmek için de sudo komutunu kullanıyoruz. Zaten sudo komutuna da kısaca değindik. 

Yeni bir hesap oluşturmak için ,"adduser" ya da "useradd" komutlarından herhangi birini kullanabiliyoruz. adduser daha kullanışlı olduğu için benim öncelikli tercihim adduser aracıdır. Yine de ikisi ben ikisini de kısaca ele alacağım. Öncelikle adduser aracını kullanalım.

## adduser

Ben nil isminde yeni bir kullanıcı oluşturmak istiyorum. Bunun için sudo adduser nil şeklinde komutumu giriyorum. Eğer sudo komutunu kullanmazsak, yetkimiz olmadığı için işlem başarısız olur. Ben mevcut kullanıcı hesabımın parolasını giriyorum.

Bakın belirttiğim isimde yani nil ismiyle kullanıcını eklendiği

nil isimli yeni bir grup oluşturulduğu

nil nin bu gruba eklendiği

nil’nin ev dizinin /home/nil dizininde oluşturulduğu 

Ve ev dizinine /etc/skel dizinindeki dosyaların kopyalandığı belirtilmiş. Bu /etc/skel klasörü standart kullanıcılar için gerekli olan temel dosyaları barındıran bir klasör. Zaten ev dizinin temel iskeletini oluşturmaya atıfta bulunmak için klasörü ismi de ingilizce iskelet ifadesinden geliyor. 

Her neyse, şimdi bizden bu kullanıcının parolasını tanımlamamız bekleniyor. Ben parolayı giriyorum. İkinci kez de yazıp onaylayalım. Şimdi eğer istersem kullanıcıyla ilgili burada bana sorulacak olan ek kişisel bilgileri doldurabilirim. Şuan için pek gerekli değil o yüzden enter ile tüm soruları geçiyorum. Tabii ki siz dilerseniz doldurabilirsiniz. Son olarak bilgileri de onaylayıp işlemi tamamlıyorum. Böylelikle nil kullanıcı hesabı oluşturulmuş oldu. Teyit etmek için ls /home/ komutuyla ev dizinin içeriğini sorgulayalım. Bakın home dizini altında nil isimli kullanıcının ev dizini oluşturulmuş. İşte adduser komutu ile kullanıcı oluşturma işlemi bu şekilde. 

Bir sonraki derste de useradd komutu ile başka bir kullanıcı daha oluşturalım.

## useradd

Normalde useradd komutunu kullandığımızda, biz özellikle belirtmezsek, adduser komutunda olduğu gibi kullanıcının ev dizini oluşturulmuyor. 

Kullanıcının ev dizinin de oluşturulması için özellikle komutumuzu useradd -m kullanıcı adı şeklinde girmemiz gerekiyor. Ben ali isimli bir kullanıcı hesabı oluşturmak istiyorum. Bunun için useradd -m ali şeklinde komutumu giriyorum. Bakın hiç bir çıktı almadık, bize ne şifre sordu ne de başka bir bilgi yalnızca kullanıcı sisteme eklendi. Eklendiğini de home dizinini listeleyerek teyit edebiliriz. Bu kullanıcının bir parolası olmadığı için tabii ki şu an bu hesapta oturum açamayız. Bu kullanıcı hesabına parola tanımlamak için de passwd komutunu kullanabiliriz. Ben sudo passwd ali şeklinde yazıyorum.

Parolamızı tanımlayalım.

Parolayı ikici kez yazıp onaylıyorum. Böylelikle ali kullanıcısı için de bir parola tanımlamış olduk. Sizlerin de fark etmiş olduğu gibi ele aldığımız önceki araç yani adduser komutu çok daha kullanıcı dostu bir kullanım imkanı sağlıyor. Çünkü ev dizinini otomatik oluşturup parola oluşturmamız için bizden talepte bulunuyor ve kullanıcıyla ilgili diğer çeşitli bilgileri de sorup doldurmamızı sağlıyor. Bu sebeple zaten yeni kullanıcı oluşturmak için genellikle adduser aracı tercih ediliyor.

Neticede kullanıcı oluşturmanın en temel iki yolundan bahsetmiş olduk. Şimdi hazır kullanıcı oluşturmaktan bahsetmişken, kullanıcı hesaplarıyla ilişkili olan birkaç dosyadan da bahsetmek istiyorum. Anlatımlarımıza daha önce birkaç kez gördüğümüz /etc/passwd dosyasından bahsederek başlayabiliriz. Öncelikle dosyamızı açıp içerisine bir bakalım.

### /etc/passwd

Bakın dosyanın sonuna, yeni eklemiş olduğum iki kullanıcı hesabı için iki satır daha eklenmiş. Bu dosyada, sistemdeki her bir kullanıcı hesabının soldan sağa sırasıyla; ismi, parolası, kullanıcı numarası, grup numarası, hesap bilgileri(hesap bilgilerinden kastım, adduser komutuyla bize sorulan tam isim, telefon numarası, oda numarası gibi bilgiler), ev dizini ve varsayılan kabuk programını bilgisini satırlar halinde tutuluyor. Biz adduser ya da useradd gibi araçları kullanarak kullanıcı oluşturduğumuzda aslında araçların yaptığı işlerden biri de bu dosyaya ilgili kullanıcı hesabının detaylarını eklemek oluyor.

Örneğin bakın adduser komutu ile oluşturduğumuz nil kullanıcısının kabuğu varsayılan olarak bash kabuğu olarak ayarlanmışken, useradd komutu ali kullanıcısının varsayılan kabuğunun sh olarak tanımlamış. Farklı kabukları tanımlamış olsalar da neticede her iki araç da kullanıcı bilgilerini bu dosyaya eklemiş. Listenin geri kalanına baktığımızda mevcut kullanıcı hesabımıza ek olarak, farklı araç ve yazılımların sistem kullanıcı hesaplarının da aynı şekilde bu listede olduğunu görebiliyoruz. Yani bu dosya mevcut sistemdeki tüm kullanıcı hesaplarının temel bilgilerini barındıran dosyamız. 

Bu dosya kullanıcıların hesap detaylarını barındırdığı için dosya içerisinde yaptığımız değişiklikle elbette ilgili hesapları de etkiliyor. Örneğin ben dilersem buradan ali kullanıcısının kabuğunu, bash aracının tam dosya adresini belirterek bash olarak değiştirilebilirim. Bunun için sudo nano /etc/passwd komutu ile yetkili şekilde passwd dosyasını açalım. ali kullanıcısının kabuğunda değişiklik yapmak için son satıra gelip, kabuk bölümüne bash kabuğunun dosya adresini yazabiliriz. Tamamdır. Dosyamı kaydettiğimde ali kullanıcısının kabuğu da bash olarak değişmiş olacak. Hatırlarsanız biz eğitimin başında varsayılan kabuğunu bash olarak değiştirmek için de bu dosyada değişiklik yapmıştık. İşte linux ta her şey dosya yapısı üzerinden ele alındığı için sistem yönetimi ve düzenlemesi de dosyalar üzerinden kolayca yapılabilir. Pek çok araç yani pek çok komutta aslında bu ve bunun gibi dosyalarda kısayoldan değişiklik yapmamızı sağlıyor. Biz hangi dosyanın hangi işlevde olduğunu biliyorsak, istersek manuel olarak elle dosyayı düzenleriz istersek de aynı işi yapan bir aracı yani komutu kullanırız. Bu dosya üzerinden açıkladığımız gibi sistemdeki dosyaların işlevlerini bildiğimiz zaman denetim ve yönetim noktasında pek çok avantaja sahip oluyoruz. Ben ctrl x ile dosyayı kaydetmek üzere kapatıp kaydetme işlemini de onaylıyorum. Neticede ali kullanıcı hesabı için varsayılan kabuğu, kullanıcı hesapları hakkında bilgileri barındıran bu dosyada düzenlemek yaparak değiştirmiş oldum.

Tıpkı bu kabuk düzenleme işlemi gibi aslında istersek adduser veya useradd gibi araçları kullanmadan kendimiz bu passwd dosyasına yeni kullanıcı hesabı tanımlayıp yeni kullanıcı da oluşturabiliriz. 

Manuel şekilde kullanıcı oluşturabiliyor olsak da, yine de en kolay ve mantıklı yöntem adduser komutunu kullanıp adduser komutunun yeni kullanıcı için gereken tüm ayarlamaları yapmasını sağlamaktır. Dosya içeriğinde oynama yapıp kullanıcı hesabıyla ilgili bilgileri kolayca değiştirebiliyor olmamız güzel bir esneklik evet. Ancak tek tek pek çok ayarlama yapmamız gerektiği için sıfırdan kullanıcı oluştururken önerdiğim veya kullandığım bir yöntem değil. Oluşturması da silmesi de daha sonra zahmetli olabiliyor. Zaten dilerseniz henüz kullanıcı hesabını oluşturma aşamasında adduser komutunun seçeneklerini kullanarak da kullanıcı hesapları ile ilgili detayları /etc/passwd dosyasını elle düzenlemeden belirtebilirsiniz. Hangi seçenekler olduğunu görmek için adduser —help komutu ile çıktıları inceleyebilirsiniz. Bakın yeni kullanıcı oluşturma aşamasında spesifik ev dizinini veya farklı bir kabuğu belirtebiliriz dilersek ev dizini olmamasını sağlayabiliriz kullanıcı numarasını belirtebiliriz ve benzeri tüm ayarlamaları buradaki seçenekleri kullanarak yapabiliriz. Tek yapmanız gereken adduser komutuna buradaki seçenekleri doğru şekilde girmektir. Eğer seçeneklere falan uğraşmak istemiyorsanız benim size önerim seçeneksiz şekilde adduser komutunu kullanıp /etc/passwd dosyasında manuel olarak düzenleme yapmanız. 

/etc/passwd dosyasına hakkında son birkaç detaydan daha bahsedip parolaların tutulduğu dosyayı açıklamak istiyorum. Tekrar sudo nano /etc/passwd komutuyla dosyamızı açıp üzerinden konuşmaya devam edelim. 

Eğer bir kullanıcı hesabının bilgilerini silmeden o kullanıcı hesabını deaktif halde getirmek istersek buradaki varsayılan kabuk programı yerine kullanıcının oturum açmasını reddeden /usr/sbin/nologin dosyasını yazabiliriz. Bakın burada çeşitli araçlara ait olan sistem kullanıcıların neredeyse hepsi bu şekilde ayarlı. Araçlara ait kullanıcılar olduğu için zaten bu kullanıcıların oturum açıp kabuk kullanması gerekmediği için bu şekilde belirtilmişler. İşte bizler de herhangi bir kullanıcının oturum açmasını kibarca reddetmek için buraya kabuk yerine bu dosyayı ekleyebiliriz. 

Ben ali kullanıcısının oturum açmasını engellemek için buradaki kabuğu /usr/sbin/nologin şeklinde giriyorum. Tamamdır dosyamızı kaydedip kapatalım.

Mevcut konsolumuz üzerinden yeni bir kullanıcı hesabına geçiş yapmak için su komutunun ardından geçiş yapmak istediğimiz hesabın ismini girmemiz yeterli oluyor. Ben ali kullanıcısına geçiş yapmak için su ali şeklinde komutumu giriyorum.

Bakın “bu hesap şu anda müsait değil” şeklinde hata aldık. Normalde eğer bir kabuk programı tanımlı olsaydı direk o kabuk başlatılacaktı fakat biz nologin dosyasını varsayılan olarak ayarladığımız için bu şekilde hesabı pasif hale getirmiş olduk.

nologin seçeneği dışında tekrar passwd dosyasını açacak olursak bakın, listede /bin/false şeklinde olan kullanıcı hesapları da var. nologin dosyasına benzer şekilde false dosyası da kullanıcının oturum açmasına engel olmak için kullanılan dosya. fakat nologin dosyasından farklı olarak kullanıcıya bu durumda bir uyarı verilmeden kullanıcı doğrudan reddediliyor. İşte sizler de bu şekilde kullanıcı bilgisini dosyadan silmeden kullanıcı hesabını kolayca pasifleştirebilirsiniz. Daha sonra dilediğiniz zaman da tekrar bu dosyayı düzenleyip kullanıcıya kabuk tanımlayarak aktifleştirebilirsiniz.

Ayrıca hiç değinmedik ama mutlaka parola bölümündeki x ler dikkatinizi çekmiştir. Buradaki x karakterleri, kullanıcı hesabının parolasının /etc/shadow dosyasında şifrelenmiş şekilde tutulduğuna işaret ediyor. Zaten kullanıcı hesaplarına ait parolalar şifresiz şekilde yani okunabilir biçimde bu listede bulunsaydı hesapların güvenliğini riske girerdi. Bunun yerine tüm kullanıcıların parola bilgileri /etc/shadow dosyasında şifrelenmiş şekilde tutuluyor. Daha iyi anlamak için şimdi /etc/shadow dosyasından bahsederek devam edelim.

## /etc/shadow Dosyası

Dosya hakkında konuşmak için önce dosyamızı açalım. Ben açmak için sudo nano /etc/shadow şeklinde komutumu giriyorum. Eğer sudo komutuyla bu dosyayı yetkili şekilde açmazsanız dosya içeriğini görüntüleyemezsiniz çünkü bu dosyada kullanıcı hesaplarının parola bilgileri bulunuyor. 

Bakın tıpkı passwd dosyasına benziyor fakat shadow dosyasında kullanıcıların parolalarıyla ilgili çeşitli bilgiler tutuluyor. 

Örneğin en son oluşturduğumuz kullanıcılar hakkında bilgi almak için satırın en sonuna inecek olursak. Bakın mevcut kullanıcı hesabım da dahil yeni oluşturduğum kullanıcıların isimleri ve yanlarında da parola bilgileri bulunuyor. 

Burada iki nokta üst üste işaretiyle birbirinden ayrılmış bölümleri tek tek ele almak istemiyorum çünkü ele alsam bile muhtemelen aklınızda kalmayacak. Eğer buradaki detayları merak ediyorsanız kısa bir araştırma ile bu sütunların neyi ifade ettiğini öğrenebilirsiniz. Ben özellikle bahsetmiyorum çünkü aslında buradaki seçenekleri çok daha kolay okuyup değiştirmemiz için kullanabileceğimiz bir araç var. Anlatımın devamında o araçtan bahsedeceğim için buradaki unutulacak detaylarla vakit kaybetmemize gerek yok. Yine de ilk iki sütunu açıklayacak olursak.

Bakın ilk sütunda kullanıcı hesabının ismi bulunuyor. İkinci sütunda ise şifrelenmiş şekilde o kullanıcının parola bilgi bulunuyor. Biz  hesabımızda oturum açmaya çalıştığımızda eğer doğru parolayı girersek, girdiğimiz parola tekrar buradaki yöntemle şifreleniyor ve bu dosyadaki değer ile eşleşiyorsa bu kullanıcı hesabında oturum açabiliyoruz.

Şimdilik etc dizini altındaki shadow dosyasının kullanıcılara ait parola bilgilerini tuttuğunu bilmeniz yeterli.

Kullanıcı hesapları hakkında anlatımlarımıza devam edeceğiz. Fakat daha fazla devam etmeden önce grup kavramından da bahsetmek istiyorum. 

# Gruplar

[https://www.linode.com/docs/guides/linux-users-and-groups/](https://www.linode.com/docs/guides/linux-users-and-groups/)

[https://www.cyberciti.biz/faq/howto-linux-add-user-to-group/](https://www.cyberciti.biz/faq/howto-linux-add-user-to-group/)

Grup yapısı sayesinde ortak izinlere sahip olmasını istediğimiz kullanıcıları aynı grupta toplayıp bireysel kullanıcı yetkileri dışında toplu şekilde erişim yetkileri ayarlayabiliyoruz.

Öncelikle grup yönetiminden bahsedelim, daha sonra zaten grupların neden bu kadar önemli olduğunu yetkilendirme bölümünde daha iyi anlayacaksınız.

Normalde yeni bir kullanıcı oluştururken bizzat deneyimlediğimiz gibi her kullanıcıya ait kullanıcı hesabıyla aynı isimde bir grup oluşturuluyor. İşte bu grup o kullanıcının birincil grubu olacak geçiyor. Sistem üzerindeki tüm kullanıcıların birincil grubu bulunuyor. Örneğin ben ali isimli kullanıcı oluşturduğum için ali kullanıcısının birincil grubu ali isimli grup oluyor.

Öncelikle bu durumu teyit etmek için mesela ali kullanıcısının grubunu sorgulamak üzere groups ali şeklinde komutumuzu girebiliriz. Buradaki groups komutundan sonra argüman olarak girdiğimiz kullanıcı isimlerinin dahil olduğu gruplar bu araç sayesinde bastırılıyor. Bakın ali kullanıcısı ali isimli gruba dahilmiş.

Bunun dışında mesela kendi kullanıcı hesabımızı da sorgulayabiliriz. Ben şu an kali kullanıcı hesabını yönettiğim için groups kali şeklinde komutumuz giriyorum. Bakın bu sefer birden fazla grup listelendi. Kali kullanıcısı birincil olarak kali grubu dahil olmak üzere ikincil şekilde pek çok harici gruba da dahilmiş. 

Örneğin bakın kali kullanıcısı buradaki sudo grubuna dahil olduğu için sudo aracıyla gerektiğinde sudo yetkileriyle komutlarını çalıştırabiliyor. Ama ali kullanıcısı sudo grubunda olmadığı için sudo aracını kullanıp yetkili şekilde işlem yapmaya kalkarsa erişim yetkisi hatası alır. İşte gruplar zaten bu şekilde birden fazla kullanıcıya ortak şekilde bazı yetkileri vermek için kullanılıyor.

groups komutuyla aldığımız çıktıların dışında kullanıcıların hangi gruplara dahil olduğunun bilgisini öğrenmek için /etc/group dosyasını da kontrol edebiliriz. Ben göz atmak için nano ile dosyamı açıyorum. 

Bakın burda yer alan ilk sütunların hepsi grupların isimleri. Örneğin en alt satıra inecek olursak bakın, nil ve ali kullanıcılarının da kendi isimlerinde grupları oluşturulduğu için onların grupları da burada gözüküyor. İlk sütun grup isimleri dedik. İkinci sütun varsa grubun şifresini temsil ediyor. Ancak çoğunlukla grup şifresi kullanılmadığı için bu konuyu es geçebiliriz. Buradaki sayı ise, bu gurubu temsil eden benzersiz grup numarası. Hatırlıyorsanız kullanıcıları temsil eden user id yani kullanıcı numaraları da /etc/passwd dosyasında her kullanıcının kendi satırında yazıyordu. Buradaki sayı da bu gurubun grup numarası işte. En sondaki iki nokta üst üste işaretinden sonra bakın bazı grupların boş sütunlar varken bazılarında kullanıcı isimleri var. Bu sondaki sütun, bu guruba dahil olan ikincil kullanıcıları temsil ediyor. Yani örneğin bakın nil guruba nil kullanıcısı dışında hiç kimse dahil olmadığı için buradaki sütun boş. Ama burada kaboxer olarak geçen gruba kali ve root kullanıcıları dahil olduğu için o kullanıcıların isimleri burada yazıyor. Hatta dikkat edecek olursanız pek çok grubun sonunda mevcut kullanıcı hesabımın yani kali kullanıcısının bu gurpla ekli olduğunu görebiliyoruz.  Zaten kali kullanıcısının dahil olduğu grupları listediğimizde bu grupların isimlerini görmüştük. İşte bakın bir kez daha teyit  etmiş olduk. İşte gruplarla ilgili bilgiler bu dosyada tutuluyor. Yani istersek bu dosyada değişiklik yaparak gruplarla ilgili tanımlamaları değiştirebiliriz. Fakat tabii ki daha önce de olduğu gibi bu işi elle yapmak yerine bu iş için uygun olan aracı kullanarak çok daha sağlıklı şekilde grup oluşturma, gruba yeni kullanıcı ekleme ve çıktarma gibi işlemleri yapabiliriz.

Örneğin yeni bir grup oluşturmak istiyorsak tıpkı yeni kullanıcı oluştururken kullandığımız araca benzeyen groupadd aracını kullanabiliriz. Ben yeni-grup isminde bir grup oluşturmak istediğim için sudo groupadd yeni-grup şeklinde komutumu giriyorum.

Tamamdır gurubumun sorunsuzca oluşturulmuş olması gerek. Teyit etmek için tail -1 /etc/group komutunu girebiliriz. Bakın yeni-grup isimli grup oluşturulmuş ve grup numarası olarak da boşta bu sayı bulunduğu için bu sayı tanımlanmış.

Şimdi oluşturduğumuz bu guruba yeni bir kullanıcı eklemeyi deneyebiliriz. 

Kullanıcı eklemek için gpasswd aracını kullanabiliriz. Ben ali isimli kullanıcıyı bu yeni oluşturduğum gruba eklemek istediğim için gpasswd -a ali yeni-grup şeklinde komutumu yazıyorum. Bakın gpasswd aracına vermiş olduğum -a seçeneği benim add yani ekleme yapmak istediğimi belirten bir seçenek. Ekleme seçeneğinin ardından hangi kullanıcının hangi gruba ekleneceğini de argümanlar olarak yazıyorum. Tamamdır şimdi komutumuz girip etkisine bakalım.

Bakın ben başta sudo komutu olmadan girdiğim için yetki hatası aldım. sudo !! komutuyla en sonra girdiğimiz komutu yetkili şekilde tekrar çalıştırmayı deneyelim. Bildiğiniz gibi buradaki çift ünlem işareti en sonra çalıştırılan komutu geçmişten çağırıyor. Ben de sudo komutunda sonra en son çalıştırılan bu komutu çağırıp yetkili şekilde çalıştırılmasını sağlıyorum. Zaten genelde yetki gerektiren işlerde sudo komutunu girmeyi unuttuğumuzda bu şekilde sudo !! komutuyla en son girdiğimiz komutu sıklıkla çağırıyoruz, büyük kolaylık gerçekten. Bakın bu kez herhangi bir yetki hatası almadık.

Şimdi tekrar konumuza dönecek olursak bakın girdiğimiz komut neticesinde ali kullanıcısının yeni-grup isimli gruba eklenmiş olması gerekiyor. Bunu teyit etmek için yine tail -1 /etc/group şekline komutumuzu girebiliriz. Bakın yeni-grubun sonuna ali kullanıcısı da eklenmiş. Ayrıca emin olmak istersek groups ali komutuyla ali kullanıcısının dahil olduğu grupları da listeleyebiliriz. Bakın bu çıktıdan da ali kullanıcısının yeni-grup isimli gruba dahil olduğunu tekrar teyit edebiliyoruz.

Eğer silmek istersek yine gpasswd aracının bu kez -d seçeneği yani delete seçeneğiyle gruba ekli olan kullanıcıyı silebiliriz. Ben eklediğim ali kullanıcısını silmek için sudo gpasswd -d ali yeni-grup şeklinde komutumu giriyorum. Tamamdır. Şimdi gruptan silindiğini teyit etmek için groups ali komutuyla ali kullanıcısının dahil olduğu grupları sorgulayalım. Bakın artık yeni-grup çıktılarda gözükmüyor. Yani ali kullanıcısını bu gruptan başarıyla çıkarmışız.

Ben gruba ekleme ve çıkarma işlemi için gpasswd aracını kullandım ama aslında usermod aracıyla da gruba yeni kullanıcı ekleyebiliyoruz. Veya deluser aracıyla gruptan kullanıcı silebiliyoruz. Kısacası aynı işi yapan alternatif pek çok araç mevcut aslında. Yine de hem gruba ekleme hem de silme işlemi için ortak olarak gpasswd aracını kullanmak bana daha kolay geliyor. Eğer siz diğer alternatif araçların kullanımlarını merak ediyorsanız. Örneğin usermod aracıyla gruba yeni kullanıcı eklemek için usermod -aG grup-ismi eklenecek kullanıcı şeklinde komut girebiliyoruz. Ben yine yeni-grup isimli gruba ali isimli kullanıcıyı eklemek istiyorum. Bunun için sudo usermod -aG yeni-grup ali şeklinde komutumu giriyorum. 

Komutumu çok kısaca açıklamam gerekirse. Buradaki -a seçeneği append yeni ekleme seçeneğinin kısaltmasından geliyorken, buradaki büyük G seçeneği de bizim gruba ekleme yapmak istediğimizi belirten seçenek. Zaten bu seçeneklerin devamında da hangi gruba hangi kullanıcıyı ekleyeceğimizi sırasıyla argümanlar olarak belirtiyoruz. Ekleme işlemini teyit etmek için yine groups ali komutu ile ali kullanıcısının gruplarını listeleyebiliriz. Bakın usermod aracıyla da gruba kullanıcı eklemeyi başarmışız. 

Eğer eklediğimiz kullanıcıyı deluser aracıyla bu gruptan silmek istersek deluser kullanıcı-adı çıkarılacağı-grup şeklinde komutumuzu girebiliriz. Ben aliyi yen-grup tan çıkarmak isteiğim için sudo deluser ali yeni-grup şeklinde komutumu giriyorum. Bakın ali isimli kullanıcının yeni-grup tan silindiğine dair çıktımızı aldık.

Şimdi emin olmak için tekrar groups ali komutu ile kontrol edelim. Bakın deluser aracıyla da kullanıcıyı gruptan çıkarmayı başarmışız.

Son olarak oluşturduğumuz grubu nasıl silebileceğimizi de ele almak istiyorum. Grup oluştururken groupadd aracını kullanmıştık. Silmek için de groupdel aracını kullanabiliyoruz. Ben yeni-grup isimli grubu silmek için sudo groupdel yeni-grup şeklinde komutumu giriyorum.

Tamamdır grubumun silinmiş olması lazım. Teyit etmek için grep “yeni-grup” /etc/group komutuyla grup ismini group dosyasında arayabiliriz. Bakın herhangi bir çıktı almadık çünkü bu grubu biraz önce silmiştik. Yani silme işlemini de böylelikle teyit etmiş olduk.

Ayrıca anlatım sırasında doğrudan değinmek için fırsatım olmadı fakat usermod aracı yalnızca gruba yeni kullanıcı eklemek için kullanılan bir araç değil.  Aslında tıpkı isminde de yer aldığı şekilde kullanıcı hesaplarının özelliklerini düzenlemeyi sağlayan bir araç.

Seçeneklerini görmek için usermod —help komutuyla yardım bilgisini listeleyelim. Örneğin bakın kullanıcı hesabı için -d seçeneği ile yeni bir ev dizini belirtmenin yanında, dilersek -m seçeneğiyle mevcut ev dizinini taşıma imkanımız da var. Yeni giriş kabuğu tanımlamak için de -s seçeneği kullanılabiliyormuş. Hatta bakın mevcut kullanıcı hesabını kilitleyip tekrar açma gibi imkanlarımız da var. Hemen bu kilitleme seçeneğini deneyebiliriz.

Ben test etmek için daha önce oluşturduğum nil isimli kullanıcı hesabında oturum açmak için su nil şeklinde komutumu giriyorum. nil kullanıcısı için parola soruluyor, belirlediğim parolayı giriyorum. Bakın prompt bölümünden de teyit edebildiğimiz gibi nil kullanıcı hesabına sorunsuzca geçiş yapmış olduk.  Hatta şu an hangi kullanıcı hesabında olduğumu whoami komutuyla da sorgulayabilirim. Bakın yine nil şeklinde çıktımızı aldık. Neticede nil isimli kullanıcı hesabına sorunsuzca geçiş yapabildiğimi teyit ettim. Şimdi exit komutu ile bu hesaptan çıkmak istiyorum. Tekrar whoami ile mevcut oturumu sorgulayabiliriz. Bakın şu anda kali kullanıcısıyım. Şimdi ben nil kullanıcısının hesabını kilitlemek istersem sudo usermod -L nil şeklinde komutumu girebilirim. Bakın buradaki büyük L seçeneği kilitlemek anlamına gelen lock ifadesinin kısaltmasından geliyor. Ben komutumu onaylıyorum. Tamamdır. Artık nil kullanıcısı parolasını doğru yazsa bile kendi hesabında oturum açamayacak. Hemen denemek için su nil şeklinde komutumuzu girelim. Benden parola istiyor en parolamı giriyorum. Bakın biraz bekletiyor, ve bakın kimlik doğrulama hatası verdi. Yani böylelikle nil kullanıcısının hesabını kilitlemiş olduğumuzu teyit etmiş olduk.

Bu kilitleme işlemi aslında nil kullanıcısının parolasını şifreli şekilde tutan /etc dizini altındaki shadow dosyasındaki bir değişiklikten kaynaklanıyor. Hemen bizzat teyit etmek için sudo tail -3 /etc/shadow komutuyla dosyamızın son 3 satırını bastıralım.

Şimdi bakın burda kilitli olmayan kali ve ali kullanıcı hesaplarının şifreli parolalarının başında ünlem işareti bulunmazken, nil kullanıcısına ait şifreli parolanın başında ünlem işareti bulunuyor. Biz oturum açarken doğru parolayı yazsak bile, bizim girdiğimiz parola ile buradaki parola asla eşleşmeyeceği için oturum açmamız mümkün olmuyor. Bu yaklaşım sayesinde, kullanıcıların hesabını veya parolasını tamamen silmeye gerek kalmadan istediğimiz bir süre boyunca ilgili hesabın kilitli kalmasını sağlayabiliriz. Hesabın kilidini kaldırmak için de buradaki ünlem işaretinin silinmesi yeterli. Ben bu işlemli yine usermod aracıyla yapmak istiyorum. Bunun için unlock kilidi açma ifadesinin kısalmasından gelen büyük U seçeneğini kullanabiliriz. Ben sudo usermod -U nil şeklinde komutumu giriyorum.

Şimdi shadow dosyasına tekrar bakalım. Bakın önceki çıktıda nil kullanıcısında bulunan ünlem işaretinin kaldırılmış olduğunu bu yeni çıktıda görebiliyoruz. Yani nil kullanıcısı hesabının kilidi açılmış olmalı. Şimdi emin olmak için su nil komutuyla geçiş yapalım. Benden yine parola isteniyor, parolamı giriyorum.

Bakın bu kez sorunsuzca nil kullanıcı hesabına geçiş yapmış oldum.

İşte benim burada kullanıcı hesaplarını kilitleme üzerinden ele aldığım gibi usermod aracını mevcut kullanıcı hesaplarının ayarlarını düzenlemek için kullanabiliyoruz. Diğer seçenekler hakkında bilgi almak için yardım çıktılara bakabilir ya da internet üzerinden araştırma yapabilirsiniz. Zaten genellikle benim ele aldığım amaçlarla kullanıldığı için diğer seçeneklere ihtiyacınız olduğunda yardım sayfasından bakarak kullanabilirsiniz.

Artık kullanıcı hesapları ve gruplar hakkında temelde bilmemiz gerekenlerden bahsettiğimize göre artık erişim yetkileri anlatımlarımıza devam edebiliriz.

# Erişim Yetkileri

Erişim yetkilerinden bahsedebilmek için öncelikle bu yetkilerin nasıl gözüktüğünü bilmemiz gerekiyor. Ben bunun için ev dizinindeyken ls -l komutuyla detaylı şekilde mevcut dizinimi listeliyorum. 

Aldığımız çıktılarda yer alan ilk sütun dosya ve dizinlerin yetkilerini diğer bir deyişle modlarını temsil eden bölüm. Buradaki mode ifadesi önemli çünkü ileride bu yetkileri değiştirirken aslında mode değiştirme aracını kullanıyor olacağız. Devamında yer alan buradaki sütunlar da ilgili dosya ve dizinin hangi kullanıcı ve hangi gruba ait olduğunu belirtiyor.

Ben kendi ev dizinimi listelediğim için tüm dosya ve dizinleri sahibi ve grubu hep kali kullanıcısı olacak gözüküyor. Anlatımın devamında bu konuya tekrar değinmek üzere şimdi tekrar buradaki yetki yani mod tanımlamalarına dönecek olursak, ben tek tek buradaki karakterlerin ne anlama geldiğini açıklamak istiyorum.

İlk karakter her zaman dosya veya dizinin türü hakkında bilgi sunan karakter oluyor. Örneğin bakın dizinler directory ifadesinin kısaltmasından gelen d karakteri ile temsil ediliyorken, standart dosyalar kısa çizgi ile belirtiliyor. Ayrıca sembolik linkler de s karakteri ile temsil ediliyor. Ayrıca buradaki çıktılarda almadık ama farklı dosya türlerinde buradaki karakter de o dosyanın türüne göre farklı bir karakterle temsil edilmiş olabiliyor. Aldığınız çıktıdaki karakterin ne anlama geldiğini bilmediğinizde kısa bir internet araştırmasıyla bu karakter temsili hakkında kolayca pek çok bilgi edinebilirsiniz. Biz şimdi asıl odağımızı kaybetmeden bu ilk karakter alanın mevcut dosya veya klasörün türünü temsil ettiğini bilmemiz yeterli.

Şimdi buradaki 9 basamaklı karakterlere geçecek olursak. Bu karakterleri 3 er basamaklı 3 gruba ayırmamız gerekiyor. Çünkü buradaki ilk üç karakter bu dosyanın sahibinin izinlini temsil ediyorken, ikinci üç karakter de bu dosyanın grubunun sahip olduğu yetkileri temsil ediyor. Son üç karakter ise ilk iki grup haricindekileri yani hem bu dosyanın sahibi olmayan hem de bu dosyanın grubuyla aynı grupta bulunmayan diğer kullanıcılar için yetkileri temsil ediyor.

Bu üç ayrı yetki grubu sayesinde her bir dosya ve klasörü yalnızca istediğimiz kullanıcıların erişebileceği şekilde yetkilendirebiliyoruz. Bu yetki karakterinde kullanılan r karakteri read yani okuma yetkisini temsil eden karakter. Eğer bu karakteri görüyorsanız o dosya veya klasörün içeriğini görüntüleyebilirsiniz. w ifadesi ise write yani yazma yetkisini temsil eden karakter. Bu karakter varsa dosya içeriğini düzenleyip, klasörlerde de dosya ekleme ve silme gibi işlemleri yapabileceğimiz anlamına geliyor. Son olarak x karakteri ise execute yani çalıştırma yetkisini temsil ediyor. Bu yetki varsa dosyaları çalıştırabilir ya da klasör içeriklerini yazma yetkisi de varsa düzenleyebilirsiniz. Klasör içeriklerini düzenlemek için yazma ve çalıştırma yetkisinin her ikisinin de bulunması şart yoksa düzenleme yapılamıyor. Ama mesela okuma yetkisi olmadan da düzenleme yapılabilir. 

Söylediklerim şu an için pek anlaşılır gelmemiş olabilir ancak merak etmeyin örnekler üzerinden ne ifade ettiklerini çok daha iyi anlamış olacaksınız.

Ben testler sırasında kullanabilmek için basit bir betik dosyası oluşturmak istiyorum. Bunun için echo “echo ben betik dosyasıyım” > [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum. ls -l ile mevcut dizinimizi tekrar listeleyelim. Bakın betik dosyası oluşturulmuş. 

Öncelikle dosyanın yetkilerine göz atacak olursak bakın bu dosyanın sahibi hem okuma hem yazma yetkisine sahipken, dosyanın grubundaki kullanıcılar ve diğer kullanıcılar bu dosyayı yalnızca okuyabiliyormuş. Bu dosyanın sahibi kali kullanıcısı olduğu için kali kullanıcısı bu yetkilere sahip. Dosya yine kali grubuna dahil olduğu için kali grubundaki tüm kullanıcılar da bu dosya üzerinde buradaki yetkilere sahip. Dosyanın sahibi olmayan veya bu grupta bulunmayan diğer tüm kullanıcılara da dosya üzerinde buradaki yetkilere sahip.

Öncelikle dosyanın sahibi üzerinden yetkilerin nasıl çalıştığını görmek için yeni bir konsol açalım ve dosyamızın okuma yetkisini test etmek için nano [testfile.sh](http://testfile.sh) komutuyla açalım.

Bakın ben dosyanın sahibi olan kali kullanıcısı olduğum için buradaki okuma yetkim sayesinde bu dosyanın içeriğini okuyabiliyorum. Şimdi yazma yetkisini test etmek için buradaki ifadesinin sonuna test yazıp ctrl x ile nano aracını kapatalım ve dosyamızı kaydetmek üzere onayımızı verelim. Bakın kaydetme aşamasında herhangi bir yetki hatası almadık. Yine de emin olmak için cat komutuyla tekrar dosya içeriğini görüntüleyebiliriz. Bakın yazma yetkim sayesinde dosyaya test ifadesini eklemeyi başarmışım. Şimdi son olarak bu dosyamızı çalıştırmayı denemek için tıpkı daha önce de yaptığımız gibi ./testfile.sh şeklinde komutumuzu girelim. Bakın bu kez yetki hatası aldık. Çünkü burda da gördüğünüz gibi dosyanın sahibi de olsam dosyayı çalıştırma yetkim bulunmuyor. Dolayısıyla bu dosyayı bir betik dosyası yani bir program gibi çalıştırmam mümkün değil. Çalıştırabilmem için daha önce de yaptığımız gibi chmod aracı yardımıyla bu dosyaya çalıştırma yetkisi vermem gerekiyor. Bu yetkilere mode dendiğiniz özellikle söylemiştim. İşte bu yetkileri değiştirmek için kullandığımız araç da change mode ifadesinin kısaltması olarak chmod şeklinde isimlendirilmiş.

Ben hemen bu betik dosyama çalıştırma yetkisi vermek için daha önce de birkaç kez yaptığımız gibi chmod +x [testfile.sh](http://testfile.sh) komutunu giriyorum. Şimdi tekrar ls -l komutuyla listeleyelim. Bakın tüm yetki grupları için çalıştırılma yetkisi verilmiş. Yani artık bu dosyayı herkes çalıştırabilir. Ben denemek için tekrar ./testfile.sh şeklinde komutumu giriyorum.

Bakın bu kez betik dosyam sorunsuzca çalıştı. Yani çalıştırma yetkisi vermeyi başardık. Fakat bu örneğimizde herkese çalıştırma yetkisi vermiş olduk. 

Şimdi yetki verme işlemini nasıl daha spesifik olarak tanımlayabileceğimizden bahsederek devam etmek istiyorum.

Öncelikle ben tüm izinleri daha rahat gösterebilmek için öncelikle dosyamdaki tüm yetkileri kaldırmak için chmod -rwx [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum. ls -l ile listeleyelim. Bakın dosyamın tüm yetkileri kaldırılmış.

Şimdi ben yalnızca dosyanın sahibine çalıştırma yetkisi vermek istediğim için chmod komutundan sonra, dosyanın sahibini temsil eden user ifadesinin kısalmasından gelen u seçeneğini yazıyorum ve yetki ekleyeceğim için artı işaretini de ekliyorum. Çalıştırma yetkisi eklemek istediğim için de x karakterini yazıyorum. Son olarak bu yetkinin geçerli olacağı dosyayı argüman olarak girebiliriz. Tamamdır, şimdi ls -l komutuyla tekrar listeleyelim. Bakın yalnızca dosyanın sahibine çalıştırma yetkisi vermiş olduk.

Yetkiyi silmek istersek de artı yerine eksi işaretini kullanabiliriz. Ben yine dosyanın sahibinden çalıştırma yetkisini kaldırmak istediğim için chmod u-x [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum. Listeleyelim.

Bakın eksi işareti sayesinde yetki kaldırma işlemini de sorunsuzca gerçekleştirdik.

Eğer dosya sahibinin yetkilerini değil de dosya gurubunun yetkilerini değiştirmek istersek u yerine g karakterini kullanabiliriz. Ben denemek için gruptaki kullanıcılara okuma ve yazma yetkisi vermek için chmod g+rw [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum.

Listeleyelim. Bakın dosyanın grubu için okuma ve çalıştırma yetkileri verilmiş.

Diğer kullanıcılar için yetki tanımlaması yaparken de others yani diğerleri ifadesinin kısalmasından gelen o karakterini kullanabiliyoruz. Ben diğer kullanıcılara yalnızca okuma yetkisi vermek istediğim için chmod o+r [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum.

Tekrar listeleyelim. Bakın diğer kullanıcılar için yalnızca okuma yetkisi tanımlanmış.

İşte bu ele aldığımız yaklaşımlar sayesinde toplu veya tekil olarak istediğimiz yetki tanımlamasını yapabiliyoruz. Örneğin tüm kullanıcıların okuma yetkisini kaldırmak istersek chmod -r [testfile.sh](http://testfile.sh) şeklinde komutumuzu girebiliriz. Bakın okuma yetkisi olanların yalnızca okuma yetkileri kaldırılmış oldu. Neticede burada öğrendiğiniz ekleme ve çıkarma yaklaşımı sayesinde hem spesifik kullanıcı grubuna hem de toplu şekilde tüm kullanıcı yetkilerine ekleme ve çıkarma yapabilirsiniz. Bu arada fark ettiyseniz biz şimdiye kadar hep ekleme ve çıkarma yaptık. Eğer artı ve eksi işaretleriyle ekleme veya çıkarma yapmak yerine doğrudan tanımlamak istediğimiz yetkiler varsa eşittir işaretini kullanabiliyoruz.

Bakın şu anda bu dosyanın sahibinin yalnızca çalıştırma yetkisi var. Eğer bu dosya sahibi için okuma veya yazma yetkisi verip çalıştırma yetkisini kaldırmak istersek hem ekleme hem de çıkarma işaretlerini kullanmamız gerekecek. Ama bunun yerine doğrudan eşittir işareti sayesinde istediğimiz tam yetki tanımlamasını yapabiliriz. Ben tanımlamak için chmod u=rw [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum. Dosya ayrıntılarını listeleyelim. Bakın buradaki eşittir işareti sayesinde yalnızca çalıştırma yetkisi bulunan kullanıcının yetkisini doğrudan okuma ve yazma yetkisine çevirmiş olduk. 

Yani gördüğünüz gibi yetki ekleme işlemi için artı, çıkarma işlemi için eksi ve doğrudan yetkiyi tanımlamak için de eşittir işaretini kullanabiliyoruz.

Ayrıca bizim burada kullandığımız yetkileri temsil eden harfler yerine aslında yetki tanımlamak için bu yetkilerin sayısal karşılıklarını kullanma imkanımız da var. Üstelik sayıları kullanarak birden fazla yetki guruba tek sefer yetki tanımlamak çok daha kolay.

Neden daha kolay olduğunu anlayabilmemiz için öncelikle sayılarla nasıl yetki tanımlayabileceğimizden bahsetmemiz lazım.

Normalde r karakteri ile temsil edilen okuma yetkisinin sayısal karşılığı 4 rakamıdır.

Yazma yetkisini temsil eden w karakteri de 2 rakamı ile temsil ediliyor.

x karakteri ile temsil edilen çalıştırma yetkisinin rakam karşılığı da 1 rakamı.

Biz üç yetki grubuna yetki tanımlaması yapmak için üç basamaklı şekilde bu rakamların toplamlarını girebiliyoruz.

Önceki örneklerimizi hep dosyalar üzerinde uyguladık fakat yetkiler klasörler için de aynen geçerli. Ben bu durumu kanıtlamak için örneklerimde kullanmak üzere yeni bir klasör oluşturmak istiyorum.

mkdir testfolder komutuyla hemen oluşturalım. Hatta tam bir klasör olması için touch testfolder/dosya{1..4} komutuyla birden fazla dosyamızı da ekleyelim.

Tamamdır. Bakın şu anda klasörümün yetkileri bu şekilde. Eğer ben klasör grubundaki kullanıcılara yazma yetkisi vermek istersem yazma yetkisini temsil eden 2 rakamını kullanabilirim.

Ekleme yapacağım için yine chmod komutundan sonra + işaretini kullanmam gerekiyor. Şimdi ben yalnızca klasör grubundaki kullanıcılara yazma yetkisi eklemek istediğim için 020 testfolder şeklinde komutumu yazıyorum. Burada üç basamaklı sayı yazmamız gerekiyor çünkü ilk sayı her zaman kullanıcıya, ikinici sayı gruba, üçüncü sayı da diğer kullanıcılara ait olan yetkileri temsil ediyor. Ben yalnızca gruba okuma yetkisi eklemek istediğim için diğer yetkilere ekleme yapılmaması için 0 şeklinde yazdım ve grubu temsil eden ortadaki sayıya okuma yetkisini temsil eden 2 rakamını girdim. Sonucu görmek için komutumuzu onaylayalım. Bakın klasör grubundakilere okuma yetkisi de eklenmiş.

Kullanımı daha iyi anlamak için mesela yalnızca klasör sahibine okuma izni verip geri kalan tüm yetkileri silmeyi deneyebiliriz. Yetki kaldırma işlemi yapacağımız için eksi işaretini kullanacağız. Klasör sahibinden yazma ve çalıştırma yetkisini eksiltmek istediğimiz için yazma ve çalıştırmayı temsil eden 2 ve 1 rakamlarının toplamını yani 3 rakamını buraya yazmamız gerekiyor. Daha sonra diğer tüm kullanıcıların tüm yetkilerini kaldırmak istediğimiz için okuma yazma ve çalıştırma yetkilerinin sayılar toplamları 4 2 1 den 7 ettiği ikinci ve üçüncü sayı kısmına da 7 rakamlarını ekleyebiliriz. Hemen komutumuzu onaylayalım. Şimdi teyit etmek için listeleyecek olursak, bakın klasörün sahibinin yalnızca okuma yetkisi varken grup ve diğer kullanıcıların yetkileri kaldırılmış.

Bence bu örnek bu yetki işlemini gayet net biçimde açıklıyor. Yine de bir tane daha örnek ele alabiliriz. Şu anda bu klasörün yalnızca sahibi için okuma yetkisi var gördüğünüz gibi.

Eğer sahibine yazma ve çalıştırma yetkisi ekleyip, grubu için yalnızca okuma ve yazma yetkisi eklemek ve diğer kullanıcılar için de yalnızca okuma yetkisi eklemek istersek komutumuzu nasıl girmemiz gerekir ? 

Hemen deneyelim.

Şimdi ben yetki eklemesi yapacağım için chmod + şeklinde yazıyorum. İlk sayımızda klasörün sahibine yazma ve çalıştırma yetkisi vereceğiz. Yazma yetkisi 2 rakamıyla temsil ediliyor, çalıştırma da 1 rakamıyla. Her iki yetkiyi temsil etmesi için toplamlarını yani 3 rakamını yazabiliriz. 

Grubu için okuma ve yazma yetkisi yani 4 ve 2 rakamlarının toplamını 6 rakamıyla girebiliriz. 

Son olarak diğer kullanıcılara yalnızca kuma yetkisi eklemek için de 4 rakamını yazabiliriz.

Tamamdır klasör ismimizi de yazıp komutumuz onaylayalım. Teyit etmek için ayrıntılı şekilde listeleyebiliriz. Bakın tam olarak istediğimiz yetkileri eklemeyi başarmışız. 

İşte yetkileri temsil eden rakamları kullanarak yetki ekleme ve çıkarma işlemi bu şekilde. Ayrıca ekleme ve çıkarma işlemi dışında dilerseniz daha önce de yaptığımız gibi eşittir işareti sayesinde tam olarak hangi yetkilerin tanımlanmasını istiyorsanız onu da belirtebilirsiniz. Ben örnek olması için kullanıcının okuma ve yazma, gruptakilerin okuma ve çalıştırma, diğer kullanıcılarında yalnızca çalıştırma yetkisine sahip olmasını istiyorum. Bunun için chmod =651 [testfolder.sh](http://testfolder.sh) şeklinde komutumu giriyorum. Hemen listeleyelim. Bakın ekleme veya çıkarma yapmama gerek kalmadan doğrudan ilgili izinleri sayılar üzerinden tanımlamış oldum. Ayrıca aslında izinleri sayısal olarak belirtiyorken burada eşittir işaretini kullanmak zorunda da değiliz. chmod 651 şeklinde de yazsaydık doğrudan buradaki yetkiler ilgili dosyada geçerli olacaktı. Genellikle de zaten bu şekilde eşittir işareti olmadan kullanılıyor fakat siz nasıl rahat ediyorsanız o şekilde kullanabilirsiniz.

Son bir örnek vermem gerekirse mesela normal şartlarda yapılması pek önerilmeyecek olsa da tüm kullanıcılara tüm yetkileri vermek için chmod +777 testfolder komutunu kullanabiliriz. 7 rakamı tüm yetkilerin toplamını temsil ettiğim için üç basamakta da 7 rakamını kullanarak tüm herkese tüm yetkileri vermiş oluyoruz. Ayrıntılı liste üzerinden kontrol edelim. Bakın tüm kullanıcılar için tüm yetkiler verilmiş. İşte sayıları kullanarak yetki tanımlamak bu kadar kolay.

Belki bu sayıların kullanımı başta biraz kafa karıştırıcı gelmiş olabilir fakat kendiniz biraz pratik yaparsanız aslında ne kadar kolay ve kullanışlı olduğunu bizzat görebilirsiniz. Test etmek için dosya veya klasörler oluşturup, bir yetki tanımlaması planlayıp bu yetkilendirmeyi doğru şekilde tanımlayıp tanımlayamayacağınızı test edebilirsiniz. Bu şekilde alıştırmalar yaparsanız zaten tam olarak kullanımını kavramış olacaksınız.

Ben şimdi son olarak klasörler üzerindeki yetki tanımlamalarının alt dizinlerdeki içerikler üzerinde de geçerli olmasını sağlayan özyineleme seçeneğinden kısaca bahsetmek istiyorum.

Bakın tesfolder isimli klasörde tüm kullanıcılar için tüm yetkiler mevcut çünkü biz bu şekilde tanımladık. Şimdi ls -l testfolder/ komutuyla bu dizinin içerisindeki tüm içerikleri ayrıntılı şekilde listeleyelim. Bakın buradaki dosyaların yetkileri bu klasörün kendi yetkisinden farklı. Yani bizim klasör üzerinde uyguladığımız yetki değişiklikleri, klasör içerisindekileri etkilememiş. Eğer biz klasörlere yetki tanımlaması yaparken ilgili tanımlamanın tüm alt dizinlerdeki içeriklerde de aynen geçerli olmasını istersek özyineleme yani recursive ifadesinin kısalmasından gelen büyük R seçeneğini kullanabiliyoruz.

Ben denemek için tüm kullanıcılara çalıştırmak yetkisi eklemek üzere chmod -R +111 testfolder şeklinde komutumu giriyorum. Buradaki büyük R seçeneği sayesinde buradaki yetki ekleme işleminin bu klasörün içinde yer alan tüm içeriklerde de aynen geçerli olması lazım. Hemen tekrar ls -l testfolder komutuyla klasörümüzün içeriğini listeleyelim. Bakın tüm kullanıcılar için tüm dosyalara çalıştırma yetkisi eklenmiş.  

Ben yetkilendirme tanımlaması için sayıları kullandım ama harfler ile de aynı şekilde R seçeneği sayesinde tüm alt dizinlerdeki içeriklerde aynı izin tanımlamalarının geçerli olmasını sağlayabiliriz. 

Ben hem harfler ile tanımlama yapabildiğimizi hem de R seçeneğinin tüm alt dizinleri etkilediğini teyit etmek için bu klasörümün içerisine mkdir testfolder/alt-klasor komutuyla yeni bir dizin eklemek istiyorum. Şimdi bir de bu dizinin içerisine dosya eklemek için touch testfolder/alt-klasor/dosya{A..D} şeklinde komutumuzu girebiliriz. Tamamdır. Hemen ls -lR testfolder komutuyla özyinelemeli şekilde tüm dizin içeriğini bastıralım. Bakın yeni oluşturduğum alt klasör ve dosyalar burada bulunuyorlar. Ve tabii ki ilk kez oluşturuldukları için standart yetkilere sahipler. Ben şimdi testfolder klasörü üzerinden tüm bu alt dizinlerde geçerli olacak bir yetki tanımlaması yapmak istiyorum.

Örneğin gruptaki kullanıcıların hepsine yalnızca yazma yetkisi tanımlamak üzere chmod -R g=w testforlder şeklinde komutumuzu girebiliriz. Buradaki R seçeneği sayesinde buradaki yetki tanımlama işlemi tüm alt dizinlerdeki içeriklerde de aynen geçerli olacak. Komutumuzu onaylayalım. Tamamdır, şimdi ls -lR testfolder komutuyla dizin içeriğinin tamamını listeleyebiliriz. Bakın tüm alt dizinlerdeki içerikler da dahil tüm içeriklerdeki grup yetkileri yalnızca yazma yetkisi olacak şekilde tanımlanmış.

Yani bizzat iki farklı şekilde de teyit ettiğimiz gibi alt dizinlerde geçerli olacak ortak dizin tanımlamaları için büyük R seçeneğinden faydalanabiliyoruz.

Ben temelde dizin tanımlamalarıyla ilgili bahsetmek istediklerim bu kadar. Ben artık bu yetkilerin etkilerini gözlemleyebilmemiz için testler gerçekleştirerek devam etmek istiyorum.

# Erişim Yetkilerinin Etkileri

Şimdiye kadar kullanıcılardan, gruplardan ve erişim izinlerinden bahsettik ancak doğrudan erişim yetkilerinin dosya ve dizinler üzerindeki etkilerini gözlemlemedik.

Buradaki yetki modlarından bahsederken, dosya veya dizinin sahibi, grubundaki kullanıcılar ve diğerleri şeklinde yetki tanımlamalı olduğunu ele aldık.

Şimdi örneğin bakın [testfile.sh](http://testfile.sh) dosyasını kali kullanıcısı oluşturduğu için dosyanın sahibi olan kullanıcı kali ve bu dosya üzerinde bu yetkilere sahip olan grup da yine kali grubundaki kullanıcılar. Bunlar dışında yer alan tüm kullanıcılar da buradaki yetkilere sahip.

Burada bahsi gelen kali grubu kali kullanıcısının birincil grubu olduğu için tabii ki biz özellikle başka bir kullanıcıyı ekleyene kadar bu grupta başka bir kullanıcı bulunmuyor. Ben grup yetkilerini test edebilmek için ali isimli kullanıcı hesabını bu kali grubuna eklemek istiyorum. Bunun için sudo gpasswd -a ali kali şeklinde komutumuzu girebiliriz. 

groups ali komutuyla ali kullanıcısının gruplarını sorgulayalım. Bakın ali, kali grubuna dahil olmuş.

Neticede şu anda sistemimde bu dosyanın sahibi olan kali kullanıcısı, bu dosya için tanımlı olan kali grubundaki ali kullanıcısı ve bunların hiç birine dahil olmayan nil isimli bir kullanıcı hesabım bulunuyor. Ben şimdi sırasıyla bu kullanıcı hesapları üzerinden dosya üzerindeki yetkileri test etmek istiyorum. Bunun için iki yeni konsol daha açalım. Öncelikle su ali komutuyla ali kullanıcı hesabında oturum açıyorum. Daha önce örnekler sırasında ali kullanıcısının oturum açmasını engellemek için passwd dosyasında varsayılan kabuk yerine nologin dosyasını eklediğim için oturum açamıyoruz. sudo nano /etc/passwd komutuyla dosyamızı açalım. Şimdi ben ali satırına geliyorum, burda bakın kabuk yerine nologin dosyası var /usr/bin/bash olarak değiştiriyorum. Ctrl X ile dosyamızı kaydedip kapatabiliriz. Tamamdır. Şimdi tekrar su ali komutuyla geçiş yapmayı deneyelim. Bakın bu kez sorunsuzca ali kullanıcı hesabında oturum açmış olduk.

Şimdi diğer konsolumuzda da nil kullanıcı hesabında oturum açmak üzere su nil şeklinde komutumuzu girelim. Parolamı da giriyorum. Tamamdır, bu konsol üzerinde de nil kullanıcı hesabında oturum açmış oldum. Konsollarımızı sağa sola tutturalım. 

Şimdi testlerimize geçebiliriz. Gördüğünüz gibi bu dosyamın şu anda sahibi için çalıştırma, grubu için de yazma yetkileri bulunuyor.

Yeni bir konsol açıp bu dosyayı okumak üzere cat [testfile.sh](http://testfile.sh) şeklinde denemek istiyorum. Bakın okuma yetkim olmadığı için erişim yetkisi hatası aldım. Şimdi üzerine veri eklemek için echo “yeni girdi” >> testfile.sh şeklinde komut girmeyi de deneyebiliriz. Bakın yine yetki hatası aldık. Son olarak dosyayı çalıştırmak üzere ./testfile.sh şeklinde komutumuzu girebiliriz. 

Bakın dosyanın sahibi yani kali kullanıcısı olmamıza ve burada da gözüktüğü gibi çalıştırma yetkisine sahip olmamıza rağmen betik dosyasını çalıştıramadık. Dosyamızı çalıştıramadık çünkü bir dosyanın çalıştırılabilir olması için okuma yetkisinin de bulunması gerekiyor. Dosyayı okuma yetkimiz yoksa, çalıştırma yetkimizin olmasının bir anlamı yok gördüğünüz gibi. Hemen teyit etmek için chmod u+r [testfile.sh](http://testfile.sh) komutuyla yetkimizi verelim. Tamamdır. Şimdi tekrar ./testfile.sh komutuyla çalıştırmayı deneyelim. Bakın bu sefer sorunsuzca çalıştırabildik. İşte siz de çalıştırma yetkisi vermek istiyorsanız mutlaka okuma yetkisi de vermelisiniz.

Dosyanın sahibi üzerinden testlerimizi gerçekleştirdik. Şimdi benzeri şekilde dosyanın grubunda bulunan ali kullanıcısı üzerinden erişim yetkilerini test edebiliriz. Bakın gruptaki kullanıcıların yalnızca yazma yetkisi bulunuyor. Ben test etmek için ali kullanıcı oturumunun açık olduğu konsola cat testfile.sh komutunu girip bu dosyamı okumayı denemek istiyorum. 

Yeni kullanıcı oturumu açmış olsam da gördüğünüz gibi hala kali kullanıcısının ev dizininde yani /home/kali dizininde çalıştığım için doğrudan dosyanın ismini girebiliyorum. Hala kali kullanıcısının ev dizinimdeyim çünkü grafiksel arayüzde kali olarak oturum açtım ve bu konsolları da ali ve nil olarak oturum açmadan önce çalıştırdığım için konsollar kali kullanıcısın ev dizininden çalışmaya başladı. Hatta emin olmak istersek yeni bir konsol açalım ve pwd ile mevcut dizini teyit edelim. Bakın konsol kali kullanıcısının ev dizinde çalışamaya başladığı için ben şimdi burada oturum açarsam oturum açtığım kullanıcı hesabı da bu dizinde çalışma başlıyor. Zaten ileride bu duruma da ayrıca kısaca değineceğiz.  Şimdi tekrar konumuza dönecek olursak ben ali kullanıcısı olarak dosyayı okumak üzere girdiğim komutumu onaylıyorum.

Bakın erişim reddedildi. Şimdi veri eklemek üzere echo “yeni veri” >> testfile.sh şeklinde komutumuzu girelim. Herhangi bir erişim hatası almadık yani muhtemelen verilerimiz sorunsuzca eklendi. Teyit etmek için kali kullanıcısı üzerinden cat komutu ile okuyalım. Evet bakın veri eklenmiş. İşlem başarılı oldu çünkü burda da gördüğümüz gibi bu gruptaki kullanıcıların dosyaya yazma yetkisi bulunuyor. Hatta bu durumu teyit etmek için bu grupta olmayan nil kullanıcısı üzerinden de okuma ve yazma gibi işlemleri test edebiliriz. Ben öncelikle okumak için yine cat testfile.sh şeklinde komutumu giriyorum. Bakın erişim yetkisi hatası aldık. Çünkü burada görüldüğü gibi dosyanın sahibi olmayan ve aynı grupta bulunmayanla hiç bir yetki verilmemiş. Emin olmak için dosyaya veri yazmayı da deneyebiliriz. Ben denemek için echo “deneme” >> testfile.sh şeklinde komutumu giriyorum. Bakın yine aynı şekilde erişim yetkisi hatası aldık çünkü nil kullanıcısı bu dosyanın yetki tanımlarına göre diğer kullanıcılar kapsamına giriyor ve bu kapsamdaki kullanıcıların da hiç bir yetkisi bulunmuyor.

Bence artık bu örnekler üzerinden burada tanımlı olan dosyanın sahibi grubu ve diğer kullanıcılar üzerindeki erişim yetkilerinin nasıl çalıştığını net biçimde ele almış olduk.

Eğer kendi kendinize pratik yaparsanız zaten izinlerin kapsamını çok daha net kavrayabilirsiniz. Örneğin bakın kali grubunda bulunan ali kullanıcısının yalnızca yazma yetkisi olduğu için ali olarak oturum açmışken nano aracıyla bu dosyayı açıp dosyada düzenleme yapamayız çünkü okuma iznimiz yok. Denemek için nano testfile.sh şeklinde komutumuzu girelim. Bakın alt tarafta dosyayı okuma iznimiz olmadığı açıkça belirtiliyor. Zaten ben de bu sebeple doğrudan echo aracıyla bu dosyaya veri yazma yetkimi test ettim. Benzer şekilde mesela dosyanın sahibinin bu dosyayı okuma ve çalıştırma yetkisi bulunuyor ama yazma yetkisi bulunuyor. Eğer nano aracıyla bu dosyayı açarsak, dosyadaki değişiklikleri kaydetmemiz mümkün olmayacak.

Hemen denemek için kali kullanıcı oturumunda nano testfile.sh komutuyla dosyamızı açalım. Bakın dosya içeriğini okuyabiliyoruz ama burada da yazdığı gibi bu dosyada değişiklik yapamayız. Biliyorum ama ben yine de denemek için “ekleme” şeklinde yazıyorum. Ctrl X ile dosyamızı kaydedip kapatmayı deneyelim. Bakın değişiklikler kaydedilsin mi diye soruyor. Yes ile onaylayalım. Bakın yetkimiz olmadığı için kaydetme işlemi başarısız oldu. Yine ctrl x ile çıkış yapıp no ile değişiklerin silinmesini sağladığımız takdirde aracımızı kapatabiliriz. Zaten hatırlıyorsanız tıpkı burada ele aldığımız örnekte olduğu gibi /etc/passwd dosyasında değişiklik yaptığımızda erişim yetkisi hatası almıştık. Çünkü bu dosya sistemdeki en yetkili kullanıcı olan root kullanıcısının yetkileri dahilinde olan bir dosya. Bu sebeple sudo komutunu kullanarak root yetkileri dahilinde bu dosyayı açıp düzenlemiştik. Hatta emin olmak olmak için ls -l /etc/passwd komutuyla dosyanın ayrıntılarını listeleyebiliriz. Bakın dosyanın sahibi ve grubu root olarak gözüküyor ve yalnızca dosyanın sahibi bu dosyada yazma yetkisine sahip. Bu sebeple tüm kullanıcılar dosya içeriğini okuyabiliyorken, yalnızca root kullanıcısı ya da sudo komutuyla root yetkilerine erişimi olan kullanıcılar bu dosyayı okuyabiliyor. 

İşte izinler dosyalar üzerindeki etkileri bu şekilde. Şimdi bir de kısaca klasörler üzerindeki etkilerinden konuşalım.

### Klasörler

Ben test etmek için önceden oluşturduğum bu klasörü kullanmak istiyorum. Bakın şu anda yetkileri bu şekilde. Örneklerimiz sırasında test edebilmek için. Ben klasörün sahibine tüm yetkileri verip, grubuna okuma ve yazma yetkisi vermek, diğer kullanıcılara da yalnızca okuma yetkisi vermek için chmod 764 testfolder şeklinde komutumu giriyorum.

ls -l komutuyla tekrar listeleyelim. Bakın klasörün modları tam olarak istediğim şekilde değişmiş. Şimdi ben kali kullanıcısı olarak klasörün sahibi olduğum için zaten gördüğünüz gibi tüm yetkilere sahibim. Yani bu klasörün ismini değiştirebilirim. İçerisine yeni dosya ve klasörler ekleyebilir veya silebilirim. Dizin içeriğini listeleyebilirim. Kısacası bu dizinde tüm yetkilere sahibim. Fakat burada dikkat etmeniz gereken detay bu işlemler dışında klasör içindeki dosya ve dizinler de kendi yetki tanımlamalarına sahip olduğu için üzerlerinde işlem yaparken bu yetki sınırlarının geçerli olduğu.  Yani örneğin ben bu dizin üzerinde tüm yetkilere sahip olabilirim ama dizin içindeki dosyayı okuma yetkim yoksa o dosyayı okuyamam. Denemek için chmod u-r testfolder/dosya1 komutuyla dosya1 isimli dosyanın sahibi yani kali kullanıcısı için okuma iznini kaldırıyorum. Tamamdır. Şimdi okumak için cat testfolder/dosya1 şeklinde komutumuzu girebiliriz. Bakın okuma iznim olmadığı için hata aldım. Yani bizzat gördüğümüz gibi klasörler üzerinde sahip olduğumuz yetkiler yalnızca klasör içeriğini listeleme, klasöre yeni dosya veya klasör ekleyip var olanları silmek ve dosya ve klasör isimlerini değiştirmekten ibaret. Bu durumu da teyit etmek için. Ben chmod u-rwx testfolder/dosya1 komutuyla dosyanın tüm yetkilerini kaldırmak istiyorum. Şimdi ls -l testfolder komutuyla dizin içeriğini listeleyelim. Bakın kali kullanıcısının dosya1 üzerinde yetkisi olmamasına rağmen dosya ismini ve ayrıntılarını görebiliyoruz. Dosyanın ismini değiştirmek üzere taşımayı da deneyebiliriz. ben mv testfolder/dosya1 testfolder/dosya-tasındı şeklinde komutumu giriyorum. Dizini tekrar listeleyelim. Bakın taşıma işlemimiz başarılı olduğu için dosyamızın ismini değiştirmiş olduk. Dilersek bu dosyayı erişim yetkimiz olan başka bir dizine de aynı şekilde taşıyabiliriz. Benzer şekilde dosyayı silmek için rm testfolder/dosya-tasındı şeklinde komutumuzu girebiliriz. Bakın silme korumalı diyor ama y tuşuna basıp silme işlemini onaylarsak silinecek. Tekrar dizini listeleyelim. Bakın silme işlemi de sorunsuzca tamamlanmış. Yani bizzat teyit ettiğimiz gibi dosyanın kendisini okuma yazma ve çalıştırma yetkimiz bulunmuyor olsa da, dosyanın içinde bulunduğu dizinde yetkimiz varsa dosyamızın erişim yetkileri boyutu ve ismi gibi ayrıntıları görüntüleyip, dosyayı istediğimi bir yere taşıyabiliyor ya da silebiliyoruz. Çünkü bu işlemlerin hepsi klasör yetkileriyle ilgili.

Şimdi klasör grubundaki ali ve diğer kullanıcı konumundaki nil üzerinden buradaki yetkilerin klasör üzerindeki etkilerini ele alalım. Bakın klasör grubundakilere okuma ve yazma yetkisi verilmiş. Ben ali kullanıcısı üzerinden bu dizinin içeriğini ayrıntılı şekilde listelemek üzere ls -l testdolder şeklinde komutumu giriyorum. Bakın yalnızca dosya ve dizin isimlerini görmekle birlikte bu dosya ve dizinlere yetkim olmadığı için erişemediğim belirtiliyor. Yani bu dizin içindeki dosya ve klasörlerde okuma yazma ve çalıştırma yetkim olsa bile bu dizinde olmadığı için bu izinlerin bir anlamı kalmıyor. Hatta emin olmak için ben hemen kali kullanıcısı üzerinden chmod g+rwx dosya3 şeklinde komutumuzu girebiliriz. listeleyelim. Bakın bu gruptaki kullanıcılara tüm yetkileri verim. Şimdi tekrar gruptaki kullanıcı olan ali kullanıcısı üzerinden bu dizini listelemeyi deneyelim. Bakın yine aynı şekilde hata aldık. Çünkü ali kullanıcısının bu dizinde çalıştırma yetkisi yok. 

Mesela okuma ve yazma yetkisi var ama burada yeni bir dosya veya klasör de oluşturamaz veya var olanları da silemez. Hemen denemek için touch testfolder/yeni-dosya şeklinde komutumuzu girelim. Bakın yine yetki hatası aldık. Mevcut bir dosyayı silmeyi de deneyebiliriz. Ben denemek için rm testfolder/dosya3 şeklinde komutumu giriyorum. Yine erişim yetkisi hatası aldık çünkü tekrar tekrar söylediğim gibi bu dizinde yani bu klasörde gruptaki kullanıcıların çalıştırma yetkisi bulunmuyor. ali de bu grupta olduğu için okuma ve yazma yetkisi olsa bile çalıştırma yetkisi olmadan bu yetkilen bir anlamı olmuyor. 

Ben şimdi son olarak diğer gruba verdiğimiz yalnızca okuma yetkisini test etmek istiyorum. Bunun için nil kullanıcı hesabındayken ls -l testfolder komutunu girebiliriz. Bakın yalnızca okuma yetkim olduğu için yine yalnızca dosya isimleri bastırıldı. Ama yazma ve çalıştırma yetkim olmadığı için bunun dışında bu klasörde bir işlem yapmam. 

Eğer merak ediyorsanız diğer kullanıcılara yalnızca çalıştırma veya yalnızca okuma yetkisi vererek de ayrı ayrı dizin içeriğini listelemeyi deneyebiliriz. Fakat günün sonunda okuma yetkimiz olmadığı için yine dizin içeriğini göremeyeceğiz.

Ben son olarak sadece okuma ve çalıştırma yetkisi verip nasıl bir etkisi olacağını görmek istiyorum. Bunun için kali kullanıcı hesabı üzerinden chmod o=rx testfolder komutuyla yalnızca diğer kullanıcılara bu dizinde okuma ve çalıştırma yetkisi veriyorum.

Şimdi tekrar nil hesabı üzerinden bu dizini listelemeyi deneyelim. Bakın bu sefer sorunsuzca dizin içeriğinin ayrıntılarını görebiliyorum çünkü hem okuma hem de çalıştırma yetkim var. Birinden biri olmasaydı bu şekilde listelenmeyeceğini zaten test ettik. Artık buradaki dosya ve dizinleri yetkilerim dahilinde okuyabilir veya çalıştırabilirim. Fakat, bu dizinde yazma yetkim olmadığı için buraya yeni dosya veya dizine ekleyemez veya var olanların ismini değiştirme taşıma ve silme gibi işlemler de yapmam. 

Ben denemek için kali kullanıcısı üzerinden buradaki dosya4 isimli dosyaya diğer kullanıcılar için tüm yetkileri vermek üzere, chmod o+rwx testfolder/dosya4 şeklinde komutumu giriyorum. Şimdi tekrar ayrıntıları listeleyelim. Bakın nil kullanıcısı bu dosya için diğer kullanıcılar sınıfına girdiği için artık bu dosya üzerinde tüm yetkilere sahip. Ben öncelikle echo “echo deneme” >> testfolder/dosya4 komutuyla dosyaya yazma işlemini test etmek istiyorum. Herhangi bir hata almadım. Şimdi okumak için cat testfolder/dosya4 şeklinde komutumuzu girelim. Bakın okuma konusunda da sorun yok. Son olarak çalıştırmak için ./testfolder/dosya4 komutunu girelim. Bakın çalıştırma konusunda da sorun yaşamıyoruz. Yani bizzat teyit ettiğimiz gibi dizinde yazma yetkimiz olmasa bile okuma ve çalıştırma yetkimiz varsa, dizin içindeki dosya üzerindeki tüm yetkilerimiz aynen geçerli oluyor.

Fakat bu dizinde yazma yetkim olmadığı için bu dizine yeni dosya eklemem veya var olanları taşıma veya silme gibi işlemler yapmam. Test etmek için touch testfolder/yeni-dosya şeklinde komutumuzu girelim. Bakın yeni dosya oluşturma işlemi başarısız oldu. Mevcut dosya4 isimli dosyayı taşıyarak ismini değiştirmek için mv testfolder/dosya4 testfolder/dosya4-tasındı şeklinde komutumuzu girelim. Bakın yine erişim hatası aldık. Son olarak silmek üzere rm testfolder/dosya4 komutunu da deneyebiliriz. Fakat tekrar teyit ettiğimiz gibi bu dizinde yazma yetkimiz olmadığı için yeni dosya veya klasör oluşturma var olanları taşıma veya silme gibi işlemler yapamıyoruz. Bunun dışında okuma ve çalıştırma yetkimiz varsa bu dizin içindeki dosya ve klasörlerin kendi sahip olduğu yetkiler dahilinde okuma yazma ve çalıştırma gibi işlemleri o dosya veya dizinler üzerinde uygulayabiliyoruz.

Ayrıca tüm bunların dışına eğer anlatım sırasında fark ettiyseniz, dosya ve klasörlerin yetkilerini yalnızca o dosya veya klasörün sahibi değiştirebiliyor. Örneğin gruptaki kullanıcılara tüm izinler verilmiş olsa bile, gruptaki kullanıcılar ilgili dosya veya dizinin yetkilerini değiştiremez.

Ben bu durumu da teyit etmek için öncelikle kali kullanıcı hesabı üzerinden chmod g+rwx [testfile.sh](http://testfile.sh) komutuyla bu dosyanın guruba tüm yetkileri veriyorum. Bakın tüm yetkileri verdim. Şimdi bu gruba dahil olan ali kullanıcı hesabı üzerinden mesela tüm kullanıcılara tüm yetkileri vermek üzere chmod +rwx testfile.sh şeklinde komutumuzu girmeyi deneyebiliriz. Bakın yetki hatası aldık çünkü ali kullanıcısının okuma yazma ve çalıştırma yetkisi olsa da bu dosyanın izinlerini değiştirme yetkisi yok. Dosya ve dizinlerin yetkilerini yalnızca sahipler değiştirebiliyor. Zaten böyle olmasaydı erişim yetkilerinin hiç bir anlamı kalmazdı. Çünkü örneğin dosyanın sahibi dışındaki herhangi bir kullanıcıya dosyayı okuması çalıştırması ve yeni veriler yazması için yetki verdiğimizde bu kullanıcı diğer herkesin yetkilerini düşürüp dosyanın tüm yetkilerini devralabilirdi. 

Bu sebeple dosya ve dizinlerin yetkilerini yalnızca sahiplerinin değiştirebileceğini unutmayın. Tabii ki sistem üzerindeki en yetkili olan root kullanıcısı da değiştirebilir fakat bu bir istisna ve root kullanıcısı zaten süper yetkilere sahip.

Biz şimdi dosya ve dizinlerin sahibini ve grubunu değiştirmekten bahsedelim.

## Dosya ve Dizinlerin Sahiplerini ve Gruplarını Değiştirmek

Burada değiştirmek istediğimiz şey dosya ve dizinlerin sahipliği olduğu için owner yani sahip ifadesinin kısaltmasından gelen chown aracından faydalanabiliyoruz. İsmi işlevini temsil ettiği için zaten ihtiyacımız olduğunda aracın ismini hatırlamamız da çok kolay oluyor. Ayrıca kullanımı da çok kolay zaten.

Ben örnek olarak kali kullanıcısına ait olan bu [testfile.sh](http://testfile.sh) isimli dosyanın sahipliğini değiştirmek istiyorum. İstersek hem dosya sahibini hem de grubunu aynı anda değiştirebileceğimiz gibi, ayrı ayrı sahibini ve grubunu da değiştirebiliriz.

Ben öncelikle yalnızca bu dosya sahibini nil olarak değiştirmek için chown nil [testfile.sh](http://testfile.sh) şeklinde komutumu giriyorum. Bakın ben bu dosyanın sahibi de olsam bu işlemi yapmak için yetkim yok. Bu işlemi yapmak için yönetici ayrıcalıklarına sahip olmamız gerekiyor. Ben komutunun başında sudo yazıp tekrar giriyorum. Buradaki sudo komutu sayesinde bu işlemi root yetkileriyle yerine getirebiliyor olacağım. kali kullanıcısı sudo grubuna dahil olduğu için sudo aracını kullanarak geçici olarak yetkilerini yükseltebiliyor. İleride bu konudan da ayrıca bahsediyor olacağız. Şimdi mevcut kullanıcı hesabımın yani kali kullanıcısının parolasını girmem gerekiyor. Parolamı girip onaylıyorum. Bakın bu kez herhangi bir hata almadık. Şimdi ls -l ile listeleyip dosyanın izinlerine bakalım. 

Bakın dosyanın sahibi olarak nil kullanıcısı gözüküyor. Yani artık buradaki izinler nil kullanıcısında geçerli ve nil kullanıcısı bu dosyanın izinleri değiştirebilir çünkü nil artık dosyanın sahibi.

Ben şimdi denemek içi dosyanın grubunu da değiştirmek istiyorum. Bunun için yine kali kullanıcısı üzerinden sudo chown yazıyorum ve grubu değiştirmek istediğim için iki nokta üst üste koyup gurubun ismini girmem gerekiyor. Ben ali isimli gurubu eklemek istiyorum. Tabii ki yeni bir grup oluşturup onu da buraya grup olarak tanımlayabilirdik fakat ben şimdilik var olan ali isimli grubu eklemek için :ali [testfile.sh](http://testfile.sh) şeklinde giriyorum.

Hemen listeleyelim. Bakın dosyanın grubunu artık ali olarak geçiyor. Yani ali grubundakiler buradaki yetkiler dahilinde bu dosya üzerinde işlemler yapabiliyor olacak.

Ben son olarak hem grubu hem de sahibini aynı anda kali olarak ayarlamak için sudo chown kali:kali [testfile.sh](http://testfile.sh) şeklinde yazıyorum. Bakın buradaki iki nokta üst üste karakterinden önceki kali ifadesi, bu dosyanın sahibini tanımlamamızı sağlıyorken, ikin nokta üst üste karakterinden sonraki kali ise grubu temsil ediyor. Zaten bir önceki komutumuzda grup tanımlarken başta iki nokta üst üste karakteri belirtmemizin nedeni de bu kullanım yapısıydı. Şimdi komutumuzu onaylayalım. Tamamdır. ls -l komutuyla tekrar bi listeleyelim.

Bakın dosyanın sahibi ve grubunu tek seferde yine kali olarak ayarlamış oldum.

İşte neticede sahiplik ve grup değiştirme işlemi bu şekilde. Örneğin ben yalnızca tek bir dosya üzerinde ele aldım ancak isterseniz birden fazla dosya veya klasör üzerinde de aynen kullanabilirsiniz. Hatta daha önce yetki işlemlerinde ele aldığımız gibi klasörün altındaki içeriklerde geçerli olacak sahiplik ve grup değişimi için büyük R karakteri ile recursive yani özyinelemeli şekilde değişiklik de yapabiliriz. 

Ben denemek için testfolder klasörümün altındaki tüm içeriğin gurubunu nil gurubu ile değiştirmek için sudo chown -R  :nil testfolder/ şeklinde komutumu yazıyorum. Buradaki büyük R seçeneği sayesinde testfolder dizini altındaki tüm içeriklerin grubu nil olarak değişmiş olacak. Komutumuzu onaylayalım.  Tamamdır hemen teyit etmek için ls -lR testfolder komutuyla dizin içeriğini özyinelemeli şekilde bastıralım. Bakın, bu dizin içindeki tüm dosya ve klasörlerin grubu nil olarak değişmiş. Yani artık tüm bu içeriklerin grup bölümündeki yetkileri nil isimli grubundaki kullanıcılar için geçerli olacak.

Ayrıca tabii ki bir tek alt dizinlerdeki gruplar değil bizzat testfolder dizininin grubu da değişti. Teyit etmek için ls -l komutunu kullanabiliriz. Bakın bu klasörün grubu da nil olarak değişmiş.

Bu yaklaşım sayesinde ilgili dosya ve klasörlere erişmesini istediğiniz kullanıcılar için bir grup oluşturup o grubu bu dosya veya klasörün grubu olarak ayarlayabilirsiniz. Dosya veya klasörün grup yetkilerini düzenleyerek de aynı anda bu gruptaki tüm kullanıcılara için ortak olarak yetki tanımlaması da yapmış olursunuz. 

En nihayetinde böylelikle yetkiler hakkında temel işleyişten bahsetmiş olduk. Yine de henüz yetkilendirmenin önemli bir yapısı olan sudo dan bahsetmedik. Gelin anlatımlarımıza sudo yapısından bahsederek devam edelim.

# sudo | sudoers Dosyasını Düzenlemek

sudo aracı, komutlarımızı sistem üzerindeki başka bir kullanıcı gibi çalıştırmamızı sağlıyor. Peki bu ne demek oluyor ?

Daha önce yetkilerden bahsederken, dosya ve dizinler üzerindeki yetkilerin, sahibi ve grubuna göre belirlendiğini bizzat deneyimledik. Yani örneğin düzenlemek istediğiniz dosya üzerinde yetkisi olan bir kullanıcı hesabını yönetmiyorsanız o dosyayı düzenleyemezsiniz bu kadar basit. Bu güzel bir güvenlik önlemi fakat, sistem üzerinde birden fazla kullanıcı hesabı ve grup oluşturulabileceğini biliyoruz. Dolayısıyla özellikle sistem yöneticisi olarak kimi zaman başka bir kullanıcının veya grubun sahipliğindeki dosya ve klasörler üzerinde işlem yapmamız da gerekebiliyor. 

Bu durumda düzenlemeyi yapmak için temelde üç alternatifimiz var. 

Öncelikle sistemdeki süper kullanıcı olan yani en yetkili kullanıcı olan root hesabına geçiş yapıp ilgili düzenlemeyi yapabiliriz. Fakat pek çok sistemde root hesabı varsayılan olarak aktif olmayabiliyor. Çünkü root en yetkili kullanıcı olduğu için gerekmedikçe bu yetkiyle çalışılması hiç güvenli değil. Ayrıca root hesabını aktifleştirip kullansak bile yetkili şekilde işlem yapması gereken tek kişi biz de olmayabiliriz. Sistem üzerindeki diğer kullanıcıların da yetkili şekilde işlem yapması gerekebilir. Bu durumda sistemdeki en yetkili kullanıcı olan root kullanıcısının parolasını herkesle paylaşmamız sizce mantıklı olur mu ? Kesinlikle olmaz. Çünkü herkes sistem üzerindeki tüm kontrole sahip olur ve güvenlikten söz edemeyiz. 

root hesabında oturum açmak istemiyorsak dosya veya dizinin sahibi olan kullanıcı olarak oturum açıp ilgili düzenlemeyi de yapabiliriz. Fakat tabii ki ilk yaklaşım da hem verimlilik hem de güvenlik açısından mantıklı bir yok değil. Düşünsenize yöneticisi olduğunuz bir sistemde 10 farklı kullanıcı bile olsa, 10 farklı hesap bilgisini hatırlayıp gerektikçe sürekli bu 10 farklı hesapta oturum açmanız gerekir. Bu kesinlikle mantıklı bir yaklaşım değil. Ayrıca yetkili şekilde işlem yapmaya bir tek sizin de ihtiyacınız olmayacak. Kimi kullanıcıların bazı başka kullanıcıların yetkilerini gerektiren işlemler yapması da gerekecek. Bu durumda tüm kullanıcıların birbiri ile parola bilgilerini paylaşmaları gerekir ki bu tamamen korkunç bir çözüm.

Bu yöntemler dışında üçüncü alternatifimiz ise komutlarımızı çalıştırırken ilgili kullanıcı gibi davranmamızı sağlayan sudo yapısından faydalanmak.

Başkası gibi komut çalıştırabilme yaklaşımı sayesinde, konfigürasyon dosyasında bu kullanıcılar gibi komutları çalıştırmak için kendimize yetki verdiysek, bu kullanıcıların şifresini bilmeden yani bu kullanıcı hesaplarında oturum açmamıza gerek kalmadan komutlarımızı tıpkı bu kullanıcılarmış gibi çalıştırabiliyoruz. 

Bu sayede biz başka bir kullanıcı gibi komut çalıştırdığımızda, aslında kendi hesabımızı kullanarak bu işlemi yaptığımız için bu işlemin kim tarafından yapıldığı da loglara kaydediliyor. Yani bu yaklaşım sayesinde yetkimiz olsa bile bu yetkileri hangi amaçla kullandığımız kayıt altında oluyor. Ayrıca tüm kullanıcılar kendi hesabını kullandığı için kullanıcı özelinde izin ve kısıtlama da tanımlayabiliyoruz. Yani başkası gibi davranma yetkilerini sınırlamamız da mümkün oluyor.

İşte bize bu imkanı sağlayan yapı da sudo yapısı. Sudo sayesinde önceden tanımlanmış kurallar dahilinde anlık işlemler sırasında sistem üzerindeki diğer kullanıcılar gibi davranabiliyoruz. Tekrar özetleyecek olursak sudo yapısı sayesinde kullanıcıların birbiri ile parola paylaşmasına gerek kalmadan, ve tüm işlemlerin kaydı tutularak komutlarımızı bir başka kullanıcı gibi çalıştırabiliyoruz. Başkası gibi davranabilme imkanı için tek ihtiyacımız konfigürasyon dosyasında bize bu konuda izin tanınmış olması. Zaten anlatımın devamında da bu konu üzerinde duruyor olacağız.

İşte sudo aracının en temel çalışma yapısı aslında bu şekilde. Eğer söylediklerim sizin için henüz anlamlı gelmiyorsa merak etmeyin bölüm sonunda tüm anlatımlar netleşmiş olacak.

Şimdiye kadar yetki gerektiren çeşitli işlerimiz için pek çok kez sudo yapısını kullandık. Şimdi daha yakından bakıp temel çalışma yapısı hakkında konuşmak istiyorum. 

sudo geçici olarak yetkilerimizi yükseltmemize olanak tanıyan bir araç. Biz herhangi bir komuttan önce sudo komutunu kullandığımızda, sudo aracının yapılandırma dosyası olan /etc/ içinde bulunan sudoers dosyasına bakılıyor. Eğer bu konfigürasyon dosyasında bize bu komutu çalıştırmak için özel ayrıcalık verildiyse komutu yetkili şekilde çalıştırabiliyoruz.

Bu yöntem sayesinde kullanıcılar root hesabının parolasını bilmeden de yetkileri varsa root düzeyindeki yetkilerle işlerini halledebiliyorlar. Zaten çoğu sistemde root hesabı güvenlik gerekçesiyle varsayılan olarak pasif şekilde geliyor. Yani root hesabını bizzat kullanmamız pek teşvik ve tavsiye edilmiyor. Ayrıca root hesabı pasif olmasa bile her önüne gelen kullanıcıyla sadece birkaç işini yetkili şekilde yapacak diye root hesabının parolasını paylaşmamız da mantıklı olmazdı. Bunun yerine sudo yapısı sayesinde geçici olarak root yetkileri ile hareket etmek çok daha mantıklı. Burada bahsettiklerimi daha iyi anlamak için root parolasını bilmeye gerek kalmadan root olarak işlem yapmaya basit bir örnek verebiliriz. 

Örneğin ben konsola whoami şeklinde yazacak olursam, bakın çıktı olarak kendi kullanıcı adımı aldım. Çünkü bu komutu kali kullanıcı olarak ben çalıştırdım. Şimdi bir de yetkili şekilde çalıştırmak için sudo whoami şeklinde komutumuzu girebiliriz. Bakın bizden kendi kullanıcı hesabımızın parolasını girmemizi istiyor. Girelim. 

Bakın sefer whoami sorgusunun yanıtı olarak root çıktısını aldık. Çünkü aslında biz burda sudo komutunu kullandığımızda whoami komutu root yetkileriyle çalıştırıldı. Dolayısıyla whoami aracı da komutu giren kişinin root olduğunu belirten çıktıyı bastırdı.

Komutumuzu root yetkileri ile çalıştırmış olmamızın yanında eğer dikkatinizi çektiyse bu işlem için root hesabının parolasına ihtiyacımız olmadı, yalnızca kendi hesabımızın parolasını girdik. Kendi hesabımızın parolasını girmemiz yeterli oldu çünkü mevcut hesabımız sudo üzerinden root yetkilerini kullanabilecek şekilde konfigürasyon dosyasında tanımlanmış. 

İşte bizzat bu basit örnekle teyit ettiğimiz gibi sudo aracı bizlere güvenli yoldan root yetkileri ile çalışabilmeyi sağlayan bir çözüm aslında.

sudo aracını kimlerin ne şekilde kullanabileceğini düzenlemek için /etc/sudoers dosyasını metin editöründe açıp düzenleyebiliriz. Düzenleme işlemi için de visudo komutunu aracını kullanmamız gerekiyor. Aslında normalde herhangi bir metin editörünü de kullanabiliriz fakat visudo aracı sayesinde dosyadaki yeni tanımların hata kontrolü yapıldığı için olası yanlış konfigürasyonların önüne geçmemiz de mümkün oluyor.

Konfigürasyon dosyasını açmak için sudo visudo komutuyla dosyamızı yetkili şekilde açabiliriz. Bakın dosyam şu anda template şablon halinde olduğu için burada .tmp uzantısı var. Eğer değişiklik yapıp kaydedecek olursak asıl dosya olan etc dizini atlındaki sudoers dosyasına kaydolmuş olacak. 

Şimdi dosya içeriğine bakacak olursak. Dosyanın en başında bulunan bu tanımlar güvenlik amaçlı. Burada da belirtildiği şekilde ayrıntılar için suoders dosyasının manual sayfalarına bakabilirsiniz. Ben detaylar üzerinde durmayacağım ama örneğin bakın ilk satır tanımlanmış olabilecek zararlı değişkenleri sıfırlıyor. İkini satır, root parolası yanlış girildiğinde tanımlı olan yöneticiye mail atılmasını sağlıyor, son satır ise zararlı dosyaları içerebilecek ek path yollarının tanımlanmış olma ihtimaline karşı standart olan path yolunu tekrar tanımlıyor. Dediğim gibi bunlar güvenlik önlemi bunlara müdahale etmeden devam edeceğiz. Daha fazla bilgi almak için manual sayfasına göz atabilirsiniz.

Diyez sembolü olan satırlar da zaten yorum satırları. Bunlar işleme alınmıyor. Gördüğünüz gibi tanımlı seçenekler hakkında kısa açıklamalar yazmak için kullanılıyor. Ayrıca örneğin bakın bazı tanımlamalar da var ama başında diyez işareti olduğu için pasif durumdalar. Dediğim gibi ben diğer ayrıntılar üzerinde duymayacağım, ihtiyaç duydukça aradınız çözüm için araştırma yapar ve manual gibi kaynakları kullanırsanız zaten hangi tanımlamayı neden kullanmanız gerektiğini öğrenebilirsiniz. Ben şimdi en temel işlem olan yetki tanımlamalarından bahsetmek için dosyanın altına geliyorum.

Buradaki ilk tanımlama ile başlayacak olursak, bu satır root kullanıcının sudo ayrıcalıklarını belirtiyor. 

Bu tanımlamadaki ilk kısım bu kuralın geçerli olacağı kullanıcın ismini belirtiyor. Yani bakın bu kural root kullanıcısı için tanımlanmış.

İkinci kısımdaki ALL ifadesi bu kuralın tüm hostlarda yani ağ üzerindeki tüm ana makinelerde geçerli olmasını sağlıyor.

Eşittir işaretinden sonra parantez içinde yazılan ilk ALL, root kullanıcısının komutları tüm kullanıcılar gibi çalıştırabileceğini gösteriyor. İkinci ALL ise root kullanıcısının komutları tüm gruplar gibi çalıştırabileceğini belirtiyor.

Hani dosya ve dizinlerin sahibini ve grubunu değiştirirken sahibi:grubu şeklinde tanımlama yapmıştık ya. İşte buradaki tanımlama da aynı aslında. Burada ALL:ALL şeklinde yazdığı için root kullanıcısı bir komutu çalıştırırken tüm kullanıcılar ve tüm gruplardakiler gibi ayrıcalıkla sahip oluyor.

En sondaki ALL ise bu kuralların tüm komutlar üzerinde geçerli olmasını sağlıyor. 

Şimdi muhtemelen, root kullanıcısı zaten sistemde en yetkili kullanıcı o zaman niye burada root kullanıcısı için bir daha yetki tanımlaması yapılıyor diye düşünmüş olabilirsiniz.

Normalde biz root hesabını kullanıyorken girdiğimiz tüm komutlarımızı en yetkili şekilde çalıştırabiliyoruz. Fakat biz root hesabındayken alışkanlık gereği yine sudo komutunu kullanırsak, sudo aracı konfigürasyon dosyasında root kullanıcısı için yetki tanımlaması olmadığı için en yetkili kullanıcı da olsa hata verir. Ne denemek istediğimiz daha net anlamak için hemen yeni bir konsol başlatalım. Ben bu konsol üzerinden root hesabına geçiş yapmak istiyorum fakat benim sistemimde root hesabı şu anda pasif durumda. Aktifleştirmek için root hesabına bir parola belirlemem gerekiyor. Bunun için de sudo passwd root şeklinde komutumu girebilirim. Öncelikle mevcut hesabımın parolasını girip bu komutu yetkili şekilde çalıştırıyorum. Tamamdır şimdi root için yeni parola belirleyebiliriz. Parolamızı onaylamak için ikinci kez yazalım. Tamamdır, artık root hesabının bir parolası olduğu için root hesabına geçiş yapabiliriz. Ben su root komutuyla geçiş yapıyorum.

Şimdi denemek için yine yalnızca whoami şeklinde komutumuzu girebiliriz. Bakın root çıktısını aldık. Şimdi bir de sudo whoami şeklinde girelim. Bakın yine root çıktısını aldık çünkü şu an pek fark edilmese de whoami komutunu sudo aracılığıyla yine root yetkileriyle çalıştırdık. Şimdi ben tekrar konfigürasyon dosyama dönüp, burada root için tanımlı olan satırın başına diyez ekleyip bu satırın yorum halini alıp görmezden gelinmesini istiyorum. Tamamdır. Ctrl x ile dosyamızı kapatıp değişikliği onaylayabiliriz. Evet root için sudo aracının kullanım ayrıcalığını kaldırdık. Şimdi tekrar root hesabında oturum açtığımız konsola dönüp whoami komutunu çalıştırmayı deneyebiliriz. Bakın ben yine tek başına whoami yazdığımda çıktı olarak root yanıtını alıyorum. Şimdi sudo whoami şeklinde yazmayı deneyelim. Bakın bu kez root kullanıcısın sudoers dosyasında yani sudo aracının konfigürasyon dosyasında tanımlı olmadığını belirtildi ve komutumuz çalıştırılmadı. Çünkü biz sudo whoami şeklinde komut girdiğimizde sudo aracı, bu komutu giren kullanıcı için bir konfigürasyon var mı diye sudoers dosyasın bakıyor eğer yoksa bu komutu çalıştırmayı reddediyor. 

Eğer yetki gerektiren işler için sudo aracını kullanmaya alıştırsanız root hesabına geçiş yapıp root olarak çalışıyor olsanız da alışkanlık gereği sudo komutunu kullanmaya devam edebilirsiniz. Bu durumda sudo dosyasında root hesabı için tanımlama yoksa hata almanız da kaçınılmaz.

Ayrıca etkileşimli şekilde root hesabını kullanmak dışında örneğin sistemin işleyişi için kullanılan bir betik dosyası içerisinde sudo komutu bulunuyor olabilir. Ve bu betik dosyasını root hesabı üzerinden çalıştıracak olursak , tıpkı buradaki gibi sudoers dosyasında root için tanımlama olmadığından dolayı en yetkili kullanıcı da olsa hata alırız. Yani içerisinde sudo komutu bulunan betik dosyamız doğru şekilde çalışmaz. 

Özetle bizzat teyit ettiğimiz gibi, root kullanıcısı en yetkili kullanıcı da olsa sudo komutunun işleyişi dolayısıyla stabil bir sistem yönetimi için sudoers dosyası içinde bulunması gerekiyor.

Şimdi ben konfigürasyon dosyasından biraz daha bahsetmek üzere sudo visudo komutu ile tekrar açıyorum. Açıklamalara devam etmek için tekrar alt satırlara gelelim.

Ben buradaki diyez işaretini kaldırıp, root kullanıcısının tüm komutları sudo üzerinden en yetkili şekilde çalışma devam etmesini sağlıyorum. Şimdi burada root kullanıcı üzerinden bizzat gördüğümüz, tek bir kullanıcı için geçerli olan yetki tanımlaması dışında eğer istersek spesifik bir gruba da yetki tanımlaması yapabiliyoruz. 

Bakın tıpkı buradaki sudo grup tanımı gibi, sudoers dosyasında, başında yüzde işareti olan tanımlamalar grubu temsil ediyor. 

Gördüğünüz gibi bu sudo gurubu için de tüm yetkiler tanımlanmış, dolayısıyla bu gruba dahil olan tüm kullanıcılar bu yetkiler dahilinde hareket edebiliyor. 

Hatırlıyorsanız gruplardan bahsederken kali kullanıcısının sudo grubuna dahil olduğunu da görmüştük. Hatta tekrar teyit etmek istersek, yeni bir konsol açıp groups kali şeklinde komutumuzu girebiliriz. Bakın kali kullanıcısı sudo grubuna da dahil. Bu sayede biz kali kullanıcısını yönetiyorken, sudo aracını kullandığımızda buradaki sudo grubu için tanımlı olan bu yetkiler dahilinde işlerimizi yürütebiliyoruz. 

Dolayısıyla örneğin tıpkı kali kullanıcısında olduğu gibi aynı yetkilere sahip olmasını istediğimiz kullanıcılar olursa onları da sudo grubuna ekleyip bu yetkiler dahilinde hareket etmelerini sağlayabiliriz. Ya da yeni bir grup oluşturup, burada bu gruba özel olarak izin tanımlaması da yapabiliriz. 

Ayrıca bu noktada dikkatinizi çekmek istediğim bir husus var. Sizin kullandığınız dağıtımdaki sudoers dosyasında buradaki gibi sudo isimli bir grup varsayılan olarak tanımlı olmayabilir. Farklı isimde örneğin admin veya wheel isimlerinde gruplar da tanımlı olabilir. Hatta hiç bir grup tanımlanmamış da olabilir. Burada asıl mesele istersek tek bir kullanıcı için veya daha fazla kişiyi etkilemesi için bir gruba özel yetki tanımlaması yapabiliyor olmamız. Bu tanımlamalar varsayılan olarak bu dosyada bulunmasa bile biz ihtiyaçlarımıza göre kendimiz ekleyebiliriz. 

Gruplar dışında bakın burada @includedir tanımının ardından bir dizin adresi belirtilmiş. Bu tanımlama sayesinde yalnızca mevcut sudoers dosyası değil, bu dizin altında yer alan diğer konfigürasyon dosyaları da okunup geçerli oluyor. Bu yaklaşım sayesinde etc dizini altındaki ana sudoers dosyasında yani şu an görüntülediğimiz dosyada değişiklik yapmadan bu dizindeki dosyalarda güvenli şekilde tanımlamalar yapabiliyoruz. Şu an incelediğimiz bu sudoers dosyası sudo için ana dosya olduğu için genellikle en temel tanımlamalar burda oluyor ve özellikle çok fazla tanımlama yapılacaksa burada belirtilen dizindeki konfigürasyon dosyalarında yapmak sistemi düzenli kullanmak adına çok daha doğru bir yaklaşım. Zaten pek çok aracın konfigürasyon dosyasında da aslında bu yaklaşım kullanılıyor. Ana konfigürasyon dosyasını sade tutmak ve mevcut yapısını bozmamak için konfigürasyon dosyasının isminin sonuna .d eklenmiş bir dizinde harici konfigürasyonlar tanımlanıp kullanılabiliyor. Buradaki .d ifadesi directory yani dizin ifadesinin kısaltmasından geliyor. Özetle şimdiden haberiniz olsun, tıpkı burada sudoers dosyasında olduğu gibi sistem üzerindeki diğer çeşitli konfigürasyonlarda da bu şekilde harici konfigürasyonların alt dizinde tutulduğuna şahit olacaksınız.

Şimdi tekrar sudoers dosyasına dönecek olursak, buraya dahil edilen dizin içeriğine bakmak için öncelikle mevcut konfigürasyon dosyamızı kapatalım. Şimdi ls /etc/sudoers.d/ komutuyla dizin içeriğini listeleyebiliriz. Örneğin bakın benim sistemimde kali-grant-root isimli bir konfigürasyon dosyası var. Okumak için visudo aracının ardından bu dosyanın tam konumu yazabiliriz. Bakın burda kali-tursted isimli bir grup tanımlanmış ve bu guruba tüm komutları parola olmadan çalıştırabilme yetkisi tanımlanmış. Buradaki NOPASSWD ifadesi parola sorulmadan buradaki yetkilerin uygulanabilmesini sağlıyor.

Dolayısıyla bu kali-trusted grubundaki tüm kullanıcılar tüm komutları kendi parolaları dahi sorulmadan sorunsuzca çalıştırabilirler. Hatta buradaki yetki tanımlamasının etkisini bizzat görmek için bu gruba bir kullanıcı ekli mi diye kontrol edip, varsa o kullanıcı üzerinden testimizi gerçekleştirebiliriz. Ben yine yeni bir konsol açmak istiyorum. Şimdi bu gruptaki kullanıcıları listelemek için grep “kali-trusted” /etc/group şeklinde komutumuzu girebiliriz. Bakın bu grup hakkında bilgi sunan satır filtrelendi ama buradaki tanımlamanın sorunda yani gruba dahil olan kullanıcıların bulunması gereken sütunda herhangi bir kullanıcının ekli olmadığını görebiliyoruz. Eğer testi yine de gerçekleştirmek istersek bu gruba kullanıcı ekleyip deneyebiliriz. Ben nil isimli kullanıcı hesabını bu gruba dahil etmek istiyorum.

Bunun için sudo usermod -aG kali-trusted nil şeklinde yazabiliriz. Ayrıca burada usermod aracı yerine gpasswd aracını da kullanabileceğimizi biliyorsunuz. Ben yalnızca ilk aklıma usermod geldiği için bu aracı kullanıyorum. Tamamdır komutumuzu onaylayalım. Bakın kali kullanıcısı sudo grubunda olduğu için ve sudo grubundakilere parola sorulmaması gibi özel bir tanımlama olmadığı için kali kullanıcısı yetkili şekilde bir işlem yapmadan önce buraya parolasını girmesi gerekiyor. Parolamı girip işlemi onaylıyorum. Tamamdır, artık nil kullanıcısının kali-trusted grubuna eklenmiş olması lazım. Kontrol etmek için yine grep “kali-trusted” /etc/group komutunu geçmişten çağırıp kullanabiliriz. Bakın bu sefer son sütunda nil kullanıcısının ismi gözüküyor. Yani gruba ekleme işlemi başarılı. Şimdi yetki işlemini teyit etmek için hemen su nil komutuyla nil kullanıcı hesabına geçiş yapalım.

Tamamdır. Şimdi tekrar sudoers.d dizini altındaki konfigürasyon dosyasına dönecek olursak, bakın burada bu gruba dahil olan tüm kullanıcıların tüm komutları parola olmadan çalıştırabileceği belirtiliyor. Şimdi bu durumu teyit etmek için tekrar nil kullanıcısı olarak oturum açtığımız konsola geri dönelim. 

Basit olması için mesela yine sudo whoami komutunu girebiliriz. Bakın bana parola sorulmadan anında whoami komutunu en yetkili kullanıcı olan root kullanıcısının yetkileriyle çalıştırmış oldum. İşte bu basit örnek, konfigürasyon dosyasındaki parola sorulmadan tüm yetkileri veren tanımlamanın geçerli olduğunun kanıtı.

Eğer süper kullanıcı yetkilerine kendi hesabının şifresini bile girmeden erişmesini istediğimiz kullanıcılar varsa bu gruba ekleyebiliriz. Ya da örneğin sizde böyle bir grup tanımlaması yoksa, buradaki tanımlamanın aynısını yaparak aynı konfigürasyonların geçerli olmasını da sağlayabilirsiniz. Fakat tabii ki burdaki gibi sınırsız yetkiyi kime vermek istediğinize de iyi karar vermeniz gerekiyor çünkü bu durum sistem güvenliği için tehlikeli olabilir. Bu mevcut tanımlamalarla tüm yetkileri vermek yerine eğer istersek  ihtiyaçlarımıza göre farklı kısıtlamalar içeren bir grup da ya da kullanıcı özelinde tanımlamalar da oluşturabiliriz. 

Şimdi gelin çok kısaca bu tanımlamalardan bahsederek devam edelim.

## Özel Kural Tanımlama

Herhangi bir kullanıcıya başka bir kullanıcı gibi davranma yetkisi verdiğimde özellikle o kullanıcı gibi çalıştırılması için sudo -u kullanıcı adı komut şeklinde komut girmemiz gerekiyor. veya grup için sudo -g grup komut şeklinde girmemiz gerekiyor. Biz ALL ile tüm kullanıcı ve grupları temsil ettiğimiz için hangi kullanıcı olarak davranmamız gerektiği sorulmadan tüm kullanıcılar gibi davranabilmemiz sağlanıyor.

```bash
┌──(ali㉿kali)-[/home/kali]
└─$ sudo whoami                                                      
[sudo] password for ali: 
Sorry, user ali is not allowed to execute '/usr/bin/whoami' as root on kali.

┌──(ali㉿kali)-[/home/kali]
└─$ sudo -u kali whoami
[sudo] password for ali: 
kali
```

Artık sudoers dosyasının genel sözdizimine aşina olduğumuza göre, ihtiyaçlarımıza göre bazı yeni kurallar tanımlayabiliriz. Tanımlama yaparken etc dizini altındaki sudoers dosyası içinde veya sudoers.d dizini altındaki dosyalarda tanımlama yapmamız mümkün. Ben bu dizin altında yeni konfigürasyon dosyası oluşturmak için sudo touch /etc/sudoers.d/yeni-tanim şeklinde komutumu giriyorum.

Tamamdır. ls -l /etc/sudoers.d/ dizin içeriğini listeleyelim. Bakın yeni dosyam oluşturulmuş. Ama tabii ki bu işlemi sudo komutuyla yaptığım için dosyanın sahibi ve grubu root olarak gözüküyor. Dolayısıyla dosyayı düzenlemek için de sudo komutunu kullanmamız lazım. Şimdi düzenlemek üzere sudo visudo /etc/sudoers.d/yeni-tanim komutuyla dosyamızı açalım.

Ben öncelikle tek bir kullanıcı için özel tanımla yapmak istiyorum. Dosyaya sonradan baktığımızda bu tanımlamayı neden yaptığımızı daha net anlayabilmek için diyez işaretinden sonra kısaca açıklama ekleyebiliriz. Örneğin ben ali kullanıcısı için tanımlama yapmak istediğim için buraya ali kullanıcısı için yetki tanımlaması şeklinde yazıyorum. Yorum satırına yazacaklarınız bittiğinde normal veri girişine dönmek için enter ile bir alt satıra geçmeniz yeterli. Bakın bir alt satıra geçince diyez işaretinin sağladığı yorum satırından çıkmış olduk. Şimdi tanımlamamızı yapabiliriz. 

Tek bir kullanıcıyı etkileyecekse, doğrudan kullanıcının ismini yazmamız gerekiyor. Ben de ali şeklinde yazıyorum. Tanımlayacağım bu yetkinin tüm hostlarda geçerli olmasını istediğim için kullanıcı ismini yazdıktan sonra boşluk bırakıp ALL yazıp eşittir işaretini koyuyorum. Şimdi yetki tanımlamasını bu eşittir işaretinden sonra yazabiliriz. 

Ben ali kullanıcısının herhangi bir kullanıcı veya grup olarak komut çalıştırmasını istemediğim için parantez açıp içine hangi kullanıcılar veya gruplar olarak komut çalıştırabileceğini belirtmiyorum. Biz özellikle kullanıcı adı veya grup belirtmediğimizde komutlar root yetkileriyle çalıştırılıyor olacak. Eğer siz tüm kullanıcı hesapları ve grupları gibi komut yürütebilmesini isterseniz ALL:ALL şeklinde belirtebilirsiniz. İleride komutlarımızı nasıl farklı kullanıcılar veya gruplar gibi çalıştırabileceğimizden bahsettiğimizde buradaki tanımlama sizin için çok daha anlaşılır olacak. Ayrıca isterseniz tüm kullanıcılar gibi çalıştırma yetkisi yerine spesifik olarak istediğiniz kişi veya grupları da aralarına virgüller belirtebilirsiniz. Ben hiç birini istemediğim parantez açmıyorum. Ancak merak etmeyin bu tanımlaya daha sonra tekrar döneceğim. Ben bu şekilde bıraktığım için ali kullanıcısı komutlarını yalnızca root olarak çalıştırabiliyor olacak.

Son olarak eğer ali kullanıcısının tüm komutları root yetkileriyle çalıştırabilmesini istersem sonda ALL şeklinde yazabilirim ancak ben size kısıtlı yetkiyi göstermek için ali kullanıcısının yalnızca ls aracını kullanmasına izin vermek istiyorum. Bunun için de ls aracının tam dosya konumunu buraya yazmam yeterli.

Ben ls aracının tam dosya konumunu bilmediğim için yeni bir konsol açıyorum. Şimdi burda which ls komutu ile öğrenebiliriz. Bakın dizin adresi buymuş. Bu dizini konfigürasyon dosyamıza ekleyebiliriz.

Ben tek bir aracı ekledim ancak isterseniz virgülle ayırarak birden fazla aracı da ekleyebilirsiniz. Örneğin mkdir aracını da root yetkileri ile çalıştırmasını istersem mkdir aracının dosya konumunu da buraya ekleyebilirim. Yine which mkdir ile sorgulayalım. Virgül koyup bu aracın dizin adresini de tam olarak ekleyelim. Tamamdır. İşte bu şekilde istediğimiz kullanıcı hesabına istediğimiz araçları root olarak çalıştırabilme yetkisi verebiliyoruz. Kuralı kendi ihtiyacınıza göre istediğiniz şekilde özelleştirebilirsiniz. Kuralı denemek için öncelikle konfigürasyon dosyamızı ctrl x ile kaydedip kapatlım.

Tamamdır. Şimdi ben tanımlamayı ali kullanıcısı için tanımladım için su ali komutu ile bu kullanıcı hesabına geçiş yapıyorum. Tamamdır. Şimdi denemek için öncelikle /root dizini içinde yeni bir klasör oluşturmayı test edebiliriz. Ben mkdir /root/test şeklinde komutumu giriyorum. Bakın yetki hatası aldık. Şimdi aynı komutumuzu sudo başta olacak şekilde tekrar girelim. Bakın bu sefer herhangi bir hata bastırılmadı. Emin olmak için ls /root komutu ile dizin içeriğini listelemeyi deneyebiliriz. Fakat bakın /root dizinini listelemeye de yetkimiz yok. Bu sorunu da aşmak için sudo ls /root şeklinde komutumuzu tekrar girebiliriz. Bakın bu sefer sudo sayesinde root yetkileriyle yeni oluşturduğum klasörü yine sudo sayesinde ls komutu ile root yetkileri dahilinde listelemiş oldum. Yani ali kullanıcısı için tanımladığımız konfigürasyonun geçerli olduğunu bizzt teyit etmiş olduk.

Ben tanımlama sırasında yalnızca ls vs mkdir araçlarının root yetkileriyle çalıştırılması için yetki vermiştim. Bu durumdan emin olmak için şimdi sudo whoami komutu ile whoami aracını root yetkileriyle çalıştırmayı deneyebiliriz. Bakın buradaki çıktıda whoami dosyasının root olarak çalıştırılamayacağına dair uyarı aldık. Bu hatayı aldık çünkü whoami aracının dosyası ali kullanıcısı için root yetkileri dahilinde tanımlanmamıştı.

İşte kullanımını bizzat teyit ettiğimiz şekilde dilediğimiz kullanıcıya dilediğimiz aracı root olarak çalıştırabilmesi için sudo kuralı tanımlayabiliyoruz.

Ben exit komutu ile ali kullanıcı oturumunu kapatıyorum. Şimdi diğer konfigürasyon seçeneklerinden bahsetmeye devam etmek için yine sudo visudo /etc/sudoers.d/yeni-tanim komutu ile konfigürasyon dosyamızı açabiliriz.

Bakın ben örnek olması için burada tek bir kullanıcı için yani ali kullanıcısı için bu yetkiyi tanımladım. Bu yetki yalnızca ali kullanıcısı için geçerli olacak. Eğer inanmıyorsanız farklı bir kullanıcı hesabı üzerinden aynı şekilde sudo komutu ile yetkili şekilde işlem yapmayı bizzat deneyebilirsiniz.

Ben burada tek kullanıcı için tanımladım ama tek tek kullanıcı yerine yeni bir grup da tanımlayabiliriz. Grup tanımlarken, grubun isminin başında yüzde işareti koymanız yeterli. Bu sayede bu yazdığınız isminin kullanıcı ismi değil grup ismi olduğu anlaşılabilir. Örneğin ben buradaki ali ifadesini silip %kali şeklinde yazacak olursam, artık buradaki tanımlama kali grubundaki tüm kullanıcılar için geçerli olacak.

Bu durumu teyit etmek isterseniz yine aynı şekilde kendiniz test edebilirsiniz. Buraya yazdığınız grubun elemanları buradaki yetki sınırları dahilinde hareket edebiliyor olacak.

Ben buradaki yetki tanımlaması hakkında birkaç detaydan daha bahsedip sudo anlatımını bitirmek istiyorum.

Örneğin bakın ben burada ALL= çalıştırılacak dosyaların isimleri şeklinde belirttim.

Bu tanım sayesinde buradaki araçlar root yetkileriyle çalıştırılabilyor.

Eğer ben yalnızca root yetkileriyle değil de istediğim bir kullanıcı veya grup olarak bu dosyayı çalıştırmak istersem buradaki eşittir işaretinden sonra parantez içinde isteklerimi belirtebilirim.

Örneğin eğer (ALL) şeklinde yazarsak tüm kullanıcılar olarak çalıştırılabilir veya (ALL:ALL) şeklinde yazacak olursak da tüm kullanıcı ve gruplar olarak çalıştırılabilir. Buradaki tüm kullanıcılardan kastım, sudo komutuna -u veya -g seçeneklerini verip komutumuzu hangi kullanıcı veya grup olarak çalıştırmak istediğimizi belirtmek. Daha iyi anlamak için hemen test edebiliriz. Bunun için ben buraya bir de whoami aracını eklemek istiyorum. Bunun için aracımızın konumunu which whoami komutu ile öğrenelim. Tamamdır virgülden sonra bu aracımızın dosya konumunu da ekleyelim. Ve bakın burada kali grubundaki kullanıcılar tanımlı olduğu için ben kali kullanıcısı olarak buradaki tanımlama benim için de geçerli. O yüzden tanımlamayı Ctrl X ile bu şekilde kaydedip, dosyamı kapatıyorum.

Tamamdır. Testlere geçmeden önce mevcut kullanıcı hesabımız için tanımlı olan sudo konfigürasyonlarını görmek istersek sudo -l komutunu kullanabiliriz. Bakın kali kullanıcısı için buradaki tanımlama geçerli gözüküyor. Kali kullanıcı sudo grubuna dahil olduğu için bildiğiniz gibi buradaki tanımlama kali kullanıcısına tüm yetkileri veriyor. Yine de bakın alt tarafta bizim tanımladığımız kural da bulunuyor. Tanımlamanın geçerli olduğunu da teyit ettiğimize göre şimdi denemek için öncelikle whoami yazalım. Bakın mevcut kullanıcı ismimizi aldık. Şimdi sudo whoami şeklinde yazalım. Bakın bu kez komutumuz root yetkileri ile çalıştırıldığı için root çıktısını aldık.

Ben bir de komutumu nil kullanıcısı olarak çalıştırmak istiyorum. Bunun için user ifadesinin kısaltmasından gelen u seçeneğini sudo aracına verebilirim. Yani ben komutumu sudo -u nil whoami şeklinde giriyorum. Bakın komutumu nil kullanıcısının yetkileri ile çalıştırdığım için whoami komutunun çıktısında nil cevabını aldım. Ali olarak çalıştırmak için sudo -u ali whoami komutunu girebilirim. Bakın bu kez de ali yanıtını aldık çünkü bu komutumuzu da ali kullanıcısının yetkileriyle çalıştırdık. Yan gördüğünüz gibi biz özellikle -u seçeneğiyle belirtmediğimiz sürece sudo aracı komutlarımızı root yetkileriyle çalıştırıyor. Benzer şekilde bir grubun yetkileri dahilide işlem yapmak için de -g seçeneğinin ardından gurubu girip peşi sıra komutumuzu girebiliriz. Fakat grubun yetkileri dahilinde hareket ettiğimi kanıtlamak için whoami komutunu kullanamam.

Örneğin id komutunu girince bakın buradaki gid yani grup numarası yazıyor. Eğer sudo id şeklinde girersem, gördüğünüz gibi root kullanıcısının grup numarası burada gözüküyor. Ben nil grubunun yetkileri dahilinde id komutunu girmek istediğim için sudo -g nil id şeklinde de komut girebilirim. Bakın bu kez nil grubunun yetkileri ile bu komutu çalıştırdığım için yanıt olarak nil grubunun id si verildi.

Umarım buradaki açıklamalar yeterince anlaşılır olmuştur. Zaten genelde istisnalar hariç root yetkilerine erişmek için sudo aracını kullanacağınız için diğer kullanıcı veya grupların yetkilerini kullanma ihtiyacı hissetmeyeceksiniz. Yine de konfigürasyon dosyasındaki tanımı net biçimde anlayabilmeniz için buradaki detaydan da bahsetmek istedim. 

Son olarak bahsetmek istediğim ufak bir ayar daha var. Onun için tekrar konfigürasyon dosyamızı açalım.

Bakın ben burada tüm kullanıcı ve grupların yetkilerini kullanabilmeniz için ALL:ALL şeklinde tanımladım ama mesela yalnızca nil kullanıcısının ve ali ile kali grubunun yetkilerinin kullanılmasını istersem nil:ali,kali şeklinde de yazabilirim. Eğer kofigürasyon dosyasını bu şekilde kaydedersem, kali grubundakiler yalnızca root ve nil kullanıcılarının ve ali ile kali grubun yetkileri dahilinde komutlarını çalıştırabiliyor olacaklar. Örneğin sisteme yeni bir kullanıcı eklenirse, veya zaten burada tanımadığımız dışında bir kullanıcı varsa o kullanıcın yetkileri dahilinde komutlarını çalıştırmazlar. Çünkü biz özellikle kimler gibi çalıştırabileceğini burada özellikle belirtmiş olduk.

Ayrıca son olarak eğer istersen bu yetkiler ile çalıştırılamayacak spesifik bazı araçları da belirtebiliriz. Örneğin tüm araçlara izin verip yalnızca whoami aracının sudo ayrıcalıkları ile çalıştırılmasını önlemek için ALL, !/usr/bin/whoami şeklinde kural belirtebilirim.

Ben şimdi ali kullanıcısının tüm araçları yalızca root yetkiler ile kullanıp yalnızca whoami aracını kullanamamasını istiyorum. Ve ayrıca ali kullanıcısına her defasında kendi parolasının da sorulmasını istemiyorum. Bunun için 

ali ALL= NOPASSWD: ALL, !/usr/bin/whoami 

şekline yazıyorum. 

Bakın burada ali kullanıcısına NOPASSWD etiketi ile parola sorulmadan whoami aracı hariç tüm araçların root yetkileri ile çalıştırılması gerektiğini tanımladık. Gördüğünüz gibi hariç tutmak istediğimiz araçları ünlem işareti ile belirtebiliyoruz.

Ben ctrl x ile dosyamı kaydedip kapatıyorum.

Tamamdır. Şimdi su ali komutu ile ali hesabına geçiş yapalım. Mevcut kullanıcı için geçerli konfigürasayonu listelemek için sudo -l komutunu kullanabiiriz. Bakı ali kullanıcısı için tanımladığım konfigürsyon burada yer alıyor. 

Şimdi ben denemek için sudo ls /root şeklinde komutumu girmek istiyorum. Bakın herhangi bir yetki hatası almadan komutumuzu root yetkileri dahilinde çalıştırmayı başardık. Şimdi bir de hariç tuttuğumuz whoami aracını sudo whoami komutu ile çalıştırmayı deneyebiliriz. 

Bakın bu kez hata aldık. Yani bu çıktıyla birlikte tanımladığımız yetkinin tam istediğimiz gibi çalıştığını da teyit etmiş olduk. Ayrıca mesela bakın ben burada ek kullanıcı veya grup ile çalıştırma yetkisi tanımlamadığım root haricinde bir kullanıcı veya grup olarak komut çalıştırmam mümkün de değil. Denemek için sudo -u nil ls komutunu girebiliriz.

Bakın bu aracın nil olarak yani nil kullanıcısının yetkileri ile çalıştırılamayacağına dair uyarımızı aldık.

Böylelikle sudo komutu ve sudoers kuralları hakkında bilmemiz gereken tüm temel detaylardan bahsetmiş olduk. Yani artık sudo ayrıcalıklarına sahip olması gereken kullanıcıları ve bu kullanıcının hangi araçlar üzerinde bu sudo ayrıcalıklarını kullanabileceklerini tam olarak istediğiniz şekilde ayarlayabilecek kadar bilgiye sahipsiniz. Gerisi pratik yapıp sonuçlarını gözlemleye kalıyor. 

Ayrıca tabii ki sudo aracının kullanım özellikleri benim anlattıklarımla sınırlı değil. Diğer özellikleri için internet ve manual sayfaları size gereken ek detayı sağlayacaktır. Özellikle söz konusu yetki yönetimi olduğu için güvenlik açısından veriler yetkiler dikkatlice tanımlanmalı. Örneğin standart bir aracı root yetkisi ile çalıştırma izni olan bir kullanıcı, ilgili araç üzerinden root yetkileri ile tüm yetki mekanizmasını aşıp sisteme zarar verebilir. 

Ne demek istediğimi somut bir örnek üzerinden ele almam gerekirse tekrar konfigürasyon dosyamızı açabiliriz. Şimdi diyelim ki ben ali isimli kullanıcıya yalnızca vi metin editörünü root yetkileri ile çalıştırabilmesi için yetki vermek istiyorum. Bunun için burada çalıştırılabilecek araç bölümüne yalnızca vi aracının dosya konumunu ekleyebilirim. Benim sistemimde vi aracı /usr/bin/vi dizininde bulunduğu için bu şekilde giriyorum. Tamamdır. Şimdi ctrl x ile dosyamızı kapatıp kaydedelim.

Ben test etmek için su ali komutu ile ali kullanıcı hesabına geçiş yapıyorum. Ben yalnızca vi aracı için root yetkilerini tanımladığım için normalde ali kullanıcısı vi dışında hiç bir komutunu root yetkileri ile çalıştıramaz. Bunu teyit etmek için sudo whoami şeklinde komutumuzu girebiliriz. Bakın root yetkisi ile çalıştıramadık. Benzer şekilde yine sudo ls ile bir kez daha teyit edebiliriz. Bakın yine hata aldık. Şimdi sudo vi komutu ile vi aracımızı root yetkileri dahilinde açalım. Bakın aracım sorunsuzca açıldı. Peki ben şu an ali kullanıcısının yetkilerini gerçekten de kısıtlamış mı oldum sizce ? Görünürde evet ama, vi editörü kendi içinde kabuk komutlarını çalıştırabildiği için ve biz de vi editörünü root yetkileri ile açtığımız için aslında tıpkı root kullanıcısı gibi komutlar girebiliriz. vi editöründe komut çalıştırmak için iki nokta üst üste işaretinden sonra ünlem işaretini yazmamız ve çalıştırmak istediğimiz komutu girmemiz yeterli. Ben test etmek için whoami şeklinde yazıp komutumu onaylıyorum. Bakın root yanıtını aldık, yani normalde yetkimiz olmadığı halde whoami aracını yetkili şekilde çalıştırmayı başardık gördüğünüz gibi.

İşte tıpkı bu örneğimizde olduğu gibi hangi kullanıcıya hangi yetkileri verdiğinize dikkat etmezseniz sisteminizde güvenlikten söz edemezsiniz. Buradaki vi aracı yalnızca tek bir örnek. Bunun gibi sayısız örnek verilebilir. Önemli olan sizin sisteminizde yüklü olan ve kullanıcınıza çalıştırması için yetki verdiğiniz araçların davranışlarını araştırıp buna göre yetki tanımlamaları yapmanız. 

Neyse bence artık sudo aracı hakkında gerekli olan tüm temel bilgilerden bahsetmiş olduk. Artık tek ihtiyacınız pratik yaparak öğrendiklerinizi pekiştirmek ve merak ettiğiniz soruları kendi kendinize araştırıp uygulama yaparak kavramak.

# su Komutu Hakkında

Şimdiye kadar özellikle ele almamış olsak da aslında kullanıcı hesapları arasında geçiş yapmak için su komutunu defalarca kez kullandık. su komutunun ismi de switch user yani kullanıcı değiştir ifadesinin kısaltmasından geliyor.

Bildiğiniz gibi su komutu kendisinden sonra belirtilmiş olan kullanıcı hesabında mevcut konsol üzerinden oturum açmayı sağlıyor. Fakat bu komutu kullanırken aslında temelde iki alternatif kullanım yönetimine sahibiz. Eğer su komutundan sonra yalnızca geçiş yapılması gereken kullanıcı ismini girersek, bu kullanıcı hesabı mevcut bulunduğumuz kabuğun altında yeni başlatılan kabukta bizim bu komutu girdiğimiz konumdan çalışmaya başlayacak. Mevcut kabuğun altında yeni bir kabuk başlatıldığı için de mevcut kabuk üzerinde geçerli olan ortam değişkenleri gibi çeşitli bilgiler de bu yeni başlatılan kabuğa aktarılıyor olacak.

Ne demek istediğimi en iyi örnek üzerinden açıklayabilirim. Şimdi ben farklı bir kullanıcı hesabına geçiş yapmadan önce export test=”bu bir testtir” komutuyla, test isimli yeni bir global değişken tanımlamak istiyorum. Bu sayede bu değişken mevcut kabuk altında başlatılan tüm alt kabuklarda da aynen geçerli olacak. echo $test ile değişkeni teyit edelim. Bakın tanımadığım değere şu an ulaşabiliyorum. Son olarak bir de mevcut bulunduğumuz dizini pwd komutu ile öğrenelim. Bakın ben şu anda bu kabukta kali kullanıcısının ev dizininde yani /home/kali dizininde çalışıyorum. 

Şimdi su root komutu ile root kullanıcısına geçiş yapmayı deneyebiliriz. Ben daha önce root hesabı için parola tanımladığım için burada tanımadığım parolayı giriyorum. Tabii siz root hesabını aktifleştirmediyseniz örnek için farklı bir kullanıcıya da geçiş yapmayı deneyebilirsiniz. 

Tamamdır root hesabı için tanımlı olan varsayılan kabuğa geçişimi yapmış oldum. Hatta kabuğu sorgulamak için echo $SHELL komutunu girebiliriz. Bakın benim kullandığım sistemde root hesabının varsayılan kabuğu zsh kabuğu olduğu için bu şekilde çıktı aldım.

Şimdi esas konumuza dönecek olursak ben kali kullanıcısının kabuğu üzerinde tanımlamış olduğum değişkene bu kabuk üzerinden ulaşıp ulaşamayacağımı merak ediyorum. Öğrenmek için echo $test şeklinde komutumuzu girelim. Bakın kali kullanıcısının kabuğunda tanımlı olan değişken burada da geçerli. Üstelik farklı kabuk olsalar bile değişken değeri aktarılmış. Bir de mevcut bulunduğumuz dizini de pwd komutuyla bastıralım. Bakın hala kali kullanıcısının ev dizinde çalışıyorum.

Burada hala aynı dizinde çalışma ve diğer kullanıcının kabuğunda tanımlanmış global değişkene ulaşabiliyor olma nedenim su komutunda sonra doğrudan yalnızca kullanıcı ismi girmiş olmam. Bu şekilde komut girdiğimizde su aracı ilgili kullanıcı hesabına geçiş yaparken mevcut kabuğun çalışma ortamındaki mevcut dizinini ve ortam değişkenleri gibi çeşitli özellikleri koruyarak geçiş yapılan kullanıcının kabuğunu alt kabukta başlatıyor. Yani aslında sıfırdan temiz bir kabuk başlatılmıyor.

Eğer biz mevcut kabuktan etkilenmeyecek temiz bir kabuk başlatılsın istersek komutumuz su - kullanıcı adı şeklinde girebiliriz. Ben denemek için mevcut root oturumunu kapatmak üzere exit komutunu giriyorum. Tamamdır. Şimdi temiz oturum açtığımız kullanıcın temiz bir kabuğunu başlatmak için su - root şeklinde komutumuzu girebiliriz. Parolamı giriyorum.

Tamamdır. Hemen bulunduğumuz dizini bastıralım. Bakın bu kez root kullanıcısının ev dizininde yani /root dizininde çalışmaya başladım. Bir de kali kullanıcısının kabuğunda tanımlı test isimli global değişkeni sorgulamak için echo $test şeklinde komutumuzu girelim. Bakın herhangi bir çıktı almadık çünkü bu değişken bu başlatılan kabuğa aktarılmadı. Biz su komutunda sonra tire işaretini girdiğimiz için bize geçiş yaptığımız kullanıcın varsayılan kabuğu standart ortam özellikleriyle birlikte tahsis edilmiş oldu.

Bu kullanım yani su - kullanıcı adı kullanımı özellikle güvenlik gerekçesiyle sistem yöneticileri tarafından sıklıkla tercih ediliyor. Çünkü farklı bir kullanıcı hesabına geçiş yapılmadan önce çalışılan mevcut kabuk üzerinde istenmeyen ortam değişkenleri tanımlanmış olabilir. Bu gibi güvenlik riski oluşturabilecek durumlardan kaçınmak için temiz bir kabuk başlatan su - kullanıcı-adı şeklinde komut girmek çok daha makul bir yaklaşım.

# Parola Kullanım Süresi Ayarlama

Daha önce parolaların geçerlilik süreleri olduğundan ve hesapları kilitleyip tekrar aktifleştirmek gibi detaylardan bahsetmiştik. Bir hesabı kilitlemek istediğimizde usermod komutunun -L seçeneğini kullanıp, kilitli olan hesabı açmak için de -U seçeneğini kullanabiliyoruz. Ayrıca bu yaklaşım dışında chage aracıyla hesap ve parola geçerlilik tarihleri de belirtmemiz mümkün. Genellikle kullanıcıları belirli aralıklarla parola değiştirmeye zorlamak düşünüldüğü kadar güvenli bir yaklaşım olmasa da, kimi zaman hesaplar için geçerlilik tarihi belirlemek isteyebiliriz.

Mevcut kullanıcı hesapları hakkında bu geçerlilik tarih bilgilerin öğrenmek için -l seçeneğini kullanabiliyoruz. Ben örnek olarak ali kullanıcısının bilgilerini sorgulamak için sudo chage -l ali şeklinde komutumu giriyorum.

Bakın çeşitli bilgiler bastırıldı. 

İlk sırada, en sonra parola değişikliğinin yapıldığı tarih var.

Daha sonra bu kullanıcı hesabı için parolanın ne zaman geçersiz olacağına dair bilgi var. Böyle bir tanımlama yapmadığımız için never yani asla olarak gözüküyor. Parolanın inaktif olacağı tarih de aynı şekilde.

Hesabın inaktif olma durumu da sınırlı değil. Örneğin geçici süre için bir kullanıcı hesabı oluşturmak istediğimizde, ilgili hesap için geçerlilik tarihi belirleyip zamanı geldiğinde otomatik olarak geçersiz kalmasını sağlayabiliyoruz.

Ayrıca parola değişikleri arasındaki minimum ve maksimum günleri ayarlamamız da mümkün. 

Son olarak buradaki sayı da, parola geçerlilik tarihini yitirmeden kaç gün önce ilgili kullanıcının uyarılacağını belirtiyor. Şimdi buradaki bilgileri nasıl düzenleyebileceğimizi öğrenmek için chage —help komutuyla yardım bilgisine göz atabiliriz.

Bakın, listede aldığımız tüm bilgileri düzenleyebileceğimiz seçenekler mevcut. Örneğin ben ali kullanıcısı hesabı için süre sınırlaması belirtmek istiyorum. Bunun için büyük E seçeneğini kullanabiliyormuşuz. 

Ben denemek için 2022 yılının 10 ayının ilk gününe kadar süre tanımak üzere sudo chage -E 2022-10-1 ali şeklinde komutumu yazıyorum. Bakın buradaki büyük E seçeneğinin hemen ardından son geçerlilik tarihini yıl ay gün şeklinde tire işaretiyle ayırarak belirtmemiz gerekiyor. Tamamdır şimdi değişimi kontrol etmek için tekrar sudo chage -l ali komutuyla sorgulayalım. Bakın 2022 yılının ekim ayında ali kullanıcısının hesabı geçersiz kalacak şekilde ayarlanmış oldu. Siz ihtiyacınıza göre istediğiniz bir günü belirtebilirsiniz. Zamanı geldiğin bu ali kullanıcısının hesabı otomatik olarak inaktif hale getirilecek, dolayısıyla kullanılamayacak. Benzer şekilde yardım bilgisinde görüntülediğimiz seçenekleri kullanarak buradaki diğer sınırlama değerlerini de değiştirebiliyoruz. 

Ben tek tek hepsine değinip vakit kaybetmek istemiyorum. 

Bunlar dışında hatırlıyorsanız ben size usermod komutunun L ve U seçenekleriyle hesapları anında kilitleyip aktifleştirebileceğimden bahsetmiştim. Eğer isterseniz bu yöntem dışında passwd aracının -l ve u seçeneklerini de aynı amaçla kullanabilirsiniz.

Yani örneğin ben ali kullanıcısının hesabını anında kilitlemek istersem, sudo passwd -l ali komutuyla bu kullanıcı hesabının parolasını geçersiz kılıp hesabında oturum açmasını engelleyebilirim. Komutumuzu onaylayalım. Bakın parolanın geçerlilik bilgisinin değiştiği belirtiliyor. Şimdi su ali yazıp bu hesaba geçiş yapamaya çalışalım. Ben parolasını doğru yazmama rağmen erişim hatası alıyorum. Şimdi kilitli olan hesabımızı sudo passwd -u ali komutuyla açıp tekrar deneyebiliriz. 

Bakın bu kez sorunsuzca ali kullanıcı olarak oturum açabildim.

En nihayetinde gördüğünüz gibi mevcut hesapların parola ve hesap geçerliliklerini burada bahsetmiş olduğumuz yaklaşımları kullanarak ihtiyacınıza göre kısıtlayabilirsiniz. 

Ben son olarak mevcut kullanıcı hesaplarını nasıl silebileceğimizden de bahsetmek istiyorum.

# Mevcut Kullanıcı Hesabını Silmek

Bunca konudan bahsettikten sonra, mevcut bir kullanıcı hesabını nasıl silebileceğimizden bahsetmediğimi fark ettim. 

Mevcut bir kullanıcıyı silmek için userdel komutuna silinmesini istediğimiz kullanıcı hesabının ismini girmemiz yeterli oluyor. Fakat bu şekilde kullandığımızda kullanıcı hesabının ev dizini silinmediği için ek olarak -r seçeneğini de eklemiz gerekiyor.

Örneğin ali isimli kullanıcı hesabını silmek istersem sudo userdel -r ali şeklinde komutumu girebilirim. Parolamızı girip onaylayalım. Bakın bende olduğu şekilde eğer sizin de silmek istediğiniz kullanıcının oturumu hala aktifse ve çalışmakta olan işlemler dolayısıyla silme işlemi başarısız olur. Bu durumda bu işlemleri sonlandırıp silme işlemini tekrar deneyebiliriz. İleride işlemleri nasıl sonlandırabileceğimizden bahsedeceğimiz için şimdi bunun yerine ben bu silme işlemini zorlayarak yapmak istiyorum. Bunun için force yani zorlama seçeneğini kullanabiliriz. Bu seçenek sayesinde, silmek istediğimiz kullanıcıya ait aktif işlemler olsa bile silme işlemi gerçekleştiriliyor. Ben komutumu bu kez sudo userdel -rf ali şeklinde giriyorum. Bakın bu kez aktif işlem olduğuna dair bir uyarı almadık. Kullanıcının silindiğini teyit etmek için su ali komutu ile geçiş yapmayı deneyebiliriz. Bakın böyle bir kullanıcının var olmadığına dair uyarı aldık. Bunun dışında dilerseniz ls /home komutuyla ev dizinin silindiğini de teyit edebilirsiniz. Gördüğünüz gibi ali için bir ev dizini artık mevcut değil.

Tabii ki biz buradaki işlemle kullanıcının ev dizinini ve kullanıcı kaydını sildik. Eğer sistemin farklı konumlarında bu kullanıcıya ait bu kullanıcın oluşturduğu dosya ve dizinler varsa onlar silinmedi.

İşte mevcut bir kullanıcıyı silmek için izlememiz gereken en temel yaklaşım bu.