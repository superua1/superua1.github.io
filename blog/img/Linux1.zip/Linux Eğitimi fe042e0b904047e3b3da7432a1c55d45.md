# Linux Eğitimi

[https://ubuntu.com/server/docs/](https://ubuntu.com/server/docs/)

Faydalı doküman: Google üzerinden diğer dokümanlarını da bulup kontrol et. [https://avys.omu.edu.tr/storage/app/public/emrecan/94761/1_sunucu-isletim-sistemlerine-giris.pdf](https://avys.omu.edu.tr/storage/app/public/emrecan/94761/1_sunucu-isletim-sistemlerine-giris.pdf)

Sektöre yönelik dns mail web server kurulumu gibi videolar ekleyecek misin ?

Mutlaka oku eksik olan kısımlar konusunda faydalan: [https://www.pardus.org.tr/kitaplar/LPI-Sertifikasyon-Kitabı-pardus.org.tr.pdf](https://www.pardus.org.tr/kitaplar/LPI-Sertifikasyon-Kitab%C4%B1-pardus.org.tr.pdf)

Kapsamlı kitap: [https://learning.oreilly.com/library/view/mastering-linux-administration/9781789954272/B13196_06_Final_NM_ePub.xhtml#_idParaDest-124](https://learning.oreilly.com/library/view/mastering-linux-administration/9781789954272/B13196_06_Final_NM_ePub.xhtml#_idParaDest-124)

RedHat baba kaynak: [https://learning.oreilly.com/learning-paths/from-zero-to/8204091500000000009/](https://learning.oreilly.com/learning-paths/from-zero-to/8204091500000000009/)

[0- Girizgah](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/0-%20Girizgah%20cce80a8724114683b64b28a260b894fb.md)

[✅ 1- Linux Nedir ?](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%201-%20Linux%20Nedir%208a0a19896bcd4ac09dc0a6b75729097a.md)

[✅ 2- Gerekli Çalışma Ortamının Kurulması](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%202-%20Gerekli%20C%CC%A7al%C4%B1s%CC%A7ma%20Ortam%C4%B1n%C4%B1n%20Kurulmas%C4%B1%20820493d2d2194d32b5370fa5e83148f5.md)

[✅ 3- Sistem Mimarisine Giriş](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%203-%20Sistem%20Mimarisine%20Giris%CC%A7%203e5f39865108492ca46d6a9989bb418f.md)

[✅ 4- Kabuk Nasıl Çalışır?](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%204-%20Kabuk%20Nas%C4%B1l%20C%CC%A7al%C4%B1s%CC%A7%C4%B1r%202091b6cbfd40407ea689e005a59916c7.md)

[✅ 5- Kısayollar](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%205-%20K%C4%B1sayollar%205e668172d14545e291e8367598fb3b63.md)

[✅ 6- Yardım Alma Komutları](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%206-%20Yard%C4%B1m%20Alma%20Komutlar%C4%B1%203fc0829e16c14a7f885c53379e0c2f0e.md)

[✅ 7- Dizinlerde Gezinti](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%207-%20Dizinlerde%20Gezinti%20b3e238d1bcd74b82a0861d9745815209.md)

[✅ 8- Bash Kabuk Genişletmeleri](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%208-%20Bash%20Kabuk%20Genis%CC%A7letmeleri%202de26021ef9841ba90226fb4ce230e00.md)

[✅ 9- Dosya İşlemleri PART 1](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee.md)

[9- Dosya İşlemleri PART 2](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/9-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%202%2018b2ce314b344a58a8374e3032ea094b.md)

[✅ 10- Metin Editörü Kullanımı | Nano & Vi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%2010-%20Metin%20Edito%CC%88ru%CC%88%20Kullan%C4%B1m%C4%B1%20Nano%20&%20Vi%202b23e4566ef34271a237ad274f2e5c19.md)

[✅ 11- Arşivleme ve Sıkıştırma İşlemleri](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%2011-%20Ars%CC%A7ivleme%20ve%20S%C4%B1k%C4%B1s%CC%A7t%C4%B1rma%20I%CC%87s%CC%A7lemleri%20d77c6c693ece4e22a2ebc7d7d83fd1a4.md)

[✅ 12- Bilgi Alma Komutları](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%2012-%20Bilgi%20Alma%20Komutlar%C4%B1%2041570e3991124f1cab8e7e5013b48cd4.md)

[14- Kullanıcı ve Grup Yönetimi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/14-%20Kullan%C4%B1c%C4%B1%20ve%20Grup%20Yo%CC%88netimi%2058629a017f47424aa80fc6cc758dcc69.md)

[15- Sembolik ve Katı Link](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/15-%20Sembolik%20ve%20Kat%C4%B1%20Link%209479cb7c294e4b86b89574b861a94fb8.md)

[16- Linux Dosya Sistemi Hiyerarşisi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/16-%20Linux%20Dosya%20Sistemi%20Hiyerars%CC%A7isi%2037212d4f034848f4899ee32595b7ea5d.md)

[17- Disk Yönetimi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/17-%20Disk%20Yo%CC%88netimi%208473f3dcf9ef41a480ae911a73fc483d.md)

[13- Paket Yönetimi: Güncelleme Kurma Kaldırma İşlemleri](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/13-%20Paket%20Yo%CC%88netimi%20Gu%CC%88ncelleme%20Kurma%20Kald%C4%B1rma%20I%CC%87s%205641619eca674fe6897343a55f92a84c.md)

[18- Temel Ağ Komutları](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/18-%20Temel%20Ag%CC%86%20Komutlar%C4%B1%20740d476626e641acbe82a04bac1d0575.md)

[19- İşlem Yönetimi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/19-%20I%CC%87s%CC%A7lem%20Yo%CC%88netimi%20c9bd662fe9b244c1b340369875688dde.md)

[20- Servislerin Yönetimi](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/20-%20Servislerin%20Yo%CC%88netimi%2026d53a1004af4dd3af2c22533b9977a5.md)

[21- Zamanlanmış Görevler](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/21-%20Zamanlanm%C4%B1s%CC%A7%20Go%CC%88revler%2059a7e31fa95a435eb72067ef717bdb9b.md)

[22- Log Dosyaları](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/22-%20Log%20Dosyalar%C4%B1%2086f5715711244af3bc8cb96c5b1fac59.md)

[✅ Eğitim Sonu](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/%E2%9C%85%20Eg%CC%86itim%20Sonu%2081ab4c887c6543d6a4bf5a8b21639b47.md)

[Temel Linux Müfredatı](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Temel%20Linux%20Mu%CC%88fredat%C4%B1%20d3334fd872014e90a95815a743bd1d98.md)

[Güvenlik Duvarı](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Gu%CC%88venlik%20Duvar%C4%B1%2068c1291f93bb40ca965d8271232e790a.md)

[Bash Shell Scripting Giriş](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Bash%20Shell%20Scripting%20Giris%CC%A7%20448e08fc148641ef9ec9b9de63ff34bb.md)

[Orta Seviye Konular](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Orta%20Seviye%20Konular%2049fd60901ffa4d1e8bf8112207b6a6b5.md)

[promt Açıklamsı](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/promt%20Ac%CC%A7%C4%B1klams%C4%B1%20fd9b76da9ab842509a1fc67ad43d6507.md)

[chroot](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/chroot%20384c754ac4ce4e159edcda6c8786daf8.md)

[Ubuntu Server Kurulumu ve Konfigürasyonu](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Ubuntu%20Server%20Kurulumu%20ve%20Konfigu%CC%88rasyonu%204cc9bf6d8cae45c4ae9e4a9c6abd2a40.md)

[Sanallaştırma ve Kısaca Docker ?](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Sanallas%CC%A7t%C4%B1rma%20ve%20K%C4%B1saca%20Docker%20eb051260823b4b23b21bab566ce0fa11.md)

[Linux Modülleri ve Sürücüleri](Linux%20Eg%CC%86itimi%20fe042e0b904047e3b3da7432a1c55d45/Linux%20Modu%CC%88lleri%20ve%20Su%CC%88ru%CC%88cu%CC%88leri%2080e5bbf9a4a24a14ae20e5b8c3c8bf36.md)