# ✅ 8- Bash Kabuk Genişletmeleri

# Kabuk Üzerinde Genişletme

Bash kabuğunun nasıl çalıştığından bahsettiğimiz bölümde, kabuğa girdiğimiz komutların önce kabuk tarafından anlamlandırılmak üzere metinsel olarak işlendiğinden bahsetmiştik hatırlıyorsanız. Kabuk girilen komutları inceleyip kendi üzerine düşen bir görev varsa bunları yapmak istiyor. 

Aslında kabuğun teknik olarak nasıl çalıştığının detaylarına girip kafamızın karışmasını istemiyorum ancak bu bölümde anlatacaklarımızın daha net olması için çok çok basit düzeyde haberdar olmamız gereken bir işleyiş var. Yani ne çok detaylı ne de üstünkörü biçimde kısaca açıklamak istiyorum. 

Kabuğa bir komut girdiğimizde girdiğimiz komut lexical analysis & parsing yani sözcük analizi ve ayrıştırma olarak geçen ilk aşamadan geçiriliyor. Daha sonra anlamlandırılan ve ayrıştırılan komuttaki genişletilmesi gereken bölümler genişletiliyor. Son olarak da komut çalıştırılıp, işlem sonlandıktan sonra durum hakkında bilgi sunan çıkış kodu da üretiliyor. Bu eğitimde ilk aşamadan yani lexical analysis ve parsing den ve exit yani çıkış kodlarının detaylarından bahsederek kafanızı karıştırmak istemiyorum. Eğer sizin bu eğitimi takip ettiğiniz dönemde benim yayınladığım bir kabuk programlama eğitimi varsa bu konulardan o eğitimde mutlaka bahsetmişimdir zaten. Eğer henüz kabuk programlama eğitimi yayınlamadıysam, kendiniz de araştırarak eksik kalan kısımları öğrenebilirsiniz. Neticede halihazırda yerli ve yabancı pek çok farklı kabuk programlama eğitimi ve bash kabuk dokümanı internet üzerinde mevcut. Tek yapmanız gereken merak ettiğiniz soruların peşine düşmek. Şimdi tekrar bu genel yapıya dönecek olursak:

![%E2%9C%85%208-%20Bash%20Kabuk%20Genis%CC%A7letmeleri%202de26021ef9841ba90226fb4ce230e00/Untitled.png](%E2%9C%85%208-%20Bash%20Kabuk%20Genis%CC%A7letmeleri%202de26021ef9841ba90226fb4ce230e00/Untitled.png)

Kabuğa input yani girdi olarak verilen komut kabuk tarafından çalıştırılmadan önce analiz ediliyor ve ayrıştırılıyor. Çok kısaca buradaki analiz ve ayrıştırma adımından bahsedecek olursak: 

Daha önce de kısaca bahsettiğimiz gibi kabuk ilk olarak komutlar içindeki boşluk karakterlerine ve ayrıca kabuk için özel anlam ifade eden ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, or ‘>’ gibi çeşitli meta karakterlere bakarak girilen komutu parçalara ayrıştırıyor. Bu parçalara da aslında token deniyor.

Parçalara ayırdıktan sonra komutta bulunan karakter veya karakterler uygun şekilde kullanıldıysa kabuk bu karakterin temsil ettiği işlevlerin yerine getirilmesi için gereken ön bilgiye sahip oluyor. 

AŞAĞIDAKİ ÖRNEK DOĞRU DEĞİL ÇÜNKÜ KELİME AYRIŞTIRMA GENİŞLETMESİ İLE İLK AŞAMADAKİ PARSİNG KARIŞTIRILMIŞ. Burada düzgün bir açıklama var: [https://stackoverflow.com/a/54161596](https://stackoverflow.com/a/54161596)

Ek Olarak BAK: [http://mywiki.wooledge.org/BashParser](http://mywiki.wooledge.org/BashParser)

Ayrıştırma işlemini daha net kavrayabilmek adına hemen basit bir örnek yapabiliriz. Eğer hatırlıyorsanız kabuğun nasıl çalıştığını açıklarken konsol echo ilk deneme echo ikinci deneme şeklinde komutumuzu girmiştik. Komutumuzu tekrar girelim. Bakın komutumuzun neticesinde ilk deneme echo ikinci deneme çıktısını aldık. Bu çıktıyı adlık çünkü, komutumuzdaki tüm kelimeler boşluk karakterleri sayesinde birbirinden ayrılıp parçalara bölündü ve aksini belirten herhangi bir karakter olmadığı için ilk parça çalıştırılacak olan aracın ismi, diğer parçalar ise bu araca iletilecek argümanlar olarak ele alındı. Neticede echo aracı buradaki ilk deneme echo ikinci deneme çıktısını bastırdı.

Şimdi komutumuzu kabuk için tek satırda iki farklı komutu temsil eden noktalı virgül karakteri ile tekrar girmeyi deneyebiliriz. Ben echo ilk deneme ; echo ikinci deneme şeklinde komutumu giriyorum.

Bakın bu kez ilk deneme ve ikinci deneme çıktılarını aldık, yani aslında buradaki ikinci echo aracı da çalıştırıldı. Nasıl oldu diyecek olursanız. Kabuk tüm komutu boşluklarından parçalara ayırdı ve ek olarak burada noktalı virgül meta karakterini gördü. Bu karakterin kabuk için anlamı, bu karakterden sonra yeni bir komut girildiği anlamına geldiği için kabuk benim tek satırda girmiş olduğum bu girdileri iki ayrı komut olarak algıladı. Bu sayede iki komutta ayrı ayrı çalıştırıldı. İşte bizzat bu basit örnek üzerinden de görebildiğimiz gibi kabuk, girilen komutu doğru anlayabilmek için öncelikle girilen komutu parçalara ayırmak istiyor. Parçalara ayırırken de boşluk tab veya tıpkı noktalı virgül gibi bazı özel metakaraktere göre komutu uygun şekilde parçalıyor. Yani girdiğimiz komut kabuk tarafından doğru şekilde anlaşılabilmesi için uygun parçalara ayrılıyor. Ayrıca çıktılarda da görebildiğiniz gibi kabuk için özel anlamı olan karakterler işlevlerini yerine getirdikten sonra komuttan kaldırılıyor. Yani örneğin ben noktalı virgül karakterini kullanmış olmama karşın noktalı virgül konsola çıktı olarak bastırılmadı çünkü buradaki noktalı virgül birden fazla komut girildiğini belirten özel bir karakter. Dolayısıyla görevini tamamladıktan sonra tekrar komutun argümanları arasında yer alması zaten mantıklı değil. Görevini tamamladığı için kaldırılıyor. 

İkinci adım olarak da kabuk kabuk, analiz ve ayrıştırma işleminden sonra yine bazı özel karakterler sayesinde ayırt edebildiği genişletilecek parçaları burada gözüken genişletme kuralları dahilinde soldan sağa doğru sırasıyla gerçek değerlerine genişletiyor.

Yani öncelikle kıvırcık parantez, daha sonra tilde, daha sonra aynı anda değişken parametre, komut ikamesi, işlem ikamesi ve aritmetik genişletme uygulanıp, kelime bölme genişletmesi ve son olarak da dosya ismi genişletmesi sırasıyla uygulanıyor.

Genişletmeler de yapıldıktan sonra komut kabuk için en son halini almış oluyor. Dolayısıyla kabuk için nihai formuna ulaşmış olan komut çalıştırılıyor, işlem tamamlandığında da çalışma durumu hakkında olumlu veya olumsuz çıkış kodu döndürülüyor. Yani biz doğrudan fark etmiyor olsak da aslında kabuğa her komut girdiğimizde buradaki şema aynen adım adım uygulayarak girilen komutun asıl anlamına ulaşıp çalıştırılması sağlanıyor.

İşte tüm bu süreç içinde bizim bu bölümde odaklanacağımız tek kısım genişletme olarak geçen adım. Eğer girilen komutta, kabuk için özel anlam ifade eden genişletme karakterleri varsa kabuk bu karakterlerin geçtiği argümanları işleyip asıl ifade ettikleri değerlere dönüştürüyor. İşte bu işleme de pek çok kez vurguladığımız gibi “genişletme” deniyor.

Teorik olarak tamam, az çok örnekler üzerinden açıkladık ama burada bahsi geçen "genişletme" pratikte tam olarak ne anlama geliyor? 

Sanırım bu durumu en açık şekilde `echo` komutu ile örnekleyebiliriz. Örneğin biz kabuğa `echo merhaba` yazarsak, çıktı olarak "***merhaba***" ifadesini alıyoruz. Aynı örneği `echo *` şeklinde uyguladığımızda ise, bakın bu kez çıktı olarak mevcut konumumuzda yer alan dosya ve dizinlerin listesini aldık. Bu durumun nedeni ikinci örneğimizde kullanmış olduğumuz yıldız(asterix) işaretinin bash üzerinde özel bir anlam taşıyor olması. Yıldız işareti bash kabuğuna göre özel anlam taşıdığı için bash kabuğu burda yıldız karakterini doğrudan echo ya argüman olarak iletip konsola bastırtmak yerine, echo aracını çalıştırmadan önce yıldız karakterini genişletip, genişletme sonucu ortaya çıkan argümanları echo aracına iletiyor. Normalde buradaki yıldız joker karakteri olası tüm karakterleri kapsama işlevinde. Bizim örneğimizde kabuk echo komutundan sonra yıldız karakterini gördüğünde, bu özel karakterin mevcut bulunduğumuz dizindeki tüm dosya ve dizin isimlerini temsil etmek için konulduğunu düşünüyor ve bu doğrultuda yıldız karakterini dosya ve dizin isimleri olarak genişletiyor. Neticede bizim echo * olarak girdiğimiz komut kabuk tarafından echo dosya ve dizin isimleri olarak genişletilmiş oluyor. Böylece echo aracına argüman olarak da dosya ve dizinlerin isimleri aktarılıyor. echo aracı da bu argümanları konsola bastırıyor. 

İşte tıpkı bu örneğimizde de olduğu gibi kabuğa komut girerken farkında olmamız gereken en önemli detay, kabuğa girmiş olduğumuz tüm komutların aslında metinsel veri girişleri olduğudur. Yani kabuk ile iletişimimizi yazılı yoldan sağlıyoruz. 

Kabuk da bizim yazılı şekilde verdiğimiz emirleri doğru şekilde algılayabilmek için komutları çalıştırmadan önce metin içerisindeki özel anlam taşıyan ifadeleri bulup gerçekte neyin kast edildiğini anlayabilmek için çeşitli bağlamlara göre değerlendiriyor. Bu değerlendirme işini de tıpkı şemada açıkladığımız gibi adım adım gerçekleştiriyor. Yani kabuk kendisinde tanımlı olan görevler dahilinde, girdiğimiz komutta kendisinin yapması gereken bir işlem varsa ilk olarak bunları yapıyor. Girilen komutlar yani argümanlar kabuk tarafından işlenip uygun şekilde genişletildikten sonra da zaten ilgili araca bu argümanlar aktarılıyor. İlgili araç da kendi özellikleri ve görevleri dahilinde bu argümanları yorumlayıp çalıştırıyor.

Yani dikkat ettiyseniz ben burada kabuğun genişletme yaptığından bahsettim ancak bu değerlendirme durumu aslında yalnızca kabuk ile de sınırlı değil. Kabuk aracılığı ile çalıştırılan harici araçlar da kendi bünyesinde bulunan kurallar dahilinde kendilerine verilen argümanları yorumlayabiliyor. Örneğin konsol üzerinden bir aracı çalıştırmak üzere komut girdiğimizde, kabuk ilgili komutu işleyip genişlettikten sonra aracı bulup çalıştırıyor ve aracı çalıştırdıktan sonra girdiğimiz komuttaki argümanları değerlendirme işi ilgili araca bırakılıyor. Yani özetle komutlarımızı ilk olarak kabuk işleyip genişletiyor daha sonra kabuğa göre işlenmiş olan argümanlar, çalıştırılan araca iletilip bu aracın da kendine göre bu argümanları işlemesi sağlanıyor. İşte "genişletme" olarak bahsettiğimiz durum, kabuğa girilen yazılı ifadelerin bağlamına göre değerlendirilip uygun değerlere dönüştürülmesi yani genişletilmesidir.

Anlatım devamında kabuk üzerinde geçerli olan genişletme kurallarının detaylarına ve gerektiğinde bu genişletmeden nasıl kaçınabileceğimize uygulamalı olarak değiniyor olacağız. Eğer kabuğun genişletmeleri nasıl ele aldığını bilirsek, çok daha az eforla kabuğa çok daha fazla iş yaptırabiliriz. Anlatımların sonunda zaten bizzat deneyimlemiş olacağınız için kabuk genişletmelerinin önemini kavramış olacaksınız. Şimdi bash kabuğunda var olan genişletme türlerinden bahsederek devam edelim.

### Bash Kabuğu Dahilindeki Genişletme Türleri

Elbette kabuk aracılığı ile çalıştırılan harici araçların kendilerine has genişletme özellikleri olsa da biz komutlarımızı ilk ele alan yapıdan yani ilk genişletmeyi uygulayan bash kabuğunun davranışlarından bahsedeceğiz. Bu sayede zaten araçlara iletilecek asıl argümanların da neler olduğunu kavrayıp ona göre daha etkili şekilde komutlarımızı girebiliyor olacağız. 

Lafı daha fazla uzatmadan kabuğun genişletme türlerinden bahsedecek olursak, Bash kabuğunda 8 türde genişletme bulunuyor. Ve bu genişletmelerin kabuk tarafından uygulanma sıralaması da bulunuyor. İlk bakışta kabuğun hangi genişletmeyi hangi öncelikte ele aldığını bilmek pek yararlı gibi gelmese de komutların sonuçlarını değiştirebileceği için yani kabuğun çalışma yapısını anlamak için önemli aslında. Tekrar şemamıza da bakacak olursak, bakın ilk olarak 

- Ayraç olarak da geçen Süslü(Kıvırcık) Parantez Genişletmesi

daha sonra

- Tilde Genişletmesi

uygulanıyor ve daha sonra hepsi aynı anda yani aynı önceliğe sahip şekilde

- Parametre ve Değişken Genişletmeleri
- Aritmetik ikamesi
- İşlem İkamesi(Eğer sistem tarafından destekleniyorsa.)
- Komut İkamesi

genişletmeleri uygulanıyor. Daha sonra

- Kelime Ayırma-Bölümleme

uygulanıp son olarak da 

- Dosya Adı Genişletmesi

uygulanıyor.

Eğer varsa ek olarak tüm bunlardan sonra tırnak işaretleri yani alıntılama karakterleri da komuttan kaldırılıyor.

![%E2%9C%85%208-%20Bash%20Kabuk%20Genis%CC%A7letmeleri%202de26021ef9841ba90226fb4ce230e00/Untitled.png](%E2%9C%85%208-%20Bash%20Kabuk%20Genis%CC%A7letmeleri%202de26021ef9841ba90226fb4ce230e00/Untitled.png)

İşte Bash kabuğu, kendisine verilen metinsel komutları bu genişletme kuralları dahilinde değerlendiriyor. Kabuğa verilmiş komutların tamamı, aksi belirtilmediği sürece buradaki genişletme yapıları kontrol edildikten sonra yani komutlar genişletildikten sonra çalıştırılıyor. Biz bu bölümde burda bahsi geçen yani yalnızca bash kabuğunun genişletmelerinden bahsediyor olacağız.

Harici kabukların veya konsol üzerinden kullanılan harici araçların genişletme davranışları için ilgili araçların yardım saylarına göz atabilirsiniz. Biz sırasıyla bash kabuğundaki genişletme türlerini açıklayarak ne ifade ettiklerini öğrenmeye çalışacağız. Öncelikle sayılar ve harfler ile istediğimiz türde örüntüler oluşturabilmemize olanak tanıyan kıvırcık parantez genişletmelerinden bahsederek başlayabiliriz. 

### Süslü(Kıvırcık) Parantez-Küme Ayracı Genişletmesi

Kıvırcık parantez genişletmesi sayesinde sayılar ve karakterlerle belirttiğimiz aralıklarda otomatik olarak verilerin oluşturulmasını sağlayabiliriz. Yani kendi ihtiyaçlarımıza göre örüntüler oluşturabiliriz. Örneğin 1 den 100 e kadar isimlendirilmiş dosyalar oluşturmak istersek genişletme yapısını kullanarak çok kısa bir komutla kolayca halledebiliriz.

Bu genişletme özelliklerini neticesinde üretilen çıktıları, argüman kabul eden tüm komutlar üzerinde kullanabiliyoruz. Örneğin normal şartlarda 1 den 100 e kadar isimlendirilmiş olan dosyalar oluşturmak için 1 ile 100 arasındaki tüm sayıları tek tek yazmamız gerekiyor. Bunun yerine sadece 1 ile 100 arasında sayıların üretilmesini talep eden genişletme yapısını kullanırsak, tıpkı biz elimizle 1 den 100 e kadar yazmışız yani tek tek argümanları girmişiz gibi komutumuz geçerli olacak. İşte bu yaklaşım sayesinde argüman alarak çalışan tüm araçlarda genişletme özelliklerinin nimetlerinden faydalanmamız mümkün. Örneklerimizi pek çok farklı araç üzerinde uygulayabiliriz ancak ben kolayca takip edilebilir olması için konsola çıktı bastıran echo komutu üzerinden bu genişletmeleri örneklendiriyor olacağım. Bu sayede genişletme sonucu üretilen karakterleri doğrudan konsol üzerinden çıktı olarak görebiliyor olacağız. Ancak söylediğim gibi genişletme özelliklerini, argüman alarak çalışan tüm araçlar üzerinde kullanabilirsiniz. Ben sadece örnekler için echo aracını kullanıyor olacağım. 

Şimdi örneğin ben konsola echo a yazdıktan sonra kıvırcık parantez içinde virgüller ile ayırarak d,l,t karakterini eklersem ve parantezi kapatıp sonuna da a karakterin eklersem gördüğünüz gibi "ada" "ala" ve "ata" şeklinde üç yeni kelime üretmiş oldum. İşte buradaki kıvırcık parantezin içindeki virgülle ayrılmış olan karakterler, kabuk tarafından sırasıyla genişletilerek baştaki ve sonraki a karakterleri ile birleştirilip ada ala ve ata argümanlarına dönüştürüldü. echo aracı da bu argümanları konsolumuza bastırdı. İşte en basit hali ile genişletme dediğimiz kavram bu. Ve kıvırcık parantez genişletmesinin en yalın kullanım metotlarından biri de bu ele aldığımız örnek. 

kıvırcık parantez içine virgüller ayırarak yazdığımız tüm karakterler soldan sağa doğru sırasıyla parantezin dışındaki karakterlerle birleştirilerek her biri için birer argüman üretiliyor. Yani belirttiğimiz şablona göre istediğimiz çeşitlilikte argüman üretebiliyoruz. 

Ben yalnızca birer karakter ekledim ancak kıvırcık parantez içerisine istediğimiz uzunlukta istediğimiz kadar karakteri ekleyebiliyoruz.  Ben bu kez echo a{bbb,dd,l,tttt}a şeklinde komutumu giriyorum.

Bakın her koşulda parantez içinde virgülle ayırarak verdiğimiz tüm karakterler, peşi sıra kaç karakter kullanıldığına bakılmaksızın kabuk tarafından genişletiliyor.

Çıktıyı incelediğimizde virgülle ayırmış olduğumuz karakterlerin tıpkı tanımlandıkları sıralamaya yani soldan sağa doğru genişletildiğini teyit edebiliyoruz. Siz de elde etmek istediğiniz argümanlar için bu sıraya dikkat ederek şablonunuzu tanımayabilirsiniz. Yalnız, bu şekilde şablon tanımı üzerinden örüntüler oluştururken boşluk karakterini kaçış karakteriyle birlikte kullanmanız gerektiğine de dikkat edin lütfen. Aksi halde kabuk genişletme uygulamıyor. 

Boşluk karakterinin genişletmeye engel olduğunu kanıtlamak için aynı komutumuzu bu kez içinde boşluk karakteri ile tekrar girebiliriz. Ben bu kez komutumuzu echo a{b b,d,l,t}a şeklinde giriyorum.

Bakın boşluk karakteri olduğu için genişletme gerçekleştirilmedi dolayısıyla köşeli parantez ve içindeki tüm karakterler olduğu gibi konsola bastırıldı. Çünkü kabuk burada bir karakter boşluk olduğunu gördüğünde burada bu boşluk karakterinin kelimeleri bölümlemek için konulduğunu düşünüyor. Dolayısıyla genişletme yerine kelime bölümlemesi yapılıp genişletme yapısı kabuk tarafından görmezden geliniyor. Bizim bu boşluğun bu amaçla eklenmediğini yani sıradan bir karakter olduğunu kabuğa belirtmek için özellikle kaçış karakterini kullanmanız yeterli. Denemek için boşluk karakterinden hemen önce kaçış karakterini ekleyelim. Tamamdır komutumuzu şimdi tekrar girelim. Bakın bu kez boşluk karakteri de sıradan bir karakter olarak görüldüğü için örüntü içine dahil edildi.

Böylece, ne zaman bir karakterin kabuk tarafından standart olarak algılanmasını istersek kaçış karakterini tıpkı bu örneğimizde olduğu şekilde kullanabileceğimizi bir kez daha teyit etmiş olduk.

Tekrar kıvırcık parantez genişletmesine dönecek olursak burada biz doğrudan genişletilecek tüm karakterleri belirttik. Eğer genişletilecek karakterlerin hepsini yazmak yerine bir aralık belirtmek istersek; iki nokta yan yana olacak şekilde `{başlangıç..bitiş..artış_oranı}` yapısını da kullanabiliyoruz. Hemen örnekler üzerinden uygulamalarımızı da yapalım.

Ben a'dan z ye kadar olan tüm karakterleri bastırmak için kıvırcık parantez içinde a..z şeklinde komutumu giriyorum. Bakın a dan z ye kadar olan tüm alfabetik karakterler sırasıyla tek tek bastırıldı. Linux üzerinde küçük büyük harf duyarlılığı olduğundan daha önce bahsetmiştik. Küçük büyük harf duyarlılığı sebebiyle eğer büyük karakterler bastırılsın istersem A..Z şeklinde büyük harfleri kullanmam gerekiyor. Bakın A dan Z ye hepsi büyük harfli şekilde bastırıldı. İstersem aynı şekilde sayı aralığı da belirtebilirim. Örneğin 1 den 50 ye kadar olan tüm sayıların bastırılması için kıvırcık parantez içinde 1..50 şeklinde yazmam yeterli. Gördüğünüz gibi tüm sayılar sırasıyla bastırıldı. Ayrıca genişletmeler sırasında üretilen örüntünün sıralı şekilde teker teker ilerlemesi de şart değil. İstersek kaçar kaçar ilerlemesi gerektiğini örüntünün sonuna iki nokta koyduktan sonra belirtebiliriz. Örneğin ben 1 den 50 kadar olan sayıların 2 şer 2 şer genişletilmesini istersem kıvırcık parantez içinde 1..50..2 şeklinde belirtmem gerekiyor. Bakın tüm sayılar birden başlayıp ikişer ikişer arttırılarak yani 1 3 5 7.. şeklinde iki sayı aralıkla bastırıldı. Sayılar dışında bu aralığı harfler üzerinde de benzer şekilde kullanabiliriz. Ben harflerin ikişer ikişer atlanarak bastırılmasını için komutumu echo {a..z..2} şeklinde giriyorum. Bakın tüm harfler alfabetik olarak a dan başlayıp ikişer sıra kaymış şekilde tek tek bastırıldı.

İşte sizler de bu şekilde ihtiyaçlarınıza uygun olan örüntüleri oluşturmak için kıvırcık parantez kullanabilirsiniz. Şimdiye kadar verdiğim basit örneklerden belki anlaşılamamış olabilir ancak buradaki genişletmelerin her biri ayrı ayrı birere argüman olarak genişletiliyorlar. Eğer genişletilecek argüman bir önceki argümandan ayrılmadıysa yani bitişik yazıldıysa, genişletme bu argüman da dikkate alınarak gerçekleştiriliyor.

Ne demek istediğimi daha net anlayabilmek için echo deneme{1..9} şeklinde komutumuzu girelim. Bakın aldığımız çıktıda deneme ifadesinin sonuna 1 den 9 a kadar rakamlar eklendi ve neticede 9 farklı argüman üretilmiş oldu. Bu çıktıyı elde ettik çünkü deneme argümanından sonra boşluk bırakmadan genişletme karakterlerini belirttik. Kabuk, girdiğimiz komutu anlamlandırmak için öncelikle boşluklarından parçalara ayırdığı için bizim girdiğimiz genişletme karakterleri ve “deneme” argümanı aynı bütünün parçaları olarak değerlendirildi. Ve genişletme karakteri de olduğu için kabuk, deneme{1..9} komutunun aslında deneme1 denem2 deneme3.. deneme9 olarak genişletilmesi için eklendiğini anlayıp buna göre muamele etti. 

Eğer aynı örneği bu kez genişletme karakteri ile önceki argüman arasında bir boşluk olacak şekilde yani echo denem {1..9} şeklinde girersek, gördüğünüz gibi deneme ve 1 den 9 a kadar olan sayılar argüman olarak üretildi. Çünkü kabuk girmiş olduğumuz komutu boşluklarından parçalara ayırdı dolayısıyla deneme argümanını ve genişletilecek karakterleri ayrı ayrı ele aldı.

Bizim kabuğa verdiğimiz komutların kabuk tarafından nasıl ele alındığını aşağı yukarı bildiğimizde işte tıpkı burada olduğu gibi girdiğimiz komutların kabuk tarafında ne anlam ifade ettiğini de çok daha iyi anlayabiliyoruz. Yani daha önce açıklamış olduğumuz kabuk nasıl çalışır bölümünü gereksiz yere ele almadık. Kabuğun komutları algılayışını bildiğimizde çok daha etkili şekilde emirler verebiliyoruz.

Tekrar örüntü oluşturmaya dönecek olursak, farklı türde örüntüler elde etmek isterseniz birden fazla genişletme karakterini peş peşe de kullanabilirsiniz. Denemek için echo {1..3}{a..c} şeklinde komutumuzu girelim. Bakın, iki genişletme karakteri bitişik şekilde kullanıldığı için 1 den 3 e kadar olan tür rakamlar ve a dan c ye kadar olan karakterleri de içeren argümanlar üretmiş oldu. Bu örnek kabuğun genişletmeleri nasıl yaptığını gayet iyi özetliyor bence. Kabuk sırasıyla genişletme yaptığı için soldan sağa doğru genişletilecek karakterleri arıyor. En soldaki karakteri genişlettikten sonra ileride genişletilecek karakter var mı diye bakıyor. Eğer varsa bunları da genişletiyor. İşte buradaki örnekte kabuk ilk olarak 1 rakamına genişletti ve devamında ikinci genişletmeye geçip a dan c ye kadar olan genişletmeyi uyguladı. Daha sonra 2 rakamına genişletti ve aynı şekilde a da c ye kadar olan genişletmeleri sırasıyla tek tek uyguladı. Yani görebildiğiniz gibi genişletmenin uygulanış biçim ve sırası oldukça düzenli. Hatta bu düzeni daha net görebilmek adına bir adet daha genişletme ekleyebiliriz. Bunun için echo {1..3}{a..c}{A..C} şeklinde komutumu giriyorum. Çıktıları inceleyecek olursak, sırasıyla ilk genişletmenin uygulanıp sonraki genişletmenin ilk basamağının da uygulandıktan sonra bir sonraki genişletmenin uygulandığınız görebiliyoruz. İlk genişletme basamağı 1 ve a olduğu için 1aA 1aB 1aC şeklinde genişletmeler uygulanmış. Geri kalan genişletmeler de benzer şekilde soldan sağa doğru adım adım uygulanmış. Aslında burada aldığımız çıktılar deneme{1..9} örneğini ile birebir benzer. Tek fark, biz burada birden fazla genişletme karakterini bitişik olarak kullandığımız için üretilen örüntüler de bu doğrultuda çok çeşitli oldu. Yoksa tüm işleyiş aynı.

Belki bu noktada aldığımız çıktılar sizlere biraz karmaşık gelmiş olabilir, ancak merak etmeyin aslında son derece kolay. Tek yapmanız gereken çıktıları biraz dikkatlice izleyip, genişletmelerin soldan sağa doğru adım adım gerçekleştirildiğini fark etmektir. Ayrıca genelde bu örneklerdeki gibi karmaşık veya anlamsız örüntüler oluşturmanız da gerekmeyecek. Ben sadece örüntü oluşturmanın temel yapısından bahsetmek için bu şekilde örnekler veriyorum. Kendiniz de farklı örnekler üzerinden farklı desenler üreterek genişletmenin tam olarak nasıl çalıştığını rahatlıkla kavrayabilirsiniz. Örneğin bu son girdiğim komutta genişletme karakteri arasında boşluk bırakırsam, genişletmeler birbirinden bağımsız olacağı için ayrı ayrı sıralı çıktıları alacağız. 

Bakın boşluk bırakınca, genişletmeler birbirinden bağımsız olduğu için çıktı ne kadar farklı oldu.

Neticede kıvırcık parantez genişletmeleri sayesinde çok çeşitli örüntüler oluşturabileceğimizi echo komutu üzerinden ele aldık. echo komutu üretilen argümanları gözlemleyebilmemiz için harika olsa da ben basit bir gerçek dünya örneği de vermek istiyorum.

Örneğin diyelim ki kendi ev dizininiz içindeki Desktop klasörü altında birbirinden farklı isimlerde yeni 5 tane klasör oluşturmak istiyorsunuz. Bunun için ne yapabilirsiniz ? Örneğin komutunuzu mkdir ~/Desktop/bir ~/Desktop/iki ~/Desktop/uc ve benzeri şeklinde uzun uzadıya girebilirsiniz. Ama artık siz genişletmeden yararlanıp örüntü oluşturmayı biliyorsunuz. Yani tüm komutu tekrar tekrar yazmak yerine isterseniz kıvırcık parantez genişletmesi ile mkdir ~/Desktop/{bir, iki, uc, dort, bes} şeklinde tek seferde istediğiniz isimlerde klasörlerin oluşturmasın da sağlayabilirsiniz. Buradaki virgülle ayrılmış her bir ifade parantez dışındaki ifadeye eklenip yeni bir argüman oluşturacağı için tıpkı tek tek ~/Desktop/bir ~/Desktop/iki ~/Desktop/uc yazmışız gibi mkdir aracına bu argümanlar aktarılıyor olacak. Bakın tek bir komutla istediğim örüntüye uyulması sayesinde birden fazla klasörü kolayca oluşturabildim. 

İşte bu ve bunun gibi sizlere pratiklik sağlayacak durumlarda kıvırcık parantez genişletmesini kullanabilirsiniz.

Aslında örnekleri çok çeşitli şekillerde çoğaltabiliriz ancak aşağı yukarı benzer amaçlar için bu örüntü oluşturma genişletmesini kullanabiliyoruz. Ayrıca ileride dosya adı genişletmelerinde benzeri bir genişletmeden tekrar söz edeceğiz. Bu genişletme için şimdilik bilmemiz gerekenler bunlar. Artık kabuğun ilk uyguladığı genişletmeyi öğrenmiş olduk. Gelin şimdi daha önceden de aşina olduğumuz tilde genişletmesi hakkında konuşalım.

# Tilde Genişletmesi

Yaklaşık işareti olarak da bilinen tilde ~ işaretini, Türkçe klavyemizden Alt + Ü tuşlaması ile oluşturabileceğimizden ve bu işaretin kabuk için mevcut kullanıcının ev dizinini temsil ettiğinden daha önce bahsettik. 

Biz tilde işaretini kullanırsak kabuk bu işareti gördüğünde, bu tilde işareti mevcut kullanıcının ev dizini neresi ise o adrese genişletiliyor. Yani örneğin ben echo ~ komutu ile tilde işaretini girdiğimde /home/taylan dizinine genişletiliyorken sizin kullanıcı dizininiz nerede ise sizde ona göre genişletiliyor olacak. Normalde standart olarak normal kullanıcıların hepsinin ev dizini /home klasörü altında kendi isimleri ile tanımlı klasörde bulunuyor. Daha önce de bu durumu gördük ancak tekrar teyit etmek için ls /home komutu ile dizin içeriğini listeleyebilirsiniz. Bakın ben daha önce ali isimli bir kullanıcı daha eklediğim için o kullanıcının ve benim mevcut kullanıcı hesabımın isimleri buradaki klasörlerde bulunuyor. Buradaki klasörler de ilgili kullanıcıların ev dizinlerini temsil ediyor. Ancak yine de istisnai durumlarda herhangi bir kullanıcının ev dizini standarda uymayan başka bir dizinde de oluşturulmuş olabilir. Tilde işareti bu durumda da ilgili kullanıcının ev dizinine genişletiliyor. Zaten tilde genişletmesinin kullanmanın avantajı buradan geliyor. İlgili kullanıcının ev dizinin hangi konumda olduğunu bilmiyorsak tilde bizim için buluyor.

Uygulamalı şekilde ilerleyecek olursak, mevcut kullanıcı hesabı dışında başka kullanıcıların ev dizinlerine genişletilmesi için tilde işaretinden sonra o kullanıcının kullanıcı adını yazmamız gerektiğini daha önce uygulamalı olarak görmüştük. Örneğin benim sistemimde nil isimli bir kullanıcı hesabı varsa bu kullanıcının ev dizinini nerede olursa olsun ~nil komutu ile o dizine genişletilmesini sağlayabilirim. 

Bu durumu test etmek için öncelikle nil isimli bir kullanıcı hesabı oluşturalım. 

Hazır örnek için yeni bir kullanıcı oluşturacakken, tilde genişletmesinin standardın dışındaki ev dizin adreslerini bile bulabildiğini teyit etmek için oluşturacağımız kullanıcının ev dizini home klasörü dışında herhangi bir adrese tanımlayabiliriz.. Bu örnek için nil isimli bir kullanıcı hesabı oluşturup bu kullanıcının ev dizini olarak da /tmp/nil klasörünü tanımlayacağım.

Kullanıcı oluşturma işlemlerinden ileride ayrıca bahsedeceğiz, şimdilik test etmek için yalnızca benim girdiğim gibi komut girebilirsiniz. Yeni kullanıcı eklemek için sudo adduser nil şeklinde yazıyorum ve ev dizinini tanımlamak için de —home seçeneğini kullanıp parametre olarak da /tmp/nil yazıyorum. Bu seçenek ve peşine girdiğimiz parametre sayesinde nil kullanıcının ev dizini /tmp/nil olarak tanımlanacak. Bakın komutumu onayladığımda nil kullanıcısının ev dizini olarak /tmp/nil klasörünün kullanılacağını çıktılarda da görebiliyoruz.

Şimdi kullanıcı için bir parola oluşturup diğer bölümleri de enter ile varsayılan olarak geçelim. Evet nil kullanıcısı oluşturuldu. Şimdi bu kullanıcının ev dizinini öğrenmek adına echo ~nil şeklinde komutumuzu girebiliriz. Bakın, nil kullanıcısının ev dizini olarak /tmp/nil çıktısını aldık. Dolayısıyla tilde işaretinin, ev dizini olarak hangi dizinin tanımlı olduğu fark etmeksizin ilgili kullanıcının ev dizinine genişletildiğini bir kez daha teyit etmiş olduk. Elbette echo gibi yalnızca konsola çıktı bastırma işlevi için tilde genişletmesini kullanmayacağız. Örneğin cd ile doğrudan nil kullanıcısının ev dizine geçiş yapmak istersek cd ~nil şeklinde komutumuzu girebiliriz. 

Bakın cd komutunun ardından ~nil ifadesini kullandığım için doğrudan nil isimli kullanıcının ev dizinine geçiş yaptım. Yazması pratik olduğu için tilde genişletmesini sıklıkla kullanıyor olacağız. Üstelik ev dizinine genişlemesi dışında pratik başka bir kullanımı daha bulunuyor. 

Tilde işaretinden sonra eklenen artı işareti mevcut dizini temsil eder. Ben denemek için öncelikle cd komutu ile /etc  dizinine geçiş yapıyorum. Buradan da cd ~/Desktop/ komutu ile kendi ev dizinimdeki Desktop dizinine geçip yapıyorum. Eğer echo ~+ komutunu kullanırsam görebildiğiniz gibi tilde artı işareti mevcut bulunduğum dizin adresine genişletilmiş oldu. Bunun dışında eğer echo ~- şeklinde komutumu girersem de bir önceki dizine genişletildiğini görebiliyorum. Örneğin bir önceki ziyaret ettiğim dizine geri dönmek istersem cd ~- şeklinde komutumu girebilirim. Neticede tilde eksi işareti bir önceki dizini temsil ettiği için bir önceki dizinin dosya yoluna genişlemiş oluyor cd komutu da bu dizine geçiş yapıyor. İşte tilde genişletmesi bu şekilde çalışıyor. Genellikle yalnızca kullanıcıların ev dizinlerini kolayca temsil etmek için kullanıyoruz ama diğer kullanımlarını da dilerseniz tercih edebilirsiniz. Normalde ben bir önceki dizine geçişler için tilde yerine doğrudan cd - komutunu tercih ediyorum, yine de tilde genişletmesinin artı ve eski ile kullanıldığını gördüğünüzde şaşırmamanız için kısaca bahsetmek istedim. 

Şimdi bir diğer genişletme adımından bahsederek devam edecek olursak; tilde genişletmesinden sonra kabuk aynı öncelikle parametre, değişken, aritmetik genişletme ve komut ile işlem ikamesi genişletmelerini uyguluyor. Hepsi aynı önceliğe sahip olsa da biz öncelikle parametre ve değişken genişletmelerden de kısaca bahsederek devam edelim.

## Parametre ve Değişken Genişletmeleri

Bash kabuğunda parametre, değerleri depolayan varlıktır. Söz konusu değer depolamak olduğu için de bash kabuğunda isim veya çeşitli özel karakterler ile parametre belirtmemiz de mümkün. Örneğin daha önce de ele almış olduğumuz değişkenler aslında bir isimle belirtilmiş olan parametrelerdir. Biz bir isimin karşılığı olarak bazı değerleri tanımlayıp, tekrar tekrar bu değişken ismi üzerinden ilgili değerlere ulaşabiliyoruz. Neticede değişken dediğimiz yapılar aslında bir isimle belirtilmiş olan parametreler. Doğru şekilde belirtildiğinde kabuk bu parametreleri depoladıkları değerlere genişletiyor. 

Genişletilecek parametrelerin bash kabuğu tarafından algılanmasını da dolar işareti sağlıyor. Örneğin daha önce ele aldığımız gibi değişkenler üzerinden parametre genişletmesini örneklendirecek olursak:

Dolar işareti ile tanımlı olan değişkenleri çağırabiliyorduk hatırlıyorsanız. İşte değişken isimlerinin önündeki dolar işareti aslında bu değişkenin genişletilmesi gerektiğini temsil eden özel bir karakter. Örneğin biz konsola echo $SHELL şeklinde yazdığımızda kabuk bu dolar işaretini gördüğünde bu işaretle bitişik olan karakterlerin değişken ismini temsil ettiğini anlayıp bu isimle eşleşen değişkenin değerine genişletiyor. Yani bizim echo $SHELL olarak girdiğimiz komut genişletildikten sonra örneğin echo /bin/bash halini almış oluyor. Dolayısıyla konsola da /bin/bash ifadesi bastırılıyor. İşte değişken genişletmesi de tam olarak bu örnekte gördüğümüz durum. İsimli parametreler yani değişkenler dışında aslında diğer parametre çeşitleri de bulunuyor ancak ben bu eğitimde diğer parametre genişletmelerinin üzerinde durmak istemiyorum. Çünkü değişkenler yani isimli parametreler dışındaki diğer parametre genişletmeleri genellikle interaktif olarak komut girerek sistemi yönettiğimiz durumlardan ziyade kabuk programlama yapılırken ihtiyaç duyacağımız türden genişletmelerdir. Bu genişletmeleri doğru şekilde anlayabilmek için kabuk programlamanın bazı detaylarından da bahsetmemiz gerekecek. Odak noktamız kabuk programlama olmadığı için ben ele alarak vakit kaybetmek ve kafamızın karışmasını istemiyorum. Eğer merak ediyorsanız ve kabuk programlama ile ilgileniyorsanız elbette kısa bir araştırma ile pek çok kaynağa ulaşabilirsiniz. Aslında ele almayı düşünüyordum ancak kullanımının nadirliği ve sebep olabileceği olası kafa karışıklıkları dolayısıyla bu eğitimde es geçmeyi daha makul buldum. Eğer ben kabuk programlama eğitimi için müsait olursam, bu konuya da değinmiş olurum. Benim hazırlayacağım olası eğitim yerine dediğim gibi yerli yabancı pek çok farklı kaynaktan anında daha fazla bilgiye de ulaşabilirsiniz tabii. Örneğin “bash shell parameter expansion” şeklinde internet üzerinde araştırma yaparsanız resmi gnu dokümanları ve harici olarak pek çok rehber bilgiye kolayca ulaşabilirsiniz.

Biz şimdi parametre genişletmeleri ile aynı önceliğe sahip olan aritmetik genişletmelerden bahsederek devam edelim.

# Aritmetik Genişletme

Açıkçası aritmetik genişletmeler de etkileşimli kabuk kullanımından ziyade kabuk programlama yaparken işimize yarayacak türden bir genişletme. Yani aslında sistemi yönetirken neredeyse hiç ihtiyacımız olmuyor ama ben yine de kullanımı çok kolay olduğu için ve genişletme kavramını temel düzeyde anlayabilmemiz için kısaca bahsetmek istiyorum.

Aritmetik genişletme için dolar işaretinden sonra çift parantez içinde istediğimiz matematiksel hesaplamayı belirtmemiz yeterli. 

Toplama işlemi için artı işaretini

Çıkarma işlemi için eksi işaretini

Çarpma işlemi için yıldız işaretini

Bölme işlemi için taksim yani slash işaretini

Üs alma için çift yıldız işaretini kullanabiliyoruz.

Örneğin echo $((10+2)) şeklinde girdiğimde, gördüğünüz gibi 12 sonucu bastırıldı. Benzer şekilde eksi işareti ile çıkarma işlemi de yapabiliriz. Bakın 8 sonucunu aldım. Yıldız işareti ile çarpma işlemi yapabiliriz. Bakın yıldız işareti sayesinde çarpma da yapabildik. Dilersek bölme işareti ile bölebiliriz de. Evet 5 sonucunu aldık. Eğer üssünü almak istersek de çift yıldız işaretini kullanabiliriz. Bakın üssünü de kolayca aldık. Eğer bu şekilde basit matematiksel işlemler için kabuğu kullanmak isterseniz dolar işaretinden sonra çift parantez içinde temel işlemleri belirtmeniz yeterli. Çok daha kapsamlı matematiksel işlemler için bash kabuğunun genişletmeleri haricinde ek olarak kullanmanız gereken araçlar bulunuyor. Eğer kapsamlı matematiksel işlemler için hangi araçları kullanabileceğinizi merak ediyorsanız kısa bir araştırma ile kolayca bulabilirsiniz. Daha önce de belirttiğim şekilde, aritmetik genişletmeler ve hesaplamalara genellikle kabuk programlamada ihtiyaç duyduğumuz için bu eğitimde üstünde çok fazla durmak istemiyorum. Yine de artık aritmetik genişletmelerden de haberdarsınız, ihtiyacınız olduğunda ya da başka rehberlerde denk geldiğinizde anlamını biliyor olacaksınız. Zaten temel matematiksel işlemler için kullanım son derece kolay. Tek dikkat etmeniz gereken dolar işaretinden sonra çift parantez işaretini kullanmak. Eğer dolar işaretini kullanmazsak ya da çift değil de tek parantez kullanırsak aritmetik genişletme için komut girildiği kabuk tarafından algılanamadığı için doğal olarak aritmetik genişletme de uygulanmıyor. Ben denemek için dolar işareti olmadan tekrar aritmetik genişletmeyi kullanmak istiyorum. Dolar işareti olmadığında, gördüğünüz gibi aritmetik genişletme uygulanmadı çünkü kabuk benim aritmetik genişletmeyi kastettiğimi anlayamadı. Dolayısıyla aritmetik genişletmeyi kullanmak için dolar işaretinden sonra çift yay parantez kullanmamız gerekiyor.

Temel matematiksel genişletmeleri de ele aldığımıza göre, parametre ve aritmetik genişletmeler ile aynı önceliğe sahip olan “komut ikamesi” genişletmelerinden bahsederek devam edebiliriz. 

# Komut İkamesi

Öncelikle komut ikamesi genişletmesinin genel olarak ne olduğundan bahsedip daha sonra birkaç ayrıntıya değinmek istiyorum.

Bu genişletmenin tanımında geçen ikame kelimesi "yer değiştirme" "yerine koyma" anlamına geliyor. Zaten "Komut ikamesi", bir komutu çalıştırmanıza ve bu komutun çıktısının komut metninin yerini almasına(yerine koymanıza) izin veren genişletmenin adıdır. Komut ikamesi genişletmelerini ters tırnak veya dolar işaretinin ardından parantez içinde genişletilmesini istediğimiz komutları yazarak belirtebiliyoruz. 

Ters tırnak kullanımına örnek olması için basit bir komut ikamesi kulanım örneğini ele almak istiyorum. Genişletmenin sonuçlarını kolay takip edebilmek için yine echo aracını kullanabiliriz. Ters tırnak oluşturmak için de Türkçe q klavyede alt gr ve virgül tuşlamasını aynı anda yapmanız yeterli. Bakın ters tırnak oluşturuldu. Artık ters tırnaktan sonra genişletilmesini istediğimiz komutu tırnak içine girebiliriz. Ben ls komutunu çalıştırmak istediğim için ls yazıyorum ve yine alt gr virgül tuşlaması ile ters tırnağı kapatıyorum. Komutumuzu girip neticesi üzerine konuşabiliriz.  Bakın mevcut dizindeki dosya ve klasörler konsola bastırıldı. Çünkü buradaki ls komutu arkaplanda yeni bir işlem olarak çalıştı ve komutun sonuçları buradaki ls komutunun bulunduğu yere argüman genişletildi. Yani ls komutunun yerini ls komutunun çıktıları aldı. Ls komutunun yerini dosya ve dizinlerin isimlerini belirten argümanlar aldığı için de echo aracı bu argümanları konsola bastırdı.

Bence bu basit örnek komut ikamesini net biçimde açıklıyor. Tekrar özetleyecek olursak ters tırnak içinde yazdığımı tüm komutlar kabuk tarafından arkaplanda yeni bir işlem olarak çalıştırıp sonuçları ters tırnağın kullanıldığı argüman yerine genişletiliyor. Bu sayede bir komutun içinde başka bir komutu kullanabiliyoruz. Yani bu genişletme sayesinde bir komutun çıktıları bir başka komut için argüman olarak kullanılabiliyor. 

Ayrıca komut ikamesinin ikincil tanımlanma biçiminden de bahsetmek istiyorum. Buradaki ters tırnak sizlerin de görebildiği üzere aslında pek de okunaklı değil. Bu kullanımın yerine yeni bash sürümlerinde, dolar işaretinden sonra parantez içerisinde yazdığımız komutlar da ters tırnakla aynı şekilde komut ikamesi genişletmesine tabii oluyorlar. 

Yani aynı çıktıları echo $(ls) komutu ile de elde edebilirdik. Buradaki genişletme karakteri  sayesinde buradaki ls komutu çalıştırılıp sonuçları bu komut ikamesinin yerini alıyor bu sayede echo komutu bunları konsola bastırabiliyor.

Ben örnek olarak tek bir komut ikamesi kullandım ancak isterseniz yan yana ya da iç içe istediğiniz kadar komut ikamesi kullanabilirsiniz.

İç içe kullanımını deneyebiliriz. Hem böylelikle ters tırnak ile dolar işareti ve parantez kullanımı arasındaki okunabilirlik farkını da bizzat deneyimlemiş oluruz. 

Henüz çok fazla komutu öğrenmediğimiz için iç içe kullanabileceğimiz bir komut yok. Bunun yerine yine echo komutunu kullanabiliriz. Benim şimdi vereceğim örneğin gerçek bir anlamı yok ama komut ikamesinin iç içe kullanımını kavramamıza yardımcı olabileceği için ele almak istiyorum.

Ben öncelikle kolay okunabilir olan dolar işareti ve parantez kullanımını ele alacağım.

Örnek olarak echo sonuc: şeklinde yazıyorum. 

`echo sonuc:`

Ve dolar işaretinden sonra parantez açıyorum bu parantezin içine echo birinci yazıyorum. 

`echo sonuc $(echo birinci)`

Parantezin dışına çıkmadan bir dolar işareti ve parantez daha oluşturuyorum. Buraya da echo ikinci yazıyorum 

`echo sonuc $(echo birinci $(echo ikinci))`

daha sonra bir dolar işareti ve parantez daha oluşturuyorum ve buraya da echo son yazıyorum. 

`echo sonuc $(echo birinci $(echo ikinci $(echo son)))`

Böylelikle iç içe olan üç komut ikamesi oluşturmuş oldum. Parantezin dışına da aynı şekilde yeni bir komut ikamesi daha tanımlayıp içine de echo kelime yazabilirim. 

`echo sonuc $(echo birinci $(echo ikinci $(echo son))) $(echo kelime)`

Neticede kabuk bu komutu okuduğunda öncelikle en soldaki komut ikamesini dikkate alacak daha sonra diğer komut ikamesine geçecek. Çünkü kabuk komutları soldan sağa doğru okuyup dikkate alıyor. Kabuk ilk komut ikamesini gördüğünde en içteki yani echo son komutunu çalıştıracak. Bu komut sonuç olarak son ifadesini vereceği için son ifadesi buraya gelecek. Kabuk daha sonra echo ikinci son haline gelmiş olan komutu çalıştıracak ve bunun sonucunu da buraya bastıracak birinci komut ikamesi için de bu işlem aynen yapılacak. En nihayetinde ilk ikinci son ifadeleri buraya bu komut ikamelerinin yerine geçmiş olacak.

Daha sonra buradaki ikinci komut ikamesi çalıştırılıp echo cumle komutunun cumle çıktısı bu komut ikamesinin yerini alacak. En nihayetinde geriye echo sonuc: ilk ikinci son kelime komutu kalmış olacak, dolayısıyla en baştaki echo komutu çalıştırılıp konsola buradaki ifadeler bastırılacak. 

Verdiğimiz örnek saçma olsa da, yan yana ve iç içe kullanılan komut ikamelerinin kabuk tarafından hangi sıralama ile çalıştırıldığı konusunda bize kolay anlaşılır bir örnek sunuyor.

Aynı örneğini ters tırnak ile yapmak istediğimizde ise pek okunaklı olmasa da aynı şekilde kullanabiliyoruz. Örneğin benzeri bir örneği ters tırnak ile oluşturmak istersek echo `echo ilk \` echo ikinci \`` şeklinde komut girmemiz gerekiyor. Bakın benzeri şekilde çıktımızı elde ettik. Ters tırnakları iç içe kullanırken başlangıç ve bitiş noktalarının kabuk tarafından doğru algılanabilmesi için içerideki ters tırnaklardan önce kaçış karakteri kullanmamız gerekiyor. Bu durumu test etmek için kaçış karakterleri olmadan komutumuzu tekrar girmeyi deneyebiliriz. 

Bakın kaçış karakteri olmadığı için, içerideki komut ikamesi çalışmadı. Bunun yerine doğrudan girdimiz komut konsola bastırıldı. İşte bu örnekte de açıkça gözüktüğü gibi tek tırnak ile iç içe komut ikamesi kullanmak istediğimizde kaçış karakteri kullanmamız gerekiyor. Hatta bu işlemi bir adım daha ileri götürerek bir katman daha komut ikamesi kullanmak istersek bu kez üç tane kaçış ikamesi kullanmamız gerekecek. Yani örneğin komutumuzu 

```bash
echo `echo deneme \`echo test \\\` echo son \\\` \` `
```

şeklinde girmemiz gerekiyor. Kaçış karakterleri sayesinde iç içe kullanılan ters tırnakların sınırlarını açıkça belirtebiliyoruz. Aksi halde hem başlangıç hem de bitiş karakterleri yalnızca tek tırnak olduğunda kabuk için iç içe olan yapının anlaşılması mümkün olmuyor. Neticede bizzat örnek üzerinden de görebildiğimiz gibi ters tırnak ile iç içe komut ikamesi kullanımı daha karmaşık bir komut yapısına sebep oluyor. 

Ters tırnağın okunması ve iç içe kullanımı karmaşaya sebep olduğu için bash kabuğunun eski sürümlerinde  çalışmak zorunda olmadıkça ters tırnak kullanımını tavsiye etmiyorum. Ancak elbette iki alternatiften dilediğinizi kullanmakta özgürsünüz. Ben de interaktif kullanımda yani sistemi yönetmek için kabuğa komutlar girerken, yazması daha pratik olduğu için tek bir komut ikamesi lazım olduğunda ters tırnağı da sıklıkla kullanıyorum. Ama iç içe yazarken tek tırnak karmaşaya sebep olabiliyor. 

Şimdilik komut ikamesi hakkında bahsetmek istediklerim bu kadar. Biliyorum henüz tam olarak gerçekte kullanımlarına dair bir örnek yapmadık ancak merak etmeyin ileride daha fazla komutu ve işlevi öğrendiğimizde gerçek hayatta kullanımlarına dair çeşitli örnekler de yapmış olacağız.

Çünkü ilk başta görünenin aksine aslında komut ikamesi son derece yararlı bir genişletme. Özellikle kabuk programlama gibi alanlarda komut ikamesi sıklıkla kullanılıyor.

Neticede artık komut ikamesinin iki alternatifi kullanım biçimini bildiğinize göre size hangisi daha kullanışlı geliyorsa onu kullanabilirsiniz. İleride komut ikamesi kullanımlarına dair birkaç örnek daha yapmış olacağımız için bence şimdilik komut ikamesi hakkında bunları bilmemiz yeterli. 

# İşlem İkamesi

Komut ikamesi haricinde işlem ikamesi adında bir genişletme alternatifimiz daha bulunuyor ancak bu genişletme özelliğini şu an açıklasam bile net biçimde anlaşılmayacak. Çünkü henüz yönlendirmelerden, işlemlerden ve pipe yapısından bahsetmedik. Bu sebeple yeri geldiğinde işlem ikamesi genişletmesinden bahsetmek üzere bu bölümde bu dersi pas geçiyorum. Genişletme türü olduğu için bu bölüme bu açıklamayı da eklemek istedim. Şimdi sözcük bölme aşamasından bahsedelim.

# Sözcük Bölme / Kelime Bölümleme

Normalde kabuğumuz, kendisine emir olarak vermiş olduğumuz komutları, aralarındaki boşluk tab veya ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, ‘>’ gibi çeşitli meta karakterlere bakarak kelime guruplarına ayırır ve bu şekilde işler. Zaten bu durumdan, eğitimin başında kabuğun nasıl çalıştığını temel düzeyde açıklarken bahsetmiştik. 

İşte genişletme aşamasında da parametre komut ikamesi ve aritmetik genişletmenin sonucunda ortaya çıkan veriler de sözcük bölümleme olarak geçen aşamadan geçip parçalara bölünüyor. 

Bu aşamadaki sözcük bölümleme işleminde eğer farklı bir bölümleme kuralı tanımlanmadıysa genişletilme sonucu ortaya çıkan argümanlar space tab veya yeni satır gibi özel boşluk karakterlerinden parçalara ayrılıyor.

Daha iyi anlamak için basit bir örnek yapmak istiyorum. Normalde eğer konsola echo $SHELL şeklinde yazarsak ne olur ? Elbette buradaki dolar işaretinden sonra belirtmiş olduğunuz SHELL değişkeni yani isimli parametre genişletilecek ve mevcut kabuğun değerini argüman olarak echo aracına verecek. Echo aracı da konsola bu çıktıyı bastıracak. Hemen deneyelim. Bakın ben mevcut kabuk programımın dizin adresini “/bin/bash” şeklinde çıktı olarak aldım. Şimdi aynı örneği bu kez IFS değişken değeri olarak slash karakterini tanımladıktan sonra deneyelim. 

Ben bunun için IFS=”/” şeklinde komutumu giriyorum. Buradaki ifs değişkeni parametre, komut ikamesi ve aritmetik genişletme sonucunda ortaya çıkan argümanların nasıl parçalara bölünmesi gerektiğini belirtmemizi sağlana bir değişken. Ben slash karakterini girdiğim için genişletme sonucu ortaya çıkan sonuç, slash karakterlerinden parçalara ayrılacak. Hemen denemek için echo $SHELL şeklinde komutumuzu tekrar girelim. Bakın bu kez “bin bash” şeklinde ayrı ayrı iki argüman halindeki çıktımızı almış olduk. Fark ettiyseniz ben IFS yani çıktıların hangi karakterden parçalara bölünmesi gerektiğini belirtirken slash karakterini tanımladığım için genişletilen /bin/bash çıktısı da; slash karakterinden parçalara bölünüp bin ve bash argümanları haline gelmiş oldu.

Yani parametre genişletmesinin ardından kelime bölümlemesi yapıldığını ve bölümleme yapılırken de IFS değerine bakılıp burada tanımlı olan karaktere göre parçalara ayrıştırıldığını bizzat bu basit örneğimizle teyit etmiş olduk. Bu kelime bölümleme işlemi parametre genişletmesine ek olarak komut ikamesi ve aritmetik genişletme sonucunda ortaya çıkan karakterler üzerinde de uygulanıyor. Eğer bu genişletmeler yoksa yani parametre, komut ikamesi veya aritmetik genişletme uygulanmıyorsa kelime bölümleme de uygulanmıyor. 

Ben örnek olması için IFS değerini değiştirmeyi ele aldım ancak normalde etkileşimli kullanımda IFS değerini değiştirmeye neredeyse hiç ihtiyaç duymuyoruz. Normalde daha önce de söylediğim gibi parametre komut ikamesi ve aritmetik genişletme yapıldıktan sonra, ortaya çıkan argümanlar space tab veya yeni satıra geçme karakterlerinden parçalara ayrılıyor. Yani genel olarak aralarında boşluk karakteri bulunan argümanlar birbirinden ayrıştırılıyor. Bu kelime bölme aşaması, kabuğun bizim girdiğimiz komutları anlayabilmek için gerçekleştirdiği ilk ayrıştırma aşamasından farklı. Bu bölümleme işlemi yalnızca parametre komut ikamesi ve aritmetik genişletme uygulandıktan sonra ortaya çıkan çıktılar üzerinde uygulanıyor. Bu özellik genellikle kabuk programlamada, genişletme sonucu ortaya çıkan argümanların istenildiği şekilde parçalara ayrıştırılması için tercih ediliyor. Yani veri manipülasyonu için kullanıldığına şahit olabilirsiniz. Ayrıca parametre komut ikamesi ve aritmetik genişletme işleminden sonra kelime bölümleme aşamasının gerçekleştiğini bildiğinizde ileride ele alacağımız diğer kuralları da net biçimde anlıyor olacaksınız.

Biz şimdi kelime bölümlemesi işleminden sonra gerçekleştirilen bir diğer genişletme türü olan "Dosya İsmi Genişletmesi"’nden bahsederek devam edelim.

# Dosya İsmi Genişletme

Kelime bölme işleminden sonra kabuk ortaya çıkan her kelimeye bakıp '*', '?' ve '[' karakterleri var mı diye kontrol ediyor. Bu karakterlerden biri görünüyorsa, kelime bir dosya ismi genişletmesi kalıbı olarak kabul edilir ve kalıpla eşleşen dosya ve klasör isimleri alfabetik olarak genişletiliyor. Yani dosya ismi genişletmesi aslında var olan dosya ve klasör isimleri ile eşleşecek kalıplar oluşturmamızı sağlıyor. Örneğin a ile başlayan dosya ve klasörler veya örneğin .txt ile biten tüm dosya ve klasörler gibi özel karakter kalıpları belirtip var olan dosya ve dizinlerin bu kalıba göre filtrelenmesini sağlayabiliyoruz.

Dosya ismi genişletmesi için de bash kabuğu standart olarak “yıldız”, soru işareti ve köşeli parantez joker karakterlerini kullanıyor. Fark ettiyseniz kabuk için özel anlam ifade eden bu karakterlere “joker karakterler” dedim. Buradaki joker karakter ifadesi önemli çünkü isminden den anlaşılabileceği gibi bu karakterler herhangi bir karakter ile eşleşebildikleri için bu isme sahipler. Hatta benim Türkçe “joker karakterler” olarak ifade ettiğim bu karakterlere ingilizce “wildcards” deniyor. Bu wildcards ifadesine, komut satırı üzerindeki çeşitli araçları kullanırken veya harici olarak ingilizce yardım sayfalarında sıklıkla rast geliyor olacağımız için joker karakterin wildcards olarak geçtiğini bilmeniz önemli. Örneğin kullanacağınız bir araç, bu “yıldız” “soru işareti” ve “köşeli parantez” karakterlerini özel anlamları ile ele almak için sizden wildcards seçeneğini ile bunu özellikle belirtmenizi bekleyebilir. Özellikle belirtmediğiniz durumda size hata çıktısında wildcards kullanmalısınız diye uyarı verebilir. Bu durumda dosya ismi genişletmek için kullanılan joker karakterlerin aslında wildcards olarak geçtiğini bilmeniz aldığınız hata çıktısını doğru anlayıp sorunu bilinçli şekilde çözmenizi sağlar. Lafı biraz uzattım ancak dosya ismi genişletmesi için kullandığımız bu joker karakterlerin wildcards olarak geçtiğini bilmeniz önemli. Şimdi kısaca bu joker karakterlerin kabuk için ifade ettiği anlamalara değinecek olursak;

Yıldız karakteri: sıfır veya herhangi bir karakter ile eşleşebiliyor.

Soru işareti: tam olarak yalnızca bir karakterle eşleşiyor.

Köşeli parantez: ise köşeli parantez içinde belirten herhangi bir karakter ile eşleşebiliyor.

Bu joker karakterlerin kullanımlarına tek tek değineceğiz ancak ilk olarak dikkatinizi çekmek istediğim nokta bu karakterlerin yalnızca var olan dosya ve klasör isimlerine genişletilmek için kullanılabildikleridir. Yeni dosya veya klasör oluşturmak gibi işlerde kullanılamazlar. Çünkü var olan dosya ve klasörler içinden bizim belirttiğimiz kalıba uyanları genişletmek için varlar. Zaten bu karakterler pattern matching yani desen eşleştirme karakteri olarak geçiyor. Yani var olan dosya dizin isimleri ile eşleşecek karakter desenleri oluşturmamızı sağlıyorlar.

Teorik açıklamanın anlamalı hale gelmesi için tabii ki örnekler yapmamız gerekiyor. Ben örnekler yapmak için öncelikle cd /etc komutu ile /etc dizinine geçiş yapmak istiyorum. etc dizini altında pek çok farklı dosya ve klasör bulunduğu için örnekler sırasında çeşitli alıştırmalar için bence bu dizin oldukça ideal. Hatta bakın ls komutu ile de bu dizin içeriğinin ne kadar çeşitli olduğunu görebiliyoruz.

Ben genişletmelerin sonuçlarını rahat gözlemleyebilmek adına yine echo komutunu kullanıyor olacağım.

Eğer echo komutumun ardından yıldız joker karakterini eklersem, bu var olan tüm dosya ve klasörlerin bastırılması demek oluyor. Hemen denemek için echo * komutunu girelim. Bakın tıpkı ls çıktısında olduğu gibi mevcut dizindeki tüm dosya ve klasörlerin isimleri konsola bastırıldı. Tabii ki ls komutunda olduğu gibi renkli ve düzenli bir çıktı olmadı ancak gizli dosya ve dizinler hariç tüm içerikler echo komutuna argüman olarak iletildiği için echo komutu tarafından konsola batırıldı. 

Ama görebildiğiniz yıldız işareti gizli dosya ve klasörleri kapsamıyor. Yani başında nokta işareti ile gizlenmiş olan dosya ve klasörlerin isimlerini yıldız genişletme karakterini kapsamıyor. Gizli olanları özellikle kapsaması için yıldız işaretinden önce nokta koymamız gerekiyor. Bakın benim etc dizinim altında tek bir gizli dosya varmış. Yıldız karakterinden önce nokta işaretini koyduğum için başlangıcı nokta olan ve devamında herhangi bir karakter olan tüm dosya ve dizinlerin kapsanması sağlanıyor. Benim çalıştığım etc dizini altında da bu biçimde olan yani gizli olan tek bir dosya olduğu için o dosya konsola bastırıldı.

Normalde yıldız işaretinin gizli içerikleri kapsamıyor olmasının nedeni farkında olmadan önemli dosyalar üzerinde yanlış işlem yapmamızı önlemektir. Zaten klasör veya dosyaların gizli olmasının amacı göz önünden uzak tutularak korunmasıdır. Bash kabuğunun joker karakteri olan yıldız işareti her şeyi kapsamasına rağmen gizli dosya ve klasörleri bilerek dışarıda tutuyor. Örneğin daha önce de ele aldığımız yani sizin de yakından tanıdığınız .bashrc konfigürasyon dosyası da kendi ev dizinimizde bulunan gizli bir dosyadır. Bu dosya silinirse kendi kullanıcı hesabımızdaki etkileşimli kabukları kullanma noktasında sorun yaşayabiliriz. Yani tekrar teyit ettiğimiz üzere yıldız joker karakteri gizli dosyaları boşuna hariç tutmuyor. Şimdi yıldız joker karakterini ihtiyacımıza göre nasıl kullanabileceğimize dair birkaç farklı örnek uygulama yapabiliriz.

Gizli içerikleri görmek için başı nokta ile başlayanları listeledik. Dilersek tersi şekilde sonu belirli  bir karakter veya karakterler ile bitenleri de listeleyebiliriz. Örneğin ben sonu i ile biten her şeyi bastırmak istersem echo *i şeklinde komutumu kullanabilirim. Bu kullanım sayesinde gizli dosyalar hariç başlangıcın ne olduğu veya ne kadar karakter içerdiği fark etmeksizin sonu i ile biten tüm içerikler bastırıldı.

Bakın buradaki tüm dosya ve dizin isimlerinin sonunda “i” harfi var.

Benzer şekilde birden fazla karakteri de spesifik olarak belirtebiliriz. Örneğin sonu .d ile biten içerikleri bastırmak için de benzer şekilde echo *.d komutunu kullanabilirim. Bakın yalnızca sonu .d ile bitenler listelenmiş oldu.

Görebildiğiniz gibi kullanımı son derece kolay. Spesifik olarak eşleşmesini istediğim bir veya birden fazla karakter varsa onları komutumda uygun şekilde belirttiğim sürece dosya ve dizin isimleri içinden tam olarak aradığım isimlerdekilere genişletiliyor. 

Ben yine örnek olması için başlangıcı “in” ile başlayan tüm dosya ve dizin isimlerinin genişletilerek echo aracına iletilmesini istiyorum. Bunun için echo in* komutunu girebiliriz. Bakın başlangıcı “in” olan tüm dosya veya klasör isimleri karakter uzunlukları fark etmeksizin bastırılmış oldu.

Başlangıç veya son yerine eğer herhangi bir yerinde i karakteri geçen tüm içerikleri bastırmak istersem echo *in* komutunu kullanabilirim. Bakın başlangıcında ortasında sonunda yani özetle dosya veya klasör isimlerinin herhangi bir yerinde “in” geçen tüm içerikler bastırılmış oldu. Yıldız işareti sıfır veya herhangi bir karakter anlamın geldiği için bu kadar geniş bir eşleşeme imkanı sağlamış oldu. Yani biz bu genişletme karakteri tanımı ile, başlangıcında sıfır veya sıfırdan başka herhangi bir uzunlukta karakter olan daha sonra “in” karakterinin geçtiği ve yine sonunda sıfır veya sıfırdan başka herhangi bir uzunlukta karakter olan tüm dosya ve dizin isimlerinin genişletilmesini sağladık.

İşte sizler de sıfır veya daha fazla sayıda herhangi bir karakter ile eşleşecek bir düzende dosya veya dizin ismi genişletmesi yapılsın istiyorsanız yıldız joker karakterini uygun biçimde genişletmenin başında sonunda veya her ikisinde de birden ihtiyacına uygun şekilde kullanabilirsiniz. 

Şimdi biraz da diğer bir dosya ismi genişletmesi karakteri olan soru işareti joker karakteriyle pratik yapalım. Daha önce soru işareti karakterinin herhangi tek bir karakter yerine geçtiğini belirtmiştik. Burada dikkat etmeniz gereken detay soru işareti joker karakterinin sıfır değil tek bir karakteri temsil ettiği. Ne demek istediğimi örnekler üzerinden açıklayalım. 

Örneğin ben başlangıcı ss olan ancak devamındaki karakterin herhangi bir karakter olduğu dosya ve klasörleri echo aracına argüman olarak vermek istiyorum. Bunun için echo ss? komutunu girmem yeterli. Bakın ssh ve ssl çıktılarını aldım. Bu çıktılarda yalnızca başlangıcı ss olan ve sonundaki tek bir karakteri herhangi bir karakter olan dosya ve klasörler yer alıyor. Yani fark ettiyseniz soru işareti yalnızca tek bir karakteri kapsıyor. 

Hatta bu durumu teyit etmek için bir veya birden fazla kez soru işareti kullandığımızda ne olacağına göz atabiliriz. Ben örnek için öncelikle echo p? şeklinde yazıyorum. Bakın tek bir karakter ile eşleştirildiği için ben pm çıktısını aldım. Şimdi bir de komutumuzu echo p?? şeklinde tekrar girelim. Bakın bu kez pm çıktısı yok, onun yerine p karakterinden sonra herhangi iki karakter bulunan pki ppp çıktılarını almış olduk. Yani bakın kaç tane soru işareti varsa yalnızca o sayı adedince karakter ile eşleşme yapılıyor. Ayrıca dikkat ettiyseniz daha önce de söylediğim gibi soru işareti karakteri 0 karakter ile eşleşme yapmıyor. Eğer soru işareti sıfır karakteri de kapsıyor olsaydı yine pm çıktısını da alacaktık. Çünkü ben çift soru işareti kullandığımda ilk soru işareti pm için m karakterini tamamladıktan sonra pm isminin devamında başka bir karakter olmadığı için yani sıfır karakter bulunduğu için ikinci soru işareti sıfır karakteri kapsayıp bize pm çıktısını vermeliydi. Ancak dediğim gibi soru işareti sıfırdan farklı yalnızca tek bir karakteri kapsıyor. İşte siz de dilediğiniz tek bir karakteri kapsaması için istediğiniz gibi soru işaretini kullanabilirsiniz. Örneğin isim ortasında kullanımına dair bir örnek olması için echo rc?.d komutu ile farklı rakamlarla temsil edilen klasörleri konsola bastırabiliriz. Bakın buradaki soru işareti rakamların yerini alıp bize bu klasörlerin isimlerini verdi.

Yani özetle tekrar tekrar tekrar teyit ettiğimiz gibi buradaki soru işareti mutlaka bir karakter ile eşleşecek şekilde genişletiliyor. 

Soru işareti dışında dosya genişletmesi için köşeli parantez kullanarak karakter aralıklarını da belirtebiliyoruz. 

Köşeli parantez içerisine yazdığımız karakterler soldan sağa doğru genişletilir. Örneğin başlangıcında a c z ve d karakterlerinden herhangi biri olan tüm içerikleri bastırmak istersem komutumu echo [aczd]* şeklinde girebilirim. Bu komut sayesinde köşeli parantez içindeki tüm karakterler soldan sağa doğru tek tek genişletiliyor ve yıldız karakteri sayesinde de devamında herhangi bir karakter olan tüm dosya ve dizineler kapsanmış oluyor. Yani neticede köşeli parantez içinde belirttiğimiz karakterlerden biri ile başlayan tüm içerikler bastırıldı görebildiğiniz gibi. 

Eğer tek tek spesifik olarak karakterleri girmek yerine aralık belirtmek istersek tire işaretini kullanabiliriz. Örneğin a da d ye tüm karakteri kapsamak için köşeli parantez içinde a-d şeklinde komut girebiliriz. 

Bakın başlangıç harfi a dan d ye kadar olan yani a b c d karakterlerinden biri ile başlayan tüm dosya ve dizinle konsola bastırıldı. Yani tire işareti ile aralık belirtebildiğimizi bu örnek üzerinde görebiliyoruz.

Benzer şekilde sayılar için de aralık belirtebiliriz. Örneğin ben isminde 1 den 5 e kadar olan rakamlardan birini barındıran tüm dosya ve klasörleri listelemek istersem komutumu echo *[1-5]* şeklinde girebilirim. Bakın içerisinde 1 den 5 e kadar olan rakamlardan birini barından tüm dosya ve klasörler listelendi. Yani sayısal olarak aralık belirtebildiğimizi de bu örnekle teyit etmiş olduk. Ayrıca farkındaysanız genişletme karakterlerini bir arada kullanabiliyoruz. Yani ben burada köşeli parantez genişletmesiyle birlikte yıldız joker karakterini de kullanıp istediğim dosya ve dizin isimlerini elde ettim. Benzer şekilde tabii ki soru işaretini de dilediğiniz gibi yıldız veya köşeli parantez genişletmesiyle birlikte kullanabilirsiniz. Bölüm sonunda karakterlerin bir arada kullanımını daha net anlayabilmek için zaten sizlere birkaç alıştırma bırakmış olacağım. Şimdi tekrar köşeli parantez genişletmesine dönecek olursak.

Linux üzerinde küçük büyük harf duyarlılığı olduğundan daha önce bahsetmiştik. Bu doğrultuda eğer genişletilecek dosya veya klasör ismi olarak büyük harfleri belirtmek istiyorsak özellikle büyük harfleri yazmamız gerekiyor. Örneğin büyük A ile başlayan içerikleri listelemek için komutumu echo [A]* şeklinde girmem gerekir. Ya da aralık belirtirken örneğin [A-Z]* şeklinde büyük harfle başlayan tüm içerikleri listeleyebiliriz. Hatta eğer echo [A-z]* şeklinde belirtirsek büyük küçük harfler de dahil başlangıcında a dan z ye kadar olan herhangi bir karakter bulunan tüm içerikler listelenecektir. Ben örnek olarak hep başlangıçtaki karakterler üzerinden çalıştım ancak siz yıldız işaretinin ve soru işaretinin işlevini öğrendiğiniz için istediğiniz şekilde çıktıları sınırlayabilirsiniz. İstediğiniz gibi özelleştirebilecek kadar detay öğrendik. Zaten temel dosya ismi genişletmeleri bunlar.

Ayrıca biz şu ana kadar hep belirttiğimizi karakterler ile eşleşecek şekilde komut girdik. Dilersek belirttiğimiz karakterler dışındakileri kapsayacak şekilde de komut girebiliriz. Yani hariç tutulacak karakterleri özellikle belirtip, geri kalan karakteri barındıran dosya ve dizinler in genişletilmesini sağlayabiliriz. Bunun için tek yapmamız gereken ünlem işaretini kullanmaktır. Örneğin başlangıcında a b c d geçmeyen içerikleri bastırmak istersem echo [!abcd]* şeklinde komut girmem yeterli. Bakın belirttiğim karakterler hariç tüm eşleşenler bastırıldı. Örnek üzerinden de görebildiğimiz gibi ünlem işaretini hariç tutulmasını istediğimiz karakterleri belirtmek için kullanabiliyoruz.

Ben anlatımlar sırasında mümkün oldukça temel işleyişi anlamamıza yetecek kadar örnek verdim ama yapısı gereği zaten joker karakterleri kullanarak sınırsız sayıda örüntü oluşturabiliriz. Yani temelde nasıl çalıştığını bildiğiniz zaman ihtiyaçlarınıza göre istediğiniz kalıbı oluşturabilirsiniz. Zaten bu karakterlerin amacı da bu, yani desenler oluşturup dosya isimleri ile eşleşmeler sağlamak. Burada ele aldıklarımız joker karakterleri etkili kullanmanın tek yolu da bolca pratik yapmanızdır. 

Ayrıca ben anlatımlar sırasında hep echo komutunu kullandım ancak sizler dilediğiniz bir araca argüman vermek için dosya ismi genişletmesini kullanabilirsiniz. Örneğin sonu .txt ile biten tüm dosyaları silmek istediğinizde rm *.txt komutunu kullanmanız yeterli olacaktır. Denemek için öncelikle sudo touch {1..9}.txt komutu ile 1 den 9 da kadar isimlendirilmiş sonu .txt ile biten dosyalarımızı oluşturalım. sudo komutunu kullanıyorum çünkü etc dizini atlında çalıştığımız için dosya oluşturma ve silme gibi işlemler için yetki gerekiyor. İleride bu konuya ayıraca değineceğiz. Bakın dosyalar oluşturuldu. Şimdi sonu .txt ile biten tüm dosyaları silmek için rm komutuna argüman olarak iletmek için tek yapmamız gereken uygun dosya ismi genişletmesi kalıbını yazmak. Bunun için komutumu sudo rm *.txt şeklinde giriyorum. Tekrar listeleyelim. Bakın sonu txt ile biten tüm dosyalar buradaki dosya ismi genişletmesi sayesinde rm komutuna argüman olarak aktarıldı, dolayısıyla rm aracı da bu dosyaların hepsini sildi. 

İşte zaten dosya adı genişletmelerini bu ve bunun gibi sebeplerle kullanıyoruz. Kabuk üzerinden dosya ve klasörler üzerindeki hakimiyetimizi arttırıp gerektiğinde bize inanılmaz kolaylık sağlayabiliyor.  

Dosya ismi genişletmesini bitirmeden önce, dosya ismi genişletmesi ile sıklıkla karıştırılan regex kavramından bahsetmek istiyorum. Bu sayede dosya ismi genişletmelerini daha net anlamış olacağız.

Eğer daha önce herhangi bir programlama dili ile ilgilendiyseniz regex yani regular expression kavramıyla mutlaka karşılaşmışsınızdır. Regex en özet haliyle, spesifik olarak belirli bir karakter kalıbı ile eşleşecek desenler yaratmanıza izin veren özel karaktere verdiğimiz isimdir. Regex doğru şekilde kullanıldığında her türlü metinsel ifadenin aranması bulunması ve ayrıştırılması konusunda inanılmaz kolaylık sağlıyor. Biz regex ile aradığımız karakter kalıbını belirtip metinsel veri girişi sağladığımızda regex metinsel verideki kalıba uyan tüm karakterleri sorunsuzca bize iletiyor. Yani regex kullanırken dosya ismi genişletmesinde olduğu gibi mevcut dosya veya dizin isimleri ile sınırlı değiliz. Regex e istediğimiz metinsel veriyi girdi olarak verip sonucunda istediklerimizi ayrıştırabiliyoruz.

Genelde modern programlama dillerinin hepsinde regex kullanmak mümkün ancak bash kabuğu programlanabilir yapıda olmasına karşın doğrudan kendi içinde regex i kullanmıyor. Bunun yerine mevcut dosya ve klasörlerin isimlerine genişletilmek üzere “dosya ismi genişletmesi” ya da diğer adıyla “globbing” olarak geçen kabuğun sağladığı yıldız soru işareti ve köşeli parantez joker karakterlerini kullanıyor. 

Bash kabuğu dahili olarak regex desteklemediği için dosya ismi genişletmesi yerine regex kullanarak metinlerdeki örüntüleri bulmamız gerektiğinde de, kabuk haricinde sed awk veya grep gibi regex destekleyen araçlar ile işimizi halledebiliyoruz. Yani buradaki dosya ismi genişletmesi özelliği kabuğun kendisine ait olan gömülü özelliktir. Harici olarak eğer regex kullanmamız gerekirse, regex yeteneğine sahip grep sed awk gibi araçları kullanarak metinsel veriyi işlememiz gerekiyor. Zaten kabuğun amacının bize komut satırında çalışma ortamı sağlamak olduğundan daha önce tekrar tekrar bahsettik. Dolayısıyla zaten kabuğun doğrudan kendi içinde regex desteklemesi gerekmiyor çünkü kabuğun asıl görevi bizim ihtiyacımız olan araçları bulup bu araçları konsol üzerinden rahat yönetebilmemiz. Biz istediğimiz aracı kabuk sayesinde çalıştırdıktan sonra zaten o aracın tüm özelliklerini kabuktan bağımsız olarak kullanabiliyoruz. 

Yani kabuğun regexi desteklememesi bir eksiklik değil, kabuğun yapısının bir parçasıdır. Kabuk tüm bu bölüm boyunca bahsettiğimiz gibi bize gerekli çalışma ortamını sağlayacak genişletme özelliklerine zaten sahip. Eğer regex gibi ek özellikler gerekiyorsa, bu özellikleri destekleyen harici araçları kullanarak işlerimizi halledebiliyoruz.

Regex ile globbing olarak geçen dosya ismi genişletmesi arasındaki farkı iyi anlamamız, kabuğa vereceğimiz komutların sonuçları üzerinde çok etkili. Kabuk temel görevlerini yerine getirmek için kendi bünyesinde tanımlı olan joker karakterler olarak da bilinen basit dosya ismi genişletme karakterlerini kullanıyor. Bu joker karakterler regex kullanımına benzer olduğu için sıklıkla karıştırılıyor ancak yıldız soru işareti ve köşeli parantez karakterleri mevcut kabukta özel anlamını bulunan çeşitli karakterlerdir. Ek bir araç olmadan bu karakterler kullanıldığında kabuk bunları joker karakter olarak değerlendiriyor. 

Ben joker karakterler ile regex in farkını size göstermek için çok basit bir örnek ele almak istiyorum. Ancak bu örneğin anlaşılabilmesi için de alıntı karakteri olarak geçen tek ve çift tırnak kullanımına değinmemiz gerekiyor. Gelin anlatıma genişletme adımlarından sonra gerçekleştirilen alıntı karakterlerinin kaldırılması ile devam edelim.

## Alıntı Karakterlerinin Kaldırılması

Kabuk için özel anlam ifade eden metakarakterlerin kabuk tarafından özel anlamlarına genişletildiğini tüm bu bölüm boyunca adım adım ele aldık. Eğer kabuk için özel anlamı olan karakterlerin kabuğun genişletmesinden muaf tutulmasını istersek bu karakterleri tırnak içinde yazarak kabuk için sıradan karakterler olarak görülmelerini sağlayabiliriz. Eğer hatırlıyorsanız yeni klasör oluştururken girdiğimiz komutta klasör ismindeki boşluk karakteri kabuk tarafından iki argüman olarak algılandığı için içerisinde boşluk karakteri bulunan yeni bir klasör oluşturamamıştık. Bu duruma çözüm olarak da klasör ismini tırnak içinde yazmıştık. Heh işte bu durum burada bahsi geçen alıntılama kavramının ta kendisi. Tırnak içinde yazmaya alıntılama deniyor ve tırnak içindeki karakterler kabuk için ifade ettikleri özel anlamlardan muaf tutuluyorlar.

Söz konusu alıntılama olduğunda tek ve çift tırnak kullanabileceğimiz iki alternatif yöntem bulunuyor. 

Tek tırnak en katı alıntılama biçimidir. Tek tırnak içindeki hiç bir karakter kabuk tarafından özel anlamaları dahilinde ele alınmıyor. 

Hemen denemek için şu ana kadar ele aldığımız genişletme karakterlerini tek tırnak içinde yazıp echo aracı ile konsola bastırmayı deneyelim. Ben denemek için öncelikle 1 den 5 e kadar rakamları genişletecek olan kıvırcık parantez genişletmesini yazıyorum. Daha sonra tilde genişletmesini test etmek için tilde işaretini ekliyorum. Parametre genişletmesini test etmek için isimli parametre olan SHELL değişkenini de ekliyorum. Aritmetik genişletme için 1 ile 2 nin toplamını da ekleyelim. Komut ikamesini denemek için de echo aracı ile test1 yazdırabiliriz. Hatta ikinci kullanımı olan test tırnak ile de test2 yazdırmayı deneyebiliriz. Son olarak de dosya ismi genişletmesini kullanmak için mevcut dizinde bulunan tüm dosya ve klasörlere genişletilecek olan yıldız joker karakterini ekleyebiliriz. Komutumuzu onaylayıp sonuca bakalım.

```bash
echo '{1..5} ~ $SHELL $((1+2)) $(echo test1) `echo test2` *'
```

Bakın tek tırnak içinde yazmış olduğum hiç bir genişletme karakteri kabuk tarafından genişletilmedi. Nasıl yazdıysam aynen echo aracına iletilip konsola bastırılması sağlandı. 

Şimdi aynı örneği çift tırnak içinde tekrar deneyebiliriz. Ben denemek için yalnızca sonraki ve baştaki tek tırnakları silip çift tırnak ekleyeceğim. Tamamdır komutumuzu onaylayıp sonuçları üzerine konuşalım.

```bash
echo "{1..5} ~ $SHELL $((1+2)) $(echo test1) `echo test2` *" 
{1..5} ~ /bin/bash 3 test1 test2 *
```

Evet, kısmi olarak bazı genişletmelerin uygulanıp diğerlerinin uygulanmadığı bir çıktı aldık. Çok fazla detaylarına girmek istemiyorum ancak çıktılarda görebildiğimiz gibi parametre genişletmesi, aritmetik genişletme ve komut ikamesi çift tırnak içinde geçerliliğini korumaya devam ediyor.

Kıvırcık parantez genişletmesi tilde genişletmesi ve dosya ismi genişletmeleri ise çift tırnak içinde geçerliliğini yitiriyor. Çünkü çift tırnak içinde kabuk dolar işareti test tırnak ve ters slash karakterleri istisna tutularak özel işlevlerini yerine getirebiliyorlar. Zaten dolar işaretini ve ters tırnağı kullandığımız genişletmelerin gerçekleştiğini çıktılardan görebiliyoruz. Aslında bunlara ek olarak ünlem işareti ile kullandığımız geçmiş genişletmeleri de çift tırnak içinde geçerli oluyor. Örneğin denemek için öncelikle echo test yazıp geçmişe yeni bir komut ekleyelim. Şimdi bu komutu geçmişten çağırmak için çift tırnak içinde echo “!!” şeklinde yazabiliriz. Bakın geçmiş genişletmeleri çift tırnak içinde geçerliliğini korumaya devam ediyor.

Konuyu detaylandırıp kafanızı karıştırmak istemiyorum. Muhtemelen buradaki detaylar zaten aklınızda kalmayacak. Ancak burada dikkatinizi çekmek istediğim asıl nokta, dosya ismi genişletmesinin çift veya tek tırnak içinde geçerli olmadığıdır. Bizler bu sayede regex destekleyen araçlara komut girerken regex karakterlerinin kabuk tarafından yanlış anlaşılmasını önlemek için tırnak içinde yazıyoruz. Örnek üzerinden bu durumu net bir biçimde anlamış olacaksınız.

İleride ayrıca ele alacağımız filtreleme aracı yani grep aracı ile örnek verebiliriz. Öncelikle filtrelenecek metin içeriğini oluşturalım. Ben bunun için cat > metin1.txt komutunu girip örnek metin olarak “linux bir işletim sistemi Değil çekirdektir” yazıp ctrl d ile dosya içeriğini kapatıyorum. Bir dosya daha oluşturalım. Ben yeni bir metin dosyası daha oluşturmak için cat > metin2.txt komutunu giriyorum. Şimdi içine “Bu bir DENEME metnidir” şeklinde yazalım. Tamamdır bunu da ctrl d ile sonlandıralım. Şimdi bu metinler üzerinde spesifik olarak istediğimiz bir kelime veya karakteri filtrelemek için grep aracını kullanabiliriz. Ben örnek olması için büyük D karakterlerini araştırmak istiyorum. Zaten sırf bu sebeple d karakterlerini de büyük yazdım. 

Grep aracı ile araştırma yaparken grep komutundan sonra araştırmak istediğimiz karakter kalıplarını regex kuralları dahilinde yazıp daha sonra bu karakterin araştırılacağı metinleri de argüman olarak eklememiz gerekiyor. Yani grep aracına: grep araştırılacak-kelime ve bu kelimenin nerelerde araştırılacağı şekline belirtemiz gerekiyor. grep komutundan sonraki ilk argüman grep aracının araştıracağı ifadeyi temsil ediyor. Diğer argümanlar ise bu ifadenin nerelerde araştırılacağını temsil ediyor. Bu durumu hemen örneğimiz üzerinden görebiliriz.

Şimdi bu metinlerdeki D karakterlerini filtrelemek için grep komutundan sonra çift tırnak içinde “D*” yazalım ve hangi metinler içinde araştırılacağını da metinler*.txt şeklinde belirtelim. Bakın burada tırnak içinde yazdığım bu ifade aslında regex tanımı. Bu tanım sayesinde içinde büyük D karakterini barından tüm kelimeler filtrelenecek. Tırnaksız olarak yazdığım metin*.txt argümanı ise dosya ismi genişletmesi için kullandığım joker karakter. Bu sayede girdiğim bu argüman genişletilip metin1.txt ve metin2.txt argümanı haline gelecek. Böylelikle grep aracı büyük D karakterini hem metin1.txt hem de metin2.txt dosyaları içinde araştırıyor olacak. Komutumuzu girip sonuca bakalım. Bakın grep aracı büyük D karakterlerini kırmızı renkle filtrelemiş oldu. Şimdi aynı örneği bu kez çift tırnak olmadan tekrar deneyelim. Bunun için ben komutumu bu kez tırnak olmadan tekrar giriyorum.

Bakın şimdi ise grep aracı  Documents ve Downloads un birer dizin olduğunu belirten çıktılar bastırdı yalnızca. Bu çıktıyı almış olma nedenimiz, kabuğun buradaki büyük D karakterinden sonraki yıldız joker karakterini dosya ismi genişletmesi olarak kabul etmesidir. Yani benim burada girmiş olduğum grep D* metin*.txt komutu genişletmelerin ardından, grep Desktop Documents Downloads metin1.txt metin2.txt halini almış oldu. Grep aracı da buradaki dosya ve dizinlerde “Desktop” ifadesini araştırmaya koyuldu ancak Documents ve Downloads yalnızca dizin olduğu için ve bu metin dosyalarında da Desktop ifadesi geçmediği için herhangi bir çıktı bastırılmadı. Hatta komutunun bu halde olduğunu kanıtlamak için cat > metin3.txt komutu ile yeni bir metin belgesi oluşturup, içine “Desktop artık mevcut” şeklinde yazalım. Tamamdır şimdi komutumuzu tekrar çalıştıralım.

Bakın desktop ifadesi öncelikle Documents ve Downloads dizinlerinde araştırılmaya çalışıldı ancak bunlar dizin olduğu için metinsel bir veri barındırmıyorlardı dolayısı ile bunların dizin olduğu uyarısı bastırıldı. Daha sonra ise metin dosyaları araştırıldı ve metin3.txt dosyasında Desktop ifadesinin geçtiği bölüm filtrelenip renkli şekilde bize sunuldu.

İşte bakın bizzat örnekler üzerinden de teyit ettiğimiz gibi regex karakterlerini çift tırnak içinde yazmadığımızda kabuk bu karakteri dosya ismi genişletmesi joker karakteri sanıp dosya ismi genişletmesi uyguluyor. Yani bizim aslında spesifik tek bir karakteri aramak için girdiğimiz regex ifadesi kabuk tarafından dosya ismi genişletmesi olarak sanılıp dosya isimlerine genişletip argümanların başka bir hale gelmesine neden oluyor.

Zaten bu sebeple çift tırnak içindeki dosya ismi genişletmesi uygulanmıyor ve regex kullanan araçlarda filtreleme için belirtilen kurallar çift tırnak içinde belirtiliyor. Umarım regex ile dosya ismi genişletme karakterlerinin benzer görünüp farklı çalışma yapıları olduğunu bu örnek ile yeterince açık anlaşılmıştır. Genellikle önemsiz gözüken bu gibi detaylar girdiğimiz komutların bambaşka sonuçlar doğurmasına neden olduğu için aslında çok önemli. Bu sebeple zaten tek tek tüm temel detaylardan bahsetmeye gayret ediyoruz. Regex kullanımından da eğitimin devamında yeri geldiğinde çok kısaca bahsediyor olacağız. 

Neticede kabuk tüm genişletmeleri uyguladıktan sonra son olarak tırnak işaretleri kaldırılıp komut en son haliyle çalıştırılıyor. 

Ve böylelikle kabuk üzerinde yer alan tüm genişletme türlerinden bahsedip, gerektiğine nasıl faydalanabileceğimizi öğrenmiş olduk. Son olarak tüm yapıyı en genel haliyle özetleyip bu bölümü artık sonlandıralım. 

# Özet

Şimdiye kadar kabuğun bizim girdiğimiz komutları tam olarak nasıl ele aldığını anlamak için sırasıyla bash kabuğu üzerinde geçerli olan genişletmelerden tek tek sırasıyla bahsettik. Şimdi kısaca tüm işleyişi tekrar özetleyip bu bölümü sonlandırmak istiyorum.

Kabuk kendisine emir olarak verilmiş olan komutu öncelikle parçalara ayırıp sözcük analizi yapılıyor. Bu sayede özel anlam ifade eden karakterler dahilinde girilen komutun doğru anlaşılması sağlanıyor.

Daha sonra genişletme aşamasına geçiliyor. Bu aşamada ilk olarak süslü parantez genişletmesi uygulanıyor. Süslü parantez genişletmesi istediğimiz türde örüntüler oluşturabilmemizi yani sıfırdan argümanlar oluşturabilmemizi sağlayan genişletme özelliği.

Daha sonra tilde genişletmesi ile ilgili kullanıcının ev dizininin tam dosya yoluna genişletme yapılıyor.

Tilde genişletmesinden sonra hepsi aynı önceliğe sahip şekilde parametre, aritmetik ikame, işlem ikamesi ve komut ikamesi genişletmeleri yapılıyor. 

Komut ikamesi gibi genişletilmiş argümanların ürettiği çıktıların doğru parçalara ayrılması için de kelime ayırma-bölümleme yapılıyor. 

Kelime ayırma işleminden sonra da dosya ismi genişletmesi olarak geçen globbing joker karakteri dikkate alınarak mevcut dosya ve dizin adreslerinin isimleri dahilinde genişletmeler yapılıyor.

Tüm bu genişletmelerden sonra da eğer kullanıldıysa tırnak işaretleri komuttan kaldırılıp komut son haliyle çalıştırılıyor. 

İşte bash kabuğun bizim girdiğimiz komutları anlamlandırışının en genel özeti bu şekilde. Sırasıyla tüm genişletmeleri dikkatlice takip edince aslında sıralamanın, girilen komutların anlamlandırılması için ne kadar önemli olduğunu da fark ediyor. Sıralama değiştiğinde komutların anlamaları da değişeceği için anlatımları da sıraya uygun biçimde genişletmelerin birbiriler ile olan ilişkisini de açıklayarak ele almaya çalıştık. 

Genişletmeleri daha iyi anlamak için tek yapmanız gereken burada bahsetmiş olduğumuz genişletmelere dair bol bol kendi kendinize pratikler yapmak. Pratik yaptıkça aslında ne kadar basit ve kullanışlı bir yapı olduğunu fark edeceksiniz.

1. parsing and lexical analysis
2. expansion
    1. brace expansion
    2. tidle expansion
    3. variable expansion
    4. artithmetic and other substitutions
    5. command substitution
    6. **word splitting**
    7. filename generation (globbing)
3. removing quotes

# Alıştırmalar

- 2’den 12 ye kadar olan sayıların ikişer aralıklar ile konsola bastırılmasını sağlayın.
    - {2..12..2}
    - [2..12..2]
    - (2..12..2)
- a dan f ye kadar olan karakterleri üretmek için hangi genişletmeyi kullanmamız gerekir ?
    - {a..f}
    - {a-f}
    - [a..f]
    - [a-f]
- a dan z ye kadar olan karakterleri beşer aralıkla üretmek için hangi genişletmeyi kullanmamız gerekir ?
    - {5..a..z}
    - {a..5..z}
    - {a..z..5}
    - {a..z}5
- test1 test3 test5 şeklinde devam eden 1 den 9 ye kadar 2 şer aralıklı argümanlar üretmek için hangi genişletmeyi kullanmamız gerekir ?
    - test{1..9}
    - test{1..9..2}
    - test {1..9}
    - test {1..9..2}
- echo {1..3}{a..c}{A..C} komutu hangi çıktıyı üretir ?
    - 1 2 3 aA aB aC bA bB bC cA cB cC
    - 1 2 3 a b c A B C
    - 1aA 1aB 1aC 1bA 1bB 1bC 1cA 1cB 1cC 2aA 2aB 2aC 2bA 2bB 2bC 2cA 2cB 2cC 3aA 3aB 3aC 3bA 3bB 3bC 3cA 3cB 3cC
    - 1a 1b 1c 2a 2b 2c 3a 3b 3c A B C
- sistemdeki ali isimli kullanıcın ev dizini öğrenmek için hangi genişletmeyi nasıl kullanırsınız ?
- ~ali
- SHELL değişkenin değerini konsola batırmak için aşağıdakilerden hangi genişletme yapısını kullanmanız gerekir ?
- $SHELL
- 3 ile 5 rakamlarının çarpımını elde etmek için hangi genişletmeyi ne şekilde kullanırsınız ?
- $((3*5))
- Komut ikamesini kullanarak konsola, “şu anda bulunduğum dizin:” yazdırıp karşısına bulunduğunuz dizinin dosya yolunu veren komutun çıktısını nasıl eklersiniz ?
- echo “Şu anda bulunduğum dizin: $(pwd) veya echo “Şu anda bulunduğum dizin: `pwd`
- aşağıdaki iç içe komut ikamesi kullanımlarından hangisi doğrudur ?
- Doğru cevap: echo $( echo “ilk ikame” $(echo “ikinci ikame” $(echo “son ikame”)))
- Dosya ismi genişletmesinde tek bir karakteri kapsayan joker karakter hangisidir ?
- soru işareti
- Dosya ismi genişletmesinde tüm karakterleri kapsayan joker karakter hangisidir ?
- yıldız joker karakteri
- Dosya ismi genişletmesi için aralık belirtmemize olanak tanıyan joker karakter hangisidir ?
- köşeli parantez joker karakteri
- tek tırnak ile çift tırnak arasındaki fark hangi seçenekte doğru açıklanmıştır.
- tek tırnak içerisinde hiç bir genişletme uygulanmaz. çift tırnakta ise dolar işareti ($) ve ters slash kaçış karakteri (\) gibi bazı özel karakterle özel anlamlarına genişletilebilirler.
- çift tırnak içinde dosya ismi genişletmesi uygulanır mı ?
- hayır uygulanmaz.

Örneğin başlangıcında herhangi tek bir karakter olan ve devamındaki karakter x y t olup sonraki karakterleri de herhangi türden karakter olan dosya ismi genişletmesini nasıl tanımlarsınız?

?[xyt]*

Başlangıç harfi a olan ve sonu .txt ile biten dosya ismi genişletmesi örüntüsünü nasıl oluşturursunuz? 

a*.txt

a ile başlayıp t ile biten tüm dosya ve klasörler için ? 

a*t

İlk harfi herhangi tek bir harf olan ve devamında x karakteri bulunan ve sonrasındaki karakter sayısı ve biçimi fark etmeyen bir dosya ismi genişletmesini nasıl tanımlarsınız ?

?x* şeklinde tanımlarız.

Başlangıcı sıfır veya birden fazla karakter olan “a” karakterini barındıran ve “a” karakterinden sonra tek bir karakter içeren dosya ismi genişletmesini nasıl tanımlarsınız ?

*a? şeklinde tanımlarız.

Başlangıcında 1 den 13 e kadar sayılardan biri olan ve devamında tek bir karakter barındıran dosya ismi genişletmesini nasıl tanımlarsınız ?

[1-13]? şeklinde tanımlarız.

İsminin balında 1 4 5 ve sonunda a b c d karakterlerini barındırmayan dosya ismi genişletmesini nasıl tanımlarsınız ?

[!145]*[!abcd]

İlk karakteri x y veya t olan ancak son karakteri x y veya t olmayan dosya ismi genişletmelerini nasıl tanımlarsınız ?

[xyt]*[!xyt] şeklinde tanımlarız.

Örnekleri çoğaltmak mümkün ancak bunun bir sonu yok. Siz kendiniz için bir çalışma ortamı hazırlayın ve dilediğiniz şekilde pratikler yapın. Örnek dosya veya klasörleri kolayca üretmek için kıvırcık parantez genişletmesi ile tek seferde istediğiniz desenlerde dosya veya klasör oluşturabileceğinizi zaten kendiniz de biliyorsunuz. Kendi çalışma ortamınızı hazırlayın ve genişletmeleri kurcalayarak özümseyin.