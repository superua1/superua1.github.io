# ✅ 12- Bilgi Alma Komutları

Bilgi alma komutları sistemdeki tarih takvim araçlar dosyalar ayarlar kayıtlar ve benzeri pek çok yapı hakkında konsol üzerinden kolayca bilgi edinebilmek için kullandığımız komutlardır. Esasen tüm eğitim boyunca kullandığımız ve kullanmaya da devam edeceğimiz pek çok komutu bilgi alma komutları sınıfında değerlendirmemiz mümkün. Çünkü hepsi, kendi görevleri özelinde pek çok bilgi sunma kabiliyetine sahip araçlar. En basit örnek olarak, ls komutu bile tek başına kullanıldığında mevcut dizinimizdeki içerikler hakkında bilgi almamızı sağlıyor. 

Yine de eğitimin geri kalanında değinmek için uygun bölümleri bulunmayan ama haberdar olmamızın faydalı olacağı bazı araçlardan “bilgi alma bölümü” altında çok kısaca bahsetmek istiyorum. Burada bahsettiklerim dışındakiler tüm eğitim boyunca kullandığımız komutlar olduğu için tekrar bilgi alma başlığı altında değinmek istemiyorum. Zaten bu bölümdeki komutları da çok kısaca hap bilgi şeklinde özetliyor olacağız. 

Öncelikle takvim ve saat gibi temel bilgileri nasıl edinebileceğimizle başlayabiliriz. 

# Tarih ve Saat Hakkında Bilgi Edinme

# date Komutu

Eğer grafiksel arayüz kullanıyorsanız zaten mutlaka tarih ve saati kolayca öğrenebileceğiniz bir ortama sahipsinizdir. Pek çok grafiksel arayüzde, tıpkı bende de olduğu gibi sistem saati masaüsütü ortamında yönetim çubuğunda gözüküyor. Eğer saatin üzerinde tıkarsak takvim bilgisine de kolayca erişebiliyoruz gördüğünüz gibi. 

Bu bilgileri komut satırından edinmek içinde ise date komutunu kullanabiliyoruz. Tek başına kullanıldığında gördüğünüz gibi sırasıyla, haftanın gününü, ayı, ayın gününü, saati, saat dilimini ve yılı içeriyor. Yardım sayfasına baktığımızda pek çok kullanım seçeneğinin olduğunu görebiliyoruz. Ancak temelde sistem tarihini ve saatini değiştirme özelliğine ihtiyacımız oluyor. 

Tarih ve saati değiştirmek için yönetici ayrıcalıklarına ihtiyacımız var bu sebeple sudo komutu başta olacak şekilde yeni sistem tarihini date -s komutunun ardından tam olarak belirtmemiz gerekiyor. Zaten buradaki s seçeneği set yani ayarlama ifadesinden geliyor. Tırnak işareti içerisinde "yıl-ay-gün saat:dakika:saniye" şeklinde belirtmemiz gerekiyor. Ben test etmek için ileri bir tarihi belirtiyorum ve parolamı girip tarihin değişmesini sağlıyorum. date komutu ile tekrar kontrol ettiğimde belirttiğim tarihin ayarlanmış olduğunu görebiliyorum. Fakat aslında sistem internet üzerinden otomatik olarak senkronize edildiği için bu özelliğe de neredeyse hiç ihtiyacınız olmaz. Yine de bağlantının olmadığı durumlarda elle tarih girmek için date komutunun -s seçeneğini kullanabileceğinizi artık biliyorsunuz. Bu seçeneği hatırlamasanız bir date —help komutu ile hemen yardım bilgisine göz atıp seçeneği tekrar hatırlayabilirsiniz. Zaten önemli olan, bu özelliğin varlığından haberdar olmak. Haberimiz olduktan sonra yardım sayfalarını her zaman kullanma imkanız var.

Normalde senkronizayonun internet üzerinden otomatik olarak gerçekleştirildiğinden bahsettim. Kısaca özetlemek gerekirse örneğin değiştirdiğiniz tarihin internet üzerinden otomatik olarak senkronize olması için tekrar senkronizasyon servisini başlatabilirsiniz. Servisi başlatmak için sudo service ntpd start komutunu girmeniz yeterli. Bakın servisi çalıştırdıktan sonra tekrar date komutu ile teyit ettiğimde tarihin otomatik olarak senkronize olduğunu görebiliyorum. Buradaki NTP kısaltması The Network Time Protocol ifadesinden geliyor. Türkçe olarak ağ zaman protokolü anlamına gelen bu servis bilgisayar sistem saatini ağ üzerinden otomatik olarak senkronize ediyor. Normalde sistem kendisi bu servisi otomatik olarak çalıştırıyor ama ben bu servisin varlığını kanıtlamak ve elle tarih ayarlamasını da göstermek istediğim için kısaca değinmiş oldum. Lütfen şimdilik buradaki servis kavramına çok takılmayın. İleride servisleri ayrıca ele alacağız. O zaman servisten kastımın ne olduğunu net biçimde anlamış olacaksınız. 

Şimdi bir sonraki bilgi edinme komutu olan cal komutundan bahsederek devam edelim.

# cal Komutu

`cal` komutu tek başına kullanıldığında mevcut ayın takvimini konsola basıyor. Bu komuta ek olarak eğer takvimde gün isimlerinin de bastırılmasını istersek ncal komutunu da kullanabiliriz. Bakın sol tarafta gün isimleri sırasıyla yazıyor. Takvim de bu günlerin sıralamasına uygun şekilde basılmış oldu. Bu iki komut da tek başına kullanıldığında mevcut ayın takvimini getiriyor. Eğer geçmiş ya da gelecek bir tarihten takvim bilgisine bakmak istersek cal ya da ncal komutunun ardından ay ve yılı belirterek tam istediğimiz tarihteki takvim bilgisine de ulaşabiliriz. Ben örnek olarak 2000 yılının ocak ayının takvimini bastırmak üzere cal 1 2000 şeklinde komutumu giriyorum. Bakın tam o tarihin takvimi getirildi. Benzer şekilde ileri tarih de belirtebiliriz. Ben 2025 yılının 6 ayı için takvim bilgisini istiyorum. Bakın bu takvim de bastırıldı. İşte ihtiyacınız olduğunda sizler de konsol üzerinden takvim bilgisine bu şekilde kolayca ulaşabilirsiniz. Komutun ismi calendar yani takvimden geldiği için hatırlaması da kolay aslında. Yine de unutursanız örneğin yardım sayfalarını apropos calendar komutu ile kurcalayabilirsiniz mesela. Bakın takvimle ilgili çeşitli komutlar karşımıza geldi.

Biz takvimi öğrenebileceğimiz bir komut olduğunu bildiğimiz sürece, ilgili komutun ismini bulmak için yardım sayfalarını kolayca kullanabiliyoruz gördüğünüz gibi.

# Dosyalar Hakkında Bilgi Edinme

# which Komutu

Konsola girdiğimiz komutlarla çalıştırdığımız araçların dosya konumlarını öğrenmek için which komutunu kullanabiliriz. Örneğin sizler de biliyorsunuz ki; ben konsola ls yazdığımda kabuk öncelikle ls isminde bir yerleşik komutu var mı diye bakıyor, eğer yoksa path yolu üzerinde bu isimde bir dosya var mı diye araştırmaya giriyor ve eğer bulabilirse bu dosyayı çalıştırıyor. Zaten bu durumdan eğitimin en başında bahsettik. İşte bash komutunun bulup çalıştırmasına benzer şekilde, which komutu da kendisine argüman olarak belirtilmiş olan isimdeki aracın tam dosya konumunu bize bildiriyor. Yani aslında which komutu da path yoluna bakarak argüman olarak verdiğim aracı araştırıyor. Dolayısıyla path yolunda olmayan araçların dosya konumları which komutu tarafından bastırılamıyor. 

Hemen ls komutunun tam dizin adresine bakalım. Bakın ls aracı tam olarak /usr/bin/ls dizini içindeymiş. hatta istersek which aracının dizinine de bakabiliriz. bakın which aracı da /usr/bin/which dizini içindeymiş. İşte bu şekilde path yolu üzerindeki araçların tam dizin adreslerini öğrenebilirsiniz. Bu komut özellikle bir aracın çalıştırılabilmesi için tam dizin adresinin girilmesi gereken durumlarda bize dizin bilgisini sunması bakımından önemli. Örneğin eğer hatırlıyorsanız, varsayılan kabuğumuzu bash olarak değiştirme işleminden bahsederken, bash kabuğunun dosya konumunu da which komutu sayesinde bulmuştuk. which komutu, özellikle bash kabuk programlamada sıklıkla kullanıldığı için, ileride karşılaşmanız ve ihtiyaç duymanız olası. Yani hemen şimdi aktif olarak kullanmayacak olsanız bile bu komutu gördüğünüzde hangi amaca hizmet ettiğini artık biliyorsunuz.

Ayrıca which komutu dışında, daha önce yardım alma konusunu işlerken manuel sayfalarını bulmak için kullandığımız whereis komutunu da tekrar hatırlatarak birkaç ek detaydan daha bahsetmek istiyorum.

# whereis Komutu

whereis komutu, araçların dosya konumlarını, kaynak dosyalarını ve manuel sayfalarının nerede olduğunun bilgisini sunuyor. Örnek olarak bash hakkında bilgi alabiliriz.

Bakın bash kabuk programının çalıştırabilir dosyası /usr/bin/bash dizini içindeymiş. Bash'in kaynak dosyası /etc/bash.bashrc dizinindeymiş ve manuel sayfası da bu dizin içindeymiş. /usr/share/man/man1/bash.1.gz 

Çıktılardan da görebildiğimiz gibi which komutu haricinde dilersek whereis komutu üzerinden de araçların çalıştırabilir dosyalarının konumları ve daha fazlası hakkında bilgi edinebiliyoruz. Zaten daha önce de ele almıştık ben yalnızca yeri gelmişken tekrar hatırlatmak istedim.

# type Komutu

type komutu, isminden de anlaşılabileceği gibi kabuğa girdiğimiz komutların tipiyle türleriyle ilgili bilgileri görüntülemek için kullandığımız bir araçtır. Diğer bir deyişle kabuğa verdiğiniz komutların kabuk tarafından nasıl algılandığını görmenizi sağlıyor. Bu komut özellikle sistemde yüklü bulunan araçların isimleri ile aynı isimde takma isimler yani aliaslar tanımlandığında, kabuğun bizim girdiğimiz komutu nasıl gördüğünü anlamak için kullanışlı bir bilgi edinme aracıdır.

Ben denemek için konsola type ls yazıyorum. Bakın kabuğa ls komutunu verdiğimde aslında kabuğun ls komutunu bir takma isim olarak kabul edip buradaki komutu çalıştırdığını öğrendik. Normalde standart ls aracı yani biz ls komutunu girdiğimizde çalıştırılan dosya /usr/bin/ls dosyası. Ama ls komutu ile aynı isimde yeni bir takma isim tanımlandığı için kabuk bizim girdiğimiz ls komutunu öncelikli olarak takma isim olarak dikkate alıyor ve buradaki takma isim tanımlamasından dolayı ls —color=auto komutunu çalıştırıyor.

Takma isimler dışında eğer kabuğun yerleşik bir komutunu girersek örneğin type cd şeklinde sorgulama yaparsak, gördüğünüz gibi bu komutun bir kabuk yerleşiği olduğu bilgisini aldık.

Ayrıca mesela type bash komutunu da girebiliriz. Bakın bu kez bash kabuğunun dosya konumunu aldık çünkü biz bash komutunu girdiğimizde mevcut kabuk bu dizindeki dosyayı çalıştırıyormuş. Bash kabuğu yerleşik bir araç olmadığı için veya bu isimde bir takma isim tanımlanmadığı için bu şekilde doğrudan çalıştırılan dosyanın konumu kabuk tarafından kullanılıyor.

Özetle bakın type komutu sayesinde bizim girdiğimiz komutlardaki araç isimlerinin kabuk tarafından nasıl algılandığını öğrenebiliyoruz. 

Peki bizim girdiğimiz komutların kabuk tarafından nasıl algılandığının neden bilmemiz gerekiyor ? 

Bu bilgi önemli çünkü, tıpkı ls komutunda olduğu gibi yerleşik ve path yolundaki harici komutlarla aynı isimde takma isimler tanımlı olabiliyor. Takma isimler yerleşik ve harici komutlardan daha öncelikli değerlendirildiği için de, girdiğimiz komutlar bizim normalde beklediğimizden daha farklı sonuçlar verebiliyor.

Örneğin ben alias ls="echo 'ben takma isimim!'" şeklinde yani var olan bir komutla aynı isimde bir takma isim tanımlarsam ne olur ? Hemen deneyelim. Ben ls isminde yeni bir takma isim tanımladım ve buradaki echo komutunu takma ismin çalıştıracağı komut olarak verdim. Şimdi konsolumuza yalnızca ls yazıp ne olacağına bir bakalım. Bakın ls komutunun neticesinde dizin içeriğini listelemek yerine "ben takma isimim" çıktısını aldık. Çünkü kabuğa girdiğimiz komutlarda ilk olarak eğer komutla eşleşen bir takma isim varsa kabuk bunu dikkate alıyor. Nitekim çıktıdan da bu durumu teyit ettik. İşte girdiğimiz komutun beklediğimizden farklı sonuçlar verdiği durumlarda type komutu ile kabuğun bakış açısından girdiğimiz komutu sorgulayabiliyoruz. Bu sayede girdiğimiz komutun neden beklenmedik şekilde çalıştığına dair çözüm için fikir sahibi olmamız mümkün oluyor. 

Örneğin benim ls takma ismi örneğinde komutumu command ls şeklinde girmem gerekiyor. Bakın bu şekilde girdiğimde, ls ifadesinin bir komut olduğunu belirtmiş oluyorum. Benim burada kullandığım command komutu sayesinde kabuk takma ismi görmezden gelip normla şekilde önce yerleşik komutlara daha sonra ls isminin geçtiği PATH yolundaki dizinlere bakıyor ve /usr/bin/ls dosyasını bulup çalıştırabiliyor. Yani buradaki command komutu ls komutunun doğrudan çalıştırılacak komut olarak kabul edilmesini sağlıyor.

Aynı durum yerleşik komutlar için de geçerli. Örneğin cd yerleşik komutu ile aynı isimde bir alias tanımlarsak cd komutunu kullandığımızda takma ismin karşılığındaki komut çalıştırılıyor olacak. Denemek için alias cd=”echo ben cd komutuyum” şeklinde yazıp onaylayalım. Tamamdır, şimdi de cd / komutu ile kök dizine geçiş yapmaya deneyelim. Bakın cd komutu asıl işlevi olan dizin geçişi işlemi yerine bizim tanımladığımız takma ismi kullanılıp konsol çıktı bastırılıyor. Hatta type cd komutu ile de teyit edebiliriz. Bakın cd komutu kabuk tarafından artık bir takma isim olarak algılanıyormuş.

Eğer biz bu takma isim yerine command cd  / veya builtin cd / şeklinde yazarsak, kabuk buradaki cd ifadesini ile tanımlı olan takma ismi görmezden gelip cd komutunun asıl işlevini yerine getiriyor olacak. Ben öncelikle command cd / şeklinde komutumu giriyorum. Bakın bu kez cd aracı yerleşik komutlar içinde bulunduğu için kök dizine sorunsuzca geçiş yaptık. Ayrıca girdiğimiz komutun bir yerleşik komut olduğunu özellikle belirtmek için builtin komutunu da kullanabiliyoruz.

Denemek için cd komutu yerleşik yani builtin bir komut olduğu için komutumuzu tekrar builtin cd / şeklinde girebiliriz. Bakın doğrudan kök dizine geçiş yapabildim çünkü buradaki builtin komutu sayesinde kabuk buradaki cd komutunu doğrudan bir yerleşik komut olarak ele aldı.

Fakat dikkat edin builtin komutu yalnızca yerleşik komutları niteliyorken, command komutu tüm komut türlerinde takma isimlerin görmezden gelinmesini sağlıyor.

Bu durumu test etmek için yerleşik komut olmayan ls komutunu builtin ls komutu ile doğrudan çalıştırmayı deneyebiliriz. Bakın ls in bash kabuğunun yerleşik aracı olmadığı konusunda hata çıktısı bastırıldı. 

Takma ismin görmezden gelinmesi için command ls şeklinde girebiliriz. Bakın bu kez ls aracı için takma isim görmezden gelinip bu isim doğrudan PATH yolundaki ilgili dosyayı çalıştırmış oldu.

Sanırım bu örneklerle birlikte, neden type komutunu kullanma ihtiyacı duyabileceğimiz ve kabuğun bizim girdiğimiz komutlara bakış açısı hakkında temel düzeyde de olsa fikir sahibi olabildik.

type komutu hakkında dikkat etmeniz gereken detay, type aracının bütüncül olarak girdiğiniz çok argümanlı komutları değerlendirmek için kullanılmadığı. Yalnızca çalıştırılacak olan araçları temsil eden komutların kabuk tarafından nasıl ele alındığını görmemizi sağlıyor.

Yani örneğin ls komutunun -l seçeneğiyle birlikte bu komutun tipini sorgulamaya çalışacak olursak, bakın ls in takma isim olduğu ama -l ifadesinin bulunamadığı belirtilmiş. Tırnak içinde yazmayı da deneyebiliriz. Ben komutumu tekrar çağırıp tırnak içine alıp onaylıyorum. Bakın bu kez de ls -l komutunun bulunamadığı hatasını aldık.

Yani bizzat buradaki örnekler üzerinden de teyit ettiğimiz gibi buradaki type aracı yalnızca ona verdiğimiz argümanlardaki araç isimlerin kabuk tarafından nasıl ele alınıp çalıştırılacağı konusunda bilgi sunuyor. Mesela type ls echo cd nano şeklinde birden fazla argüman verip, birden fazla aracı temsil eden komutların kabuk tarafından nasıl ele alındığını görebiliriz. Bakın bu komutlar kabuk tarafından çalıştırılırken buradaki özellikleri dahilinde ele alınıp çalıştırılıyorlarmış.

Anlatımları daha da netleştirmek adına kabuğun temelde ele aldığı ve type ile hakkında bilgi edinebileceği birkaç farklı türde komut yapısını da sıralamak istiyorum. Aslında burda bahsedeceğimiz detaylar daha çok bash kabuk programlama sırasında ihtiyaç duyacağınız bilgiler fakat etkileşimli kabuk kullanımında da işinize yarayabileceği için çok kısaca değinmek istiyorum. Bash kabuğuna göre bizim ona verdiğimiz komutlar bu listedeki türde komutlardan biri oluyor:

- alias yani takma isim türünde komutlar olabiliyor. Aliasların ne olduğunu biliyorsunuz, daha önce bahsettik. Örneğin yeni bir takma isim alias takma_isim="komut " şeklinde tanımlayabiliyoruz.
- function yani fonksiyon türünde komutlar olabiliyor. Fonksiyonlar kabuğun programlanabilir yapısının bir parçası. Tıpkı diğer programlanabilir dillerde olduğu gibi bash kabuğunda da fonksiyonlar tanımlayabiliyoruz. Dolayısıyla girdiğimiz bir komut kabuk için fonksiyon ismini temsil ediyor olabilir.
- builtin yani dahili-yerleşik komutlar. Yerleşik komutlar, kabukta dahili olarak bulunan araçları temsil ediyor. Örneğin cd echo pwd type gibi komutlar bash kabuğuyla birlikte gelen dahili komutlardır.
- çeşitli araçların disk üzerindeki dosyaları da diğer komut türlerine giriyor. PATH yolu üzerinde yer alan ve çalıştırılabilir dosyası bulunan tüm araçları kabuk üzerinden dosya ismi sayesinde çağırıp çalıştırabiliyoruz. Bu komutlara da harici komutlar denebiliyor.
- keyword yani kabuk tarafından rezerve edilmiş kelimeler. Rezerve edilmiş kelimeler de kabuğu programlarken kullanılan çeşitli kelimeler. Örneğin döngülerde kullandığımız for ifadesi rezerve edilmiş kelimedir. Biz kabuğa for ifadesini yazığımızda kabuk için bu ifadenin öncelikli anlamı döngü oluşturmaktır. Kabuk bu ifadenin ardından bizden bir döngü tanımlamamızı bekler.

Ve işte bash kabuğunda var olan komut tipleri bunlar.

Dediğim gibi kabuk programlama detaylarına değinmeyeceğiz ama yine de kısaca kabuğun bizim girdiğimiz komutları ne şekillerde görebildiğini bilmenizi istedim. Eğer kabuk programlamayla ilgiliyseniz zaten burada bahsi geçen tüm komut türlerini biliyorsunuzdur. Bilmiyorsanız da araştırıp kolayca öğrenebilirsiniz.

Ben şimdi son olarak, hazır tüm bunlardan bahsetmişken bir de kabuğun bu türlerdeki öncelik sıralamasının nasıl olduğundan da kısaca bahsetmek istiyorum. Aslında kabuğun hangi sıralama ile komutları çalıştırdığını doğrudan aklımızda tutamayabiliriz tutmamız şart değil fakat yine de sıralama hakkında genel bilgi sahibi olmamız; girdiğimiz komutların neden bizim beklediğimizden farklı sonuçlar verebileceği hakkında fikir sahibi olmamızı sağlayabilir. Bu sebeple çok kısaca bahsedelim. 

Normalde farklı türdeki bu yapılar için aynı isimlendirme yapılması genellikle kötü bir yaklaşımdır. Ancak yine de tıpkı bizim ls komutu için alias tanımlamamız gibi böyle durumlar ile kabuğun karşılaşması olası. 

Kabuğa bir komut girildiğine kabuk öncelikle bu isimde bir takma isim var diye kontrol eder eğer varsa onu çalıştırır. Yoksa bu isimde rezerve bir kelime var mı diye bakar ve bu doğrultuda komutu dikkate alır. Eğer rezerve kelime yoksa komut içinde slash yoksa yani dizin adresi belirtilmediyse bu isimde bir fonksiyon var mı diye bakar varsa çalıştırır. Fonksiyon yoksa bu isimde bir bash kabuk yerleşik aracı var mı diye bakar, varsa çalıştırır. Eğer eşleşen yerleşik bir komutta yoksa PATH yolundaki dizinlere sırasıyla bakıp bu isimde çalıştırılabilir bir dosya var mı diye bakar, varsa çalıştırır. Girilen komut PATH yolunda da bulunamadıysan, komutun bulunamadığına dair konsola hata çıktısı döndürülür. 

Daha önce de söylediğim gibi aslında bu kavramlar ve öncelik sıralaması aslında kabuk programlama yaparken ihtiyacımız olan bilgilerdir. Yine de bence etkili bir kabuk kullanımı için bu bilgileri az çok anımsamak faydalı olacaktır. Örneğin takma isimin önceliğe sahip olduğunu bildiğinizde takma isim tanımlamalarınızı da bu doğrulta başka komutlar ile çakışmayacak şekilde tanımlayamaya özen gösterebilirsiniz. Ya da girdiğiniz komutlar beklediğiniz şekilde çalışmadığında, bu sıralamayı ve type komutunun çıktısından öğrendiniz komut tipi bilgisini dikkate alarak sorununuzu çözebilirsiniz. Komut ismi ile aynı takma isimden dolayı sorun yaşıyor olabilir yani örneğin kabuğun rezerve veya yerleşik komutları ile aynı isimde tanımlamalar yaptığınız için sorun yaşıyor olabilirsiniz. 

En nihayetinde type komutunun bizlere kabuğun bakış açısından komutları görebilme imkanı tanıdığı gördük. Artık ihtiyacınız olduğunda komutların kabuktaki karşılığını nasıl öğrenebileceğinizi biliyorsunuz.

# file Komutu

`file` komutu bir dosyanın türünü hakkında bilgi almak için kullanabileceğimiz basit bir komuttur. Özellikle dosya uzantısı bulunmayan ve türünü bilmediğimiz dosyalar hakkında hızlıca bilgi edinmek için file komutunu kullanabiliyoruz. Daha önce arşiv dosyalarının türünden emin olmak için kullanmıştık hatırlıyorsanız. Tekrar hatırlayacak olursak örneğin file ~/.bashrc komutu ile .bashrc dosyasının aslında ASCII text dosyası olduğunu öğrenebiliyorum.

Başka bir örnek olarak arşiv dosyasını sorgulayabilirim. Bakın arşiv dosyasının, hangi tür arşiv olduğu hakkında bilgi alabildik. Benzer şekilde sıkıştırılmış arşiv dosyasını da kontrol edebiliriz. Normalde dosya uzantılarından zaten arşiv ve sıkıştırma biçimlerini anlayabiliyoruz ancak biz teyit edilebilir örnekler bu sıkıştırılmış dosyamızın biçimini de file komutu ile sorgulayalım.

Bakın dosya türü hakkında temel bilgiler konsola bastırıldı. file komutu özellikle uzantısı olmayan dosyaların türlerini anlamada bizlere oldukça yardımcı oluyor.

Son bir örnek olarak sistemde yüklü bulunan araçların dosyalarını da sorgulayabiliriz. Ben file /usr/bin/ls komutu ile ls aracının dosya türünü sorguluyorum. Gördüğünüz gibi tür olarak ELF basıldı.  Bu kısaltma Executable and Linkable Format ifadesinin kısalmasıdır. En genel hali ile yürütülebilir dosyaları temsil ediyor. İşte tıpkı sorguladıklarımız gibi, sistem üzerinde pek çok farklı türde dosya bulunuyor. file komutu sayesinde gerektiğinde dosyaların türleri hakkında bilgi edinebiliyoruz. Eğer aldığımız çıktının yani dosya türünün ne ifade ettiğini bilmiyorsak, kısa bir internet araştırması ile dosya türü hakkında bilgi edinmemiz de mümkün. Bu sayede zaman içinde sık karşılaştığınız temel dosya türlerini de kolayca tanıyabilirsiniz.

# stat Komutu

Sistem üzerindeki her bir dosya ve klasörün kendine ait "isim" "boyut" "dizin adresi" "erişim yetkileri" ve türü gibi pek çok öznitelik detayını temsil eden metaverileri bulunuyor. Stat komutu da dosya veya klasörlerin sahip olduğu öznitelikler yani metaveriler hakkında detaylı bilgi sunan bir komuttur. 

Herhangi bir dosyayı stat komutunun ardından girdiğimizde gördüğünüz gibi dosyanın detaylı bilgileri konsol basılıyor.

Dosyanın tam ismi, boyutu ve dosya tipi gibi detaylar burada gözüküyor. Örneğin bu dosya standart bir dosya olduğu için regular file şeklinde çıktı aldık. Daha önce ele aldığımız vi aracı kısayolla vim aracına bağlı olduğu için bu dosyanın özelliklerini de sorgulayabiliriz. Ben sorgulamak için stat $(which vi) şeklinde komutumu giriyorum. Bakın komut ikamesi içinde kullandığım which aracı vi aracının tam dizin adresini buldu, komut ikamesi de bu adresi stat komutuna argüman olarak iletti dolayısıyla vi aracının dosyası hakkında bilgileri elde edebildik. Komutumuzu stat /usr/bin/vi olarak da girebilirdik ama ben daha önceden öğrendiğimiz yapıları kullanmak istedim. Neticede bakın daha önce de bahsettiğim şekilde biz vi aracını kullanırken yani vi dosyasını çalıştırmak için komut girdiğimizde bu dosya bir kısayol işlevi görüp bizi vim editörüne yönlendirdiği için vi dosyasının türü de sembolik link olarak gözüküyor. Sembolik link kavramını şu an bilmiyorsunuz ancak ileride katı link kavramıyla birlikte ayrıca ele alacağız.

Bunun dışında ileride sembolik ve kati link bölümünde ele alacağımız inode ve links bilgisini de buradan görebiliyoruz. Şimdilik sizin için bir anlam ifade etmese de ileride buradaki bilgiler anlamlı gelecek. Dosyanın erişim izinlerini ve sahiplik bilgilerini de buradan görebiliyoruz. Burası dosyanın yetkilerini, sahibini ve grubunu bize bildiriyor. Bu kavramlardan da daha sonra bahsedeceğiz.

Ayrıca bakın burada dosyanın en son erişim, düzenleme ve değişim tarihleri detaylı şekilde basılmış. 

Erişim tarihi; dosyanın en son erişilen tarihi belirtiyor. Örneğin dosyanın okunması veya çalıştırılması gibi bir erişim.

Düzenleme tarihi; dosya içeriğinin en son ne zaman değiştirildiğini belirtiyor. 

Değişim tarihi; dosyanın meta verilerinin en son ne zaman değiştirildiğini belirtiyor. Örneğin dosyanın ismi değiştirildiyse bu tarih de değişecektir. 

Ayrıca bakın birth yani dosyanın ilk oluşturulduğu ile ilgili bir satır daha bulunuyor. Ancak gördüğünüz gibi boş. Genellikle bu bilgi dosya sistemi tarafından desteklenmediği için stat komutu ile herhangi bir ilk oluşturma tarihi basılmıyor. 

# vmstat

# Sistem Hakkında Genel Bilgi Edinme

# lsb_release

lsb_release komutu sayesinde mevcut dağıtım hakkında çeşitli bilgiler edinebiliyoruz. Komutumuzda yer alan lsb ifadesi Linux Standard Base ifadesinin kısalmasından geliyor. Linux Standard Base kısaca (LSB), Linux sistem yapısını standartlaştırmak için Linux Vakfı'nın organizasyon yapısı altında yürütülen bir projedir. LSB' projesinin en temel amacı, Linux dağıtımları arasındaki uyumluluğu sağlamak için bir dizi açık standart geliştirmek ve bunların kullanımını teşvik etmektir. İşte biz de lsb_release komutu ile mevcut dağıtımımızın bu standartlar dahilindeki bazı bilgilerine ulaşabiliyoruz. Yani aslında mevcut dağıtımınızın adı sürümü gibi detayları verir. Tüm bilgileri listelemek için lsb_release -a komutunu kullanabiliriz. Bakın çıktılarda, dağıtıcı kimliği, kullandığım dağıtım, sürümü, kodadı gibi detaylar bastırıldı. Bu bilgiler mevcut dağıtım hakkında standart düzende bilgiler sunuyor. Buradaki bilgiler sayesinde mevcut dağıtımın tam olarak hangi sürüm olduğunu anlayabiliyorum.

Buradaki lsb modülü bulunamadı hatasına takılmayın. Bu hata lsb_release aracının kurulu olduğu ama çekirdek modülünün kurulu olmadığını söylüyor. Şart değil ama dilerseniz lsb çekirdek modülünü nasıl kurabileceğinizi araştırıp kolayca kurulum yapabilirsiniz.

Ayrıca `lsb_release —help` komutu ile yardım bilgilerinde de görebileceğimiz gibi aslında yalnızca -a seçeneği yok. Çeşitli bilgileri ayrı ayrı bastırmamızı sağlayan farklı seçenekler de var. Eğer kabuk programlama sırasında bu bilgilere ayrı ayrı ihtiyacınız olan bir durumla karşılaşırsanız kullanabilirsiniz. Bunun dışında ben yalnızca gerektiğinde mevcut dağıtım bilgisini edinmek için `lsb_release -a` komutunu kullanıyorum.

# uname

uname komutu mevcut işletim sistemi ve donanımı hakkında temel bilgiler sağlayan komuttur. Tüm temel bilgilerin hepsini tek seferde öğrenmek için -a seçeneğiyle birlikte kullanabiliyoruz. Burada sırasıyla; çekirdek adını, hostname bilgisini yani mevcut, cihazımızın daağ üzerinden iletişim kurarken kullandığı adı, çekirdek sürümünü, çekirdek versiyonunu, makinenin donanım adını, işlemci mimarisini, donanım platformunu ve son olarak da işletim sisteminin adını yazıyor. 

İsterseniz tek seferde bastırdığımız tüm bu bilgileri tek tek de bastırabilirsiniz. Bunun için help komutu ile uname komutunun seçeneklerine göz atabiliriz. Örneğin bakın yalnıza çekirdeğin adını bastırmak istersem -s seçeneğini kullanmam yeterli. Bu şekilde mevcut sistem hakkında uname komutu üzerinden bilgi kolayca edinebiliyoruz.

# uptime Komutu

Adından da anlaşılabileceği gibi uptime komutu sistemin ne kadar süredir çalıştığı konusunda bilgi almamızı sağlayan bir komuttur. Tek başına seçenek belirtilmeden kullanıldığında geçerli saati, sistemin ne kadar süredir açık olduğunu, oturum açan kullanıcı sayısını ve son 1, 5 ve 15 dakika için sistem yük ortalamalarını veriyor.

Buradaki yük ortalaması, sistemin 1 5 ve 15 dakikalık son periyottaki meşguliyetini ifade ediyor. Bu çıktılarda sizin sisteminizde yakın zamandaki yani 15 den 1 e doğru bu miktarın arttığı görülüyorsa sistemin yükünün artmakta olduğunu düşünebilirsiniz. Şu anda benim sistemin yük altında olmadığı için yani çoğunlukla bekleme modunda olduğu için buradaki değerler sıfıra yakın gözüküyor. Örneğin yük durumunu denemek için echo {1..99999} şeklinde komutumuzu girip sistemi suni olarak biraz daha yük altında bırakabiliriz. Bu işlemden hemen sonra da uptime komutu ile sistemin son durumunu kontrol edebiliriz. Bakın yakın zaman aralığındaki yük durumu ve uzak zamanın ortalama yük durumunda değişiklik olduğunu buradaki çıktılarda da net biçimde görebiliyoruz. Bu çıktı bize, yakın zamanda sistemin daha fazla yük altına girdiğini haber veriyor. 

Burada dikkat etmeniz gereken detay Linux'ta yük ortalamaları yalnızca CPU'lara değil, disk kaynaklarına olan talebi de yansıtıyor olması. Yani disk üzerindeki okuma yazma da sistem yükü ortalamasını etkiliyor. Elbette bu konu çok daha detayı barındırıyor ancak temel seviye için bu detaylar gerekli değil. Yine de daha fazla detay için ders kaynaklarında da paylaştığım bu blog yazısını da okuyabilirsiniz. [https://www.brendangregg.com/blog/2017-08-08/linux-load-averages.html](https://www.brendangregg.com/blog/2017-08-08/linux-load-averages.html)

Temelde eğer sizdeki çıktılarda sistem yükü bende olduğu gibi düşük veya 0 olarak gözüküyorsa, bu durum sisteminizin bu kısa periyotta genellikle beklemede olduğunun bilgisini veriyordur. Eğer yakın zaman aralığında artış görülüyorsa da bu sisteminizin gittikçe daha fazla yük altında kaldığına işaret ediyordur. 

Eğer uptime komutundaki bu gibi detayları görmek istemezsek yani bu çıktı yerine yalnızca sistemin ne kadar süredir açık olduğunu daha okunaklı şekilde görmek istersek pretty ifadesinin kısalması olan p seçeneğini kullanabiliriz. 

Bakın yalnızca sistemin ne kadar süredir açık olduğunu daha güzel yani okunaklı şekilde bastırmış olduk.

Eğer tarih olarak sistemin ne zamandan beri açık olduğunu görmek istersek yani ilk açılış zamanı görmek istersek since ifadesinin kısaltması olan -s seçeneğini kullanabiliyoruz. 

Bakın sistemin ne zaman başlatıldığı tam tarih ve saat olarak bastırılmış oldu.

uptime komutu sistemin çalışma durumunu kontrol etmek için kullandığımız basit ama bilgi verici güzel bir araçtır. uptime hakkında bahsetmemiz gereken ekstra bir detay da bulunmuyor. Zaten yalnızca -p ve -s olmak üzere iki işlevsel seçeneği var. Unutmanız halinde yardım sayfasından seçeneklerin işlevlerini saniyeler içinde tekrar hatırlayabilirsiniz. Önemli olan uptime yani çalışma süresi komutunu biliyor olmanız. Zaten ismi de tam olarak işlevini tanımladığı için kolay kolay da unutmazsınız.

# free Komutu

`free` komutu fiziksel ve takas yani swap belleğinin toplam miktarı ile birlikte boş ve kullanılan bellek hakkında bilgi sunuyor. Herhangi bir seçenek olmadan kullanıldığında, mevcut bellek ve takas ile ilgili bilgileri kilobayt olarak konsola bastırıyor.

Bakın sütunlar halinde pek çok detay bastırıldı. Zaten sütun başlıkların buradaki miktarların tam olarak neyi temsil ettiği de açıkça belirtiliyor. Eğer kilobayt yerine daha okunaklı şekilde çıktıları bastırmak istersek human readable dan gelen h seçeneğini kullanabiliriz. Bakın tüm çıktılar çok daha okunaklı şekilde bastırılmış oldu. free komutu sayesinde toplam bellek ve takas alanı hakkında ve ayrıca anlık olarak kullanılan ve boştaki bellek miktarları hakkında kolayca bilgi alabiliyoruz. 

Eğer tek seferliğine değil de belirli bir aralık belirterek kullanılan bellek miktarını görmek istersek -s seçeneği ile kaç saniyede bir bu değerlerin bastırılacağını da özel olarak belirtebiliriz. Ben denemek için free -s 3 komutu ile 3 saniyelik aralık belirtiyorum.

Bakın 3 saniyede bir en son bellek miktarı bastırılıyor. Biz ctrl + C ile durdurana kadar 3 saniyede bir bu çıktılar basılmaya devam edecek. Eğer istersek basılma sayısını da tam olarak belirtebiliriz. Yani biz durdurana kadar değil bizim önceden belirttiğimiz sayı kadar çıktı basılır. Bunun için count yani sayma anlamındaki ifadenin kısaltması olan c seçeneği kullanabiliriz. Ben `free -s 3 -c 4` komutu ile 3 saniye aralıkla 4 kez çıktıların bastırılmasını istiyorum.

Bakın 3 saniye aralıkla yalnızca 4 kez bellek kullanımı hakkındaki son durum bastırılmış oldu.

Bu seçenekler dışında free komutunun yardım sayfasında yer alan seçenekler de zaten standart kullanımdaki çıktıları sınırlamak veya genişletmek için kullanılan özelliklerdir. Dilerseniz buradaki seçenekler ile çıktıları istediğiniz formda bastırabilirsiniz. 

# du Komutu

du komutu "disk usage" yani "Disk kullanımı" ifadesinin kısaltmasından geliyor. Dosyalar veya dizinler tarafından kullanılan tahmini disk alanı miktarını bildirir. Büyük miktarda disk alanı kaplayan dosya ve dizinleri bulmak için kullandığımız pratik bir komuttur.

du komutu herhangi bir seçenek veya argüman olmadan çalıştırıldığında, mevcut dizindeki ve alt dizinlerdeki tüm dosya ve klasörlerin disk kullanımını bayt cinsinden konsola bastırıyor. Bakın çıktılarda yalnızca klasörler basıldı ve en altta toplam disk boyutu bastırıldı. Bu çıktılar uzun olduğu için size karmaşık gelebilir. Daha yalın bir çıktılar üzerinden konuşsak daha iyi olacak.

Örneğin tek bir dosyanın disk üzerindeki boyutunu öğrenmek için du dosya_adı şeklinde komutumuzu kullanabiliriz. Bakın dosyanın kaç kilobayt disk alanı kapladığı bastırıldı. Dilersek birden fazla dosyanın boyutuna da kolayca bakabiliriz. Hatta -h seçeneğini eklersek büyüklüklerin gösterimi bakımından daha okunaklı çıktılar da elde edebiliriz. Bakın dosyanın tam dizin adresini belirttiğimiz sürece sorunsuzca istediğimiz dosyaların boyutlarını öğrenebiliyoruz. Dosya üzerinde kullanımı gayet basit ve yalın. Birde klasörler üzerinde gözlemleyelim. Ben gözlemleyebilmek için içerisinde dosyalar ve iç içe klasörler barındıran /home klasörünün disk üzerinde kapladığı alanı `du` /home komutu ile sorguluyorum.

Şimdi çıktılara bakalım. Bakın en altta klasörün içindeki tüm dosya ve klasörlerle birlikte diskte kapladığı toplam disk alanı basılmış. Sonda başa doğru da alt klasörlerin disk üzerindeki boyutları yer alıyor. Her dizin yalnızca kendi içindeki dosya ve klasörlerin toplam boyutunu veriyor, bu şekilde içe içe olan tüm dizinlerin boyut bilgisi sırasıyla bastırılmış oluyor. Gördüğünüz gibi du komutu sayesinde bir klasör içinde tüm dizinlerin disk üzerinde toplam kapladıkları alan hakkında kolayca bilgi alabildik. Fakat dikkatinizi çektiyse dosyaların diskte kapladığı alan toplam alana ekleniyor olsa da dosyalar bastırılmadı. Eğer klasörler ile birlikte dosyaların da bastırılmasını istersek -a seçeneği ile tüm içeriğin bastırılmasını söyleyebiliriz. Bakın klasörün içindeki tüm dosya ve dizinlerin disk üzerinde kapladıkları alanın bilgisini kolayca bu çıktıdan öğrenebiliyoruz.

Hepsini bastırmak dışında ayrıca dilersek yalnızca belirttiğimiz klasörün boyutunu öğrenmek için -s seçeneğini kullanabiliriz. Ben yine /home klasörü üzerinde deniyorum. Bakın yalnızca bu klasörün toplam boyutunu bastırdım.

Eğer dilersek birden fazla klasörün toplam kapladıkları disk alanını da öğrenebiliriz. Birbirinden bağımsız birden fazla klasör veya dosyanın toplam boyutunu öğrenmek için -c seçeneğini kullanmamız gerekiyor. Normalde du komutu tek bir klasör altındaki tüm içeriği tarayıp bu klasörün toplam boyutunu sunduğu için, birbirinden bağımsız klasörlerin toplam boyutunu öğrenmek için “c” seçeneğini kullanmamız gerekiyor. Ben denemek için ev dizinimde bulunan D harfi ile başlayan dosya ve klasörlerin toplam kapadıkları disk alanını öğrenmek üzere du -shc ~/D* şeklinde komutumu giriyorum.  Bakın büyük D ile başlayanların toplam boyutu en altta yazıyor. Benzer şekilde çok farklı dizinlerde bulunan dosya veya klasörleri de kullanabiliriz. Örneğin ben /etc/ dizini ile /home/ dizini altındakilerin toplam boyutunu okunaklı şekilde öğrenmek üzere sudo du -shc /etc /home/ şeklinde komutumu giriyorum.

Bakın toplam boyutu yine görebiliyoruz. Neticede dosyalar ve klasörlerin disk üzerinde kapladıkları alan bilgisini öğrenmek için du komutunu çok kolay şekilde kullanabiliyoruz. Eğer du komutunun yardım sayfasına bakacak olursak daha fazla kullanım seçeneği olduğunu da görebiliyoruz. Ancak benim ele aldıklarım dışındaki diğer seçenekler pek sık tercih edilmediği için ben onlardan bahsetmeyeceğim. Dilerseniz zaten temelde nasıl çalıştığını bildiğiniz için buradaki ek seçenekleri keşfedebilirsiniz. Yardım sayfaları hep bir komut uzağınızda.

Bilgi alma bölümünü sonlandırmadan çekirdek modülünden de bahsetmek istiyorum. 

Çekirdeğin, yazılımlar ile donanımların haberleşmesini sağlayan yani işletim sistemi kaynaklarımızın yönetimi ve denetiminden sorumlu yapı olduğunu biliyoruz. Çekirdeğin, donanımlar ile haberleşmesi için de çeşitli çekirdek modülleri bulunuyor. Yani Linux çekirdeği modüler bir tasarıma sahip. Çekirdek modüllerini biz daha çok sürücü yani driver olarak biliyoruz. Bu sürücüler çekirdeğin işlevselliğini genişleten kod parçaları aslında. Bazı modüller çekirdekte yerleşik olarak bulunurken, bazıları da ihtiyaçlar doğrultusunda derlenip yüklenebiliyor. Örneğin kişisel bilgisayarınızda Linux için wifi sürücüsü sunulduysa, bu sürücüyü mevcut çekirdeğinize yükleyip wifi kartınızı sorunzuca kullanabilirsiniz. Hatta Linux çekirdeğine sistemi yeniden başlatmadan modül eklememiz bile mümkün oluyor. Ben yalnızca bilgi alma komutlarından bahsettiğim için çekirdek modüllerinin detaylarına değinmeyeceğim. Zaten temel seviye için çekirdek modülleri ile haşır neşir olmanız da gerekmiyor.

# lsmod

Çekirdeğimizde yüklü bulunan modülleri listelemek için lsmod komutunu kullanabiliyoruz. Bakın çeşitli çekirdek modülleri listelendi. 

İlk sütunda modülün ismi, ikinci sütunda modülün boyutu, son sütunda ise bu modülün kullanım sayısı ile ilgili modülleri veriyor. Biliyorum çekirdek modüllerini çok kısaca geçiyoruz ama temel eğitim için bu konulara girmek istemiyorum. Şimdilik yalnızca modül yapısından haberimiz olması temel eğitime devam etmemiz için yeterli. Merak eden arkadaşlar ileri araştırmalar yapıp hatta bizzat yeni sürücü kurulumlarını deneyip, modül yapısı hakkında daha fazla bilgi sahibi olabilirler.

Ben son olarak sistemimize bağlı bulunan bazı aygıtları listelememizi sağlayan birkaç bilgi alma komutundan da bahsedip bu bölümü sonlandırmak istiyorum.

# lsusb & lspci & lshw

Sistemimize bağlı bulunan aygıtları listelemek istersek, lsusb komutun kullanabiliyoruz. Zaten komutun ismi komutun işlevini gayet iyi biçimde açıklıyor.

Örneğin bakın benim sisteminde şu anda bu aygıtlar usb ile bağlı gözüküyor. Örneğin usb üzerinden harici bir wifi kartı taktığınızda aygıt hakkında buradan bilgi alabilirsiniz. Aygıtınız tanınmıyorsa buradaki ID üzerinden internette araştırma yaparak uygun aygıt sürücüsü olup olmadığını sorgulayabilirsiniz. 

Benzer şekilde pci veriyolu üzerinden sistemimize bağlı aygıtları görüntülemek için de lspci komutunu kullanabiliyoruz. Bakın lsusb komutuna benzer şekilde bu kez pci bağlantısı olan aygıtlar listelenmiş oldu.

Eğer sisteme bağlı bulunan bütün aygıtları listelemek istersek de lshw komutunu kullanabiliyoruz. Buradaki hw ifadesi hardware yani “donanım” ifadesinin kısaltmasından geliyor. Komutumuzu girip sonuçlar üzerine tekrar konuşalım.

Bakın farklı kategoriler altında bilgisayarımıza bağlı bulunan tüm aygıtlar hakkında bilgi alabiliyoruz. Komut satırı üzerinden mevcut sistemin aygıtları hakkında bilgi almak için bu bahsetmiş olduğumuz komutlar çoğu durumda yeterli oluyor. 

Ben özellikler değinmeyeceğim ama hem bu bahsetmiş olduğumuz komutların ek seçenekleri hem de daha bir çok aygıt hakkında bilgi sunan ek komutlar bulunuyor. Merak ediyorsanız biraz araştırma ile diğer komutları ve seçeneklere kolayca ulaşabilirsiniz. Örneğin bizim bahsetmiş olduğumuz komutların yardım sayfalarına bakarak diğer seçenekler hakkında bilgi sahibi olup, sonuçlarını bizzat test ederek gözlemleyebilirsiniz. 

Bilgi alma komutları olduğu için çok fazla üzerine düşüp uzun açıklamalar yapmak istemedim çünkü pek çok farklı türde bilgi sunan komutları ele aldığımız için detaylıca bahsetmeye kalkarsak bu bölüm çok uzun sürecekti. Ben sadece en temel bilgi alma komutlarının en temel işlevlerini odaklandım. Bu sayede daha fazlası için gerektiğinde yardım sayfaları ve internet araştırması ile tüm sorularınıza yanıt bulabilirsiniz. 

# Sorular

1- Haftanın gün isimleriyle birlikte takvim bilgisi almak için hangi komutu kullanabiliriz?

- date
- ndate
- cal
- ncal - D

2- Mevcut tarihi ve saati öğrenmek için hangi komutu kullanabiliriz ?

- cal
- time
- date
- ctime

3- which komutunun işlevi nedir ?

- komutun türü hakkında bilgi vermek
- dosya ve klasörlerin özniteliklerini bastırmak
- hangi dizinde olduğumuzu söylemek
- argüman olarak verilen komutun dosya konumunu belirtmek

4- Dosyaların tipi hakkında bilgi almak için hangi komutu kullanabiliriz ?

- type
- which
- what
- file

5- Komutların türleri hakkında bilgi almak için hangi komutu kullanabiliriz ?

- type
- which
- what
- file

6- Dosya ve dizinlerin öznitelikleri(metaverileri) hakkında bilgi almak için hangi komutu kullanabiliriz ?

- free
- what
- stat
- file

7- Bellek kullanımı hakkında bilgi almak için hangi komutu kullanabiliriz ?

- free
- what
- stat
- file

8- lsb_release -a komutu hangi çıktıyı verir ?

- sistemin çalışma süresini
- sistemin donanım bilgisini
- sistemin sürümü gibi standart bazı bilgileri

9- hostname, çekirdek sürümü, donanım mimarisi gibi bilgileri öğrenmek için hangi komutu kullanabiliriz ?

- lsb_release -a
- what -a
- vmstat -a
- uname -a

10- Sistemin ne kadar süredir açık olduğunu öğrenmek için hangi komutu kullanabiliriz ?

- uptime
- uname
- when
- while

11- Kendi ev dizinimizdeki tüm alt dizinler de dahil dosya ve klasörlerin toplam boyutunu öğrenmek için hangi komutu kullanabiliriz ?

- ls -la ~
- total -a ~
- du ~
- count ~

12- lsusb komutunun işlevi nedir ?

- sisteme bağlı bulunan tüm aygıtları listelemek
- sisteme bağlı bulunan tüm tanımlanamayan aygıtları listelemek
- sisteme bağlı bulunan usb aygıtlarını listelemek
- sistemdeki tüm bozuk aygıt dosyalarını listelemek

13- du aracıyla büyüklük birimi bakımından daha okunaklı çıktılar almak için hangi seçeneği kullanmamız gerekir ?

- -a
- -s
- -S
- -h human readable ifadesinden gelen h seçeneği sayesinde daha okunaklı büyüklük birimleri ile çıktıları görüntüleyebiliyoruz.

14- du aracıyla tüm dosya ve dizinlerin isimlerini listelemek için hangi seçeneği kullanabiliriz ?

- -a  Eğer a seçeneğini kullanmazsak, dosyaların isimleri çıktılarda gözükmüyor.
- -s
- -S
- -h

15- Dosya ve dizin isimleri yerine yalnızca toplam boyut miktarını öğrenmek yani özet bilgi almak için du aracının hangi seçeneğini kullanabiliriz ?

- -S
- -s
- -h
- -k