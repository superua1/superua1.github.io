# 14- Kullanıcı ve Grup Yönetimi

[https://infosecwriteups.com/creating-a-backdoor-in-pam-in-5-line-of-code-e23e99579cd9](https://infosecwriteups.com/creating-a-backdoor-in-pam-in-5-line-of-code-e23e99579cd9)

Güvenlik için neden `su -` kullanılmalı : [https://unix.stackexchange.com/a/7021/364572](https://unix.stackexchange.com/a/7021/364572)

Erişim hakkında

acl adlı bir sistem varmış, primitif izinlerden biraz daha üstün gözüküyor

mesela (bu thread'den aldım: [https://askubuntu.com/questions/609194/how-do-i-prevent-one-user-in-particular-from-accessing-my-home-directory](https://askubuntu.com/questions/609194/how-do-i-prevent-one-user-in-particular-from-accessing-my-home-directory)); 

`setfacl -Rm u:enemyuser:000 /`

Gruplara şifre koymaktan bahset: Gruplara neden şifre koymamız gerekir ki ?

```bash
sudo gpasswd grup-adı
```

real user id ve effective user id kavramlarından da bahset: [https://stackoverflow.com/questions/32455684/difference-between-real-user-id-effective-user-id-and-saved-user-id#:~:text=So%2C the real user id,%2C there are some exceptions](https://stackoverflow.com/questions/32455684/difference-between-real-user-id-effective-user-id-and-saved-user-id#:~:text=So%2C%20the%20real%20user%20id,%2C%20there%20are%20some%20exceptions)).

[https://linuxhint.com/difference-between-real-effective-user-id-in-linux-os/](https://linuxhint.com/difference-between-real-effective-user-id-in-linux-os/)

[https://developer.ibm.com/tutorials/l-lpic1-107-1/](https://developer.ibm.com/tutorials/l-lpic1-107-1/)

[https://www.tecmint.com/manage-users-and-groups-in-linux/](https://www.tecmint.com/manage-users-and-groups-in-linux/)

PROMTAKİ $ İŞARETİ STANDART KULLANICIYI # İŞARETİ DE ROOT KULLANICISINI TEMSİL EDER BU DETAYDAN DA BAHSET

sudo !! ifadesine de anlatım sırasında dikkat çek

şifre politikası

[https://www.youtube.com/watch?v=LKPjVLAhMTM&list=PLeKWVPCoT9e1tqsgPTQabtumX6E1XpAhz&index=36](https://www.youtube.com/watch?v=LKPjVLAhMTM&list=PLeKWVPCoT9e1tqsgPTQabtumX6E1XpAhz&index=36)

Kullanıcının birincil gurubu kullanıcı varken silemezsiniz. Çünkü ilgili kullanıcının yetkileri bu grup üzerinden tanımlanıyor. Eğer kullanıcının birincil grubunu silmek istiyorsanız o kullanıcıyı başka bir birincil guruba eklemeniz gerekiyor. Örneğin taylan kullanıcısının varsayılan birincil kullanıcısı taylan dır. bu gurubu silmek için taylan kullanıcısını başka bir gruba taşıyıp daha sonra bu grubu silmeniz gerekir.

# Dosyaların Öznitelikleri | Attributes

Dosya taşıma veya kopyalamayla ilgili olan izinlerden bahset. Örneğin farklı bir kullanıcı dosyayı kopyalabiliyorken dosyayı taşıyamıyor.

Hazır kopyalama, taşıma ve silme gibi işlevleri ele almışken, bu işlemler sonrasında değişime uğrayabilen dosya ve dizinlerin özniteliklerinden de bahsetmek istiyorum.

[https://linuxize.com/post/chattr-command-in-linux/](https://linuxize.com/post/chattr-command-in-linux/)

lsattr ve chattr komutları aslında attributes yani özellikleri temsil ediyor. lsattr detaylıca dosya veya dizinlerin atturebeslerini yani özelliklerini gösteriyor. chattr ise özelliklerin değiştirilmesini sağlıyor.

i seçeneği immulatble yani değişmez anlamına geliyor.

Ayrıca kopyaladığımız dosyaların yani kopya dosyaların, kopyalama işlemini yapan yani kopyalama komutunu giren kişinin sahipliğinde oluşturulduğuna da dikkat etmeniz gerekiyor. Sistem üzerde dosya ve dizinlere erişim yetkilerinin yönetilebilmesi için her dosya ve dizinin sahibi oluyor. İleride bu konunun detaylarından bahsediyor olacağız. Şimdi kısaca bilmeniz gereken tek detay, oluşturulan kopyanın, kopyalama komutu giren kullanıcıya ait olarak oluşturulduğudur. Eğer bu durum yerine orijinal dosyanın sahiplik yetkilerinin de 

[https://linuxize.com/post/cp-command-in-linux/](https://linuxize.com/post/cp-command-in-linux/)

# chattr

attrubutes özellikler anlamına geliyor. Dosyaların özniteliklerini değiştirmek için de change attributes ifadesinin kısalmasından gelen chattr komutunu kullanabiliyoruz.

Linux'taki chattr komutu, bir dizindeki bir dosyanın özniteliklerini değiştirmek için kullanılan bir dosya sistemi komutudur. Linux'ta dosya öznitelikleri, dosyanın davranışını tanımlayan meta-veri özellikleridir. Zaten bu pek çok dile getirdik. Dilersek dosyaların özniteliklerinden bazılarını istediğimiz şekilde değiştirebiliriz. chattr komutu da change attributes yani öznitelikleri değiştirmenin kısaltmasıdır. 

Eğer yazma korumalı dosyaları silmeniz gerekiyorsa ve yetkiniz varsa, rm komutunun f seçeneğini kullanabilirsiniz. Buradaki f seçeneği ingilzice force yani zorlama ifadesinin kısaltmasından geliyor. Toplu şekilde dosya ve klasörleri silerken her seferinde size bu dosyaların silinip silinmeyeceğinin size sorulmasını istemezseniz, f seçeneğini kullanabilirisniz. Yani örneğin içerisinde yazma korumalı dosyalar da bulunan dizini silmek için rm -rf komutunu kullanabilirsiniz. Ancak bu komutun çok tehlikeli olabileceğini lütfen unutmayın. Bir dosya yazma korumalı ise, içeriğinin korunmasını gerekecek haklı nedenler vardır. Emin olmadığınız dosyaları zorlama ile kardırmanız, telafisi olamayan veri kayıplarına neden olabilir. Yine de ihtiyaç duymanız halinde dosya ve dizinleri silmek için hangi komutları kullanmanız gerektiğini artık biliyorsunuz.  

[https://linuxize.com/post/chattr-command-in-linux/](https://linuxize.com/post/chattr-command-in-linux/)

## **chattr**

Hepimizin başına mutlaka gelen ve çok can sıkıcı bir durum var. Bu durum yanlışlıkla silinen dosyalar. Her nasıl ve neden olursa olsun eğer önemli gördüğümüz dosyalar varsa bir şekilde silinmeden onları koruma altına almamız mümkün. Bizlere bu koruma imkanını veren komut `chattr` komutudur. Aslında `chattr` komutu bir tek silinmeye karşı korumuyor, genel olarak dosyanın değiştirilmesine(silme, değiştirme vs.) engel olmak amacıyla kullanılıyor. Yani bu komutumuz bir nevi ilgili dosyayı dokunulamaz kılıyor. Öyle ki herhangi bir yanlış durumda dosyanın kaybolmasına engel olmak adına **root kullanıcısının bile** değişiklik yapmasına imkan tanımıyor. Komutun kullanım alanına bir örnek daha vererek daha iyi anlamış olalım. Örneğin sistemde bir konfigürasyon dosyasını düzenlediniz ve sistemi yeniden başlattınız, fakat bir bakıyorsunuz ki düzenlediğiniz(değiştirdiğiniz) ayarlar kaybolmuş ve dosya eski haline dönmüş. İşte bu gibi durumlarda sistemin bile ilgili dosyaya müdahale etmesini engellemek için oldukça kullanışlı olan `chattr` komutunu kullanabiliyoruz.

Komutun kullanımı `chattr +i dosya_adı` şeklindedir. Hemen bir örnek yapalım.

Bu tür dosyaları listelemek için `lsattr` komutu kullanılıyor. Bizde dosyaların durumunu daha sonradan karşılaştırabilmek adına ilk olarak konsola `lsattr` komutunu verdik.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/13.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/13.png)

test.txt isimli dosyamızı `chattr +i test.txt` komutu ile koruma altına aldık.

Daha sonra bunu teyit etmek için `lsattr` komutunu kullandık.

Komutumuzun çıktısında görüldüğü gibi dosyamızın sol tarafında izinler kısmında `-i` şeklinde bir ifade var. İşte bu ifade dosyamızın artık düzenlenemeyecek olduğunun işaretidir. Dosyayı silmeye çalışarak bu durumu teyit ettik.

Eğer bu işlemi geri almak ve dosyamızı üzerinde değişiklikler yapılabilir hale getirmek istersek `chattr -i test.txt` komutumuzu kullanmamız yeterli olacaktır. Örneği aşağıda inceleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/14.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/14.png)

Çıktıda da görüldüğü gibi hedef dosyamızın solundaki `-i` işareti yok olmuş. Dolayısıyla test.txt isimli dosyamızın artık eski halinde dönerek, düzenlenebilir forma girmiş olduğunu gördük. Ve dosyamızı silerek bu durumu teyit ettik.

Linuxta her şey bir dosya olarak ele alınır demiştik. Daha önceki örneklerimizden de bu durumu gözlemlemiştik. Şimdi dikkat çekici bir örnek olması için konsol araçlarımızdan birine girilen verileri başka bir konsol aracı üzerinden okumayı deneyebiliriz.

Not: tty komutu ile mevcut kabuğun hangi sanal konsol üzerinden çalıştığını görebiliyoruz. Bu daha kolay anlaşılır bir örnek.

Denemek için mevcut konsolda çalışmakta olan bash işleminin işlem numarasını öğrenelim. Bu işlem numarası üzerinde /proc/işlem numarası/fd klasörünün içeirğini ls -la komutu ile listelediğimizde kabuğun buradaki konsoldan standart girdi alıp standart çıktılarını da yine bu konsola aktardığını görebiliyoruz. Bu konsolun dosya karşılığı sistem üzerinde budur. Yeni bir konsol açıp bu dosyayı basitçe yani cat dosya adı komutu ile okumayı deniyorum. Şu anda çıktı boş. Eğer içeriğini okuduğum konsola veri girmeye başlarsam, gördüğünüz gibi konsol dosyasını okuyan cat komutunda girdiğim veriler gözüküyor. Kısacası sistem üzerinde konsol aracı da alsında bir dosya olarak tanındığı için, tıpkı diğer dosyaları okur gibi cat komuut ile konsol aracını da okuyabiliyorum. Bu durumda sürekli tekrar ettiğimiz her şeyin bir dosya olarak görülüyor olmasına dikkat çekici bir örnek. Her şeyi bir dosya gibi ele alabildiğimzide yani aslında her şey bir bayt akışı olduğunda, bayt akışını kontrol edebilemek ve gerektiğinide istediğimiz gibi düzenleyebilmek sistemi yönetmek demek oluyor. İşte dosyalar üzerinde yönetim, ve düzenlemeye yapabilmemizi sağlayan araçlar ve bu araçların birbiri ile bağlantılı şekilde kullanılabilmesi bu sebeple çok önemli. 

# Kullanıcılar

[https://www.linuxfordevices.com/tutorials/linux-user-administration](https://www.linuxfordevices.com/tutorials/linux-user-administration)

Sistem kaynaklarına erişimi olan ve sistemini yetkileri dahilinde yönetenlere kullanıcı deniyor. Linux'ta "süper", "sistem" ve "normal" olmak üzere üç tür kullanıcı vardır. Şimdi sırasıyla bu kullanıcıları açıklayacak olursak.;

Süper Kullanıcı: Daha çok root yani kök kullanıcı olarak bilinir. Sistem üzerinde tüm haklara sahip olan Linux sisteminin yöneticisidir. root hesabı süper kullanıcıya aittir. root kullanıcının herhangi bir komutu çalıştırmak için izne ihtiyacı yoktur, çünkü en yetkili kullanıcıdır.

Sistem Kullanıcısı: Yazılım veya uygulamalar tarafından oluşturulan kullanıcılardır. Örneğin saati senkronize etmeyi sağlayan ntp aracı da bir kullanıcı hesabına sahiptir. Bu kullanıcı hesabı üzerinden görevlerini yerine getirir. İşte bu ve bunun gibi sistemdeki çeşitli yazılımların, işlerini görmek için kendi kullanıcı hesapları vardır. Bu hesaplar insanların değil yazılımların sistemi yönetmek için kullandığı türden hesaplardır. 

Normal Kullanıcı: Kök kullanıcısının oluşturduğu standart kullanıcı hesaplarıdır. İnsanların sistemi kullanması ve yönetmesi için oluşturulan hesaplardır. BU tür hesapları insanlar kullanacağı için normal kullanıcılar kendi ev dizinlere sahiptir ve yetkileri dahilinde sistemdeki araçları kullanabilirler. Yetkileri düşük veya yüksek olmasına göre sistem üzerinde yetkileri dahlinde hareket edebilirler. 

# Sudo Komutunu Anlamak

Sistemde en yetkili kullanıcının root olduğunu öğrendik. Sistemi yönetirken de yetki gerektiren işlemler yapmamız gerebilir. Bu durumda görevi yerine getirmek için root hesabına geçiş yapabiliriz. Ancak root hesabındayken, tüm yetkilere sahip olacağınız için, hatalı şekilde kritik dosyaları silmenizi önleyecek veya sistemin işleyişine zarar verecek bir eyleminizde sizi uyaracak hiç bir mekanizma yoktur. Çünkü root hesabını yalnızca gerektiğinde kullandığınız ve ne yaptığınızı bildiğiniz varsayılır. root hesabını kullanmak tehlikeli olabileceği için çoğu sistemde root hesabı pasif şekilde gelir. Siz aktifleştirmediğiniz sürece root hesabı kullanılamaz. Buna karşın root hesabı aktif olmasa bile yetki gerektiren işlerimiz için geçici olarak root yetkileri ile hareket edebilmemizi sağlayan sudo komutunu kullanabiliriz. sudo sayesinde root hesabı aktif değilken veya root aktifse bile root hesabının şifresini bilmeden yönetici ayrıcalıkları ile işlerimizi yürütebiliriz. Elbette hangi kullanıcıların hangi ayrıcalıklara erişebileceğini belirlemek için yapmamız gereken konfigurasyonlar bulunuyor. Ancak şimdi bu detaylardan bahsetmeyeceğiz. 

Daha net anlaşılabilmesi için sudo komutuna birkaç kavramı açıkladıktan sonra tekrar değineceğiz. Şimdilik genel olarak bilmeniz gereken, sudo komutunun kullanıcıya yetkili şekilde sistemi yönetebilme imkanı tanıdığıdır. sudo komutunun ardından girdiğimiz komutlar yetkili şekilde çalıştırılır. Basit bir örnek olarak root kullanıcısının ev dizini görüntülemeyi deneyebiliriz. Ben görüntülemek için ls /root komutunu giriyorum. Bakın erişim hatası aldık. Şimdi aynı komutu sudo ile birlikte girelim. Buraya kendi hesabımın parolasını girmem gerekiyor. Güvenlik için parola yazarken gözükmüyor, gözükmese de yazmaya devam edin lütfen.

Parolamı doğru yazdığım için bakın yetkili şekilde /root dizinin içeriğini görüntüleyebildim. işte sudo komutunun en temel kullanımı bu şekilde. şimdilik bu kadarlık bilgi de yeterli.

# Kullanıcı Hesabı Oluşturmak

Yeni bir kullanıcı hesabı oluşturmak istiyorsak, yetkilerimizin olması gerekiyor. Ben daha önce yalnızca root hesabının yani en yetkili kullanıcının yeni hesap oluşturabileceğini söylemiştim. Bu durumun bir istisnası bulunuyor. Eğer normal bir kullanıcı root hesabının bulunduğu yetki grubuna dahil edildiyse bu kullanıcı root gibi davranarak yetki gerektiren işlemleri yapabilir. Bir işlemi yetkili şekilde yerine getirmek için de sudo komutunu kullanıyoruz. Zaten sudo komutuna da kısaca değindik. 

Yeni bir hesap oluşturmak için iki "adduser" ya da "useradd" komutlarından herhangi birini kullanabiliyoruz. adduser daha kullanışlı olduğu için benim öncelikli tercihim adduser aracıdır. Yine de ikisi ben ikisini de kısaca ele alacağım. Öncelikle adduser aracını kullanalım.

## adduser

Ben ece isminde yeni bir kullanıcı oluşturmak istiyorum. Bunun için sudo adduser ece şeklinde komutumu giriyorum. Eğer sudo komutunu kullanmazsak, yetkimiz olmadığı için işlem başarısız olur. Ben parolamı giriyorum.

Bakın belirttiğim isimde yani ece ismiyle kullanıcını eklendiği

Ece için yeni grup oluşturulduğu

Ece nin bu gruba eklendiği

Ecenin ev dizinin /home/ece dizininde oluşturulduğu 

Ve ev dizinine /etc/skel dizinindeki dosyaların kopyalandığı belirtilmiş. Bu /etc/skel klasörünün içinde standart kullanıcı hesabı için gereken temel dosyalar vardır. İngilizce skeleton yani iskelet ifadesinin kısaltmasıdır, ev dizinin temel iskeletini oluşturmaya atıfta bulunur. İstersek teyit etmek için ls -la /etc/skel komutu ile listeleyebiliriz. Buradaki dosyalar yeni oluşturulan kullanıcıların ev dizinine kopyalanan standart dosyalardır. Her neyse, şimdi bu kullanıcının parolasını tanımlamamız gerekiyor. Parolayı ikinci kez de yazıp onaylıyorum. Şimdi eğer istersem kullanıcıyla ilgili burada bana sorulacak olan ek kişisel bilgileri doldurabilirim. Pek gerekli değil o yüzden enter ile tüm soruları geçiyorum. Elbette siz dilerseniz doldurabilirsiniz. Son olarak bilgileri de onaylayıp işlemi tamamlıyorum. Böylelikle ece kullanıcı hesabı oluşturulmuş oldu. Ev dizinine bakarak ece kullanıcına ait dizin olduğunu teyit edebiliriz. Hatta dizin içindeki dosyaların skel dosyasından kopyalanan dosyalar olduğunu da görebiliyoruz.

Şimdi de useradd komutu ile başka bir kullanıcı daha oluşturalım.

## useradd

Kullanıcının ev dizinin de oluşturulması için özellikle komutumuzu useradd -m kullanıcı adı şeklinde girmemiz gerekiyor. Ben ali isimli bir kullanıcı hesabı oluşturmak istiyorum. Bunun için useradd -m ali şeklinde komutumu giriyorum. Bakın hiç bir çıktı almadık, bize ne şifre sordu ne de başka bir bilgi yalnızca kullanıcı sisteme eklendi. Eklendiğini de home dizinini listeleyerek teyit edebiliriz. Bu kullanıcının bir parolası olmadığı için elbette hesabında oturum açamaz. Bu kullanıcı hesabına parola tanımlamak için passwd komutunu kullanabiliriz. Ben sudo passwd ali şeklinde yazıyorum.

Parolayı iki kez yazıp onaylıyorum. Böylelikle ali kullanıcısı için de bir parola tanımlamış olduk. Sizlerin de fark etmiş olduğu gibi adduser komutu çok daha kullanıcı dostu bir kullanım imkanı sağlıyor. Bu sebeple de zaten sıklıkla kullanıcı oluşturmak için adduser aracı tercih edliyor.

İşte kullanıcı oluşturmanın en temel yolu budur. İleride birkaç farklı seçeneklerden daha bahsedeceğiz. Ancak şimdi kullanıcılarla ilişkili olan birkaç dosyadan bahsetmek istiyorum. Daha önce birkaç kez gördüğümüz /etc/passwd dosyasından bahsederek başlayabiliriz. Öncelikle dosyamızı açıp içerisine bir bakalım.

### /etc/passwd

Bakın dosyanın sonuna, yeni eklemiş olduğum iki kullanıcı hesabı için iki satır daha eklenmiş. Bu dosya, sistemdeki her bir kullanıcı hesabının soldan sağa sırasıyla; ismi, parolası, kullanıcı numarası, grup numarası, hesap bilgileri(hesap bilgilerinden kasıt, adduser komutun bize sorulan tam isim,telefon numarası, oda numarası gibi bilgilerdir), ev dizini ve varsayılan kabuk programını bilgisini satırlar halinde tutuyor. Biz adduser ya da useradd gibi araçları kullanarak kullanıcı oluşturduğumuzda aslında araçların yaptığı işlerden biri de bu dosyaya kullanıcının hesap detaylarını eklemektir.

Örenğin bakın adduser komutu ile oluşturduğumuz ece kullanıcısının kabuğu varsayılan olarak bash kabuğu olarak ayarlanmışken, useradd komutu sh kabuğunu varsayılan olarak tanımlamış. Ancak neticede her ikisi kullanıcının bilgisi de bu dosyaya uygun şekilde eklemiş. Listenin geri kalanına baktığımızda farklı araç ve yazılımların sistem kullanıcı hesaplarının ve bizim şu an kullanmakta olduğumuz hesabın da aynı şekilde bu listede olduğunu görebiliyoruz.

Bu dosya kullanıcıların hesap detaylarını barındırdığı için dosya içerisinde yaptığımız değişiklikle elbette ilgili hesapları de etkiler. Örneğin ben dilersem buradan ali kullanıcısının kabuğunu, bash aracının tam dosya adresini belirterek bash olarak değiştirilebilirim. Bunun için sudo nano /etc/passwd komutu ile yetkili şekilde passwd dosyasını açıyorum. Son satıra gelip, bash kabuğunun dosya adresini yazıyorum. Dosyamı kaydettiğimde ali kullanıcısının kabuğu da bash olarak değişmiş olacak. Hatırlarsanız biz eğitimin başında varsayılan kabuğunu bash olarak değiştirmek için de bu dosyada değişiklik yapmıştık. İşte linux ta her şey dosya yapısı üzerinden ele alındığı için sistem yönetimi ve düzenlemesi de dosyalar üzerinden kolayca yapılabilir. Pek çok araç yani pek çok komutta aslında bu ve bunun gibi dosyalarda kısayoldan değişiklik yapmamızı sağlıyor. Biz hangi dosyanın hangi işlevde olduğunu biliyorsak, istersek manuel olarak elle dosyayı düzenleriz istersek de aynı işi yapan bir aracı yani komutu kullanırız. Bu dosya üzerinden açıkladığımız gibi sistemdeki dosyaların işlevlerini bildiğimiz zaman denetim ve yönetim noktasında pek çok avantaja sahip oluyoruz.

Yani aslında ben adduser ya da useradd komutlarını kullanmadan bu dosyaya uygun şekilde yazarak yeni bir kullanıcı hesabı da oluşturabilirim. Çünkü bu dosya kullanıcıların bilgilerinin tutulduğu konfigürasyon dosyasıdır. Kullanıcılarla ilgili detaylar gerektiğinde sistem bu dosyaya bakıyor. 

Ben bu durumu da kanıtlamak için manuel isimli bir kullanıcı eklemek istiyorum. Eklemek için şablon olarak kullanmak üzere bir önceki kullanıcıya ait olan satırı kopyalayıp dosyanın en alta satırına yapıştırıyorum. Kullanıcı adını manuel olarak değiştiriyorum. Önceki hesap ile kesişmemesi için elbette kullanıcı numarasını ve grup numarasını daha önce kullanılmamış bir numara olarak tanımlamam gerekiyor. Ben bir arttırıp yazıyorum. Ev dizinini istediğim herhangi bir klasör konumu olarak belirtebilirim ancak standardı bozmamak adına home dizini altında kullanıcı ismiyle belirtiyorum. Son olarak varsayılan kabuğunu da bash olarak ayarlıyorum. Dosyayı kaydettiğimde sistem benim eklemiş olduğum manuel kullanıcısını tanıyor olacak. Fakat yeni kullanıcıyı yalnızca bu dosyaya eklemem de yeterli değil, çünkü /etc/passwd dosyasında benim elle girdiğim grup şu an mevcut değil. Kullanıcı hesapları oluşturulurken kullanıcıların isimleri ile aynı olan bir de grup oluşturulur ve grup numarası olarak da boşta olan bir grup numarası kullanılır. Ben de /etc/passwd dosyasında belirtmiş olduğum grup numarasına uyan, manuel kullanıcı için bir grup eklemelim. Gruplar /etc/group dosyası içinde tutuluyor. sudo nano /etc/group komutu ile dosyayı düzenlemek üzere açalım. Dosyanın sonuna geldiğimizde daha önce oluşturulmuş olan ali ve ece kullanıcının kendi isimlerindeki gruplarını ve numaralarını görebiliyorum. Şimdi ben de manuel kullanıcısı için ismini ve /etc/passwd dosyasında yazdığım grup numarasını buraya uygun şekilde giriyorum. Tamam artık dosyayı kaydedip çıkabiliriz. Bu /etc/group dosyasını grupların nasıl çalıştığından bahsederken tekrar ele alacağımız için dosya içindeki iki nokta ile ayrılmış sütunlardan bahsetmedim. En nihayetinde manuel kullanıcısının grubunu da eklemiş olduk. Fakat henüz işimiz bitmedi çünkü kullanıcının ev dizini ve parolası da oluşturulmadı. Ev dizini oluşturma, kullanıcıya parola atama gibi işlemleri de kendimiz yapmalıyız. /etc/passwd dosyasına ev dizini belirtmek klasörün oluşturulmasını sağlamıyor. Öncelikle ev dizini oluşturmak için sudo mkdir /home/manuel komutunu giriyorum. Son olarak parola tanımlamak için sudo passwd manuel komutunu giriyorum ve parolasını tanımlıyorum. Böylelikle kullanıcı hesabımı manuel olarak oluşturmuş oldum.

Yeni oluşturduğum kullanıcı hesabını test etmek için su manuel komutu ile manuel kullanıcı hesabına geçiş yapmayı deniyorum. Buradaki su komutu hesaplar arası geçiş yapmamızı sağlıyor daha sonra tekrar bahsedeceğim. Parolamı doğru şekilde yazdığımda manuel kullanıcı hesabına sorunsuzca geçiş yapmış oldum. whoami komutu ile de bu durumu teyit edebiliyorum. mevcut kullanıcı hesabından çıkmak için exit komutunu kullanabiliyoruz

Manuel şekilde kullanıcı oluşturabiliyor olsak da, yine de en kolay ve mantıklı yöntem adduser komutunu kullanıp adduser komutunun yeni kullanıcı için gereke tüm ayarlamaları yapmasını sağlamaktır. Dosya içeriğinde oynama yapıp kullanıcı hesabıyla ilgili bilgileri kolayca değiştirebliyor olmamız güzel bir esneklik evet. Ancak tek tek pek çok ayarlama yapmamız gerektiği için sıfırdan kullanıcı oluştururken önerdiğim veya kullandığım bir yöntem değil. Oluşturması da silmesi de daha sonra zahmetli olabiliyor. Zaten dilerseniz henüz kullanıcı hesabını oluşturma aşamasında adduser komutunun seçeneklerini kullanarak da kullanıcı hesapları ile ilgili detayları /etc/passwd dosyasını elle düzenlemeden belirtebilirsiniz. Hangi seçenekler olduğunu görmek için adduser —help komutu ile çıktıları inceleyebilirsiniz. Bakın ev dizinini kabuğu belirtebiliriz dilersek ev dizini olmamasını sağlayabiliriz kullanıcı numarasını belirtebiliriz ve benzeri tüm ayarlamaları buradaki seçenekleri kullanarak da yapabiliriz. Tek yapmanız gereken adduser komutuna buradaki seçenekleri doğru şekilde girmektir. Eğer seçeneklere falan uğraşmak istemiyorsanız benim size önerim seçeneksiz şekilde adduser komutunu kullanıp /etc/passwd dosyasında manuel olarak düzenleme yapmanızdır. 

/etc/passwd dosyasına hakkında son birkaç detaydan daha bahsedip parolaların tutulduğu dosyayı açıklamak istiyorum. Eğer bir kullanıcı hesabının bilgilerini silmeden kullanıcı hesabını deaktif etmek istersek buradan varsayılan kabuk programı yerine kullanıcının oturum açmasını reddeden /usr/sbin/nologin dosyasını yazabiliriz. Bakın burada sistem kullanıcıların neredeyse hepsi bu şekilde ayarlı. İşte bizler de kullanıcının oturum açmasını kibarca reddetmek için buraya kabuk yerine bu dosyayı ekleyebiliriz. Ben denemek için su giremez komutu ile giremez kullanıcı hesabına geçiş yapmayı deniyorum. Bakın "Bu hesap şu anda kullanılamıyor." hatası bastırılarak hesaba geçiş yapmama izin vermedi.  Çünkü kabuk yerine nologin dosyasının adresini ayarlamıştık.

Hatta tekrar passwd dosyasına bakarsanız listede /bin/false şeklinde olan kullanıcılara da denek gelebilirsiniz. benzer şekilde false dosyası da kullanıcının oturum açmasına engel olmak için kullanılan dosyadır. nologin dosyasından farklı olarak kullanıcıya bu durumda bir uyarı verilmez kullanıcı doğrudan reddedilir. İşte sizler de bu şekilde kullanıcı bilgisini dosyadan silmeden kullanıcı hesabını pasifleşitrebilirsiniz. Dilediğiniz zaman da tekrar bu dosyayı düzenleyip kullanıcıya kabuk tanımlayarak aktifeştirebilirsiniz.

Ayrıca mutlaka parola bölümündeki x ler dikkatinizi çekmiştir. Buradaki x lerin anlamı şifrelenmiş parolanın /etc/shadow dosyasında saklandığıdır. Eğer şifrelerek okunabilir biçimde bu listede bulunsaydı hesapların güvenliğini riske girerdi. Şimdi de bahsi geçen /etc/shadow dosyasına göz atalım.

## /etc/shadow Dosyası

Dosya hakkında konuşmak için önce dosyamızı açalım. Ben açmak için sudo nano /etc/shadow şeklinde komutumu giriyorum. Eğer sudo komutuyla bu dosyayı yetkili şekilde açmazsanız dosya içeriğini görüntüleyemezsiniz çünkü bu dosyada kullanıcı hesaplarının parola bilgileri bulunuyor. 

Bakın tıpkı passwd dosyasına benziyor fakat shadow dosyasında kullanıcıların parolalarıyla ilgili çeşitli bilgiler tutuluyor. 

Örneğin en son oluşturduğumuz kullanıcılar hakkında bilgi almak için satırın en sonuna inecek olursak. Bakın mevcut kullanıcı hesabım da dahil yeni oluşturduğum kullanıcıların isimleri ve yanlarında da parola bilgileri bulunuyor. 

İki nokta üst üste işaretiyle birbirinden ayrılmış olan sütunları sırasıyla açıklayacak olursak. İlk sütunda kullanıcı hesabının ismi bulunuyor. İkinci sütunda ise şifrelenmiş şekilde o kullanıcının parola bilgi bulunuyor. Biz  hesabımızda oturum açmaya çalıştığımızda eğer doğru parolayı girersek, girdiğimiz parola tekrar buradaki yöntemle şifreleniyor ve bu dosyadaki değer ile eşleşiyorsa bu kullanıcı olarak sistemde oturum açabiliyoruz.

Şifreli parola bölümünden sonra ise, bu parolanın en son değiştirildiği tarih belirtiliyor. Bu tarih 1 ocak 1970 den itibaren parolanın değiştirildiği güne kadar geçen gün sayısını veriyor. Sistem parola için milat tarihini 1 ocak 1970 olarak ayarlamış, parolanın değiştirildiği tarihi de milattan sonraki kaçıncı gün olduğuna göre burada sayısal olarak belirtiyor. Tabii ki bu gösterim bizim için kolay hesaplanır değil ancak merak etmeyin anlatımın devamında parola geçerlilik tarihleri hakkında konuşurken kullanıcıların parola bilgileri hakkında daha okunaklı çıktılar almayı öğrenmiş olacağız. Şimdilik buradaki sayının bu anlama geldiğini bilmeniz yeterli. 

Bu sayıdan sonra da minimum şifre yaşı geliyor. Bu sayı bir kullanıcının en son parola değişikliğinden sonra yeniden parolasını değiştirebilmesi için geçmesi gereken gün sayısını belirtiyor. Genelde burda olduğu gibi 0 olarak yani minimum şifre yaşı olmayacak şekilde ayarlı oluyor. Güvenlik gerekçesiyle bu sayı değiştirilebilir tabii ki.

Buradaki sayı da maksimum şifre yaşı yani kullanıcının en son tanımlamış olduğu şifreyi kullanabileceği maksimum gün sayısını belirtiyor. Yakın zamanda şifrenin sona ermemesi için burada gördüğünüz gibi çok büyük sayılar belirtilebiliyor. 

### /etc/shadow

Öncelikle dosyayı açıp dosya içeriği üzerinden açıklamamıza devam edelim. Dosya kullanıcıların şifrelerini barındırdığı için elbette yetkili olmayan kullanıcılar dosya içeriğini göremez.

[https://www.cyberciti.biz/faq/understanding-etcshadow-file/](https://www.cyberciti.biz/faq/understanding-etcshadow-file/)

Basically, the /etc/shadow file stores secure user account information. All fields are separated by a colon (:) symbol. It contains one entry per line for each user listed in [/etc/passwd file](https://www.cyberciti.biz/faq/understanding-etcpasswd-file-format/). Generally, shadow file entry looks as follows (click to enlarge image):(Fig.01: /etc/shadow file fields)

[data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjU3IiB3aWR0aD0iMzIwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIvPg==](data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjU3IiB3aWR0aD0iMzIwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIvPg==)

![https://www.cyberciti.biz/media/new/uploaded_images/shadow-file-795497.png](https://www.cyberciti.biz/media/new/uploaded_images/shadow-file-795497.png)

1. **Username** : It is your login name.
2. **Password** : It is your encrypted password. The password should be minimum 8-12 characters long including special characters, digits, lower case alphabetic and more. Usually password format is set to , The  is the algorithm used On GNU/Linux as follows:
    
    $id$salt$hashed
    
    $id
    
    1. **$1$** is MD5
    2. **$2a$** is Blowfish
    3. **$2y$** is Blowfish
    4. **$5$** is SHA-256
    5. **$6$** is SHA-512
3. **Last password change (lastchanged)** : Days since Jan 1, 1970 that password was last changed
4. **Minimum** : The minimum number of days required between password changes i.e. the number of days left before the user is allowed to change his/her password
5. **Maximum** : The maximum number of days the password is valid (after that user is forced to change his/her password)
6. **Warn** : The number of days before password is to expire that user is warned that his/her password must be changed
7. **Inactive** : The number of days after password expires that account is disabled
8. **Expire** : days since Jan 1, 1970 that account is disabled i.e. an absolute date specifying when the login may no longer be used.

### A note about password ageing

The last 6 fields provides password aging and account lockout features. You need to use the chage command to setup password aging. According to man page of shadow – the password field must be filled. The encrypted password consists of 13 to 24 characters from the 64 character alphabet a through z, A through Z, 0 through 9, \. and /. Optionally it can start with a “$” character. This means the encrypted password was generated using another (not DES) algorithm. For example if it starts with “$1$” it means the MD5-based algorithm was used. If a password field which starts with a exclamation mark (!) means that the password is locked. The remaining characters on the line represent the password field before the password was locked.

Eğer kullanıcı hesabını pasif hale getirmek istersek parolasının başına ! işareti ekleyebiliriz. Bu sayede parolası geçerli olacağı için kullanıcı giriş yapamaz. Ben denemek için ali kullanıcısının parolasının başına ünlem ekliyorum, ve dosyayı kaydedip değişikliğim geçerli olmasını sağlıyorum. Şimdi su ali komutu ile oturum açmayı deneyebilirim. Bakın parola soruluyor, parolamı giriyorum. Ancak gördüğünüz gibi kimlik doğrulama hatası aldım. Ne yaparsam yapayıp parola uyuşmayacağı için hesaba giriş yapamam. Yani sistemde ali isimli bir kullanıcı var ama artık oturum açılamayacağı için pasif halde. /etc/passwd dosyasındaki ! işaretini silip tekrar kontrol edebiliriz. Ben silip dosyayı kaydediyorum. Şimdi tekar oturum açmayı deneyiyorum ve gördğünüz gibi sorunsuzca ali heasbına geçiş yapabildik. Sizler de bu şekilde istediğiniz kullanıcı hesabını pasif hale getirip dilediğiniz zaman tekrar aktifleştirebilirsiniz.

Ayrıca daha önce yeni kullanıcı oluşturduktan sonra şifre tanımlamak için kullandığımız passwd komutunu elbette var olan şifreleri değiştirmek için de kullanabiliriz. 

# Hesapları Düzenlemek

Daha detaylı açıkla son kullanma tarihi gibi detaylara değin.

Mevcut hesapları düzenlemek istediğimizde usermod komutunu kullanabiliyoruz. Hangi özellikleri değiştirebileceğimiz görmek için usermode —help komutunu girebiliriz. Bakın ev dizinlerini, kullanıcı ismini, parola son kullanma tarihi gibi detayların hepsini değiştirebiliyoruz. Ben örnek olarak ismi değiştirmek istiyorum. ali kullanıcısının ismini hasan olarak değiştirmek için login seçeneğini kullanabilirim. Ben komutumu usermod -l yeni-isim ali şeklinde giriyorum. Değişikliği teyit etmek için /etc/passwd dosyasına bakabiliriz.  Bakın isim değişikliği geçerli olmuş. İşte bu şekilde kullanıcı hesabında değiştirmek istediğiniz özellikleri usermod aracı yardımıyla kolayca gerçekleştirebilirsiniz.

Yardım sayfasında göz atıp neleri değiştirebileceğinizi görebilirsiniz. Örneğin bakın daha önce benim /etc/shadaw  dosyasında kullanıcının parolasının önüne ünlem işareti ekleyerek yaptığım kullanıcının hesabını pasifleştirmeyi buradaki büyük -L yani lock seçeneği ile de yapabilirim. Hemen deneyelim. Ben ece kullanıcısının hesabını usermod -L ece komutu ile pasif hale getiriyorum. /etc/passwd dosyasından bu durumu teyit edebiliriz. Bakın parolanın başında ünlem işareti var. bir de su ece komutu ile hesaba geçiş yapmayı deneyelim. bakın kimlik hatası verdi. 

pasif haldeki hesabı tekar aktifleştirmek istersek unlock seçeneğini kullanabiliriz. usermod -U ece komutunu giriyorum. /etc/passwd dosyasına tekrar bakalım. bakın ünlem işareti kaldırılmış. şimdi su ece komutunu girip geçiş yapmayı deneyelim. parolayı yazıyorum ve gördüğünüz gibi sorunsuzca geçiş yapabildim. Yine daha önce dosya üzerinden manuel olarak yapabildiğimiz bir işi araç yardımıyla kısayoldan yapmış olduk. Dosyaların işlevlerini bilmenin neden faydalı olabileceğinin bir tekrarı daha oldu böylece.

İşte sizler de usermod seçeneğini kullanarak kullanıcı hesaplarında istediğiniz değişiklikleri gerçekleştirebilirsiniz. Tek yapmanız gereken yardım sayfasına göz atmak. Zaten hangi seçeneğin hangi işlevde olduğu açıkça yazıyor. Hepsine tek tek değinmemiz epey vakit alacağı için geri kalan seçenekleri araştırıp keşfetmeyi sizlere bırakıyorum. Zaten bu seçeneklere çok sık ihtiyaç da duymayacağınız için hepsinin üzerinde uzun uzadıya zaman harcamak istemiyorum. Merakınız sizin öğretmeniniz olsun.

## Kullanıcı Hesaplarını Silmek

Mevcut kullanıcı hesaplarını silmek için `userdel` komutunu kullanabiliyoruz. Örneğin ben ece  kullanıcısını silmek istersem `sudo userdel ece` şeklinde komut girmem yeterli. /etc/passwd dosyasına göz atarak kullanıcının silinip silinmediğini teyit edebiliriz. Bakın hesapla ilgili girdi silinmiş. Emin olmak için su ece komutu ile silinen hesaba geçiş yapmayı deneyebiliriz. Bakın böyle bir kullanıcı yok şeklinde hata aldık. Kullanıcı kaydı silindi ancak ev dizini silinmedi. `ls /home` komutu ile teyit edebiliriz. Kullanıcı hesabını silerken ev dizininin de otomatik olarak silinmesi için `-r` seçeneğini de eklememiz gerekiyor. ben bu kez giremez hesabını ev diziniyle birlikte silmek için `userdel -r giremez` komutunu giriyorum. Bakın halihazırda çalışmakta olan bir işlem olduğu için silinemedi. Yani halihazırda oturum açmış ve işlemleri yürütmekte olan kullanıcıları silemeyiz. Silmeden öne ilgili kullanıcının çalıştırdığı tüm işlemleri `sudo killall -u kullanıcı adı` şeklinde komut girerek sonlandırmamız gerekiyor. Buradaki `killall` komutundan işlemler bölümünde ayrıca bahsedeceğiz. Şimdilik tüm -u seçeneği ile ilgili kullanıcının çalıştırdığı tüm işlemleri sonlandırdığını bilmeniz yeterli. Ben "giremez" kullanıcısındaki tüm işlemleri sonlandırmak istediğim için `sudo killall -u giremez` şeklinde komutumuz giriyorum. Böylelikle kullanıcı ile oturumunda başlatılan tüm işlemeler sonlandırıldı. Şimdi kullanıcıyı ev diziniyle beraber silebiliriz. komutumu tekrar giriyorum. Ve böylelikle kullanıcı hesabı ev diziniyle birlikte silinmiş oldu. `ls /home` komutu ile ev dizinin silindiğini görebiliriz. 

Ayrıca ben ele almadım ancak, silmek istediğiniz kullanıcı sistemde oturum açmış ve birtakım işlemler çalıştırmış olabilir. Eğer bu kullanıcı hesabını işlemlerin bitmesini beklemeden zorla sonlandırmak isterseniz doğrudan `sudo userdel -f kullanıcı_adı` şeklinde komutunuzu girebilirsiniz. Buradaki f seçeneği force yani zorlama anlamındaki seçenektir. Zorla kullanıcının silinmesini sağlar. Ama elbette en sağlıklı yöntem bir önceki ele aldığımız gibi önce işlemleri sonlandırılıp sonra kullanıcıyı silmektir. İşlemleri sonlandırmada sorun yaşarsanız da elbette f seçeneği ile silmeye zorlayabilirsiniz. 

Ayrıca userdel komutu yerine deluser komutunu da kullanabilirsiniz. Kullanımları benzerdir. Tek yapmanız gereken yardım sayfasına göz atıp kullanabileceğiniz seçenekleri incelemektir. Her iki araç da kullanıcı hesaplarını silmede bize yardımcı olurlar.

# Erişim Yetkileri Hakkında

Linux çok kullanıcılı bir işletim sistemi olduğu için kullanıcıların faaliyetlerini kontrol altında tutmamız gerekiyor. Aksi halde standart bir kullanıcı bile sistemin işleyişini veya güvenliğini her an riske edebilir. Tıpkı gerçek dünyada olduğu gibi düşünün. Örneğin içerisinde pek çok dairenin bulunduğu bir apartmanda her dairenin bir anahtarı vardır. Ev sahipleri de kendi anahtarını kullanarak dairelerine giriş yapabilir. Anahtarı olmayan yani giriş için izni olmayan hiç kimse bir başkasının dairesine giremez. Birden fazla kişinin yaşadığı bir apartmanda bu olmazsa olmazdır. Aksi halde mahremiyet diye bir kavram kalmaz.

Bu duruma benzer şekilde, Linux sistemindeki tüm dosya ve dizinlerin kendine ait "erişim yetkileri" kuralları vardır. Bu kurallar kimlerin hangi dosya ve klasör üzerinde ne gibi işlemlere yapabileceğini açıkça sınırlar. Bu sayede yalnızca yetkisi olan kişiler, yetkileri dahilinde sistemdeki dosya ve klasörlere erişebilirler. Genel olarak bahsettiğimize göre gelin bu yetkilendirme mekanizması nasıl çalışıyormuş daha yakından bakalım.

## Kullanıcı ve Grup Kavramları Üzerine

Her bir kullanıcının kullanıcı adı ve grup numarası olduğunu hesap oluştururken gördük. Peki ama yeni bir kullanıcı hesabı oluşturulurken hem kullanıcı numarası hem de grup numarası niçin oluşturuyor ? 

Linux sisteminde her kullanıcının kendi ismiyle oluşturulmuş olan bir de grubu vardır. Herhangi bir kullanıcı kendi hesabından dosya veya klasör oluşturduğunda bu dosya veya klasörün sahipliği bu kullanıcıya aittir. Yani örneğin ben kendi hesabımdayken bir dosya oluşturursam bu dosyanın benim olduğu, dosyanın özniteliklerine yani metaverisine eklenir. Hemen teyit etmek için cat > betik.sh komutu ile bir betik dosyası oluşturup içine "echo program çalıştı" yazalım. Bu dosyayı daha sonra testlerde kullanacağız. Şimdi dosyamın özniteliklerini de bastırmak için ls -l  test.txt ile detaylı bir çıktı istiyorum.

Bakın buradaki kolon dosyanın sahibini belirtiyor, dosyayı ben oluşturduğum için benim kullanıcı adım yazıyor. Hemen yanındaki kolonda ise bu dosyanın grubu yazıyor. Dosyayı ben oluşturduğum için dosyanın grubu da otomatik olarak benim kullanıcı hesabımın gurubu oldu. İşte dosyanın sahiplik bilgisinden kastım buydu. Bir tek dosya olarak da düşünmeyin birebir klasörler için de aynı durum geçerli. Kim oluşturduysa sahibi o olarak tanımlanıyor. Peki sahiplik neden önemli ?

Sahiplik önemli çünkü, bu dosyaya kimlerin erişebileceğinin kısıtlanmasını sağlıyor. Bu durumu dana net anlamak için öncelikle burada yer alan erişim yetkilerinin ne ifade ettiğini öğrenmemiz gerekiyor. Erişim yetkileri ile devam edelim.

# Erişim Yetkileri

Kullanıcıların dosya ve klasörler üzerinde yapabilecekleri temelde üç eylem vardır. Bunlar "okuma" "yazma" ve "çalıştırma" eylemleridir. 

**okuma(r) :** Klasör listesini ve dosya içeriğini görüntülemeyi sağlar. İngilizcedeki read yani okuma ifadesinin kısalması olan r karakteri ile temsil edilir.

**yazma(w):** Dosya veya klasör üzerinde değişiklik yapmaya izin verir. İngilizcedeki write yani yazma ifadesinin kısalması olan w karakteri ile temsil edilir.

**çalıştırma(x):** Hedef dosyayı çalıştırmaya veya klasöre geçiş yapmaya izin verir. İngilizcedeki execute yani çalıştırma ifadesinin kısalması olan x karakteri ile temsil edilir.

Erişim izinlerini gözlemlemek için ls -l komutunun çıktısına göz atabiliriz. Bakın benim daha önce oluşturmuş olduğum betik.sh dosyasında bu erişim yetkilerini görebiliyoruz. En baştaki tire işareti dosyanın tipini belirtiyor. Erişim yetkisiyle alakası yok. Burada erişim yetkilerini belirten üç küme yer alıyor. İlk küme bu dosya sahibinin hangi erişim izinlerinin olduğunu gösteriyor. İkinci küme ise dosyaya tanımlı gruptaki kullanıcıların yetkilerini temsil ediyor. En son küme ise ilk iki kümeden olamayan yani dosyanın sahibi ya da dosyayla ilişkili gruptan olmayan diğer tüm kullanıcıların yetkilerini temsil ediyor.

Ben dosyanın sahibi olduğum için benim okuma ve yazma yetkim bulunuyor. Dosyanın ilişkili olduğu gruptaki kullanıcıların da okuma ve yazma yetkileri bulunuyor. Aslında bu grup benim kullanıcı hesabımın grubu olduğu için bu yetki de şu an beni etkiliyor. Bu grup benim kullanıcı hesabımın grubu olduğu için ve henüz başka bir kullanıcıyı bu gruba dahil etmediğim için grupta yalnızca ben bulunuyorum. İleride gruba nasıl kullanıcı ekleyeceğimizi ele alacağız. Geri kalan tüm kullanıcıların ise yalnızca okuma yetkisi bulunuyor. 

Söylediklerimi teyit etmek istersek dosyayı okumayı içeriğini değiştirmeyi ve çalıştırmayı deneyebiliriz. Dosyamı okumayı deniyorum. Bakın içeriğini sorunsuzca bastırdım. Veri eklemeyi de deneyebilirim. Ben yeni satır şeklinde yeni bir veri ekliyorum yani yazma yetkimi kullanıyorum. Bakın sorunsuzca ekleme de yapabildim. Şimdi henüz yetkim olmayan çalıştırma işlemini deneyebilirim. Bakın erişim yetkisi hatası aldım. Dosyanın grubu benim şu anki kullanıcımın grubu olduğu için ikinci kümedeki erişim yetkileri de benim kullanıcı hesabım için geçerli o yüzden aynı işlemi tekrar etmemize gerek yok. Ama son kümedeki diğerleri olarak geçen bir kullanıcı hesabı ile de yetki mekanizmasını test edebiliriz. Son küme, dosyanın sahibi veya dosyayla ilişkili olan grupta bulunmayan tüm kullanıcıları kapsıyor. Benim daha önce oluşturmuş olduğum kullanici1 hesabı da bu kümeye dahil. su kullanici1 komutu ile hesaba geçiş yapıyorum. diğerleri kümesindeki kullanıcıların yalnızca okumaya yetkisi var. hemen okumayı deneyelim. bakın içeriği sorunsuzca görüntüleyebildik. şimdi bir de yeni veri eklemeyi deneyelim. gördüğünüz gibi erişim reddedildi. çünkü yetkimiz yok. son olarak dosyayı çalıştırmayı da deneyebiliriz. bakın çalıştırma iznimiz de olmadığı için yine reddedildik. Böylelikle en nihayetinde dosyanın sahip olduğu erişim yetkilerini ve yetkilerin temsil ettiklerini uygulamalı olarak öğrenmiş olduk. Artık temelde erişim yetkileri ile ilgili bilmemiz gerekenleri öğrendiğimize göre bu yetkileri nasıl değiştirebileceğimizi öğrenerek devam edebiliriz.

### Yetkilerin Değişimi | chmod Komutu

Mevcut dosya veya klasörlerin gerektiğinde yetkilerini değiştirebiliriz. Yetki değiştirmek için daha önce de kullandığımız chmod komutunu kullanıyoruz. Ancak tahmin edebileceğiniz gibi yetki değiştirme işlemini her önüne gelen yapamaz. Dosya veya klasörleri ancak dosyanın sahibi veya en yetkili kullanıcı olan root kullanıcısı değiştirebilir. 

Öncelikle chmod komutunun seçeneklerini tanıyarak yetki değişimlerini nasıl yapabileceğimizi öğrenmeye başlayabiliriz. 

chmod komutunun hemen ardından hangi küme için yetki tanımlayacağımız belirtmemiz gerekiyor. Dosya sahibinin yetkilerini değiştireceksek user ifadesinin kısaltması olan u seçeneğini kullanmamız gerek. Eğer dosyayla ilişkili grup için erişim yetkisi belirteceksek group ifadesinin kısalması olan g seçeneğini kullanmalıyız. Diğer kullanıcılar için de others ifadesinin kısaltması olan o seçeneğini kullanırız. Eğer bir yetkili herkese ortak şekilde vermek istiyorsak da all ifadesinin kısaltması olan a seçeneğini kullanabiliriz. 

Yetkiyi hangi kümeye tanımlayacağımzı belirttiken sonra yetki eklemek için artı var olan yetkiyi silmek için eksi veya tam olarak yazacağımız yetkiyi tanımlamak için eşittir işaretini kullanabiliyoruz. örnekler üzerinden çok daha net anlaşılacağı için gelen uygulama yapalım.

Ben betik dosyasının sahibine çalıştırma yetkisi vermek istiyorum. Bunun için öncelikle chmod komutunu yazıyorum. Daha sonra dosyanın sahibini belirtmek için u seçeneği ekliyorum. Dosyaya yetki eklemesi yapacağım için de artı işartini koyuyorum ve eklemek istediğim yetkiyi yazıyorum. son olarak dosyayı belirtip komutumu onaylıyorum. ls -l komutunun çıktısından da teyit edebildiğimiz üzere bakın dosyanın sahibi yani ilk kümeye çalıştırma yetkisi eklenmiş. dosyayı çalıştırmayı deneyerek de bu durumu teyit edebilirim. bakın betik dosyası sorunsuzca çalıştı.

İstersek eklemek yerine var olan yetkileri silebiliriz. Ben dosyayla ilişkili olan gurubun okuma ve yazma yetkisini silmek istiyorum. Bunun için chmod komutunun ardından grubun yetkilerini belirtmek için g seçeneğini yazıyorum. yetki sileceğim için de eksi işaretini koyup silmek istediğim yetkileri yazıyorum. son olarak dosya ismini de girip komutumu onaylıyorum. tekrar ls -l komutu ile dosyamızın yetkilerini kontrol edebiliriz. bakın ikinci küme yani gruptaki kullanıcılar için olan yetkiler silinmiş. 

Ekleme ve silme dışında spesifik olarak hangi yetkilerin olmasını istediğimizi eşittir işareti ile doğrudan belirtebiliriz. Bakın şu anda diğer kullanıcılar için yalnızca okuma yetkisi bulunuyor. Ben diğer kullanıcılar için yalnızca çalıştırma yetkisi vermek istiyorum. Bunun için chmod komutunun ardındna diğer kullanıcıları temsil eden o seçeneğini yazıyorum. ekleme veya çıkarma yapmayacağım doğrudan istediğim erişim yetkilerini vereceğim için eşittir işaretini yazıp istediğim çalıştırma yetkisini ekliyorum. yetkisini değiştirmek istediğim dosyayı da belirtip komutumu onaylıyorum. bakın ls -l komutunun çıktısında, istediğim yetkilendirmenin doğrudan tanımlandığını teyit edebiliyorm. Önceden yalnızca okuma yetkisi vardı. Şimdi eşittir işartini kullandığım için tek seferde okuma yetkisini silip yalnızca çalıştırma yetkisi kalacak şekilde erişim yetkisini güncellemiş oldum. 

Son olarak da tüm kullanıcılarda geçerli olacak bir değişikliği deneyebiliriz. Tüm kullanıcıları temsil eden karakterin a olduğunu söylemiştik. Hemen test edebiliriz. Örneğin ben öncelikle tüm kullanıcılara yazma yetkisi vermek için chmod a +w dosya adı şeklinde komutumu giriyorum. Bakın tüm kullanıcılara yazma yetkisini tek seferde vermiş oldum. Şimdi de aynı şekilde tüm kullanıcılaradan yazma yetkisini silmek üzere chmod a -w dosya adı şeklinde komut girmem yeterli. Bakın tek seferde tüm kümeler için yazma yetkisi silindi. Eğer tüm kullanıcılara tüm yetkileri vermek istersem de örneğin chmod a =rwx dosya adı şeklinde komutumu girebilirim. Bakın artık tüm kullanıcılar tüm yetkilere sahip. Hatta aslında a seçeneğini özellikle belirtmenize de gerek yok. Örneğin chmod -rwx dosya adı şeklinde komut girersem herhangi bir kümeyi özellikle belirtmediğim için yetki çıkarma işlemi tüm kümeler üzerinde etkili olacaktır. Bakın tüm yetkiler silinmiş. Neticede tüm kullanım biçimlerinden bahsetmiş olduk. Zaten mantığını kavradığınız da ne kadar kolay olduğunu görebiliyorsunuz. 

Hatta dilersek bu yetkileri rakamlar üzerinden de düzenleyebiliriz. Bu yöntem çok daha sade ve sık tercih ediliyor üstelik. Bu tabloya bakarak yetkilerin rakamsal karşılıklarını görebilirsiniz. 

![Screenshot_1.png](14-%20Kullan%C4%B1c%C4%B1%20ve%20Grup%20Yo%CC%88netimi%2058629a017f47424aa80fc6cc758dcc69/Screenshot_1.png)

chmod +700 yaptığımızda mevcut yetkilerin üzerine ekleme yapılır. Yani bu kullanımda dosyasını sahibine tüm yetkieler verileriken diğer yetkieler eski haliyle kalır. DOğrudan ilgili dizinin yetkilerin atamak için artı ya da eksi kullanmadan belirtmek gerekiyor. 

Bir dosya veya klasöre yalnızca okuma yetkisi vermek için 4 rakamını, yalnızca okuma yetkisi için 2 rakamını ve yalnızca çalıştırma yetkisi için de 1 rakamını kullanırız. Eğer aynı birden fazla yetki vereceksek de bu rakamların toplamını kullanırız. Örneğin okuma ve yazma yetkisi için 4 + 2 den 6 rakamını girerken tüm yetkileri vermek için 4 + 2 + 1 den 7 rakamını girmeliyiz.

sahibine grubuna ve diğer kullanıcılara erişim izinleri tanımlamak için de sayıları üç basamaklı şekilde peş peşe yazmamız gerekir. ilk yazdığımız sayı dosya sahibi için, ikincisi dosyanın grubu için son basamak ise diğer kullanıcılar için yetki tanımlamamızı sağlıyor. Örnekler üzerinden kullanımını kolayca göreceğiz. Hemen deneyelim.

Ben en son ls -l komutunun çıktısında da görebileceğiniz gibi betik dosyamın tüm yetkilerini silmiştim. Şimdi rakamları kullanarak yeni yetkiler tanımlayabiliriz.

Ben yalnızca dosyanın sahibine çalıştırma yetkisi vermek istiyorum. Bunun için chmod komutundan sonra yazacağım ilk rakam dosyanın sahibini için olan yetkileri temsil ediyor. Çalıştırma yetkisi de 1 rakamı ile temsil edildiğini için ilk rakam olarak 1 yazıyorum. geri kalan iki basmağı ise 00 şeklinde dolduruyorum çünkü gruptaki  ve diğer kullanıcılara hiç bir yetki vermek istemiyorum. 

bakın yalnızca dosyanın sahibine çalıştırma yetkisi eklenmiş. bir örnek daha vererek durumu pekiştirelim. ben dosyanın sahibine yalnızca okuma ve yazma yetkisi, dosyayla ilişkili olan gruba yalnızca okuma ve çalıştırma yetkisi diğer kullanıcılara ise yalnızca çalıştırma yetkisi vermek üzere komutumu giriyorum. rakamları topladığımda sırasıyla dosyanın sahibi için 6, grubu için 5 , diğer kullanıcılar için de 1 rakamını kullanmam gerektiğini hesapladım komutumu chmod 651 şeklinde giriyorum. ls -l komutu ile teyit edelim. bakın birebir istediğim erişim yetkilerini tanımlamış oldum. gördüğünüz gibi rakamlar üzerinden tanımlama yapmak çok daha kolay çünkü ekleme çıkarma yapmakla veya hangi küme için hangi kısaltmayı kullanacağınızla uğraşmanız gerekmiyor. kısayoldan erişim yetkilerini atayabiliyoruz. Bakın chmod 000 dosya adı şeklinde komut girdiğimde birden tüm yetkilerini kolayca silmiş oluyorum. rakamları akılda tutması zaten çok kolay.  zaten zamanla kullandıkça hemen aklınıza geliyor olacaklar. yani rakamlar gözünüzü korkutmasın. 

Ben örnekleri hep dosya üzerinden ele aldım ancak birebir klasörler için de aynı adımları takip ediyoruz. Sadece son olarak bir klasörün altındaki tüm dosya ve dizinlerin yetkilerini nasıl tek seferde değiştirebileceğimize de değinmek istiyorum. Hatırlıyorsanız klasörleri silersek özyineleme diye bir kavramdan bahsetmiştik. Burada da benzeri bir yaklaşım söz konusu. Bir klasörün içerisinde birden fazla dosya ve klasör olabileceği ve o klasörlerin de içinde başka dosyalar bulunabilir. Eğer bir tek seferde hepsine ortak bir erişim yetkisi tanımlaması yapmak istersek işlemin tüm alt dosya ve klasörlerde geçerli olabilmesi için özyinelemeli olarak gerçekleşmesi gerekiyor. bunu da recursive yani özyineleme ifadesinin kısaltması olan büyük R seçeneği ile chmod komutuna belirtebiliriz.

Ben vakit kaybetmemek için ev dizinimdeki içerisinde iç içere klasörler ve dosyalar bulunan daha önce oluşturmuş olduğum bu klasörü kullanacağım. Siz de test etmek için kendinize böyle bir klasör oluşturabilirsiniz. ls -lR komutu ile alt dizinler de dahil tüm dosya ve klasörleri izinleriyle birlikte listeleyebiliz. Bakın tüm dosya ve klasörler listelendi. ls komutuna verdiğimiz büyük R seçeneği de recursive yani özyinelemeli olarak listelenmesini sağladı. Şimdi testlere geçebiliriz.

Ben öncelikle ana klasörün yetkisini değiştirip alt klasörlerin ve dosyaların etkilenip etkilenmeyeceğini test etmek istiyorum. Ben yalnızca klasörün sahibine tüm yetkileri vermek için chmod 700 şeklinde komutumu giriyorum. Şimdi alt dizinlerle beraber listeleyelim. Bakın yalnızca ana klasörün yetkisi değişmiş. Şimdi bir de özyineleme seçeneği yani R seçeneği ile örneğimizi tekrar deneyelim. Bakın tüm alt klasörlerin ve dosyaların yetkileri ortak şekilde değişmiş. İşte sizler de büyük R seçeneğini kullanarak klasöre tanımlayacağınız yetkinin tüm alt dizinlerde de ortak şekilde geçerli olmasını sağlayabilirsiniz.

Artık yetkileri tanıyabiliyor ve istediğimiz şekilde ayarlayabiliyor olduğumuza göre grup kavramından bahsederek devam edebiliriz. 

# Grup Yönetimi

Artık erişim yetkilerinden de haberdar olduğumuza göre grupların esas amacını rahatlıkla kavrayabiliriz. 

Yeni bir kullanıcı hesabı oluştururken gözlemlediğimiz gibi, sisteme her yeni kullanıcı hesabı eklendiğinde, tek üyesi bu kullanıcı olan ve kullanıcı adıyla aynı ada sahip bir grup oluşturuluyor. 

Hatta kullanıcıların yeni dosya ve klasör oluşturduklarında otomatik olarak dosyanın sahibi olarak tanımlandıklarını ve ayrıca dosyanın ilişkili olduğu grubu olarak da kullanıcının grubunun tanımlandığını biliyoruz. Buradaki grup kavramı önemlidir. Grupların amaçlarından biri, bu kaynaklar üzerinde doğru izinleri ayarlayarak dosyalara ve diğer sistem kaynaklarına basit bir erişim denetimi uygulamaktır. Bir gruba birden fazla kullanıcı eklersek, tek seferde gruptaki tüm kullanıcıların erişim yetkilerini etkileyecek değişiklikler yapabiliriz. Zaten gruplar bunun için var. Örneğin benim oluşturduğum bir dosya üzerinde başka bir kullanıcının yetkisinin olmasını istersem, ilgili kullanıcıyı dosyanın ilişkili olduğu gruba ekleyip dosyanın grup için olan yetkilerini de uygun şekilde ayarlayabilirim. Bu sayede ilgili kullanıcı diğer kullanıcılardan farklı olarak bu dosya üzerinde erişim haklarına sahip olur. Oldukça basit bir yapı aslında. Örnekler üzerinden çok daha net anlaşılacaktır.

Öncelikle testler sırasında kullanabilmek için yeni kullanıcı hesapları oluşturmamız gerekiyor. Ben bu durumu test etmek için hemen üç yeni kullanıcı oluşturacağım. Kullanıcıların isimlerini de kullanici1 kullanici2 ve kullanici3 şeklinde ayarlayacağım. Kullanıcı hesaplarını oluşturdum. 

Şimdi grup mekanizmasını test etmek için daha önce oluşturmuş olduğum [betik.sh](http://betik.sh) dosyasını kullanmak istiyorum. Bu dosya içerisinde bildiğiniz gibi çalıştığında konsola çıktı bastıran echo komutu bulunuyor. Bu sayede dosyanın çalışıp çalışmadığını teyit edebiliyoruz. Daha önce oluşturmadıysanız test etmek için dosyanın içine echo komutu ile istediğiniz bir ifadeyi yazıp kaydetmeniz yeterli. Şimdi ben dosyanın yetki detaylarına ve sahiplik bilgisini görmek için ls -l betik.sh şeklinde komutumu giriyorum. Bakın bu dosyayı ben oluşturduğum için dosyanın sahibi benim. Ve dosyanın ilişkili olduğu grup da yine benim hesabımın grubu. Ben dosyanın sahibi olarak burdaki yetkilere sahibim. Eğer ek olarak bazı kullanıcılara özel yetkiler de kazandırmak istersem, ilgili kullanıcıları bu dosyanın ilişkili olduğu guruba ekleyebilirim. Daha sonra dosyanın gruptaki kullanıcılar için olan yetkilerini yani ikinci kümedeki erişim yetkilerini düzenleyip, bu kullanıcılara özel erişim izni ayarlayabilirim. Dosyanın sahibi ve bu gruptaki kullanıcılar dışındaki tüm kullanıcılar için de nasıl bir yetkilendirme istiyorsam son erişim kümesine buna göre tanımlama yapabilirim. Bu sayede güvenli şekilde dosya ve klasörlere kimlerin ne şekilde erişebileceğini sınırlamış olurum. İşte grup mekanizması bu sebeple önemli. Hemen uygulama üzerinden deneyimleyelim. 

Ben dosyanın sahibine yani kendime tüm yetkileri veriyorum. Benimle aynı gruptaki kullanıcılara okuma ve çalıştırma yetkisi veriyorum. Diğer kullanıcılara ise yalnızca okuma yetkisi veriyorum. ls -l komutu ile atadığım yetkileri de teyit ediyorum. bakın yetkiler sorunsuza tanımlanmış. Şimdi daha önce oluşturduğum kullanici1 ve kullanici2 yi dosyayla ilişkili olan kendi hesabının grubuna ekleyip kullanici3 için herhangi bir değişiklik yapmayacağım. 

Gruba ekleme işlemi için daha önce gördüğümüz usermod aracını kullanacağız. Bu araç ile kullanıcıları kendi grubuma dahil edebilirim. Usermod aracının -a seçeneği append yani ekleme işlevindedir. büyük G ise grupları temsil eder. Kullanici 1 ve kullanici2 yi eklemek için usermod -a -G komutunun ardından eklemek istediğim grubu yazmam gerekiyor. Dosyayla ilişkili grup olduğu için kendi kullanıcı hesabımının grup adını giriyorum. Zaten benim kullanıcı adım ile aynı. Daha sonra eklemek istediğim kullaniciları virgülle ayırarak yazıyorum. Neticede kullanıcıları gruba ekledim. /etc/group dosyasına bakarak da bu durumu teyit edebilirim. Bakın kendi grubumun sonunda eklediğim kullanıcı isimleri de bulunuyor. /etc/group dosyasındaki en son kolon zaten gruba dahil edilen kullaniciları temsil ediyor.

Gruba eklemeyi başardığımıza göre artık yetkileri ve yetkilerin gruplar üzerindeki etkisini test edebiliriz. Ben test emek için öncelikle kullanici 1 hesabına geçiş yapıyorum. Komut dosyası benim ev dizinimde olduğu için öncelikle yetkilerini tekrar görmek adına ls -l /home/taylan/[komut.sh](http://komut.sh) şeklinde dosyamın bilgilerini konsola bastırıyorum. Bakın sahibi tüm yetkilere sahipken sahibiyle aynı gruptakiler yani örneğin şu an geçiş yaptığım kullanıcı yalnıza okuyup çalıştırabiliyor, dosya içeriğini değiştirmeye yetkisi bulunmuyor. Teyit etmek için öncelike dosya içeriğini cat komutu ile okumayı deneyelim. Bakın sorunsuzca okuyabildim. Şimdi bir de çalıştırmayı deneyelim. Çalıştırırken de bir sorun yaşamadım. Son olarak dosyaya echo "ekleme" >> betik.sh şeklinde komut girerek dosyaya yazma yetkim olup olmadığını teyit etmek istiyorum. Bakın erişim reddedildi. Çünkü gruptaki kullanıcılar için yazma yetkisi tanımlı değil. Böylelikle dosyanın ilişkili olduğu gruptaki tüm kullanıcılara için istediğimiz erişim yetkilerini tanımlayabileceğimizi teyit etmiş olduk. 

İsterseniz aynı gruba dahil ettiğimiz kullanıcı2 için de aynı testleri yapıp gruplara eklenen kullanıcıların bu dosyada tanımlı olan ortak yetkilere sahip olduğunu teyit edebiliriz. Aslında gerek yok ama aklınızda şüphe kalmaması için ben gruptaki diğer kullanıcı hesabına da geçiş yapıyorum. Öncelikle dosyamı okumayı deneyeceğim. bakın içeriği görüntüleyebiliyorum. şimdi çalıştırmayı deneyelim. çalıştırırken de yetkim olduğu için sorun yaşamadım son olarak üzerine yeni veri eklemeyi yani içeriğine veri yazmayı deneyelim. bakın tıpkı kullanici1 de olduğu gibi erişim hatası aldım. çünkü her iki kullanıcı hesabı da ortak grupta ve bu grubun bu dosya üzerindeki yetkileri de dosyada değişiklik yapmalarına müsade etmiyor. Bakın tek bir grup üzerinden birden fazla kullanıcı için kolayca yetki tanımlaması yapabildik. Testi nihayete erdirmek için üçüncü küme yani dosya sahibi olmayan veya dosya ile ilişkili olan grupta bulunmayan diğer kullanıcı üzerinden dosya üzerindeki erişim yetkilere göz atabiliriz.

Diğer kullanıcıların yalnızca dosyayı okuma yetkisi bulunuyor. Ben öncelikle okumayı deniyorum. Bakın sorunsuzca okuyabildim. Şimdi içeriğine veri eklemeyi yani yazma yetkisini test edelim. Gördüğünüz gibi erişim reddedildi. Çünkü buna yetkim yok. Son olarak da dosyayı çalıştırmayı deneyip testimizi nihayete erdirelim. Bakın çalıştırma girişimim de reddedildi çünkü diğer kullanıcıların çalıştırma yetkisi de bulunmuyor. 

Ben örnek olarak dosya kullandım ancak elbette aynı durum klasörler üzerinde de geçerli. Dosya veya klasörün durumuna göre hangi kullanıcıların bu dosya üzerinde ne gibi yetkileri olacağını ayarlayabilirsiniz. Dosyanın sahibi olmayan ama dosya üzerinde birtakım haklarının olmasını istediğiniz kullanıcıları bu şekilde gruba ekleyip istediğiniz erişim yetkisini tanımlayabilirsiniz. Zaten bu üç küme yani dosyanın sahibi, dosyayla ilişkili olan gruptaki kullanıcılar ve bunlar dışındaki geriye kalan kullanıcıların yetkilerini yönetmek yetkilendirme ile ilgili ihtiyaçlarının büyük kısmını karşılayacaktır. Ancak yine de dosyayı oluşturan kişinin grubunu istemeye de bilirsiniz. Dilerseniz ilgili dosyaya başka bir grup da tanımlayabilirsiniz. Anlatımın devamında bunun üzerinde duralım.

# Grup Oluşturmak

Zaten dosya ve klasörler oluşturulurken sahibinin grubu da ekleniyorsa neden yeni bir grup oluşturmamız gerekiyor ki ? Cevap aslında basit, istisnai durumları karşılamak için. Örneğin diyelim ki önemli bir dosya oluşturdunuz ve bu dosya için yalnızca birkaç kişiye yetki vermek istiyorsunuz. Eğer dosyanın ilişkili olduğu grubu değiştirmezseniz, yalnızca sizin kullanıcı grubunuza dahil olan tüm kullanıcılar için bir erişim izni tanımlayabilirsiniz. Fakat siz bu dosya için kendi grubunuzdaki tüm kullanıcılara da yetki vermek istemiyorsunuz diyelim. Belki kendi grubunuzda bulunan yalnızca birkaç kişiye ve sistemdeki başka birkaç kullanıcıya daha yetki vermeniz gereken özel bir durum oluştu. Yani özetle özel amacınız doğrultusunda birkaç kullanıcıyı bir araya toplayıp ortak yetki vermenizi gerektiren bir durumla karşılaşırsanız yeni grup oluşturup bu kullanıcıları bu gruba ekleyebilirsiniz. daha sonra ilgili dosyanın ilişkili olduğu grubu da bu yeni oluşturduğunuz grup olarak ayarlarsınız. ve işte tamam. tam olarak sizin istediğiniz seçtiğiniz insanlar için tam olarak istediğini yetkileri verebilme imkanına sahip oldunuz. hadi gelin bu durumu somut bir örnek üzerinden bu bizzat test edelim.

Ben yine [betik.sh](http://betik.sh) dosyasını kullanacağım. Öncelikle istediğimiz kullanıcı hesaplarını bir arada toplayabileceğimiz yeni bir grup oluşturalım. Yeni grup oluşturmak için groupadd komutunu kullanabiliriz. Komutun hemen arından oluşturmak istediğiniz grubun ismini girmemiz gerek. Ben "yetkili" adında oluşturmak üzere groupadd yetkili şeklinde komutumu giriyorum.

Yeni grubun oluşturulduğunu teyit etmek için /etc/group dosyasına tail komutu ile bakabiliriz. Bakın yeni grup eklenmiş. Şimdi bu gruba istediğim kullanıcıları ekleyebilirim. Ben kullanici1 ve kullanici3 ü eklemek istiyorum. Gruba kullanıcı eklemek için daha önce de kullandığımız usermod komutunu tekrar kullanacağız.

Gruba ekleme yapacağım için öncelikle append yani ekleme seçeneğini yazıyorum. Ve grubu belirtmek için büyük G seçeneğini yazıp hemen ardından grubun ismini giriyorum. Gruba eklemek istediğim kullanıcıları da virgülle ayırarak yazıyorum. Böylelikle kullanici1 ve kullanici3 ü "yetkili" guruba eklemiş oldum. Kullanıcıları da eklediğimize göre son olarak dosyanın ilişkili olduğu grubu, bizim yeni oluşturduğumuz bu grup olarak ayarlamamız gerekiyor. Bunun için dosya veya klasörlerin sahipliğini değiştirmemizi sağlayan chown komutunu kullanacağız. Zaten komutun ismi de change owner yani sahibi değiştir ifadesinin kısalmasından geliyor. Yani herhangi bir dosya veya klasörün sahipliğini değiştirmek istediğinizde isim açılımından dolayı chown komutunu rahatlıkla hatırlayabilirsiniz.

Örneğimize dönecek olursak, bakın şu anda dosyanın sahibi ve grubu ben ve benim grubum. Ben grubu değiştirmek istediğim için chown mevcut grup iki nokta üst üste yeni grup ve dosyanın ismi şeklinde komutumu girmem gerekiyor. sudo chown taylan:yetkili betik.sh

Dosyayı tekrar listelediğimde bakın grubunun değiştiğini görebiliyoruz. Bu da demek oluyor ki artık yetkili grubundaki kullanıcılar için buradaki gruplar için olan erişim yetkileri geçerli olacak. Örneğin ben bu gruptaki kullanıcılara tüm yetkileri vermek diğer herkesin yetkilerini kısıtlamak istersem chmod 070 [betik.sh](http://betik.sh) komutunu kullanabilirim. Bu sayede yalnızca yetkili grubundaki kullanici1 ve kullanici3 bu dosyaya tam erişim izinlerine sahip olur. Hadi gelin teyit edelim. Ben dosyanın sahibiyim, sırsıyla dosyayı okumayı, yani veri yazmayı ve çalıştırmayı deniyorum. Bakın dosyaya erişim iznim olmadığı için hepsi reddedildi. Aynı durum gruptaki kullanıcılar hariç tüm kullanıcılar için geçerli. Çünkü diğer kullanıcıların da tüm yetkilerini kısıtladık. Şimdi gruptaki bir kullanıcı olan kullanici3 e geçiş yapıp bir de o hesaptan deneyelim. Öncelikle dosyayı okumaya çalışıyorum. Bakın sorunsuzca içeriği bastırıldı. Bir de yeni veri eklemeyi yani yazma yetkisini de test edelim. Yazma konusunda da hiç bir sorun yok. Bakın dosyayı çalıştırırken de herhangi bir erişim sorunu yaşamıyoruz.

Neticede bir dosyaya erişebilecek kullanıcıları kısıtlamak için özel bir grup oluşturup, bu gruba istediğimiz kullanıcıları ekledik. Dosyanın grubu olarak da bu yeni grubu tanımladık ve dosyanın yetkilerini istediğimiz şekilde düzenledik. Böylece tam olarak kimlerin dosyaya erişmesini istediğimize karar vermiş olduk. 

Ben örneği dosya üzerinden ele aldım ancak elbette tüm işlemler klasörler üzerinde de geçerli. İhtiyaçlarınıza özel gruplar oluşturup bu grupları dosya veya klasörlere tanımlayarak istediğiniz yetkilendirmeyi yapabilirsiniz. 

Ayrıca dilerseniz dosya veya klasörün yalnızca grubunu değiştirmekle sınırlı değilsiniz. chown komutu ile dosyanın sahibini de değiştirebiliriz. örneğin bakın dosyanın grubunu değiştirmiş olmama rağmen betik dosyasının sahibi olarak hala benim kullanıcı hesabım gözüküyor. Ben dosyanın sahipliğini kullanici1 e vermek için chown kullanici1 dosya adı şeklinde komutumu giriyorum. Bakın dosyanın yeni sahibi artık kullanici1 hesabı. Yani buradaki ilk kümedeki yetkiler artık kullanici1 hesabının yetkileri oldu. Sizler de bu şekilde istediğiniz dosya veya klasörün sahipliğini ve ilişkili olduğu grubu chown komutu ile kolayca değiştirebilirsiniz.

Klasörlerin sahipliğine dosyalar ile birebir aynı olduğu için hiç örnek vermedim ama ekstra bir bilgi vermek istiyorum. Eğer klasörün içindeki tüm alt dizinlerde aynı sahiplik ayarlarının geçerli olmasını istiyorsanız recursive yani özyineleme işlevindeki büyük R seçeneğini de kullanmanız gerekiyor. Zaten recursive seçeneğinin klasörler üzerindeki etkisini biliyorsunuz. Daha önce birkaç kez daha  farklı komutta bu özelliği deneyimledik. Örneğin benim daha önce oluşturmuş olduğum ve içinde iç içe pek çok klasör ve dosya bulunan bu klasörü örnek olarak kullanabiliriz. Öncelikle ls -lR komutu klasörün içeriğindeki tüm dosya ve klasörleri bastıralım. Bakın hepsinin sahibi ve grubu benim. Örneğin hepsinin sahipliğini kullanıcı3 e devretmek istersem sudo chown -R kullanici3 klasör adı şeklinde komut girmem yeterli. Tekrar listeyebiliriz. Bakın ana klasörle birlikte altındaki tüm klasör ve dosyaların sahipliği kullanici3 e geçmiş oldu. Aynı şekilde R yani özyineleme seçeneği kullanarak ilişkili oldukları grubu da tek seferde değiştirebiliriz. Ben hepsini yetkili grubu ile ilişkilendirmek için sudo chown -R mevcut grup adı: yetkili grubu ve klasör adı şeklinde komutumu giriyorum. Listeleyip değişikliğe göz atalım. Bakın tüm gruplar da tek seferde tüm alt dizinlerde geçerli oldu.

İşte sizler de bu şekilde dosya veya klasörlerinizin sahiplik durumlarını dilediğiniz gibi düzenleyebilirsiniz.

## Dosya ve Klasörleri Birden Fazla Grup İle İlişkilendirmek

Anlatım boyunda daha kolay anlaşılabilmesi için dosya ve klasörlerde tanımlı bulunan grubun, dosya ve klasörün ilişkili olduğu grup olduğunu söyledim. Ancak bu tam olarak doğru değil. Burada belirtilen grup dosyanın sahibini olan grubu temsil ediyor. Dolaylı yoldan grup içindeki kullanıcılar da aslında dosya veya klasörün sahipleri olup, yetkileri dahlinde üzerinde işlem yapabiliyorlar.

İhtiyacınız doğrultusunda tek bir dosyaya birden fazla grup tanımlamak istemiş olabilirsiniz. Bu normal grup yapısı ile mümkün değil ama siz bunun yerine Erişim Noktası Kontrol Listesi kullanabilirsiniz.

However using access control lists you can define permissions for other groups.

Grubu Düzenlemek

groupmod

Using access control lists ?

bu konu ileri seviye olduğu için temel eğitime eklemede kararsızım

[https://devconnected.com/access-control-lists-on-linux-explained/](https://devconnected.com/access-control-lists-on-linux-explained/)

Grubu Silmek

# sudo | wheels grubu ve sudoers

[https://www.digitalocean.com/community/tutorials/how-to-edit-the-sudoers-file](https://www.digitalocean.com/community/tutorials/how-to-edit-the-sudoers-file)

Sudo komutu, root olmayan kullanıcıların normalde süper kullanıcı ayrıcalıkları gerektiren komutları çalıştırmasına izin verirken, sudoers dosyası sisteme sudo komutunun nasıl kullanılacağını bildirir.

Anlatım boyunca kullanıcı ve grup yönetimi için sürekli olarak sudo yetkilerine ihtiyaç duyduğumuzdan bölümün başında kısaca sudo komutuna değinmiştik. Şimdi biraz daha yakında bakalım. 

sudo komutu geçici olarak yetkilerimizi yükseltmemize olanak tanıyan bir araçtır. Biz herhangi bir komuttan önce sudo komutunu kullandığımızda, sudo aracının yapılandırma dosyası olan /etc/ içinde bulunan sudoers dosyasına bakılır. Eğer bize bu komutu çalıştırmak için özel ayrıcalık verildiyse komutu yetkili şekilde çalıştırabiliriz.

Bu sayede root hesabını kullanmadan root'un ayrıcalıkları ile işimizi halletmiş oluruz. Bu yöntem sayesinde kullanıcılar root hesabının parolasını bilmeden de yetkileri varsa root düzeyindeki yetkilerle işlerini görebiliyorlar. Zaten çoğu sistemde root hesabını güvenlik gerekçesiyle varsayılan olarak pasif şekildedir. Ayrıca pasif olmasa bile her önüne gelen kullanıcıyla sadece birkaç işini yetkili şekilde yapacak diye root hesabının parolasını paylaşmamız da mantıklı olmazdı. root parolasını bilmeye gerek kalmadan root olarak işlem yapmaya basit bir örnek verebiliriz. 

Örneğin konsola whoami yazdığımızda bakın kendi kullanıcı adımızı alıyoruz. Eğer sudo whoami yazarsak, kendi hesabımızın parolasını girip bakın root yanıtını aldık. Çünkü aslında biz sudo komutunu kullandığımızda root hesabı bizim için bu komutu çalıştırmış oldu. Bu işlem için de root hesabının parolasına ihtiyacımız olmadı, yalnızca kendi hesabımızın parolasını girdik. Kendi hesabımız da sudo komutunu çalıştırabilecek gruba dahil olduğu için sudo komutu ile geçici root yetkilerini elde etmiş olduk. İşte gördüğünüz gibi sudo aracı bizlere güvenli yoldan root yetkilerini sunan işlevsel bir araçtır.

sudo aracını kimlerin ne şekilde kullanabileceğini düzenlemek için /etc/sudoers dosyasını metin editöründe açıp düzenleyebiliriz. Ancak burada dikkat etmeniz gereken detay kullandığınız metin editörünün dosya yapısını bozmayacak türden olmasıdır. nano ya da vi kullanabilirsiniz. zaten visudo komutunu girdiğinizde sisteminizdeki varsayılan metin editöründe /etc/sudoers dosyası açılır. Elbette dosyayı açmak için dosyayı açmaya yetkimizin de olması gerekiyor. Dosyayı sudo komutu ile açabiliyoruz. Benim kullandığım hesap yönetici hesabı olduğu için ben dosya içeriğini sudo visudo komutu ile okuyabiliyorum. 

Şimdi dosya içeriğine bakacak olursak. Dosyanın en başında bulunan varsayılan olarak tanımlı üç satır bulunuyor. Bunlar güvenlik amaçlıdır. İlk satır tanımlanmış olabilecek zararlı değişkenleri sıfırlar. İkini satır, root parolası yanlış girildiğinde yöneticiye mail atılmasını sağlar, son satır ise zararlı dosyaları içerebilecek ek path yollarının tanımlanmış olma ihtimaline karşı standart olan path yolunu tekrar tanımlar. Dediğim gibi bunlar güvenlik önelimi bunlara müdahale etmeden devam edeceğiz.

Diyez sembolü olan satırlar da zaten yorum satırları. Bunlar işleme alınmıyor.

Buradaki ilk tanımlama ile başlayacak olursak, bu satır root kullanıcının sudo ayrıcalıklarını belirtiyor. 

İlk kısım bu kuralın geçerli olacağı kullanıcın ismini belirtiyor. Bu kural root kullanıcısı için tanımlandığından burada root yazıyor.

İkinci kısımdaki ALL ifadesi bu kuralın tüm hostlarda yani tüm ana makinelerde geçerli olmasını sağlıyor.

Eşittir işaretinden sonra parantez içinde yazılan ilk ALL, root kullanıcısının komutları tüm kullanıcılar gibi çalıştırabileceğini gösteriyor. İkinci ALL ise root kullanıcısının komutları tüm gruplar gibi çalıştırabileceğini belirtiyor.

En sondaki ALL ise bu kuralların tüm komutlar üzerinde geçerli olmasını sağlıyor.

root kullanıcısı halihazırda tüm yetkilere sahip olduğu için buradaki tanımlama size gereksiz gibi gelmiş olabilir, ancak gereksiz değil. Bu tanım root kullanıcısının da sudo aracını çalıştırabilmesini sağlar. Hadi netleştirmek için basit bir test gerçekleştirelim. Ben bu satırın dikkate alınmaması için başına yorum işareti olan diyez işaretini ekleyip dosyamı kaydediyorum. Şimdi de root hesabına geçiş yapalım. Ben daha önce root için bir parola belirleyerek root hesabını aktifleştirmiştim. Eğer sizler aktifleştirmediyseniz sudo passwd root komutu ile root için yeni bir parola belirleyerek aktifleştirebilirsiniz. sudo su komutu ile root hesabına geçiş yapıyorum. Bakın şu anda root hesabındayım. Eğer konsola ls komutunu girersem sorunsuzca içerikleri listeleyebilirim. Bir de komutun başına sudo ekleyerek tekrar deneyelim. Bakın aldığımız hatada root kullanıcısının bu makinede ls aracını root yetkileri ile çalıştırmasına izin verilmediği belirtildi. Bu hatayı aldık çünkü etkisiz hale getirdiğimiz satırda root kullanıcısının herkes olarak çalıştırılma yetkisini de devredışı bırakmış olduk. Aslında root kullanıcısının sudo komutuna ihtiyacı yoktur, çünkü bizzat kendisi root yetkilerinin sahibidir. Fakat özellikle içerisinde sudo komutu bulunduran betik dosyalarının çalıştırılması noktasında root hesabındayken sorun yaşamamak adına sudoers dosyasının en başındaki kuralı değiştirmemeliyiz. Bu sayede root kullanıcısı da sudo aracını sorunsuzca kullanabilir. Ben exit ile root hesabından çıkıyorum.

Dosyamızı sudo visudo komutu ile tekrar açalım ve yorum satırı işaretini silelim. Şimdi diğer satırlardan bahsedecek olursak;

sudoers dosyasında, başında yüzde işareti olan satırlar da grupları temsil eder. Örneğin bakın admin diye bir gruba buradaki yetkiler verilmiş. Burada, admin yani yönetici grubunun herhangi bir ana bilgisayardaki herhangi bir kullanıcı olarak herhangi bir komutu yürütebildiğini görüyoruz. Benzer şekilde, sudo grubu da aynı ayrıcalıklara sahiptir, ancak herhangi bir grup olarak da çalışabilir. Buradaki ikinci ALL ifadesinin tüm gruplar olarak çalışmaya izin verdiğini söylemiştim.

Eğer bizler herhangi bir kullanıcı hesabını bu iki gruptan birine dahil edersek, grupların buradaki yetkilerine göre bu kullanıcılar sudo komutunu kullanarak root yetkileri ile hareket edebilirler. 

Örneğin ben bu dosyayı açmak için sudo visudo komutunu kullanırken sorun yaşamadım çünkü benim kullanıcı hesabım sudo grubuna dahil. sudo komutunu girip kendi hesabımın parolasını girdiğimde burada belirtilen sınırlar dahilinde geçici root yetkileri ile istediğim komutu çalıştırabiliyorum. 

Hatta benim kullanıcı hesabımın sudo grubuna dahil olduğunu teyit etmek için grep "sudo" /etc/group komutu ile group dosyasına bakabiliriz. Bakın benim kullanıcı hesabım sudo grubunun bir üyesi olarak gözüküyor. İşte sizler de sudo yetkileri ile çalışmasına izin vermek istediğiniz kullanıcıları admin ya da sudo grubuna dahil edebilirsiniz.

Ayrıca bu noktada dikkatinizi çekmek istediğim bir husus var. Sizin kullandığınız dağıtımdaki sudoers dosyasında buradaki grubun adı admin veya sudo olarak geçmiyor olabilir. wheel grubu olarak da geçiyor olabilir. Debian tabanlı dağıtımlarda admin ve sudo tanımlı iken centos da wheel grubunu varsayılan olarak tanımlı görebilirsiniz. Ancak burada grup isminin bir önemi yok. Bir kullanıcıya sudo aracını kullanabilme izni vermek istiyorsanız tek yapmanız gereken, ilgili kullanıcıyı bu dosyada belirtilmiş olan gruba eklemektir. Yani burada varsayılan olarak tanımlı olan grubun ismine takılmayın, yetkilerine bakın ve istediğiniz kullanıcıyı dahil edin.

Ben denemek için sudo aracını kullanma yetkisi olamayan kullanici2 ye bu yetkiyi vermek üzere gruba eklemek istiyorum. Öncelikle kullanıcı2 nin sudo aracını kullanamadığını teyit etmek üzere su kullanici2 komutu ile geçiş yapalım. şimdi sudo ls komutu ile yetkili şekilde içerikleri listelemeyi deneyelim. Bakın daha önce root komutunda aldığımıza benzer bir hata aldık. Bunun nedeni kullanici2 nin sudo aracını kullanma yetkisinin olmamasıdır. Tek yapmamız gereken bu kullanıcıyı sudo ya admin grubuna dahil etmektir. Ben sudo grubuna dahil etmek istiyorum. Bunun için öncelikle sudo komutunu kullanabilen kendi hesabıma exit komutu ile dönmem gerek. Şimdi sudo usermod -aG sudo kullanici2 şeklinde gruba ekleyelim. gruba eklendiğini grep "sudo" /etc/group ile teyit edebiliriz. Bakın sudo grubunun üyesi olarak kullanici2 de eklenmiş. şimdi hesaba geçiş yapıp birde uygulamalı olarak test edelim. komutumu sudo ls şeklinde giriyorum, kullanıcı parolamı da girip onaylıyorum. ve evet gördüğünüz gibi ls komutunu sudo aracını kullanarak root yetkileri ile çalıştırmayı başardım. hatta istersem sudo whoami komutu ile bu durumu kesin olarak teyit de edebilirim. işte sudo aracını kullanma yetkisi vermek bu kadar kolay. sizler de yalnızca gerekli olan kullanıcılara bu yetkiyi vermek için onları sudo grubuna dahil edebilirsiniz.

Ancak elbette sudoers dosyasında sudo grubuna tüm yetkiler verildiği için kullanıcıları sudo dosyasına dahil etmek tehlikeli olabilir. dilersek ihitiyaçlarımıza göre farklı kısıtlamalar içeren bir grup da oluşturabiliriz. hatta tek bir kullanıcı için bile sudoers dosyasında kural tanımlayabiliriz.

## Özel Kural Tanımlama

Artık sudoers dosyasının genel sözdizimine aşina olduğumuza göre, ihtiyaçlarımıza göre bazı yeni kurallar oluşturabiliriz.

Örneğin istersek tek bir kullanıcı hesabı için kural tanımlayabiliriz. 

Bene denemek için kullanici1 e özel sudo kuralı tanımlamak istiyorum.

öncelikle kullanıcı adını yazıyorum daha sonra boşluk bırakıp tüm hostlarda geçerli olmasını istediğim ALL yazıp eşittir işaretini koyuyorum. Herhangi bir kullanıcı veya grup olarak komut çalıştırmasını istemediğim için parantez açıp içine hangi kullanıcılara veya gruplar olarak komut çalıştırabileceğini belirtmiyorum. Eğer siz tüm kullanıcı hesapları ve grupları gibi komut yürütebilmesini isterseniz ALL:ALL şeklinde belirtebilirsiniz. Ayrıca isterseniz ALL yerine istediğiniz kişi veya grupları da aralarına virgüller belirtebilirsiniz. Ben hiç birini istemediğim parantez açmıyorum. Eğer tüm komutları çalıştırmasını istersem son olarak ALL yazabilirim, ancak ben kullanici1 in yalnızca ls aracını root yetkileri ile çalıştırabilmesini istediğim için ls aracının tam dosya konumunu yazacağım. Dosya konumunu bilmediğim için which komutu ile öğrenmem gerekiyor. Bakın tam dosya dizin adresi buymuş. Bu dosya adresini kullanici1 in root yetkileri ile çalıştırabileceği komut bölümüne ekliyorum. Ben tek bir aracı ekledim ancak isterseniz virgülle ayırarak birden fazla aracı da ekleyebilirsiniz. Örneğin mkdir aracını da root yetkileri ile çalıştırmasını istersem mkdir aracının dosya konumunu da buraya ekleyebilirim. İşte bu şekilde istediğimiz kullanıcı hesabına istediğimiz araçları root olarak çalıştırabilme yetkisi verebiliriz. Kuralı kendi ihtiyacınıza göre istediğiniz şekilde özelleştirebilirsiniz. Ben bu kuralı denemek için öncelikle dosyadaki değişikliği kaydediyorum. şimdi kullanici1 e geçiş yapalım.

Ben öncelikle denemek için sudo whoami komutu ile whoami aracını root yetkileri ile çalıştırmayı deniyorum. Bakın hata aldık. Şimdi bir de sudo ls komutunu deneyelim. Bakın herhangi bir hata almadım. Çünkü ls komutunu kullanici1 için sudo kurallarına eklemiştim. 

İşte kullanımını bizzat teyit ettiğimiz şekilde dilerdiğiniz kullanıcıya dilerdiğiniz aracı root olarak çalıştırabilmesi için sudo kuralı tanımlayabilirsiniz.

Tek tek kullanıcı yerine yeni bir grup da tanımlayabiliriz. Grup tanımlarken, grubun isminin başında yüzde işareti koymanız yeterli. Bu sayede bu yazdığınız isminin kullanııc ismi değil grup ismi olduğu anlaşılabilir. 

Gruplar dışında birden fazla kullanıcıya ortak sudo kurallarını tanımlamak için istersek alias yapısından faydalanabiliriz. 

Daha önce kabuktaki alias yani takma isim yapısını öğrenmiş ve kullanmıştık. sudoers dosyasında da takma isimler kullanabiliriz. Örneğin ortak yetki alanına dahil etmek istediğimiz kullanıcıları takma isimler üzerinden tek bir kümede gruplayabiliriz. Daha sonra bu takma isime özel sudo kuralları tanımlarız. Böylelikle olası karmaşıklıkların da önüne geçmiş olur, daha okunaklı bir sudoers dosyası elde ederiz.

Hemen basit bir örnek yapalım. Ancak yazılış kuralları önemli. 

Kullanıcılar için alias tanımlamak tanımlamak üzere User_Alias şeklinde yazıyorum. Daha sonra büyük harfler ile kullanıcı grubuna bir takma isim veriyorum. Ben ILKGRUP şeklinde isimlendiriyorum ve boşluk bırakıp eşittir işaretinden sonra eklemek istediğim kullanıcıları virgüllere ayırarak yazıyorum. ben kullanici1 ve kullanici3 ü buraya ekledim.

ikinci kullanıcı aliası da belirtebilirm. IKINCIGRUP olarak isimlendirip bu kez de kullanici 2 ve kullanici 3 u bu gruba ekliyorum.

İşte bu şekilde istediğiniz ortak amaçlar doğrultusunda kullanılacak olan kullanıcıları takma isimler üzerinden gruplayabiliyoruz. Şimdi bu gruplara kural tanımlayalım. Örneğin ben ILKGRUP kullanıcıları için ls ve touch komutlarını root olarak kullanabilmeleri için tam dosya konumları ile kuralımı yazıyorum. 

İşte bu tanımlama sayesinde ILKGRUP takma ismine karşılık gelen tüm kullanıcılara için bu yetkiler geçerli olacak. Takma isim özelliği, sistemde çok fazla kullanıcı olduğunda belirli amaçlar doğrultusunda kullanıcılara ortak sudo kuralları tanımlamak için harika bir kolaylıktır. Ayrıca istersek kullanıcı adları dışında komutlar için de takma isim tanımlayabiliriz. Bu sayede araçların dosya isimlerini tekrar tekrar yazmamız gerekmez.

Örneğin ben ağ ile ilgili olan birkaç komutu tek bir takma isime tanımlayı bu takma isim üzerinden kural tanımlayabilirim. 

Komut için takma isim belirtirken Cmnd_Alias yazıp boşluk bıraktıktan sonra tamamı büyük harflerle olacak şekilde takma isim belirtmemiz gerekiyor. Ben NETWORK şeklinde beliriyorum. Eşittir işaretinden sonra hangi araçları istiyorsam onların dosya konumlarını virgüllerle ayırarak girmem gerekiyor. ifconfig ifdown ve ifup araçlarının dosya konumlarını which komutu ile öğrenip buraya yazalım. Evet bu sayede kural tanımlarken NETWORK takma adını kullandığımda bu araçların tamamı otomatik olarak tanımlanmış olacak. Hatta istersek birden fazla takma ismi de tek bir takma isime tanımlayabiliriz. Örneğin ben bir de WLAN isiminde bir komut aliası oluşturuyorum. Çalıştırılabilecek dosyalar olarak da iwconfig iwevent araçlarının dosya konumlarını öğrenip ekliyorum. Şimdi bu iki komut aliasını tek bir takma isime de tanımlayabilirim. Ben NETWORK-ADMIN adında bir alias daha tanımlıyorum ve eşittir işaretinden sonra bu komut aliaslarını yani NETWORK ve WLAN ı ekliyorum. Bu sayede kural tanımlarken NETWORK-ADMIN aliasını kullandığım otomatik olarak tüm bu araçları kapsıyor olacağım. 

Örneğin daha önce oluşturmuş olduğum IKICIGRUP aliasındaki tüm kullanıcılar için bu komut aliasları üzerinden kural tanımlaması yapabilirim.

IKINCIGRUP ALL eşittir NETWORK-ADMIN şeklinde yazdığımda takma isimlerin karşılık geldiği tüm araçlar otomatik olarak kurala dahil edilecek. Eğer istersem elbette yalnızca NETWORK ya da WLAN şeklinde de belirtebilirim. 

Zaten yapı son derece basit. Takma isim daha okunaklı bir dosya düzeni oluşturmakla beraber, bizin yazma tekrarından da kurtarıyor. 

Son bir alias dan daha bahsetmem gerek o da "runas" yani "olarak çalıştırma" takma isimi. Kural tanımlarken komutların belirtilen kullanıcı veya grup olarak çalıştırılması için parantez içinde tanımlama yapabileceğimizi belirtmiştim. İşte istersek bu kullanıcı isimlerini veya gruplarını da alias olarak tanımlayabiliriz.

Örneğin ben gerektiğinde komutların kullanıcı1 ve kullanıcı2 olarak yürütülebilmesi için Runas_Alias STANDART = kullanici1, kullanici2 şeklinde belirtiyorum. İstersek aynı şekilde kullanıcı isimleri yerine grup isimleri de belirtebiliriz.

Örneğin ben gerektiğinde kullanici3 ün komutları, kullanıcı1 ve kullanıcı2 olarak çalıştırabilmesini istersem kullanici3 ALL=(STANDART) şeklinde yazıyorum parantez içindeki alias kullanici3 ün komutları kullanici1 ve kullanici2 olarak çalıştırmasını sağlıyor. sondaki ALL ise tüm komutları kapsıyor.

İşte takma isimlerin kullanımı bu şekilde. Örnekleri çoğaltmak mümkün ancak zaten temel kullanımına değindik. Pratikler üzerinden takma isimlerin kullanımını deneyimleyebilirsiniz. 

### Etiketler Hakkında

sudoers dosyasında kullanabileceğimiz bazı özen anlamlara gelen etiketler vardır. örneğin kullanıcıya parola sorulmasını istemiyorsak NOPASSWD etiketini kullanabiliriz. Tek yapmamız gereken çalıştırılacak araçlardan önce NOPASSWD: etiketini eklemektir. Ben bu etiketi eklediğimde bu kullanıcıya buradaki araçları sudo ayrıcalıkları ile çalıştırırken parola sorulamayacak. Yine de bu etiketi kullanırken dikkatli olmalısınız. Çünkü araçları root olarak çalıştırırken şifre sorulmaması sistemin güvenliğini riske edebilir. Dilerseniz kullanıcıya bazı araçlar için şifre sorulup bazıları için sorulmamasını da ayarlayabilirsiniz. Örneğin ben yalnızca network aliasındaki araçlar için parola sorulmayıp, WLAN aliasındaki araçları kullanırken parolanın sorulmasını sağlayabilirim. parola sorulmamasını istediğim araçların başında yani NETWORK aliasının başına NOPASSWD: etiketini ekleyip, sorulmasını istediğim araçların başına yani WLAN aliasının başına da PASSWD: etiketini ekliyorum. Böylelikle network aliasının temsil ettiği bu araçlara parola sorulmayıp, wlan aliasının temsil ettiği araçları kullanırken sorulacak.

Parola sorma ile ilgili olan etiketler dışında araçların çalışmalarını kısıtlamak için NOEXEC etiketine de sahibiz. Bu etiket çok önemlidir. Örneğin, less gibi bazı araçlar, kendi arayüzündeyken ünlem işaretinden sonra yazılan komutların çalıştırılmasını sağlayabilirler. Örneğin biz bir kullanıcıya yalnızca less aracını sudo ayrıcalıkları ile çalıştırabilmesi için kural tanımlarsak, bu kullanıcı less aracı içinden root yetkileri ile istediği tüm komutları yürütebilir. Çünkü less aracı root yetkileri ile açılmıştır, less aracının içinden verilen komutlar da root yetkileri ile çalışır. Ben denemek için yeni kullanici5 isminde yeni bir kullanıcı oluşturuyorum. Bu kullanıcımın hiç bir yetkisi yok. Şimdi bu kullanıcı için sudo kuralı tanımlayıp less aracının dosyanı konumunu belirtiyorum. Böylelikle kullanici5 yalnızca less aracını root yetkileri ile çalıştırabilecek. Dosyayı kaydediyorum. Şimdi kullanici5 e geçelim. Ben denemek için öncelikle sudo whoami yazıyorum. Bakın yetkilendirme hatası aldım. Bir de sudo less komutunu .bashrc dosyasını okumak için kullanalım, bakın less aracı root yetkileri ile açıldı. Normalde bu araç dosya içeriklerini konsol üzerinden kolay görüntüleyebilmek için kullandığımız basit bir programdır. Ama bu programın bir de kendi içinden komut çalıştırma özelliği vardır. Komut çalıştırmak için ünlem işaretinin ardından çalıştırmak istediğim komutu giriyorum. Ben root yetkileri ile komut verebildiğimi teyit etmek için whoami komutunu giriyorum. Bakın root çıktısını aldık. Neticede yalnızca less aracını root olarak çalıştırma iznim olmasına rağmen root yetkileri ile istediğim komutu yürütebilir hale geldim. İşte bu sebeple hangi araçlara yetki verdiğimiz sistemin güvenliği için çok çok önemli. Hak yükseltme saldırıları da zaten bu gibi konfigürasyon hataları nedeniyle oluyor. Peki bu durumun önüne nasıl geçebiliriz? Yani less aracı ve benzeri araçlar için hiç kimseye sudo ayrıcalığı veremeyecek miyiz? elbette hayır. bahsetmiş olduğumuz noexec etiketi de tam olarak bu iş için kullanılıyor. noexec etiketini başına eklediğimiz araçların yalnızca kendisi root yetkileri ile açılıyor, aracın kendisi root yetkileri ile komut yürütemiyor. Hadi hemen deneyelim. Etiketi eklemek için sudoers dosyasını tekrar açıyorum. Şimdi kurala gelip aracın başına NOEXEC: etiketini yazıp dosyayı kaydediyorum. Şimdi tekrar less aracını sudo ile açıp tekrar komut girmeyi deneyelim. Bakın komutun çıktısını alamadık çünkü aracın komut çalıştrılıması NOEXEC etiketi sayesinde engellendi. İşte sizler de güvenliğini denetlemek istediğiniz kullanıcıların bu gibi araçlar üzerinden komut çalıştırmasını engellemek için NOEXEC etiketini kullanmalısınız.

Ayrıca tüm komutlara izin verip yalnızca birkaç komutu engellemek de isteyebilirsiniz. örneğin tüm araçlara izin verip yalnızca passwd aracının sudo ayrıcalıkları ile çalıştırılmasını önlemek için ALL, !/usr/bin/passwd şeklinde kural belirtebilirim.

Böylelikle sudo komutu ve sudoers kuralları hakkında bilmemiz gereken tüm temel detaylardan bahsetmiş olduk. Yani artık sudo ayrıcalarınlarına sahip olması gereken kullanıcıları ve bu kullanıcının hangi araçalar üzerinde bu sudo ayrıcalıklarını kullanabileceklerini tam olarak istediğiniz şekilde ayarlayabilecek kadar bilgiye sahipsiniz. Gerisi pratik yapıp sonuçlarını gözlemleye kalıyor. 

# Set-user Identification SUID ve Set-group identification SGID Bit’leri Anlamak

Hadi basit bir test yapalım. passwd komutunun yeni şifre tanımlamak ve var olan şifreleri değiştirmek için kullanıldığını biliyoruz. Şifre değiştirme işi de kesinlikle yetkili olmayı gerektirir. Çünkü passwd aracı yalnızca root kullanıcınsının düzenleyebileceği, şifrelerimizi tutan /etc/shadow dosyasında değişiklik yapar. Tekrar teyit etmek için ls -l /ets/shadow komutu ile yetkilerine göz atabiliriz. Bakın yalnızca dosyanın sahibi root ve bu dosyan yalnızca sahibi tarafından düzenlenebilecek şekilde yetkilendirilmiş. Dolayısıyla passwd aracını kullanmak için ya root olmamız ya da sudo gibi bir yapı ile geçici olarak root yetkileriyle hareket ediyor olmamız gerekir. 

Ancak bu durumun bir istisnası var. Örneğin ben kendi hesabımının parolasını değiştirmek istersem root kullanıcısı olmam ya da sudo ile geçici root yetkisi ile hareket etmem gerekmiyor. Hemen deneyelim. Ben kendi hesabımın parolasını değiştirmek için passwd yazıyorum. Bakın eski şifrem soruldu, eskisini ve yeni olanı belirleyip işlemi sonlandırıyorum. Bakın parolamı sorunsuzca değiştirdim. Bana hiç bir yetki sorulmadı. Yalnızca passwd yazdım ve aracı kullandım. Peki ben standart bir kullanıcı olarak başka bir kullanıcının şifresini değiştirmeye çalışsaydım ne olurdu ? Deneyip görelim. Ben kendi hesabımdayken kullanici1 hesabının parolasını değiştirmek üzere passwd kullanici1 şeklinde komutumu giriyorum. Bakın direk yetki hatası aldık. Çünkü diğer kullanıcı hesaplarının parolalarını yalnızca root değiştirebilir. Ben root kullanıcısı değilim dolayısıyla erişimim reddedildi. Eğer geçici olarak root yetkileri ile hareket etmek için sudo passwd kullanici1 şekline komutumu girersem. Bakın artık yeni şifre belirleyebiliyorum. sudo komutu benim için çalıştı çünkü benim hesabım sudo komutunu kullanabilecek yönetici hesabı sınıfındadır. 

Peki her önüne gelen sudo komutu ile istediği kullanıcının parolasını değiştirbiliyor mu ? Elbette hayır. Belirttiğim gibi sudo komutunu yalnızca yönetici olarak eklenen kullanıcılar kullanbiliyor. 

Her şey güzel ama kendi hesabımızın parolasını düzenlerken passwd aracını kullanarak aslında /ets/shadow dosyasında değişiklik yapmış olduk. shadow dosyası yalnızca root kullanıcı tarafından düzenlenebiliyorsa biz sıradan bir kullanıcı olarak nasıl bu dosyayı düzenleyebildik ?

İşte bu noktada devreye suid bit kavramı giriyor. Öncelikle ls -l /usr/bin/passwd komutu ile passwd aracının yetkilerine göz atalım. Bakın aldığım çıktıda dosyanın rengi kırmızı. Bu bizim dikkatimizi çekmek için. Yetkilerine baktığımda dosya sahibinin çalıştırma yetkisinin olması gereken yerde s karakteri bulunuyor. Buradaki s karakteri suid biti temsil ediyor. bu dosyanın herkes tarafından dosyanın sahibinin yetkileri ile çalıştırılmasını sağlıyor. bu dosya root kullanıcısının olduğu için bu dosyayı herkes root yetkisi ile çalıştırabiliyor. işte bu sayede biz kendi parolamızı değiştirirken yetki hatası almadık. dosyanın erişim izinlerinde suid bit olduğu için /usr/bin/passwd dosyasını herkes root kullanıcısının yetkileri ile açabiliyor.

Bu nokta ;da başka bir soru daha aklınza geldiğine eminim. Peki ama madem dosyayı herkes root yetkileri ile açabiliyor o zaman neden başka kullanıcıların parolalarını değiştirmeye çalışırken yetki hatası alıyoruz. işte burada da devreye /usr/bin/passwd aracı giriyor. siz dosyayı root yetkileri ile açtığınızda öncelikle sizin kullanıcı numaranıza bakıyor. eğer parolasını değiştirmek istediğini kullanıcı numarsı ile sizin numaranız eşleşiyorsa root yetkileri ile /etc/passwd dosyasında değişiklik yapılmış oluyor. Sizin kullanıcı numaranız ile parolasını değiştirmek istediğiniz kullanıcının numarası eşleşmediğinde ise istediğiniz passwd komutu tarafıdan reddeliyor. Bu durumun tek istisnası root kullanıcısı veya sudo komutu ile root kullanıcısı gibi hareket edebilen yönetici hesapladırı. 

işte suid bit çalışırken yetkiye ihtiyaç duyan dosyalara herkesin erşilebilmesi için kullanılan bir yetkilendirme çözümüdür. elbette herkese yetki verdiğmizde güvenlik riskleri ortaya çıkabileceği içinde bu yetkiyi verdiğimiz aracın passwd aracı gibi buna uygun olması gerekir. yoksa sistem üzerinde büyük bir zaafiyet ortaya çıkar.

sgid ise kullanıcı ile aynı grupta bulunan kişilere verilen yetkilerin herkes için geçerli olmasını sağlıyor. örnek olarak /usr/bin/wall dosyasının yetkilerini görüntüleyebiliriz. Bakın bu dosyanın grup yetkilerinde çalıştırma yetkisinin yerinde s karakteri bulunuyor. 

Eğer yetkilerde küçük s yerin büyük S görüyorsanız, ilgili dosya veya klasörün çalıştırılma yetkisi olmadığı anlamına gelir. Denemek içn ben passwd dosyasının çalıştırma yetkisini karlıdırıyorum. Benkın küçük s karakteri çalıştırma yetkisini kaldırdıktan sorna büyük S e dönüştü. neticede çalıştırma yetkisi üzerine s karakteri geldiği için gözükmüyor. ama küçük ve büyük s olmasından dosyanın veya klasörün çalıştırma yetkisi bulunup bulunmadığını öğrenebiliyoruz. 

Var olan dosyalardan basettik. Eğer biz atamak istersek chmod komutu ile 4 standart yetki tanımının en başın 4 rakamını ekleyebiliriz. 

### How to set SUID on a file?

`# chmod 4555 [path_to_file]`

### How to set GUID on a file?

`# chmod 2555 [path_to_file]`

## SUID/SGID biti aktif dosyaların bulunması

Güvenlik riski oluşturabileceği için sistemde bulunan aktif suid ya da sgid bitlerinin rutin olarak kontrol edilmesinde fayda var. Tümünü görmek için find komutundan faydalanabiliriz.

Ben aynı aynı listede hem kullanıcı bitlerini

[https://www.syslogs.org/suid-ve-sgid-bitler-ve-bu-bitlere-sahip-dosyalarin-bulunmasi/](https://www.syslogs.org/suid-ve-sgid-bitler-ve-bu-bitlere-sahip-dosyalarin-bulunmasi/)

find / \( -perm -u+s -or -perm -g+s \) -type f -exec ls -l {} \;

# Sticky Bit

Bu izin tek tek dosyaları etkilemez. Klasör seviyesindedir. Bir klasöre bu izin verildiğined klasör içindeki hiç bir dosya, dosyanın sahibi veya root istemediği sürece silinemez. Bu klasörün içindeki her bir dosya kendi izinlerine sahiptir. Sticky bit yalnızca bu dosyaların silinmesini önler. Sistemde en anlaşılır örneğin /var/tmp dizinidir. ls -ld /var/tmp komutu ile dizini yetkilerine bakmak üzere listeyebiliriz. 

Bakın diğer kullanıcıların çalıştırma yetkisinin bulunduğu bölümde sticky bit için karakter karşılılığı olan t bulunuyor. Eğer dizinin çalıştırma yetkisi olmasaydı büyük T ile gösteriliyor olacaktı.

Geçici dosyaların barındırıdlığı bu dizindeki tüm dosyaların birbirinden bağımsız yetkileri vardır. Kullanıcılar yetkileri dahilinde bu dosyalar üzerinde işlemler yapabilirler. Ancak dosyanın sahibi veya root olmayan hiç bir kullanıcı bu dosyaları silemez. 

- SUID = 4
- SGID = 2
- Sticky = 1

### How to set sticky bit permission?

`# chmod +t [path_to_directory]
or 
# chmod 1777 [path_to_directory]`

# su Komutu Hakkında

su komutu switch user yani kullanıcı değiştir ifadesinin kısaltmasından geliyor.

su komutu kendisinden sonra belirtilmiş olan kullanıcı hesabında mevcut konsol üzerinden oturum açmayı sağlar. örneğin ben konsola su kullanici1 yapıp parolamı girdiğimde kullanici1 in kabuğunda çalışmaya başlarım. bu durumu teyit etmek istersek /etc/passwd dosyasından kullanici1 in kabuğunu sh olarak değiştirebiliriz. ben test etmek için yönetici hesabıma dönüp kullanici1 in kabuğunu değiştireceğim. exit ile mevcut kullanıcı hesabından çıktıp kendi kabuğuma dönüyorum. sudo nano /etc/passwd komutu ile dosyayı açıyorum. kullanici1 satırının sonundaki kabuğu sh olarak düzenleyip dosyamı da kaydediyorum. evet şimdi tekrar su kullanici1 komutu ile kullanici hesabına geçiş yapabiliriz. çalışmakta olduğum mevcut kabuğu teyit etmek için echo $SHELL komutunu giriyorum bakın çıktıda sh kabuğu olduğunu görebiliyorum. işte böylelikle aslında su komutu ile hesaplar arasında geçiş yaptığımızda aslında geçiş yaptığımız kullanıcı hesabının kabuğundan çalışmaya başladığımızı da teyit etmiş olduk.

ayrıca fark ettiyseniz su komutu ile geçiş yaptığımızda kabuk değilse de mevcut bulunduğumuz dosya konumundan çalışmaya devam ediyoruz. eğer mevcut bulunduğumuz dizin yerine geçiş yapatığımız kullanıcının ev dizininden çalışmaya devam etmek istersek de komutumuzu su - kullanici adı şeklinde girebiliriz. Ben test etmek için su - kullanici2 şeklinde komutumu giriyorum. Bakın pwd komutu ile de rahatlıkla teyit edebildiğimiz gibi su komutuyla birlikte kullandığımız tire işareti sayesinde doğrudan kullanıcının ev dizinine geçiş yapmış olduk.

su - kullanımı ilgili kullanıcı oturum açmış gibi gerekli konfigürasyon dosyalarının okunmasını yani ortam değişkenleri gibi değerlere ulaşılabilmeyi sağlar. Zaten kabuktan bahsederken echo $0 komutunun çıktısı ile aldığımız -bash ifadesindeki tire işaretinin oturum açma kabuğunu temsil ettiğini söylemiştik. İşte biz su - kullanıcı adı şeklinde komutumuzu girdiğimizde ilgili kullanıcı için bir oturum açma kabuğu başlatılıyor. 

hangi dosyaların neden okuduğuna falan da değin. örneğin bash.bashrc ve profile dosyaları su - kullanıcı adında okunuyor

su - ifadesi oturum açma kabuğunu çağırdığı için profile dosyası da okunuyor. yani aslında buradaki ne tür shell çağırdığımızla ilgili bir durum söz konusu.

exit komutunu girdiğimzide ise geçiş yaptığımız kullanıcı hesabının kabuğunu kapattığımız için mevcut kullanıcı hesabımızın kabuğa dönmüş oluyoruz. hatta exit komutunun aslında mevcut kabuğu kapattığını teyit etmek için herhangi bir yeni konsol açıp exit komutunu girmeyi deneyebilirsiniz. bakın konsol anında kapanıyor çünkü konsolla beraber başlatılmış olan kabuğu exit komutu ile kapattığımızda konsolun bir işi kalmayıp kapanmış oldu.

# chattr

attrubutes özellikler anlamına geliyor. Dosyaların özniteliklerini değiştirmek için de change attributes ifadesinin kısalmasından gelen chattr komutunu kullanabiliyoruz.

Linux'taki chattr komutu, bir dizindeki bir dosyanın özniteliklerini değiştirmek için kullanılan bir dosya sistemi komutudur. Linux'ta dosya öznitelikleri, dosyanın davranışını tanımlayan meta-veri özellikleridir. Zaten bu pek çok dile getirdik. Dilersek dosyaların özniteliklerinden bazılarını istediğimiz şekilde değiştirebiliriz. chattr komutu da change attributes yani öznitelikleri değiştirmenin kısaltmasıdır. 

[https://linuxize.com/post/chattr-command-in-linux/](https://linuxize.com/post/chattr-command-in-linux/)

## **chattr**

Hepimizin başına mutlaka gelen ve çok can sıkıcı bir durum var. Bu durum yanlışlıkla silinen dosyalar. Her nasıl ve neden olursa olsun eğer önemli gördüğümüz dosyalar varsa bir şekilde silinmeden onları koruma altına almamız mümkün. Bizlere bu koruma imkanını veren komut `chattr` komutudur. Aslında `chattr` komutu bir tek silinmeye karşı korumuyor, genel olarak dosyanın değiştirilmesine(silme, değiştirme vs.) engel olmak amacıyla kullanılıyor. Yani bu komutumuz bir nevi ilgili dosyayı dokunulamaz kılıyor. Öyle ki herhangi bir yanlış durumda dosyanın kaybolmasına engel olmak adına **root kullanıcısının bile** değişiklik yapmasına imkan tanımıyor. Komutun kullanım alanına bir örnek daha vererek daha iyi anlamış olalım. Örneğin sistemde bir konfigürasyon dosyasını düzenlediniz ve sistemi yeniden başlattınız, fakat bir bakıyorsunuz ki düzenlediğiniz(değiştirdiğiniz) ayarlar kaybolmuş ve dosya eski haline dönmüş. İşte bu gibi durumlarda sistemin bile ilgili dosyaya müdahale etmesini engellemek için oldukça kullanışlı olan `chattr` komutunu kullanabiliyoruz.

Komutun kullanımı `chattr +i dosya_adı` şeklindedir. Hemen bir örnek yapalım.

Bu tür dosyaları listelemek için `lsattr` komutu kullanılıyor. Bizde dosyaların durumunu daha sonradan karşılaştırabilmek adına ilk olarak konsola `lsattr` komutunu verdik.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/13.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/13.png)

test.txt isimli dosyamızı `chattr +i test.txt` komutu ile koruma altına aldık.

Daha sonra bunu teyit etmek için `lsattr` komutunu kullandık.

Komutumuzun çıktısında görüldüğü gibi dosyamızın sol tarafında izinler kısmında `-i` şeklinde bir ifade var. İşte bu ifade dosyamızın artık düzenlenemeyecek olduğunun işaretidir. Dosyayı silmeye çalışarak bu durumu teyit ettik.

Eğer bu işlemi geri almak ve dosyamızı üzerinde değişiklikler yapılabilir hale getirmek istersek `chattr -i test.txt` komutumuzu kullanmamız yeterli olacaktır. Örneği aşağıda inceleyebilirsiniz.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/14.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/14.png)

Çıktıda da görüldüğü gibi hedef dosyamızın solundaki `-i` işareti yok olmuş. Dolayısıyla test.txt isimli dosyamızın artık eski halinde dönerek, düzenlenebilir forma girmiş olduğunu gördük. Ve dosyamızı silerek bu durumu teyit ettik.

[](14-%20Kullan%C4%B1c%C4%B1%20ve%20Grup%20Yo%CC%88netimi%2058629a017f47424aa80fc6cc758dcc69/Untitled%206b4dcf7e4d58456e860ee22849cbdaac.md)

chroot kavramı ?

chage geçerlilik süresini belirtme

umask

Linux Access Control Lists (ACLs)

Temel olarak bilmemiz gereken tüm kavramlardan bahsettik. Tüm ele aldığımız konular dışında PAM konusunu da internette araştırıp öğrenmenizi tavsiye ederim. Temel düzeyi aşmamak için ben ele almıyorum.

id komutu ?

finger user komutu ile ilgili kullanıcı hakkında bilgi alabiliyorsun. bunu ekleyip eklemeyeceğine karar ver.