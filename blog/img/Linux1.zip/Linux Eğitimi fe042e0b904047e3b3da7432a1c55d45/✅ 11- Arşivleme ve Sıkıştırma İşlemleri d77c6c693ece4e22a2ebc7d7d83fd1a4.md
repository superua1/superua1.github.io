# ✅ 11- Arşivleme ve Sıkıştırma İşlemleri

Bu bölümde dosya arşivleme, sıkıştırma ve sıkıştırılmış olan dosya arşivlerini açma gibi işlemleri ele alacağız. Zaten bu kavramlar sizlere yabancı gelmemeli zira daha önce hangi işletim sistemini kullanmış olursanız olun öyle ya da böyle mutlaka arşiv dosyaları karşınıza çıkmıştır. Genellikle yüksek boyutlu dosyaların sıkıştırılmasında veya veri kaybı olmadan güvenli transfer yapabilmek için ve bunlar gibi pek çok avantaj dolayasıyla arşiv dosyaları ile sıklıkla karşılaşıyoruz, karşılaşmaya da devam edeceğiz. Sırasıyla öncelikle dosyaları nasıl arşivleyebileceğimizden daha sonra ise sıkıştırma işlemlerinin nasıl yapıldığından bahsedeceğiz. Anlatıma arşiv dosyalarını nasıl oluşturabileceğimizi öğrenerek başlayabiliriz.

# Arşivlemek

Bir grup dosya veya klasörü tek bir arşiv dosyası içerisinde toparlamaya arşivleme diyoruz. Dosya transferlerinde veri kayıplarını önlemek ve dosyaları daha düzenli depolamak için arşivlere sıklıkla ihtiyacımız oluyor. Linux üzerinde arşiv işlemi için grafiksel arayüze sahip araçlar olmasına karşın, biz daha verimli olacağı için arşivlemeyi de komut satırı üzerinden gerçekleştiriyor olacağız. Komut satırından arşivleme işlemi için de tar aracını kullanabiliyoruz.

### tar Komutu

tar aracının ismi "Tape ARchive" ifadesinden geliyor. İsmi şu an için garip gelebilir ancak bu araç manyetik bantlar için arşiv oluşturmak üzere geliştirildiği için bu isim verilmiş. Bu ifadeyi arama motorunun görseller bölümünde arattığımızda manyetik bantların depolandığı pek çok arşiv odası resmi karşımıza çıkıyor. Zaten ismi de buradan geliyor. Akılda kalıcı olması için isminden bahsetmek istedim ancak isminin nerden geldiği çok da önemli değil. Neticede tar aracını kullanarak arşivler oluşturabiliyoruz.

Tar komutunu kullanarak arşiv oluşturmak için aracın c ve f seçeneklerini birlikte kullanmamız gerekiyor. c seçeneği create yani oluşturmak ifadesinin kısaltmasıyken, f seçeneği ise file ifadesinin kısalmasından geliyor. c seçeneği sayesinde arşiv dosyası oluşturmak istediğimizi belirtiyorken, f seçeneği sayesinde de oluşturulacak arşiv dosyasının ismini belirleyebiliyoruz.

Ben basit örnek olması için çeşitli metin dosyalarını ve resimleri arşive almak istiyorum. Örnek için boş dosyaları da kullanabiliriz, fakat ileride sıkıştırma işlemi de uygulayacağımız için kullanacağımız dosyaların içi dolu olursa sıkıştırma işleminden sonraki boyut farkını gözlemeyebiliriz. 

Ben arşivleme örnekleri sırasında linux hakkında dokümanlar paylaştığım linux-dersleri websitesinin github üzerindeki dosyalarını kullanmak istiyorum ancak elbette siz arşivlemek için istediğiniz türde dosyaları kullanabilirsiniz. 

```bash
taylan@virtualbox:~$ ls linux-dersleri-master/
bildirim.html  docs         fonts          img         js          menu.html  sw_sayfa.js
css            egitim.html  hakkinda.html  index.html  liste.html  README.md  sw_site.js
```

Bakın websitesinin tüm dosyaları burada bulunuyor. Ben alt klasörlerdekiler de dahil tüm dosya ve klasörleri tek bir arşiv dosyası içine almak istiyorum. Normalde arşivleme işlemi sonrası arşivlenen dosyaların boyutlarında bir değişiklik olmuyor. Çünkü biz özellikle belirtmediğimiz sürece arşivleme işlemi sırasında sıkıştırma yapılmıyor. Arşivleme işlemi, ilgili dosya ve klasörlerin tek bir arşiv dosyası altında toparlanmasını sağlıyor. 

Söylediğim bu durumu teyit etmek için arşivleme işleminden önce klasörün kapladığı disk boyutunu öğrenmek üzere `du -h linux-dersleri` şeklinde komutunu girmek istiyorum. `du` komutu sayesinde hedef gösterdiğim klasörün alt dizinleri de dahil toplam boyutunu okunaklı şekilde öğrenebiliyoruz. 

```bash
taylan@virtualbox:~$ du -h linux-dersleri-master/
1,1M	linux-dersleri-master/fonts
240K	linux-dersleri-master/js
..
..
63M	linux-dersleri-master/
```

Bakın çıktının sonunda toplam boyut belirtiliyor. Artık arşivleme işleminden sonra arşiv dosyasının boyutu ile orijinal klasörün boyutunu kıyaslayabiliriz. Şu an yalnızca arşivleme işlemi yapacağımız için zaten herhangi bir sıkıştırma işlemi uygulanmayacak ve arşiv dosyasının boyutu mevcut klasör ile aynı olacak. Hemen arşivleyip bizzat görelim.

Arşivlemek için tek yapmamız gereken tar -cf komutundan sonra oluşturulacak arşiv dosyasının ismini belirtmek. Ben linux-dersleri.tar şeklinde yazıyorum. Şimdi bir de hangi dosyaların arşiv içerisine ekleyeceğini belirtmemiz gerekiyor. Ben linux-dersleri klasörü altındaki tüm dosyaları arşiv dosyasına eklemek istediğim için klasörün ismini giriyorum.

```bash
tar -cf linux-dersleri.tar linux-dersleri-master/
```

Bu komut sayesinde buradaki klasörün içindeki tüm dosya ve klasörler mevcut dizinde linux-dersleri.tar isimli bir arşiv dosyasına alınmış olacak.

Belki burada dosya isminin sonuna eklediğim tar uzantısının şart olup olmadığı kafanıza takılmıştır. Dosya isminin sonuna eklemiş olduğum tar uzantısı, tar aracının standart arşiv uzantısıdır. Zorunda değilsiniz ancak sistem üzerinde arşiv dosyalarınızı ayırt edici kılmak için mutlaka bu dosya uzantısını da ismine eklemenizi tavsiye ederim. Dosya uzantısını eklemesiniz de arşiv dosyası olarak kullanabilirsiniz ancak daha sonra dosyaları listelediğinizde tar uzantısı sayesinde arşiv dosyasını ayırt etmeniz daha kolay olur. Zaten benzeri durumdan kabuk genişletmeleri bölümünde bahsetmiştik. Düzenli sistem yönetimi için bu tip detaylar önemli. Örneğin sonu tar ile biten dosyaları listele diyerek, tüm tar arşivlerini bir çırpıda listeleyebileceğinizi düşünün.

Ben arşivlemek için komutumu onaylıyorum. Ekranda herhangi bir çıktı belirmese de arkaplanda dosyalar arşivlendi. Hemen bulunduğumuz dizini ls komutu ile tekrar listeleyelim. Bakın arşiv dosyası tam da benim belirttiğim isimde oluşturulmuş. 

Üstelik gördüğünüz gibi renk olarak da ayırt edici şekilde listelendi. Her zaman renkli çıktı almayabiliriz. Renk dışında zaten .tar uzantısı arşiv dosyasını diğer dosyalardan kolay ayırt edebilmemizi sağlıyor. Bu durumu teyit etmek için ls *.tar komutunu da kullanabiliriz. Bakın yalnızca tar uzantılı olduğu için arşiv dosyasını kolayca filtreleyebildik. 

Ayrıca du -hs linux-dersleri* komutu kullanarak, arşiv dosyası ile orijinal klasörün boyutlarının neredeyse aynı olduğuna dikkatinizi çekmek istiyorum. 

```bash
taylan@virtualbox:~$ du -hs linux*
63M	linux-dersleri-master
62M	linux-dersleri.tar
```

Arşiv dosyasının boyutunda dikkate değer bir küçülme olmadı çünkü henüz bir sıkıştırma işlemi uygulamadık.

Neticede gördüğünüz gibi arşivleme işlemi son derece kolay. Şimdi arşivler hakkında bilmemiz gereken diğer bilgilerden bahsederek devam edelim. Örneğin ben arşiv oluştururken arşivleme işlemini konsol üzerinden takip etmek istemediğim için verbose seçeneğini komutumla birlikte belirtmemiştim. Eğer tüm arşivleme işlemini konsol üzerinden adım adım takip etmek istiyorsak pek çok komutta olduğu gibi verbose özelliği ile detaylı şekilde çıktı almak istediğimizi belirtebiliriz. Ayrıca ben bir önceki örnekte klasörü arşiv içine ekledim fakat dilerseniz istediğiniz kadar dosyayı arşive alabilirsiniz. Örnek olması için ben touch {a..z} komutu ile a dan z ye kadar isimlendirilmiş dosyalar oluşturuyorum. Şimdi bu dosyaları arşive almak istersek arşive alınacak dosyaların isimlerini belirtmemiz yeterli. Belirtirken de yine kabuk genişletmesini kullanabiliriz. Yani örneğin  tar -cvf alfabe.tar {a..z} komutu ile tüm dosya ve dizinlerin arşive alınmasını da sağlayabilirim.  Buradaki verbose seçeneğinin kısaltması olan v seçeneği sayesinde tüm arşivleme adımlarını konsol üzerinden takip edebileceğiz. Komutumuzu onayalım. 

```bash
taylan@virtualbox:~$ tar -cvf alfabe.tar {a..z}
a
b
c
..
..
y
z
```

Bakın tüm arşivleme işlemi konsola çıktı olarak adım adım bastırıldı. Bu şekilde istediğimiz kadar dosya ve klasörü tek bir arşiv altında toparlayabiliyoruz. 

Mesela benzer şekilde klasörü arşive alırken de verbose seçeneği ile çıktıları takip edebiliriz. Bunun için tar -cvf arsiv2.tar linux-dersleri şeklinde komutumuzu girmemiz yeterli. Bakın, çıktılara baktığımızda en başta arşivlemek için hedef gösterdiğimiz dizin olmak üzere sırasıyla tüm alt dizinlerin adım adım arşive eklendiğini görebiliyorum. Yani arşivleme işleminde klasör düzeni aynen korunuyor. Belki benim örnek için kullandığım klasör gibi olan küçük boyutlu dosyalar için ayrıntılı çıktı özelliği pek önemli olmasa da özellikle büyük boyutlu dosyaların arşivlenmesi sırasında işlemi konsol üzerinden takip edebilmek adına verbose seçeneği oldukça rahatlık sağlıyor. Yoksa uzun süren arşivleme işlemlerinde, işlemin duraksadığı yanılgısı oluşabiliyor. 

Tamamdır, arşiv dosyasını nasıl oluşturacağımızı gördük. 

Ben şimdi oluşturduğum arşiv dosyasının içeriğini, arşiv dosyasını dışarı çıkarmadan görüntülemek istiyorum. Bunun için tar komutunun t seçeneğini kullanabiliriz. Arşiv dosyasının ismini yazacağımız için ayrıca -f seçeneğini de kullanmamız gerekiyor yoksa komut başarısız olacak. Hemen denemek için ilk oluşturduğum linux-dersler.tar arşiv dosyasını okumak üzere tar -t linux-dersleri.tar şeklinde komutumu giriyorum.

Bakın -f seçeneğini komutuma eklemediğim için arşiv dosyasının içeriği okunamadı. Şimdi komutumuza -t seçeneğine ek olarak -f seçeneğini de ekleyip tekrar girelim. 

İlk oluşturduğum arşiv dosyasının içeriğini görüntülemek için tar -tf linuz-dersleri.tar komutunu giriyorum. Bakın bu kez sorunsuzca arşiv dosyasının tüm içeriği sırasıyla hiyerarşik düzende konsola bastırıldı. 

Yani bizzat teyit ettiğimiz gibi, tar aracının t seçeneği sayesinde arşiv dosyasının içeriğini arşiv dosyasını dışarı çıkarmadan da rahatlıkla listeleyebiliyoruz. Hatta daha ayrıntılı bir listeleme yapmak istersek t seçeneğine ek olarak verbose seçeneğinin kısaltması olan v seçeneği de komutumuza ekleyebiliriz. Hemen deneyelim. 

Bakın bu kez tıpkı ls komutunun -l seçeneğini kullandığımızda olduğu gibi, arşiv dosyasının içindeki dosyaların yetkileri, sahibi, grubu ve benzeri diğer tüm özellikleri yani ayrıntılı listesini almış olduk. Üstelik arşiv dosyasını dışarı çıkarmamız da gerekmedi. 

Arşiv dosyasının içeriğini listeleme özelliği sayesinde spesifik olarak aradığımız bir dosya varsa arşivi dışarı çıkarmadan da konsol üzerinden rahatlıkla kontrol edebiliyoruz. Ben örnek olarak index isimli bir dosya var mı diye kontrol etmek üzere komutunun sonuna | grep index şeklinde eklemek istiyorum. 

```bash
taylan@virtualbox:~$ tar -tvf linux-dersleri.tar | grep index
-rw-rw-r-- nil/nil       16610 2022-05-23 21:05 linux-dersleri-master/index.html
```

Bakın arşiv içindeki index.html dosyası karşımıza geldi. Yani ihtiyacımıza yönelik olarak grep aracını tar aracı ile birleştirip istediğimiz sonucu elde edebildik. Neticede konsol üzerinden aldığımız çıktılar akış halindeki verilerden ibaret. Bu metinsel verileri daha önce öğrendiğiniz manipülasyon ve filtreleme yöntemleri ile istediğiniz şekilde biçimlendirmek yani ihtiyaçlarınıza yönelik çözümleri bulmak tamamen bizim elimizde.

Böylelikle nasıl arşiv oluşturabileceğimizi ve arşiv içeriğini görüntüleyebileceğimizi ele almış olduk. Şimdi de arşiv dosyasının içeriğini nasıl dışarı çıkarabileceğimizden bahsedelim.

# Arşivi Dışarı Çıkarmak

Arşivden çıkarma yaparken temelde iki farklı seçeneğe sahibiz. Birincisi arşiv içeriğinin tamamını dışarı çıkarmak, diğer ise spesifik olarak belirttiğimiz bazı dosya ve klasörleri dışarı çıkarmak. Öncelikle tüm dosya içeriğini dışarı çıkarmayı deneyelim. Çıkarma işlemi için extract seçeneğinin kısalması olan -x seçeneğini kullanıyoruz.

Eğer yalnızca bu seçeneği kullanırsak, arşiv dosyasının içeriği mevcut bulunduğumuz dizine çıkarılacak. Bu sebeple ben öncelikle arşivi çıkaracağım “linux” isminde yeni bir klasör oluşturmak istiyorum. 

```bash
taylan@virtualbox:~$ mkdir linux
```

Tamamdır şimdi arşiv içeriğini buraya çıkarmak için `tar -xf linux-dersleri.tar -C linux/` şeklinde komutumuzu girelim. Eğer buradaki büyük -C ile hedef arşiv içeriğinin çıkarılacağı hedef dizin belirtmezsek, arşiv dosyası mevcut dizine çıkarılıyor. Bu sebeple spesifik dizin belirtirken -C seçeneğini kullanmamız gerekiyor. Komutumuzu girip sonuçlarına bakalım, daha sonra diğer alternatif yaklaşımlardan bahsedeceğim.

Evet komutumlar birlikte arşiv dosyası dışarı çıkarıldı, ls komutu ile de bizzat teyit edebiliyoruz. Bakın arşiv içine aldığımız klasör burada bulunuyor. Klasör içeriğini de listeleyelim. Tüm arşiv içeriğinin sorunsuzca çıkarıldığını buradan görebiliyoruz. 

İşte  arşiv dosyasının tüm içeriğini dışarı çıkarmak bu kadar kolay. Şimdi birkaç ayrıntıdan daha bahsetmek istiyorum. Örneğin arşiv dosyasını spesifik bir hedef dizine çıkarmak için büyük -C seçeneğini kullanmak size pek akılda kalıcı ve pratik gelmediyse iki farklı alternatif yaklaşımla da arşiv içeriğini istediğiniz bir dizine çıkarabilirsiniz.

İlk yaklaşım, arşiv dosyasının içeriğini çıkarmak istediğimiz dizine geçiş yapıp çıkarma işlemini bu dizin içinden gerçekleştirmek. tar aracı, arşiv içeriğini varsayılan olarak komutun girildiği dosya konumuna çıkardığı için biz hangi dizin içindeysek arşiv içeriği de bu dizine çıkarılabiliyor. Örneğin ben linux klasörü içine çıkarmak istediğim için cd linux komutu ile öncelikle bu dizine geçiş yapıyorum. Şimdi tek yapmam gereken çıkarmak istediğim arşiv dosyasın belirtmek. Örneğin bir üst dizinde olduğu için tar -xf ../linux-dersleri.tar şeklinde komut girebilirim ya da kesin yolu belirtmek için tar -xf /home/taylan/linux-dersleri.tar komutunu da kullanabilirim.

```bash
taylan@virtualbox:~/linux$ tar -xf ~/linux-dersleri.tar 
taylan@virtualbox:~/linux$ ls
linux-dersleri-master
```

Bakın arşiv dosyasının içeriği mevcut bulunduğu dizine çıkarıldı. Örneğin ben Documents dizini altına çıkarılsın istersem öncelikle cd Documents komutu ile dizine geçiş yapıp yine aynı şekilde komutumu kullanabilirim. Burada tek yaptığım, çıkarılacak arşiv dosyasının tam dizin adresini eksiksiz şekilde belirtmek. Bunu yaptığımda zaten tar aracı -x seçeneğinin varsayılan davranışı olarak mevcut bulunduğum dizin altına bu arşiv içeriğini çıkarıyor.

Diğer alternatif yöntem ise dışarı çıkarmak istediğimiz arşiv dosyasını hangi dizine çıkaracaksak o dizine taşıyıp o dizinde dışarı çıkarmak. Örneğin ben Documents dizini altında çıkarmak istiyorsam, öncelikle mv komutu ile arşiv dosyasını buraya taşıyıp daha sonra bu dizine geçiş yapabilirim. Şimdi tek yapmam gereken tar -xf linux-dersleri.tar komutu ile arşiv dosyasını buraya çıkarmak. Bakın dosya içeriğini bu yöntemle de istediğimiz dizine çıkarmayı başardık.

Şimdiye kadar örneklerimde hep arşiv dosyasının tüm içeriğini dışarı çıkarmayı ele aldım ancak her zaman tüm içeriği çıkarmak istemeyebiliriz. Bu durumda istediğimiz dosya veya klasörleri seçip, yalnızca bunların dışarı çıkarılmasını da sağlayabiliriz. Bu işlemden önce dışarı çıkardığımı şu klasörü silelim çünkü yenisi gelecek. Silmek için rm -r linux-dersleri-master şeklinde komutumuzu girebiliriz. Bakın tab ile otomatik tamamlama sayesinde uzun uzadıya yazmaktan kurtuluyoruz, büyük kolaylık gerçekten. 

Şimdi konumuza dönecek olursak öncelikle -t seçeneği ile arşiv dosyasının içeriğini listeleyelim. Bakın burada websitesine ait bazı dosya ve klasörler var. Ben hepsini dışarı çıkarmak istemiyorum. Yalnızca index.html dosyasını, css dizini altındaki style.css dosyasını ve js klasörünün tamamını dışarı çıkarmak istiyorum. Bunun için buradaki çıktılarda aldığım dosya ve dizinlere ait olan tam ismi belirtmem yeterli. Yani örneğin index.html dosyasını çıkarmak için linux-dersleri-github-io-master klasörünü de belirtmem gerekiyor çünkü dışarı çıkarmak istediğim bu dosya, arşiv içinde tam olarak bu dizin atlında tutuluyor. Benzer şekilde diğer tüm dosyalar da benim arşivimde alt klasörlerde tutuluyorlar.

Örneğin tar -xf linux-dersler.tar index.html /js /css/style.css şeklinde komutumu yazarsam başarısız olacağım. Hemen deneyelim. 

Bakın belirttiğim dosya ve dizinlerin arşiv içinde bulunamadığına dair uyarı aldım çünkü gerçekten de burada yazdığım şekilde tutulmuyorlar. Bu duruma çözüm olarak tek tek tüm dosya yolunu her bir dosya için belirtebilir ya da daha önce öğrendiğimiz dosya ismi genişletme karakteri olan yıldız karakterinden faydalanabiliriz. Ben bu yolu tercih edeceğim. Denemek için bu kez komutumu tar -xf linux-dersleri.tar *index.html */js */css/style.css şeklinde giriyorum.

Bakın bu kez de dosya isimlerinde örüntü işleme karakteri kullandığımızı ama —wildcards seçeneği ile bu karakterlerin geçerli olmasını sağlayacak wildcards özelliğini aktifleştirmediğimizi belirten bir çıktı aldık. Yani dosya ismi genişletmesi için yıldız joker karakterini kullanacaksak komutumuza —wildcards seçeneğini de eklememiz gerekiyor. Bu seçeneğini de ekleyelim.

```bash
tar --wildcards -xf linux-dersleri.tar *index.html */js */css/style.css
```

Tamamdır. Ben içerikleri mevcut bulunduğum dizine çıkarmak istediğim için komutumu bu şekilde onaylıyorum. 

Bakın herhangi bir hata almadık.

Komutumun ardından tam olarak istediğim dosya ve klasörlerin çıktığını teyit edebilmek için klasör içeriğini özyinelemeli olarak bastırmak üzere ls -R linux-dersleri-master şeklinde komutumu giriyorum. Bakın tüm arşiv dosyasının içeriği değil, yalnızca benim belirtmiş olduğum dosya ve klasörler dışarı çıkarılmış.

Sizler de bu şekilde spesifik olarak dışarı çıkarılmasını istediğiniz içerikleri belirtebilirsiniz. Dışarı çıkarma işleminde dikkat etmeniz gereken tek husus, çıkarmak istediğiniz dosyanın veya dizinin arşiv içindeki tam adresini belirtmeniz. 

Arşivleme konusunda son olarak mevcut arşiv içeriğine nasıl yeni dosya ekleyip çıkarabileceğimizden bahsetmek istiyorum. Daha sonra sıkıştırma işlemlerinden bahsedebiliriz.

Ben örnek olması için öncelikle var olan arşiv dosyamın içerisine yeni bir dosyayı daha eklemek istiyorum.

# Arşive Yeni Dosya Eklemek

Arşive yeni dosya eklemek için öncelikle yeni bir dosya oluşturalım. Basit şekilde içeriği dolu bir dosya oluşturmak için echo “deneme” > metin.txt şeklinde komutumu girebilirim. Dosyamı oluşturdum. Bu dosyayı mevcut arşive eklemek için de -r seçeneğini ya da uzun haliyle —append seçeneğini kullanabilirim. Ben daha akılda kalıcı olduğu için —append yani ekleme seçeneğini tercih ediyorum. Dosyamı eklemek için komutumu tar —append -f linux-dersleri.tar metin.txt şeklinde giriyorum. Dosyamın arşive eklenmiş olması lazım. Teyit etmek için tar -tf linux-dersleri.tar komutu ile arşiv içeriğini listeleyelim. Bakın yeni eklediğim dosya burada, yani yeni dosya eklemeyi başardık. Benzer şekilde klasör de ekleyebiliriz. Ben denemek için mkdir metinler komutu ile yeni bir klasör oluşturuyorum. Şimdi bu klasör içine içine dosya eklemek için touch metinler{a..d} şeklinde komutumuzu girebiliriz. Bakın dosyalar oluşturuldu. Şimdi bu klasörü arşiv dosyasına eklemek için yine aynı şekilde append seçeneğini kullanabiliriz. Ben eklemek için tar —apend -f linux-dersleri.tar metinler/ şeklinde komutumu giriyorum. Şimdi eklenip eklenmediğini görmek için tar -tf linux-dersleri.tar komutunu da girelim. Bakın gördüğünüz gibi klasörü de sorunsuzca eklemeyi başardık.

Bu şekilde bir veya birden fazla dosya ve klasörü bir arşiv içerisine istediğiniz zaman ekleyebiliyoruz. Tek yapmamız gereken, eklemek istediğimi dosya veya dizinin tam adresini belirtmek.. 

Ekleme işlemini gördük, şimdi de var olan bir dosyayı nasıl arşivden silebileceğimizi ele alalım. 

# Arşivden Dosya Silmek

Arşivdeki bir dosyayı silmek için de —delete seçeneğini kullanıyoruz. Bu seçeneğin kısaltması yok, zaten bu şekilde daha akılda kalıcı bir seçenek.

Ben arşive en son eklemiş olduğum metin.txt dosyasını silmek istediğim için komutumu tar -f arsiv.tar —delete metin.txt şeklinde giriyorum. Şimdi tekrar tar -tf linux-dersleri.tar komutu ile arşiv dosyasının içeriğini listeleyelim.

Bakın en son eklemiş olduğum metin.txt dosyası arşivden silinmiş bulunuyor.

Mesela ben silme seçeneğini yani —delete seçeneğini sonda kullandım ama istersek başta da kullanabiliriz. Ben bu kez en son eklediğim klasörü silmek için tar —delete -f linux-dersleri.tar metinler/ şeklinde komutumu giriyorum. tar -tf linux-dersleri.tar komutu ile içeriği tekrar listeleyelim. Bakın arşiv içindeki klasörü bu şekilde de silmeyi başardım.

Bence tüm işlemler son derece kolay. Burada öğrendiklerinizle konsol üzerinden kendi arşivlerinizi oluşturup içeriğini dilediğiniz gibi düzenleyerek gerektiğinde arşiv içeriğini dışarı aktarabilirsiniz. 

Pratik yaptıkça zaten kolaylıkla alışacaksınız. 

Neticede arşivleme hakkında bilmemiz gereken tüm temel pratikleri öğrendik. Arşivleme işlemi tek başına son derece kullanışlı olsa da, sıkıştırma işleminin sağladığı avantajlar dolayısıyla çoğu zaman arşivleri sıkıştırmaya da ihtiyacımız oluyor. Şimdi anlatımlarımıza sıkıştırma işlemlerinden bahsederek devam edelim.

# Sıkıştırma

Çeşitli teknikler uygulanarak verilerin geri döndürülebilir ve depolama alanından tasarruf sağlayacak biçimce sıkıştırılması işlemine genel olarak sıkıştırma deniyor. Sıkıştırmadan yararlanmak için, sıkıştırma işleminin teknik olarak nasıl çalıştığını bilmemiz gerekmiyor. 

Zaten burada tek bir sıkıştırma algoritmasından da bahsetmeyeceğimiz için teknik ayrıntıların içinden çıkamayız. Pek çok alternatif var dedik, elbette her birinin de kendi içinde avantaj ve dezavantajları olduğu için hangi sıkıştırma yönetimini kullanacağınız tamamen ihtiyaçlarınızın ne olduğuyla ilgilidir. Biz öncelikle Linux üzerinde en yaygın kullanıma sahip olan gzip ve bzip2 sıkıştırma algoritmalarından bahsederek başlayalım.

Sıkıştırma algoritmalarını dosyalarımız üzerinde kullanabilmemiz için algoritmaların isimleriyle temsil edilen çeşitli araçlar bulunuyor. Örneğin gzip algoritmasını kullanmak için gzip isimli aracı kullanıyorken bzip2 algoritması için de bzip2 isimli aracı kullanabiliyoruz.

Ben burada gzip ve bzip2 algoritmaları için en yaygın kullanıma sahip temel araçlardan bahsettim ancak benzer şekilde sıkıştırılmış arşivleri açan pek çok alternatif araçla karşılaşabilirsiniz. Örneğin gzip algoritması için paralel olarak çalışabilen pigz gibi bir aracı da kullanabilirsiniz. Neticede bizim için önemli olan, ilgili algoritmayı kullanabilmemize olanak tanıyacak aracın bulunuyor olması. Ben tüm araçlardan ve kullanımlarından bahsetmeyeceğim. Temelde zaten hepsi benzer şekilde çalıştığı için alternatif araçları kullanmak için kısaca yardım sayfalarına göz atmanız yeterli. 

Gelin şimdi gzip aracı ile daha önce oluşturduğumuz bir arşiv dosyasını sıkıştırmayı deneyelim. 

# Gzip

Ben daha önce oluşturduğum arşiv dosyasını sıkıştırmak istiyorum.

Öncelikle arşiv dosyasının sıkıştırılmadan önceki boyutunu öğrenmek için ls -lh linux-dersleri.tar komutunu girelim. Bakın şu anda arşiv dosyamın boyutu bu kadarmış. Şimdi sıkıştırıp dosya boyutundaki değişimi kıyaslayalım. Dosyaları sıkıştırmak için tek yapmamız gereken gzip komutundan sonra sıkıştırılmasını istediğimiz dosya veya dosyaları belirtmek. Örneğin benim daha önce oluşturmuş olduğu arşiv dosyasını sıkıştırmak için gzip linux-dersleri.tar şeklinde komut girmem yeterli. Bu komutun neticesinde mevcut arşiv dosyası sıkıştırılacak ve isminin sonuna gz uzantısı eklenecek. 

Hemen ls -lh komutu ile mevcut dizini listeleyelim. Bakın linux-dersleri.tar isimli arşiv dosyamın linux-dersleri.tar.gz olarak değiştiğini ve önceki boyutu ile kıyasladığımda bir miktar sıkıştırıldığını da teyit edebiliyorum. Bakın önceki boyutu bu kadardı, sıkıştırıldıktan sonraki boyutu ise bu kadar. Neticede arşiv dosyamı gzip aracı ile sıkıştırmış oldum.

Bu arada yanlış anlaşılma olmasın yalnızca arşiv dosyası sıkıştırmak zorunda da değiliz. İstediğimiz türdeki bir veya birden fazla dosyayı sıkıştırmamız da mümkün. Örneğin ben denemek için bir resim dosyasını sıkıştırmayı da deneyebilirim. Dosya boyutu küçük olduğu için muhtemelen çok küçük bir miktar sıkıştırma yapılacak ancak örnek olması için deneyebiliriz. Ben yine websitesi dosyalarında bulunan resim dosyasını sıkıştırmayı deneyeceğim. Örnek üzerinde kullanmak üzere resimlerin bulunduğu dizinden bir dosyayı ana dizinime kopyalamak istiyorum. ls -lh linux.jpg komutu ile dosyanın boyutunu da öğrenelim. Tamamdır, şimdi bu dosyayı sıkıştırmayı deneyebiliriz. 

Bir önceki örnekte de bizzat şahit olduğunuz gibi gzip aracı sıkıştırma işlemini orijinal dosya üzerinde yapıyor. Yani sıkıştırma işlemi sonucunda geriye yalnızca sıkıştırılmış dosya kalıyor. Ancak gzip aracının dosyayı sıkıştırırken orijinal dosyayı kullanıyor olmasını kimi zaman istemeyebiliriz. Ben hem orijinal dosya korunsun hem de sıkıştırılmış bir versiyonu oluşturulsun istediğim için -k seçeneği ile keep yani orijinal dosyanın “korunması” özelliğini de aktifleştirmek istiyorum.

Bunun için komutumu gzip -k resim-dosyası şeklinde giriyorum. Sıkıştırma anında tamamlandı. Şimdi ls -lh komutu ile mevcut dizinimizi listeleyelim. 

Bakın orijinal dosya ve sıkıştırılmış versiyonu karşımıza çıktı. Yani keep seçeneği sayesinde orijinal dosyanın korunmuş olduğunu görebiliyoruz. Ayrıca çıktılara baktığımızda çok küçük bir miktar da olsa, resim dosyasının artık eskisinden daha az alanı kapladığını ve dosya isminin sonuna sıkıştırıldığını belirten .gz uzantısının da eklenmiş olduğunu teyit edebiliyoruz. İşte sizler de tıpkı bu iki örneğimizde olduğu şekilde istediğiniz türdeki dosyaları sıkıştırabilirsiniz. 

Ayrıca ben örnekleri hep tek bir dosya üzerinden gösterdim ancak sizler aynı anda birden fazla dosya ismini belirterek çoklu şekilde sıkıştırılmalarını da sağlayabilirsiniz. Sıkıştırma işlemi bu şekilde.

## Sıkıştırılmış Dosyaların Açılması

Sıkıştırmış olduğumuz dosyaları açmak yani tekrar önceki haline çevirmek için de tek yapmamız gereken decompress ifadesinin kısalması olan -d seçeneğini kullanmak. Örneğin ben daha önce sıkıştırmış olduğum arşiv dosyasını eski haline getirmek için gzip -d linux-dersleri.tar.gz şeklinde komutumu giriyorum. ls -lh ile dizinimizi bir daha listeleyelim.

Bakın sıkıştırmış olduğum arşiv dosyası sonundaki .gz uzantısı da silinerek eski boyutuna genişletilmiş oldu. Yani aslında sıkıştırmış olduğumuz dosyayı -d seçeneği sayesinde sorunsuzca eski haline getirmiş olduk.

Ben örneklerimde kullanmadım ancak işlemleri takip etmek için isterseniz verbose seçeneğinin kısalması olan -v seçeneğini de komutunuza ekleyebilirsiniz. Bir sonraki örneğimizde verbose seçeneğini de kullanabiliriz.

Eğer bir dizin altındaki tüm dosyaları teker teker sıkıştırmak istiyorsanız recursively ifadesinin yani özyinelemeli ifadesinin kısalmasından gelen -r seçeneğini kullanabilirsiniz. Örneğin ben website dosyalarının her birinin ayrı ayrı sıkıştırılmasını istediğim için gzip -rv websitesi şeklinde klasörün ismini giriyorum. Buraya v seçeneğini eklediğim için tüm işlemi konsol üzerinden takip edebiliyor olacağız. Komutumu onaylıyorum. Bakın sırasıyla hiyerarşik biçimde tüm dosyalar teker teker sıkıştırılıyor ve sıkıştırılma oranlarını da burada görebiliyoruz. İlgili dosya sıkıştırıldıktan sonra sıkışmış versiyonuyla da değiştiriliyor. İşlem bitti. Şimdi dosya içeriğini ls -R komutu ile bastırıp bakalım. Bakın tüm dosyalar tek tek sıkıştırılmış. Eğer arşivleme yapmayacaksak tek bir klasör altındaki tüm dosyaları bu şekilde kolaylıkla sıkıştırabiliyoruz. 

Benzer şekilde sıkıştırılan tüm dosyaları eski haline getirmek için de -rvd seçeneğini kullanabilirsiniz. Hemen ana klasörün ismini belirterek komutumuzu girelim. Bakın şimdi de sıkıştırılmış olan dosyalar açılıyor. İşlem tamamlandı, ls -R komutu ile içeriğe tekrar göz atalım. Bakın tüm dosyalar sıkıştırılmadan önceki hallerine geri dönmüşler. 

## Sıkıştırma Seviyeleri

Sıkıştırma ve eski haline getirmeyi öğrendik. Ancak sıkıştırma seviyesi kavramından henüz bahsetmedik. Biz aksini belirtmediğimiz için şimdiye kadar ele aldığımız örneklerde hep standart olan 6. kademe sıkıştırma uygulandı. Normalde gzip üzerinde 1 den 9 a kadar sıkıştırma seviyeleri bulunuyor. İlk kademe en az sıkıştırmayı uygulayıp hızlıca işini bitiyorken, seviye yükseldikçe sıkıştırma oranı artarken işlem süresi de uzuyor. Sıkıştırılmış dosyalar açılırken ise tersi şekilde, çok sıkıştırılan daha çabuk, az sıkıştırılan daha yavaş olacak şekilde açılıyor.

Peki bu sıkıştırma seviyelerini nasıl belirebiliriz ? Çok basit, tek yapmamız gereken gzip komutunun ardından tire işaretinin peşine istediğimiz sıkıştırma seviyesini belirtmek. 

Örneğin standart bir sıkıştırma yerine maksimum sıkıştırma oranını istiyorsanız gzip -9 sıkıştırılacak_dosya şeklinde komut girmeniz gerekiyor. Tersi şekilde yani örneğin hızlı ama az sıkıştırılmasını istiyorsak gzip -1 sıkıştırılacak_dosya şeklinde komutumuzu girebiliriz. 

Ben şimdi sıfırdan standart, hızlı ve en çok sıkıştırma seviyelerin hepsini deneyip süre ve sıkıştırma oranlarını test etmek istiyorum. Ancak baştan belirteyim, sıkıştıracağım dosyanın boyutu çok büyük olmadığı için süre ve sıkıştırma oranı bakımından çok büyük farklılıklar görmeyeceğiz. Anlatımın devamında daha kapsamlı bir testten bahsedeceğim biz yine de kendimiz için ufak bir test gerçekleştirelim.

Süreyi ölçmek için time komutunu kullanacağım. Time komutu sayesine, time komutunun ardından belirtilmiş olan komutun çalışma süresi hakkında bilgi edinebiliyoruz. Bu sayede işlemlerin ne kadar sürdüğünü konsol üzerinden öğrenebileceğiz. Dosyaları istediğim isimde dışarı aktarmak için de -c seçeneği ve yönlendirme operatörünü kullanacağım. Buradaki c seçeneği, sıkıştırma işlemi sonrası elde edilen çıktıların standart çıktıya bastırılmasını sağlıyor. Biz de bu sayede yönlendirme operatörünü kullanarak istediğimiz bir dosyaya bu çıktıları yönlendirebiliyoruz. Ben de spesifik istediğim isimde sıkıştırılmış dosya oluşturmak için bu yaklaşımı kullanacağım. Ayrıca diskin okuma yazma hızından etkilenmemesi için bu sıkıştırılmış dosyaları geçici dizin olan tmp dizinine yönlendiriyor olacağım. Bu sayede daha şeffaf bir zaman testi sağlayabiliriz. Öncelikle sıkıştırmak istediğim linux-dersleri.tar dosyasını /tmp dizinine kopyalamak istiyorum. Şimdi bu dizine geçiş yapıp komutumuzu girebiliriz. 

İlk olarak standart seviye olan 6. seviyeyi test etmek üzere:

time gzip -c arsiv.tar > standart.tar.gz 

şeklinde komutumu giriyorum. Bakın işlemin ne kadar sürdüğü burada yazıyor. 

Şimdi en hızlı ama en az sıkıştırmayı uygulayan 1. seviyeyi test etmek üzere:

time gzip -1 -c arsiv.tar > en-az.tar.gz 

şeklinde komutumuzu girelim. 

Son olarak da en yüksek sıkıştırmayı uygulayan ama yavaş olan -9 seviyeyi deneyelim.

time gzip -9 -c arsiv.tar > en-cok.tar.gz

Evet işlemlerin sonunda hangisinin ne kadar süre tuttuğunu görebiliyoruz. Buradaki rakamlar sıkıştırılan dosyaya göre değişkenlik gösterse de bize çok kabaca fikir veriyor. Dosya boyutu çok küçük olduğu için istatistikler net değil ancak kıyaslayabilmek için “user” olarak geçen buradaki zamana yani işlemin gerçekleşmesi için harcanan cpu zamanına bakabiliriz. Bakın en yüksek sıkıştırma seviyesi en uzun sürede oluşturulmuşken, en düşük seviye en hızlı tamamlanan işlem olmuş. Buradaki standart seviye olan 6 seviye gzip algoritmasının en optimum seviyesi olduğu için hem sıkıştırma hem de zaman bakımından ortama olarak iyi performans gösteriyor. Özellikle dosyanın boyutu küçük olduğu için sıkıştırma işlemini çabucak tamamladığından süre bakımından en az sıkıştırma oranı ile yarışıyor. Yani buradaki çıktılar kafanızı karıştırmasın. Az sıkıştırma işlemi normalde daha kısa sürerken, sıkıştırma oranı arttıkça işlem süresi de uzuyor. Elbette bu rakamlar sıkıştırılan dosyaların boyutları ve türlerine göre değişkenlik gösterebilir ancak sizde de aşağı yukarı tıpkı bende olduğu gibi bir fark oluşacaktır.

Şimdi de sıkıştırma oranlarına göz atmak için gzip aracının sıkıştırma oran istatistiklerini sunan -l seçeneğini kullanalım. Ben tüm dosyaları tek seferde kontrol etmek üzere gzip -l /tmp/*.gz şeklinde komutumu giriyorum. 

Evet sıkıştırılma oranlarını aldık. Tabloya bakacak olursak hızlı olan seviyede en az sıkıştırma yapılmışken, yavaş olan 9 seviyede en yüksek sıkıştırma miktarı uygulanmış olduğunu görebiliyoruz.

Başta da belirttiğim gibi aslında uyguladığımız bu test çok basit ve yetersiz bir test ancak yine de sıkıştırma oranları ve süresi hakkında aşağı yukarı bize fikir verebilir. Örneğin süre testini sıkıştırılmış dosyaları açma işlemleri için de gözlemleyebiliriz ancak dosya boyutu küçük olduğu için dikkate değer bir fark oluşturmayacaktır. Yine de dosyaları açıp daha önce belirttiğim ters orantıyı gözlemeye çalışalım. time gzip -d komutundan sonra dosyanın ismini girmemiz yeterli. Tüm dosyalar için sırasıyla komutumuzu girelim.

time gzip -d en-az.tar.gz

time gzip -d standart.tar.gz

time gzip -d en-cok.tar.gz

Bakın en-az sıkıştırılan dosya en geç açılırken, en çok sıkıştırılmış dosya ise daha çabuk açıldı. Böylelikle daha önce belirtmiş olduğumuz sıkıştırma ve açma sürelerinin seviyelere göre değişimini bizzat test etmiş olduk. Gerçekleştirdiğimiz test her ne kadar basit bir gözlem imkanı sağlasa da elbette bu sıkıştırma oranları ve süresi özellikle büyük veya çok sayıdaki dosyanın üzerinde uygulanırken önem kazanıyor. Neyse anlatımın sonlarında bu konunun üzerinde ayrıca duracağım. Şimdi gzip alternatifi olan bzip2 sıkıştırma algoritmasından bahsederek devam edelim.

# bzip2

Esasen bzip2 aracının kullanımı gzip ile neredeyse tamamen aynı. Gzip aracında bahsettiğim seçenekleri ve dolayısıyla özellikleri aynen bzip2 üzerinde de uygulayabiliyoruz. 

Örneğin bzip2 dosya adı şeklinde komut girdiğimizde ilgili dosya sıkıştırılıp dosya isminin sonuna da bz2 uzantısı ekleniyor. Ben arşiv dosyasını sıkıştırmak üzere bzip2 linux-dersleri.tar şekliden komutumu giriyorum. Sıkıştırma tamamlandı, ls -l komutu ile listeleyelim.  

Bakın dosyanın isminin sonuna bz uzantısı eklenmiş ve dosya sıkıştırılmış. Hatta gzip den daha fazla sıkıştırma uygulandığını iki dosyanın boyutlarını kıyaslayarak görebiliyoruz. Sıkıştırma seviyelerinden daha sonra bahsedeceğim. Şimdi sıkıştırılmış olan dosyayı eski haline getirelim. Bunun için decompress ifadesinin kısalmasından gelen -d seçeneğini kullanabiliriz. 

Bakın dosya eski haline geri döndü.

Eğer orijinal dosya korunsun harici olarak sıkıştırılmış versiyonu oluşturulsun istiyorsak gzip aracında da kullandığımız keep seçeneğinin kısalması olan k seçeneğini kullanabiliriz. Ben test etmek için bu kez komutumu bzip2 -k linux-dersleri.tar şeklinde yazıyorum. Hatta istersek, verbose seçeneğini ekleyip işlem hakkında ayrıntılı bilginin konsola bastırılmasını sağlayabiliriz. Komutumuzu onaylayalım.

Bakın işlem sonunda sıkıştırma işlemi hakkında çeşitli bilgileri de aldık. ls komutu ile mevcut dizinimizi de listeleyelim. Bakın -k seçeneği sayesinde orijinal dosya korunurken, sıkıştırılmış versiyonu da oluşturulmuş.

Ben bu örnekte orijinal dosyayı koruyarak orijinal dosya ile aynı isimde sıkıştırılmış versiyonunu oluşturdum. Ancak istersem -c seçeneği ile spesifik olarak istediğim isimde dosya oluşturulmasını da sağlayabilirim. Buradaki -c seçeneği sıkıştırılmış verilerin standart çıktı ile bastırılmasını sağlıyor. Biz de bu standart çıktıları yönlendirme operatörlerini kullanarak istediğimiz isimde bir dosyaya yönlendirebiliyoruz. 

Örnek olması için arşiv dosyasını sıkıştırıp masaüstü dizinimde yeni-arsiv.tar.bz2 ismiyle kaydetmek istiyorum. Bunun için bzip2 -c arsiv.tar >/home/taylan/Desktop/yeni-arsiv.tar.bz2 şeklinde komutumu yazıyorum. Aslında burada dosya isminin sonuna tar.bz2 eklentisini eklemesem de sıkıştırma işlemi başarılı olacak ancak daha önce de bahsettiğim düzenli çalışma adına bu gibi eklenti detaylarına dikkat etmemiz gerekiyor. Komutumu onaylıyorum.

İşlem tamamlandı. Şimdi masaüstü dizinini ls -l komutu ile kontrol edelim. Bakın dosyanın sıkıştırılmış versiyonu tam olarak istediğim dizine ve tam olarak istediğim isimle kaydedilmiş bulunuyor.

Söylediğim gibi bzip2 aracının kullanımı gzip ile son derece benzer. Ufak tefek farkların dışında her iki aracı da hemen hemen aynı şekilde kullanabiliyoruz.

Örneğin gzip üzerinde bahsetmiş olduğum sıkıştırma seviyeleri aynen bzip2 üzerinde de mevcut fakat varsayılan olarak kullanılan seviyeler farklı. Gzip algoritmasındaki varsayılan seviye 6 iken Bzip2’nin varsayılan sıkıştırma seviyesi ise 9 dur. Algoritmaların farklı seviyeleri varsayılan olarak kullanma nedeni, ilgili algoritmanın en verimli şekilde çalıştığı seviyenin farklı olmasıdır. Yani sıkıştırma ve işlem zamanı ortalamasındaki en verimli seviye bzip2 algoritması için 9 iken gzip için 6’dır. Elbette bzip2 algoritmasında da tıpkı gzip de olduğu gibi her zaman varsayılan sıkıştırma seviyesini kullanmak zorunda değiliz. Dilediğimiz bir sıkıştırma seviyesini bzip2 komutunun ardından -1 veya -9 şeklinde belirtebiliyoruz.

Eğer az ama hızlı sıkıştırma istiyorsanız 1 seviye, çok ama daha yavaş olmasını kabul ediyorsanız da 9. yani varsayılan seviyeyi kullanabilirsiniz. Ayrıca bu seviyelerin arasındaki diğer seviyeleri de kullanmakta özgürsünüz tabi. Örneğin 2 3 4 5 7 8 gibi rakamları da kullanarak farklı seviyelerde sıkıştırma uygulayabilirsiniz. Ben yalnızca iki uç seviyeden bahsederek aralarındaki farka değindim.

Biliyorum tam da bu noktada gzip mi yoksa bzip2 mi kullanılmalı diye düşünüyorsunuz. Hemen iki algoritma arasında kıyaslama yapıp hangisinin daha iyi olduğunu gözlemleyebiliriz. Ancak kullanılan tüm sıkıştırma algoritmaları gzip ve bzip2 den ibaret değil. Bu noktada daha adil bir değerlendirme için alternatif sıkıştırma yöntemleri de dahil tüm sıkıştırma algoritmalarını seviye seviye kıyaslamamız gerekiyor. Daha çok windows sistemlerinde sıklıkla karşılaştığımız rar ve zip sıkıştırma algoritmalarını şimdilik bir kenara bırakacak olursak; günümüzde gzip bzip2 xz lz4 lzip zstd gibi yaygın kullanıma sahip çeşitli sıkıştırma algoritmaları bulunuyor. Elbette tüm sıkıştırma algoritmaları bunlardan ibaret değil ancak en yaygın kullanıma sahip olan ve karşılaşmamızın daha olası olduğu temel sıkıştırma biçimleri bunlar. Ben yalnızca gzip bzip2 xz ve zstd arasında kısaca kıyaslama yaparak hangisinin hangi durumda kullanılabileceğinden bahsetmek istiyorum. 

İnternet üzerinde çeşitli algoritmaları kıyaslayan pek çok blog yazısı bulunuyor. Dilerseniz bizzat kendiniz de kıyaslama yapabilirsiniz. Ubuntu üzerinde şu an için gzip bzip2 ve xz algoritmalarını kullanabileceğimiz araçlar halihazırda yüklü olarak geliyor. Ayrıca başka sıkıştırma algoritmaları da varsayılan olarak kullanılabilir şekilde bulunuyor. Ancak ben hepsinden bahsetmek yerine son dönemde göze çarpan zstd algoritmasından da bahsetmek istiyorum. Şu an için varsayılan olarak bu algoritmayı kullanabileceğimiz araçlar Ubuntu içinde yüklü gelmiyor. Ancak facebook tarafından açık kaynaklı olarak desteklenen bu algoritmayı kolaylıkla sistemimize kurabiliyoruz. Kısacası ben en çok karşımıza çıkan gzip bzip2 ve xz algoritmaları dışında gelecek vaadeden zstd algoritmasından da bahsetmek istiyorum. Araçların kullanımları son derece benzer olduğu için ve artık sıkıştırma araçlarını aşağı yukarı nasıl kullanabileceğinizi bildiğiniz için xz ve zstd araçlarını da tek tek ele almayacağım. Tek yapmanız gereken yardım sayfalarına göz atıp hangi özellikleri olduğunu görmek.

Zstd aracını kullanmak istiyorsanız, elbette sistemde yüklü bulunmadığı için öncelikle yüklemeniz gerekecek. Aracımı kurmak için sudo apt update && sudo apt install zstd -y şeklinde komutumu giriyorum. Eğer redhat tabanlı bir dağıtım kullanıyorsanız sudo dnf install zstd -y komutunu kullanabilirsiniz. Biliyorum henüz güncelleme ve paket kurulumlarından bahsetmedik ancak şimdilik sadece komutu girip aracı kurmanız yeterli. İleride bu konudan bahsediyor olacağız. 

Tamamdır aracımız kuruldu.

Algoritmaların kıyaslamasından da bahsedeceğim ancak bundan önce tar yani arşiv oluşturma komutu ile aslında aynı zamanda sıkıştırma işlemi de yapabileceğimizden bahsetmek istiyorum. [Buradaki](https://linuxreviews.org/Comparison_of_Compression_Algorithms) tabloda gördüğünüz tüm parametreler ilgili sıkıştırma algoritmasının tar aracı ile birlikte kullanılarak nasıl sıkıştırılmış arşiv dosyası oluşturabileceğimizi belirten seçeneklerin bilgileri.

![[https://linuxreviews.org/Comparison_of_Compression_Algorithms](https://linuxreviews.org/Comparison_of_Compression_Algorithms)](%E2%9C%85%2011-%20Ars%CC%A7ivleme%20ve%20S%C4%B1k%C4%B1s%CC%A7t%C4%B1rma%20I%CC%87s%CC%A7lemleri%20d77c6c693ece4e22a2ebc7d7d83fd1a4/Untitled.png)

[https://linuxreviews.org/Comparison_of_Compression_Algorithms](https://linuxreviews.org/Comparison_of_Compression_Algorithms)

Örneğin ben daha önce websitesinin dosyaları tar komutu ile yalnızca arşivlemiştim. Eğer hem arşivleyip hem de sıkıştırılmasını istersem bunun için tar komutuna ilgili sıkıştırma algoritmasının seçeneğini eklemem gerekiyor. Ben denemek için öncelikle gzip ile sıkıştırılmış bir arşiv oluşturmak istiyorum. Temiz bir dizinde çalışmak için mkdir arsiv komutumu ile yeni klasör oluşturalım. Klasörün içine de websitesinin klasörünü cp -r komutunu yardımıyla kopyalayalım. Tamamdır şimdi bu dizine geçiş yapıp arşivleme ve sıkıştırma işlemlerinden bahsedebiliriz.

Ben öncelikle gzip algoritması ile sıkıştırılmış bir arşiv oluşturmak istiyorum. tar aracında gzip algoritmasını -z seçeneği ile temsil edildiği için arşiv oluşturma komutuna z seçeneğini eklememiz yeterli. Ben arşiv dosyası oluşturacağım için tar komutunun -c seçeneğini yazıyorum, ayrıca gzip algoritması ile sıkıştırılmasını istediğim için z seçeneğini de ekliyorum. Son olarak arşiv dosyasının isminin ne olacağını belirtebilmek için de -f seçeneğini ekliyorum. Ben isim olarak linux-dersleri.tar.gz olarak yazıyorum ve arşivlenip sıkıştırılacak klasörün ismini de yazıyorum. Tamamdır. 

tar -czf linux-dersleri.tar.gz linux-dersleri-master

ls -l komutu ile listeleyelim. Hatta boyut farkını görmek için du -sh * şeklinde kıyaslama da yapabiliriz. Bakın sıkıştırılmış arşiv dosyası bir miktar daha az disk alanı kaplıyor. 

Ayrıca dosyanın türünü öğrenmek için `file` komutundan da yararlanabiliriz. `file` komutu bir dosyanın türünü hakkında bilgi almak için kullanabileceğimiz basit araç. Özellikle dosya uzantısı bulunmayan ve türünü bilmediğimiz dosyalar hakkında hızlıca bilgi edinmek için file komutunu kullanabiliyoruz. Ben de oluşturduğum dosyanın türünü teyit etmek için kullanmak istiyorum. Yani örneğim ben oluşturduğum sıkıştırılmış arşiv dosyasının türünü öğrenmek için file linux-dersleri.tar.gz şeklinde komutumu girebilirim. Bakın gzip ile sıkıştırılmış veri olduğuna dair çıktı aldık. Yani tar aracına -z seçeneğini ekleyip sıkıştırılmış arşiv dosyası oluşturabileceğimizi bizzat teyit etmiş olduk. 

Ben gzip algoritmasını kullandım ancak benzer şekilde diğer algoritmaları da kullanabiliriz. Örneğin bzip2 ile sıkıştırılması için “j” seçeneğini kullanabiliyoruz. Hemen deneyelim. Ben seçeneği j olarak değiştiriyorum ve isim olarak da .gz yerine bz2 uzantısını ekliyorum. 

İşlem tamamlandı, du -hs * komutu ile tekrar listeleyip boyutlarına bakalım. Bakın bzip2 ile sıkıştırılmış arşiv dosyası gzip algoritması ile sıkıştırılmış dosyadan bir miktar daha az depolama alanı kaplayacak şekilde oluşturulmuş. Daha önce uygulamalı olarak ele almadık ancak dilersek xz algoritması için de büyük J seçeneğini de kullanabiliriz. Hangi algoritmanın hangi seçenek ile belirtildiğini hatırlamadığınızda  tar —help komutu ile hemen öğrenebilirsiniz. Örneğin bakın xz için büyük J karakteri olduğu burada da belirtiliyor.

Ben komutumu yeninden xz doğrultusunda revize ediyorum. xz ile sıkıştırma işlemi gzip veya bzip2 ye oranla gördüğünüz gibi daha uzun sürdü. Şimdi dosya boyutlarını da listeleyelim. 

Bakın xz arşiv dosyası bzip2 ve gzip den daha fazla sıkıştırılmış. 

Son olarak zstd ile sıkıştırılmış arşiv dosyası da oluşturmak istiyorum. zstd algoritması için şimdiye kadar ele aldığımız algoritmalarından farklı olarak kısa bir seçenek yok. Bunun yerine yardım bilgisine tekrar göz atacak olursak, uzun şekilde --zstd seçeneğini kullanmamız gerektiği belirtilmiş. 

Ayrıca hazır yeri gelmişken belirteyim, bu listede kısa veya uzun seçenekleri bulunmayan bir algoritma ile sıkıştırılmış arşiv dosyası oluşturmak istiyorsanız büyük I seçeneğinin ardından kullanmak istediğiniz algoritmanın programını yazmanız yeterli. Tabii ki kullanmak istediğiniz sıkıştırma algoritmasının programının sisteminizde yüklü olması gerekiyor. Örneğin bu listede mevcut fakat zstd algoritmasının bu listede olmadığını varsayacak olursak benim öncelikle sistemime zstd algoritmasını kullanabilmemi sağlayan aracı indirmem gerekiyor. Zaten indirmiştim. Araca sahip olduktan sonra bu sıkıştırma algoritmasının kullanılması için de -Izstd şeklinde komutumu girebilirim.

Örneğin zstd sıkıştırma algoritmasının kullanılabilmesi için bu kez komutumu tar -c -Izstd -f linux-dersleri.tar.zst linux-dersleri-master şeklinde komutumu giriyorum. Burada benim zstd olarak belirtiğim harici algoritma yerine sisteminizde yüklü bulunan dilediğiniz bir algoritmayı belirtebilirsiniz. Yani harici algoritmaların kullanımı bu şekilde. Ayrıca sıkıştırma seviyesini de özellikle belirtmek istersem komutumu -I”zstd -sıkıştırma seviyesi” şeklinde tırnak içinde yazabilirim. Mesela ben -10 seviye için -I”zstd -10” şeklinde yazabilirim. Yani burada büyük ı karakterinden sonra aslında, kullanmak istediğim aracın ismini yazdığım için normalde bu aracı tek başına kullandığımızda nasıl komut gireceksek buraya da aynı şekilde yazabiliyoruz. Ben seviye belirtmeden standart seviye için komutu sade şekilde gireceğim.

Yine du -hs * ile dosyaları boyutlarıyla birlikte listeleyelim. Bakın zstd sıkıştırma algoritması hızlıca işlemi tamamlamış olmasına rağmen gayet iyi bir sıkıştırma oranı sağlamış.

Tüm bu sıkıştırılmış arşivleri açmak için de ortak olarak -x seçeneğini kullanabiliyoruz. Sıkıştırılmış arşivlerin açılması için -x dışında ekstra bir seçenek eklememiz gerekiyor. Çünkü otomatik olarak ilgili algoritmanın açılımı gerçekleştiriliyor. Teyit etmek için sıkıştırmış olduğumuz tüm arşivleri tek tek açmayı deneyebiliriz. Ben -v seçeneğini de ekleyerek sırasıyla tüm sıkıştırma türlerindeki arşiv dosyaları için denemek istiyorum. Ama aynı klasörü farklı algoritmalar ile sıkıştırdığım için çıkardığımda hepsi aynı klasörünün üzerine yazılacak. Bu sebeple ben her çıkarma işleminden sonra dizinimi listeleyip daha sonra klasörü de sileceğim. İlk olarak buradaki mevcut klasörü rm -r linux-dersleri-master komutu ile silelim. Tamamdır. Şimdi örneğin gzip ile sıkıştırılmış olan arşivi açmayı deneyebiliriz. Bunun için tar -xf linux-dersleri.tar.gz şeklinde komutumu giriyorum. Bakın klasör dışarı çıkarıldı. Silip bir sonraki çıkarma işlemine geçelim. Şimdi de zstd algoritması ile oluşturduğum arşivi açmak istiyorum. Bakın bu arşiv de sorunsuzca açıldı. İşte bu şekilde sıkıştırılmış tüm arşiv dosyalarını -x seçeneği ile ortak şekilde açabiliyoruz. Büyük bir kolaylık. Tabii arşiv dosyasında kullanılan sıkıştırma algoritması için gerekli olan aracın sistemde yüklü olması gerekiyor. Yani örneğin sisteminizde zstd algoritması yüklü değilse, zstd ile sıkıştırılmış bu arşivi açmak için tar aracının -x seçeneğini kullandığınızda hata alırsınız.

Ayrıca hata almaktan bahsetmişken, üretilen arşiv dosyalarının sağlığını nasıl kontrol edebileceğimizden de çok kısaca bahsetmek istiyorum. Çünkü bizler aslında genellikle verilerimizi yedeklemek için arşivleme ve sıkıştırma işlemini uyguluyoruz. Yedeklenecek kadar önemli olan verilerin tabii ki de sağlıklı olması yani tekrar arşivden çıkarılarak eksiksiz şekilde ulaşılabilmesi de çok önemli. Aslında kontrol işlemi çok kolay. Kontrol için test ifadesinin kısalmasından gelen -t seçeneğini kullanabiliyoruz.

Test işlemini iki farklı düzeyde yapabiliriz. Eğer tar aracı ile sıkıştırıp arşivlediysek veya sadece arşivlediysek bile bu arşivi -t seçeneği sayesinde kontrol edebiliyoruz. Normalde daha önce de bahsettiğimiz gibi tar komutunun -t seçeneği arşiv içeriğini listelemek için kullandığımız bir seçenek. Aslında bu seçenek arşiv içeriğini listelerken yalnızca sağlıklı olan dosyaları çıktı olarak bize vermiyor. Eğer arşivde bir hasar varsa bunu da bize çıktı olarak bildiriyor. Denemek için öncelikle hasarlı bir arşiv dosyası oluşturmaya çalışalım. Ben bu işlem için sıkıştırma işlemi uzun süren xz algoritması ile yeni arşiv oluştururken, bu işlemi durdurup arşivin tam olarak oluşturulmasını önleyeceğim. Bu sayede tam olarak oluşturulamamış, hasarlı bir arşiv dosyamız olacak.

Ben denemek için tar -cJf hasarlı.tar.xz linux-dersleri-master komutumu giriyorum ve bir süre geçtikten sonra ctrl c tuşlaması ile bu işlemi sonlandırıyorum. Tamamdır, bakın işlemi yarıda kesmiş olmama rağmen arşiv dosyası oluşturulmuş. Şimdi bu arşivin sağlık durumunu teyit etmek için tar -tf hasarlı.tar.xz şeklinde komutumuzu girelim. Bakın burada öncelikle hasarsız olan dosya ve dizinler listelendi, son olarak da arşiv dosyasının beklenmedik şekilde sonlandığını ve dolayısıyla bu arşivin hasarlı olduğunu belirten çıktıları da almış olduk. Eğer bu kadar uzun uzadıya çıktı değil de yalnızca arşiv dosyasının sağlıklı olup olmadığını kontrol etmek istiyorsanız hatasız çıktıları /dev/null dosyasına yönlendirerek yalnızca hatalı çıktıları da alabilirsiniz. Yani komutumuzu tar -tf hasarlı.tar.xz > /dev/null şeklinde girebiliriz. Bakın yalnızca hatalı olan çıktıları aldık. Özellikle birden fazla arşiv dosyasını kontrol ederken bu şekilde yalnızca hatalı olan çıktıları almak işimizi oldukça kolaylaştırıyor. Bu arşiv dosyası bu şekilde hasarlı olduğu için dışarı çıkarılamaz. Denemek isterseniz, hemen deneyelim. Bakın arşivin hasarlı olduğuna dair benzer bir hata aldık. Çıkarırken de gördüğümüz gibi arşivlerin hasarsız olması, yedeklediğimiz verilerin sağlığı için çok önemli.

Ben tar aracı ile arşivleri nasıl kontrol edebileceğimizden bahsettim ancak yalnızca arşivleri değil sıkıştırılmış dosyaları da sıkıştırıldıkları algoritma programları ile de kontrol edebiliyoruz.

Örneğin ben xz algoritması ile bu arşiv dosyasını sıkıştırdığım için xz -t hasarlı.tar.xz komutu ile bu dosyanın sağlığını kontrol edebilirim. Bakın yine beklenmedik girdi sonu şekilde bir hata aldık.

Eğer dosya hatasız olsaydı hiç bir çıktı almayacaktık. Hatta denemek için buradaki hatasız dosyayı deneyebilirim. Ben denemek için xz -t linux-dersleri.tar.xz komutunu giriyorum. Bakın dosya hatasız olduğu için herhangi bir çıktı almadım. Yani gördüğünüz gibi -t seçeneği sayesinde eğer dosya hasarlı ile ise çıktı alıyoruz. Hasar yoksa hiç bir çıktı olmuyor. Bu durum özellikle çoklu şekilde dosyaları kontrol ederken, sorunsuz dosyalar hakkında gereksiz çıktı almamızı önlediği için biz kolaylık sunuyor. 

Ben xz algoritması ile sıkıştırıldığı için xz -t komutu ile kontrol ettim ancak siz hangi algoritma ile sıkıştırdıysanız o algoritmanın aracını kullanmanız gerekiyor. Örneğin gzip ile sıkıştırıldıysa gzip -t komutu ile kontrol edebilirsiniz. Duruma göre tar aracını veya sıkıştırma işleminde kullandığınız algoritmanın aracını kullanarak oluşturduğunuz dosyaların sağlığını kontrol edebilirsiniz. Örneğin sizin kullandığınız sıkıştırma algoritmasının aracı dosya bütünlüğünü -t seçeneği ile kontrol etmiyor da olabilir. Tek yapmanız gerekene ilgili aracın yardım bilgilerine göz atıp hangi seçeneğin, dosya bütünlüğünü test ettiğini öğrenmek.

Arşivleme ve sıkıştırmayla ilgili bahsettiğimiz pek çok temel bilgiden sonra. Şimdi asıl merak edilen noktaya yani sıkıştırma algoritmalarından hangisini kullanmamız gerektiğine gelecek olursak, bu sorunun cevabı için testler yapmamız gerekiyor. Fakat ben algoritmaları tek tık kıyaslayacağım bir test yapmayacağım. Biz kendimiz de yapabilirdik ancak zamandan kazanmak adına daha önce gerçekleştirilmiş testlere bakarak da aşağı yukarı fikir sahibi olabiliriz. 

Ben şimdi bu algoritmaların daha önce gerçekleştirilmiş testleri üzerinden genel yorumlamada bulunmak istiyorum. [Buradaki](https://linuxreviews.org/Comparison_of_Compression_Algorithms) kaynak yaygın kullanıma sahip pek çok algoritmayı kıyasladığı için fikir sahibi olabilmemiz için bence iyi bir kaynak. Elbette bu kıyaslama haricinde pek çok alternatif kaynağı da gözden geçirebilirsiniz. Biz genel fikir sahibi olabilmemiz için bu tabloyu yorumlamaya çalışalım. Başlamadan belirtelim, tabii ki buradaki sonuçlar nihai sonuçlar değil. Yani kullanılan sistemin durumuna ve sıkıştırılacak dosyaların türüne göre sonuçlarda değişimler olabilir. Fakat yine de aynı sistemde aynı dosya üzerinden yapılmış bu testler bize genel fikir verebilir. Daha kesin sonuçlar için dilerseniz sıkıştırmanın uygulanacağı sisteminiz üzerinde kendiniz de bu testleri yapabilirsiniz. Tabloya dönecek olursak;

Eğer anlık olarak hızlıca sıkıştırıp açılacak bir dosyanız varsa gzip in standart olan 6. seviyesini kullanabilirsiniz. Ya da bunun yerine xz algoritmasının 1. seviyesi de benzer işlev için kullanılabilir.

Eğer sistemin yük altında olmadığı dönemde örneğin geceleri büyük dosyaları fazlaca sıkıştırmak istiyorsanız, bu durumda en fazla işlem kaynağı harcayan ancak en az depolama alanı kaplayan xz -9 veya zstd -19 zstd -22 gibi alternatifleri de tercih edebilirsiniz.

Özellikle bir dosya çok fazla kişi tarafından indirilip kullanılacaksa, bir kere bu dosyayı çok sıkıştırmak ağ üzerindeki bant genişliğinden tasarruf sağlayabilir. 

Bzip2, sıkıştırma oranı ve işlem hızı arasında iyi bir denge sağlar, ancak sıkıştırmanın açılması uzun sürer, bu nedenle sıkıştırılan içerik nadiren açılacaksa iyi bir seçenek olabilir.

Mesela büyük kitlelere hizmet edecek bir web sunucu için muhtemelen arşivleme ve sıkıştırma işlemini mümkün olduğunca çabuk bitirmek isterseniz. Bu sebeple depolama alanı çok büyük sorun olmadığı sürece işlemciyi meşgul etmek yerine depolama alanından biraz taviz vermek daha doğru bir çözüm olabilir. 

Sonunda en iyi seçenek, işlem süresi ve sıkıştırma oranı arasında neyin peşinde olduğunuza bağlıdır.

Yani en nihayetinde tüm mesele tam olarak nasıl bir çözüme ihtiyacınız olduğuyla ilgili. Elbette buradaki sıkıştırma oranları ve süresi kullanılan dosya ve sisteme göre farklılıklar gösterebilir. Yine de buradaki tablo algoritmaların davranışları hakkında genel bilgi sahibi olmamızı sağlıyor bence. Kullandığınız sistem üzerinde kendiniz de bizzat test edip, içinde bulunduğunuz durum için hangi çözümün daha efektif olduğuna kendiniz karar verebilirsiniz. Çünkü hangi dosyaları sıkıştırdığınız ve hangi amaçla sıkıştırma yaptığınız tüm sonuçları değiştirebilir. Bu noktada deneme yanılma ve daha fazla araştırma yapmak sistem yöneticisi olarak sizin sorumluluğunuzda. Ben yalnızca gzip ve bzip2 ile sınırlı kalmak zorunda olmadığınızı, ideal çözüm için bizzat kendinizin araştırıp sisteminizde denemeniz gerektiğine vurgu yapmak için birden fazla algoritmanın varlığından bahsettim. Hatta biz yalnızca birkaç algoritmadan bahsettik ancak bunlar ile sınırlı değil. Spesifik olarak pek çok farklı iş için geliştirilmiş olan pek çok farklı algoritma ile de karşılaşabilirsiniz. 

Son dönemde pek çok sistemde xz yaygın olarak karşımıza çıkıyorken, gün geçtikçe zstd algoritmasını kullanmaya başlayan pek çok sistemi görmeye devam edeceğiz gibi duruyor. Zamanla bu söylediklerimin yerine çok farklı çözümler de kullanılabilir elbette. Buradaki mesele, potansiyelin farkında olabilmeniz.

Ayrıca bazı algoritmalar küçük dosyaların sıkıştırılmasında daha iyi sıkıştırma oranı sağlayabiliyor. Bu sebeple her tür dosya için harika çözüm sunan tek bir algoritmadan bahsetmek de olası değil. İhtiyacınıza yönelik çözümleri araştırıp deneyip, kendi sisteminizde de kullanabilirsiniz.

# Paralel Olarak Kullanmak

Sıkıştırma işlemi yapılacak sistemdeki işlemci birden fazla çekirdeğe sahipse, sıkıştırma işlemlerinin birden fazla çekirdek üzerinden paralel olarak çok daha hızlı biçimde gerçekleştirilmesini sağlayabiliriz. Paralel araçların kullanımı son derece kolay. Tek ihtiyacınız, kullanmak istediğiniz algoritmanın paralel olarak çalışmasına olanak tanıyan aracını edinmek. Sisteminizde yüklü de olabilir. Eğer yüklü değilse, kullanmak istediğiniz algoritmanın paralellik için hangi aracı kullandığını araştırıp bulup yükleyebilirsiniz. Örneğin bzip2 için pbzip2 aracı paralellik sağlıyorken, gzip için pigz isimli aracı kullanabiliyoruz. Mesela pigz aracı benim sistemimde yüklü değil ama sudo apt install pigz komutu ile kolayca kurabilirim. Ben örnek olması için tek bir araç üzerinden ilerliyor olacağım ancak sizler dilediğiniz algoritmayı benzer şekilde kullanabilirsiniz. Burada dikkatinizi çekmek istediğim husus, sıkıştırma işleminin işlemcinin müsait olduğu durumda yani çok çekirdekli işlemcilerde paralel şekilde yapılabileceği. 

Ben öncelikle standart sıkıştırma ile paralel sıkıştırmada oluşan süre farkını kıyaslayabilmek için standart arşivleme yapmak istiyorum. Bunun time tar -czf standart.tar.gz linux-dersleri şeklinde komutumuzu girebiliriz. Bakın işlemin ne kadar sürdüğünü görebiliyoruz. Şimdi aynı sıkıştırma işlemini paralel olarak gerçekleştirmeyi deneyelim.  Bunun için time tar -cIpigz -f paralel.tar.gz linux-dersleri şeklinde komutumu giriyorum. Buradaki I seçeneğinin ardından istediğimiz sıkıştırma algoritmasını belirtebileceğimizi daha önce de ele almıştık. İşte bu seçeneğin ardından ben paralel olarak sıkıştırma yapan pigz aracının ismini yazıp bu aracın kullanılarak arşiv dosyası oluşturulmasını sağlıyorum. Siz dilediğiniz alternatif sıkıştırma algoritmasını belirtebilirsiniz. Paralel olması için tek yapmanız gereken pbzip2 pxz pzstd gibi özellikle paralelliği sağlayan aracı sisteminize kurmak ve bu aracın ismini büyük I seçeneğinden sonra belirtmek. Ayrıca eğer kullandığınız sistemdeki işlemci tek çekirdekli ise elbette paralellik bir avantaj sağlamayacaktır. Bu durumu dikkate alarak hız konusunda beklentilerinizi doğru ayarlayabilirsiniz. Ben denemek için sanal makinemde 2 çekirdek tanımladım. Yani şu an testi gerçekleştirdiğim bu makinede çift çekirdek bulunuyor. Eğer siz de sanal makine üzerinden çalışıyorsanız sanal makinenizin ayarlarını açıp, çekirdek sayısını donanımınızın el verdiği ölçüde uygun şekilde istediğiniz miktarda arttırabilirsiniz. Ben komutumu onaylıyorum. 

Bakın standart yöntemi kullanarak sıkıştırma yapılırken tek bir işlemci birimi kullanıldığı için işlem daha yavaş olmuştu. Şimdi ise çift çekirdeğe sahip olduğum için ve paralel olarak sıkıştırılmasını sağladığım için işlem daha kısa sürede tamamlandı. 

Benzer şekilde sıkıştırılmış arşiv dosyasını açmak için de paralellikten faydalanabiliyoruz. Ben öncelikle time tar -xf standart.tar.gz komutu ile standart şekilde arşiv dosyasını dışarı çıkarmak istiyorum. Bakın geçen süre bu şekilde. Şimdi paralellik kullanarak sıkıştırılmış arşivi açmak için time tar -x -Ipigz -f paralel.tar.gz şeklinde komutumuzu girelim.

Gördüğünüz gibi paralellik sayesinde çok daha kısa bir sürede arşiv dosyasını dışarı çıkarabildik.

Belki benim sıkıştırdığım dosyanın boyutu küçük olduğu için aradaki zaman farkı size çok fazlaymış gibi gelmemiş olabilir. Ancak daha büyük ölçekli sıkıştırma durumlarında paralellik kesinlikle büyük fark yaratacaktır. 

İşte benim gzip algoritması için ele aldığım bu paralellik yaklaşımını araştırırsanız kullanmak istediğiniz diğer sıkıştırma algoritmaları için nasıl uygulayabileceğinizi de öğrenebilirsiniz. Örneğin ben değinmedim ancak pigz aracının da pek çok seçeneği var. Mesela pigz aracını kullanırken maksimum kaç çekirdeğin kullanılacağını sınırlamamız mümkün. Bu sayede sistemin sahip olduğu tüm çekirdekleri meşgul etmek istemediğimizde istediğimiz sınırlamayı belirebiliyoruz. Bu ve bunun gibi pek çok özellik ve alternatif araç var ancak ben bu detayları değinmeyeceğim. Çünkü amacım paralelliğin var olduğundan haberinizin olmasıydı, nitekim artık var. Geri kalan araştırma işi sizde. 

Ayrıca bize sıkıştırma işlemi için paralellik sağlayan pigz gibi araçların yanında, neredeyse her türlü görevi paralelleştirmeye olanak tanıyan Gnu Paralel gibi harici çözümler de mevcut. Eğer paralellik konusunda meraklıysanız mutlaka GNU paralel aracını da araştırıp kurcalayın.

[https://www.rootusers.com/gzip-vs-bzip2-vs-xz-performance-comparison/](https://www.rootusers.com/gzip-vs-bzip2-vs-xz-performance-comparison/)

[https://etbe.coker.com.au/2020/06/06/comparing-compression/](https://etbe.coker.com.au/2020/06/06/comparing-compression/)

[https://linuxreviews.org/Comparison_of_Compression_Algorithms](https://linuxreviews.org/Comparison_of_Compression_Algorithms)

[https://stephane.lesimple.fr/blog/lzop-vs-compress-vs-gzip-vs-bzip2-vs-lzma-vs-lzma2xz-benchmark-reloaded/](https://stephane.lesimple.fr/blog/lzop-vs-compress-vs-gzip-vs-bzip2-vs-lzma-vs-lzma2xz-benchmark-reloaded/)

Buradaki detaylı bir kıyaslama yazısı bulunuyor. Dilerseniz bizzat test etmek için sizinle paylaştığım bu basit komut dizisini kullanabilirsiniz.

Eğer sıkıştırma seviyelerine göre ne kadar süre geçtiğini ve sıkıştırma oranlarını öğrenmek isterseniz aşağıdaki basit komut dizisini kullanabilirsiniz.

```bash
for i in {1..9}; 
	do echo -e "\n\033[0;31mSıkıştırma Seviyesi:\033[0m$i" ; 
		time gzip -$i -vc arsiv.tar >$i.tar.gz ; 
		echo -e "\nÖnceki boyutu: `ls -Ss1 --block-size=1 arsiv.tar`" ; 
		echo "Sonraki boyut: `ls -Ss1 --block-size=1 $i.tar.gz`" ; 
	done
```

Burada ben gzip aracını yazdım ancak sizler hangi aracı test etmek istiyorsanız onu ekleyebilirsiniz. Örneğin gzip yerine bzip2 yazmanız yeterli.

# ****zcat-zgrep-bzcat-bzgrep zless zmore zdiff vs..****

Daha önce dosyalar üzerinde kullandığımız cat grep less more diff gibi araçları biliyorsunuz. Normalde sıkıştırılmış bir dosya üzerinde bu cat grep gibi araçları doğrudan kullanamıyoruz çünkü veriler sıkıştırılmış oluyor. Fakat çözümsüz değiliz çünkü standart dosyalarda olduğu gibi bu işlevlerin benzerlerini arşiv dosyaları için sunan araçlar da mevcut. Örneğin gzip algoritması için zcat zgrep zless zmore zdiff ve benzeri araçlar kullanılıyor. Diğer algoritmalar için de benzeri şekilde farklı isimlendirilmiş araçlar var. Pek çok farklı sıkıştırma algoritması olduğu için elbette benzer görev için pek çok farklı yardımcı araç var. Ben örnek olarak gzip algoritmasında kullanılan zcat ve zgrep araçlarından bahsedeceğim ancak sizler diğer tüm algoritmaların harici yardımcı araçlarına manuel sayfasından göz atabilirsiniz. Daha önce ele aldığımız için zaten cat ve grep araçlarının temel işlevlerini biliyorsunuz. Sıkıştırılmış dosyalar üzerinde kullandığımız bu araçlar da aynı şekilde çalıştığı için üzerlerinde çok fazla durmak istemiyorum. Basit örnekler verip anlatımımıza devam edebiliriz. 

Öncelikle zcat aracı ile sıkıştırılmış bir metin dosyasının içeriğini okumayı deneyebiliriz. Ben test edebilmek için echo “denem” > test komutu ile içerisinde deneme yazan “test” isimli bir dosya oluşturmak istiyorum. Bakın bu dosyayı cat komutu ile sorunsuzca okuyabiliyoruz. Şimdi gzip test komutu ile dosyayı sıkıştıralım. Tamamdır. Şimdi bu dosyayı cat test.gz komutu ile okumayı deneyelim. Bakın dosya içeriği bozuk şekilde konsola bastırıldı. Şimdi zcat ile aynı dosyayı okumak için zcat test.gz komutunu girelim. Bakın sıkıştırılmış dosyanın içeriğini zcat komutu ile sorunsuzca okunabildi. Aslında zcat aracı, sıkıştırılmış arşiv dosyasının içeriğini standart çıktıya açıyor. Yani aslında sıkıştırılmış dosya içeriği zcat tarafından açılıyor ve çıktı olarak standart çıktıya yönlendiriliyor. Bu sebeple gzip ile sıkıştırılmış dosyayı standart cat aracı ile okuyamıyorken, gzip için çözüm sunan zcat aracı ile okuyabiliyoruz. Benzer şekilde grep aracının sunduğu çözümü gzip ile sıkıştırılmış dosyalar üzerinde kullanabilmek için zgrep aracını kullanabiliriz.

Biliyorum çok çok basit bir örnek olacak fakat ben daha önce sıkıştımış olduğum test dosyası içinde “de” ifadesi geçiyor mu diye kontrol etmek için zgrep aracını kullanmak istiyorum. Çıktıların renklendirilmesi için de komutumuz zgrep —color “de” test.gz şeklinde giriyorum.

Bakın tam olarak “de” ifadesi ile eşleşen kısım renkli şekilde zgrep aracı yardımıyla filtrelenmiş oldu.

Aynı testi zgrep yerine grep aracını kullanarak da deneyebiliriz. Bakın herhangi bir çıktı almadık çünkü grep aracı sıkıştırılmış olan dosyanın içeriğini doğru şekilde tarayıp filtreleyemedi. cat ve grep araçlarının gzip ile sıkıştırılmış dosyalar üzerindeki en temel çalışma biçimi işte bu şekilde.

Ayrıca tıpkı gzip aracında olduğu gibi diğer algoritmalar içinde benzer şekilde çözümler sağlayan alternatif araçlar mevcut olduğuna dikkatinizi çekmek istiyorum. Örneğin bzip2 algoritması için bzcat aracını kullanabiliyoruz. Ben tüm bu araçlardan tek tek bahsetmeyeceğim çünkü cat less more grep diff ve benzeri araçların kullanımlarını daha önce ele aldık sizin tek yapmanız gereken sıkıştırma algoritmasına uygun olan aracı bulup kullanmak.

# zip ve rar

Normalde Linux üzerinde çok sık karşılaşmayacak olsak da ihtiyacımız olabileceği için zip ve rar arşivlerinden de bahsetmek istiyorum. 

Zip ve rar algoritmalarını diğer algoritmalardan ayrı olarak ele alıyor olma nedenim lisans ve dosya özelliklerinin korunmamasıyla ilgili olan farklılıklardır. 

rar iyi sıkıştırma oranı sunuyor olsa da tescilli olan rar algoritması özgür lisansa sahip değil. Sıkıştırılmış dosyaların açılması konusunda lisans sorun olmuyorken, yeni dosyaların sıkıştırılması rar algoritmasının tescilli olması dolayısıyla bir handikap. Üstelik özgür lisansa sahip pek çok açık kaynaklı alternatif olduğu için rar kullanımını Linux üzerinde pek sık görmezsiniz. 

Ayrıca rar ve zip algoritmaları kullanılarak yapılan sıkıştırmalarda, linux üzerindeki dosyanın sahiplik izinleri ve benzeri dosya özellikleri kayboluyor. Elbette istisnalar hariç sıkıştırılan dosyaların açıldıklarında önceki dosya özelliklerini korumasını isteyeceğimiz için rar veya zip algoritmaları öncelikli tercihimiz olmuyor. Biz yine de ihtiyaç duyduğumuz arşiv oluşturma ve mevcut arşivleri çıkarmak hakkında bilgi sahibi olalım. Zaten en temel işlevler olan arşiv oluşturma ve mevcut arşivleri çıkarmayı ele alacağız sadece.

# zip

zip özellikle pek çok işletim sistemi ortamında ortak olarak kullanılabildiği için sistemler arası ortak bir arşivleme ve sıkıştırma yöntemi olarak tercih ediliyor. Eğer kullanmakta olduğunuz sistemde zip aracı varsayılan olarak yüklü gelmiyorsa sudo apt install zip -y veya sudo dnf install zip -y komutu ile kolayca kurabilirsiniz.

Aracımızın kullanımı hakkında bilgi almak için yardım bilgisine göz atabiliriz. zip —help komutunu girelim. Bakın kullanılabilir seçenekler listelendi. Örneğin dizinleri arşivlemek için recursive yani özyineleme seçeneğini temsil eden -r seçeneğini kullanmamız gerekiyor. -r seçeneği sayesinde ilgili klasörün altındaki dizinlere de ulaşılmış oluyor. Ayrıca sıkıştırma seviyesi gibi seçeneklere de sahip olduğunu buradaki yardım bilgisinden görebiliyoruz. 

Ben websitesinin dosyalarını zip ile sıkıştırmak istediğim için komutumu zip -r linux.zip linux-dersleri şeklinde giriyorum. Buradaki r seçeneğini eklemezsek alt dizinlerdeki dosyalar sıkıştırılmayacak. Klasörleri sıkıştırırken r seçeneği önemli yani. Zaten şimdiye kadar klasörler üzerinde çalışırken bu durumdan tekrar tekrar bahsettik. Hatta test etmek için -r seçeneği olmadan komutumuzu girelim.

Bakın işlem anında tamamlandı. İşlem tamamlandı ama aslında alt dosya ve klasörler bu sıkıştırılmaya dahil edilmedi. Bu durumu teyit etmek için ls -l komutunu girebiliriz. Bakın oluşturulan dosyanın boyutu çok çok küçük. Yani aslında klasörün tüm içeriğinin sıkıştırılmadığını buradan da teyit edebiliyoruz. Şimdi aynı komutu bu kez -r seçeneğini de ekleyerek girelim.

Bakın adım adım tüm sıkıştırma işlemlerini konsoldan takip edebiliyoruz. Şimdi tekrar ls -l komutu ile dosyanın boyutunu kontrol edelim. Bakın bu kez dosyanın boyutu daha gerçekçi bir oranda küçülmüş. Yani klasörün alt dizinlerindeki tüm dosya ve klasörlerin dahil edildiğini tahmin edebiliyoruz. Hatta teyit etmek için sıkıştırılmış dosya içeriğini dışarı çıkarabiliriz. 

zip ile sıkıştırılmış olan dosyaları dışarı çıkarmak için unzip aracını kullanmamız gerekiyor. Mevcut dizine çıkardığımızda aynı klasörün yerini alacağı için ben öncelikle sıkıştırmak için kullandığım klasörü silmek istiyorum. rm -r linux-dersleri komutu ile klasörümü sildim. Şimdi unzip linux.zip komutunu girelim. Bakın tek tek tüm dosyalar çıkarıldı. cd komutu ile çıkarılan dizine geçiş yapalım ve dizin içeriğini ls komutu ile listeleyelim. Görebildiğiniz gibi sıkıştırılmış dosya içeriği sorunsuzca dışarı çıkarılmış. 

## rar

Normalde rar aracı ubuntunun mevcut sürümünde varsayılan olarak yüklü gelmiyor. Dolayısıyla kullanabilmek için öncelikle kurmamız gerekiyor. Kurmak için sudo apt install rar -y komutunu girebiliriz. 

Aracım kısa sürede kuruldu, şimdi nasıl çalıştığına göz atmak için manual sayfasına yada doğrudan kendi yardım çıktıları için rar komutunun çıktılarına bakabiliriz. Ben rar şeklinde yazıp komutumu onaylıyorum. 

Rar algoritmasının tescilli olduğundan bahsettik. Aldığımız yardım çıktılarının en başına bakacak olursak, bakın burada da kurmuş olduğumuz rar aracının deneme sürümü olduğunu görebiliyoruz. Rar tescilli olduğundan, şu anlık yalnızca bireysel kullanım için deneme sürümüne sahibiz. 

Tamamdır, rar algoritmasının tescilli olduğunu artık biliyoruz. Şimdi buradaki yardım çıktılarına göz atarak nasıl yeni arşiv oluşturabileceğimize göz atalım.

Bakın arşive dosya eklemek için a parametresini kullanmamız gerekiyormuş. Bu seçenek sayesinde eğer hiç yoksa yeni arşiv oluşturabilir, eğer varsa da yeni dosya ekleyebiliriz. Mevcut arşivi çıkarmak için de e parametresini kullanıyoruz. Hemen deneyelim.

Ben denemek için yine websitesinin dosyalarını sıkıştırmak istiyorum. Rar aracını kullanırken dosya ekleme yaklaşımı kullanıldığı için ben klasörün içindeki tüm dosyaları belirtmek için yıldız joker karakterini kullanacağım. Yani komutumu rar a linux.tar linux-dersleri-master/* şeklinde giriyorum.

Yıldız karakteri ile işaret ettiğim için tüm dosyaların arşivle eklendiğini konsol üzerinden de takip edebiliyoruz. Şimdi ls -l komutu ile listeleyelim. Bakın rar arşivi oluşturulmuş üstelik gayet iyi sıkıştırma sağladığını, arşiv dosyasının boyutundan da anlayabiliyoruz. 

Şimdi oluşturduğumuz bu arşiv dosyasını dışarı çıkaralım. Çıkarmak için de x seçeneğini kullanabiliyoruz. Mevcut bulunduğumuz dizine çıkarmak istersek doğrudan rar x linux.rar şeklinde komutumuzu girebiliriz. Fakat halihazırda bu isimde klasör ve içinde aynı dosyalar bulunduğu için bizden onay istenecek. Hemen deneyelim. Bakın bize teker teke bu şekilde hangi dosyaların çıkarılması gerektiği soruluyor olacak. Ben tek tek uğraşmak istemediğim için hepsini temsil eden All yani büyük A yazıp onaylıyorum. 

Bakın arşiv içeriğinin çıkarılışını konsoldan takip edebiliyoruz. İşlem tamamlandı, şimdi ls komutu ile listeleyelim. Bakın dosya içeriğini x seçeneği sayesinde dışarı çıkarmayı başardık. Dilerseniz mevcut dizin yerine spesifik olarak çıkarılmasını istediğiniz dizini komutun sonunda belirtebilirsiniz. Yani örneğin benim durumda rar x linux.rar çıkarılacağı konum şeklinde komut girebilirdim.

Neticede rar ve zip aracı hakkında bahsetmek istediklerim bu kadar. Aslında tıpkı rar komutunun çıktılarında da gördüğümüz gibi pek çok özellik mevcut fakat ben lisans gereği pek sık kullanmaya ihtiyaç duymayacağımız için ek detaylardan bahsetmek istemiyorum.

rar ve zip araçlarının kullanımı ile ilgili merak ettiğiniz tüm ek bilgileri yardım sayfasından öğrenebilirsiniz. Zaten çok Linux üzerinde çok sıklıkla ihtiyaç duymayacağınız için yardım sayfaları üzerinden dilediğiniz zaman gerekli bilgileri edinebilirsiniz. 

Evet neticede arşivleme ve sıkıştırma işlemleri hakkında bilmemiz gereken temel bilgilerden bahsettik. Ben bahsetmedim ancak arşivleri parçalara bölmek veya şifrelemek ve çok daha fazla özellik için ihtiyaç duyduğunuz bilgileri hem manuel sayfalarından hem de internet araştırmalarından kolaylıkla öğrenebilirsiniz. Sadece şimdiye kadar kısaca bahsettiğimiz arşivleme ve sıkıştırma alternatiflerini düşündüğünüzde, hepsinden bahsetmemiz veya hepsini biliyor olmamız pek olası olmadığı bence gayet açık.  Bizim bu bölümdeki amacımız temel arşivleme ve sıkıştırma yaklaşımlarından haberdar olabilmemizdi. İhtiyaç duyduğunuz çözümler için her zaman ekstra araştırma yaparak çözümlere ulaşma imkanına internet sayesinde sahipsiniz zaten. 

Bir sonraki bölümde komut satırı üzerinden çeşitli bilgiler edinmemizi sağlayan komutlardan bahsederek devam ediyor olacağız.