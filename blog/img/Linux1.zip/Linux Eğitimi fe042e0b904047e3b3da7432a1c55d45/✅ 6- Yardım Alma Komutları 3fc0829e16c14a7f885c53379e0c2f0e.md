# ✅ 6- Yardım Alma Komutları

# **Yardım Almak**

Söz konusu bir işletim sistemini yönetmek olduğunda, neredeyse sınırsız çeşitlilikte pek çok aracı kullanmamız gerekeceği için her aracın her kullanım bilgisini aklımızda tutmamız mümkün ve mantıklı değildir. Neticede zaman içinde ihtiyaçlarımıza göre pek çok farklı aracın pek çok farklı özelliğini kullanacağız. Sık kullandığımız araçlar ve bu araçların sık kullandığımız özellikleri dışındaki çoğu bilgiyi unutmamız son derece normal. Unutmaya ek olarak ayrıca her zaman internete erişmemiz de mümkün olmayabilir. Yani internet üzerinden unuttuğumuz bilgilere bakmamız kimi zaman mümkün olmayabilir. Bu noktada en büyük dostumuz, sistemde mevcut bulunan yani çevrimdışı ulaşılabilir olan yardım sayfalarıdır. En yetenekli ve bilgili sistem uzmanları bile gerektiğinde yardım sayfalarına göz atarlar. Bizler de hem öğrenme aşamasında hem de daha sonrasında sıklıkla yardım sayfalarını kullanıyor olacağız.

Yani özetle, bu bölümde kelimenin tam anlamıyla öğrenmeyi öğreneceğiz.

Grafiksel arayüzlü araçları kullanırken sezgisel olarak özellikleri keşfetmek ve hatırlamak komut satırı araçlarına oranla daha kolaydır. Çünkü grafiksel arayüzde menüleri kurcalayabilir ve çeşitli butonlara tıklayarak etkilerini gözlemleyebilirsiniz. Ancak komut satırı üzerinden kullanılan araçlarda grafiksel arayüzdeki gibi sezgisel olarak keşif için gerekli ortam yoktur. Çoğu zaman yerine getirilmesini istediğiniz görevleri spesifik olarak yazılı komutlarınızla belirtmeniz gerekir. İlgili komutu bilmiyorsanız işlemi yapamazsınız. Bu nedenle komut satırı arayüzü ile çalışan araçlar, tüm özelliklerini iyi biçimde açıklayan yardım dokümantasyonlarına sahiptir. 

Linux’un kendi bünyesinde bulunan özellikleri, yapıları ve araçları açıklayan dokümanların yanında, sisteme kurulan harici araçlarla birlikte gelen yardım sayfalarının da sayesinde çevrimdışı şekilde ulaşabileceğimiz oldukça geniş bir yardım kaynağına sahibiz. 

Ayrıca, Linux'un bünyesinde bulundurduğu yardım sayfalarının dışında da birçok yardım alma kaynakları mevcuttur. Zaten zamanla göreceksiniz ki; Linux'a kurmak için edindiğimiz hemen her araç veya program kurulum dosyalarının beraberinde, kurulum ve kullanımla ilgili açıklamayı içeren belgelerle birlikte geliyor olacak.

Bu bağlamda, Linux sistemlerinin temel doküman-bilgi kaynaklarını 4 türe ayırabiliriz.

Bunlar; 

- kısa bilgi açıklamaları**(help)**
- **kılavuz sayfaları(manuel)**
- **bilgi sayfaları(info)**
- **uygulamalar ile gelen dokümanlar**dır.

Bizler de zaman zaman unuttuğumuz için veya bilmediğimizden dolayı, bu yardım sayfalarına ve dokümanlarına danışıyor olacağız. Yardım sayalarını kullanabilmek, gerçekten oldukça önemli. Sistemi verimli şekilde yönetebilmek istiyorsanız kısa sürede aradığınız bilgiye nasıl ulaşacağınızı bilmeniz gerekiyor. Zaten zaman içinde yardım sayfalarının ne kadar faydalı olabileceğine bizzat şahit olup sıklıkla kullanacaksınız. Bu girizgahtan sonra artık yavaş yavaş yardım alma komutlarımıza geçebiliriz. Öncelikle help komutu ile başlayalım.

### help Komutu

Daha önce, yerleşik ve harici komutların neler olduğundan bahsetmiştik. Yerleşik komutlar kabuğun beraberinde gelen çeşitli araçlardı. İşte help komutu da kabukta yerleşik olarak bulunan komutların yardım açıklamalarına ulaşmak için kullandığımız bir araçtır. Hemen denemek için yerleşik bir komut olan `echo` komutunun yardım bilgilerini görüntüleyelim. Bunun için tek yapmamız gereken `help` komutunun ardından yardım bilgisine ulaşmak istediğimiz yerleşik komutu belirtmektir. Ben echo aracı hakkında bilgi almak istediğim için `help echo` komutunu giriyorum.

Bakın, gördüğünüz gibi help komutu echo aracı hakkında çeşitli özet bilgiler sunan yardım bilgisini anında konsola bastırdı. Çıktıları inceleyecek olursak; ilk olarak komutun nasıl kullanıldığına dair örnek gösterim bulunuyor. Örneğin echo komutunun ardından seçenekleri yazıp, daha sonra argümanları girebileceğimiz basit şekilde ifade edilmiş. Alt tarafta ise araç hakkındaki bilgileri görebiliyoruz. Hakkında bilgi almak istediğimiz aracın işlevini buradan kısaca öğrenebiliyoruz.

Kısa açıklamanın ardından kullanabileceğimiz seçeneklerin de açıklamalarıyla birlikte listelenmiş olduğunu görebiliyoruz.

Neticede buradaki yardım çıktılarına bakarak, sorguladığımız araç hakkında tüm temel bilgileri kolayca öğrenebiliyoruz. 

Zaten bizler de help komutunu, genellikle ilgili komutun kullanım seçenekleri ve işlevleri hakkında kısaca bilgi almak istediğimizde sıklıkla kullanıyor olacağız. Sizler de bash kabuğunda yerleşik olan araçlar hakkında bilgi almak istediğinizde help komutunu kullanabilirsiniz. 

Ayrıca hazır yeri gelmişken help komutunun yalnızca yerleşik olan araçlar hakkında bilgi sunduğunu teyit etmek için yerleşik olmayan bir aracın yardım bilgisini help komutu üzerinden sorgulamayı da deneyebiliriz. Ben denemek için harici bir araç olan chmod aracını help ile sorgulamak istiyorum.

Bakın, chmod araç harici bir araç olduğu için help komutu bilgi sunmadı. Çıktı olarak da bu ifade ile eşleşen bir yardım konusunun bulunamadığı ve alternatif olarak nasıl bilgi alabileceğimiz burada belirtilmiş. Bu alternatiflerden daha sonra ayrıca bahsedeceğiz. Ben şimdi tüm araçların kendi bünyesinde bulundurduğu yardım bilgisine nasıl ulaşabileceğimizden bahsetmek istiyorum.

`help` komutunu kullanmak yerine dilerseniz, ilgili aracın isminden sonra —help komutunu da kullanabilirsiniz. Hemen chmod aracının yardım bilgisini görmek için chmod —help şeklinde komutumuzu girelim. Bakın tıpkı daha önce help komutu ile bash kabuğuna yerleşik olan echo aracı hakkında aldığımız yardım bilgisi gibi, —help seçeneği sayesinde harici araç olan chmod aracı hakkında da yardım bilgisi sorunsuzca konsola bastırıldı.

Burada kullanmış olduğumuz —help seçeneği, istisnalar hariç genellikle tüm araçların temel yardım bilgilerini sunuyor. Üstelik aslında hem dahili hem de harici komutlar için —help seçeneğini de kullanabiliyoruz. 

Tam da bu noktada olası kafa karışıklıklarını önleyebilmek için help aracının ve —help seçeneğinin kullanımına açıklık getirmek istiyorum.

Yerleşik komutların pek çoğu da dahil —help seçeneği kullanılarak ilgili komutla ilgili bilgi alabiliriz dedim. Örneğin yerleşik bir komut olan cd komutu hakkında bilgi almak için dilersek help cd komutunu ya da cd —help komutunu kullanabiliriz. Sırasıyla komutlarımızı girip sonuçlarına bakalım.

Bakın her iki çıktı da birebir aynı yardım bilgisini konsola bastırdı. Bu örnek ile yerleşik komutlarda da —help seçeneğini kullanabileceğimizi görebiliyoruz ancak istisnai olan komutlar da bulunduğu için help komutuna da ihtiyacımız var. Örneğin echo aracı hakkında bilgi almak için echo —help şeklinde komut girmeyi deneyebiliriz. Bakın yardım bilgisi yerine doğrudan —help ifadesi konsola bastırıldı, çünkü echo aracının görevi kendisine argüman olarak verilmiş olan değerleri konsola bastırmaktır. Heh, işte tam da echo komutunda da olduğu gibi bazı yerleşik komutlar hakkında bilgi almak için help aracına ihtiyaç duyabiliyoruz. Eğer hakkında bilgi almak istediğiniz yerleşik bir komut varsa ve bu komut —help seçeneği ile bilgi sunmuyorsa help komutundan sonra ilgili yerleşik komutu yazıp bilgi alabilirsiniz. Dolayısıyla yerleşik komutların istisnaları haricinde neredeyse tüm komutlar —help seçeneği ile yardım bilgisi sunabiliyor. Tek yapmanız gereken bu seçeneği kullanıp çalışıp çalışmadığını denemek. İstisnalar hariç tüm araçlar size bilgi sunmak için —help seçeneğini kullanmanızı bekliyor zaten.

Umarım help komutu ve —help seçeneği arasındaki fark net bir biçimde anlaşılmıştır. Çünkü komutlar hakkında kısa ama etkili şekilde bilgi almak için bu yöntemleri sıklıkla kullanıyor olacağız.

## man(Manual Sayfası) Komutu

Bir diğer yardım kaynağımız da man komutu ile ulaşabildiğimiz ve man pages olarak geçen yardım sayfalarıdır. 

Manual ifadesinin kısalmasından gelen man sayfaları sistem üzerindeki araçlar için temel yardım bilgileri içeren hiyerarşik düzende bulunan dosyalardır. Buradaki manual ifadesinin nereden geldiğini almak için internet üzerinde manuals ifadesini aratabiliriz. Eğer internet üzerinde görsel arama kısmına manuals ya da product manuals şeklinde yazıp aratırsak, karşımıza çeşitli ürünlerin kullanımlarını ve özelliklerini açıklayan kılavuz sayfalarının resimleri gelecektir. Zaten bu görseller size tanıdık geliyordur. Örneğin bir telefon veya benzeri bir araç aldığınızda mutlaka kutu içeriğinden kullanma kılavuzu da çıkmıştır. Heh, işte man olarak geçen yardım sayfaları da tıpkı gerçek hayattaki kılavuz sayfaları gibi sistemimizde yüklü bulunan araçlar hakkında bilgi sunan kılavuz sayfalarıdır. Man ismi de doğrudan buradan geliyor. 

Sistemde varsayılan olarak yüklü bulunan araçlar ve sistemin bileşenleri bu manuel sayfalarında tek tek açıklanmıştır. Ayrıca istisnalar hariç, sisteme yeni yüklenen araçlar da beraberinde ilgili araç hakkında bilgi içeren manuel sayfalarıyla birlikte gelirler. Bu yaklaşım sayesinde, sistem üzerinde yüklü bulunan neredeyse tüm araçlar hakkında çevrimdışıyken de bilgi alabileceğimiz hiyerarşik düzende bir referans kılavuzuna sahip oluyoruz.

Manual sayfalarına ulaşmak için de başta söz ettiğimiz man komutunu yani aslında man aracını kullanıyoruz.

man komutunu kullanmak için komut satırına, hakkında bilgi edinip yardım almak istediğimiz komutu `man komut` şeklinde girmemiz yeterli. Örneğin ben chmod hakkındaki bilgilere ulaşmak istiyorsam konsola man chmod şeklinde yazarak gerekli bilgilere kolayca ulaşabilirim. Görebildiğiniz gibi chmod aracının manuel sayfası açılmış oldu. Tüm içerik elbette şu an gözüktüğü kadarla sınırlı değil.

Açılan bu kılavuz sayfasında yön tuşlarını kullanarak satır satır ilerleyebiliyoruz. Eğer sağ tarafta kalan yani ekrana sığmayan yazılar varsa sağ sol tuşları ile bu yazıları da görebiliyoruz. Yani bildiğiniz yön tuşları ile tüm sayfa içeriğinde özgürce dolaşabiliyoruz. Ayrıca hızlıca alt satırlara inmek istersek sayfa sayfa atlamak için space tuşunu da kullanabiliyoruz. Zaten alt çubuktan da tüm manuel sayfasının ne kadarını okuduğunuzu kolayca takip edebilirsiniz. Ayrıca man sayfasının kısayollarını ve kullanımını görmek isterseniz man sayfası açıkken h tuşuna basarsanız sizi man kılavuzunun yardım sayfası karşılar, orada man komutunun kullanımı ile ilgili detaylı bilgi yardımı mevcuttur. Esasen bu kılavuz sayfasında gezinmek için space ve yukarı aşağı yön tuşları çoğu zaman yeterli olacağı için buradaki detaylı bilgilere pek ihtiyacınız olmayacaktır. Ben yalnızca arama özelliğinden faydalanıyorum.

Eğer bilgi sayfaları çok uzunsa dilerseniz siz de arama özelliğini kullanabilirsiniz. Manuel sayfaları içinde arama yaparken iki temel seçeneğe sahibiz. Eğer mevcut bulunduğumuz satırdan daha ilerideki eşleşen kelimeleri bulmak istiyorsak slash işaretinden sonra aramak istediğimiz kelimeyi yazabiliriz. Ben örnek olarak /change komutu ile ileriye doğru change ifadesini araştıyorum. Bakın aldığım çıktıda change ifadesi ile eşleşen bölümler belirgin şekilde aydınlatıldı. Ve sayfayı biraz yukarı kaydırdığımda aslında change ifadesi ile eşleşen başka bölümlerin de olduğunu ancak ben slash ile arama yaptığım için bunların görmezden gelindiğini teyit edebiliyorum. 

Eğer bulunduğumuz satırın gerisinde arama yapılmasını istiyorsak da soru işaretinin ardından araştırmak istediğimiz kelimeyi yazabiliyoruz. Ben yine change ifadesini yazıyorum. Bakın bu kez de yukarı doğru araştırma yapıldı ve uygun kelime aydınlatıldı. 

Aşağıdaki kelimeler için slash, yukarıdakiler için soru işareti kullanabiliyoruz. Aşağı ve yukarı araştırma seçenekleri dışında bence en önemli özellik eşleşen ifadeler arasında hızlıca geçiş yapabilmek. Yani eşleşmeler arası ileri geri atlayabilmek. Önceki ve sonraki eşleşmelerde atlama yapmak için n ve büyük N karakterlerini kullanabiliyoruz. 

Mevcut kılavuz yani manuel sayfası içinde arama yapmak istiyorsanız slash işaretinin ardından aradığınız kelimeyi girmeniz yeterli olacaktır. Küçük n karakterini peşi sıra kullanarak aşağıdaki eşleşmelere doğru atlayabildiğim gibi büyük n karakteri ile de tersi yönde önceki eşleşmelere kolayca geçiş yapabiliyorum. Ben şahsen çoğunlukla slash işaretinin arından aradığım ifadeyi yazıp n ve büyük N tuşlaması ile eşleşmeler arasında atlayarak aradığım bölümü buluyorum. Arama özelliği dışında manuel sayfalarındaki diğer kısayollar ile pek haşır neşir olduğumu söyleyemem. Yine de sizler göz atıp neler yapabileceğinizi kendiniz değerlendirebilirsiniz.

Kılavuz sayfasını kapatmak isterseniz de, sadece q tuşuna basmanız yeterli olacaktır. Neticede görebildiğiniz gibi herhangi bir araç hakkında bilgi almak üzere manual sayfalarını kullanmak çok basit. Şimdiye kadar nasıl açılıp, sayfalardan nasıl gezinebileceğimizden bahsettik.

Şimdi biraz da **man** sayfasının iç yapısına yani sayfa düzenine kısaca değinelim istiyorum. Elbette hakkında bilgi aldığınız araca göre, kılavuz sayfasındaki başlıklar da farklı olabilir. Ancak ben yine de temel olan ve sıklıkla karşılaşacağımız başlıklardan kısaca bahsetmek istiyorum. Ben örnek olması açsından tekrar chmod aracının manuel sayfasını referans alarak bölümleri açıklamaya çalışacağım. Benim açıkladığım başlıklar haricinde farklı başlıklara karşılaşırsanız da elbette İngilizce karşılıkları sayesinde kolayca kavrayabilirsiniz. Manuel sayfasının bölümlerini kısacak açıklayacak olursak:

- **NAME:** İlgili aracın isminin ve işlevinin kısaca açıkladığı bölümdür.
- **SYNOPSIS:** Aracın nasıl kullanılacağına dair kısa açıklamalar ve örnek komutları içerir. Bu bölümde genellikle sık kullanılan seçenek ve parametrelerinin nasıl girilmesi gerektiği şablon olarak gösterilir.
- **DESCRIPTION:** İlgili aracın yerine getirdiği görev hakkında nispeten daha uzun ve detaylı şekilde açıklama içeren bölümdür.

Ayrıca görebildiğiniz gibi chmod komutuna özel olan birkaç alt başlık daha bulunuyor. Araçlara özel olarak eklenmiş olan bu tür benzersiz başlıklar ile sıklıkla karşılaşacaksınız zaten. Çünkü araçların pek çoğu benzersiz özellikleri dolayısıyla benzersiz ek açıklamalara ihtiyaç duyabiliyor. Yani bu alt başlıklar doğrudan tüm manuel sayfalarında göreceğiniz standart bölümleme kategorisinin bir parçası değiller. Diğer standart bölümler ile devam edecek olursak:

- OPTIONS: Komutun sahip olduğu seçenekler ve bu seçeneklerin kullanımı hakkında bilgi sunan bölümdür. Buradaki bilgiler çoğunlukla ilgili aracın —help seçeneği ile sunulan seçenek bilgileridir. Hatta denemek için yeni konsol açıp chmod —help şeklinde komutumuzu girebiliriz. Bakın burada manuel sayfasındaki seçeneklerin derli toplu bir çıktısı bastırıldı. Ayrıca manual sayfasının başındaki aracın örnek kullanımı yani snopsis bölümünün de —help seçeneği sayesinde bastırıldığını görebiliyoruz. Zaten istisnalar hariç, araçların —help seçeneği ile sunduğu yardım bilgileri bu şekilde manuel sayfalarında yer alan temel bilgilerin listelenmesidir.
- AUTHOR: Yazarların isimleri ve iletişim bilgilerinin yer aldığı bölümdür.
- REPORTING BUGS: Hata veya eksikleri bildirebileceğiniz iletişim adresleri hakkında bilgi sunuyor.
- COPYRIGHT VE SEE ALSO: Son bölümde ise, telif hakları ve daha fazla bilgiyi nereden alabileceğimiz gibi ekstra detayları belirten açıklama bulunuyor.

Ayrıca chmod komutunun manuel sayfasında karşılaşmadık ama, genelde ilgili aracın kullanıma dair örnekler de EXAMPLES başlığı altında sunulabiliyor. Bu bölümde genellikle çok sık tercih edilen, ya da aracın kabiliyetlerini kavramamızı sağlayacak örneklere sıklıkla yer veriliyor. İleride farklı araçların manuel sayfalarını okurken mutlaka örnekler başlığı ile de sıklıkla karşılaşırsınız.

Artık, ihtiyaç duyduğumuzda kılavuz sayfalarından nasıl bilgi edinebileceğimizi öğrendik. Peki ama bu kılavuz sayfalarındaki bilgiler de nereden geliyor ?

Kısaca yanıt vermem gerekirse, man kılavuzunun sayfaları /usr/share/man konumu altında hiyerarşik düzende tutuluyor. Yani konsol ekranına basılan yardım(kılavuz) bilgileri bu konum içerisinde yer alan dosyalar kullanılarak sunuluyor. Bu dizinin içeriği hakkında konuşabilmek için öncelikle bu dizine geçiş yapalım. Dizin içeriğine göz atmak için cd komutunun ardından geçiş yapmak istediğimiz dizini yani /usr/share/man adresini yazıp komutumuzu onaylayalım. Dizin içeriğini konsola bastırmak için de ls komutunu kullanabiliriz.

Bakın burada pek çok farklı dili temsil eden klasörler bulunuyor. Çünkü dillere özel olan yardım dosyaları, ilgili dili temsil eden dizin altında tutuluyor. Örneğin fransızca manual sayfaları fr dizini altında tutulurken, Türkçe için tr dizini kullanılıyor. Sizin kullandığınız sistemde farklı diller için de manual sayfaları bulunabilir. Burada benim dikkatinizi çekmek istediğim detay farklı diller için de manuel sayfalarının bulunduğu. Bu diller dışında elbette standart dil olan ingilizce içinse doğrudan bir klasör bulunmuyor. Varsayılan dil ingilizce olduğu için ek olarak bir alt klasör daha oluşturulmamış. Manuel sayfaları buradaki man1 man2 ve man 9 diye devam eden klasörler içinde tutuluyor. Zaten diğer dillerin klasör içeriklerini listelerseniz bu şekilde man 1 man2 diye devam eden klasör içeriklerini görebilirsiniz.

Manuel sayfalarının farklı dillere çevrilmesi kimi kullanıcılar için kolaylık sağlasa da manuel sayfalarının yerelleştirilmesi çoğunlukla eksik kaldığından en doyurucu bilgiye standart olan İngilizce dili üzerinden ulaşabiliyoruz. Bu sebeple ben sizlere ingilizce haricindeki manuel sayfalarını kullanmanızı önermiyorum. En ulaşılabilir ve en detaylı olanı ingilizcede bulunuyor. Eğer kendi dilinizde kullanmak isterseniz kısa bir araştırma ile nasıl yapabileceğinizi öğrenebilirsiniz. Tek yapmanız gereken ilgili manuel sayfalarını indirip, man aracını kullanırken Türkçe dili için uygun olan sayfaların kullanılmasını sağlamak. Ben ele almıyorum çünkü kullanımını faydalı bulmuyor. Ancak söylediğim gibi eğer manuel sayfalarını Türkçe kullanmak istiyorsanız kısa bir araştırma ile nasıl yapabileceğiniz öğrenebilirsiniz.

Şimdi benim asıl odaklanmak istediğim detay, manuel sayfalarının neden bu şekilde isimlendirilmiş oldukları ve bu klasör isimlerinin sonundaki rakamların ne anlama geldiği.

Normalde 8 farklı manual klasörü bulunuyor, çünkü manuel sayfaları sekiz farklı hiyerarşik kategoriye göre ayrılmıştır. Esasen hangi kategorinin hangi manuel grubunda olduğunu bilmemiz veya hatırlamamız gerekmiyor. Çünkü hakkında bilgi almak istediğimiz araç veya konuyu man komutunun ardından argüman olarak yazarak kolayca ulaşabiliyoruz. Ben yine de hazır kategorileşmeden bahsetmişken buradaki rakamların anlamlarını hakkında kısa açıklamada bulunmak istiyorum ;

- **man1:** genel kullanıcı araçları: kullanıcılar tarafından kabuk aracılığı ile çalıştırılan çeşitli araçlar hakkında bilgi burada bulunuyor.
- **man2:** sistem çağrıları hakkında bilgiler bu grupta
- **man3:** sistem çağrıları hariç kütüphane fonksiyonları hakkında bilgiler
- **man4:** çeşitli cihazlar bazı özel dosyalar hakkında bilgiler de bu grupta bulunuyor
- **man5:** çeşitli konfigürasyon dosyaları ve okunabilir dosya içerikleri hakkında açıklamalar bu gruba dahil edilmiş
- **man6:** ekran koruyucuları ve oyunlar gibi araçlar hakkındaki bilgiler bu grupta
- **man7:** çeşitli konuların, kuralların ve protokollerin, karakter seti standartlarının, standart dosya sistemi düzeninin ve çeşitli diğer şeylerin genel bakışları veya açıklamaları.
- **man8:** sistem yönetimini ve bakımı için gerekli olan araçlar hakkında bilgi almak için de bu gruptaki bilgilerden faydalanıyoruz.

Ayrıca burada benim aldığım çıktıda görebileceğiniz gibi 9. manuel sayfasıyla da karşılaşabilirsiniz. Bu manuel sayfası da birtakım çekirdek özellikleri ve arayüzleri hakkında bilgi sunan kılavuz bilgilerinin bulunduğu bölümdür. Her zaman bu manuel sayfası ile karşılaşmıyoruz. Ancak ben sanal makine üzerinden çalıştığım için bende bu dizin de mevcut. Bu dizinde ne olduğunu öğrenmek için geçiş yapıp dizin içeriğini listelemek istiyorum. Örneğin bakın ben sanal makine üzerinden kullandığım için sanal ağ bağdaştırıcısı hakkında bilgi sunan vmxnet isimli manuel sayfası burada bulunuyormuş. 

İşte manual kategorilerinin açıklamaları en özet haliyle bu şekilde.

Bunları sırasıyla açıkladım, ancak açıklamak için manuel sayfasının kendisine göz atıp hangi grubun hangi amaç için olduğuna bakıp öğrendiğim için buraya ekleyebildim. Yoksa hangi grubun hangi amaçla oluşturulduğu hafızamda tutmuyorum. En azından ben şu ana kadar böyle bir ihtiyaç duymadım.

Yani doğrudan hangi kategorinin hangi klasörde yer aldığını biz kullanıcılar olarak bilmek zorunda değiliz. Biz man komutunun ardından hakkında bilgi almak istediğimiz konuyu girip ilgili bilgiye doğrudan erişebiliyoruz. Örneğin bir araç hakkında bilgi alacaksak, man komutunun ardından o aracın ismini yazmamız yeterli oluyor. Ancak benim burada kategorileri tek tek ele alarak vurgulamak istediğim yani farkında olmanızı istediğim detay, bir aracın birden fazla manuel grubunda açıklama sayfalarının bulunabileceği. Yani herhangi bir araca ait kılavuz bilgileri farklı kategoriler altında manuel sayfalarına eklenmiş olabilir. Bu sebeple ilgili araç hakkında tüm bilgilere erişmek için ilgili aracın tüm manuel sayfalarına baktığımızdan emin olmamız gerekiyor. Her zaman olmasa da kimi zaman birden fazla manuel sayfasına bakmamız gerekebilir. 

Normalde yalnızca man komutunu kullandığımızda ilk manuel dizininde yer alan manuel sayfası karşımıza getiriliyor. Ancak belki de bizim aradığımız bilgi başka bir manuel sayfasında bulunuyor olabilir. Örneğin aynı aracın diğer manuel sayfası 2. manuel kategorisine dahil edildiyse bu manuel sayfasını açmak için man 2 chmod komutunu girmemiz gerekiyor. Buradaki 2, ikinci manuel kategorisine bakılması gerektiğini belirtiyor. Birden fazla manual sayfasının olması güzel, peki ama biz hangi aracın hangi manuel sayfalarında bilgilerinin bulunduğunu nereden bileceğiz ? Elbette bunun da bir çözümü var, bu iş için whatis komutunu kullanabiliriz. 

### whatis Komutu

Bu komut sayesinde hangi komutun hangi `man` sayfasında olduğunu kolayca öğrenebiliyoruz. Daha iyi anlamak için hemen örnekler yapalım. Komutun kullanımı `whatis araştırılacak_komut` şeklindedir. Ben passwd aracının kılavuz bilgilerinin hangi manual sayfalarında olduğunu öğrenmek istediğim için komutumu `whatis passwd` şeklinde giriyorum.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/2-%20Yard%C4%B1m%20Alma%20Komutlar%C4%B1/7.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/2-%20Yard%C4%B1m%20Alma%20Komutlar%C4%B1/7.png)

Bakın, yanıt olarak 5. 1. ve ayrıca 1ssl isimli manual sayfalarında passwd aracı hakkında bilgi bulunduğunu öğrenmiş olduk.

Artık ben bu bilgi sayesinde passwd aracı için yalnızca 1. manuel sayfasındaki bilgiler ile yetinmeden 5. manuel sayfasındaki bilgilerine de man 5 passwd komutu ile ulaşabilirim. 

Belki tam bu noktada neden tek bir araç hakkında tek bir manual sayfasında tüm bilgiler verilmiyor da ayrı ayrı gruplanmışlar diye düşünmüş olabilirsiniz. Elbette daha önce de açıkladığım şekilde, manuel sayfalarının 8 kategoride gruplanmasının bir nedeni var. Örneğin görebildiğiniz gibi passwd aracının 5. gruptaki manual sayfası çeşitli konfigürasyon dosyaları hakkında bilgi sunarken, 1. gruptaki dosyası aracın kullanımı hakkında genel bilgi sunuyor. Kıyaslamak için yeni konsolda passwd aracının 1. manual sayfasına göz atabiliriz. Bakın 1. sayfada aracın kullanımına dair bilgiler sunuluyorken, 5. sayfada konfigürasyon dosyaları hakkında çeşitli bilgiler bulunuyor.

Hatta manual sayfalarını listelerken passwd aracı için 1ssl isimli manuel sayfasının olduğunu da görmüştük. Bu sayfaya göz atmak için de örneğin man 1ssl passwd şeklinde komutumuzu girebiliriz. Bakın bu manuel sayfası da OpenSSL özelinde passwd aracı hakkında bilgi sunan bir kılavuzmuş. 

Yani bizzat örnek üzerinden de görebildiğimiz gibi, birden fazla manual sayfası aynı araçla ilgili olmasına karşın, verdikleri bilgilerin türü dolayısıyla farklı gruplarda bulunabiliyorlar. Bu sayede araç hakkında gerektiği zaman gereken bilgiyi daha sade ve okunaklı olan ilgili sayfadan edinebiliyoruz. Ayrıca ileride sisteme yüklediğimiz harici ek araçlar ve bileşenler, sistemde mevcut bulunan araçlarla olan ilişkisi açıklamak için de mevcut manual sayfalarına müdahale etmeden yine ek manual sayfaları ekleyebilirler. Tıpkı passwd aracı için openssl örneğinde olduğu gibi, zamanla bir araç için birden fazla manual yardım bilgisinin sisteme eklenmesi ve bileşenler silindiğinde bu ek manual sayfalarının tekrar silinmesi de mümkün olur. Bu yaklaşım sayesinde sistemdeki mevcut hiç bir yardım sayfasına da zarar verilmemiş olur. İşte tüm bu sebepler dolayısıyla her manual sayfası kendi kategorisine göre bilgi sunmak için ayrı ayrı tutulmuştur. 

Dolayısıyla söz konusu yardım sayfaları olduğunda whatis aracı yardımıyla, araştırdığınız bilginin hangi manuel gruplarında olabileceğine dair genel fikir sahibi olabilirsiniz. Ayrıca sizlerin de bilgiği üzere aslında pek çok manual sayfasının sonunda, SEE ALSO yani “AYRICA BAKINIZ” başlığı altında ilgili araçla ilgili harici manual sayfalarına atıfta bulunuluyor. Burada daha geniş bilgi edinilebilmesi için ana konu hakkındaki ek sayfalar ve konu içinde geçen diğer ilişkili kavramlara dair ek manual sayfalarına da referans veriliyor. Ancak whatis komutu doğrudan tek bir araç özelindeki tüm manual sayfalarını listeleme konusunda daha etkili kolay bir yaklaşım.

İlgili aracın hangi manual sayfalarında açıklandığını whatis komutu ile öğrenebilmek büyük bir kolaylık. Peki ya bu araştırma işini bir adım daha ileriye götürüp, araç veya aracın kısa işlev açıklaması ile eşleşen manual sayfalarını listeleyebilmek isteseydik ne yapmamız gerekirdi ?

Gelin bu sorunun cevabını `man -k` ve `apropos` komutlarını kullanarak yanıtlamaya çalışalım.

### Manual Sayfalarında Araştırma

Manual sayfaları her ne kadar bütüncül olarak faydaları kaynaklar olsa da manuel sayfalarını yalnızca yekpare bilgi almak için kullanmanız gerekmiyor. Yani manual sayfalarını yalnızca dokümanları baştan sonra okumak için kullanmamız şart değil. Örneğin yalnızca manual sayfalarının başında yer alan, ilgili aracın isminin ve işlevinin açıklandığı bölümden de faydalanmak isteyebiliriz. Öncelikle man passwd komutu ile bir manual sayfası açalım. Bakın burada isim bölümünde, daha önce de izah ettiğimiz şekilde, aracın ismi ve işlevi hakkında kısa bir açıklama bulunuyor. İşte bizler bu bölümdeki açıklamaları kullanarak, aracın isminden kısaca işlevini ya da tersi şekilde, aracın işlev açıklamasından aracın adını bulabiliriz. Örneğin passwd aracının işlevini yani kullanıcı parolası değiştirme işlevini hatırlıyorsunuz ancak passwd aracının ismi aklınıza gelmedi diyelim. Heh, işte tam bu noktada man komutunun -k seçeneğini kullanıp, argüman olarak aracın işlevini yazıp aratabilirsiniz. Şu an çok net anlaşılmamış olabilir hemen basit bir örnek üzerinden ele alalım. Bunun için hemen yeni bir konsol açalım, ve komut satırına `man -k passwd` komutunu girelim.

Görebildiğiniz gibi burada yazmış olduğum komut sayesinde manuel sayfasının NAME yani isim bölümünde yazan araç ismi ve kısaca açıklamasında `passwd` ifadesi geçen tüm manuel sayfaları tek tek konsola bastırıldı. Bakın burada, adında veya kısa açıklamasında passwd geçen tüm manual içerikleri bastırıldı. Kimisinin sadece adında, kimisinin de işlev açıklamasında passwd ifadesi geçiyor gördüğünüz gibi. Buradaki parantezler içinde de hangi manual sayfasında bu ifadenin geçtiği açıkça belirtiliyor. Daha önce passwd aracının birden fazla manual girdisi olduğunu görmüştük, buradaki çıktılarda da aynen bu bilgiyi alabildik. Diğer çıktılar isminin bir kısmında veya açıklamasının bir bölümünde passwd yani aradığımız ifade geçen manual sayfaları. 

Bu bilgilerin nerden geldiğiniz yani aslında biz araştırma yaparken nereye bakıldığını teyit edebilmek için passwd arcının 1. manual sayfasını açtığımız önceki konsola da göz atabiliriz. Bakın burada NAME bölümünde passwd aracının ismi ve yanında kısa işlev açıklaması bulunuyor. Eğer man -k komutunun çıktısında aldığımız çıktıyla kıyaslayacak olursak buradaki çıktıların aslında manual sayfalarının NAME yani isim bölümünden alındığını bizzat teyit edebiliyoruz. Bu durum çıktılarda yer alan diğer tüm sayfalar için de aynen geçerli. Teyit etmek isterseniz diğer manual sayfalarına da tek tek göz atabilirsiniz. Neticede işte bizler man -k komutu ile araştırma yaparken aslında tüm manual sayfalarının isim bölümlerine bakılıyor ve araştırdığımız ifade veya ifadeler ile eşleşen bir manual sayfası varsa bize çıktı olarak sunuluyor. 

Ben örnek olarak aracın ismini yazdım ancak manuel sayfalarında geçen dilediğiniz bir kelimeyi veya kelime gruplarını araştırmanız mümkündür. Ben bu kez yeni bir örnek olarak "change file" kelimelerini araştırmak istiyorum. Yani bu kez, aracın işlevinden aracın ismine ulaşmayı denemek istiyorum.

Görebildiğiniz gibi içerisinde tam olarak "change file" ifadesi geçen tüm manuel sayfaları listelendi. Buradaki eşleşmenin, ismin yanındaki kısa açıklama bilgisi sayesinde yakalandığını da buradaki çıktılara bakarak kolayca teyit edebiliyoruz. 

Netice buradaki örneklerimizde bizzat deneyimlediğimiz gibi manual sayfalarının isim bölümlerinde araştırma yapmak için man -k komutundan yararlanabiliyoruz. Yalnız burada dikkat etmeniz gereken detay, bütünleşik olarak birden fazla kelime içeren bir araştırma yapmak istiyorsanız bu kelimeleri tırnak işareti içine alarak yazmanızdır. Örneğin ben man -k “change file” komutunu girdiğim için doğrudan bu ifade ile eşleşenler konsola bastırıldı. Eğer tırnak içinde yazmasaydım hem “change” hem de “file” ifadelerinden tek biri veya her ikisi ile de eşleşen tüm sayfalar tek tek bastırılacaktı. Hemen deneyelim.

Bakın tırnak içinde yazmadığım için aralarında boşluk bulunan change ve file kelimeleri ayrı ayrı değerlendirildi ve bunlardan biri veya birden fazlasıyla eşleşen tüm sayfalar bastırıldı. Bu örnekte de görebildiğiniz gibi eğer girdiğiniz kelimeler ayrı ayrı araştırılsın istemiyorsanız mutlaka tırnak içinde yazmanız gerekiyor.

Hazır man -k komutundan bahsetmişken apropos komutunda da bahsetmemek olmaz. apropos komutu da man -k komutu ile birebir aynı işlevdedir. Yani dilerseniz man -k yerine doğrudan apropos komutu ile de aynı şekilde manual sayfalarının isim bölümlerinde araştırma yapabilirsiniz. Teyit etmek için bir önceki komutu bu kez apropos ile tekrar girmeyi deneyebiliriz.

Bakın birebir aynı çıktıyı aldık çünkü man -k ile apropos komutu aynı işlevi gören iki farklı komut. Hatta man —help komutu ile man aracının yardım bilgisini listeleyip kontrol edebiliriz. Bakın -k seçeneğinin uzun karşılığı olarak burada da apropos ifadesinin kullanıldığını görebiliyoruz. Apropos aracının ismi de buradan geliyor zaten. Ayrıca bakın daha önce ele aldığımız whatis aracı ile aynı işlevdeki seçeneğin -f olduğunu da buradan görebiliyoruz. Hatta bizzat test etmek için man -f passwd ve whatis passwd komutlarını girebiliriz. Bakın çıktılar birebir aynı oldu çünkü aynı görevi gören iki farklı komutu kullanmış olduk. 

Yani aslında man aracının pek çok seçeneği var ancak seçenekleri akılda tutmaktansa, seçeneklerle aynı işlevleri yerine getiren ve ismiyle işlevleri çağrıştıran basit araçları kullanmak çok daha hatırlanası ve kolay oluyor. Sizin için hangisi daha akılda kalıcı ise onu kullanmakta özgürsünüz.

Örnekler üzerinden pratik yaptık ancak belki şimdiye kadar verdiğim örnekler, manual sayfaları üzerinde isim bölümünü araştırabiliyor olmanın ne gibi kolaylıklar sağladığı konusunda yeterince açıklayıcı olmamış olabilir.

Komutun kullanım amacını daha iyi anlamak için; örneğin, bir komutun ismini tam olarak hatırlayamıyorsunuz ancak işlevini hatırlıyorsunuz diyelim. İşte bu noktada apropos ya da man -k komutu sayesinde man klavuz sayfaları içinde anahtar kelime araştırması yapılmasıyla yazdığınız kelime ile ilgili olan tüm komutlara kolayca ulaşabilirsiniz. Yani aslında amacımız tüm manual sayfasını okumak olmasa bile aradığımız işleve uygun aracın ismini kolayca bulmak veya hatırlamak için apropos ya da man -k komutlarını kullanabiliyoruz.

**Örneğin**

Bir komut vardı.. dizinleri listeleme işlevindeydi.. neydi.. neydi diye düşünüyorken; konsola `apropos "list directory”` şeklinde yazarsanız, karşınıza bu ifadenin isim bölümünde geçtiği ilgili manual sayfaları bastırılacaktır. Hemen deneyelim. Bakın çıktıda dizinler listelemeyi sağlayan çeşitli araçların kılavuz sayfaları listelendi. Benim aradığım araç ls aracıydı, bu çıktı sayesinde kolayca hatırlayabildim.

Benzeri şekilde aracın isminin yalnızca bir kısmını hatırladığınızı düşünüyorsanız da apropos yardımcı olabilir. Örneğin ben içinde tty ifadesi geçen bir komut vardı diye hatırlıyorsam, apropos tty şeklinde aratıp çıktıların sol tarafında aradığım komut var mı diye kontrol edebilirim.

Yani özetle, man sayfalarında yer alan açıklamalar sayesinde, tam olarak ismini hatırlayamadığınız araçların isimlerini ya da tam tersi şekilde ismini bilip işlevini hatırlayamadığınız durumlarda da işlevlerini apropos ya da man -k komutu yardımıyla kolaylıkla sorgulayabilirsiniz. Ayrıca apropos aracının sunduğu ek pek çok seçenek daha bulunuyor. Bunlar hakkında bilgi almak isterseniz apropos —help komutunu kullanabileceğinizi zaten biliyorsunuz. Ben buradaki seçeneklerden özellikle bahsetmeyeceğim ancak sizler merak ediyorsanız buradaki yardım sayfası veya manual sayfalarını kullanarak ve bizzat uygulayarak yani deneme yanılma ile istediğiniz tüm bilgilere ulaşabileceğinizi biliyorsunuz.

Sanırım, manuel sayfalarının ne kadar faydalı olabileceğine dair az çok fikir edinebildik. Şimdiye kadar özellikle değinmedik ancak, elbette manual sayfalarındaki bilgilerin faydalı olabilmesi için güncel olmaları da gerekiyor. O halde son olarak manuel sayfalarını nasıl güncelleyebileceğimizi de ele alalım. 

Eski bilgileri güncellemek veya aradığımızda ulaşamadığımız manuel bilgilerine ulaşabilmek için ara ara manuel sayfalarını güncellememiz gerekiyor. Çünkü sisteme kurulan veya kaldırılan araçlarla birlikte manual sayfalarının içeriklerinde değişimler olması kaçınılmaz. Zaten bu durumdan daha önce de kısaca bahsetmiştik hatırlıyorsanız. Dolayısıyla en güncel kılavuz içeriğine sahip olmak için ara ara güncelleme yapmamız gerekiyor. Güncelleme için konsola `mandb` komutunu girmemiz yeterli olacak, hemen komutumuzu girelim. Bakın görebildiğiniz gibi işlem son derece kısa sürdü ve güncelleme işleminden sonra yapılan değişiklikleri de son satırda bizlere bildirir. Eğer sisteminizde manual sayfalarının değişmesine sebep olabilecek herhangi bir değişim meydana gelmediyse doğal olarak burada herhangi bir güncelleme de yapılmıyor. Yine de eğer aradığınız manual sayfasını bulamıyorsanız ya da apropos veya man -k komutu ile araştırdığınız kelime ile eşleşme sağlanmıyorsa mandb komutu ile manual içeriklerini güncelleyip tekrar araştırmayı deneyebilirsiniz. İnsanlar çoğunlukla güncelleme yapmadığı için apropos aracının doğru şekilde çalışmadığı yanılgısına da düşebiliyorlar. Bu sebeple mümkünse uzun aradan sonra apropos ya da man -k komutunu kullanacaksanız öncelikle mandb komutu ile manual sayfalarını güncelleyin. Benim manual sayfaları hakkında söylemek istediklerim bu kadar. Bir sonraki bölümde bir diğer bilgi kaynağı olan info kaynaklarından bahsederek devam etmek istiyorum.

## info Komutu

man yani manual'e ek olarak 90'ların başında, GNU projesi "man" dokümantasyon sisteminin güncelliğini yitirdiğine karar verdi ve onun yerini alması için info aracı geliştirildi. Ancak ne yazık ki info, dönemine göre nispeten daha kolay okunur olsa da hiç bir zaman man kadar popüler olamadı. Yani man kılavuz sayfaları halen info ya oranla daha sık tercih ediliyor.

Ancak yine de yardım sayfalarının nasıl sunulacağı, geliştiricinin tercihine bırakıldığı için yalnızca man ya da yalnızca info veya her ikisi üzerinden de yardım bilgisi sunan araçlarla karşılaşmanız olasıdır. 

Genelde pek sık kullanılmadığı için ve man yeterli görüldüğü için bazı dağıtımlarda info aracı varsayılan olarak yüklü gelmiyor. Eğitimi hazırlarken kullandığım Ubuntu dağıtımında da info aracı varsayılan olarak kurulu değildi. Ancak elbette eğer istersek, paket yöneticisi yardımıyla info aracını kolayca kurabiliriz. Ben debian tabanlı bir dağıtım olan Ubuntu kullandığım için apt paket yöneticisi ile yani `sudo apt install info -y` komutu ile info aracını kolayca kurabilirim. Komutumu girip onaylıyorum. Aracım kısa sürede sorunsuzca kuruldu görebildiğiniz gibi. Eğer sizin kullanmakta olduğunuz sisteminizde info aracı varsayılan olarak yüklü ise zaten bu komutun ardından aracın yüklü olduğuna dair çıktıları da görebilirsiniz. Neticede info aracını sistemime kurdum.

Şimdi aracın kullanımından kısaca bahsetmemiz gerekirse, aslında info aracının kullanımı da tıpkı man gibidir. Yani info aracına sahip olduktan sonra `info` komutunun ardından bilgi edinmek istediğiniz aracın adını girmeniz yeterli. Ancak bu kullanımdan önce aslında info yaklaşımının nasıl çalıştığından biraz bahsedebilmek adına doğrudan info komutunu girmek istiyorum.

Bakın burada  info aracı ile okuyabileceğimiz, farklı kategorilere göre ayrılmış olan pek çok sayfa için liste bulunuyor. Listede aşağı inmek için yine klavyemizdeki yön tuşlarını rahatlıkla kullanabiliyoruz. Hatta eğer biraz dikkat edecek olursak, man sayfalarından farklı olarak info aracındayken yön tuşları ile imlecimizi çok daha esnek şekilde kontrol edebiliyoruz. Man aracında imleç olmadan yalnızca sayfa içeriğini görüntüleyebiliyorken, info aracında yazılı olan tüm içeriğinde üzerinde imleç yardımıyla kolayca gezinebiliyoruz. Bakın burada kategorilerine göre gruplanmış olan pek çok araç hakkında bağlantı bulunuyor. Örneğin diyelim ki ben chmod aracı hakkında bili almak istiyorum buradan chmod yazan başlığın üzerine gelip enter ile onaylamam yeterli. Bakın anında chmod aracı hakkında bilgi içeren sayfaya atlamış oldum. Hatta bakın üst başlıkta bir sonraki bilgi sayfasının “touch” aracıyla ilgili olduğu belirtilmişken bir öncekinin de chgrp aracı hakkında olduğu burada açıkça yazıyor. Eğer yön tuşunu kullanarak imlecimi yukarı doğru taşırsam bakın bir önceki konu olan chgrp açıklamasına geçiş yaptığımı alttaki çubuktan açıkça görebiliyorum. Benzer şekilde imlecimi kullanarak aşağıya doğru indiğimde de chmod açıklamasından sonra gelen touch açıklamasına geçiş yaptığımı alt çubuktan takip edebiliyorum.

Ayrıca burada gördüğümüz altı çizili olan bölümlerin hepsi, ilgili konunun açıklamasına yönlendirme yapan bağlantılardır. Yani örneğin buradaki altı çizili ifadenin üstüne gelip enter ile onaylarsam, görebildiğiniz gibi ilgili konuya doğrudan kolayca geçiş yapabiliyorum.

Zaten info aracı da man aracından farklı olarak bizzat burada deneyimlediğimiz imleç ile sayfalar arasında kolay geçiş imkanını tanımak amacıyla geliştirilmiş. Bu sayede bütüncül olarak bilgilere erişmek için tıpkı websiteleri gibi bağlantı adreslerinin ve yönlendirmelerin kullanılabilmesi mümkün olmuş. 

Ben burada doğrudan info yazıp tüm sayfaların içine daldım ancak elbette tüm hepsi içinden tek tek arayıp bulmamız da gerekmiyor. 

Örneğin tıpkı man komutunu kullanırken olduğu gibi chmod aracı için bilgi edinmek istersek info chmod komutunu kullanabiliriz. Bakın doğrudan chmod hakkında bilgi sayfası karışımıza gelmiş oldu. Yine de daha önce bahsettiğimiz şekilde önceki ve sonraki dokümanlara yön tuşlarını kullanarak kolayca geçiş yapabiliyoruz. 

Ayrıca aslında tek tek geçmek zorunda da değiliz tıpkı manuel sayfalarında olduğu gibi space tuşu ile hızlıca atlayabileceğimiz gibi, alt çubuktan da hangi başlık altında olduğunuzu ve sayfanın ne kadarını okuduğunuzu takip edebiliyoruz. info sayfasını kapatmak istediğimizde ise q tuşunu kullanmamız yeterli. info komutunun genel kullanımı işte bu şekildedir. Ayrıca dilerseniz info aracı hakkında daha fazla bilgi almak için info info komutunu kullanabilir ya da çok daha basit şekilde info aracı açıkken h tuşuna basabilirsiniz. Bakın burada info aracının kullanımına dair pek çok başlık altında pek çok bilgi sunuluyor. Buradan özelliklerini rahatlıkla okuyabilirsiniz. 

Ben info aracının yalnızca arama özelliğinden bahsetmek istiyorum. Mevcut sayfa içinde kelime araması yapmak istiyorsanız s tuşuna basıp, istediğiniz kelimeleri araştırabilirsiniz. Örneğim ben command ifadesini araştırmak için yazıyorum ve enter ile onaylıyorum. Bakın command ifadesinin geçtiği tüm bölümler aydınlatıldı. Yani arama özelliği sorunsuzca ve işlevsel şekilde çalışıyor. 

Info aracı hakkında bahsetmek istediklerim bu kadar. Ben yalnızca ek olarak arama özelliğinden bahsettim ancak sizler dilerseniz bu ve bunun gibi özellikler için özellik açıklamalarını okumanız yeterli. Örneğin info aracının da tıpkı man aracında kullandığımız gibi apropos veya -k seçeneği bulunuyor. Eğer yardım sayfasına göz atar ve uygulama yaparsanız nasıl çalıştığını kolayca kavrayabilirsiniz.

Benim kişisel tercihim, bana daha kolay ulaşılabilir geldiği için man yani manuel sayfalarını kullanmak. Ancak, elbette sizler dilediğiniz aracı kullanmakta özgürsünüz. Neticede artık yardım alabileceğiniz alternatifleri bildiğiniz için hangi durumda hangisini kullanmak istediğinize kendiniz de karar verebilirsiniz. help man ve info araçlarından da bahsettiğimize göre son olarak dokümantasyonlardan da bahsederek, yardım alma bölümünü yavaş yavaş sonlandırabiliriz.

## Dokümantasyonlar

İstisnalar hariç, uygulamalar ile birlikte ilgili aracın kullanımı hakkında bilgi, örnek ve değişim notları gibi detayları içeren dokümantasyonlar da sisteme ekleniyor. Bu dokümanların içeriğini sınırlayarak anlatmam mümkün değil çünkü ilgili aracın kullanım alanına göre pek çok türde dosya bulunabiliyor. Bu dokümanlar varsayılan olarak sistemde /usr/share/doc dizini altında tutuluyor. Hemen bu dizinde ne kadar çok araca ait doküman klasörü olduğunu görebilmek için geçiş yapıp dizinin içeriğini ls komutu ile listeleyelim. Bakın burada sistemde yüklü bulunan pek çok araca ait dokümanların klasörleri bulunuyor. 

Ben örnek olarak ileride ayrıca kullanımını ele alacağımız nano aracının dokümanlarına göz atmak istiyorum. cd nano komutu ile geçiş yapıp ls komutu ile listeleyelim. Bakın burada birtakım dosyalar ve klasörler bulunuyor. Elbette tüm araçların dokümantasyon içeriği buradaki ile birebir aynı olmayacaktır. Ancak bu dizinin içeriği bize az çok dokümantasyon dizininde hangi türden içeriğin olduğuna dair bir fikir verebilir bence. Örneğin bakın, aracın yazarları, değişim notları, telif hakkı, örnek klasörü, sıkça sorulanlar, geliştirmeler, yenilikler ve benzeri pek çok farklı türde bilgiyi sunan farklı türde dosyalar burada bulunuyor. Örneğin geliştiriciler hakkında bilgi almak için AUTHORS dosyasını cat komutu ile okuyabiliriz. Bakın geliştirici bilgileri konsola bastırdık. Dilersek benzeri şekilde examples klasörüne de geçiş yapıp içeriğine bakabiliriz. Bakın burada nano aracı için örnek bir konfigürasyon dosyası bulunuyormuş. Bu dosyanın içeriğini de cat aracı ile kolayca konsola bastırabiliriz. Bu dosya da nano aracında kullanılabilecek konfigürasyon tanımlamaların yer aldığı ve kısaca açıklandığı örnek bir dosyaymış görebildiğiniz gibi.

Ben yalnızca nano aracı üzerinden inceleme yaptım ancak farklı araçların dokümanlarına baktığımızda, pek çok türde dosyanın yer aldığını sizler de bizzat görebilirsiniz. Neticede bizzat teyit ettiğimiz üzere, sistemde yüklü bulunan araçların, dokümanları da bu konumda yer alıyor. Dolayısıyla sizler de gerektiğinde değişim notları, yenilikler, örnek dosyalar ve benzeri dokümantasyon kaynakları için bu dizini kontrol edebilirsiniz. Buradaki dokümanlar help ya da manuel sayfalarından çok daha farklı türde pek çok bilgi barındırıyor. Yani aslında buradaki dokümanlara muhtemelen çok sıklıkla ihtiyaç duymayabilirsiniz ancak yine de araçlarla birlikte sisteme eklenmiş olan dokümanlardan da haberdar olmamız kimi araçları kullanırken gerekli olabilir. Dokümantasyonların varlığından haberdar olmak bence önemli, bu sebeple kısaca bahsetmek istedim.

Ayrıca son olarak, yardım sayfaları için katı bir kural olmadığını da hatırlatmak istiyorum. Yardım sayfaları konusunda benimsenmiş tek bir yaklaşım olamadığı için birden fazla alternatif yönetimi bilmemiz gerekiyor. Ben de bu sebeple birden fazla yardım alma yönetimden bahsettim. 

Örneğin yerleşik komutlar hakkında bilgi almak için help komutunu kullanabileceğimden bahsetmiştik. Ancak eğer yerleşik komutların manuel sayfalarına bakmak istersek, kimi komutların manuel sayfalarının olmadığını görebiliriz. Hemen deneyelim, ben man cd yazarak, yerleşik olan cd komutu hakkında almak istiyorum. Gördüğünüz gibi cd komutu için manuel sayfası yok. Şimdi de bir diğer yerleşik komut olan pwd komutuna bakalım. Gördüğünüz gibi pwd komutu için manuel sayfaları mevcut. İşte bu örnekler üzerinden de teyit edebildiğimiz gibi, yardım sayfalarında katı bir zorunluluk olmadığından, komutlar hakkında bilgi edinmek için farklı yardım araçlarını kullanmamız gerekebiliyor. Ancak sorun değil, zaten tüm temel yardım araçlarını öğrendiğimiz için, gerektiğinde alternatif yardım araçlarını kullanabiliriz. Örneğin cd komutu için manuel sayfası yok, ama help cd komutu ile ya da cd —help komutu ile yardım bilgisine kolayca ulaşabiliyoruz.

### Genel Özet

Bu bölümü bitirmeden önce son bir kısa özet ve hatırlatmada bulunmam gerekirse: daha önce ele aldığımız —help seçeneği, genellikle ilgili aracın işlevine ve kullanımına dair özet bilgi sunarken, manual sayfaları araçlarlar ilgili çok daha fazla detay bulunuyor. Pek sık tercih edilmese de manual sayfalarına ek olarak tıpkı manual sayfaları gibi uzun açıklamalar bulunduran ve komut satırı üzerinden daha rahat dolaşım imkanı tanıyan info aracını da kullanabilirsiniz. Ancak tüm dağıtımlarda varsayılan olarak yüklü bulunmadığı için öncelikli tercihiniz manual sayfaları olabilir. Ayrıca tüm bunların yanında, eğer kullandığınız araç harici olarak dokümanlar sunuyorsa gerektiğinde /usr/share/doc/ dizini altındaki bu dokümanları da kullanabilirsiniz.

Özetle kapsamlı bilgi almak için manuel ya da info sayfalarını tercih ederken, komutun unuttuğumuz özelliklerini işlevlerini hatırlamak için genellikle —help seçeneğini kullanıyoruz. Ek dokümanlar ile de araca dair ek bilgiler edinebiliyoruz.

Evet neticede sistem üzerinde yer alan tüm temel yardım mekanizmalarından kısaca söz ettik. Artık yardım gerektiğinde kendi başınızın çaresine nasıl bakacağınızı biliyorsunuz. Elbette yardım alırken yalnızca sistem üzerindeki kaynaklarla sınırlı değilsiniz. Dilerseniz internet üzerinden de ekstra pek çok bilgiye ulaşabilirsiniz. Doğru şekilde araştırdığınız sürece blog yazıları, forum siteleri ve benzeri pek çok kaynaktan örneklerle açıklanmış pek çok bilgiye rahatlıkla ulaşabilirsiniz. Yine de sistem üzerindeki yardım mekanizmaları çoğu zaman ilk başvurduğumuz kaynaklar olacağından, burada anlatılan yardım alma yöntemlerini dikkate almanızı şiddetle tavsiye ederim. 

Bir sonraki bölümde dizinlerde gezintiden bahsediyor olacağız.

# Pekiştirme Testleri

1- Neredeyse tüm araçlarda kısa yardım bilgisini görüntülemek için komutumuzu nasıl girebiliriz ?

- help komut
- komut help
- komut —help D

2- `help komut` komutuyla hangi tür araçlar için bilgi alabiliyoruz ?

- tüm araçlar hakkında bilgi alabiliriz
- kabuğun tüm dahili komutları hakkında bilgi alabiliriz
- istisnalar hariç tüm araçlar hakkında bilgi alabiliriz.
- bazı istisnalar hariç kabuğun dahili komutları hakkında bilgi alabiliriz D

3- Sistem üzerindeki tüm araçların manual sayfaları vardır.

- Doğru
- Yanlış - Hayır tüm araçların manual sayfaları olmak zorunda değil. Yine de manual sayfaları yaygın kullanıma sahip olduğu için pek çok aracın manual sayfasıyla karşılaşırsınız.

4- apropos ve man -k komutlarının işlevleri nedir ?

- Tüm manual sayfaları içeriklerinde filtreleme yapmak.
- Manual sayfalarının NAME bölümünde yer alan verilere bakarak filtreleme yapmak. D
- Manual sayfalarını güncellemek.
- Argüman olarak verilen manual sayfalarını açmak.

5- Manual sayfalarında mevcut satırdan sonraki eşleşmeleri araştırmak için hangi kısayolu kullanmamız gerekiyor ?

- ?aranacak-kelime
- .aranacak-kelime
- !aranacak-kelime
- /aranacak-kelime D

6- Manual sayfalarında mevcut satırdan önceki eşleşmeleri araştırmak için hangi kısayolu kullanmamız gerekiyor ?

- ?aranacak-kelime D
- .aranacak-kelime
- !aranacak-kelime
- /aranacak-kelime

7- Manual sayfasında araştırma sonrası bulunan eşleşmelere hızlıca geçiş yapmak için hangi kısayol tuşlarını kullanabiliyoruz ?

- m ve shift + n
- m ve shift + m
- n ve shift + n Büyük küçük n karakteri olarak da düşünebilirsiniz. Doğrudan n tuşuna bastığımızda önceki eşleşmelere atlayabiliyorken, büyük n karakteri oluşturmak üzere shift + n tuşlaması yaptığımızda sonraki eşleşmelere hızlıca atlayabiliyoruz.
- j ve shift + j

8- man aracından çıkmak için ne yapmak gerekir ?

- e tuşuna basmak
- ctrl + e tuşuna basmak
- ctrl + q tuşuna basmak
- q tuşuna basmak D

9- Tüm araçların yardım sayfaları ve dokümanları mevcut mudur ?

- Hayır - Tabii ki yardım sayfaları sunmakla ilgili kesin katı bir zorunluluk olmadığı için tüm araçların yardım bilgisi olacak diye bir kaide yoktur. Ayrıca tüm araçlar /usr/share/doc dizini altında doküman da sunmayabilir.
- Evet

10- manual sayfalarını güncellemek için hangi komutu girmemiz gerekiyor ?

- updatedb
- update man
- manupdate
- mandb d