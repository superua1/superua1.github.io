# promt Açıklamsı

Daha detaylı ve tutarlı bir şekilde ele al.

Konsolda gördüğümüz bu promter bölümü öylesine mevcut değil. Aslında bize pek çok bilgiyi bir arada sunuyor. Örneğin ben kendi promter ımı alacak olursam;

ilk olarak konsolda oturum açmış olan kullanıcı adı yazıyor.

at @ işaretinden sonra ise hostname yani mevcut bilgisayarın ağ üzerindeki ismi yazıyor.

iki nokta üst üste işaretinden sonra ise şu anda konsol üzerinde hangi dizinde çalışmakta olduğum belirtiliyor.

son olarak buradaki $ dolar işareti ise benim normal kullanıcı olduğumu belirten bir işaret. Eğer root kullanıcısı olsaydım buradaki işaret # şeklinde olacaktı.

Gördüğünüz gibi basit gibi görünün şu kadarcık promt ile aslında ne kadar da çok bilgi sunuluyor. Bu promt önemli çünkü sistemimizi konsol üzerinden komut satırı ile yönetiyorken referans olarak bilmemiz gereken tüm bilgileri sunuyor. Örneğin her defasında pwd komutunu kullanmama gerek kalmadan o anda hangi dizinde olduğumu buradan öğrenebiliyorum. Ya da şu anda hangi kullanıcı hesabı ile oturum açmış olup komut girdiğimi de buradan görebiliyorum. Kısacası promt aslında ilk başta göründüğünden çok daha önemli.

Elbette tüm konsollarda promter görünümü bende olduğu gibi klasik görünümde olmayabilir. Bu farklılığın sebebi bu promter bölümünün istenildiği şekilde özelleştirilebilecek olmasıdır. Özelleştirmek için tek yapmamız gereken mevcut kabuğun konfigürasyon dosyasını açıp istediğimiz şekilde düzenlemektir. Ben mevcut kullanıcı hesabımın konfigürasyonlarına göz atmak için ev dizinindeki .bashrc dosyasına göz atmak istiyorum.

Konfigürasyon dosyasında hangi özelliğin hangi satırlarda tanımlandığı yorum satırları ile kolayca anlaşılabiliyor. Örneğin bakın promt için gereken konfigürasyonlar burada yer alıyor. Göz atacak olursak; ilk olarak renkli bir promt için gereken şartların uygun olup olmadığı kontrol ediliyor eğer uygunsa da buradaki promt tanımamasının geçerli olması sağlanıyor.

Belki buradaki tanımlama sizin için çok anlamlı gelmemiş olabilir. Ancak görünenin aksine son derece basit bir tanımlama. Üstelik ezbere bilmeniz falan gerekmiyor. İnternet üzerinde nasıl düzenleyebileceğinize dair tonla kaynak bulunuyor. Biraz aşratırısanız diğer insanların düzenleyip kendi temalarını paylaştıkları konfigurasyonları da kolaylıkla bulabilirsiniz. Hatta en kolay yolu, kullandığınız kabuğa göre online şekilde özelleştirme araçlarını kullanabileceğiniz alternatifler. Örneğin bash kabuğunun promtunu düzenlemek için bash promt editor şeklinde aratmamız yeterli. Bakın pek çok farklı servis karşımıza çıktı. Dilediğiniz bir siteyi ziyaret edebilirsiniz. Buradan istediğiniz gibi düzenleme yapıp prompt satırını kendiniz için en kullanışlı hale getirebilirsiniz.

Ayrıca bash için bash-it veya zsh için oh-my-zsh gibi eklentileri kurarak mevcut kabuğunuzda özelleştirmeler yapabilirsiniz. Ancak özelleştirme yaparken, tüm sistemlerde bu eklentiler kurulu olmayacağı için ve bu eklentiler sizi bazı komutların yazımı konusunda tembelliğe itebileceği için harici makineleri yönetmeniz gerektiğinde sizi duraklatabilecek alışkanlıklar edinmemeye yani eklentilere çok bağlanmamaya çalışın.

Evet bireysel kullanımda eklentiler büyük konfor sağlayabiliyor ancak profesyonel kullanımda her an kullanıılabilir olmayacağı için sizi köreltmelerine de müsade etmeyin.