# 9- Dosya İşlemleri PART 2

lsof kullanımına güzel bir örnek : [https://www.kurtulusoz.com.tr/linux/linux-en-cok-islem-yapilan-dosyalari-belirleme/](https://www.kurtulusoz.com.tr/linux/linux-en-cok-islem-yapilan-dosyalari-belirleme/)

# paste Komutu

Şu ana kadar birden fazla dosya içeriğini aynı anda okurken, dosya içeriklerinin hep alt alta bastırıldığını gördük. Yani örneğin cat komutu ile daha önceden oluşturduğum “harf” “rakam” ve “sehir” isimli dosyaları okumak üzere tek seferde komut girersem, bakın girdiğim sıralamaya uygun şekilde bu dosyaların içerikleri alt alta bastırıldı.

Eğer dosya içeriklerini satır satır yan yana olacak şekilde konsolumuza bastırmak istersek paste komutunu kullanabiliriz. Ben örnek olması için daha önce oluşturduğum harf rakam ve sehir dosyalarını yan yana bastırmak üzere paste rakam harf sehir şeklinde komutumu giriyorum. Bakın tam olarak girdiğim komut sırasına uygun şekilde dosya içerikleri aralarında boşluklarla ayrılmış şekilde yan yana bastırılmış oldu.

Burada dosya içeriklerinin kolay ayırt edilebilmesi için boşluklar yer alıyor. Fakat dilersek, bastırılan sütunlar arasında boşluk yerine özel bir işaret yani özel bir sınırlayıcı karakter de ekleyebiliriz. Örneğin ben her bir sütun arasına kısa dikey çizgi eklemek istiyorum. Paste aracına sütunları nasıl ayıracağını belirtmek için de ingilizce “delimiter” yani “sınırlayıcı” ifadesinin kısalmasından gelen -d seçeneğini kullanabiliyoruz.

Ben dikey çizgiyi dosya içerikleri arasındaki sınırlayıcı olarak belirtmek için -d seçeneğinin ardından sınırlayıcı karakteri yani dikey çizgiyi tırnak içinde yazıyorum. Ve yan yana bastırmak istediğim dosyaların adını tekrar peşi sıra giriyorum. 

```bash
paste -d "|" rakam harf sehir
```

Bakın, tüm sütunların arasında dikey çizgi yer alıyor, çünkü ben sınırlayıcı karakter olarak buradaki dik çizgi karakterini tanımlamıştım. Elbette sizler dilediğiniz bir karakteri sınırlayıcı olarak kullanabilirsiniz. Hatta birden fazla sınırlayıcı karakter de belirtebilirsiniz. Örneğin dikey çizgi ve kısa çizgi karakterlerini sınırlayıcı olarak kullanırsak, sırasıyla iki sınırlayıcı da dosya içeriklerini sınırlamak için kullanılıyor olacak. Bu durumu daha net gözlemeyebilmek adına daha fazla dosyayı yan yana bastırsak daha iyi olur. Ben aynı dosyaları tekrar tekrar yan yana bastırmak istiyorum. Yani komutumu:

```bash
paste -d "|-" rakam harf sehir rakam harf sehir
```

Şeklinde giriyorum.

Gördüğünüz gibi sırasıyla hem dikey çizgi hem de kısa çizgi karakterleri sütunlar arasındaki sınırlayıcı olarak kullanıldılar. İşte sizler de bu şekilde istediğiniz sınırlayıcı karakterlerini belirtebilirsiniz. Birden fazla sınırlayıcı belirttiğimizde de tıpkı burada aldığımız çıktıda da olduğu gibi bu karakterler sırasıyla soldan sağa doğru tekrar eden bir örüntü gibi kullanılıyor olacak.

Ayrıca sınırlama işareti dışında eğer her bir satırı yan yana değil de alt alta eşleşecek şekilde sıralamak istersek -s seçeneğini de kullanabiliyoruz. 

Kıyaslayabilmek için öncelikle s seçeneği olmadan dosyaları bastıralım. Bakın dosyalarda yer alan tüm satırlar yan yana bastırıldı. Şimdi de -s seçeneğini kullanarak komutumuzu girelim.

Görebildiğiniz gibi normalde satırlar yan yana basılırken şimdi iki dosyanın satırları alt alta olacak şekilde basılmış oldu. Sizler ihtiyacınıza göre istediğiniz sayıda dosyanın satırlarını birebir yan yana ya da alt alta paste komutu ile görüntüleyebilirsiniz. Eğer birden fazla dosya içeriğinin yan yana birleştirilmiş hali lazımsa yönlendirme işareti ekleyip çıktıları yeni bir dosya olarak kaydedebilirsiniz. Zaten artık hatırlatmama gerek yok. Sizler yönlendirmeler ile ilgili bilmeniz gereken tüm temel altyapıya sahipsiniz. İhtiyaçlarınıza göre sistem üzerinde tüm araçlarda kullanabilirsiniz. Özellikle veri bilimi gibi alanlarda çalışırken, bu şekilde birden fazla kaynaktan alınan verilerin istenildiği şekilde derlenebilmesi çok kullanışlı olabiliyor. Tüm mesele elimizdeki verileri ihtiyaçlarımıza göre düzenleyip kullanabilmek.

# wc komutu

wc komutu en temel haliyle kelimeleri saymamızı sağlayan işlevsel bir komuttur. wc komutunun ismi word count yani kelime sayma ifadesinin kısaltmasından geliyor. Biz kelime dedik ama yalnızca kelimeleri değil, karakterleri, satırları ve ayrıca baytları saymak için de kullanılabiliyor. Eğer komutu ek bir seçenek olmadan kullanırsak, sırasıyla kaç yeni satır, kelime ve bayt olduğunu ve okunan dosyanın ismini bastırıyor. Hemen deneyelim. Ben denemek şehirleri ve plakaları içeren dosyam üzerinde kullanıyorum.

Buradaki ilk sayı dosya içeriğinin kaç satır olduğunu, ortadaki sayı toplam kaç kelime olduğunu ve son sayı ise toplam kaç bayt olduğunu bildiriyor. 

İstersek bu çıktıların hepsini almak yerine yalnızca ihtiyacımız olan çıktıları da bastırabiliriz. Örneğin ben yalnızca satırların basılmasını istersem ingilizce lines yani satırlar ifadesinin kısaltması olan -l seçeneğini kullanabilirim. Bakın bu kez yalnızca kaç satır olduğunu öğrendik. Bu arada dosya içeriğinde boş satırlar olduğunda bu satırların da sayıldığını unutmayın lütfen.

Satır sayısı yerine kelime sayısını öğrenmek için de yine ingilizce karşılığı word yani kelime olan -w seçeneğini kullanabiliyoruz. Ben teyit etmek için bu kez de yalnızca w seçeneği ile dosyamı okuyorum. Bakın bu sefer de yalnızca kelime sayısı bastırıldı.

Yalnızca bayt sayısını öğrenmek istersek, c seçeneğini kullanabiliriz. Ben yine aynı dosyamı bu kez de c seçeneği ile belirtiyorum. Bakın yalnızca bayt sayısı bastırıldı. c seçeneği belki aklınızda kalmayabilir. Hatırlamazsanız zaten dilediğiniz zaman yardım sayfasına göz atabilirsiniz. 

Ayrıca tüm seçenekleri tek tek kullanabileceğimiz gibi elbette aynı anda da kullanabiliriz. Ancak dikkat etmeniz gereken detay, alacağınız çıktıların komutun en başında bahsettiğimiz standart sıralamasında olacağıdır. Yani seçenekleri hangi sıralamada vermiş olursak olalım, aldığımız çıktılar, soldan sağa doğru; yeni satır, kelime, karakter, byte ve dosya adı şeklinde olacak. Denemek için ben wc -wl dosya adı şeklinde yani kelimelerin ve satırların hesaplanacağı şekilde komutumu giriyorum. Şimdi birde seçeneklerin sıralamasını değiştirip tekrar girmeyi deneyelim.

Bakın iki çıktıdaki sayıların sıralaması da aynı. Yani bizim verdiğimiz seçenek sıralamasının wc komutu için bir önemi yok. Her koşulda, çıktılar kendi standartlarında oluyor. Karakter sayısı da dahil bastırmak için tüm seçenekleri kullanabiliriz. Bakın aldığımız bu çıktıdaki sıralama da yeni satır, kelime, karakter, byte ve dosya adı şeklinde oldu. Bu çıktı sıralamasını aklınızda tutamıyorsanız sorun yok. Çünkü man wc komutunu kullanıp, komut açıklamasındaki sıralama tanımına bakabilirsiniz. Bakın burada sıralamadan bahsediliyor. Böylelikle unuttuğunuz zaman 10 saniyede sıralamayı tekrar hatırlayabilirsiniz. İyi ki yardım sayfaları var, haksız mıyım ?

Ayrıca birden fazla dosya ismi belirtirsek ayrı ayrı bu dosyalardaki istatistikler ve toplamları bize sunuluyor. Hemen denemek için birkaç dosya daha ekleyerek komutumuzu girelim. Bakın tek tek tüm dosyaların istatistikleriyle birlikte son satırda toplam sayılar da bize sunuluyor. Bu şekilde ister tek isterseniz de birden fazla dosyanın istatistiklerini kontrol edebilirsiniz. 

# uniq Komutu

uniq komutu bir dosyadaki peş peşe tekrarlanan satırları bulup, birden fazla olanı silmemizi sağlayan bir araçtır. Ancak uniq yalnızca aynı satırlar peş peşe olduğunda çalışıyor. Tekrar eden satırlar arasında boşluk varsa bu tekrarlar silinmiyor. Denemek için ben içerisinde isimlerin bulunacağı örnek bir metin hazırlamak istiyorum.  Dosyamın içine çeşitli isimleri belirli aralıklarla giriyorum.

```bash
cat > isimler
ahmet
mehmet
mehmet
hasan
ayse
fatma
hasan
hasan
hasan
ahmet
mehmet
ayse
ayse
fatma
```

Evet neticede peş peşe ya da farklı satırlarda aynı isimlerin geçtiği bir liste hazırladık. Eğer uniq komutunu kullanırsak yalnızca peş peşe tekrar eden satırlar filtrelenip bu satırlar tek bir kez bastırılacak.

```bash
uniq isimler 
ahmet
mehmet
hasan
ayse
fatma
hasan
ahmet
mehmet
ayse
fatma
```

Evet dosya içeriği filtrelenmiş oldu. Bakın, birbirini farklı satırlarda tekrar eden kelimeler olmasına karşın, uniq yalnızca peş peşe olan ve birbiri ile aynı olan satıları sildi. Zaten görevinin bu olduğunu da söylemiştik. Eğer istediğiniz tam olarak buysa evet uniq komutu bu bağlamda faydalı olabilir. Ama eğer ben tüm tekrar eden satırların silinmesini istiyorsanız daha önce de ele aldığımız şekilde sort komutunun u parametresini kullanabilirsiniz. Bu komut öncelikle tüm tekrar eden satırları peş peşe sıralayacak daha sonra u yani uniq seçeneği ile tekrar eden satırlardan yalnızca birer tanesini bastıracak. Bakın sort -u isim şeklinde kullandığımda yalnızca benzersiz olan satırlar bastırıldı. 

```bash
sort -u isimler
ahmet
ayse
fatma
hasan
mehmet
```

Tıpkı bu örnekteki gibi uniq komutunun işlevinin farkında olarak doğru yerde doğru komutu kullanmamız gerekiyor. uniq komutunun asıl görevi peş peşe tekrar eden satırların filtrelenmesi. Farklı satırlarda olan tekrarlar ile ilgilenmiyor.

uniq komutu ile devam edecek olursak, peş peşe tekrar eden satırlar dışındaki tüm satırları bastırmak istersek -u seçeneğini kullanabiliyoruz. Daha net görebilmek adına öncelikle dosyanın değişmemiş halini cat komutu ile okuyalım. Şimdi uniq -u dosya ismi şeklinde komutumuzu girelim.

```bash
uniq -u isimler 
ahmet
hasan
ayse
fatma
ahmet
mehmet
fatma
```

Bakın peş peşe tekrar etmeyen tüm satırlar bastırıldı. Mehmet, hasan ve ayse isimlerinin peş peşe tekrar ettiği kısımlar basılmadı. Bunlar hariç geriye kalan satırlar basıldı. Aynı ifade farklı satırlarda olduğu için bakın onlar sorunsuzca basılmış. Buradaki asıl amaç peş peşe tekrar eden satırları kaldırmak. Nitekim önceki listeye baktığımızda yalnızca üst üste tekrar eden satırların kaldırıldığını da görebiliyoruz. 

Tersi şekilde yalnızca peş peşe tekrar eden satırları da bastırabiliriz. Bu üst üste tekrar eden satırları bastırmak için duplicate  yani tekrarlamak ifadesinin kısaltmasından gelen -d seçeneğini kullanıyoruz. Ben öncelikle sonuçları rahat kıyaslayabilmek için tekrar cat komutu ile değişmemiş içeriği bastırıyorum. Şimdi de -d seçeneği ile dosya içeriğini filtreleyelim.

```bash
uniq -d isimler 
mehmet
hasan
ayse
```

Bakın, gördüğünüz gibi şimdi de yalnızca üst üste tekrar eden mehmet, hasan ve ayse ifadeleri bastırıldı. Çünkü yalnızca bu ifadeler üst üste tekrar ediyordu. Hatta doğrudan tekrar eden ifadelerin hepsini de bastırabiliriz. Bunun için büyük -D seçeneğini kullanıyoruz. Hemen deneyelim. Bakın bu kez yalnızca tekrar eden satırların birer örneği değil doğrudan tüm tekrar eden satırlar tekrar tekrar konsol bastırıldı. Zaten iki komutu kıyaslayıp aralarındaki farkı rahatlıkla görebiliyoruz.

```bash
uniq -D isimler 
mehmet
mehmet
hasan
hasan
hasan
ayse
ayse
```

Ayrıca tüm bunlar dışında eğer istersek satırların peş peşe kaç kez tekrar ettiğini de öğrenebiliriz. Bunun için count yani saymak ifadesinin kısaltmasından gelen -c seçeneğini kullanabiliyoruz. Ben tekrar temiz listeyi bastırıyorum.

Şimdi bir de -c seçeneği ile satıların tekrar eden satıların sayılmasını sağlayalım.

```bash
uniq -c isimler 
      1 ahmet
      2 mehmet
      1 hasan
      1 ayse
      1 fatma
      3 hasan
      1 ahmet
      1 mehmet
      2 ayse
      1 fatma
```

Evet sayılar ile birlikte çıktımızı aldık. Buradaki sayılar bu satırın üst üste kaç kez tekrar ettiğini belirtiyor. Bakın üst üste tekrar edenler hariç tüm satırlarda bu sayı 1 olarak basılmış. Çünkü bu kullanım yalnızca üst üste tekrar eden satırların sayımı için. Benzer şekilde önceki kullandığımız seçenekler üzerinde de kullanabiliriz. Örneğin ben yalnızca üst üste tekrar eden satıların tekrar sayısını öğrenmek istersem komutumu `uniq -dc dosya_adı` şeklinde girebilirim. Bakın yalnızca üs üste tekrar eden satırlar ve onların yanında da tekrar sayıları bastırıldı. 

```bash
uniq -dc isimler 
      2 mehmet
      3 hasan
      2 ayse
```

Şimdiye kadar hep içinde yalnızca küçük harfler bulunan listeyle çalıştık. Ama elbette içerisinde küçük büyük harfler bulunan içerikleri de uniq komutu ile filtrelememiz gerekebilir. Normalde eğer biz özellikle belirtmezsek ifadeler birebir aynı da olsa küçük büyük harf farklılıkları olduğunda bu ifadeler tekrar ediyor sayılmıyor. Çünkü küçük büyük harf duyarlılığı varsayılan olarak aktiftir. Bu durumu gözlemleyebilmek için öncelikle dosyamızın içeriğine büyük harfleri yani satırlar ekleyelim. Ben isim dosyasının sonunda cat >> isim komutu ile başlangıç harfi büyük Fatma tamamı büyük FATMA ve HASAN ifadelerini ekliyorum. Tamamdır. Şimdi listemizin son haline bi bakalım. Bakın listenin sonunda küçük büyük harfleri farklı olan üç tane fatma satırı bulunuyor. Şimdi uniq komutunun bu içeriği nasıl ele alacağına bakabiliriz. 

Ben öncelikle bu listenin nasıl ele alınacağını görmek için seçenek belirtmeden uniq komutunu kullanıyorum. Bakın küçük büyük harfler farklı olduğu için peş peşe de olsa fatma ifadeleri tek bir satırda basılmadı. Normalde uniq komutu peş peşe tekrar eden satırlardan yalnızca bir tanesini bastırıyor. Ama bunların küçük büyük harfleri farklı olduğu için bunlar aynı sayılmadı. Bu durumda eğer küçük büyük harf duyarlılığını kaldırmak istersek -i seçeneğini kullanabiliriz. Bu i seçeneği ignore-case yani görmezden gelme ifadesinin kısaltmasıdır. Hadi şimdi -i seçeneğiyle tekrar deneyelim. Bakın bu kez küçük büyük harfleri farklı da olsa peş peşe olan satırlar tek bir satırda bastırıldı. Sizler de gerektiğinde i seçeneği ile küçük büyük harflerin görmezden gelinmesini sağlayabilirsiniz.

uniq komutu için bu kadar bilgi şimdilik yeterli. Eğer daha fazla özelliğine göz atmak isterseniz, yardım sayfasından kısaca bilgi edinebilirsiniz. Zaten komutun temel çalışma yapısını bildiğiniz için bahsetmediğimiz diğer özellikleri de yardım sayfasından edindiğiniz bilgilerle uygulamalı şekilde test edebilirsiniz. 

# diff Komutu

diff aracı iki dosyayı satır satır kıyaslayıp varsa aralarındaki farklardan haberdar olabilmemizi sağlayan işlevsel bir araçtır. Aracın ismi İngilizce "differences" yani "farklılıklar" ifadesinin kısaltmasından geliyor.

Herhangi bir seçenek belirtmeden kullandığımızda diff komutu iki dosyanın içeriğini kıyaslayıp varsa farklı olan satırların hangisi olduğunu konsola bastırıyor. Eğer iki dosyanın satırlarında farklılık yoksa hiç bir çıktı üretilmez. Her zamandaki gibi aracın işlevini en iyi uygulama yaparak görebiliriz. Ben iki dosya arasında kıyaslama yapmak üzere yine içerisinde isimler geçen dosyaları kullanacağım. Zaten bunları dersten önce oluşturmuştum. Bakın paste komutu ile yan yana bastırdığımda iki isim dosyasındaki hangi isimlerin yer aldığını ve kabaca iki dosyanın da içeriğinde farklılıkla olduğunu görebiliyoruz. Kimi isimlerin yeri farklı kimisi satır satıra aynı ve ayrıca bakın bu dosyada fazladan isim satırları da var. Sizler de benzeri iki liste oluşturabilirsiniz. 

```bash
paste isimler1 isimler2
ahmet	    ahmet
mehmet	  mehtap
hasan	    hasan
ayse	    ayse
fatma	    sude
sude	    ali
ali	      fatma
mert	    mert
can	      can
mert can	canan
					kemal
					cemre
```

Şimdi ben yeni bir terminal penceresi açıyorum ve isimler1 dosyasını isimler2 dosyası ile kıyaslamak üzere diff isimler1 isimler2 şeklinde komutumu giriyorum. Burada dikkat etmeniz gereken detay, dosya sıralamasının çok önemli olduğudur. Bu kullanımda, ben birinci dosyanın içeriğinin ikinci dosya ile aynı olması için ne değişiklikler yapmam gerektiğini sorguluyorum. Yani benim örneğimde isimler1 dosyasının tıpkı isimler2 dosyası gibi olması için hangi değişiklikleri yapmam gerektiğini öğreniyor olacağım. 

Bakın farklılıklara dair birtakım çıktılar konsola bastırıldı. Şimdi bu çıktıdaki ifadelerin anlamlarını öğrenip, çıktının aslında bize ne söylediğini açıklamaya çalışalım.

İl sayılar, ilk dosyadaki satır sayısını veya satır aralığını belirtiyor.

Buradaki karakterler dosyaların eşitlenmesi için değişimin nasıl olması gerektiğini belirten özel karakterler. Eğer a karakteri varsa add yani satırın eklenmesi gerektiğini beliriyorken. c karakteri varsa change yani satırın değiştirilmesi gerektiği belirtiliyor. Eğer d karakteri varsa da delete yani ilgili satırın silinmesi gerektiği belirtiliyor.

Özel karakterden sonraki sayılar da ikinci dosyadaki satır sayısını veya satır aralığını belirtiyor.

Küçüktür işareti birinci dosyadaki satırı belirtiyor. 

Büyüktür işareti ise ikinci dosyadaki satır olduğunu belirtiyor.

Bu işaretlerin hemen peşi sıra yazılanlar da zaten bu satırın içeriğidir.

Çıktıları incelediğimizde bu ifadeleri daha net kavrayacaksınız. Görebildiğiniz gibi yapılması gereken düzenleme bilgisinin ardından hangi satırın düzenlenmesi gerektiği belirtiyor. Ben buradaki çıktıları takip ederek ilk dosyanın içeriğini düzenleyeceğim. Bu sayede ilk dosyam da ikinci dosya ile aynı içeriğe sahip olacak. Bunun için de yeni bir terminal ekranı açıyorum. nano isimler1 komutu ile dosyanın içeriğini düzenlemek üzere metin editörünü açıyorum. diff komutunun çıktılarından aldığımız bilgi ile anlık olarak isimler1 dosyasının içeriğini isimler2 dosyası ile aynı hale getireceğiz. Hatta satırları daha rahat takip edebilmek adına nano aracındayken alt n tuşlaması yapıp, satır bilgisini de açalım. Bakın artık satır numaraları da gözüküyor, dolayısıyla düzenlemeleri daha kolay şekilde takip edebiliyor olacağız. Şimdi diff komutunun çıktılarındaki rehberi takip edebiliriz.

Buradaki çıktı 2c2 şeklinde. Yani ilk dosyadaki ikinci satırın, 2 dosyadaki ikinci satır ile değişmesi gerektiği belirtilmiş. İlk rakam, birinci dosyadaki satır sayısını belirtiyor. Ortadaki karakter change yani değişim ifadesinin kısalması, yani değişim yapılması gerektiğini belirtiyor. İkinci rakam da ikinci dosya üzerindeki hangi satır ile değişim yapılacağını belirtiyor. Zaten ayrıca bakın küçüktür karakteri ile birinci dosyadaki hangi kelimenin değişmesi gerektiği belirtilmiş ve bu kelimenin ikinci dosyadaki hangi kelime ile değiştirileceği de büyüktür karakteri ile belirtilmiş. Yani bu örneğimizde birinci dosyanın ikinci satırında yer alan mehmet ifadesi yerine, ikinci dosyadaki ikinci satırda yer alan “mehtap” ifadesinin gelmesi gerektiği açıkça belirtiliyor. Hemen bu değişikliği uygulayalım.

Nano editöründeki dosyamın ikinci satırına geliyorum ve mehmet ifadesini mehtap ile değiştiriyorum. 

İkinci bilgi, ilk dosyanın 5. satırındaki fatma satırının silinmesi gerektiğini bu sayede ikinci dosyadaki 4. satıra birebir eşleneceğini belirtiyor. Nano editörüne gelip, 5. satıra iniyorum ve fatma ifadesini siliyorum. Bakın bu gerçekten de ilk dosyasının 4. satırı ile ikinci dosyanın 4. satırı birebir aynı. 

Üçüncü bilgi, ilk dosyanın yedinci satırına gelip, buraya ikinci dosyanın 7. satırındaki fatma ifadesini eklemem gerektiğini belirtiyor. İlk dosyada 7. satıra geliyorum ve fatma ifadesini buraya ekliyorum.

Bir sonraki bilgi de ilk dosyanın 10. satırını ikinci dosyanın 10 ila 12. satırları ile değiştirmem gerektiğini belirtiyor. Ben ilk dosyada 10. satıra yani mert can yazan satıra geliyorum. Buradaki ifadeyi silip sırasıyla ikinci dosyadaki canan kemal ve cemre ifadelerini satır satır dosyama ekliyorum. Tamamdır. Artık birinci dosyanın ikinci dosyadan hiç bir farkı kalmadı. Ben nano editöründeki dosyayı ctrl x ile kapatıyorum. Kapatılırken bana değişiklikleri kaydetmek istiyor muyum diye soruyor. y tuşuna basıyorum. Şimdi de hangi isimde kaydetmek istediğimi soruyor. ben isimler3 şeklinde yazıyorum enter ile onaylayıp y tuşuna basarak kaydediyorum. Şimdi diff komutunun çıktılarına bakarak düzenlediğimiz isimler1 dosyasının düzenlenmiş hali olan isimler3 dosyasını, referans dosyamız yani isimler2 dosyası ile paste komutu yardımıyla yan yana bastıralım. Bakın yana yana baktığımızda, diff komutunun çıktılarını kullanarak gerçekleştirdiğimiz değişikliklerin doğru olduğunu görebiliyoruz. İki dosya içeriği de artık birebir aynı. İşte sizler de bu şekilde iki dosyayı kıyaslayabilirsiniz. diff komutunu kullanırken dikkat etmeniz gereken, ilk dosyanın ikinci dosyaya benzemesi için gerekenlerin bastırıldığıdır. Bizzat teyit etmek için bu kez komutumuzu diff isimler2 isimler1 şeklinde girebiliriz. Bakın bu kez de isimler2 dosyasının isimler1 dosyası ile aynı olması için gereken değişiklikler bastırıldı.

Ben çıktıların kolay anlaşılabilmesi için tüm düzenlemeleri metin editörü üzerinde kendim tek tek yaptım. Ancak elbette bunun da kolay bir yolu var. Eğer iki dosyanın birebir aynı olmasını istiyorsak ed komutundan faydalanabiliriz. Ancak bundan önce diff komutunu kullanarak klasör içeriklerini de kıyaslayabileceğimizi belirtmek istiyorum. diff komutunun ardından içeriklerini kıyaslamak istediğimiz iki dosyayı yapıp, hangi klasörde hangi içeriklerin farklı olduğunu öğrenebiliriz.

Ben örnek olması için kendi ev dizinimin root kullanıcısının ev dizini ile birebir aynı olması için ne yapmam gerektiğini öğrenmek istiyorum. Elbette root kullanıcısının dosyaları ile kıyaslama yapacağımız için komutunun en başında sudo ifadesi ile işlemi yetkili şekilde gerçekleştirmemiz gerekiyor. sudo diff ~ ~root şeklinde komutumu girip, parolamı da yazıp işlemi tamamlıyorum.

```
sudo diff ~ ~root
```

Bakın yalnızca benim ev dizinimde olan dosya ve klasörler olduğunu çıktılarda görmemle birlikte, root kullanıcısında da olan ama benimdekinden farklı içeriğe sahip dosyaların olduğunu da görebiliyorum. Üstelik bendeki aynı dosyaların root kullanıcısınınki ile aynı olması için yapmam gereken değişiklikler de açıkça burada belirtiliyor.

```
Only in dir1: tab2.gif
Only in dir1: tab3.gif
Only in dir1: tab4.gif
Only in dir1: tape.htm
Only in dir1: tbernoul.htm
Only in dir1: tconner.htm
Only in dir1: tempbus.psd
```

İşte bizzat buradaki çıktılardan gördüğümüz gibi, ilk dizinin altındaki tüm içeriğin ikinci dizin altındakiler ile aynı olması için gereken tüm bilgiyi yine diff komutu yardımıyla öğrenebiliyoruz.

Tabii ki daha önce de söylediğim gibi aslında diff komutunun çıktılarına bakarak tek tek düzenleme yapmamız da gerekmiyor. Bizim yerimize ed komutu diff komutunun çıktılarına bakarak otomatik olarak gerekli düzenlemeleri yapabiliyor. Hadi gelin ed komutundan bahsederek devam edelim.

# ed

Esasen ed komutu metin dosyalarını oluşturmak, görüntülemek, değiştirmek ve başka şekillerde işlemek için kullanılıyor. Çok fazla kullanım biçimi olmasına karşın biz buradaki anlatımlarda sadece iki dosya arasındaki değişikliklerin yok edilmesi için kullanıyor olacağız.

ed komutunu dosyadaki değişikleri düzenlemek için kullanmadan önce diff komutundan ed komutunun işleyebileceği biçimde hangi değişikliklerin yapılması gerektiğini çıktı olarak elde etmemiz gerekiyor. Bunun için diff komutunun -e seçeneğini kullanabiliyoruz. Ben e seçeneğini de ekleyerek tekrar isimler1 ve isimler2 dosyalarını kıyaslıyorum. Bakın bu elde ettiğim çıktı, ed dosyasının okuyabileceği türden. Ben bu çıktıları "kural" isminde bir dosyaya kaydetmek üzere yönlendirme operatörünü de ekleyip diff -e isimler1 isimler2 > esle.txt karşılaştırma bilgilerini dosyaya yönlendiriyorum.

Şimdi son olarak dosyanın sonuna w ifadesini eklememiz gerekiyor. Çünkü biz w ifadesini eklediğimizde ed komutu dosya üzerinde yazama izniyle işlemini yapabilecek. Ben dosyanın sonuna ekleme yapmak için cat >> kural komutunu girip, w ifadesini ekliyorum.

Tamamdır artık ed komutunu kullanmaya hazırız. İçerisinde kurallar bulunan dosyamızı kullanarak, ilk dosyasının içeriğinin değiştirilmesi için komutumuzu ed - isimler1 < kural şeklinde girebiliriz. Buradaki tire işareti ile ed aracına girdileri standart girdiden okuması gerektiğini söylemiş oluyoruz. Kuralların hangi dosya üzerinde uygulanacağını yani içeriği düzenlenecek olan dosyayı da burada argüman olarak belirtiyoruz. En sonunda yönlendirme operatörü ile de kural dosyasını standart girdiye yönlendiriyoruz. Bu sayede kural dosyasındakilere göre isimler1 dosyasının içeriği düzenlenecek. Hemen komutumuzu onaylayalım.

Gerekli değişiklikler dosyamızda yapılmış olmalı. Biz isimler1 dosyasının isimler2 dosyası ile aynı içeriğe sahip olması için düzenleme yaptık. Paste komutu ile iki dosyayı yan yana bastırarak ikisinin de aynı olup olmadığını teyit edebiliriz. Bakın her iki dosya içeriği de birebir aynı. İşte sizler de bu şekilde diff komutu ile değişiklikleri bulup, ed komutu ile bu değişikliklerin ilgili dosyanın diğer dosya ile aynı içeriğe sahip olacak şekilde uygulanmasını sağlayabilirsiniz. Yani daha önce yaptığımız gibi tek tek tüm adımlarını kendiniz uygulamanız gerekmiyor. 

Kaldı ki dosyanın aynısı oluşturmak istiyorsanız, aslında doğrudan ilgili dosyayı kopyalama imkanınız da var. Bunun yerine ben şahsen diff aracını iki dosya arasındaki farkları daha net görebilmek adına kullanıyorum. Esasen dosyalar arasındaki farkları söyleyen başka araçlar da var ama şahsi olarak diff komutu daha kolay ulaşılabilir ve okunabilir geldiği için ben diff aracını tercih ediyorum. 

Bir de diff aracı dışında çok daha görsel şekilde farkları görmemizi sağlayan vimdiff aracı da bulunuyor. Ancak vimdiff aracı her sistemde yüklü olmayabilir. Eğer sisteminizde vim yüklü ise veya sonradan yüklediyseniz vimdiff aracı da beraberinde gelmiştir. Hazır yeri gelmişken çok kısaca vim diff aracına da değinmek istiyorum. 

# vimdiff

Vimdiff aracı özellikle içerikleri renkli şekilde görselleştirdiği için farklılıkların kolayca gözlemlenebilmesini sağlıyor. Kullanımının detaylarına değinmeyeceğim zaten bahsedilecek çok detay yok. Test etmek için daha önce oluşturduğum dosyaları bu kez de vimdiff komutu ile tekrar kıyaslamak istiyorum. Ben denemek için vimdiff adlar adlar2 şeklinde komutumu giriyorum.

Bakın renkli şekilde tüm farklar açıkça karşımıza getirildi. Örneğin aynı bölümler mor ile belirtilmişken, farklı olanlar açıkça kırmızı ile belirtiliyor. Fazlalık olan kısım da mavi renkle temsil ediliyor.

Örneğin ilk dosya içeriğini düzenlemek istersem i tuşuna basıp burada kırmızı olan mehmet ifadesinin üstüne gelip, diğer dosyadaki mehtap ifadesi ile aynı hale getirebilirim. Bakın aynı satırlar yanı ifadeleri içeriği için kırmızılık yok olup, yerini mora bıraktı. Benzer şekilde örneğin ilk dosyayı değil de ikinci dosyayı düzenlemek istersek esc tuşuna basıp normal moda döndükten sonra iki kez ctrl w tuşu ile bir sonraki dosyaya geçiş yapabiliriz. Bakın ben iki kez ctrl w tuşuna bastığımda bir sonraki sayfaya geçebildim. Bu şekilde yani iki kez ctrl w tuşlaması yaptıkça sayfalar arasında geçiş yapabiliyorum. Şimdi ben ikinci sayfayı düzenlemek için bu sayfadayken i tuşuna basıyorum.

Şimdi örneğin sude isminden önce fatma ifadesini ekleyip bu bölümün eşitlenmesini sağlayabilirim. Bakın eşitlediğim bölüm yine mor renkle temsil ediliyor. İşte bu şekilde dosyaları görsel olarak kıyaslayıp istediğimiz dosyanın içeriğinde değişiklik yapabiliyoruz. Değişikliklerin ardından bu değişiklikleri kaydetmek istersek de tıpkı daha önce olduğu gibi esc tuşuna basıp :wq komutu ile değişikliklerin kaydolmasını sağlayabiliyoruz. Bakın ben her iki dosyada da değişiklik yapığım ilk dosyayı kaydettikten sonra aynı şekilde diğer dosyanın içeriğini de :wq komutu ile kaydedip kapatmam gerekiyor. 

Tekrar dosya içeriklerini yan yana görmek için paste komutunu kullanabiliriz. Bakın uyguladığım değişiklikle dosyalarda geçerli olmuş.  Görebildiğiniz gibi vimdiff aracı son derece kolay kullanıma sahip kıyaslama ve düzenleme ortamı sağlıyor. Eğer ihtiyacınız varsa ve vim aracı sisteminizde yüklü ise bence kullanmamanız için hiç bir sebep yok. Hatta biraz araştırırsanız işlevsel pek çok ek özelliğini de kolayca keşfedebilirsiniz. 

# cut

cut komutu, satıların istenilen bölümlerinin kesilmesini sağlayan bir araçtır. Zaten isminde geçen cut ifadesi Türkçe olarak kesmek anlamına geliyor. Ben örnekler sırasında basit bir metin dosyası üzerinde çalışıyor olacağım ancak siz okunabilir formatta olan tüm metinsel verilerinizi cut komutu ile kesip biçimlendirebilirsiniz.

Öncelikle dosya içeriğini cat komutu ile görüntüleyelim. Bakın boşluklarla ayrılmış pek çok sütun bulunuyor. Normalde tabii ki daha anlamlı veriler üzerinde çalışıyor olacaksınız fakat ben komutun anlaşılması için yani bölümleri etkilediğini daha rahat görebilmemiz için dosya içerisine satır1bolüm1 satı1bölüm2 veya satır2bölüm1 şeklinde tek tek yazdım. 

Şimdi cut aracının kullanımına geçecek olursak, örneğin ben bu dosyadaki tüm sütunları değil de yalnızca 1 ila 4. sütunları istiyorsam cut komutuna bu durumu izah edebilirim. Bu işlem için cut komutuna bu verileri neye bakarak ayıracağını bildirmemiz gerekiyor. Tıpkı kabuğun komutları yorumlaması gibi cut aracı da elindeki verilerin hangi parçalardan oluştuğunu anlamak için bir delimiter yani sınırlayıcı karakter belirtmemizi istiyor. Bunun için cut komutundan sonra -d seçeneğinin hemen ardından sınırlayıcı karakteri yazmamız lazım. Örneğin benim dosyamda boşluk karakteri sütunları birbirinden ayırdığı için ben tırnak için “ “ boşluk karakterinin sınırlayıcı olduğunu belirtiyorum. Şimdi son olarak hangi sütunların, yani aslında burada da belirttiğimiz şekilde hangi bölümlerin kalmasını istiyorsak, bunu fields yani alanlar-bölümler seçeneğinin kısalması olan -f seçeneğinin hemen ardından belirtebiliyoruz. Ben 1 ila 4. bölümleri almak istediğim için 1-4 şeklinde yazıyorum ve işlenecek verilerin bulunduğu dosyanın ismini de ekleyip komutumu onaylıyorum.

Bakın yalnızca 1. den 4. bölüme kadar olan sütunlar bastırıldı. Hatta emin olmak için tekrar cat dosya-ismi şeklinde komutumu giriyorum. Bakın normalde 7. sütuna yani 7. bölüme kadar olan içerikler cut komutu sayesinde 4. bölüme kadar kesilmiş oldu. cut komutu ona söylediğimiz gibi dosya içeriğini okuyup dosyadaki boşluk karakterinin bulunduğu tüm bölümleri birbirinden ayırdı ve bizim belirttiğimiz bölümleri de filtreleyip bize sundu. Burada önemli olan, bölümleri birbirinden ayıran boşluk karakterinin cut komutuna bildirilmesi. Hatta bu durumda emin olmak için ben aynı içeriğin boşluk yerine virgüllerle ayrılmış sürümü üzerinden cut komutunu tekrar kullanmak istiyorum. Öncelikle dosya içeriğini kontrol etmek için cat komutu ile virgüllü dosyayı okuyalım. Bakın buradaki tüm bölümler virgülle birbirinden ayrılmış durumda. Şimdi biz bu verileri kesmek istersek virgüllerin sınırlayıcı değer olduğunu özellikle belirtmemiz gerekiyor. Bu durumu bizzat teyit etmek için virgülü belirtmeden önceki komutumuzu yani boşluk karakterini sınırlayıcı olarak belirttiğimiz komutumuzu bu dosya üzerinde de uygulamayı deneyebiliriz. Bakın herhangi bir kesme işlemi uygulanamamış. Şimdi buradaki delimiter yani sınırlayıcı karakteri olarak tırnak için virgül karakterini ekleyelim. “,” Bakın virgül karakteri sayesinde birbirinden ayrıştırılan bölümler cut komutu tarafından işlenip tam olarak istediğim bölüm aralığı karşıma getirilmiş oldu. Bu örnek üzerinden de görebildiğimiz gibi elimizdeki verinin türüne göre sınırlayıcı olan değeri doğru şekilde belirtmezsek, kesme işlemi de uygulanamıyor. Eğer cut komutuna herhangi bir sınırlayıcı karakter belirtmezsek, cut varsayılan olarak tab boşluklarına göre bölümleme yapıyor. Hemen denemek için herhangi bir sınırlayıcı karakter veya dosya ismi belirtmeden cut -f 3 şeklinde komutumu giriyorum. Bu komut sayesinde bakın cut komutu bizden veri girmemizi bekliyor. Biz buraya verileri girip enter ile onayladığımızda girdiğimiz verilerdeki 3. bölümde yer alan bölümü bize çıktı olarak tekrar sunacak. Çünkü ben burada -f 3 seçeneği ile 3. bölümdeki verilerin bastırılmasını talep ettim. Hemen denemek için aralarında yalnızca boşluk karakteri bulunacak şekilde 1 2 3 4 şeklinde komutumuzu girelim. Bakın 3. rakamını değil, doğrudan tüm girdiğimiz verileri çıktı olarak geri aldık. Çünkü cut komutu boşluk karakterini varsayılan sınırlayıcı karakter olarak görmüyor. Bunun yerine 1 tab 2 tab 3 tab 4 tab 5 şeklinde tekrar veri girişi yapıp enter ile onaylayabiliriz. Bakın bölümleri tab tuşu ile ayırdığım için yanıt olarak 3. bölümdeki 3 rakımını almış olduk. Böylelikle bu örnek üzerinden cut komutunun varsayılan sınırlayıcı değer olarak tab boşluğunu kabul ettiğini, ve spesifik olarak dosya ismi belirtilmediğinde doğrudan standart girdiden yani bizim örneğimizde konsolumuzdan verileri alıp işleyebileceğini görmüş olduk. Ayrıca -f seçeneğinin ardından belirttiğimiz tek bir sayı ile spesifik olarak istediğimiz tek bir bölümü filtreleyebileceğimizi de görmüş oldu.

Birkaç kullanım biçiminden daha bahsedecek olursak, tek bir bölüm yerine spesifik olarak birden fazla bölümü tanımlamak için de virgüller bölümleri belirtebiliriz. Ben 1 3 5 ve 6. bölümü istediğim için field seçeneğinin ardından 1,3,5,6 şeklinde komutumu giriyorum. Bakın tam olarak belirttiğim bölümler karşıma getirildi. 

Farklı bir kullanım biçimi olarak örneğin 3 e kadar olan bölümleri elde etmek için filed seçeneğinin ardından -3 şeklinde yazabiliriz. Buraya yazdığım eksi işareti “e kadar” anlamına geliyor. Yani örneğin -5 şeklinde yazıldığında 5 de dahil 5 e kadar olan bölümler demiş oluyorum. Hemen sonucu görmek için komutumuzu onaylayalım. Bakın tam olarak belirttiğim şekilde -3 ifadesi sayesinde 3. bölüme kadar bölümleri bastırmayı başardık. Benzer şekilde 3 den sonrası için de 3- şeklinde komutumuzu düzenleyebiliriz. Bakın şimdi de 3. bölüm de dahil 3 den sonraki tüm bölümler bastırıldı. Eğer işlediğimiz verilerde kaç bölüm olduğundan emin değilseniz bu şekilde aralık belirtip aralıktaki tüm bölümlerin kapsanmasını sağlayabilirsiniz. Zaten örneğin 3-5 şeklinde yazdığımızda da 3 den 5 e kadar değiş oluyoruz. Aralığı spesifik olarak başlatmadığımızda veya bitirmediğimizde cut komutu eldeki verilere göre aralığa uygun bölümlerin hepsini işliyor. 

Aslında cut komutun başka seçenekleri de bulunuyor ancak diğer seçeneklerin detaylarına girmeyi düşünmüyorum. Zaten temel çalışma yapısını anladığınız için cut —help komutu ile elde edeceğiniz buradaki tüm açıklamaları rahatlıkla anlayıp uygulayarak test edebilirsiniz. Örneğin bakın complement seçeneği, bizim belirttiğimiz bölümlerin haricindeki bölümleri bastıran bir seçenekmiş. Bu durumu görmek için en son girdiğimiz komutu tekrar girelim. Şimdi bir de bu komuta —complement seçeneği ekleyip tekrar girelim. Bakın ilk komutta tam olarak belirttiğimiz bölümler bastırılırken, complement seçeneğini kullandığımızda belirttiğimiz bölümlerin haricindekiler bastırıldı. 

Complement seçeneği haricinde örneğin yalnızca bölümleri bastırmak yerine karakter veya baytlara göre kesme işlemi yapabileceğimiz de belirtilmiş. Örneğin 1 den 5. karaktere kadar olan bölümü bastırmak istersek cut -c 1-5 dosya ismi şeklinde komutumuzu girebiliriz. Bakın yalnızca 1 den 5 e kadar olan karakterler bastırıldı. Farklı bir örnek olarak mesela 5 den sonrasını bastırmak istersem komutumu cut -c 5- dosya-ismi şeklinde girebilirim. 5 den sonraki kısa çizgi işareti sayesinde 5 den sonraki karakteri işaret etmiş oldum ve bu doğrultuda ilgili karakterler bastırıldı. Ayrıca complement seçeneğini kullanarak işaret ettiğimiz karakterler haricindeki karakterin basılmasını da sağlayabiliriz. Bunun için komutumuzun sonuna —complement seçeneğini eklememiz yeterli. Bakın bu kez de 5. karakterden öncekileri kesip konsola bastırmış olduk.

İşte sizler de bu şekilde yalnızca bölümleri kesmek yerine istediğiniz karakterleri de kesebilirsiniz.

Ayrıca tekrar cut komutunun yardım sayfalarına dönecek olursak bakın burada karakterleri seçme imkanının yanında bir de özellikle baytları seçebileceğimiz -b seçeneği de bulunuyor. Aslında karakter ve bayt seçme seçenekleri aynı şekilde davranıyor. Emin olmak istersek son girdiğimiz komuttaki -c seçeneğini -b ile değiştirebiliriz. Bakın -c yani karakter seçeneği ile b yani baytları filtreleyebilmemizi sağlayan seçenek aynı şekilde çalışıyor. Siz dilediğiniz seçeneği kullanarak karakter filtrelemesi yapabilirsiniz. Fakat karakter filtrelemesi yaparken karakterlerin bayt karşılıklarına da dikkat etmeniz gerekiyor. Aksi halde türkçe gibi tek bir karakterin birden fazla baytla temsil edildiği durumlarda beklediğiniz çıktıları alamazsınız. Ne demek istediğimiz hemen bir örnek üzerinde görmek için öncelikle cat komutu ile dosyamızın içeriğini bastıralım. Bakın burada küçük ı veya ö gibi bazı türkçe karakterler bulunuyor. Örneğin ben yalnızca 3 karakteri yani “t” ifadesini konsola bastırmak istersem cut -c 3 dosya-adı şeklinde komut girmem yeterli. Bakın “t” karakteri konsola bastırıldı. Şimdi bir de 4. karakteri yani küçük ı karakterini aynı şekilde bastırmak için cut -c 4 dosya-adı komutunu girelim. Bakın bu kez yalnızca tanımlanamayan karakterleri temsil eden kare içindeki soru işareti çıktısını aldık. Peki neden böyle olduğuna dair bir fikriniz var mı ?

Evet daha önce de söylediğim gibi, bazı türkçe karakterler birden fazla bayt ile temsil edildiği için birden fazla karakterlik alan kaplıyor. Dolayısıyla bu gibi karakterleri bastırmak için kapladıkları bayt boyutunu veya baytın karakter karşılığını özellikle belirtmemiz gerekiyor. Örneğin ı karakteri 2 baytlık yani 2 karakterlik alan kapladığı için komutumuzu 4-5 şeklinde düzenleyip tekrar girdiğimizde, gördüğünüz gibi ı karakterini de sorunsuzca görüntüleyebiliyoruz.

Peki ama neden bazı karakterler daha fazla yer kaplıyor diye düşünüyorsanız hemen kısaca açıklamaya çalışalım.

Çok fazla detaylarına girmeden açıklayacak olursak. 

Bilgisayarların yalnızca 0 ve 1 lerden anladığını mutlaka duymuşsunuzdur. Yani en genel söylemle bilgisayar ile iletişimi 0 ve 1 ler sayesinde sağlıyoruz. Düşük akım 0 iken yüksek akım 1 olarak kabul ediliyor. Bu elektrik sinyallerinin uygun şekilde sıralanması ile bilgisayar, verileri işleyip sonuçlarını sunabiliyor. Tüm veri aktarımı bu ikili sayı sistemi üzerinden yapılıyor. Bu ikili sayı sistemine yani 0 ve 1 lerden oluşan veri kümesine de ikili kod yani binary code deniyor.

Bu 0 ve 1 sinyalleri de bilgisayarlar üzerindeki en küçük veri birimi olan bit kelimesi ile ifade ediliyor. 

8 tane bit yan yana getirilerek de bir bayt oluşturuluyor. Dolayısıyla bir bayt 2 üzeri 8 den tam 256 farklı değeri temsil edebiliyor. 

Bu baytlar da ascii gibi standartlarca önceden belirlenmiş olan özel karaktere karşılık geliyor. Örneğin büyük A harfinin ikili sayı sistemindeki karşılığı 0 1 0 0 0 0 0 1 olup ascii kodu 65 tir. Bu achii tablosunda belirlenmiş olan standarttır. Ascii tablosuna bakan herkes büyük A harfine bu yolla ulaşabiliyor yani. Bizi şu an doğrudan ilgilendirmediği için ascii kodunun nasıl hesaplandığına değinmek istemiyorum. Kısa bir ek araştırma ile ulaşabilirsiniz.

![Screenshot_1.png](17-%20Disk%20Yo%CC%88netimi%208473f3dcf9ef41a480ae911a73fc483d/Screenshot_1.png)

Neticede burada esas vurgulamak istediğim, biz tek bir karakteri kullandığımızda örneğin klavyemizden a tuşuna bastığımızda bu karakter toplam 8 bitten 1 bayta karşılık geliyor ve bilgisayar bu a karakterini ikili kod olarak ele alıp işliyor.  

Bu sistem geliştirilirken ingilizce için gerekli olan tüm harfler, sayıları ve sembolleri dikkate alınarak ASCII standardı oluşturulmuş. Fakat zaman içinde farklı dillerdeki sembollerin de temsil edilmesi gerektiği için ASCII standardı da doğal olarak yeterli gelmemeye başlamış. İşte bu sorunu çözmek için de UTF-8 isminde yeni bir standart sunulmuş. Bu standartta karakterlerin temsili için tek bir bayt yerine 1 ila 4 bayt kullanılabildiği için inanılmaz sayıda farklı karakterin doğru şekilde temsil edilebilmesi de mümkün oluyor. 

İşte örneğin küçük ı karakteri de 2 bayt ile temsil edildiği için bizim cut komutuna -b seçeneğinin ardından bu iki baytı belirtmemiz gerekiyor. Ya da -c seçeneğinin ardından da küçük ı karakteri iki karakterlik alan kapladığı için yine bu iki karakter aralığını yazmamız yeterli oluyor.

Buradaki anlatım çok yalın bir açıklama sadece. Ben yalnızca neden bazı karakterlerin birden fazla bayt ile temsil edildiğiniz veya birden fazla karakterlik alan kapladığını anlayabilmemiz için çok kısaca durumu açıklamak istedim. Daha fazla bilgi için interneti kullanabilirsiniz. Örneğin bu konuda youtube üzerinde bile onlarca güzel video var. 

# split

splite , verileri parçalara ayırabilmemizi sağlayan bir araçtır. Zaten split kelimesi Türkçe olarak bölmek anlamına geldiği akılda kalan bir komut. Ben örnek verebilmek için daha önce içerinde 1000 satır bulunan basit bir metin dosyası oluşturdum. Yani içerisinde 1000 satır bulunan tek bir dosyam var şu anda. Ben bu dosyanın tüm içeriğini belirli bir satır sayısına göre parçalara ayırmak istiyorum. Dosya içeriğini belirli satır aralıklarından bölmek için satırların ingilizce karşılığı olan line seçeneğinin kısalmasını yani -l seçeneğini kullanabiliyoruz. Ben dosyamı 250 şer satır olacak şekilde bölmek istiyorum. Bu sayede tüm dosyanın içeriğin 250 satırdan oluşan 4 dosyaya bölünmüş olacak. Bunun için split -l 250 dosya-ismi şeklinde komutumuzu girebiliriz. Komutumu onayladıktan hemen sonra dosya içeriği parçalanıp yeni dosyalar oluşturuldu. Teyit etmek için ls -lh komutunu kullanabiliriz. Bakın burada xaa xab xac xad şeklinde sırasıyla isimlendirilişmiş 4 dosya bulunuyor. Dosya boyutlarına baktığımızda orijinal dosyanın 4 parçaya bölünmüş boyutu olduğunu da görebiliyoruz. Hatta emin olmak istersek paste xa* komutu ile dört dosyanın içeriğini de yan yana bastırabiliriz. Bakın dört dosyanın da sırasıyla 250 500 750 1000 şeklinde 250 şer satırdan parçalara ayrıldığını görebiliyoruz. İşte dosya içeriğini dilediğimiz satır aralığından parçalara ayırmak bu kadar kolay.

Satır sayısı belirtmek yerine spesifik olarak kaç parçaya ayrılması gerektiğini de belirtebiliriz. Öncelikle daha önce oluşturulan dosyaları silmek için rm xa* komutunu giriyorum. 

Şimdi ben dosya içeriğini 5 parçaya bölmek istiyorum. Bunun için split komutundan sonra -n seçeneğini yazıp 5 rakamını da ekliyorum. Dosya ismini de girdiğimizde işlem tamamdır. ls -lh ile dosyaları listeleyelim. Bakın bu kez sıralı şekilde 5 dosyanın oluşturulduğunu ve bu dosyaların toplam boyutlarının orijinal dosyanın boyutunu verdiğini görebiliyoruz. Dosya içeriği 1000 satırdan oluştuğu için ve ben de 5 eşit parçaya bölünmesini istediğim için 200 şer satırlık 5 dosya oluşturuldu. Görmek için paste xa* şeklinde komutumuzu girebiliriz. Bakın satırlar biraz kaymış olsa da yaklaşık olarak 200 şer satırdan oluşan 5 dosya oluşturulmuş. Yani doğrudan satır sayısı yerine kaç parçaya ayırmak istediğimizi belirterek de dosya içeriğini bölümleyebiliyoruz. Ancak tıpkı bu örnekte olduğu gibi özellikle metin dosyalarının içeriklerinde satır haricinde parçalama yaptığımızda içerikte kaymalar oluşabiliyor. Örneğin ben 5 parçaya değil de 7 yada 11 13 gibi farklı sayıda parçaya bölmek isteseydim dosya içeriği de bu doğrultuda pek simetrik olmayacak şekilde bölünebilirdi. 

Ayrıca özellikle büyük boyutlu dosyaların arşivlenmesi için satır veya parça belirtmek yerine doğrudan ne kadarlık boyutlarda dosyalar oluşturulmasını istediğimizi de belirtebiliyoruz. Önceki oluşturduğumuz dosyaları silmek için rm xa* komutumuzu girelim. Tamamdır.

Örneğin bakın burada 10 mb kadarlık bir dosyam daha bulunuyor. Eğer ben bu dosyanın 1 er mb dosyalar halinde bölünmesini istersem -b seçeneğinin ardından istediğim boyutu belirtmem mümkün. Buradaki b seçeneği byte ifadesinin kısaltmasından geliyor ancak biz büyüklükleri bayt cinsinden belirtmek zorunda da değiliz. Örneğin ben 1 mb lık parçalara bölmek istediğim için komutumu split -b 1M dosya-ismi şeklinde giriyorum. Şimdi sonuçlara bakalım. 

Bakın sırasıyla isimlendirilmiş 1 megabaytlık dosyalar oluşturuldu. Tabi dosyanın boyutuna göre en sondaki parçanın boyutu 1 megabayttan az olabiliyor. Ancak neticede görebildiğiniz gibi ilgili dosya tam olarak benim belirttiğim gibi birer megabaytlık parçalara ayrılmış bulunuyor.

Belki buradaki sıralı isimlendirmeye takılmış olabilirsiniz. Aslında dilerseniz buradaki isimlendirmeyi istediğiniz şekilde düzenleyebilirsiniz. Çok fazla detayına girmeyeceğim ama örneğin ben parçalanma sonucu ortaya çıkan dosyaların “bolunmus” isim ön ekiyle başlamasını istiyorsam komutumun sonuna bunu belirtebilirim. Yani örneğin en son girdiğim komutun sonuna “bolunmus-” ifadesini eklemem yeterli. ls -lh ile tekrar kontrol edelim. Bakın benim belirttiğim “bolunmus-” ifadesinin hemen alfabetik olarak sıralanmış dosya isimleri üretilmiş. Eğer dosyalarınızı bu şekilde isimlendirmek istiyorsanız komutunuzun sonuna tıpkı benim yaptığım gibi eklemeniz yeterli. 

Pek her şey güzel ancak bu böldüğümüz dosyaları tekrar tek parça haline getirmek istersek sizce ne yapmamız gerekiyor ? 

Eğer yönlendirmelerden bahsettiğimiz bölümü atlamadıysanız bu sorunun cevabını doğru tahmin etmişsinizdir. Evet cat aracını kullanarak parçalara ayrılmış bu dosyaları tek bir dosya olarak birleştirebiliriz.

Örneğin ben en son oluşturduğum bolunmus ön ismiyle başlayan dosyaları tek bir dosya haline getirmek istediğim için cat bolunmus-* > birlesmis-dosya şeklinde yazıyorum. Bakın buradaki cat aracı isminin başında bolumus- ifadesi geçen tüm dosyaları buradaki yıldız dosya ismi genişletmesi sayesinde okuyup, buradaki yönlendirme operatörü sayesinde de bu dosyaya yönlendirecek. Cat aracı a dan z ye kadar sıralanmış olan tüm dosyaları sırasıyla okuyup yönlendireceği için de daha önce parçalara ayrılmış olan tüm dosya bölümleri tıpkı ilk hali gibi eksiksiz şekilde bir araya gelmiş olacak. Yani dosya içeriğinde sıralama konusunda da bir sorun yaşanmamış olacak. Hemen görmek için komutumuzu onaylayalım. ls -lh komutu ile kontrol ettiğimizde, bakın dosyanın oluşturulduğunu görebiliyoruz. Dilersek diff aracı ile iki dosya arasındaki farkları da kıyaslayabiliriz. 

Kıyaslamak için diff komutun ardından orijinal dosyayı ve yeni bir araya getirdiğim “birlesmis” dosyasını yazıp komutumu onaylıyorum. Bakın herhangi bir çıktı almadık çünkü iki dosya birebir aynı. Eğer aralarında ufak bir farklılık dahi olsa daha önce de gördüğümüz gibi diff aracı bu farkı bize sunacaktı.

Tamamdır sanırım split yani bölümleme aracı hakkında temelde bilmemiz gerekenlerden bahsettik. Diğer özellikleri ve seçenekleri için hemen split —help komutunun çıktılarından faydalanabilirsiniz. Temel kullanımını bildiğiniz için diğer seçenekleri de rahatlıkla kuracalayabilirsiniz.

# md5sum sha256sum sha512sum

split komutunu ele alırken dosya içeriklerini nasıl parçalayabileceğimizden ve parçalamış olduğumuz dosyalarını nasıl tekrar bir araya getirebileceğimizden bahsettik. Hatta dosya içeriklerinin aynı olup olmadığını kontrol etmek için diff aracını da kullandık. Diff aracından farklı bir yaklaşım için bu derste çok kısaca hash kıyaslamasından da bahsetmek istiyorum.

Burada bahsi geçen hash kavaramı, belirli bir veri kümesinin bütünlüğünün kontrol edilebilmesi için bu veri kümesine özel olarak üretilmiş olan değerdir. Örneğin bir dosyayı md5 algoritmasından geçirip bir hash değeri elde ettiğimizde, bu dosya ile birebir aynı içeriğe sahip başka bir dosya da md5 algoritmasından geçirildiğinde aynı hash değerini veriyor olacak. Hemen denemek için daha önce parçalayıp tekrar birleştirdiğim dosya ile orijinal dosyanın hash değerlerini kıyaslamak istiyorum.

Mesela ben bu orijinal dosyayı md5 algoritmasından geçirip hash değerini üretmek istediğim için linux üzerinde bu işi yapan md5sum aracını kullanabilirim. Komutumu md5sum dosya-ismi şeklinde giriyorum. Bakın dosyamın hash değeri bu şekilde. Eğer bu dosyanın içeriğiyle birebir aynı olan dosya mevcutsa, o dosyanın hash değeri de aynı olacak. Bizzat görmek için sonradan birleştirdiğim dosyanın ismini de ekliyorum. Bakın iki dosyanın ismini girdiğim için her iki dosya sırasıyla md5 algoritmasından geçirilip bir hash değerleri üretildi. Ve alt alta gördüğümüz için her ikisinin de aynı hash değerine sahip olduğunu görebiliyoruz. Yani her iki dosya içeriği de birebir aynı.

Emin olmak için farklı bir dosyanın hash değerini de hesaplayabiliriz. Ben alakasız bir dosyanın hash değerinin de hesaplanması istediğim için  dosyanın ismini de ekliyorum. Bakın bu dosyanın içeriği bu dosyalardan farklı olduğu için tamamen farklı bir hash değeri üretilmiş oldu. 

Hatta dosya içeriğindeki ufak bir değişimin bile hash değerini değiştireceğini teyit etmek için buradaki orijinal dosyada ufak bir değişiklik yapıp hash değerini yeniden hesaplayabiliriz. Ben bunun için echo a >> dosya-ismi şeklinde komutumu giriyorum. Bu komut sayesinde dosyamın sonuna yalnızca a karakterini eklemiş oldum. Şimdi hash değerini yeniden hesaplamak için hem orijinal hem de sonradan birleştirmiş olduğum dosyanın ismini girmek istiyorum. Bakın artık orijinal dosyam diğer dosyadan tamamen farklı bir hash değerine sahip. Hash değeri farklı çıktı çünkü ben orijinal dosyaya yeni bir karakter ekleyerek dosyada değişiklik yapmış oldum. Bence böylelikle hash değerlerinin ne kadar benzersiz olduğunu ve dolayısıyla veri bütünlüğünü kontrol etmek için iyi bir yaklaşım olduğunu son örneğimizle birlikte bizzat teyit etmiş olduk.

İşte zaten tıpkı md5 algoritmasında olduğu gibi sha256 veya daha farklı pek çok hash hesaplama algoritmasını kullanabiliyoruz. Bu yaklaşımlar sayesinde birebir aynı veri kümesi olmadan aynı hash değeri üretilemiyor ve verilerin bütünlüğü kontrol edilebiliyor. Bu algoritmaların ve hash değerlerinin güvenlik çözümlerindeki kullanımlarına değinmeyeceğim ancak güvenlik yaklaşımları için hash değerlerinin kullanılabildiğinden de haberiniz olsun.  Ben örnek olarak md5 algoritmasını kullanmamızı sağlayan md5sum aracını ele aldım, ancak muhtemelen pek çok farklı algoritma için ilgili algoritmaları destekleyen araçlar varsayılan olarak sisteminizde yüklüdür. Örneğin sha yazdıktan sonra tab tuşu ile mevcut araçları listediğimizde, bakın sha256 veya sha512 gibi algoritmaları kullanabileceğimiz araçların sistemde halihazırda yüklü olduğunu görebiliyoruz. Yüklü olmadığı durumda kolayca kurmanız da mümkün zaten.

En nihayetinde, eğer herhangi bir veri kümesinin değişip değişmediğini teyit etmek istiyorsanız bu algoritmalardan dilediğiniz birini kullanabilirsiniz. Örneğin genellikle kurulum için kullanılan büyük iso dosyalarının dosya bütünlüğünün kontrolü için, dağıtımı sunan geliştiriciler bu kontrolü yapmanızı söylerler. Çünkü dosya indirilirken veya farklı aşamalarda dosya bozulmuş olabilir.

Ayrıca örneğin sizin gönderdiğiniz dosyanın hiç bir şekilde değişmeden karşı tarafa ulaştığına emin olmak istiyorsanız, dosyayı göndermeden önce dosyanın hash değerini alıp, karşı tarafa aynı algoritmayı kullanarak elindeki dosyanın hashi ile kıyaslamasını söyleyebilirsiniz. Bu sayede karşı taraf güvenlik endişesi taşımadan ilgili dosyayı kullanabilir. Yani özetle md5 gibi çeşitli algoritmalar kullanılarak oluşturulan hash değerleri, dosyanın değiştirilmemiş olduğunun teyit edilebilmesi için kullanılan yaygın bir yaklaşım. Siz de dosyaların değişmediğini veya birebir aynı olup olmadığını teyit etmek için bu yaklaşımları kullanabilirsiniz.

# shuf

İngilizcedeki shuffle ifadesinin karşılığı Türkçede “karıştırmak” anlamına geliyor. shuf aracının ismi de buradan geliyor. shuf aracı sayesinde satırların rastgele olacak şekilde karıştırılmasını sağlayabiliyoruz. Örneğin cat komutu ile liste1 dosyasını okuyacak olursam, bakın içinde 1 den 10 a kadar sıralı şekilde satırlar bulunuyor. Eğer ben bu dosyamın satır sıralamalarını karıştırmak istersem shuf komutunu kullanabilirim. Denemek için shuf komutundan sonra dosyamızın ismini girelim. Bakın bu kez rastgele sıralanmış şekilde satırlar bastırıldı. Komutumuzu her kullandığımızda, gördüğünüz gibi satırların sıralaması rastgele olacak şekilde karıştırılıyor. Elbette buradaki karıştırma işlemi kaynak dosyayı etkilemiyor. Shuf komutu kaynak dosyadan okuyup karıştırdığı satırları standart çıktıya bastırıyor. Yani orijinal dosyada bir değişiklik olmuyor. Teyit etmek için tekrar cat komutu ile “liste” dosyamızı okuyabiliriz. Bakın dosyanın içeriğinde herhangi bir değişiklik olmamış. Çünkü dediğim gibi shuf komutu yalnızca okuduğu satırları rastgele karıştırıp standart çıktıya yönlendiriyor. Eğer biz bu karışık listeyi bir dosyaya kaydetmek istersek, yönlendirme operatörü ile istediğimiz bir dosyaya yönlendirebiliriz. Ben bunun için komutun sonuna > karisik.txt şeklinde ekliyorum. Paste komutu ile dosyalarımızı yan yana bastırarak son duruma bakabiliriz. Bakın kaynak dosyada hiç bir değişiklik yok ve yönlendirme operatörü sayesinde standart çıktıyı yönlendirdiğimiz karisik.txt dosyasının içeriği de istediğimiz gibi karışık satırlardan oluşuyor.

Bu basit kullanım dışında eğer isterseniz tüm satırlar yerine belirli sayıda satırların bastırılmasını da sağlayabilirsiniz. Örneğin ben 10 satırdan oluşan bu listenin karıştırılıp, yalnızca 3 satırın bana çıktı olarak verilmesini istiyorum. Bunun için -n seçeneğinin ardından istediğim satır sayısını yazmam yeterli. Yani komutumuzu shuf -n 3 liste1 şeklinde girebiliriz. Bakın rastgele 3 satır bastırıldı. Komutumu tekrar tekrar girdiğimizde, yalnızca 3 satır olacak şekilde rastgele satırların bastırıldığını görebiliyoruz. 

Eğer karıştırılacak veriler dosyadan okunmayacaksa, -e seçeneğinin ardından arasında boşluk bırakarak yazdığınız tüm verilerin karıştırılmasını da sağlayabilirsiniz. Ben shuf -e 1 2 3 4 5 şeklinde yazıp komutumu onaylıyorum. Bakın girdiğim rakamlar rastgele olacak şekilde sıralandı. 

Benzer şekilde eğer doğrundan standart girdiden verilerin okunmasını istersek yalnızca shuf komutunu yazıp onaylayabiliriz. Bakın shuf komutu şu anda bizden girdi bekliyor. Buraya satır satır veri girip son olarak ctrl d ile standart veri girişini sonlandırdığımızda shuf aracı bu girdiğimiz satıları karıştırıp karşımızı getirecek.

Ben örnek olması için ilk satıra bu ilk satır, ikinci satıra “bu iki”, üçüncü satırda “bu üç” ve son olarak da “bu dört” şeklinde yazıp enter ile bir alt satıra geçtikten sonra ctrl d ile veri girişini sonlandırıyorum. Bakın shuf komutu benim girdiğim satıların sıralamasını rastgele değiştirmiş oldu. Fark ettiyseniz satırlar içinde girdiğim boşluk karakterlerine değil, doğrudan satırların kendisine bakılarak karıştırma işlemi yapıldı. Shuf komutunun -e seçeneğini kullandığımızda boşluklara bakılarak karıştırma işlemi yapılıyor. Dosya içeriğinden veya standart girdiden okunan verilerde satırlar referans alınıyor. Bu duruma dikkat ederek komut girerseniz, beklentileriniz doğrultusunda doğru sonuçlar elde edebilirsiniz.

Ayrıca buradaki örneğimizde standart girdiden veri okunması için shuf komutuna herhangi bir argüman vermedik ama aslında örneğin -n seçeneğini kullanarak karıştırılan satırlardan yalnızca kaç tanesini istiyorsak o kadarının bastırılmasını da sağlayabilliriz.

Ben denemek için shuf -n 2 şeklinde yazıp komutumu onaylıyorum. Bakın standart girdiden veri bekleniyor. Şimdi basit olması için 1 den 5 e kadar rakamları satır satır girip, ctrl d ile veri girişini sonlandıralım. Bakın 5. satırdan sonra yalnızca iki rastgele satır bastırılmış oldu. Burası bizim standart girdiye veri gönderdiğimiz alan, burası da shuf aracının ürettiği standart çıktı. İşte bizzat görebildiğimiz gibi standart girdiden veri okunurken de shuf aracının uygun seçeneğini kullanabiliyoruz. 

Neticede artık elinizdeki verileri karıştırmak istediğinizde shuf aracını nasıl kullanabileceğinizi biliyorsunuz. shuf aracının diğer seçeneklerini merak ediyorsanız shuf —help komutu ile yardım bilgisine göz atıp, kendiniz keşfedebilirsiniz.

Örneğin bakın hazır yeri gelmişken burada de geçen ve sıklıkla karşılaşabileceğiniz kısa çizgi ile standart girdiden veri okunmasına da değinmek istiyorum. Önceki örneğimizde shuf aracına herhangi bir argüman vermeden olduğu gibi kullandığımızda standart girdiden verileri okuyup işlevini yerine getirdiğini gördük. Dilersek bunun yerine shuf - yazıp aynı şekilde standart girdiden verilerin alınmasını da sağlayabiliriz. Bakın shuf aracı şu anda bizden veri girişi bekliyor. Hemen birkaç satır ekleyip, ctrl d ile veri girişini sonlandıralım. Gördüğünüz gibi, burada kullandığımız kısa çizgi işareti sayesinde shuf aracı standart girdi olarak bizim konsolumuzdan verileri alıp karıştırdı ve sonuçları yine bize aktarabildi. Benzer şekilde komutumuzu shuf -n 3 - şeklinde de girebilirdik. Şu an bizden veri girmemiz bekleniyor, yine sıralı şekilde rakamlar ekleyelim ve ctrl d ile girişi sonlandıralım. Bakın kısa -n seçeneğine ek olarak kısa çizgi kullandığımızda shuf aracı standart girdiden veri okuyabiliyor. İşte buradaki kısa çizgi işaretinin kullanımı ile başka araçlarda da karşılaşabilirsiniz. Standart girdiden veri kabul eden pek çok araç yalnızca ismi ile çalıştırıldığında standart girdiyi okuyor olsa da, kimi zaman kısa çizgi işaretinin kullanıldığı durumlarla karşılaşabilirsiniz. Özellikle internet üzerindeki rehber anlatımlarda standart girdiden veri okunacağının ayırt edici biçimde belirtilmesi için genellikle kısa çizginin kullandığını kendiniz de göreceksiniz. Yani siz standart girdiden verileri göndermek için her zaman kısa çizgiyi kullanmayacak olsanız bile artık haberdar olduğunuz için gördüğünüzde ne anlama geldiğini de biliyor olacaksınız. 

# pipe ile tee komutundan bahset

# pipe Hakkında

Şimdiye kadar sistem üzerindeki yapıların dosya olarak ele alındığından ve dolayısıyla dosya içeriklerini yani baytları istediğimiz gibi manipüle edilip yönlendirebilmenin neden çok önemli olduğundan pek çok kez söz ettik. Yani her şeyin aslında bir bayt akışı olduğunu vurguladık hep. Vurgulamaya da devam edeceğiz. Özetle sistemi komut satırı üzerinden yöneten kişi olarak bizim işimiz gücümüz hep bayt akışlarını kontrol etmek.

Hep birlikte dosya içeriklerinde birtakım değişiklikler yapabileceğimiz bazı araçları tanıdık. Başka araçlardan da bahsedeceğiz ancak devam etmeden önce birden fazla aracı birbirine bağlayarak çalıştırmamıza yardımcı olan pipe yani boru mekanizmasından bahsetmem gerekiyor. 

# Pipe

history | cut -c 8- | sort | uniq -c | sort -r | head

Yönlendirme işlemleri sırasında girdileri ve çıktıları istediğimiz şekilde nasıl aktarabileceğimizi öğrendik. Sizlerin de bildiği üzere yönlendirme sırasında aslında dosyalar arasında veri aktarmış oluyoruz. Yönlendirme işlemleri dosya tanımlayıcılar üzerinden gerçekleştirildiği için baytların yönlendirildiği adresin bir dosya olması veya sanal olarak dosya gibi temsil edilmesi gerekiyor. 

Peki ya bir aracın çıktısını başka bir araca girdi olarak aktarmak istediğimizde ne yapmamız gerekiyor ? Yani örneğin ben history komutu neticesinde üretilen çıktıları sort aracına aktarıp sıralamak ve daha sonra oradan da uniq aracına aktarıp benzersiz olanları ayrıştırmak istersem mümkün müdür ? Kısa cevap evet elbette mümkün.

Uzun cevap yani araçlar arasındaki veri aktarımını ele alabilmek için öncelikle çalıştırılan bir aracın sistem üzerindeki temsiline değinmemiz gerekiyor. Biz bir aracı çalıştırdığımızda, bu araç sistem üzerinde bir process yani bir işlem olarak ele alınıyor. Bu işlemlerin de sistem üzerinde sanal dosyalar ile temsil edildiğinden yani /proc dizini altında işlem numarası ile isimlendirilmiş klasör altında tutulduğundan bahsettik ama bu sanal dosyalar doğrudan yönlendirme işlemleri için bize bir kolaylık sağlamıyor. Örneğin history aracının çıktılarının doğrudan sort aracına aktarılmasını istediğimizde, öncelikle sort aracının sistem üzerinde hangi işlem numarası ile çalıştığını bulmamız daha sonra o işlem numarası ile temsil edilen uygun konumdaki dosya tanımlayıcıya yönlendirmemiz gerekiyor. Ancak gireceğimiz bir komut ile o anda oluşturulacak olan işlemler için bu yaklaşım pek mantıklı değil. 

Bu yöntem uygulanabilir olmadığı için temel yönlendirme mekanizmasını kullanarak veri aktarmak istiyorsak, ilk aracın ürettiği çıktıları bir dosyaya kaydetmeli, daha sonra başka bir aracın bu dosyadan veri alarak bu verileri işleyip yeni veriler üretmesini sağlamamız gerekiyor. Takdir ederseniz ki arada dosya olması bu işlemi yavaş ve verimsiz hale getiriyor. Özellikle 2 den daha fazla aracı peş peşe birbirine bağladığımızı düşünsenize. Önce ilk aracın çıktılarını bir dosyaya kaydetmemiz, daha sonra ikinci aracın bu dosyayı okuyup işledikten sonraki çıktılarını başka bir dosyaya kaydetmemiz ve bu şekilde kullanılacak araç sayısına göre birden fazla dosya oluşturup bu dosyaların ilgili araçlar tarafından okunmasını sağlamamız gerekiyor. Bu durumun bize kolaylık sağlamayacağı aşikar.

Tekrar sorumuza dönecek olursak; birden fazla aracı birbirine bağlı şekilde çalıştırmak için ne yapmamız gerekiyor ?

Eğer dosyalar yerine anlık olarak işlemler arasında veri aktarmak istersek pipe mekanizması tam olarak ihtiyacımız olan çözümü sağlıyor. Araçlar yani işlemler arasındaki verilerin anlık aktarımları için isimli(named-fifo) ve isimsiz(unnamed-ordinary) pipe olarak geçen yapılardan faydalanabiliyoruz. Pipe mekanizması aslında arkaplanda yine sanal dosya oluşturup verilerin bu sanal dosya üzerinden anlık olarak aktarılmasını sağladığı için dosya tanımlayıcıları üzerinden yönlendirme mekanizmasına uyum sağlıyor. Normalde araçlar arasında veri aktarımı yapmak için bizim manuel olarak dosya oluşturup bu dosyaların diğer araçlar tarafından tekrar okunmasını sağlamamız gerekiyor. Pipe mekanizması bu işlemi bizim için arkaplanda sanal dosyalar üzerinden anlık olarak çok hızlı bir biçimde halledebiliyor. Çünkü aslında disk üzerine herhangi bir veri kaydı gerçekleşmiyor. Bellek üzerinden bir aracın çıktıları doğrudan diğer araca aktarılacak şekilde yönlendiriliyor. Bu sayede disk üzerinde okuma yazmadan kaynaklanacak yavaşlama olmadan veriler çok hızlı biçimde aktarılabiliyor. İleride işlemler yani proses kavramından bahsettiğimiz bölümde pipe konusunu tekrar biraz daha detaylıca ele alıyor olacağız. Şimdilik çok fazla detay verip kafanızı karıştırmak istemiyorum.

 Pipe yapısına ihtiyaç duymamızdaki en temel iki sebep; hızlı çalışması ve aynı anda paralel şekilde işlemler arasında aktarım yapılabilmesidir. Biz şimdilik bu bölümde yalnızca isimsiz yani sıradan pipeları ele alacağız. Ancak merak etmeyin, hem bu bölümün sorunda hem de ileride process olarak bilinen “işlemler” konusunu ele aldıktan sonra bahsettiğim pek çok kavram sizin için çok daha anlamlı hale gelecek. Anlatımlarımıza isimsiz yani sıradan(ordinary) pipe ile başlayalım. 

## İsimsiz-Sıradan Pipe(Unnamed-Ordinary)

İsimsiz olarak geçen pipe, çubuk şeklinde görünen dik çizgi  `|` operatörü ile temsil ediliyor. Daha önce kısaca bahsettiğimiz gibi pipe mekanizması gereği pipe operatöründen önceki işlemin çıktıları, operatörden sonraki işlemin girdisi olarak aktarılıyor. Hatta aktarım biçimi de "ilk giren ilk çıkar/first in first out(fifo)" şeklinde ifade ediliyor. Yani veriler, ilk işlemin ürettiği sıraya uygun şekilde tek yönlü olarak bir sonraki işleme aktarılıyor. Daha iyi anlamak adına çalışma yapısına daha yakından bakalım.

Basit bir örnek üzerinden gidecek olursak; Diyelim ki ben find komutu ile sonu .jpg uzantısıyla biten dosyaları araştırmak, bulunan dosyaları isimlerine göre alfanümerik olarak sıralamak ve daha sonra numaralandırmak istiyorum. Bu işi yapacak tek bir araç var mı varsa da hangi seçenekleri kullanmalıyım tam olarak bilmiyorum. Ancak her birini yapan ayrı ayrı üç araç biliyorum. find sort ve nl araçları ilk aklıma gelenler. Sizin şu anda find ve nl araçlarını bilmediğinizin farkındayım, ancak merak etmeyin ileride hepsini ayrıca ele alacağız. Şimdi pipe yapısının çalışma mekanizmasını ele alabilmek için vereceğim örneğe odaklanmanız yeterli. Neticede ihtiyacım olan sonuca ulaşabilmek için bu üç aracı bir arada kullanabilirim. 

Öncelikle sonu jpg uzantısı ile biten dosyaların dosyaların bulunabilmesi için find / -name *.jpg -type f komutunu giriyorum. Bu komut sonu jpg ile biten dosyaları listeleyecek. find aracının çıktılarını sıralamak istediğim için de bu çıktıları sort aracına aktarmam gerekiyor. Aktarmak için pipe kullanabilirim. Pipe çubuk simgesi ile kullanılıyor. Sıralama işleminden sonra, sıralanmış çıktıları numaralandırmak için de sort aracının çıktılarını nl aracına aktarabilirim. Neticede birden fazla aracı peşi sıra tek bir amaç için kullanmış olduk. Şimdi komutumuzu onaylayarak çıktılara göz atalım. Gördüğünüz gibi yetkimiz olan dizinlerdeki sonu .jpg ile biten dosyalar kısa sürede klasör isimlerine göre sıralanmış ve numaralandırılmış şekilde bastırılmış oldu.

Peki bu çıktıyı tam olarak nasıl elde ettik yani pipe tam olarak nasıl çalışıyor ?

Bizim girdiğimiz komutta bulunan üç farklı araç aynı anda üç ayrı işlem olarak başlatıldı. İlk aracın standart çıktısı ikinci aracın standart girdisine bağlandı. İkinci aracın standart çıktısı da üçüncü aracın standart girdisine bağlandı. 

Yani bizim ele aldığımız örnekte find komutu sonu .jpg ile biten dosyaları araştırıp bulduğu sonuçları sort aracına girdi olarak aktardı. sort aracı da aldığı verileri sıralayıp anında nl aracına aktardı. Böylelikle tek bir görevi yerine getirmek için birden çok aracı birbirine bağlayarak çalıştırmış olduk.

Elbette bu işlemi her bir komutun çıktılarını bir dosyaya aktarıp ilgili dosyadan diğer araçların verileri okumasını sağlayarak da yapabilirdik fakat bu komutu yazmak hem daha uğraştırıcı olacaktı hem de araçlarımız pipe kullanımına oranla daha verimsiz çalışacaktı. Hemen bu durumu gözlemleyelim.

Aynı işlemi bu kez dosyalara yönlendirme ile denmek istiyorum. Öncelikle komutu yazayım, daha sonra açıklayacağım.

```jsx
find / -name *.jpg -type f > bul ; sort < bul > sırala ; nl < sırala
```

Bu girdiğimiz komutta önce find komutu çalıştırılacak ve işini tamamladığında çıktılarını “bul” isimli dosyaya aktaracak. Daha sonra sort komutu bul isimli dosyayı okuyacak ve içeriğindeki verileri sıraladıktan sonra sırala isimli dosyaya aktaracak. En son nl komutu sırala isimli dosyadaki içeriği okuyup numaralandıracak ve çıktısını konsolumuza basacak. İşte girdiğimiz komutun çalışma yapısı tam olarak bu.

Bakın yazması ve açıklaması bile gereğinden uzun sürdü. 

Çalışma hızı ise pipe a oranla daha yavaş olacak çünkü bu kullanımda komutlar sırasıyla disk üzerindeki dosyalara veri yazıp okuyarak çalıştırılıyor. Dolayısıyla soldan sağa doğru bir komut çalışmasını tamamlamadan bir sonraki komut çalıştırılmıyor. Pipe kullanımında ise tüm komutlar ayrı işlem olarak aynı anda parelel şekilde çalıştırılıyor. Her bir aracın ürettiği çıktı da üretilir üretilmez boru hattındaki diğer işlemlere disk üzerine veri yazılıp okunmasına gerek kalmadan aktarıldığı için veriler çok daha hızlı işlenmiş oluyor. Zaten ilk giren ilk çıkar ifadesi de buradan geliyor. Bir komut çıktı üretir üretmez, çıktının üretilme sıralaması korunarak bir sonraki işlem aktarıyor, bu sayede tüm veriler sırasıyla işlenmiş oluyor. Tabii ki bizim örneğimizde ilk aracın ürettiği çıktıların hepsinin alındıktan sonra sıralaması gerektiği için sort aracı find aracının çıktılarını bitirmesini bekledi aslında. Yani araçlar paralel çalışıyor olsalar da çıktıların gönderilme ve okunma durumlarına bağlı olarak birbirlerini de bekliyorlar. Yine de pipe mekanizması disk üzerindeki dosyalara okuma yazma yapmadığı ve araçları paralel olarak aynı anda çalıştırabildiği için çok daha verimli bir yaklaşım. Üstelik basit örnek üzerinden de görebildiğiniz gibi birden fazla aracı birbirine bağlayacak çalıştırmak istediğimizde pipe ile komut girmek çok da daha kolay ve kısa.

Ayrıca örnek üzerinde peşi sıra pipe kullandığımız bu komutun bütününe de pipeline yani boru hattı deniyor. Neticede birden fazla pipe yani boru kullanarak ikiden fazla aracı birbirine bağladığımız için boru hattı oluşturmuş oluyoruz. 

## Pipe Kullanım Amacı ve Pipeline Kavramı

Benim örnek için kullandığım araçlar pipe kullanımı için son derece uyumlu çalışabilecek araçlar olduğu için işlem sorunsuzca tamamlandı. Ama tüm araçlar doğrudan pipe ile çalışacak yapıda olmayabilir. Daha fazla ilerlemeden önce bu noktada hatalı pipe kullanımından doğabilecek olası problemleri de kısaca ele alarak pipe yapısını doğru şekilde kavramaya çalışalım.

Veri aktarımında bulunmak istediğimiz araçları peşi sıra pipe çubuğu ile ayırdığımızda "pipeline" olarak geçen birbirine bağımlı bir "boru hattı" oluşturmuş oluyoruz. Bu hattı tıpkı akışkan materyalleri aktaran basit boru hatları gibi düşünebiliriz. Eğer hattın bir noktasında tıkanma ya da kesinti olursa ilgili materyal başlangıç noktasından bitiş noktasına ulaştırılamaz. 

Pipeline üzerindeki işlemler arasında pipe ile veri aktarımı yaptığımız tüm araçlar, hat üzerinde bulundukları konuma göre çıktıları okuma ya da çıktı üretme durumundadır. Aksi halde pipeline olarak geçen aktarım hattı tıkanıp işlem sonlandırılacaktır. Örneğin ilk araç sorunsuzca çıktı üretiyor ancak ikinci araç bu çıktıları okumuyorsa ilk araç tıkanır. Benzer şekilde ilk komut çıktı üretmiyorsa ikinci komut okuma yaparak çalışıyorsa ikinci komut da tıkanarak çalışmaz. Her iki durum da pipeline yani boru hattının tıkanıp çalışmamasına neden olur. Bu sebeple çıktıları üretecek ve çıktıları okuyacak olan işlemlerin birbirine uyumlu şekilde seçilmesi çok önemlidir.  Yani standart çıktıya veri gönderen ve standart çıktıdan veri okuyabilen araçların kullanılması gerekiyor. Her araç standart girdinden veri okuma veya standart çıktıya veri aktarmayı desteklemiyor.

Pipeline yapısını yani peşi sıra birden fazla işlemi paralel olarak çalıştırıp çıktılarını birbirine bağlamayı yalnızca çok katmanlı bir problem çözümü için tercih etmemiz gerekir. Bu yaklaşım Unix felsefesinden geliyor. Unix felsefesi gereği araçlar tek bir işi en iyi şekilde yerine getirmeli ve gerektiğinde girdi alıp okunaklı çıktılar üretebilmelidir. Zaten pipe özelliği, işini çok iyi yapan birden fazla aracı tek bir karmaşık sorunu çözmek üzere ortak olarak kullanabilmemiz içindir. İhtiyaçlarımıza göre, basit işlevleri yerine getiren girdileri okuyan ve çıktılar üretebilen araçların kombinasyonu ile neredeyse tüm ihtiyaçlarımızı karşılayabilen pipeline çözümleri geliştirebiliriz. Pipeline üzerinde yer alan işlemler birbiriyle uyumlu olduğu sürece, paralel olarak çalıştırıldıkları ve veri aktarımı eş zamanlı yapıldığı için son derece hızlı çalışırlar.

Detaylarına değinmeyecek olsak da hazır yeri gelmişken unix felsefesinden de kısaca bahsedebiliriz. Unix felsefesi gereği;

- Tek bir işi en iyi şekilde yapan araçlar geliştirilmelidir. Mevcut araçlara yeni işleri yapabilmesi için özellik ekleyerek karmaşık hale getirmek yerine bu işi yapabilen yeni araçlar geliştirilmelidir.
- Geliştirilen araçlar birbiri ile bağlantılı şekilde çalışabilmelidir. Yani araçlar çıktı üretip, gerektiğinde başka araçların çıktılarını okuyup işleyebilmelidir. Bu sebeple üretilen çıktılar okunaklı biçimde olmalıdır. Gerekmedikçe sütunlu tablolar şeklinde ya da ikili formatta çıktı üretilmemelidir.
- Genel olarak metin akışlarını işleyebilecek yapıda araçlar geliştirilmelidir. Çünkü basit metinsel veriler, evrensel şekilde tüm araçlar tarafından üretilebilen ve girdi olarak alınıp işlenebilen ortak veri biçimidir. Yani veri akışı basit metinler olduğunda evrensel bir iletişim protokolü sağlanabilmiş oluyor.

İşte benim temel olarak değindiğim unix felsefesi bizlere, ihtiyacımıza yönelik son derece esnek ve güçlü araç kombinasyonları oluşturarak kompleks problemlerin dahi nasıl kolayca çözümlenebileceğine dair bir metodoloji sunuyor. Biz uzun uzadıya değinmedik ancak, bahsi geçen unix felsefesinin detaylarını ayrıca araştırmanızı da şiddetle tavsiye ediyorum. Linux sistemlerinde de bu yaklaşımı benimsendiği için kullanması basit ama görevini çok iyi yerine getiren pek çok araç işlevsel araç bulunuyor. Bu araçları birbirine bağlayarak spesifik sorunlara kolayca çözümler üretebiliyoruz. Temel yapıdan bahsettiğimize göre neden tüm araçlarla birlikte pipe kullanamayacağımızdan ve bu duruma nasıl çözüm getirebileceğimizden bahsederek devam edelim.

# xargs Komutu

Pipe yapısından bahsederken çıktı üretme ve üretilen çıktıların okunması noktasında uyumlu araçların tercih edilmesi gerektiğini vurgulamıştık. Bu noktada dikkat edilmesi gereken husus; her aracın önceki aracın çıktılarını alıp kendisine verilen bir argüman gibi işlemeyebileceğidir. Yani her araç standart girdiden okuduklarını argüman olarak kabul etmeyebilir.  Normalde unix felsefesi gereği araçların tek bir iş yapıp onu en iyi şekilde yapması ve kullanıcıları interaktif kullanıma zorlamaması gerekir. Yani hatalı ve hatasız çıktılar üretmesi ve işleyeceği verileri standart girdiden alabiliyor olması gerekiyor. Yine de her araç standart girdiden veri kabul etmeyebiliyor. Bu durum pipe kullanımı ile araçların bağlantılı şekilde çalışmasına engel oluşturur. Çünkü biz pipe yapısını kullandığımızda, ilk aracın standart çıktıları ikinci aracın standart girişine yönlendiriliyor. Eğer ikinci araç standart girdiden veri okumuyorsa bu durumda pipeline tıkanıp çalışmıyor. İşte bu duruma çözüm olarak da xargs isimli aracı kullanabiliyoruz.

`xargs` aracı, standart girdiden okuduğu verileri kendisinden sonraki komutun argümanı olarak iletiyor. Bu sayede standart girdiden veri kabul etmeyen araçlar, tıpkı biz elle o araca argümanlar girmişiz gibi iletilebiliyor. xargs aracının isminin açılımı "e**X**tended **ARG**ument**S**" yani genişletilmiş argümanlardır. Esasen `xargs` aracı pek çok seçeneği bulunan harici bir yardımcı araçtır. Çok fazla seçeneği yani çok fazla özelliği olduğu için ben yalnızca temel özelliklerinden bahsederek olası ihtiyaçlarınız için nasıl çözüm olabileceğine dair fikir vermek istiyorum.

Örneğin silme işlevinde olan `rm` aracı standart girdiden veri okumuyor. Bunun yerine doğrudan argüman verilmesini bekliyor. Ben denemek için bulunduğum konuda yer alan sonu .txt ile biten dosyaları listeliyorum. Bakın tüm metin dosyaları listelendi. Eğer tüm dosyaları kolayca silmek istersem pipe ile dosya isimlerini rm komutuna aktarabilirim. Hemen deneyelim.

```jsx
osboxes@osboxes:~$ ls *.txt | rm
rm: missing operand
Try 'rm --help' for more information.
```

Gördüğünüz gibi komut başarısız oldu. Çünkü rm komutu standart girdiyi okumuyor. Aynı örneğini xargs komutu ile tekrar deneyebiliriz.

```jsx
osboxes@osboxes:~$ ls *.txt | xargs rm
osboxes@osboxes:~$ ls *.txt
ls: cannot access '*.txt': No such file or directory
```

Bakın .txt uzantılı tüm dosyalar kolayca silinmiş oldu. Ben pipe işaretinden sonra xargs komutunu girdiğim için xargs aracı bir önceki araçtan gelen çıktıları okudu ve bunları rm komutuna argüman olarak ekleyip komutun bu şekilde çalıştırılmasını sağladı.

Hatta daha net görmek adına xargs aracını boş şekilde dahi kullanabiliriz. Normalde xargs aracına herhangi bir aracın ismi verilmediğinde echo ile konsola çıktı bastırıyor. Örneğin denemek için mevcut bulunduğumuz konumdaki dosyaları listeleyip, çıktıları pipe ile xargs aracına aktarabiliriz. Ben denemek için ls | xargs şeklinde komutumu giriyorum.

Bakın aldığımız çıktıda, ls aracından gelen çıktıların boşluklarla birbirinden ayrılmış olan argümanlar halinde konsola bastırıldığını görebiliyoruz. İşte biz xargs aracına bu okuduğu çıktıları hangi araca argüman olarak iletmesi gerektiğini belirttiğimizde standart girdinden verileri okumayan yani yalnızca argüman alarak çalışan araçlar bile pipe mekanizmasına dahil edilebiliyor. 

Hatta emin olmak için istersek yalnızca argüman alarak çalışan touch aracını üzerinden de örnek verebiliriz. Bildiğiniz gibi touch aracı sayesinde dilediğimiz isimde yeni dosyalar oluşturabiliyoruz. Fakat söylediğim gibi touch aracı standart girdiden veri okumak yerine yalnızca kendisine argüman olarak verilen ifadeleri dosya ismi olarak kullanıyor. Denemek için echo test1 test2 test3 | touch şeklinde komutumuzu girebiliriz. 

Bakın echo komutu test1 test2 ve test3 ifadelerini pipe ile touch aracının standart girdisine yönlendirmiş olmasına karşın, touch aracı argüman alarak çalıştığı için dosyaları oluşturamadı. Bunun yerine touch komutundan önce xargs komutunu ekleyip tekrar deneyelim.

ls test* komutu ile teyit edecek olursak, bakın test1 test2 ve test3 dosyaları sorunsuzca oluşturulmuş. Buradaki xargs aracı ilk araçtan yani echo aracının çıktılarından gelen ifadeleri pipe sayesinden standart girdiden okudu. Daha sonra bu girdileri aralarında boşluklarla birlikte ayrı ayrı argümanlar olarak touch komutuna ekledi ve aracın bu şekilde çalıştırılmasını sağladı. Neticede touch aracı standart girdiden veri okumuyor olsa da, pipe mekanizmasında xargs aracı ile dahil edilerek kullanılabildi. Çünkü xargs aracı kendi elindeki argümanları touch aracına ekleyip tıpkı bizim konsola komut girdiğimizdeki gibi çalıştırılmasını sağladı. Yani bu girdiğim komut aslında arkaplanda touch test1 test2 test3 komutuna dönüştürülüp çalıştırıldı.

Çalışma mekanizmasının bu şekilde olduğundan emin olmak istersek xargs aracının, komutları çalıştırmadan önce konsola çıktı bastırılmasını sağlayan -t veya —verbose seçeneklerini kullanabiliriz. Ben en son girdiğim komutun ne şekilde ele alındığın görmek istediğim için xargs aracından sonra -t seçeneğini ekliyorum ve komutumu onaylıyorum. Bakın touch komutuna buradaki çıktıların argüman olarak verildiğini görmüş olduk. 

Ayrıca burada dikkatinizi çekmek istediğim nokta, biz -t veya —verbose seçeneğini kullandığımızda yalnızca konsola çıktı bastırılmıyor. Çıktı bastırıldıktan sonra çıktıdaki bu komut çalıştırılıyor. Örneğin bakın ls test* komutu ile listeleme yaptığımızda test dosyalarını görebiliyoruz. Bunları rm test* komutu ile silelim ve en son girdiğimiz komutu tekrar çalıştıralım. Dosyaların varlığını teyit etmek için ls test* şeklinde komutumuzu girebiliriz. Bakın dosyalar tekrar oluşturulmuş. Yani -t veya —verbose seçeneği xargs aracının çalıştıracağı komutu haber verip, ilgili komutun çalıştırılmasını sağlıyor.

Eğer komutlar çalıştırılmadan önce sizden onay alınsın isterseniz -p seçeneğini kullanabilirsiniz. Buradaki p seçeneği “prompt” ifadesinin kısalmasından geliyor. Hatta teyit etmek için xargs —help komutu ile seçenekleri kontrol edebiliriz. Bakın -p veya uzun şekilde —interactive seçeneğinin “prompt before running commands” yani “komutları çalıştırmadan önce sor” özelliğini temsil ettiğini ve buradaki -p seçeneğinin prompt ifadesinin kısalmasından geldiğini görebiliyoruz. İşleme devam edilmeden önce bizim prompt satırımızda bizden onay isteneceği için bu şekilde ifade edilmiş.

Örneğin en son girdiğimiz komutta -t yerine -p seçeneğini yazıp komutumuzu tekrar girelim. Bakın çalıştırılacak komut konsola çıktı olarak bastırıldı ve benden onay bekliyor. Eğer bu komutun çalıştırılmasını istiyorsam “y” yazıp onaylayabilir veya istemiyorsam da “n” yazıp işlemin sonlandırılmasını sağlayabilirim. Ben “n” ile işlemi sonlandırıyorum. 

Açıkçası komut beklediğim gibi çalışmadığı veya komutun sonuçlarından emin olmadığım sürece -t veya -p seçeneklerine pek ihtiyacım olmadı. Ancak ihtiyacım olduğunda seçeneğin kısaltması için yardım bilgisine bakıp ilgili seçenekleri kullanıyorum. Size bu seçenekleri açıklama nedenim; hem xargs aracının çalışma biçimini gözlemleyebilmeniz hem de gerektiğinde bu seçeneklerin varlığından haberdar olup kullanabilmenizdi. 

Çok uzatmak istemiyorum ama xargs aracının tam anlamıyla tıpkı bizim elle yazdığımız gibi komutlar oluşturduğunu ve bu komutları çalıştırıldığını doğru biçimde anlamanız çok önemli.

Basit bir örnek olması için ls aracını kullabiliriz. Normalde ls komutunu kullandığımızda yalnızca mevcut dizindeki dosya ve klasör isimlerinin bastırıldığını biliyoruz. Eğer detaylı bir liste istersek ls aracına -l seçeneğini argüman olarak vermemiz yani komutumuzu ls -l şeklinde girmemiz gerekiyor.

Bakın şimdi daha ayrıntılı bir liste elde ettik. Peki aynı sonucu xargs aracını kullanarak da elde edebilir miyiz ? Hadi deneyelim.

Ben çalıştırılmadan önce komutun son halini görmek ve benden onay alınmasını istediğim için echo “-l” | xargs -p ls şeklinde komutumu giriyorum. Bakın çalıştırılacak komutun ls -l olduğu belirtiliyor. Onaylayıp sonuca bakalım. Bakın tüm dosya ve dizinler detaylı bir biçimde listelenmiş oldu. Çünkü xargs aracı echo dan gelen “-l” ifadesini argüman olarak ls komutunun sonuna ekledi ve komutun bu şekilde çalıştırılmasını sağladı. Örneğin benzer şekilde echo komutunun ardından “/home -l” yazıp tekrar deneyebiliriz. Bakın bu kez de komutumuzun son hali ls /home -l şeklinde oldu çünkü xargs aracı standart girdiden okuduğu tüm verileri sırasıyla kendisinden sonraki aracın argümanı olarak iletti ve komutun son halinin bu şekilde çalışmasını sağladı.

Bu örnek üzerinden gördüğümüz gibi xargs aracının ilettiği argümanlar sıradan metinler olarak değil, doğrudan çalıştırılacak komutun argümanları olarak iletiliyor. Dolayısıyla xargs aracı ile yönlendirdiğiniz argümanların sebep olabileceği sonuçlara dikkat etmeniz şart. Örneğinde farkında olmadan, silmek istemediğiniz dosyaların silinmesi gibi sonuçlarla karşılaşabilirsiniz. 

Ayrıca madem xargs aracı argümanları olduğu gibi iletiyor bu bir güvenlik sorunu oluşturabilir mi diye düşünmüş olabilirsiniz. Yani örneğin ben ls aracına /home ve -l seçenekleri argüman olarak iletmek için echo aracına bu ifadeleri aralarında boşluk bırakarak ilettim. Bunlara ek olarak örneğin ikinci komutu çalıştırmamızı sağlayan “nokalı virgül” karakterini ekleyip ls aracından sonra başka bir komutun çalıştırılması mümkün mü ? Hemen deneyelim. Ben en son komutumu geçmişten tekrar çağırıp, /home -l ifadesinden sonra noktalı virgül ve echo test şeklinde yazıp komutumu onaylıyorum.

Bakın komutun son hali bu şekilde. Görebildiğiniz gibi birden fazla karakteri çalıştırmamızı sağlayacak olan noktalı virgül karakteri tek tırnak içine alınarak asıl işlevinin geçersiz kalması sağlanmış. Emin olmak için komutu onaylayıp sonuçlara bakabiliriz.

Bakın noktalı virgül karakteri özel anlamında değerlendirilemediği için echo test ifadesi de dahil geri kalan tüm ifadeler ls komutuna listelenmesi gereken dosya veya klasör ismi olarak aktarıldı. Bu isimde dosya veya klasör olmadığı için de hata çıktılarını gördük. Komutun hatasız kısmı yani ev dizini listeleyen kısmı ise sorunsuzca bastırıldı. Neticede gördüğünüz gibi xargs komutu olası kötüye kullanımlar için bazı özel karakterleri tek tırnak içine alarak özel anlamalarının kaybolmasını sağlayabiliyor. Yine de özellikle denetimsiz bir kaynaktan okunan verilerin argüman olarak kullanılması noktasında sistem bütünlüğünün güvenliği için dikkatli olmanız gerekiyor. Kasıtlı olark zarar verme amacı dışında genellikle kritik dosyaların silinmesi veya hasar görmesine sebep olabilecek hatalar da yapılabiliyor. Yani xargs aracını kullanırken aracın çalışma biçimini de göz önünde bulundurarak dikkatli biçimde kullanmanızda fayda var. Özellikle emin olmadığınız durumlarda -p seçeneğinin de yardımıyla çalıştırılacak komutları önceden görüp onay verip vermemeye karar vermeniz çok daha sağlıklı bir yaklaşım olacaktır.

Ayrıca hazır xargs aracını kullanırken dikkat etmemiz gerekenlerden bahsediyorsak yeni satır veya diğer bazı özel karakterleri içeren ifadelerin sonundaki karakterlerin sıfır karakter ile yani null karakteri ile değişiminden de bahsetmek istiyorum.

Normalde xargs aracı boşluk yeni satır veya diğer bazı özel karakterleri, ifadeleri birbirinden ayırıp ayrı aryı argüman olarak kullanmak için dikkate alıyor. Bunun yerine dilediğimiz bir karakteri sınırlayıcı yani delimiter olarak tanımlayıp, xargs aracının elindeki verileri bu sınırlayıcı karaktere göre ayrıştırmasını sağlayabiliriz.

Örneğin virgüllerle birbirinden ayrılmış verileri ayrıştırıp birer argüman olarak ele almasını istediğimiz durumda, delimiter yani sınırlayıcı ifadesinin kısaltmasından gelen -d seçeneğinin ardından istediğimiz karakteri belirterebiliriz. Ben örnek olması için öncelikle echo “test1,test2,test3” xargs -t komutu ile yazdığım komutun nasıl ele alındığını görmek istiyorum. 

Bakın aralarında virgül bulunan ifadeler birbirinden ayrılmadan tek bir argüman olarak xargs aracı tarafından ele alınmış. Normalde xargs aracına argümanları ileteceği bir araç ismi girmediğimizde echo aracını kullandığını söylemiştik. İşte buradaki komutta da ilk komuttan gelen ifadeler xargs komutu tarafından echo ile konsola bastırıldı. Şimdi virgül karakterini tırnak içinde sınırlayıcı olarak belirtmek için -d seçeneğinin ardından virgül karakterini de yazalım.

Bakın bu kez virgülle ayrılmış olan her bir ifade ayrı ayrı argüman olarak dikkate alındı. Bu şekilde elinizdeki özel verinin istediğiniz şekilde ayrıştırılıp xargs ile ilgili araca argüman olarak aktarılmasını sağlayabilirsiniz.

[https://www.oreilly.com/library/view/linux-shell-scripting/9781785881985/ee18631c-3b92-4204-8fea-55df0da65868.xhtml](https://www.oreilly.com/library/view/linux-shell-scripting/9781785881985/ee18631c-3b92-4204-8fea-55df0da65868.xhtml)

[https://stackoverflow.com/questions/6958689/running-multiple-commands-with-xargs](https://stackoverflow.com/questions/6958689/running-multiple-commands-with-xargs)

[https://superuser.com/questions/1560582/why-does-xargs-split-on-spaces-even-with-0](https://superuser.com/questions/1560582/why-does-xargs-split-on-spaces-even-with-0)

İşte xargs aracının en temel kullanım şekli ve amacı bu ele aldığımız örneklerdekiler kadar basit. Çoğunlukla bu temel kullanım biçimi işinizi görecek olsa da bence xargs aracının birkaç seçeneğinden de bahsetsek hiç fena olmaz.

Örneğin, xargs aracının tek seferde ileteceği argüman sayısını sınırlayabiliriz. Sınırlandırma işlemi için -n seçeneğini kullanabiliyoruz. Bu kısaltmasının “number” ifadesinden geldiğini düşünürseniz daha kolay aklınızda kalır. Ben denemek için yine en son girdiğim komuta benzer bir komut girmek istiyorum. Ama bu kez yalnızca birer argüman iletilmesini istiyorum. Bunun için komutumu echo test1 test2 test3 test4 | xargs -t -n 1 touch şeklinde giriyorum. Bakın bir argüman sınırı koyduğum için touch araçlarına yalnızca birer argüman iletildi. Yani benim durumumda dört ayrı touch aracına sırasıyla birer argüman verilerek aracın çalıştırılması sağlandı. Sınırlama yapısını daha net görebilmek adına argüman sınırlamasını 1 yerine 2 ye çıkarıp komutumuzu tekrar girebiliriz.

Bakın bu kez touch araçlarına sırasıyla ikişer argüman eklenip bu araçların bu argümanlarla çalışması sağlandı. Teste devam etmek için sayıyı 3 yapalım. 

Bakın bu kez de ilk touch aracına 3 argüman iletilirken ikinci araca yalnızca tek bir argüman kaldığı için bu argüman iletilmiş. 

İşte -n seçeneği ile araca tek seferde iletilecek argümanları sınırlayabiliyoruz. Bu sayede tüm argümanlar bitine kadar araç belirtilen sınırlı argüman sayısı ile tekrar tekrar çalıştırılmış oluyor. Bu seçeneği, özellikle çok sayıda argüman kabul etmeyen araçları elinizdeki tüm argümanları işlemeleri için tekrar tekrar çalıştırmak üzere kullanabilirsiniz. Örneğin x aracı var ve bu araç tek seferde yalnızca tek bir argüman alarak çalışıyor diyelim. Ama siz birden fazla argümanı işlemesini istiyorsanız -n seçeneği ile 1 rakamını belirtip elinizdeki tüm argümanların teker teker bu araçla birlikte çalıştırılmasını sağlayabilirsiniz.

Bu yaklaşıma benzer şekilde dilersek aynı argümanları farklı araçlara da tek seferde iletebiliriz. Yani aslında xargs aracının birden fazla araca aynı argümanları göndermesini sağlayabiliriz. Bunun için değişkenlerden yardım alıyoruz. 

xargs aracının büyük I seçeneği sayesinde belirteceğimiz spesifik bir karakterin, argümanları temsil etmesini sağlayabiliyoruz. Şu an söylediğimden hiç bir şey anlamadıysanız sorun yok. Uygulama üzerinden görmek için hemen basit bir örnek yapalım.

Örneğin yeni klasörler oluşturup bu klasörlerin ayrıntılı listesini konsola bastırmayı deneyebiliriz. 

Ben klasor1 klasor2 ve klasor3 isimli 3 yeni klasör oluşturmak istiyorum. Bunun için yine en kolay şekilde echo komutunun ardından bu klasör isimlerini yazabiliriz. Şimdi pipe işaretinden sonra xargs komutunu girelim ve xargs aracının nasıl bir komut üreteceğini konsol üzerinden görebilmek için -t seçeneği de kullanalım. Tamamdır şimdi tek yapmamız gereken xargs aracının sahip olduğu argümanları bir değişkene tanımlamak. Bunun için büyük I seçeneğini kullandıktan sonra istediğimiz bir ifade veya sembolü kullanabiliriz. Genellikle yüzde işareti kullanıldığı için ilk örneğimizde biz de yüzde işaretini ekleyelim. Şimdi son olarak çalıştırılacak komutları özellikle belirtmemiz gerekiyor. Bunun için en makul yaklaşım bir kabuk çağırıp, kabuk içinde çalıştırılacak birden fazla komutun belirtilmesi ve argümanları tutan buradaki değişkenin de bu uygun yere konumlandırılarak bu araçlara argüman olarak iletilmesi gerekiyor. Bash ya da sh kabuklarından birini çağırabiliriz. Kabuğa doğrudan bir komutu çalıştırmasını söylemek için command ifadesinin kısaltmasından gelen -c seçeneğinin ardından kabuğun çalıştıracağı komutu yazmamız yeterli. Çağırdığımız komutun tüm birden fazla komutu sorunsuzca işleyip çalıştırabilmesi için de bunları kıvırcık parantez içine almamız gerekiyor. Hiç merak etmeyin “işlem yönetimi” bölümünde bu konunun ayrıntıların bahsediyor olacağız. O zaman burada kullandığımız komut gruplama yapısı sizin için tamamen anlaşılır hale gelmiş olacak. O zamana kadar birden fazla komutun tek bir komutmuş gibi ele alındığını düşünebilirsiniz. Bu sayede xargs aracı tek bir komut çalıştırdığını düşünürken biz birden istediğimiz sayıda komutun çalıştırılmasını sağlamış oluyoruz. Yani komutumuzun son hali bu şekilde oluyor.

echo "klasor1 klasor2 klasor3" | xargs -t -I % sh -c '{ mkdir %; ls -l %; }’

Bakın öncelikle mkdir komutu çalıştı ve yüzde işareti olarak tanımladığımız değişken değeri sayesinde ilk echo komutundan gelen çıktıları argüman olarak kullandı. Daha sonra yine echo aracından gelen çıktılar ls -l aracı için de argüman olarak kullanıldı ve spesifik olarak yalnızca bu klasörlerin özellikleri listelendi. İşte bizzat görebildiğimiz gibi büyük ı seçeneğinin ardından belirlediğimiz özel değişkeni argümanların getirilmesini istediğimiz yerlerde rahatça kullanabiliyoruz.

Değişken kullanımı daha net görebilmek adına istersek buradaki yıldız işaret yerine istediğimiz karakterleri kullanabiliriz. Ben ayrıt edici olması için büyük harflerle DEGISKEN şeklinde belirleyip komutumu da buna göre düzenliyorum. 

echo "klasor1 klasor2 klasor3" | xargs -t -I DEGISKEN  sh -c '{ mkdir DEGISKEN ; ls -l DEGISKEN ; }’

Bakın yine aynı çıktıyı aldık çünkü değişkenlerin bulunduğu bölümlere aynı argümanlar iletilerek iki komutun da sırasıyla çalıştırılması sağlanmış oldu.

Ayrıca son olarak xargs aracı kullanılırken yapılan verimsiz bir yaklaşımdan da çok kısaca bahsetmek istiyorum. Ben örnekler sırasında anlaşılır olması için hep ilk olarak echo aracı tarafından üretilen çıktıların xargs aracı ile diğer araçlara argüman olarak iletildiği durumları ele aldım. Ancak bildiğiniz gibi ilk komut herhangi bir araç olabilir. Hatta örneğin cat veya benzeri bir araç ile bir dosyanın içeriğini okuyup çıktıları xargs aracına da yönlendirebiliriz. Ben denemek için cat > oku-beni şeklinde komutumu giriyorum. Şimdi içerisine birbirinden boşluklarla ayırdığımız birkaç ifade ekleyelim ve ctrl d ile dosyayı kaydedip kapatalım. Tamamdır bakın cat komutu ile okuduğumuzda dosyanın tüm içeriği konsola bastırılıyor. Bu çıktıları yine aynı şekilde pipe yardımıyla xargs aracına aktarıp oradan da diğer araçların bu çıktıları argüman olarak kullanmasını sağlayabiliriz. 

Ben çok basit bir örnek olması için cat komutu ile okuduğum çıktıları ilk olarak doğrudan xargs aracına yönlendirmek istiyorum. Bildiğiniz gibi xargs aracına çalıştıracağı bir araç ismi verilmediğinde okuduğu çıktıları echo aracına argüman olarak iletip konsola bastırılmalarını sağlıyor. Hatta daha net görebilmek için xargs aracına -t seçeneğini de ekleyebiliriz.

Bakın cat komutu ile okunup çıktıları pipe ile xargs aracına aktarılan tüm ifadeler xargs tarafından echo aracına argüman olarak verildi. Yani aslında dosya içeriğini bir başka aracın argümanları olarak iletmeyi başardık. Genellikle dosya içerikleri argüman olarak kullanılmak istendiğinde bu yaklaşım sık tercih ediliyor ancak her zaman bu yaklaşıma ihtiyacımız yok. Pipe mekanizması ve cat gibi bir aracın yardımı olmadan da doğrudan xargs aracının dosya okuma özelliğini veya yönlendirme operatörünü kullanarak dosya içeriklerinin argüman olarak kullanılmasını sağlayabiliriz.

Bildiğiniz gibi yönlendirme operatörlerini kullanarak istediğimiz bir aracın standart girdisine veri gönderebiliyoruz. Bunun için küçüktür yönlendirme operatörünü kullanabiliriz. 

Yani komutumu xargs -t <oku-beni şeklinde girerek de aynı sonucu elde edebilirim. Bakın birebir aynı çıktıyı aldık. Hatta dilerseniz touch komutu ile dosya içinde boşluklara ayrılmış ifadelerin dosya isimleri olarak kullanılmasını da sağlayabiliriz. Bunun için xargs -t touch <oku-beni şeklinde komutumuzu girelim. Dosyaları teyit etmek için ls komutunu da girelim. Gördüğünüz gibi dosya içerisindeki ifadeler ile aynı isimleri taşıyan dosyalar eksiksiz olarak oluşturulmuş. Yani cat gibi bir araç ve pipe olmadan da xargs aracına dosyadan veri aktarabildik. Çünkü zaten standart girdi standart çıktı ve yönlendirme gibi kavramların bilincindeyiz. xargs aracı da standart girdiden okuduklarını argüman olarak kullanan bir araç olduğu için tek yaptığımız bu aracın standart girdisine istediğimiz dosyayı yönlendirmek oldu.

Ayrıca daha önce de söylediğim gibi xargs aracının bu iş için bir seçeneği de bulunuyor. Hemen görmek için xargs —help komutunu girip yardım bilgisine göz atalım. Bakın burada -a seçeneği sayesinde bir dosyadan argümanların alınabileceği belirtilmiş. Ben bu kez denemek için dosyadan okunan ifadeler ile oluşturulan dosyaların bu kez aynı şekilde dosyadan okunan bilginin argüman olarak kullanılarak silinmesini istiyorum. Bunun için xargs -t -a oku-beni rm şeklinde komutumu yazıyorum. Bakın buradaki -a seçeneğinin ardından belirttiğim dosya okunacak ve içindeki ifadeler buradaki rm aracına argüman olarak iletilerek bu dosyaların silinmesi sağlayanacak. Hemen komutumuzu onaylayalım. Tamamdır bakın tam da beklediğimiz şekilde komutun çalıştığınız -t seçeneği sayesinde konsolda da çıktı olarak görmüş olduk. Şimdi ls komutu ile mevcut dizinimizi de listeleyelim. Bakın bir önceki çıktıda gördüğümüz dosyalar artık burada bulunmuyor çünkü hepsinin ismi dosyadan okunarak rm aracına argüman olarak verildi ve silindirler.

İşte basit örneklerimiz üzerinden de bizzat gördüğümüz gibi eğer yalnızca bir dosyadan veriler okunup başka araçlara argüman olarak iletilecekse yani pipeline gerektirecek çok katmanlı işlemler yoksa, cat gibi araçlara ihtiyaç duymadan doğrudan dosyanın içeriğini okuyabiliyoruz. Tabii günlük kullanımda cat gibi bir araç ile dosyayı okuyup pipe ile xargs aracına yönlendirmek size daha kolay geliyorsa bu kullanımda da çok büyük bir sorun yok. Fakat yine de gereksiz yere işlemi uzatmak yerine yönlendirme bilginize başvurmanız çok daha efektif bir yaklaşım olacaktır.

Neticede tüm detaylarından olmasa da temelde xargs aracı hakkında bilmemiz gereken tüm özelliklerden kabaca bahsetmiş olduk. Bahsi geçen özellikleri kavramak için kendiniz de bol bol pratik yapın lütfen. Ayrıca geri kalan seçenekleri de elbette manual sayfalarından veya xargs —help komutu aracılığıyla yardım sayfalarından öğrenip uygulayabilirsiniz. Ben bir sonraki derse en az pipe mekanizması kadar önemli olan tee aracından bahsederek devam ediyor olacağım.

[https://linuxize.com/post/linux-xargs-command/#disqus_thread](https://linuxize.com/post/linux-xargs-command/#disqus_thread)

# tee Komutu

Standart pipe yani boru yapısı tek yönlü akış için tasarlanmıştır. Örneğin hem bir sonraki işleme hem de bir dosyaya aynı anda yönlendirme yapamıyoruz. Bu duruma çözüm olarak da tee isimli aracı kullanmamız gerekiyor. Pipe mekanizmasını düz boru olarak düşünecek olursak buradaki tee aracı da bildiğiniz t boru görevi görüyor. İlk işlemden aldığı çıktıyı okuyor, istenilen dosyaya ve aynı zamanda bir sonraki işlemin standart girdisine yönlendiriyor.

Ben denemek için ls /etc/ komutu ile etc dizini altındaki dosyaları listeliyorum. Bu komut neticesinde pek çok dosya ve dizin listelendi. Eğer yalnızca ilk 10 satırı listelemek istersem pipe ile verileri head komutuna aktarabilirim. Buradaki head aracı, aldığı verilerin yalnızca ilk 10 satını çıktı olarak iletildiği için kullandık. İleride bu araçtan ayrıca bahsediyor olacağız. Şimdi komutumuzu girip deneyelim.

Bakın yalnızca ilk 10 içerik listelenmiş oldu. Ben ls komutunun tüm çıktılarının bir dosyaya kaydedilmesini hem de head komutu ile ilk 10 satırını okumak istiyor da olabilirim. Bunun için tee komutunu kullanabilirim. Komutumu ls /etc/ | tee liste.txt | head şeklinde yazıyorum. Bu komut sayesinde ilk olarak ls aracı /etc dizini altındaki tüm içeriği listeleyip pipe ile tee aracına aktaracak. tee aracı da aldığı çıktıyı buradaki “liste.txt” isimlide dosyaya kaydedecek ve ayrıca aynı verileri head aracına pipe ile yönlendirecek. Head aracı da aldığı verilerden yalnızca ilk 10 satırı konsola çıktı olarak bastıracak. Komutumuzu onaylayalım. 

Bakın ilk 10 satır konsola basılmış oldu. Şimdi liste dosyasının içeriğine bakalım. Gördüğünüz gibi ls komutunun tüm çıktıları da bu listeye kaydedilmiş. Yani tee komutu ls komutunun  çıktılarını hem dosyaya hem de bir sonraki işlem olan head işlemine iletmiş oldu. Burada fark ettiyseniz tee aracı kendisine verilen tüm verileri hem dosyaya hem de bir sonraki araca eksiksiz şekilde iletiyor. İşte tee komutu pipeline üzerinde bu amaçla sıklıkla kullanılıyor. 

Hatta istersek dosya isimlerini yan yana yazarak birden fazla dosyaya yazılmasını da sağlayabiliriz. Ben denemek için aynı komutu çağırıp, bir dosya ismi daha belirtiyorum ve komutumu bu şekilde onaylıyorum. Şimdi paste komutu ile her iki dosyayı da yan yana bastırabiliriz. Bakın iki dosyaya da aynı veri kaydolmakla birlikte head aracına da bu çıktılar aktarıldığı için konsola ilk 10 satır bastırıldı.

Ayrıca örneğin çıktıların hem konsola hem de dosyaya yazdırılmasını istersek de tee komutunu kullanabiliriz. Normalde eğer bir komutun çıktısını bir dosyaya yönlendirirsek konsola bir çıktı basılmaz. Hemen teyit etmek için ls > liste şeklinde komutumuzu girelim. Bakın ls komutunun çıktısı konsola basılmadı çünkü ls komutunun çıktıları belirttiğim dosyaya yönlendirildi. cat komutu ile de bu durumu teyit edebiliriz.

Şimdi aynı örneği tee komutunu ile tekrarlayalım. ls | tee ls-dosyasi şeklinde komutumu giriyorum. Bakın konsola çıktılar basılmış oldu. Hemen dosyanın içeriğini de kontrol edelim. Bakın ls komutunun çıktıları konsola bastırılmakla birlikte dosyaya da kaydedilmiş. Eğer ben tee aracından sonra bir pipe daha kullanıp bir araç ismi yazsaydım tee aracının elindeki veriler bu araca yönlendirilecekti. Fakat tee aracından sonra bir araç ismi girmediğim için tee aracı elindeki verileri dosyaya yazmasının yanı sıra standart çıktı adresi olan konsola da bastırmış oldu.

tee aracının kullanımı gördüğünüz gibi son derece kolay olduğu için daha fazla örneğe gerek yok. Yine de son olarak birkaç kullanım detayını daha bilmenizde fayda var. Normalde tee komutu aynı isimde bir dosya varsa onun üzerine yazar. Yani o dosyanın içeriğini yok edip, elindeki verileri o dosyaya yazar. Eğer aynı isimli dosya varsa dosya içeriğinin sonuna yeni verilerin eklenmesini istersek append yani ekleme ifadesinin kısalması olan -a seçeneğini kullanabiliriz.

Ben denemek için echo "deneme" | tee deneme.txt komutunu giriyorum. deneme.txt dosyasını okuduğumuzda içeriğin eklendiğini teyit edebiliyoruz. 

Şimdi aynı dosyaya bu kez farklı veri göndermek için echo “test” | tee deneme.txt şeklinde aynı dosyanın ismini de yazıp komutumuzu girelim. Bakın tee aracı bir önceki araç olan echo aracından aldığı test ifadesini konsola bastırdı. Aynı zamanda tabii ki deneme.txt dosyasına da bu ifadeyi yönlendirdi. Teyit etmek için cat komutu ile deneme.txt dosyasını da okuyalım. 

Bakın dosyanın eski içeriği silinip tee aracının en son yönlendirdiği veri eklenmiş. Bizzat gördüğümüz gibi tee aracına özellikle belirtmediğimiz sürece tıpkı tek yönlendirme operatörü kullandığımızdaki gibi hedefteki dosyanın içeriğinin üzerine yazılıyor.

Ben verileri dosyanın sonuna eklemek istediğim için append yani ekleme ifadesinin kısalatmasından gelen -a seçeneği ile komutumu tekrar girmek istiyorum. Bu kez tee aracına test2 verisini yönlendireceğim. Bakın tee aracın echo aracından test2 ifadesini aldığı için bunu konsola bastırdı. Ayrıca -a seçeneğini de eklediğimiz için bu veriyi deneme.txt dosyasının sonuna eklemiş olması gerekiyor. Hemen cat komutu ile deneme.txt dosyasının içeriğine bakalım. Bakın tam da istediğimiz gibi  a seçeneği sayesinde dosya içeriğine ekleme yapıldığını görebiliyoruz. Kısacası tıpkı yönlendirme operatörlerinde bir dosyanın sonuna yeni veri eklemek için çift operatör kullandığımız gibi tee komutu için de a seçeneğini kullanmamız gerekiyor. Aksi halde tee aracı aynı isimli dosyanın üzerine yeni verileri yazıp eskilerini yok ediyor.

Son olarak hazır tee komutundan bahsetmişken pratik bir kullanımından da bahsetmek istiyorum. Diyelim kim yetkimiz olmayan bir dosyaya örneğin /etc/passwd dosyasına ekleme yapmak istiyoruz. 

Normalde yetki gerektiren bir görevi yerine getirmek için komutumuzun en başına sudo ifadesini yazıp eğer yetkimiz uygunsa çalıştırabiliyoruz. Yani örneğin normalde /etc/passwd dosyasını düzenlemek için yetkimiz yok fakat en yetkili kullanıcı gibi davranmak için komutumuzun başına sudo yazı işlemi yerine getirmeyi deneyebiliriz.

Yani örneğin sudo echo "eklenecek veri" >> /etc/passwd şeklinde komutumuzu girebiliriz. Ancak gördüğünüz gibi yetki hatası aldık. Halbuki ileri de ayrıca ele alacağımız sudo komutu bizim yetkili şekilde bu dosyaya veri ekleyebilmemizi sağlamalıydı. Burada sudo komutu işe yaramadı çünkü yönlendirmeler üzerinde sudo komutunun etkisi bulunmuyor. Sudo komutunu kullansak dahi yönlendirme operatörü ile ilgili dosyaya veri yazma yetkisi kazanamayız. Bunun yerine tee komutunu sudo ile yetkili şekilde çalıştırabiliriz. Hadi hemen deneyelim. Ben echo "yeni satır" | sudo tee -a /etc/passwd şeklinde komutumu giriyorum. Buradaki a seçeneğini unutmayın aksi halde bu çok önemli dosyasının tüm içeriğinin silinmesine neden olabilirsiniz. Ben yetkili olduğumu kanıtlamak için parolamı girip onaylıyorum. Ve gördüğünüz gibi herhangi bir yetki hatası almadım. cat komutuyla dosya içeriğini görüntüleyerek de içeriğin eklendiğini teyit edebiliyorum. Bakın dosyanın en sonuna yeni satır ifadesi eklenmiş.

Böylelikle yönlendirme operatörlerinin sudo ile yetki kazanamadığından ve alternatif olarak tee komutu sayesinde yetkili şekilde dosya içeriğine veri ekleyebileceğimizden de haberdar olduk. Tee aracını ele aldığımız örnekleri de dikkate aldığımızda tıpkı T boru gibi düşünmek bence oldukça mantıklı. Konsol üzerinde hem standart çıktıya hem de bir dosyaya yönlendirme yapmak istediğinizde veya bir yönlendirme işlemini yetkili şekilde yapmak istediğinizde tee aracını kullanabilirsiniz.

# tr Komutu

tr komutu translate yani "çevirmek-dönüştürmek" ifadesinden geliyor. Görevi, karakterleri değiştirmek ya da silmektir. Küçük ve büyük harf değişimi, tekrar eden karakterlerin silinmesi, özel karakterlerin silinmesi ve bulup değiştirme gibi işlevler için tr aracını kullanabiliyoruz.

tr komutu standart girdiden veri okuduğu için pipe ile veri aktarmak en sık tercih edilen kullanım yöntemidir. Ben kolay bir örnek olması için küçük i ve küçük e karakterlerini büyükleri ile değiştirmek üzere echo "linux dersleri" | tr "ie" "IE" şeklinde komutumu giriyorum. Yani ilk argüman olarak değiştirilecek karakterleri sırasıyla belirtirken, ikinci argümana da ilk argümandaki karakterlerin yerine hangilerinin geçeceğini sırasıyla belirtiyoruz. Burada girmiş olduğum argümanların sıralaması çok önemli. Çünkü tr komutu sıralamaya uyarak yani ilk argümanın ilk karakterini, ikinci argümanın ilk karakteri ile ve ilk argümanın ikinci karakterini de ikinci argümanın ikinci karakteri ile değişecek şekilde işlem yapıyor. 

Bakın aldığım çıktı, belirttiğim sırlamaya uyuyor. Şimdi sırlamayı değiştirip deneyelim. 

Bakın bu çıktı da komutta belirttiğim sırlama dahilinde yani küçük i için büyük E küçük e için de büyük I karakteri şeklinde oldu.

Örneğin tüm küçük harfleri büyük harflere dönüştürmek istersek aralık belirterek komut girebiliriz. Hemen deneyelim. Ben tekrar echo "linux dersleri" | tr komutunu giriyorum, şimdi tüm küçük harfli karakterleri kast etmek için a-z yazıyorum. Burada yazdığım a-z argümanı a dan z ye kadar demek oluyor. Yerine geçecek karakterler için de yani ikinci argüman olarak da büyük şekilde A-Z yazıyorum. Böylelikle tüm küçük karakterler büyükleri ile eşleşip değiştirilecek.

Bakın tüm karakterler büyükleri ile otomatik olarak yer değiştirdi.

Ayrıca kullanabileceğimiz bazı özel kalıplar da bulunuyor. Bunları görmek için tr —help komutunu kullanabiliriz. Gördüğünüz gibi kullanabileceğimiz çeşitli özel karakterler yardım bilgisinde belirtilmiş. Örneğin bakın buradaki lower kalıbı küçük harfli olan tüm karakterleri kapsıyor, benzer şekilde upper da tüm büyük harfleri kapsıyor. Denemek için gelin bu kalıpları kullanarak küçük harfleri büyüğe dönüştürelim.

echo "Linux Dersleri" | tr [:lower:] [:upper:] şeklinde komutumu giriyorum. 

Gördüğünüz gibi tüm küçük harfli karakterler büyük harfler ile değiştirilmiş oldu. Elbette istersek tersi şekilde komut girerek, büyük harflerin küçük harfler ile değiştirilmesini de sağlayabiliriz. Bakın tüm karakterler değişmiş oldu. Sizler de bu listeye göz atıp, ihtiyacınız olan kalıpları kolayca kullanabilirsiniz. 

Bir örnek daha yapalım ben PATH değişkenin çıktıların yer alan iki nokta karakterini yeni satır karakteri ile değiştirmek istiyorum. Öncelikle echo $PATH komutu ile değişkeni konsola bastıralım.

```bash
taylan@virtualbox:~/arsiv$ echo $PATH
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
```

Bakın PATH yoluna ekli olan her bir dizin birbirinden iki nokta üst üste karakteri ayrılmış. Şimdi bu çıktı bana biraz karışık geldiği için her bir path dizinini yeni bir satırda görmek istiyorum. Bunu yapmak için iki nokta üst üste karakterini yeni satır karakteri ile yani bakın buradaki listede de görülen \n karakteri ile değiştirebiliriz. Hemen deneyelim. Ben komutumu echo $PATH | tr “:” “\n” şeklinde giriyorum.

```bash
taylan@virtualbox:~/arsiv$ echo $PATH | tr ":" "\n"
/usr/local/sbin
/usr/local/bin
/usr/sbin
/usr/bin
/sbin
/bin
/usr/games
/usr/local/games
/snap/bin
```

Bakın, her bir path dizinini ayrı ayrı satırlarda bastırmayı başardık. Bu şekilde tam istediğim gibi daha okunaklı bir çıktı elde etmiş oldum. Bence bu yaptığımız örnek, tr aracının kullanımına ve ayrıca yeni satıra geçilmesini sağlayan \n gibi kalıplara da iyi bir örnek oldu.

Buradaki kalıplar üzerinde pratik yaptığınız zaman zaten isimleri dolayısı ile kolayca hatırlayabilirsiniz. Ayrıca hatırlamadığınız durumda elbette bu şekilde yardım sayfası üzerinden de tekrar öğrenebilirsiniz. Zaten hatırlarsanız burada ters slash ile belirtilen karakterler echo komutunda da geçerliydi. Yani pek çok araç zaten benzer standardı izlediği için zaman içinde bu tür kalıplar aklınızda yer edecektir.

Bu ifadeler dışında biraz da seçeneklerinden bahsedebiliriz.

### Peş Peşe Tekrar Eden Karakterlerin Sadeleştirilmesi

Eğer peş peşe tekrar eden karakterlerden yalnızca bir tane kalmasını istersek, -s seçeneğini kullanabiliriz. Buradaki s seçeneği squeeze yani sıkmak, sıkıştırmaktan aklınıza gelebilir. Ben denemek için "echo "www.deneme...com" şeklinde yazıyorum. Eğer buradaki noktaları silmek istersem, tr -s "." şeklinde komut girmem yeterli. Bakın peş peşe tekrar eden noktalar yerine yalnızca 1 tane nokta basıldı. Benzer şekilde eğer tekrar eden w karakterinin de tek bir tane olacak şekilde değiştirilmesini istersem, ekleyebilirim. Bakın w karakteri de teke düşürüldü.

Hatta istersem bastırılabilir olan tüm tekrar eden karakterlerin otomatik olarak filtrelenmesini de sağlayabilirim. Bunun için tekrar tr komutunun yardım sayfasına göz atıyorum. Bakın [:graph:] seçeneği bastırılabilir tüm karakterler için kullanılabiliyormuş. Deneyelim. Ben komutumu echo "www.deneme...com" | tr -s [:graph:] şeklinde giriyorum.

Gördüğünüz gibi peş peşe tekrar eden tüm karakterler teke düşürülmüş oldu. Dikkat ettiyseniz peş peşe tekrar etmesi önemli, nitekim buradaki deneme ifadesinde “e” karakteri üç kez geçmesine rağmen bu karakterler aynen kaldı çünkü peşi sıra tekrar etmiyorlardı. Benzer şekilde burada tekrar eden sayılar olsaydı da aynı şey geçeli olacaktı. Deneme için echo komutunun sonuna 1111 şeklinde ekleyip, komutumuzu tekrar çalıştırabiliriz. Bakın tekrar eden rakamlar da dahil tüm tekrar eden karakterler -s seçeneğine verdiğimiz [:graph:] kalıbı sayesinde teke düşürülmüş oldu.

Yani bu örnek üzerinden de gördüğümüz gibi aslında spesifik olarak belirtmemiz gereken karakterler yoksa, tr —help komutunun çıktısında yer alan ifadeler ve kalıplar zaten pek çok tanımı karşılıyor. Örneğin tekrar eden sayıları mı düzenlemek istiyorsunuz, bakın digit ifadesini kullanılabilir. Hemen komutumuzdaki graph kalıbı yerine digit kalıbını ekleyip tekrar girelim.

Bakın diget kalıbı sayesinde yalnızca peş peşe tekrar eden sayılar teke indirilmiş oldu.

İşte sizler de gerektiğinde yardım sayfasından göz atıp, bu ifadeleri kolayca kullanabilirsiniz. 

Her neyse, neticede s seçeneğinin art arda tekrar eden karakterleri teke düşürdüğünü teyit etmiş olduk. 

### Karakterlerin Silinmesi

Ayrıca tr aracını her zaman tekrar eden karakterleri sadeleştirmek veya mevcut bir karakteri bir diğeri ile değiştirmek için kullanmak istemeyebiliriz. Doğrudan karakteri bulup silmek için de tr aracını kullanmamız mümkün. Bunun için delete yani silme ifadesinin kısaltması olan d seçeneğini kullanabiliyoruz. Ben denemek için web adresindeki noktaları silmek istiyorum. Tek yapmam gereken tr aracının -d seçeneğini kullandıktan sonra silinmesini istediğim karakteri belirtmek.

```bash
taylan@virtualbox:~/arsiv$ echo "www.deneme...com" | tr -d "."
wwwdenemecom
```

Gördüğünüz gibi tüm noktalar silindi. Bu şekilde metin içinde silinmesini istediğiniz tüm karakterleri belirtebilirsiniz. Fakat yalnızca tek bir karakteri işaret ettiğinizi unutmayın lütfen. Yani örneğin ben aynı komutta -d seçeneğinden sonra “we” yazarsam, “w” ve “e” karakterinin hepsi bulunup silinecek. Komutumuzu onaylayalım. 

```bash
taylan@virtualbox:~/arsiv$ echo "www.deneme...com" | tr -d "we"
.dnm...com
```

Bakın yazdığım tüm karakterler ayrı ayrı ele alındı ve eşleşen karakterler kaldırıldı. Yani doğrudan “we” ifadesini aranmadı, w ve e karakterleri ayrı ayrı aranıp bulunduğunda teker teker silindiler. tr aracının yalnızca birer karakter üzerinde çalıştığını şimdiye kadarki örneklerimiz üzerinde de tekrar tekrar gördük zaten. Yine de tr aracının bu şekilde çalıştığına dikkatinizi çekmek istediğim için ek olarak belirtmek istedim. Eğer bitişik yapıdaki birden fazla karakteri kapsayacak değişiklikler istiyorsanız ileride ele alacağımız sed veya awk gibi araçlardan yararlanabilirsiniz. tr aracı yalnızca bir karakter ile başka bir tanesini değiştirme silme veya tekrar edenleri sadeleştirmek gibi işler için kullanılıyor.

Ayrıca son olarak, biz tr aracının kullanım örneklerinde verileri hep pipe üzerinden tr aracına yönlendirdik. İstersek yönlendirme operatörü ile de tr aracının standart girdisine veri aktarabiliriz. Ben denemek için site isimli bir dosya oluşturuyorum, dosyanın içine de daha önceki gibi web adresini fazladan nokta ekleyerek kaydediyorum.

Ben peş peşe tekrar eden karakterlerin tr komutu ile teke düşürülmesi için yönlendirme operatörü ile dosyayı tr komutuna aktaracağım. Bunun için tr -s [:graph:] komutundan sonra tr aracının standart girdisine veri iletmek için < site şeklinde dosyasının ismini giriyorum.

```jsx
bubirosboxes@osboxes:~$ cat > site
www.deneme...com
osboxes@osboxes:~$ tr -s [:graph:] < site 
w.deneme.com
```

Gördüğünüz gibi dosyadaki veri tr komutu tarafından okunup, filtrelenmiş oldu. Yani bizzat teyit ettiğimiz gibi tr komutunu yalnızca pipe ile kullanmak zorunda değiliz. tr aracı verilerini standart girdiden okuyor. Dolayısıyla standart girdisine verileri yönlendirdiğiniz sürece tr aracı ilgili verileri işleyip çıktıları standart çıktıya yani çoğu durumda konsola yönlendiriyor olacak.

Eğer bu çıktıları bir dosyaya kaydetmek istersek örneğin aynı komutun sonuna > kaydet  şeklinde yazabiliriz. Şimdi cat ile kaydet dosyasını okuyalım. Bakın tr aracı tarafından işlenmiş çıktıları sorunsuzca dosyaya yönlendirmiş olduk.

tr aracı hakkında bahsetmek istediklerim bu kadar. Aslında iki tr aracının -c ve -t kısaltmaları ile temsil edilen iki seçeneği daha bulunuyor ancak ben bu seçeneklerin işlevlerini öğrenmeyi size bırakıyorum.

# grep Komutu | egrep fgrep

grep aracı muhtemelen en sık kullanacağınız komut satırı araçlarının başında geliyor. En temel şekilde tanımlayacak olursak grep aracının görevi filtreleme yapmak. Söz konusu filtreleme işlemi olduğu için de aslında grep aracı ilk başta göründüğünden çok daha kapsamlı ve güçlü bir araç.

Üstelik grep aracı hem standart girdiden hem de kendisine argüman olarak verilmiş olan dosyadan veri okuyup filtreleyebiliyor. En temel kullanımı bir dosya ve standart girdiden okunan veri kümesi için spesifik bir kelimeyi araştırmak.

Ben denemek için /etc/passwd dosyasında kaç kez bash ifadesinin geçtiğini öğrenmek üzere grep komutundan sonra araştırmak istediğim kelimeyi ve daha sonra da hangi dosyada araştırılacağını grep bash /etc/passwd şeklinde giriyorum.

Bakın içerisinde bash ifadesi bulunan tüm satırlar listelendi. Benzer şekilde standart girdiden alınan veriler de grep tarafından işlendiği için komutumuzu cat /etc/passwd | grep bash şeklinde de girebilirdik. 

Aynı sonucu elde ettik çünkü cat aracı passwd dosyasının içeriğini pipe ile grep aracına aktardı, grep de benim istediğim doğrultusunda içinde bash ifadesi geçen satıları filtreleyip standart çıktıya yönlendirdi. İşte grep aracının en temel kullanımı bu şekilde.

## Ters Arama

Aradığımız kelime ile eşleşen verileri nasıl filtreleyebileceğimizi ele aldık. Eğer tersi şekilde aradığımız ifadenin geçmediği bölümleri istersek bulun için grep aracının hariç tutma özelliğini kullanabiliriz. Hariç tutma özelliğini kullanmak için de kısaca -v seçeneğini kullanabiliyoruz.  

Yani örneğin ben passwd dosyasının içinde bash ifadesinin geçmediği satırları listelemek istersem grep -v bash /etc/passwd şeklinde komutumu girebilirim. 

Bakın bash ifadesinin geçtiği satırlar hariç tüm içerikler konsola bastırıldı.

 Ben yalnızca tek bir dosya üzerinde filtreleme yaptım ancak istersek birden fazla dosyanın tüm içeriğinde de filtreleme yapabiliriz. Ben denemek için etc passwd ve etc group dosya içeriklerinde “root” ifadesinin aranmasını istiyorum. Bunun için grep “root” /etc/passwd /etc/group şeklinde komutumu giriyorum. 

Bakın eşleşmiş olan satırlar hangi dosyada bulundukları da belirtilerek filtrelenmiş. Yani gördüğünüz gibi istersek aynı anda çoklu şekilde dosyalar üzerinde de çalışabiliyoruz. Çoklu dosyalarla çalışmanın yanında dilersek alt dizinlerdekiler de dahil bir dizin içindeki tüm içeriklerin grep aracı tarafından filtrelenmesini sağlayabiliriz. Bunun için özyineleme yani recursive seçeneğinin kısalması olan -r seçeneğini kullanabiliyoruz.

## Özyinelemeli Araştırma

Ben kendi ev dizinimde, içinde “test” ifadesi geçen tüm dosyaların filtrelenmesini istiyorum. Bunun için grep -r “test” /home/taylan şeklinde komutumu giriyorum. Buradaki -r seçeneği benim hedef gösterdiğim bu dizinden başlayıp tüm alt dizinler de dahil olmak üzere tüm dosyalarda “test” ifadesinin geçtiği yerleri filtreleyip bana sunacak. Komutu onaylayalım.

Bakın sırasıyla tüm dizinlerde geziniliyor ve test ifadesi eşleşen satırlar ilgili dosyanın ismi de başta olacak şekilde bize sunuluyor. Tabii ki grep aracı satırları filtrelediği için arasında boşluk bulunmayan uzun satır içerikleri de uzun uzadıya bastırılmış oldu. Yine de neticede filtreleme işlevi istediğimiz şekilde tüm alt dizinleri de kapsayacak şekilde çalışmış oldu.

Yalnızca ilgili satırın çıktısını almak ?

Birden fazla kelimeyi filtrelemek ?

1. Use single quotes in the pattern:
    
    grep 'pattern*' file1 file2
    
2. Next use extended regular expressions:
    
    egrep 'pattern1|pattern2' *.py
    
3. Finally, try on older Unix shells/oses:
    
    grep -e pattern1 -e pattern2 *.pl
    
4. Another option to grep two strings:
    
    grep 'word1**\|**word2' input
    

[https://www.cyberciti.biz/faq/searching-multiple-words-string-using-grep/](https://www.cyberciti.biz/faq/searching-multiple-words-string-using-grep/)

Örneğin bir dizindeki tüm dosyaların içinde geçen spesifik bir kelimeyi araştırıken grep — “kelime” şeklinde komutumuzu kullanabiliriz. 

aslında çoğu durumda cat komutunu kullanmamız da gerekmeyebilir. çünkü çoğu araca parametre olarak dosya ismi verebiliyoruz. 

örneğin:

cat dosya-adı | grep “bulunacak kelim”

komutu yerine doğrudan aşağıdaki komutu da kullanabiliriz.

grep “bulunacak kelime” dosya-adı

Cat aracı, dosya isimlerini parametre olarak kabul etmeyen araçlara argüman olarak göndermek için kullanılabilir. Bunun dışında doğrudan ilgili araç dosyaları açıp işleyebiliyorsa o araca parametre olarak bu dosyayı vermek çok daha mantıklı olur.

# find Komutu

find aracı, açıkça isminde de anlaşılabileceği gibi sistem üzerindeki dosya ve klasörleri arayıp, konumlarını bulmamıza yardımcı olan bir araçtır. En yalın kullanımı find komutundan sonra hangi dizinde araştırıma yapılacağını belirtip daha sonra -name seçeneğinin ardından araştırılacak olan dosya ya da klasör isminin girilmesi şeklindedir. 

Ben denemek için öncelikle Documents klasörünün içine bulbeni isimli bir dosya oluşturuyorum. Şimdi bir de Pictures içine bulbeni isimli yeni bir klasor de oluşturuyorum. find komutumuzu bu dosya ve klasörleri bulmak için kullanabiliriz. Ben şu an ev dizinimdeyim, bulunduğum dizinden itibaren tüm alt dizinlere bakılıp aradığım kelime ile eşleşen dosya ya da klasör ismi var mı diye bakmak için find ./ yazıyorum burada ./ bulunduğum dizini temsil ediyor. Yani find komutuna benim bulunduğum dizinin altına bak demiş oluyorum. Kelime ile eşleşen dosya ve klasörleri bulmak için de -name seçeneğinin ardından aradığım kelimeyi giriyorum.

Bakın isimle eşleşen hem klasör hem de dosya konumlarıyla birlikte listelenmiş oldu.

Bu find komutunun en yalın hali. Elbette araştırma yapılırken filtreleme yapılabilmesi için aranacak dosya veya klasörün özelliklerine göre kullanabileceğimiz birden fazla seçenekler bulunuyor. Hemen kısaca bunlardan söz edelim.

Yalnızca dosyaları filtrelemek istiyorsak type seçeneğinin ardından f yazmalıyız. Buradaki f file yani dosya ifadesinin kısaltmasıdır. Eğer klasörleri filtrelemek istersek de directory yani klasör ifadesinin kısaltması olan d ifadesini kullanabiliyoruz. Hemen örneğimiz üzerinden deneyelim. Öncelikle yalnızca benibul isimli dosyayı araştırıyorum. Bakın burada aldığımız çıktı yalnızca dosyanın konumunu veriyor. ls komutu ile de teyit edebiliriz. Benzer şekilde yalnızca klasörü bulmak için d seçeneği ile araştırma yapabiliriz. Bu çıktı da klasörün konumuna işaret ediyor. 

Tip seçeneğini belirtmek dışında dilersek, boyutuna göre araştırma da yapabiliriz. Örneğin bulunduğumuz dizin altındaki 1 megabayttan büyük olan dosyaları getirmek için find ./ -type f -size +1M şeklinde komutumuzu kullanabiliriz. Boyutu farklı girmek isterseniz bayt için b kilobayt için k megabayt için büyük M ve gigabayt için büyük G kullanmalısınız. Buradaki artı işareti büyük dosyaları kapsaması için var. Eğer 1 megabayttan küçük olan dosyaları görmek istersek de eksi işareti ile komutumuzu kullanabiliriz. Dosya yerine klasörleri görmek için type seçeneğine d operatörünü verebilirsiniz. Hatta spesifik olarak tam bir dosya ya da dizin boyutunu arıyorsak artı ya da eksi olmadan direk boyutunu da belirtebiliriz. Bu sayede tam olarak ilgili boyutla eşleşen dosya veya klasörler listelenecektir.

Ayrıca erişim, değişim ve düzenleme tarihlerine göre de filtreyebiliriz. Öncelikle bu kavramların neyi ifade ettiğini öğrenmeliyiz.

- Access - the last time the file was read
- Modify - the last time the file was modified (content has been modified)
- Change - the last time meta data of the file was changed (e.g. permissions)

işte atime mtime veya ctime seçeneğinin arından kaç gün önce veya kaç gün sonra olduğunu eksi veya artı işareti ile belirtebiliyoruz. Ayrıca tam gün sayısı belirtmek için de artı ve eksi olmadan doğrudan günü yazmamız yeterli.

Eğer man find şeklinde yazarsanız, aslında ne kadar çok filtreleme seçeneği olduğunu kendiniz de görebilirsiiniz. Ancak ben hepsine değinmeyeceğim. İhtiyacınız olduğunda manuel sayfasından açıp bakabilirsiniz.

Son olarak henüz yetki kavramlarını öğrenmemiş olsak da dosya veya klasörleri yetkilerine göre filtreleyebileceğimizi de belirtmek istiyorum. Bunun için permission yani izin ifadesinin kısalması olan perm seçeneğini kullanabiliyoruz. 

Hariç tutmak için:

`find / -name MyFile ! -path '*/Directory/*'`

# locate Komutu

locate komutu find komutundan farklı olarak düzenli olarak güncellenmesi gereken önceden oluşturulmuş bir veritabanı kullanıyor. find komutu ise her defasında tüm dosya sistemi üzerinde araştırma yapıyor. 

Her defasında tüm dosya sistemi taranmadığı için locate komutu find komutuna oranla daha hızlıdır. Ancak locate komutunun doğru şekilde çalışabilmesi updatedb komutu ile locate komutunun kullandığı veritabanın güncellenmesi gerekiyor. Ara ara otomatik olarak güncelleniyor olsa da, siz locate komutunu kullanmadan önce updatedb komutunu kullanırsanız, alacağınız sonuçlar çok daha doğru olacaktır.

Tüm bunlar dışında elbette find komutu tamamen işlevsiz değildir. Find komutu ile dosyaları özniteliklerine göre filtreleyebildiğiniz için daha fazla seçeneğe sahipsiniz. Zaten find komutunu ele alırken dosyaların çeşitli özelliklerine göre nasıl filtreleme yapabileceğimizi ele aldık. İşte locate komutu yalnızca dosya isimleri ile eşleşme yaptığı için find komutu ile kullanabileceğiniz dosya özelliklerini filtreleme gibi işlevleri kullanamazsınız. 

updatedb elindeki dosya indexini güncellemek için dosya veya dizinlerin değiştirilme tarihlerine bakar. Eğer updatedb aracının en son çalıştırıldığı tarihten sonra bir değişlik yoksa bu içeriklere bakılmaz. Dolayısıyla updatedb yalnızca tüm dosya sisteminde değiştirilmiş olan en son dosyaların bilgisinin alınmasını sağlıyor.

find aracı ise her defasında değişme durumuna bakmaksızın kendisine hedef olarak gösterilen dizin altındaki tüm içerikler her defasında uçtan uca tarıyor.

[https://superuser.com/questions/1675919/what-makes-locate-so-fast-compared-with-find](https://superuser.com/questions/1675919/what-makes-locate-so-fast-compared-with-find)

# sed

# awk

# Konsol Üzerinde Okunaklı Çıktılar Elde Etmek

Şimdiye kadar nasıl dosya oluşturabileceğimizi, dosyaları nasıl okuyup, içeriklerini istediğimiz gibi değiştirebileceğimizi öğrendik. Şimdi de konsol üzerinden verileri okumak istediğimizde bizlere kolay okuma imkanı sunan araçlardan bahsedelim istiyorum. Komut satırı üzerinde çalışıyorken, araçların ürettiği çıktıları yine komut satırımız üzerinde yazılı şekilde takip ediyoruz. Fakat dizin de bildiğiniz gibi komut satırının da bir görüntüleme sınırı var. Eğer grafiksel arayüzdeki bir komut satırında çalışıyorsak, zaten terminal aracı çıktıların konsola sığmayan kadarını görebilmemizi sağlayan kaydırma çubuğu gibi özellikler sunuyor. Yani örneğin ben konsol aracını pencereli şekilde kullanıyorsam ve bu şekilde küçük bir pencere ise, cat /etc/passwd komutu ile uzun içeriğe sahip dosyamı okurken tüm çıktılar bu konsolun görünen kısmına sığmayacak. Hemen denemek için komutumuzu girelim. Bakın şu anda yalnız dosya içeriğinin sonunu görebiliyorum. Önceki çıktıları ulaşmak için buradaki çubuğu kullanarak yukarı doğru kaydırabilirim. Ayrıca bakın uzun veriler barındıran satırların da zaten otomatik olarak pencere boyutuna göre kırpılıp alt satırdan devam ettirildiğini de görebiliyoruz. Eğer pencere boyutunu büyütecek olursak, bu çıktıların da büyüklüğe göre hizanladığını görebiliyoruz. İşte bizzat test ettiğimiz gibi grafiksel arayüzdeki bu konsol aracımız, çıktıların tamamını bu pencere içerisinde tek seferde gösteremiyor olsa da, tamamını görebilmemiz için bize birkaç özellikle kolaylık sağlıyor. Fakat komut satırı arayüzündeki tty konsollarında çalışırken, önceki çıktılara dönme gibi bir imkanımız olmuyor. Dolayısıyla uzun çıktılar üreten araçların tüm çıktılarını yalnız komut satırı arayüzünün bulunduğu tty konsollarında tam şekilde görüntüleyemiyoruz. 

Denemek için komut satırı arayüzüne geçiş yapıp, burada oturumumuzu açalım. Tamamdır. Şimdi test etmek için ben yine cat /etc/passwd komutunu girmek istiyorum. Bakın yine ekrana sığmadığı için çıktıların yalnızca bir kısmını alabildik. Önceki çıktıları görmek için faremizin sroll tuşu ile yukarı kaydırmayı deneyebiliriz. Fakat gördüğünüz  gibi herhangi bir reaksiyon alamıyoruz çünkü komut satırı arayüzdeki bu tty konsolları üzerinde bu işlev sağlanmıyor. 

İşte bu duruma çözüm olarak araçların çıktılarını bize parça parça sunabilecek ek araçlara ihtiyacımız var. Ben de anlatımın devamında bize bu imkanı tanıyan more less head tail ve nl araçlarından bahsedip, komut satırı arayüzündeki hakimiyetimizi arttırmak istiyorum.

## more Komutu

more aracı, kendisine yönlendirilmiş olan verilerin en başından itibaren ekrana sığan kadarlık kısmını sırasıyla parça parça bize sunuyor. Örneğin bir dosya içeriğinin ilk 10 satırı ekranımıza sığıyorsa, ilk olarak 10 satırı daha sonra bir sonraki 10 satırı ve bir sonraki 10 satırı gösterecek şekilde tüm içerik bitene kadar baştan sonra tüm verileri parça parça bize sunuyor.

Zaten more ismi de buradan geliyor. Biz istedikçe verilerin geri kalanını yani daha fazlasını bize parça parça sunduğu için more ismi verilmiş. 

Ben örnek olması için /etc dizinin içeriğini listeleyip, tüm listeye parça parça bakmak istiyorum. Örneğin ls /etc şeklinde komutumu girdiğimde bakın, çıktıların tamamını göremiyorum çünkü epey bir içerik listeleniyor. Bu sorunu çözmek içim bu çıktıları pipe ile more aracına yönlendirip çıktılara parça parça bakabiliriz. Ben pipe dan sonra more komutunu da ekliyorum. Bakın bu kez, içerik listesinin en başından itibaren yalnızca ekranıma sığan kadarlık kısmını görüyorum ve altta “more”  ifadesi var. Bu ifade, ileride daha fazla verinin olduğuna işaret ediyor. Eğer bir satır sonrasını görmek istersem enter ile satır satır daha fazla içeriğe ulaşabilirim. Bakın ben enter a bastıkça yeni satırlarda sonraki veriler gözüküyor. Eğer satır satır değil de, doğrudan ekranıma sığacak kadarlık yeni içerikleri görmek istersem de doğrudan space tuşunu kullanabilirim. Bakın ekranıma sığacak kadar yeni veriler karşıma getirildi. Üstelik bakın hala veriler olduğu için more ifadesi gözükmeye devam ediyor.  Ben yine space ile ekranıma sığacak kadar sayfa sayfa yeni çıktıları görüntülüyorum ve en nihayetinde tüm veriler bittiğinde more ifadesi kaybolup, tekrar komut girebileceğim promt satırına ulaşıyorum.

Gördüğünüz gibi tamamı konsol ekranımıza sığmayacak kadar olan tüm verileri, more aracına yönlendirip, bu araç vasıtasıyla ekranımıza sığan kadarlık kısmını parça parça veya satır satır ileriye doğru görüntüleyebiliyoruz. Fark ettiyseniz özellikle ileriye doğru dedim çünkü more aracı önceki çıktılara dönmemizi sağlamıyor. Tek yönlü şekilde yani hep daha fazlası için en baştan en sona doğru verileri görüntüleyebiliyoruz. Örneğin space ile geçtiğiniz önceki parçaya dönmek isterseniz bu more aracı ile mümkün değil. Bu duruma çözüm olarak bir sonraki derste ele alacağımız less aracı var. Fakat bu araca geçmeden önce more aracının dosyalar üzerinde de kullanılabileceğini belirtmek istiyorum. Ben denemek için more komutundan sonra içeriğini görmek istediğim /etc/passwd dosyasını yazıyorum. Bakın ekranımıza sığan kadarlık kısmı bastırıldı. Hatta alt tarafta dosya içeriğin yüzdelik olarak ne kadarlık kısmının görüntülendiği de belirtiliyor. Enter ile satır satır ilerledikçe de buradaki yüzde artıyor çünkü dosya içeriğinin daha fazlasını görüntülüyoruz. En nihayetinde dosyanın sonuna geldiğimizde de görüntüleme işlemi sonlanıyor.

Yani bizzat test ettiğimiz gibi more aracı standart girdiden veri almasına ek olarak, kendisine argüman olarak verilmiş olan dosya içeriğini de parça parça konsol üzerinden görüntüleyebilmemize olanak tanıyor.

Hatta dilersek more aracı ile birden fazla dosyayı da aynı anda açıp okuyabiliriz. Ben denemek için son komutumu çağırıp sonuma bir de /etc/group dosyasını da okumasını söylüyorum. Bakın satırın en başında şu anda hangi dosyanın içeriğinin görüntülendiği belirtiliyor. Space ile devam edelim. passwd dosyasının sonuna geldik. Eğer devam edecek olursak, sıradaki dosyanın /etc/group dosyası olacağı da burada açıkça belirtiliyor. Ben devam ediyorum. Bakın satırın en başında, hangi dosya içeriğini görüntülendiği yazıyor. Yani böylelikle more aracı ile birden fazla dosyanın içeriğini peşi sıra parça parça konsolumuz üzerinden görüntüleyebileceğimizi de deneyimlemiş olduk.

Ayrıca eğer more aracını kullanırken içeriğin sonuna gelmeyi beklemeden aracı sonlandırmak isterseniz q tuşuna basmanız yeterli. Bakın ben dosyanın geri kalanını okumadan yalnızca q tuşuna bastığım için more aracı kapandı ve komut girebileceğim promt satırına geri döndüm. 

# less Komutu

more aracının verileri yalnızca ileriye doğru bastırdığını gördük. Yani more aracı ile önceden görüntülediğimiz verilere dönmemiz mümkün olmuyor. Bu duruma çözüm olarak more ile benzer işlevi olan ancak geriye dönme özelliğini de destekleyen less aracını kullanabiliyoruz.

More aracının çıktılarda geriye doğru kaydırma yapamamasından bıkan başka bir geliştirici "az çoktan fazladır" a atıfta bulunarak less aracını geliştirmiştir. 

less komutu more komutundan farklı olarak dosya içeriğinde aşağı yukarı, sağa ve sola doğru kaydırma hareketlerine imkan tanıyor. 

Test etmek için yine etc dizinini listeleyip çıktıları less aracına yönlendirebiliriz. Bakın yine ekranımıza sığacak kadarlık kısım karşıma geldi. Devamında veri olduğunu buradaki iki nokta üst üste karakterinden anlayabiliyorum. 

Eğer bir satır aşağı inmek istersem klavyemdeki aşağı yön tuşunu kullanabilirim. Benzer şekilde bir üst satıra çıkmak için de klavyemdeki yukarı yön tuşunu kullanmam yeterli. Ayrıca more komutunda olduğu şekilde enter ile de bir satır aşağı inip, space ile birer sayfa ileriye atlayabiliyoruz. 

Space tuşu haricinde bir sayfa ileri gitmek için forward yani ileri ifadesinin kısaltması olan f tuşunu kullanabiliyoruz. Bir sayfa geri gelmek için de backward yani geriye ifadesinin kısaltması olan b tuşunu kullanabiliyoruz. Okuma işimiz bittiğinde aracı kapatmak için q tuşuna basmamız yeterli. Bakın aracım kapandı ve normal komut satırına geri döndüm.

Ben yalnızca standart girdideki verileri less aracına aktardım ancak tabii ki less aracı ile dosya içeriklerini de görüntüleyebiliyoruz. Okumak istediğiniz dosyaların isimlerini less aracına argüman olarak vermeniz yeterli. Ben denemek için less /etc/passwd komutu ile dosyamı okumak istiyorum.

Bakın şu anda görüntülediğim dosyanın ismi burada yazıyor. Ayrıca less aracıyla, satırların geri kalanını okumak için sağ sol yön tuşlarını da kullanabiliyoruz. More aracında bu şekilde satırları geniş biçimde görüntüleyip, kaydırma hareketi yapamıyoruz. Less aracı her yönde daha esnek bir kullanım sağlıyor.

Ayrıca şimdiye kadar ele aldığımız temel kullanım özelliklerine ek olarak aslında less aracının pek çok ekstra özelliği mevcut. Bunları görmek için less —help komutunu girebiliriz. Bakın burada yön tuşlarına ek olarak arama yapma, dosyalar arasında geçiş yapma ve benzer pek çok özelliğin açıklaması bulunuyor. Birçok özelliği olmasına karşın biz yine de temelde aşağı yukarı hareket ederek dosya içeriğini görüntülemek için kullanacağımız için bu kadarlık bilgi bence yeterli. Yine de arama yapma ve dosyalar arasında geçişten de çok kısaca bahsetmek istiyorum. Bunun için tekrar less aracı ile dosya okumayı deneyebiliriz. Ben bu kez iki tane dosyayı okumak üzere less /etc/passwd /etc/group komutunu giriyorum. Bakın ilk yazdığım passwd dosyasının açıldığı aşağıda belirtiliyor. Örneğin ben şu an görüntülenmekte olan bölümden sonraki içeriklerde araştırma yapmak istiyorsam, slash işareti koyup araştırmak istediğim ifadeyi yazıyorum. Ben taylan ifadesini araştırmak istiyorum. Bakın içeriğin devamında taylan ifadesi geçtiği için eşleşen yere atladım. Benzer şekilde eğer mevcut bulunduğum konumdan geriye doğru araştırma yapmak istersem de soru işaretinden sonra araştırmak istediğim ifadeyi yazmam gerekiyor. Ben root şeklinde aratıyorum. Bakın üstteki içeriklerden root ifadesi ile eşleşen yere atamış oldum. Eğer aramayı sürdürmek istersem küçük ne karkteri ile geriye doğru gidebilirim. Ya da bir önceki araştırmaya dönmek için de büyük N karakterini kullanabilirim. Bakın önceki ve sonraki eşleşmeler arasında küçük ve büyük N karakteri sayesinde geçiş yapabiliyorum. Bu hızlı geçiş yöntemini hem ileri hem de geriye dönük araştırma yaparken kullanabiliyoruz. 

Bunun dışında şu anda passwd dosyasını okuduğumuzu biliyorsunuz. Dosyasının sonuna geldiğimizde, more aracında olduğu gibi bir sonraki dosyaya geçişmiyor. Geçiş için iki nokta üst üste karakterinden sonra next yani sonraki ifadesinin kısaltmasından gelen n karakterini yazıp onaylamanız gerekiyor. Bakın bir sonraki dosya olan group dosyasına geçtim. Eğer bir önce dosyaya dönmek istersem previous yani önceki ifadesinin kısalması olan p karakterini iki nokta üst üste karakterinden sonra girip onaylamam yeterli. Bakın şimdi de önceki dosyaya dönmüş oldum.

Bence less aracı hakkında bu kadarlık bilgi yeterli.  Daha fazlasını öğrenmek veya unuttuğunuzda hatırlamak için less —help komutunu kullanıp less aracının yardım sayfasından faydalanabilirsiniz.

# nl Komutu

Eğer satırların başına satır numaralarını eklemek istersek nl komutunu kullanabiliyoruz. Özellikle çok fazla verinin tek bir satıra sığdırıldığı yoğun içerikli dosyalarda içeriği daha rahat okuyabilmek için numaralandırma bize kolaylık sunabiliyor.

Ben denemek için daha içerisinde uzun satırlar bulunan passwd dosyamı nl komutu ile açıyorum. Gördüğünüz gibi konsol ekranına tek satırda sığmıyor olsa da aslında buradaki her bir numara, tek bir satırı işaret ediyor. İşte bu gibi dosyaların kaç satırdan oluştuğunu görmek için nl komutu oldukça faydalı.  Mesela tüm içeriği göremediğimiz için pipe ile bu çıktıları less aracına yönlendirip parça parça numaralı çıktıları görüntüleyebiliriz. Bakın ekrana sığan kadarlık kısmı numaralı şekilde görebiliyoruz. Bu şekilde ihtiyacımıza yönelik çözümler için birden fazla aracı birbirine bağlayacak çalışabilmenin ne kadar esneklik sağladığını da tekrar görmüş olduk.

Arıca tabii ki doğrudan dosya içeriğini numaralandırmak yerine ls aracı ile /etc dizinini listeleyelim ve bu çıktıları numaralandıralım. Bunun için ls /etc | nl şeklinde komutumu giriyorum.  Bakın standart girdiden okunan verileri de pipe ile nl aracına yönlendirip numaralandırmış olduk.

nl komutunun da tıpkı diğer pek çok araç gibi elbette birden fazla ek seçeneği bulunuyor. Eğer nl —help komutunu kullanırsak, seçenekleri görebiliriz. Ancak açıkçası ben bu kadar seçenekle ilgilenmiyorum. Benim ihtiyacımı cat komutunun n seçeneği de yeterince iyi görüyor. Örneğin aynı dosyayı cat -n seçeneği ile de numaralandırabilirim. Buradaki çıktıda boş satırlar da numaralandırıldı. Eğer boş satırları istemezsem cat komutunun -b seçeneğini de kullanabilirim. Zaten kullanımından daha önce bahsettim.

Peki madem cat komutu ile aynı işi yapabiliyoruz neden bir daha nl komutunu ele aldım ? nl komutunu ele aldım, çünkü kullanımı ile sık karşılaşabilirsiniz. nl komutunu sunduğu ek özellikler için özellikle kabuk programlamada sıklıkla tercih ediliyor. Ben sadece sık kullanıldığı için nl komutundan da haberdar olmanızı istedim. Hangi iş için hangi komutu kullanacağınız tamamen sizin alışkanlıklarınıza bağlı. Aklınıza ilk nl komutu geliyorsa, bu aracı kullanabilirsiniz. Pek çok farklı aracın aynı özellik için farklı seçenek tanımları bulunduğu için aslında nl gibi spesifik olarak tek bir işi yapan aracı bilmek bir avantaj. Örneğin less aracı satırları listelemek için büyük -N seçeneği ile listeleyebiliriz. Başka bir araç için de başka seçenek tanımlanmış olabilir. İşte bu durumda aynı özellik için farklı araçların farklı seçeneklerini hatırlamak yerine tek bir aracı hatırlayıp o iş için bu aracı kullanabiliyoruz. Elinizdeki verileri numaralandırmak mı istiyorsunuz, nl aracını kullanabilirsiniz. İstediğiniz bir aracın çıktısını veya dosyayı nl aracına yönlendirmeniz yeterli.

Eğer sizin için hatırlanması ve kullanması daha kolay geldiyse aracın diğer seçeneklerine de mutlaka göz atın.

# head Komutu

İsminin de çağrışım yaptığı gibi head komutu kendisine yönlendirilen içeriğin başından itibaren okunabilmesini sağlıyor. Herhangi bir seçenek belirtmediğimizde head aracı ilk 10 satırı konsola bastırıyor. Ben denemek için head /etc/passwd komutu ile dosyamı okumak istiyorum. Bakın 

Dosya içeriğinin yalnızca ilk 10 satırı bastırılmış oldu.

Birden fazla dosya okunmasını da sağlayabiliriz. Eğer aynı anda birden fazla dosya okunuyorsa her bir dosyanın ilk 10 satırını bastırır. Hemen deneyelim. Ben /etc/group dosyasını da okumak üzere komutumu düzenliyorum.

Bakın en başta hangi dosya olduğunu da açıkça belirtilerek her iki dosyanın da ilk 10'ar satırı bastırıldı.  

Eğer kaç satır bastırılmasını gerektiğini belirtmek istiyorsanız, -n seçeneğinin ardından kaç satır basılacağını da yazabilirsiniz. Ben denemek için dosyanın ilk 5 satırını bastırmak üzere head -n 5 dosya_adı şeklinde komutumu giriyorum. Bakın dosyamın yalnızca ilk 5 satırı bastırıldı. Ayrıca bu kullanım dışında doğrudan head -5 dosya_adı komutu ile de aynı şekilde ilk 5 satırın bastırılmasını sağlayabiliyorum. Yani n seçeneği olmadan doğrudan tire işaretinden sonra kaç satır bastırılmasını gerektiğini de belirtebilirsiniz.

Tahmin ettiğiniz gibi tabii ki yalnızca dosyalar üzerinde çalışmak zorunda da değiliz. Örneğin ls /etc komutunu çıktılarını pipe ile head aracına yönlendirip ilk 10 satırın bastırılmasını sağlayabiliriz. Bakın yalnızca 10 satırı bastırıldı.

Ayrıca head aracının başka seçenekleri de var fakat diğer seçeneklerine neredeyse hiç ihtiyaç duymayacağınız için bahsetmiyorum. Merak ediyorsanız, head —help komutunu kullanabilirsiniz.

# tail Komutu

Tail ifadesi türkçe kuyruk anlamına geliyor. İsminden de kolayca anlaşılabileceği gibi tail komutu dosyaların sondaki satırlarının bastırılmasını sağlıyor. Yani head aracının tersten çalışan versiyonu olarak düşünebilirsiniz. tail, ekstra bir seçenek kullanılmadığında varsayılan olarak ilgili dosyanın sondan 10 satırını bastırıyor. Hemen denemek için /etc/passwd dosyasını okumayı deneyelim.

Bakın dosya içeriğinin sondan 10 satırı bastırıldı. Dilersek kaç satır bastırılacağını -n seçeneğinin ardından belirtmemiz de mümkün. Ben son 6 satırı bastırmak için tail -n 6 /etc/passwd şeklinde komutumu giriyorum.

Bakın yalnızca sondan 6 satır bastırılmış.

Ayrıca tıpkı head komutunda olduğu gibi elbette birden fazla dosyayı da aynı anda açabiliriz. Ben passwd ve group dosyalarının sondan 3 satırını bastırmak için tail -n 3 /etc/passwd /etc/group komutunu giriyorum. Bakın sırasıyla her iki dosyanın da sondan 3 er satırı bastırıldı.

Dosya içeriklerinin okunması yerine standart girdiden alınan verilerin kullanılması da mümkün. Ben ls /etc/ komutu ile dizin içeriğinin listelenip, pipe ile bu çıktların tail aracına aktarılmasını istiyorum.

Bu sayede gördüğünüz gibi etc dizin içeriğinin sondan 10 satırı konsola bastırılmış oldu.

Bu basit kullanımlar dışında, tail aracının -f seçeneği sayesinde özellikle sürekli güncellenen verilerin takibi için kullanılması da mümkün. Bu -f seçeneği, özellikle log dosyalarındaki en son değişikliklerin takibi için sıklıkla kullanıyor. Ben test etmek için yeni bir konsol açıyorum. Bu konsoldayken cat > yeni.txt komutunu giriyorum şimdilik dosyaya herhangi bir veri eklemeyeceğim. Önceki konsola geçip tail -f yeni.txt komutunu girelim. Konsolları yan yana getirip, değişimi daha rahat gözlemeyebiliriz. Ben cat komutunu girdiğim konsola dönüp merhabalar yazıp enter ile bir alt satıra iniyorum. Bakın anında tail -f komutunu yazdığım çıktıyı okuyup konsola bastırdı. Bu şekilde okunan dosyadaki tüm yeni veri girdileri tail -f komutu sayesinde anlık olarak konsola bastıracak. Hemen deneyelim.

Bakın ne kadar yeni veri girersem, tail -f komutu o kadar veriyi bastırıyor. Bu komut özellikle log dosyalarını okumak için kullanıyor zaten. Örneğin sistemdeki oturumlar hakkında kayıtların tutulduğu /var/log/auth.log dosyasını tail -f komutu ile okumayı deneyebiliriz. 

Ben dosyadaki değişikliği gösterebilmek için yeni konsolda, su nil komutu ile nil kullanıcı hesabına geçiş yapacağım. Bakın nil kullanıcısı olarak oturum açtığımda buradaki log dosyasına bu kayıt anında işlendi ve ben de tail -f komutu sayesinde bu anlık değişimi konsol üzerinden takip edebildim. İleride log kayıtları ile uğraşırken tail -f komutunu sizler de sıklıkla kullanıyor olacaksınız.

Böylelikle temel olarak tail aracının işlevinden ve kullanımından da haberdar olduk. Tabii diğer seçenekleri için yardım sayfalarına göz atabilirsiniz.

Ayrıca ben özellikle ele almadım ancak pipe mekanizmasının da yardımıyla ihtiyacınıza yönelik olarak bu bölümde öğrenmiş olduğunu uygun yapıdaki tüm araçları birbine bağlayarak çalıştırabileceğinizi zaten biliyorsunuz. Ben yalnızca araçların temel kullanımlardan bahsettiğim için özellikle birden fazla aracın birlikte kullanıldığı farklı durumlara örnekler verme fırsatım olmadı ama siz kendiniz pratikler yaparak deneyimleyebilirsiniz. 

Ve artık böylelikle dosya işlemleri için bilmemiz gereken temel araçları tanıdığımıza göre bu bölümü sonlandırabiliriz. Bir sonraki bölümde komut satırı arayüzünde kullanabileceğimiz metin editörlerinden bahsederek devam ediyor olacağız.