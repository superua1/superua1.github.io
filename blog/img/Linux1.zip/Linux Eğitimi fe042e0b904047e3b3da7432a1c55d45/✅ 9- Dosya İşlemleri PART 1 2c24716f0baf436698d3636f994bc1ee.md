# ✅ 9- Dosya İşlemleri PART 1

Eğer daha önce az çok Linux ile haşır neşir olduysanız ve biraz da meraklıysanız “Linux üzerinde her şey bir dosyadır” sözünü mutlaka duymuşsunuzdur. Bu sözün ne ifade ettiğini özellikle ele alacağız ancak, sizlerin de fark edebileceği gibi bu söz şimdiden bu bölümün ne kadar önemli olduğunun sinyallerini veriyor. Bu doğrultuda bu bölümü de anlatım sırasına uyarak ve anlatımları mümkün oldukça uygulamaya geçirerek takip etmenizi rica ediyorum.

Her şey bir dosyadır tanımı, klavyenizin, dosyaların, dizinlerin, soketlerin, boru hatlarının(pipeline), aygıtların ve benzeri tüm yapıların birer dosya olarak tanımlanıp, çekirdekteki sanal dosya sistemi katmanı üzerinde soyutlanmış olan dosya tanımlayıcılar ile temsil edilmesidir. Yani "Her şey bir dosyadır" ifadesi, işletim sisteminin genel mimari yaklaşımını özetliyor. Bu yeterince açık bir tanımlama olmadı biliyorum, çünkü henüz bahsetmediğimiz kavramları kullanarak açıklamış oldum. Ancak merak etmeyin anlatımın devamında açıklamalarım sizin için de netleşmiş olacak.

Bir soru sorarak başlayacak olursak; örneğin biz konsol üzerinden kabuğa komut verirken klavyemizden yazdıklarımız nasıl kabuğa ulaştırılıyor? 

Konsola komut girdiğimizde aslında kabuğumuza emir verdiğimizi biliyoruz. Bash kabuğu varsayılan olarak konsoldan gelen emirleri okuyup çalıştırıyor, sonuçlarını da yine konsola çıktı olarak aktarıyor. Yani konsola bir komut giriyoruz, komutun sonucunu anında görebiliyoruz. Bu sayede etkileşimli yani interaktif şekilde bash kabuğunu konsol aracımız üzerinden kullanabiliyoruz. Burada kullandığımız kabuk programı ve konsol aracı da aslında sistem tarafından bir dosya gibi ele alınıyor. Ve neticede iki dosya arasında veri akışı sağlanarak iki aracın birbirine bağlı şekilde çalışması sağlanmış oluyor. Buradaki araçların dosya olarak ele alınması çok genel ve belirsiz bir tanımlama oldu, netleşmesi için biraz daha açıklamak istiyorum.

Eğer hatırlıyorsanız konsol türlerini açıklarken tty konsolundan ve grafiksel arayüzdeki sözde(pseudo) konsollardan bahsetmiş ve dosya karşılıklarını da tty komutu ile öğrenmiştik. Örneğin 1. tty konsolunda çalışıyorsak bu konsol sistem üzerinde /dev/tty1 dosyası ile temsil ediliyorken, eğer grafiksel arayüzde tek bir terminal aracını açtıysak bu terminal de sistemde /dev/pts/0 dosyası ile temsil ediliyordu. Yani konsolların da sistem üzerinde dosya olarak ele alındığını zaten biliyoruz. Bir kez daha teyit etmek için tty komutunu girip sonucuna bakabiliriz. Bakın grafiksel arayüzdeki ilk konsolun /dev/pts/0 dosyası olarak temsil edildiğini belirten çıktıyı aldım.

Grafiksel arayüzde açılan konsolların /dev/pts dizini altında bir dosyada sırasıyla temsil edildiğini teyit etmek için yeni konsollar açabiliriz. Öncelikle ls /dev/pts komutu ile bu dizinin içeriğini görüntüleyelim. Bakın şu anda grafiksel arayüzde tek bir konsol açtığım için burada yalnızca bu konsolu temsil eden 0 isimli bir dosya var. Şimdi iki yeni konsol daha açalım. Tamamdır konsollar açıldı. Şimdi komutumuzu tekrar girip bu konsolları temsil eden yeni dosyaların oluşturulup oluşturulmadığına bi bakalım. Bakın 1 ve 2 isimli yeni dosyalar da oluşturulmuş. İşte bizim burada konsollar üzerinden teyit ettiğimiz bu, her şeyin dosya gibi ele alınması yaklaşımı aslında tüm sistem genelindeki işleyişi temsil ediyor. 

Tam da bu noktada, neden bu dosya yaklaşımının tercih edildiğini merak etmiş olabilirsiniz. Bu durumun en temel nedeni, dosyalar üzerinde işlem yapmanın herkes için çok kolay ve anlaşılabilir olması aslında. Sistemdeki tüm yapılar dosya gibi ele alındığında, kullanıcıların ve sisteme yazılım geliştiren yazılımcıların sistemi daha kolay anlamalarını ve yönetmelerini mümkün oluyor. 

Çünkü tüm kullanıcılar ve yazılımlar için dosyaları okumak veya dosyalara yeni veri eklemek çok kolay. Bu yaklaşım sayesinde tüm sistemde ortak bir iletişim yolu ortaya çıkmış oluyor. Diğer bir deyişle dosyaları okuyup dosyalara veri yazarak tüm sistemdeki yapıların ortak yöntemle haberleşmesi mümkün oluyor. Örneğin x programının ürettiği çıktılar y programı tarafından tıpkı bir dosya okurmuşçasına açık ve kolay şekilde okunabiliyor, dolayısıyla birbirinden bağımsız pek çok aracı bir arada zahmetsizce kullanabiliyoruz.  Veya başka bir açıdan baktığımızda, sistemimize bağlı olan bir cihazın sistem üzerindeki dosya karşılığı üzerinden bu aygıt hakkında bilgi almamız da mümkün oluyor. Basit bir analoji ile bu yaklaşımı dünyadaki tüm canlıların ortak dille iletişim kurması gibi düşünebilirsiniz. 

İşte bu yaklaşımın getirdiği kolaylık sebebiyle çekirdek, sistem üzerindeki tüm yapıları bize bir dosyaymış gibi sunuyor. Çekirdekteki sanal dosya sistemi yapısı, çalışan işlemleri, aygıtları ve diğer her şeyi sanal olarak bize bir dosyaymış gibi sunuyor. Biz de bu dosyaları okuyarak veya dosyalara veri ekleyerek işlemleri veya aygıtları yönetebiliyoruz. Özetle her şeyin dosya gibi ele alınması, kullanıcının sistem üzerindeki tüm mekanizmalardan kolayca haberdar olup, gerektiğinde bu mekanizmalara müdahale edebilmesine olanak tanıyor. Çekirdek donanımlar ile gereken alt seviyeli iletişimi kendisi sağlayıp bize sade ve okunaklı şekilde sanal dosyalar sunduğu için pek çok yapıyı rahatlıkla denetleyip yönetebiliyoruz. 

Çok teknik ayrıntılara girmek veya kendimi tekrar edip lafı uzatmak istemiyorum. Ama birkaç kez vurguladığım gibi çekirdek, bize sistem üzerindeki tüm yapıların sanal dosya karşılıklarını sunduğu için sistemi yönetmek, dosya açıp okuyup değiştirmek kadar basitleştirilmiş oluyor. 

Örneğin bir programı çalıştırdığımızda bu program kabuk tarafından sistem üzerinde bir “işlem” yani “process” olarak ele alınıyor. Ve bu işlem hakkında tüm bilgiler de /proc/ dizininde bu işlemi temsil eden işlem numarası altında bize sunuyor. Örneğin ben X isimli bir aracı çalıştırdığımda çekirdek, bu aracın kolayca denetlenip yönetilebilmesi için bu aracın işlemine bir sayı atıyor. Mesele X işlemi için 15 işlem numarasını tanımlıyor. Dolayısıyla /proc/ dizini atlında da /15/ klasörü içinde bu işleme dair tüm bilgileri içeren çeşitli dosya ve klasörler de bize sunuluyor. Biz bu işlem hakkında bilgi almak istediğimizde doğrudan buradaki dosyaları açıp okuyabiliyor ya da yine buradaki dosyalardan yararlanarak bize bilgi sunan çeşitli araçları da kullanabiliyoruz. Ayrıca bu işlemi durdurmak veya kapatmak gibi işlemler için de yine bu işlem numarasını kullanabiliyoruz. Bu konulardan işlem bölümünde ayrıca bahsedeceğiz ancak çekirdeğin her şeyi neden bir dosya olarak ele aldığını bence buradaki kısa örnek gayet net biçimde gösteriyor. Her şeyi bir dosyaymış gibi sadeleştirirsek, sistem üzerindeki her şeyi denetleyip tam olarak istediğimiz şekilde yönetebiliyoruz. 

Bu bahsettiklerimiz ışığında somut bir örnek üzerinden anlatımlarımızı daha anlaşılır kılmayı deneyebiliriz. 

Ben somut bir örnek üzerinden konuşmak için her şeyi kapatıp yeni bir konsol açıyorum ve konsola sırasıyla echo test ve asdf komutunu giriyorum. 

```bash
┌──(kali㉿kali)-[~]
└─$ echo test
test

┌──(kali㉿kali)-[~]
└─$ asdf
Command 'asdf' not found, did you mean:
```

Girdiğim ilk komut başarılı oldu ve test ifadesi konsola bastırıldı. Girmiş olduğum ikinci komut kabuk tarafından bulunamadığı için komutun hatalı olduğuna dair yanıt yine konsola bastırıldı. Yani konsol üzerinden kabuğa vermiş olduğum emirlerin, olumlu ve olumsuz yanıtlarını yine konsolda görüntüleyebildik.

Yapıyı en basit haliyle açıklayacak olursam. 

Yeni bir konsol açtığımda otomatik olarak varsayılan kabuk programı da başlatılıyor. Yani ben konsolu açtığımda bash kabuğu da bir işlem olarak başlatıldı. Bu işlem de sistem üzerinde bir dosya ile temsil ediliyor. Sistem üzerinde dosya gibi ele alınan bash kabuğunun işlemi de varsayılan olarak 3 tür dosya tanımlayıcısı ile başlatılıyor. Bu noktada bizim için yeni olan “dosya tanımlayıcısı(file descriptor)” kavramını çok kısaca açıklamam gerek.

İsminden de anlaşılabileceği gibi dosya tanımlayıcısı, dosyadan veri okumak veya bu dosyaya veri göndermek isteyenler için hangi veriyi nereye gönderip nereden veri alabileceklerini belirten bir tanımlayıcı adres görevi görüyor. Yani bu üç dosya tanımlayıcısı üzerinden bash kabuğunun çalıştırıldığı bu işleme yani bu dosyaya veri gönderebiliyor, ve bu dosyadaki verileri okuyabiliyoruz. Yani kabuk ile tıpkı dosyaymış gibi iletişim kurabiliyoruz. Bunu da dosya tanımlayıcılar sayesinde yapıyoruz.

Şimdi somut açıklamalar eşliğinde bu yapıyı tekrar en basit haliyle açıklayacak olursak. Ben konsolu açtığımda çekirdek tarafından dosya sisteminde otomatik olarak bu konsolu temsil eden /dev/pts/0 dosyası oluşturuldu. Bu durumu daha önce de bizzat teyit etmiştik. Konsolu temsil eden dosya oluşturulduktan sonra yani konsol açıldıktan sonra varsayılan kabuk çalıştırılıyor. Bu kabuk da benim sistemim için bash kabuğu. 

Bash kabuğu çalıştırıldığında bu kabuk bir işlem yani proses olarak çekirdek tarafından başlatılmış oluyor. Bu bash işlemi de yine çekirdek tarafından dosya sisteminde /proc/ dizini altında işlem numarası ile isimlendirilmiş sanal bir dizin altında sanal dosyalar ile temsil ediliyor. Bu sayede biz bu sanal dosyalar üzerinden kabuk işlemi hakkında bilgi alabiliyoruz. Yani kabuk işlemi, çekirdek tarafından bize dosyalar üzerinden ulaşılabilir hale getirildi. Hemen bu dosyaları görmek için öncelikle çalışmakta olan mevcut kabuğun işlem numarasını öğrenelim. Bunun için ps komutunu kullanabiliriz. Şimdilik bu komutun detaylarına takılmayın lütfen. 

```bash
┌──(kali㉿kali)-[~]
└─$ ps
    PID TTY          TIME CMD
 111676 pts/0    00:00:00 bash
 112166 pts/0    00:00:00 ps
```

Burada bash e karşılık gelen pid sayısı, bu konsola bağlı olarak çalışmakta olan bash kabuğunun çekirdekteki işlem karşılığını veriyor. Dizine geçiş için cd /proc/işlem-numarası/ şeklinde komutumuzu girelim. 

```bash
┌──(kali㉿kali)-[~]
└─$ cd /proc/111676/
```

Şimdi dizin içeriğini görüntülemek için ls komutunu kullanabiliriz. 

```bash
┌──(kali㉿kali)-[/proc/111676]
└─$ ls                                       
arch_status         ns
attr                numa_maps
autogroup           oom_adj
auxv                oom_score
cgroup              oom_score_adj
clear_refs          pagemap
cmdline             patch_state
comm                personality
coredump_filter     projid_map
cpu_resctrl_groups  root
cpuset              sched
cwd                 schedstat
environ             sessionid
exe                 setgroups
fd                  smaps
fdinfo              smaps_rollup
gid_map             stack
io                  stat
limits              statm
loginuid            status
map_files           syscall
maps                task
mem                 timens_offsets
mountinfo           timers
mounts              timerslack_ns
mountstats          uid_map
net                 wchan
```

Bakın burada listelenmiş olan tüm dosya ve klasörler, bu konsola bağlı olarak çalışan bash kabuk işlemini temsil ediyor. Bu dosyalar üzerinden bash işlemi hakkında çeşitli bilgiler edinip, gerekirse düzenleme yapabiliriz. Tabii ki bu noktada böyle bir şeye ihtiyacımız yok ama görebildiğiniz gibi konsol başlatıldıktan sonra otomatik olarak başlatılan bash kabuk işleminin, çekirdek tarafından bize sunulan sanal dosyaları kanlı canlı karşımızda duruyor. Yani bizzat görebildiğimiz gibi işlemler bile, dosya olarak temsil ediyor.

Bunca detaydan bahsettikten sonra benim aklımda tek bir soru canlanıyor: madem sistem üzerinde her şey dosyalar ile temsil ediliyor, konsolu temsil eden dosya ile kabuk işlemini temsil eden dosya nasıl haberleşiyor ? Yani biz konsola komut girdiğimizde girdiğimiz komutlar nasıl kabuğa ulaştırılıyor ve kabuğun yanıtları nasıl tekrar konsola iletilebiliyor ?

Cevap aslında çok basit, dosya tanımlayıcılar(file descriptors). Her bir dosyanın yeni veriler okumak veya var olanları aktarmak için bu verileri aktarabileceği bir kanala ihtiyacı var. İşte dosya tanımlayıcılar da dosyaları uygun şekilde birbirine bağlayarak verilerin okunması veya yeni verilerin gönderilebilmesini sağlıyorlar. 

Kabuk ile konsolun arasındaki veri alışverişini en basit haliyle izah edebilmek için şimdiye kadar bahsetmiş olduğumuz tüm kavramları toparlayabiliriz. Ben grafiksel arayüzden çalıştığım için sanal terminal üzerinde çalışıyorum. Bu bağlamda anlatımları çalışmakta olduğum ilk sanal konsolu yani sistemde /dev/pts/0 dosyası olarak temsil edilen konsolu dikkate alarak yapacağım. Hatta tty komutunu girip, mevcut konsolun dosya karşılığını da öğrenebiliriz. 

```bash
┌──(kali㉿kali)-[/proc/111676]
└─$ tty                                      
/dev/pts/0
```

Bakın /dev/pts/0 olarak geçiyor.

Varsayılan olarak bash kabuğunu konsol üzerinden kullanırken, çalışmakta olan bash işlemi, girdileri yani emirleri sistem üzerinde konsolun dosya karşılığı olan /dev/pts/0 dosyasından okuyor. Bash işleminin ürettiği hatalı ve hatasız çıktılar da yine /dev/pts/0 dosyasına yönlendiriliyor. Bu sayede konsol üzerinden bash kabuğuna emirler verip sonuçlarını yine konsol üzerinden görüntüleyebiliyoruz. İşte tüm bu girdi ve çıktıların yönlendirilmesi sırasında, aralarında veri aktarımı yapılacak işlemlerin hangi dosyaya aktarım yapması gerektiğini de "dosya tanımlayıcısı" olarak geçen yapı belirliyor. Burada bahsi geçen durumu kendi gözlerimizde görmek istersek mevcut bash işleminin dosya tanımlayıcı adreslerine göz atabiliriz. Dosya tanımlayıcı ifadesi ingilizce file descriptor kelimesinden geliyor. İşlemleri temsil eden bu dosyalar içinde de kısaca fd ile kısaltılmış dizinde altında tutuluyor. Görmek için cd fd komutu ile bu dizine geçiş yapabiliriz. 

```bash
┌──(kali㉿kali)-[/proc/111676]
└─$ cd fd
```

Şimdi dosya tanımlayıcıları da görmek için ls -l komutu ile mevcut dizini listeleyelim. 

```bash
┌──(kali㉿kali)-[/proc/111676/fd]
└─$ ls -l
total 0                                      
lrwx------ 1 kali kali 64 Jan 24 11:25 0 -> /dev/pts/0
lrwx------ 1 kali kali 64 Jan 24 11:25 1 -> /dev/pts/0
lrwx------ 1 kali kali 64 Jan 24 11:25 2 -> /dev/pts/0
lrwx------ 1 kali kali 64 Jan 24 11:25 255 -> /dev/pts/0
```

Bakın burada çeşitli sayıların karşılığında daha önce de söylediğim gibi konsol aracının dosya karşılığı olan /dev/pts/0 dosyasına işaret edilmiş. 

İşte burada gördüğümüz sayılar aslında dosya tanımlayıcıları. Ve bu dosya tanımlayıcıları da buradaki /dev/pts/0 dosyasına kısayolla bağlı durumdalar. Buradaki dosya tanımlayıcı saylarının ne anlama geldiğini kısaca açıklayabiliriz. 

0 sayısı ile temsil edilen dosya tanımlayıcısı, girdilerin alındığı adresi belirtir.

1 sayısı, hatasız çıktıların iletileceği adresi belirtir.

2 sayısı ise hatalı çıktıların iletileceği adresi belirtiyor.

Şimdilik 255 sayısını görmezden gelebiliriz. Buradaki çıktılardan da anlayabildiğimiz gibi konsola bağlı olarak başlatılan bash kabuk işlemi, girdilerini konsolu temsil eden /dev/pts/0 dosyasından okurken, hatalı ve hatasız çıktılarını da yine /dev/pts/0 dosyasına yönlendiriyor.

Bakın her şey dosyalar ile temsil ediliyor ve dosya tanımlayıcıları veri alışverişini mümkün kılıyor. Kullanmakta olduğumuz kabuk aslında sistem üzerinde çalışmakta olan bir işlemdir ve kendisine özel işlem numarası vardır. İşlem numarası ile dosya sisteminde /proc dizini altında yer alan bu dizin de, bu işlemi dosya olarak ele almamızı sağlayacak her şeyi barındıran bash işleminin bütüncül dosya temsilidir. İşte her şey bir dosyadır tabiri bu yaklaşımdan geliyor.

Ben yalnızca bash kabuk işlemi için örnek gösterdim ama sistem üzerindeki tüm yapıların bir dosya olarak alınmasının sonucu olarak aslında tüm yapılarla dosya tanımlayıcıları sayesine bu şekilde iletişim kurabiliyoruz. Örneğin konsol üzerinden yeni bir araç çalıştırdığımızda, bu aracın işlem karşılığı da aynı şekilde sanal dosya sisteminde oluşturulacak ve dosya tanımlayıcıları sayesinde konsoldan emirler alıp yine konsola çıktılar gönderiyor olacak. Bu yaklaşım sayesinde sistem üzerindeki tüm yapıların birbiri ile kolayca haberleşmesi ve özellikle birden fazla aracın birbirine bağlanıp ortak şekilde çalıştırılabilmesi de mümkün oluyor. Kompleks bir sorunun çözümü için birden fazla basit aracın aşamalı olarak çalışıp birbiri ile veri alışverişinde bulunduğu yapılar kurabiliyoruz.

Ben kafamızın karışmaması için özellikle ele almayacağım ama aslında bizim komutları girmek için kullandığımız klavye ve sonuçları görüntülemek için kullandığımız monitör aygıtları da sistem üzerinde sanal dosyalar üzerinden temsil ediliyor. Çekirdek arkaplanda aygıtlarla iletişim kurup, önplanda sanal dosya sistemi üzerinden tüm yapıların birbiri ile haberleşmesine olanak tanıyor. 

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled.png)

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%201.png)

Tamam sanırım artık neden Linux sisteminde her şeyin bir dosya olduğu konusunda temel seviyede fikir sahibi olabildik. Şimdi tekrar asıl odak noktamız olan kabuk kullanımına dönecek olursak. Bash kabuğunda standart olan üç dosya tanımlayıcısı olduğundan bahsettik. Sistem hakkında bilgi almak ve araçları birbirine bağlayarak kullanabilmek için dosya tanımlayıcıları kullanabilmemiz gerekiyor. Bu sebeple anlatımın devamında bu dosya tanımlayıcılarını kullanarak girdileri ve çıktıları nasıl yönlendirebileceğimizi ele alacağız. Yönlendirmeler sayesinde sistem üzerindeki tüm araçlar arasında veri aktarımı yapıp spesifik sorunlara çözüm için dilediğimiz araçları bir arada kullanabiliyor olacağız. Yönlendirme işlemlerini doğru anlayabilmemiz için de standart olan bu üç dosya tanımlayıcıyı biraz daha açıklamak istiyorum. Yani “dosya tanımlayıcı tam olarak nasıl gözüküyor, nasıl temsil ediliyor?” bilmemiz önemli.

# Standart Dosya Tanımlayıcıları(File Descriptors)

## Standart Girdi: Stdin (0)

Girdilerin alındığı dosya tanımlayıcısı İngilizce olarak "**standard input**" olarak ifade ediliyor. Standart input ifadesinin anlamı Türkçe olarak "**standart girdiler**" olmakla birlikte genellikle kısaltması olan "**stdin**" ifadesi kullanıyor. Elbette bizler yönlendirme yaparken bu tanımları olduğu gibi kullanmıyoruz. Bunlar yerine mevcut dosya tanımlayıcısı için özellikle tanımlanmış olan değerler var. Örneğin standart girdileri yönlendirme işlemlerinde tanımlanmış olan temsili değer **0** rakamıdır. Zaten bu rakamı, bash kabuğunun işlem dosyalarında fd dizini altında da görmüştük hatırlıyorsanız. 

Şu an temsili rakam sizin için bir anlama ifade etmiyor olmayabilir ancak merak etmeyin rakamların kullanımını yönlendirme işleminde tekrar göreceğiz ve çok net biçimde anlayacaksınız. Bir diğer dosya tanımlayıcısı olan standart çıktı ile devam edebiliriz. 

## Standart Çıktı: Stdout (1)

Üretilen hatasız çıktılara "**standard output**" yani "**standart çıktı**" deniyor. Standart çıktılar da kısaca "**stdout**" olarak ifade ediliyor. Üretilen hatasız çıktılar öğrenilmek istenirse bu dosya tanımlayıcının okunması gerekiyor. Yönlendirme işlemlerinde **1** rakamı ile temsil ediliyor.

## Standart Hata: Stderr (2)

Standart çıktılardan farklı olarak, bu çıktılar yalnızca hata bildirisinde bulunurlar. Yani gerçekleştirilen işlemlerin döndürdükleri hatalar, "**standard error**" yani "**standart hata**" adı altında çıktı olarak buradan sunuluyor. Standart hata ifadesi kısaca "**stderr**" olarak da geçmektedir. Hatalı çıktılar öğrenilmek istenirse bu dosya tanımlayıcı okunmalıdır. Yönlendirme işlemlerinde de **2** rakamı ile temsil ediliyor.

Bahsetmiş olduğumuz bu üç dosya tanımlayıcısı, konsol üzerinden bash kabuğunu kullanırken yani etkileşimli kabuk kullanımda varsayılan olarak konsol aracımızı işaret eden dosyaya bağlıdırlar. Zaten bu durumu bash işleminin dosyalarını incelerken fd dizini altında bizzat görmüştük. Bash kabuğu komutları yani girdileri konsol üzerinden aldığı, hatalı ve hatasız çıktıları da yine konsola ilettiği için tüm dosya tanımlayıcılar konsolun dosya sistemindeki karşılığı olan /dev/pts/0 dosyasına bağlı gözüküyor. Terminalinizin /dev/pts/0 olduğunu varsayarsak, bash başladığında dosya tanımlayıcı tablosu şöyle görünüyor:

![%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%202.png](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%202.png)

Sistem üzerindeki tüm yapılar dosya olarak ele alınıp birbirleri ile dosya tanımlayıcılar üzerinden haberleşebildikleri için teorik olarak tüm yapıların birbiri ile dosya tanımlayıcıları üzerinden veri alışverişinde bulunması mümkündür. Dosya tanımlayıcıların detaylarından yönlendirmeler başlığı altında ayrıca bahsedeceğiz ancak Linux sisteminde her şey bir dosyadır denmesinin altında yatan yaklaşımın en özet hali bu şekildedir.

Dolayısıyla aslında her şey bir dosyadır ifadesinden ziyade "her şeyin bir dosya tanımlayıcısı olabilir" daha doğru bir ifade olabilir. Bu noktada peki ama neden tüm yapılar dosya gibi ele alınmaya çalışıyor diye düşünmüş olabilirsiniz. Aslında bu sorunun cevabını verdik.

Tüm yapıları dosya olarak ele alma yaklaşımı, sadelik ve yapılar arasındaki iletişimin esnekliğini arttıran bir unsurdur. Bu sayede tıpkı dosya içeriği okur gibi yapılar hakkında her türlü bilgiyi bu dosyalar üzerinden de alabiliyoruz. Örneğin bash işleminin tüm değişkenlerini öğrenmek istersek bash işlemini temsil eden dizin altındaki environ dosyasını cat komutu ile kolayca okuyabiliriz. Bakın burada environ isimli bir dosya var. Dosya içeriğini cat komutu ile okumayı deneyelim. Gördüğünüz gibi pek çok değişkeni burada görebiliyoruz. Teyit etmek için mevcut kabuktaki tanımlı değişkenlerin bilgisini veren env komutunu kullanabiliriz. Bakın buradaki çıktılar ile bu dosyası çıktılar aynı. Çünkü biz şu anda zaten bu kabuk üzerinde çalışıyoruz. Buradaki dosya da mevcut kabuk işleminin çekirdek tarafından sunulan sanal dosya karşılığı. 

Görebildiğiniz gibi doğrudan işleme ait dosyayı okuyarak ya da bununla ilgili olan env aracını kullanarak aynı bilgiye ulaşabiliyoruz.

Her şeyi dosya gibi ele alama yaklaşımı sayesinde tıpkı biraz önceki örneğimizde de olduğu gibi, dosyalara veri yazar veya dosyalardan veri okur gibi tüm yapıların gerektiğinde birbiri ile iletişim kurabilmesinin ortak yolu sağlanmış oluyor. Hatta Linus Torvalds "her şey bir dosyadır" sözünden farklı olarak daha açık şekilde "her şey bir bayt akışıdır" diyerek asıl işleyişe daha açık biçimde vurgu yapıyor. Dosyaları sadece okuyabilir ya da dosyalar arasında dosya tanımlayıcıları kullanarak istediğimiz yönde veri aktarımında bulunabiliriz. Dosya tanımlayıcıların yönetimi yani kontrolü de çekirdektedir. Dolayısıyla iznimiz olduğu sürece teorik olarak çekirdeğin de denetimi altında istediğimiz dosyalar arasında veri akışını sağlayabiliyoruz. 

Aslında son derece basit bir yapı ama yine de ilk defa duyduysanız biraz kafanız karışmış olabilir, ancak endişelenmeyin. Anlatımın devamında uygulamalı olarak tüm bu kavramları tekrar ele alacağız. 

Ayrıca eğitimi takip eden deneyimli kullanıcılar için belki de burada anlattıklarım çok yalın gelmiş olabilir. Biliyorum dosyalar ve dosya tanımlayıcıları hakkında daha pek çok detaydan söz edilebilir ancak henüz bu noktada daha fazla bilgi temel linux kullanımı için gerekli değil. Çünkü bu eğitimdeki amacımız sıfırdan temel linux öğrenmek ve kendi başımıza yeni bilgiler öğrenebilir hale gelebilmektir. 

Neticede amacımız doğrultusunda temelde her şeyin neden dosya olarak ele alındığından ve dosya tanımlayıcısının basit olarak ne ifade ettiğinden haberdar olduğumuzda, sistemi yönetirken sıklıkla kullanacağımız yönlendirmeler kavramını net bir biçimde anlamış olacağız.

# Yönlendirmeler

Hepimizin bildiği üzere; konsola girmiş olduğumuz komutlar kabuk tarafından yorumlanarak, yapılan işlemin olumlu ya da olumsuz sonuçlarını konsola bastırılıyor. Bu işleyişin dosya tanımlayıcıları sayesinde mümkün olduğunu zaten kısaca açıkladık.

Eğer istersek dosya tanımlayıcılarının verileri okumak ya da yazmak üzere işaret ettiği dosyaları da ihtiyaçlarımıza göre değiştirmemiz mümkündür. Yani normalde bash kabuğu konsolun dosya karşılığı olan /dev/pts/0 dosyasından emirler alıp yine bu dosyaya çıktı gönderiyorken, biz bu dosya yerine istediğimiz dosyadan emir alınmasını ya da çıktıların istediğimiz başka bir dosyaya gönderilmesini sağlayabiliriz. Bunu yalnızca kabuk işlemi için düşünmeyin. Kabuk üzerinden çalıştırdığımız tüm işlemlerin girdilerini ve çıktılarını istediğimiz dosyaya ya da işleme yönlendirebiliriz. Yani aslında kabuk üzerinde çalıştırmak istediğimiz işlemleri birbirine bağlayarak çalıştırmamız mümkündür. Anlatımın devamında zaten bahsedeceğiz. Bize bu imkanı sağlayan, dosya tanımlayıcılarını istediğimiz gibi yönlendirebilme olanağıdır. Dosya tanımlayıcılara istediğimiz dosyaları atamak üzere de yönlendirme operatörü olarak geçen büyüktür ve küçük işaretlerini kullanıyoruz. Anlatıma, sırasıyla çıktıların aktarılması ile başlayıp devamında girdilerin nasıl alınacağına değinerek devam ediyor olacağız. Öncelikle çıktıların yönlendirilmesiyle başlayalım.

# Çıktıların Yönlendirilmesi

Eğer herhangi bir komutun çıktısını başka bir dosyaya ya da komuta yönlendirmek istersek yönlendirme operatörlerinden biri olan büyüktür işaretini kullanabiliyoruz. 

- **Tek büyüktür işaretini kullandığımızda tek büyüktür** kendinden önceki tüm verileri silip üzerine yenilerini yazıyor.
- **Çift büyüktür işareti** ise var olan verileri koruyarak, verilerin sonuna ekleme yapıyor.

Zaten daha önce dosya oluşturup içerisine yeni veriler eklemek için tekrar tekrar büyüktür yönlendirme operatörünü kullanmıştık. Şimdi tekrar hatırlamak üzere basit bir örnek yapalım. 

Örneğin ben konsola cat > metin.txt şeklinde yazıp onaylarsam, cat komutu benden yeni veriler eklememi bekleyecek. Ben verileri girip, artık yeni veri girmeyeceğimi Ctrl + D kısayolu ile cat komutuna ilettiğimde. Büyüktür operatörü benim cat komutu aracılığı ile girdiğim tüm verileri metin.txt dosyasına aktaracak. Bu noktada eğer metin.txt isimli bir dosya yoksa dosyayı oluşturup içerisine buradaki verileri aktaracak. Eğer dosya varsa, girdiğim veriler metin.txt dosyasının içindeki verilerin üzerine yazılacak, yani dosyanın eski içeriği silinip benim en son yazdıklarım dosyaya yönlendirilmiş olacak.

Öncelikle çalışmakta olduğumuz dizinde metin.txt isimli bir dosya olmadığını teyit etmek için ls komutunu kullanabiliriz. Gördüğünüz gibi bu isimde bir dosya henüz mevcut değil. Şimdi yönlendirme operatörüyle yeni dosyanın oluşturulup oluşturulmayacağını test edebiliriz.

Ben denemek için cat > metin.txt şeklinde yazıp komutumu onaylıyorum. Bakın bende veri eklememi bekliyor. "ilk veri" şeklinde yazıyorum ve Ctrl + D ile veri girişinin sonlandığını haber veriyorum. Tamamdır metin.txt isimli dosya oluşturuldu ve benim girdiğim ilk veri ifadesi de dosya içeriğine kaydedildi. Dosya içeriğini okumak için de yine cat komutunu kullanabiliriz. 

Gördüğünüz gibi dosyaya eklediğim "ilk veri" ifadesi başarılı şekilde kaydedilmiş. Peki ya tekrar aynı komutu verip, bu kez başka ifadeler yazarsam ne olur ? Elbette eski içerik silinip en son yönlendirdiğim veriler kaydolacak. Hadi deneyelim.

Ben bu kez aynı şekilde cat komutu ile metin dosyasına cat > metin.txt şeklinde yönlendirme yapıyorum ve içerik olarak da "ikinci veri" ifadesini yazıp Ctrl + D ile veri girişini sonlandırıyorum. Dosya içeriğini cat komutu ile kontrol edelim.

Bakın tek büyüktür yönlendirme operatörünü kullandığım için, ilk veri silinip üzerine ikinci veri ifadesi yazılmış. İşte tek büyüktür işareti, eğer dosya yoksa yeni bir tane oluşturuyorken, aynı isimli bir dosya mevcutsa o dosya içeriğinin üzerine yeni verileri yazıyor.

Aynı örneği çift büyüktür işareti ile de deneyebiliriz. Ben öncelikle çift büyüktür işareti ile yeni bir dosya oluşturmak istiyorum. Bunun için konsola cat >> yeni-metin.txt şeklinde komutumu giriyorum. Buradaki çift büyüktür sayesinde birazdan burada yazacaklarım yeni-metin.txt dosyasının içeriğine eklenecek. Bu dosya henüz var olmadığı için elbette öncelikle bu dosya oluşturulacak. Ben denemek için "birinci satır" ifadesini giriyorum ve veri girişini Ctrl + D ile sonlandırıyorum. Şimdi cat komutu ile dosyayı okuyalım. Bakın yeni-metin.txt isimli dosyam oluşturulmuş ve içine de benim yönlendirdiğim veriler kaydolmuş. Şimdi tekrar aynı komutu kullanarak dosya içeriğine ekleme yapalım. Ben yine aynı komutu kullanıp bu kez "bu da son satır" şeklinde yazıyorum ve Ctrl + D ile veri girişini sonlandırıp dosyanın kaydolmasını sağlıyorum. Sonucu görmek için dosyamızı açıp okuyabiliriz.

Bakın ikinci yönlendirdiğim veri de dosyanın sonuna eklenerek kaydedilmiş. Yani bu örnekle birlikte çift büyüktür işaretinin; eğer yoksa yeni bir dosya oluşturduğunu fakat aynı isimde dosya varsa dosya içindeki verilere zarar vermeden üzerine ekleme yapmak için kullanıldığını bizzat teyit etmiş olduk. Özetle üzerine ekleme yapmak için çift büyüktür yönlendirme operatörünü kullanıyorken, eskisini silip yenisini ekleme yani üzerine yazma işlemi için de tek büyüktür yönlendirme operatörünü kullanıyoruz.

Ayrıca biliyorum cat komutunu sıklıkla kullanmış olmamıza karşın henüz özellikle ele almadık. 

cat komutunu daha önce de kullandık sıklıkla kullanmaya da devam edeceğiz, çünkü  veri okuma ve yazma konusunda kullanımı ve hatırlaması son derece basit bir araç. Zaten en temel işlevi dosya içeriklerini okumak ve dosya oluşturup dosyalara veri aktarmak olduğu için ek olarak açıklamamız gereken önemli bir detay bulunmuyor. Elbette cat komutunun da pek çok kullanılabilir seçeneği mevcut ancak genellikle istisnai durumalar harici cat komutunu seçeneksiz olarak kullanmak bile son derece yeterli. Yine de merak etmeyin ileride cat komutunu da özellikle açıklıyor olacağım. Şimdi dosyaları ve yönlendirmeleri etkili kullanabilmemiz için gereken temel bilgi altyapısını oluşturmak üzere devam edelim.

Anlatımın devamında, konsola girilmiş olan bir komutun neticesinde üretilen hatalı ve hatasız çıktıları nasıl yönlendirebileceğimizi ele alacağız. Tek bir örnek üzerinden ilerlersek açıklamalar çok daha anlaşılır olacaktır. Ancak tek bir komut ile hem hatalı hem de hatasız çıktılar elde etmek her zaman mümkün olmayabiliyor. Bu yüzden hatalı ve hatasız çıktılarımızı tek bir komut neticesinde üretmek üzere kendimiz betik oluşturup hazırladığımız betiği kullanabiliriz. Neticede betik dosyasının içine kabuğa girebileceğimiz komutları ekleyebildiğimiz ve bunları bu betik dosyasından çalıştırabildiğimiz için örnekleri açıklarken tam olarak işimizi görecek bir betik dosyası oluşturabiliriz.

Hem hatalı hem de hatasız çıktılar üretmek için cat > [betik.sh](http://betik.sh) ile yeni bir dosya açıp içerisine hem hatasız hem de hatlı çıktılar üretecek komutları girebiliriz.

Ben örnek olarak öncelikle echo ile "sorunsuz bir çıktı" ifadesini bastıracağım, bir sonraki komut olarak da aslında var olmayan bir komut yani "asdf" yazıyorum, daha sonra bulunduğum dizini bastıracak pwd komutunu yani hatasız çıktı üretecek komutu giriyorum, daha sonra hatalı çıktı üretmesi için ls - komutunu giriyorum ve son olarak yine echo komutu ile sorunsuz başka bir çıktı daha bastırılmasını sağlıyorum. Ctrl + D ile dosyamı kaydediyorum. Şimdi dosyamıza chmod +x betik komutu ile çalıştırma yetkisi verelim. Bu sayede artık dosyamızı sorunsuzca çalıştırabiliyor olacağız. Dosyayı çalıştırmamız ile, herhangi bir aracı yani komutu çalıştırmamız aynı olacağından betik dosyası bizim ihtiyaç duyacağımız hatalı ve hatasız çıktıları vereceği için iyi bir örnek olacak.  Ben bu betik dosyasını kolayca tek bir komutla çalıştırmak için takma isim tanımlamak istiyorum. Bunun için alias komut=". ~/betik.sh" şeklinde komutumu giriyorum. Bakın konsola komut yazdığım anda betik dosyasının içindeki tüm komutlar çalışıyor. 

```
echo "Sorunsuz bir çıktı"
asdf 
pwd
ls -
echo "Sorunsuz başka bir çıktı daha"

```

Tamamadır, artık neticede hem hatalı hem de hatasız çıktılar üreten tek bir araca sahibiz.

Anlatımın devamında daha önce de açıkladığımız şekilde çıktıları yönlendirirken, standart girdi standart çıktı ve standart hata dosya tanımlayıcılarının rakamsal karşılıklarını yani 0 1 ve 2 rakamlarını kullanıyor olacağız. Hadi hatasız çıktıların nasıl yönlendirilebileceğini öğrenerek devam edelim.

## Hatasız Çıktıların Yönlendirilmesi

Konsoldan aldığımız **hatasız çıktıları** yönlendirmek istediğimizde tek yapmamız gereken hatasız çıktıları temsil eden **1** rakamını, yönlendirme operatörü olan büyüktür işareti ile birlikte kullanmaktır.

Örneğin ben betik dosyasını çalıştırıp yalnızca hatasız olan çıktılarını hatasiz.txt isimli bir dosyaya yönlendirmek istiyorum. Bakın normalde “komut” takma ismiyle betik dosyamı çalıştırdığımda hem hatalı hem de hatasız çıktılar konsola bastırılıyor. Ben hatasız olan çıktıları hatasiz.txt dosyasına yönlendirmek üzere `komut 1> hatasiz.txt` şeklinde komutumu giriyorum.

Bakın konsola yalnızca hatalı olan çıktılar bastırıldı çünkü hatasız olanlar dosyaya yönlendirildi. Teyit etmek için cat komutu ile hatasiz.txt dosyasını da okuyalım. Bakın bu dosyada da yalnızca hatasız olan çıktılar bulunuyor. Yani teyit edebildiğimiz üzere hatasız çıktıları dosyaya yönlendirmeyi başardık.

Aslında burada belirtmiş olduğumuz **1** rakamını yazmadan, yalnızca **>** operatörü kullanılarak da hatasız çıktıları dosyaya aktarabiliriz. Çünkü zaten büyüktür yönlendirme operatörü varsayılan olarak standart çıktıları yani hatasız çıktıları temsil ediyor. Dolayısıyla standart çıktıları temsil eden 1 rakamını tekrar kullanmamız gerekmiyor.

Biz özellikle farklı bir rakam belirtmedikçe yönlendirme operatörünün alacağı dosya tanımlayıcısı değeri **1** rakamıdır. Yani daha önceleri de büyüktür işaretini kullanarak komut çıktılarını dosyalara yönlendirirken, aslında **sadece hatasız çıktıları** yönlendirmiş oluyorduk. Hemen söylediklerimizi teyit edelim. Ben bu kez komut çıktılarını yalnızca büyüktür işareti ile hatasız2.txt isimli dosyaya yönlendiriyorum. Bakın konsola yine yalnızca hatalı olan çıktılar basıldı çünkü hatasız olanlar dosyaya yönlendirildi. Şimdi bir de ikinci oluşturduğumuz dosyaya bakalım. Bakın burada yalnızca hatasız olan çıktıları görebiliyoruz. Neticede hatasız çıktıları yönlendirirken aslında 1 rakamını kullanmak zorunda değiliz.

```bash
komut > hatasız2.txt
```

Yönlendirmelerin daha net anlaşılabilmesi için ben ayrıca girdiğimiz komutun arka planda nasıl işlendiğine görselleştirme yoluyla da değinmek istiyorum.

Bu işlem sırasında; ben ilk sanal konsolu kullandığım için kabuğum bu konsolun dosya karşılığı olan /dev/pts/0 dosyasına bağlı. Ben cat > hatasiz2.txt komutunu girdiğim için kabuk bu komutu okuduğunda çalıştıracağı komutun standart çıktılarının artık hatasız2.txt dosyasına yönlendirilmesi gerektiğini öğrenip bu komutun standart çıktısını bu dosyaya yönlendiriyor. Bunun dışında zaten standart girdi ve standart hata için ekstra bir detay belirtilmediğinden, bunlar hala konsolun dosya karşılığı olan /dev/pts/0 dosyasına bağlı kalmaya devam ediyor. Bu durumu da bu şekilde görselleştirebiliyoruz.

![%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%203.png](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%203.png)

Girdiğimiz komut > hatasız2.txt komutu neticesinde, neden yalnızca hatalı olan komutların konsola basıldığı buradaki görsel üzerinden net biçimde anlaşılıyor. İşte yönlendirme mekanizması bu şekilde çalışıyor. 

Biz hatasız olan çıktıları yönlendirdik. Dilersek yalnızca hatalı olanları da istediğimiz şekilde yönlendirebiliriz. 

## Hatalı Çıktıların Yönlendirilmesi

Şimdi de yalnızca hatalı çıktıları bir dosyaya aktaralım. Bunun için hatalı çıktıları temsil eden dosya tanımlayıcı sayısını kullanmamız yeterli. Hatalı çıktıların varsayılan olarak 2 numaralı dosya tanımlayıcısı ile ifade edildiğini biliyoruz. Bu sebeple ben `komut 2> hatali.txt` şeklinde komutumu giriyorum. Bakın şimdi de konsola yalnızca hatasız olan çıktılar bastırılmış oldu çünkü hatalı olanları dosyaya yönlendirdik.

```
komut 2> hata.txt
```

Hatalı çıktıları görmek için yönlendirdiğimiz dosyayı cat komutu ile okuyabiliriz. Görebildiğiniz gibi hatalı çıktılar da bu dosyaya yönlendirilmiş.

Arka plandaki işleyişe tekrar diyagram üzerinden bakacak olursak, 2 rakamı sayesinde komutun ürettiği hatalı çıktılar /dev/pts/0 yerine hatali.txt dosyasına yönlendirilmiş oldu. Standart girdi ve standart hata için herhangi bir ek yönlendirme bildirilmediği için de bu kez yalnızca hatasız çıktılar konsola bastırılmış oldu.

![%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%204.png](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%204.png)

Diyagram üzerinden de ele aldığımızda yönlendirmelerin ne kadar basit yapıda olduğunu daha net görebiliyoruz. Burada dikkat etmeniz gereken detay yönlendirme için kullandığınız büyüktür operatörünün ihtiyacınıza göre tek veya çift büyüktür olması.

Yönlendirmeler esnasında tek büyüktür işareti kullandığımız için çıktıların, hedefteki dosyanın üzerine yazıldığını biliyorsunuz. Dolayısıyla hata çıktılarını yığınlar halinde dosyaların sonuna kaydetmek isterseniz, elbette ele aldığımız örnekleri çift büyüktür işareti ile uygulayabilirsiniz. Örneğin ben hatalı.txt dosyasının üzerinde eklenmesini istediğim için komutumu komut 2>> hatali.txt şeklinde tekrar giriyorum. Şimdi dosya içeriğini kontrol edelim. Bakın çift büyüktür işaretini kullandığım için hatalı çıktılar tekrar dosyanın sonuna eklenmiş. Zaten çift yönlendirme operatörünün, mevcut verilerin üzerine ekleme yaptığını daha önce de test etmiştik. Bu örneğimizde de ele aldığımız şekilde, ihtiyacınıza uygun şekilde tek veya çift operatör kullanmanız gerekiyor.

Tüm bunlara ek olarak elbette istersek hatalı ve hatasız çıktıları tek seferde iki ayrı dosyaya da yönlendirebiliriz. Ben örnek olarak hatalı ve hatasız çıktıları daha önce oluşturduğum dosyalara eklenecek şekilde yönlendirmek istiyorum. Bunun için komutumu komut >> hatasiz.txt 2>> hatali.txt şeklinde giriyorum. Burada hatalı veya hatasız çıktılarından hangisini ne sırada yazdığımız önemli değil. Tam tersi şekilde de yazabilirdik. Bakın konsola hiç bir çıktı basılmadı çünkü çıktılarımız dosyalara yönlendirilmiş oldu. cat komutu ile ikisini de aynı anda açıp kontrol edebiliriz. Bakın hatalı çıktılar hatalı.txt dosyasına, hatasız olanlar da hatasız.txt dosyasına eklenmiş. Ben sonuna eklenecek şekilde komut verdim. İstersek üzerine yazılacak şekilde de aynı anda iki çıktıyı da yönlendirebiliriz. Ben üzerine yazılması için bu kez komutumu tek yönlendirme operatörleri ile giriyorum. Bakın yine konsola herhangi bir çıktı basılmadı çünkü çıktılar, ilgili dosyalara yönlendirildiler. Yönlendirmeleri teyit etmek için dosyalarımızı da tekrar cat komutu ile okuyalım. Bakın eski içerikler silinip yalnızca en son yönlendirdiklerimiz uygun dosyalara kaydedilmiş. Yine hatasızlar “hatasız.txt” dosyasında, hatalı olanlar da “hatalı.txt” dosyasında görülebiliyor.

Sizler de bu şekilde hatalı veya hatasız çıktılarınızı istediğiniz biçimde ilgili dosyalara yönlendirebilirsiniz. Bu yönlendirme diyagramına da kısaca göz atacak olursak. Bakın hatasız çıktıları temsil eden 1 dosya tanımlayıcısı hatasiz.txt dosyasına yönlendiriliyor. Ben komut sırasında 1 rakamını kullanmadım ama zaten kullanmadığımızda bu yönlendirme operatörünün varsayılan olarak 1 rakamını yani standart çıktıyı temsil ettiğini biliyoruz. Benzer şekilde hatalıları temsil eden 2 numaralı dosya tanımlayıcısı da hatali.txt dosyasına yönlendiriliyor. Zaten bu sebeple konsola hiç bir çıktı basılmıyor. 

Tamamdır, çıktıları ayrı ayrı nasıl istediğimiz dosyalara yönlendirebileceğimizi öğrendik. Şimdi de hatalı ve hatasız çıktıları tek seferde nasıl tek bir istikamete yönlendirebileceğimizden bahsederek devam edelim.

## Hatalı ve Hatasız Çıktıların Birlikte Yönlendirilmesi

Eğer hem hatalı hem de hatasız çıktıları tek bir dosyaya yönlendirmek istersek, **ampersant**(**&**) işaretini kullanabiliyoruz. Ampersant işaretini yönlendirme operatörlerinden önce veya sonra kullanabiliriz. Ben denemek için betik dosyamı `komut &> sonuc.txt` komutu ile çalıştırıyorum. Konsola herhangi bir çıktı basılmadı, çünkü hatalı ve hatasız tüm çıktılar sonuc.txt dosyasına yönlendirildi. Hemen sonuc dosyasının içeriğine göz atalım.

Bakın sonuc.txt dosyası hem hatalı hem de hatasız çıktıların hepsini içeriyor. Ben bu örnekte ampersant işaretini yönlendirme operatöründen önce kullandım, ancak istersek yönlendirme operatöründen sonra da kullanabiliriz. Hemen deneyelim. Ben bu kez ampersant işaretini yönlendirme operatörünün sonuna ekliyorum ve sonuc2.txt dosyasına kaydediyorum. 

Dosyamı okuduğumda aynı şekilde hatalı ve hatasız çıktıların sorunsuzca yönlendirilmiş olduğunu teyit edebiliyorum. 

Özetle her iki kullanımda geçerlidir ancak ampersant işaretinin önde olduğu ilk kullanım daha sık tercih edilir. Hatta isterseniz önceki verilerin sonuna eklenmesi için çift yönlendirme operatörünü de kullanabilirsiniz. Yani komutumuzu komut &>> sonuclar.txt şeklinde tekrar girersek, hatalı ve hatasız çıktıların hepsi sonuclar.txt dosyasının sonuna eklenmiş olacak. Denemek için komutumuzu bu şekilde de girelim. Tamamdır, şimdi dosya içeriğini açıp bakalım. Bakın dosyanın sonuna eklenmiş. Yani çift yönlendirme parametresi tam olarak beklediğimiz şekilde çalıştı.

```
komut &> hatalı-hatasız.txt
komut >& hatalı-hatasız.txt
```

Tekrar ampersant işaretine odaklanacak olursak, bu kullandığımız operatör aslında bir kısayoldur. Biz bu kısayolu kullandığımızda yönlendirme diyagramı bu şekilde gözüküyor. 

![%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%205.png](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%205.png)

Diyagramda, hatalı çıktıları temsil eden 2 dosya tanımlayıcısını öylesine 1 e bağlanmış gibi göstermedim. Girdiğim komut tam olarak diyagramdaki şekilde çalışıyor. Bu diyagramı dana net anlamak için, hatalı ve hatasız çıktıları bir arada yönlendirmeyi sağlayan bu kısayol yerine tercih edilen diğer yönlendirme biçimlerini de ele almak istiyorum.

En kolay yöntem bu ele aldığımız yöntem olsa da söz konusu yönlendirme olduğunda aynı işi pek çok farklı yoldan yapabiliyoruz.

Tüm alternatifleri kullanmayacak olsanız bile farklı yöntemleri ele alırsak, yönlendirme yapısının nasıl çalıştığına dair daha net bir fikir edinebilirsiniz. Şimdi ele alacağımız yöntem sıklıkla kullanılan bir alternatiftir. Özellikle bash kabuğu için yazılmış olan betik dosyalarını incelerken ya da internet üzerinde yer alan rehber anlatımları takip ederken bu yönlendirme biçimi ile sık karşılaşmanız olasıdır. Ben öncelikle komutumu girip daha sonra bu komut üzerinden yönlendirmenin nasıl işlediğini açıklıyor olacağım. 

Örneğin ben konsola `komut > sonuclar.txt 2>&1` komutunu girdiğimde de hatalı ve hatasız çıktılar sonuclar.txt dosyasına yönlendiriliyor. cat komutu ile tüm çıktıların burada olduğunu teyit edebiliriz. Bakın hem hatalı hem de hatasız olan çıktılar bu dosyaya yönlendirilmiş.

Şimdi girmiş olduğum komuta geri dönecek olursak, belki bu girmiş olduğum komut ilk bakışta biraz karmaşık gelmiş olabilir, ancak hiç de karmaşık değil. Kısaca adımları açıklayacak olursak;

Öncelikle bilmemiz gereken bash kabuğunun birden fazla yönlendirme ile karşılaştığında, yönlendirmeleri soldan sağa doğru okuyup değerlendirdiğidir. 

Burada girmiş olduğum komutta, **ampersant**(**&**) işareti yol gösterici olarak çalışıyor. İşaretin tam olarak ne anlam ifade ettiğini örnek üzerinden daha net görebiliriz.

Adımları inceleyelim ve bunun nasıl olduğunu görelim. Herhangi bir komutu çalıştırmadan önce Bash'in dosya tanımlayıcı tablosu bu şekilde görünüyor: Bakın tüm yönlendirmeler konsol aracının dosya karşılığına bağlı.

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%206.png)

Bash, komutu okuyup ilk yönlendirmeyi gördüğünde, hatasız çıktıları sonuclar.txt dosyasına yönlendirilecek şekilde ayarlıyor. 

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%207.png)

Bash ikinci yönlendirmeyi okuduğunda ise, hatasız çıktıların yönlendirileceği adresi kopyalayıp, hatalı çıktıların yönlendirileceği yeni adres olarak ayarlıyor. Yani 2 numaralı dosya tanımlayıcısına ampersant işareti sayesinde 1 numaralı dosya tanımlayıcısının **mevcut adresini kopyala** demiş oluyoruz. Diğer bir deyişle 1 numaralı dosya tanımlayıcısı nereye işaret ediyorsa sen de oraya git demiş oluyoruz. 

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%208.png)

Bu sayede 1 numaralı dosya tanımlayıcısının yönlendirildiği dosya adresi, 2 numaralı dosya tanımlayıcısı için de tanımlanarak, hem hatalı hem de hatasız çıktılar aynı dosyaya yönlendirilmiş oluyor.

Eğer çalışma yapısının bu şekilde olduğuna emin olamadıysak yönlendirmelerin sırlamasını değiştirerek tekrar test edebiliriz. Ben yönlendirme sıralamasını değiştirip komutumu bu kez `komut 2>&1 >sonuclar2.txt` şeklinde giriyorum. 

Ve sonuç olarak gördüğünüz gibi konsola hatalı çıktılar basıldı. Bir de sonuclar2 dosyasının içeriğine göz atalım. Bakın hatasız çıktıların da bu dosyaya kayıt olduğunu görebiliyoruz. Peki ama neden bu şekilde oldu ? Neticede yalnızca komutun sıralamasını değiştirdik. Gelin adım adım açıklayalım.

Komutu çalıştırmadan önce dosya tanımlayıcı tablosu yani yönlendirmeler bu şekildeydi.

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%209.png)

Bash ilk yönlendirmeyi okuduğunda, hatasız çıktıların yönlendirileceği adresi kopyalayıp hatalı çıktıların yönlendirileceği adres olarak ayarladı. Bu aşamada hatasız çıktılar konsola basılmak üzere mevcut konsola yönlendirilmiş olduğu için hatalı çıktılar da mevcut konsola yönlendirilmiş oldu.

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%2010.png)

İlk yönlendirmenin ardından bash ikinci yönlendirmeyi okudu ve komutta öyle belirtildiği için hatasız çıktıları sonuclar2.txt dosyasına yönlendirdi. Yani yönlendirme diyagramı en son bu hale gelmiş oldu.

![Untitled](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%2011.png)

Bu yapı gereği de hatasız çıktılar belirtilen dosyaya aktarılırken, hatalı çıktılar konsola yönlendirilerek bastırılmış oldu.

Kabuğun soldan sağa doğru okuyup yönlendirme yaptığını bilmeyen kişiler, bu duruma dikkat etmediğinde ikinci örneğimizde olduğu gibi istediklerinden farklı sonuç alırlar. İşte neyi niçin yaptığınızı bilirseniz, çok daha bilinçli hareket edip verimli sonuçlar elde edebilirsiniz. Zaten bu sebeple mevcut eğitim boyunca öncelikle kabuğun ve ihtiyaç duyacağımız diğer yapıların temelde nasıl çalıştıkları hakkında bilgi edinmeye çalışıyoruz. Yani kimi zaman bazı detaylar sizi sıksa veya gereksiz gibi görünse bile hepsinin eğitimin önemli yapıtaşları olduğu için ele alındığını lütfen unutmayın. Şimdi konumuza dönecek olursak.

Buradaki örneğimiz üzerinden de bizzat fark ettiyseniz bash, ilgili komutu çalıştırmadan önce yönlendirmeleri soldan sağa doğru okuyup ayarlıyor, komutu en son çalıştırıyor. Bu sebeple eğer yönlendirme hatalı yapıldıysa tüm komut başarısız olacaktır. Komut çalıştırılmadan önce yönlendirmelere bakılmasının avantajı, yönlendirilme hatalı ise boşuna komut çalıştırılarak kaynak israfı yapılmamasıdır. Bu durum hızlı açılıp kapanabilen araçlar için çok önemli olmasa da, açılması uzun süren ve fazla kaynak tüketen uygulamalar eğer yönlendirme hatalı ise boşuna çalıştırılmamış oluyor. Bu sayede zamandan ve sistem kaynaklarından tasarruf edilmiş oluyor. 

Ayrıca işleyişi daha iyi anlamak adına girdiğimiz komutun sıralamasını uygun şekilde değiştirmemiz de mümkün. Örneğin biz normalde komut > sonuc.txt 2>&1 şeklinde komutumuzu girdiğimizde;

hatasız çıktılar sonuc.txt dosyasına yönlendirilirken, hatalı çıktılar da hatasız çıktıların işaret ettiği dosyaya yani yine sonuc.txt dosyasına yönlendiriliyor.

Bunun yerine hatalı çıktıları bir dosyaya yönlendirip, hatasız çıktıların da hatalı çıktıların yönlendirildiği adresi takip etmesini sağlayabiliriz. Bu noktada videoyu durdurup komutu nasıl girebileceğinizi düşünmenizi ve denemenizi istiyorum. 

Ben şimdi devam ediyorum. İstediğim yönlendirme şeması için öncelikle komut 2> sonuc2.txt şeklinde yazıp hatalı çıktıların sonuc2.txt dosyasına yönlendirilmesi gerektiğini belirtebiliriz. Daha sonra hatasız çıktıların da hatalı çıktılar nereye yönlendiriliyorsa oraya yönlendirilmeleri için >&2 şeklinde komut girmemiz yeterli. Buradaki ampersant işaretiyle birlikte standart çıktıların, standart hata çıktılarının takip etmesi gerektiğini belirtmiş oluyoruz. Burada standart çıktılar için özellikle 1 rakamını eklemem gerekmiyor çünkü daha önce de belirtiğim şekilde büyüktür yönlendirme operatörü zaten varsayılan olarak standart çıktıları yönlendirmemizi sağlıyor. Yani buraya 1>&2 şeklinde de girebilirdik ancak komutumuzu uzatmaya gerek yok. Komutumuzu onaylayalım. Bakın konsola herhangi bir çıktı bastırılmadı. Şimdi bir de sonuc2.txt dosyasının içeriğini kontrol edelim. Bakın tıpkı daha önceki yönlendirme biçimlerinde olduğu gibi bizim girdiğimiz bu komut da hem hatalı hem hatasız çıktıları sonuc2.txt dosyasına sorunsuzca yönlendirmiş oldu. 

Bizzat bu örnek üzerinden de görebildiğimiz gibi önemli olan temel çalışma prensibini bilmek. Temelleri bildiğimizde aynı işi pek çok farklı şekilde yapabilecek yetkinliğe sahip oluyoruz. Girdiğimiz komutların ve sonuçlarının da farkında olarak sistemimizi ezberle değil bilinçli şekilde yönetebiliyoruz. 

Hatalı ve hatasız çıktıları tek bir ortak hedefe yönlendirirken hep üzerine yazma metodunu uyguladığımızı fark etmişsinizdir. Yani örneğin ben en son girdiğim komutu tekrar girersem, hatalı ve hatasız çıktılar sonuc2.txt dosyasının üzerine yazılacak. Emin olmak için komutumuzu tekrar girelim. Şimdi dosyamızın içeriğini kontrol edelim. Bakın daha önceki çıktılar silinip yeni çıktılar yazılmış. Eğer dosyanın sonuna ekleme yapılıyor olsa aynı çıktıların iki kez basıldığını görecektik.

Üzerine yazma işlemi yerine ekleme işlemi için çift yönlendirme operatörünü kullanabileceğimizi daha önce örnekler üzerinde gördük. Şimdi ele aldığımız yönlendirme biçimleri üzerinde nasıl kullanabileceğimize göz atalım.

Örneğin komut 2&> dosya şeklinde komutumu girebilirim. Bakın hatalı ve hatasız çıktılar dosyaya kaydedilmiş. Şimdi komutumuzu tekrar girecek olursak, yeni çıktılar eskilerinin üzerine yazılacak. Görmek için komutumuzu tekrar girelim. Şimdi dosya içeriğini tekrar okuyabiliriz. Bakın, yeni yönlendirilen veriler eskilerinin üzerine yazılmış. Üzerine yazılması yerine dosyanın sonuna eklenmesini istersek buradaki tek yönlendirme operatörünü çift hale getirebiliriz. 

Komutumu komut 2&>> dosya şeklinde giriyorum. Şimdi dosya içeriğini tekrar görüntüleyelim. Bakın bu kez çift yönlendirme operatörü sayesinde dosyanın sonuna eklenmiş. Bu yönlendirme biçiminde ekleme işlemi gayet sıradan. Ancak diğer yönlendirme biçimlerinde dosyaya ekleme yapmak üzere yönlendirme işlemlerinde dikkat etmemiz gereken bir detay bulunuyor.

Örnek üzerinden görmek için komutumuzu komut > dosya 2>>&1 şeklinde girelim. Bakın ikinci yönlendirme tanımında çift yönlendirme işareti kullandığım için ve bu işaret & işaretinden önce geldiği için bash kabuğu hata verdi. Bunun yerine takip edilen yönlendirme tanımına çift yönlendirme operatörü ekleyebiliriz. Yani komutumuzu komut >> dosya 2>&1 şeklinde girebiliriz. Bakın bu kez herhangi bir hata almadık. Yönlendirdiğimiz veriler dosyaya eklenmiş mi diye kontrol etmek için dosyayı açabiliriz. Bakın yönlendirme işlemi sonucu son çıktılar da dosyaya eklenmiş. 

Sizin de tahmin ettiğiniz gibi komutumuzu komut 2>> dosya >&2 şeklinde de girebiliyoruz. Bakın bu kullanım biçimi sayesinde hatalı çıktıların dosyaya eklenmek üzere yönlendirilmesini, hatasız çıktıların da bu yönlendirmeyi takip etmesini sağladık. 

Tüm bunlar dışında eğer çıktıları hiç bir yere yönlendirmek istemiyorsak, bu iş için özel olarak mevcut bulunan /dev/null dosyasına yönlendirebiliriz. /dev dizini altındaki null isimli dosya isminden de anlaşılabileceği gibi boşluğu temsil ediyor. Bu dosyaya yönlendirilen veriler hiç bir yere kaydolmuyor. Bu sayede istemediğimiz tüm çıktıları bu dosyaya yönlendirerek yok edebiliyoruz. Hemen denemek için basit bir örnek yapalım.

Örneğin betik dosyamı çalıştırdığımda gördüğünüz gibi hem hatalı hem de hatasız çıktılar konsola yönlendiriliyor. Eğer hatalı çıktıları yok etmek istersek komut 2> /dev/null şeklinde komutumuzu girip, hatalı çıktıları /dev/null dizinine yönlendirebiliriz. Bakın konsola hatalı bir çıktı bastırılmadı. Hatta bu çıktıların yok edildiğini yani boşluğa gönderildiğini teyit etmek için cat /dev/null komutu ile yönlendirdiğimiz dosyayı da okumayı deneyebiliriz. Ben cat /dev/null komutu ile bu dosyayı okumayı deniyorum. Bakın dosya içeriği tamamen boş çünkü aslında bu dosya verileri boşluğa göndermek için kullanılan sanal bir dosya. Yani biz yönlendirsek de içerisinde hiç bir veri tutmuyor çünkü bu dosya bizim bildiğimiz standart dosyalardan değil. Daha önce linux üzerinde her şeyin bir dosya gibi ele alından bahsetmiştik. İşte bu dosya da bu yaklaşımın bir sonucu. Siz de istemediğiniz tüm verileri /dev/null dosyasına yönlendirip onlardan kurtulabilirsiniz. Bu dosya disk üzerinde yer alan gerçek bir dosya olmadığı için disk üzerinde okuma yazma yükü oluşturmaz. Bu ve benzeri dosyalar, çekirdek tarafından sanal olarak oluşturulan ve bellek yani geçici hafıza üzerinden çalıştırılan sözde dosyalardır. Bu yaklaşım sayesinde disk üzerinde yük oluşturma durumundan da endişe etmemize gerek kalmıyor.

Anlatım biraz uzadı ancak yönlendirmeye dair karşınıza çıkabilecek tüm temel yaklaşımları ele almış olduk. Şimdiye kadar hep çıktıların yönlendirilmesinden bahsettik, artık biraz da girdilerin yönlendirilmesini ele alarak devam edelim.

# Veri Giriş Yönlendirmesi

Çıktıları yönlendirmeyi ele aldık. Şimdi de girdileri nasıl yönlendirebileceğimizi ele alalım. Veri girişinin hangi şekilde yapıldığına göre kullanmamız gereken yönlendirme operatörü de değişiklik gösteriyor. Sırasıyla bu operatörlerimizi tanıyalım. Dosyaların veri girişi için kullanılmasıyla başlayabiliriz. 

## Dosyaların Veri Girişi İçin Kullanılması

Dosyadan veri yönlendirmesi yapmak için tek bir küçüktür işareti kullanmamız yeterli. Yani komutumuzu komut < dosya_adı şeklinde girebiliyoruz.

```bash
komut < dosya_adı
```

Bunu yaptıktan sonra dosya tanımlayıcı tablosu şu şekilde görünür:

![%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%2012.png](%E2%9C%85%209-%20Dosya%20I%CC%87s%CC%A7lemleri%20PART%201%202c24716f0baf436698d3636f994bc1ee/Untitled%2012.png)

Olası kafa karışıklığını önlemek adına kısaca tabloyu da açıklayabiliriz. Gösterimdeki 0 dosya tanımlayıcısı okunun ters olması gerektiğini düşünmüş olabilirsiniz. Ancak burada 0 dosya tanımlayıcısı varsayılan olarak tanımlandığı üzere "okuma" işlevindedir. Dolayısıyla 0 dosya tanımlayıcısı kendisine işaret edilen dosyayı, okuyacağı dosya olarak kabul ediyor. Bu sebeple gösterimdeki okun yönü doğrudur.

Hatta bu durumu yani 0 dosya tanımlayıcısının yalnızca okuma yaptığını bir örnek üzerinden teyit edebiliriz. Örneğin ben konsola echo "veri gönderiyorum" şeklinde yazıp bu veriyi 1> yönlendirme operatörü ile veri.txt isimli bir dosyaya yönlendirebilirim. Dosya içeriğini okuyalım. Bakın dosyanın içerisine "veri gönderiyorum" ifadesi kaydolmuş. Şimdi aynı örneğin bu kez 0 numaraları dosya tanımlayıcı ile deneyebiliriz. Ben bu kez komutumu echo "yeni veriler" 0> veri2.txt şeklinde yazıyorum ve onaylıyorum. Bakın çıktı doğrudan konsola bastırılmış oldu. Çünkü 0 numaralı dosya tanımlayıcısı veri okuma işlevindedir. Ama dosyamız büyüktür yönlendirme operatörünü kullandığımız için oluşturuldu. Bakın listelediğimizde görebiliyoruz. cat komutu ile içeriğini okumayı da deneyebiliriz. Gördüğünüz gibi içeriği boş. Çünkü zaten çıktının konsola bastırıldığını gördük. Böylelikle 0 dosya tanımlayıcısı yalnızca verileri okumak için kullanıldığını teyit etmiş olduk.

Şimdi dosya içeriğinin standart girdiden okunmasını sağlayalım. Henüz dosyaları değiştirmemizi sağlayan temel araçları ele almadığımız için şimdilik basit bir örnek vereceğim. Ancak ileride farklı araçları tanıdığımızda, standart girdiden veri kabul eden araçlara tıpkı burada yapacağımız örnekteki gibi veri gönderebiliyor olacağız. 

Normalde cat komutu zaten kendisine argüman olarak verilen dosyanın içeriğini konsola bastırıyor. Benzer şekilde < küçüktür yönlendirme operatörü ile cat komutunun, belirttiğimiz dosyayı okuyup konsola çıktı olarak bastırmasını da sağlayabiliriz. Buradaki küçüktür işareti 0 dosya tanımlayıcısı olmadan da doğrudan ilgili komutun standart girdisine yönlendirme yapıyor. Yani cat <0 okunacak-dosya komutu yerine doğrudan cat < okunacak-dosya şeklinde de komutumuzu girebiliyoruz. 

Gördüğünüz gibi verileri küçüktür işareti sayesinde cat aracına girdi olarak yönlendirebildik. Biliyorum cat komutu çok basit bir örnek oldu. Ancak merak etmeyin ileride pek çok farklı komut üzerinde bu veri girişi yönlendirmesini kullanıyor olacağız. Şimdilik veri girişinin nasıl çalıştığını öğrenmemiz yeterli.

Bu operatörün kullanımında dikkat edilmesi gereken, bütün komutların bu yönlendirme operatörünün kullanımı için uygun olmadığıdır. Yani herhangi bir komuta veri girişi yönlendirmesi yapabilmemiz için, kullanmış olduğunuz komutun yönlendirme operatöründen gelecek veriyi kabul edecek yapıda olması gerekiyor.

Örneğin `cat` komutu veri girişi yönlendirme operatörünü tanıyorken, `echo` komutu bu operatörü tanımaz.

Tekrar denemek için cat komutu yerine örneğin echo komutuna dosyayı standart girdiden okuması için aynı şekilde yönlendirme yapabiliriz. Bakın echo komutu dosyanın içeriğini bastırmadı. Çünkü echo komutu yalnızca kendisine argüman olarak verilmiş olan karakterleri işleyip konsola bastırıyor. Yani standart girdi olarak geçen dosya tanımlayıcısını okumuyor ancak standart çıktı ve standart hata dosya tanımlayıcılarına veri gönderiyor. Zaten bu durumdan bahsetmiştik.

Bu gibi komutlar arasındaki farklılıkların en temel nedeni, her komutun yani aslında her bir aracın tanımlandığı görev dahilinde hareket edebilen fonksiyonel programlar olmasıdır. Yani bizzat deneyimleyebildiğimiz gibi komutların sınırsız özellikleri ya da sezgisel tepkileri bulunmuyor. Bu yüzden veri girişini bu şekilde küçüktür işareti ile gerçekleştirdiğinizde, kullanmış olduğunuz komutun standart girdiden veri kabul ettiğine emin olmanız gerekiyor.

## Satırların Veri Girişi İçin Kullanılması

Verileri dosyadan yönlendirmek yerine yalnızca komut satırına yazacağımız bir grup verinin aktarılmasını da sağlayabiliriz. Örneğin biz yalnızca cat komutunu yazıp enter ile komutu onayladığımızda cat komutu bizden veriler girmemizi bekliyor. Ben ilk satır şeklinde yazıp enter ile onayladığımda bakın yazdığım ifade cat komutu tarafından tekrar konsola bastırıldı ve hala benden yeni veriler girmemi bekliyor. Ben ctrl + d tuşu ile veri girişini sonlandırdığımı belirtene kadar da bu şekilde benim yazıp enter ile onayladığım her bir satırı tek tek işleyip konsola bastıracak. Fakat fark edebileceğiniz gibi bu kullanımda benim birden fazla satırı tek seferde bastırmam mümkün değil. Yalnızca tek satır tek satır bastırabiliyorum, çünkü ben bir alt satıra geçmek için enter tuşuna bastığımda yazdığım satıdaki ifadeler cat komutu tarafından işlenip benden başka bir satır girmem bekleniyor. Bu sorunu aşmak için cat komutuna, birden fazla satırı olan ifadeler gireceğimizi belirtmemiz gerekiyor. Bunun için de çift küçüktür yönlendirme operatörünü kullanabiliriz. Hemen deneyelim. Ben tekrar cat komutunu yazıp daha sonra çift küçüktür işaretini koyuyorum. Hemen ardından cat komutunun kolayca algılayabileceği bir sınır belirtmem gerekiyor. Ben ayırt edilebilir olması için büyük harfler ile EOF ifadesini ekleyip enter ile bir alt satıra geçiyorum. Artık dilediğim kadar satır atlayıp bütün halinde girmek istediğim verileri yazabilirim. Ben birden fazla satıra rastgele ifadeler ekiyorum. Normalde biliyorsunuz alt satıra inmek için enter tuşuna bastığımızda cat komutu yazdıklarımızı doğrudan işleme alıyor. Ancak biz burada çift küçüktür yönlendirme operatörünü kullandığımız ve hemen onun yanına sınırlayıcı EOF ifadesini eklediğimiz için cat komutu tekrar EOF ifadesini görene kadar bizden girdi almaya devam edecek. Eğer benim yazacaklarım bittiyse yazdıklarımın cat komutuna girdi olarak iletilmesi için başta belirttiğim sınırlayıcının aynısını yazıp enter tuşuna basabilirim. Bakın başta kullandığım sınırlayıcıyı sonda kullanıp enter ile onaylar onaylamaz girdiğim tüm satırlar cat aracına girdi olarak aktarıldı. Sizler de bu şekilde konsol üzerinden istediğiniz araca istediğiniz kadar veriyi aktarabilirsiniz. Gireceğiniz verilerin bittiğini, baştaki sınırlayıcı karakteri kullanarak özellikle belirtmediğiniz sürece konsola yazdıklarınız ilgili araca yönlendirilmez.

```bash
cat <<EOF 
> Ben ilk satıra yazılanlarım
> ben ikinci satırım
> bu böyle uzar gider..
EOF
```

Ancak bu kullanımda dikkat edilmesi gereken nokta, biz sınırları belirtmediğimiz sürece konsolun sonsuza kadar bizden veri girişi bekleyecek olmasıdır. Bu sebeple mutlaka gireceğimiz verilerin en başında ve en sonunda aynı sınırlayıcı ifadeyi kullanarak veri girişinin kapsamını belirtmeliyiz.

Burada benim sınırlama için kullandığım "EOF" ifadesi "end of file" yani dosya sonu anlamına geliyor ve benim girdiğim verilerin kapsamını belirtmemi sağlıyor. 

Sınır belirtirken yalnızca EOF ifadesini kullanmak zorunda da değiliz. EOF yerine herhangi bir ifade de kullanabiliriz ancak pek çok kişinin ortak olarak sınırları belirtmek için kullandığı ifade EOF kısaltmasıdır. Sıklıkla bu ifadeyle karşılaşacağınız için ben de bu şekilde belirttim.  Hemen farklı bir sınırlayıcı belirterek aynı işlemi tekrar deneyelim. Ben bu kez cat <<SINIR şeklinde komutumu giriyorum. Sınırlayıcının hepsini büyük harfle yazma nedenim ben veri girerken bu ifade ile kesişecek bir veri girmekten kaçınabilmek. Neticede sınır olarak belirttiğim ifadeyi bir kez daha kullanıp enter ile onayladığımda tüm verilerimi girmeyi tamamladığım anlamına gelecek.

Bakın bu şekilde de istediğim kadar satır atlayıp veri girebiliyorum. Veri girişini sonlandırıp verileri cat komutuna yönlendirmek için SINIR yazıp enter ile onaylıyorum. Bakın girdiğim veriler cat komutuna girdi olarak aktarıldı, cat komutu da konsola bunları bastırdı.

Aslında bizler bu sınırlayıcı kavramına hiç de yabancı değiliz. Hatırlarsanız cat komutu ile dosya içerisine veri yazarken yazdıklarımız bittiğinde hep ctrl d tuşlaması ile bunu belirtmiştik.

İşte burada yazılı şekilde belirttiğimiz sınırlayıcıya benzer şekilde bizlerden sonsuzca kadar veri girişi bekleyecek programları sonlandırmak istediğimizde de veri girişinin sonlandığını Ctrl + D kısayolu ile belirtebiliyoruz. Bu kısayolu kullandığımızda "delimiter" yani "sınırlayıcı" mekanizması devreye girip programa, "tamam yazacaklarım bu kadardı artık bu verileri alıp işleyebilirsin" demiş oluyor. Zaten eğitim içerisinde cat komutu ile dosya oluştururken bu durumu tekrar tekrar gözlemlemiştik. cat komutu haricinde sizden veri bekleyen tüm araçlara veri girişinizi sonlandırdığını bildirmek için ctrl d tuşlamasını kullanabilirsiniz.

## Tek Bir Satırın Veri Girişi İçin Kullanılması

Eğer herhangi bir araca, yalnızca tek bir satırla veri yönlendirmesi yapmak istersek üç küçüktür işaretini kullanabiliyoruz. Yönlendirmeyi denemek için yine cat komutunu kullanabiliriz. Normalde `cat` komutu argüman olarak, konsola bastırılacak olan dosyanın ismini bekliyor. Yani konsoldan yazdığımız verileri doğrudan alıp bastırmaz. Bunun için özellikle yönlendirme operatörü kullanmamız gerekiyor. Zaten bir önceki yönlendirme metodunda sınırlayıcı belirterek  birden fazla satırı cat komutuna nasıl yönlendirebileceğimizi ele almıştık. Şimdi de tek bir satırı kolayca yönlendirmek üzere üç küçüktür işaretini kullanabiliriz. 

Eğer bir önceki metotta olduğu gibi yalnızca iki küçüktür işaretini kullanırsak, başında ve sonunda sınır belirtmemiz gerekeceği için tek satırlık veri girişlerinde bu pek de pratik bir yöntem olamayacak. Hatta sınırlayıcı belirtmeden çift küçüktür işareti ile cat komutuna veri girişi yönlendirmeyi de deneyebiliriz. Bakın hata aldık çünkü herhangi bir sınırlayıcı belirtmedik.

Bunun yerine üç küçüktür işaretinin hemen ardından ilgili komutun standart girdisine yönlendirmek istediğimiz verileri tek satırda yazıp yönlendirebiliriz. Ben denemek için cat <<<”bu bir test” şeklinde yazıp komutumu onaylıyorum. Burada tırnak içinde yazmazsak, boşluklarla birbirinden ayrılmış olan kelimeler ayrı argümanlar olarak değerlendirileceği için cat komutuna doğru şekilde iletilmezler. Bakın ben bu yöntemle cat komutuna tek satırda istediğim verileri gönderebildim. 

Gördüğünüz gibi cat komutu benden aldığı verileri görevini yerine getirerek konsol bastırdı. 

Neticede normal şartlarda cat komutu dosya üzerinden veri girişi alıyorken biz konsol üzerinden cat komutuna tek bir satırda veri yönlendirmesi yapmış olduk. Sizler de standart girdiden veri kabul eden tüm araçlara burada öğrendiğiniz şekilde veri girişi yönlendirmesinde bulunabilirsiniz.

Şimdiye kadar bahsettiklerimizi çok kısaca özetleyecek olursak:

Bir dosyayı veri girişi olarak yönlendirecekseniz tek küçüktür işaretinden sonra dosyanın ismini girmeniz yeterli. Ayrıca ben sadece dosya olarak bahsettim ancak farklı araçların çıktılarını da tıpkı dosyalarmış gibi diğer araçlara girdi olarak aktarabilirsiniz. Bu duruma anlatımın devamında diğer araçları da tanıdıkça örnekler üzerinden zaten değiniyor olacağım.

Tek bir dosya veya araç yerine, konsol üzerinden birden fazla satırda veri girişi yönlendirmesi yapmak istiyorsanız da çift küçüktür işaretinin hemen ardından bir sınırlayıcı değer belirtip dilediğiniz kadar veri girişinde bulunabilirsiniz. Veri girişini sonlandırmak istediğinizde de başta belirttiğiniz sınırlayıcı değeri tekrar girip komutunuzu onaylamanız yeterli.

Eğer konsol üzerinden tek bir satırda veri girişi yönlendirmesi yapmak istiyorsanız da üç küçüktür işaretinden sonra tırnak içinde istediğiniz verileri yazıp yönlendirebilirsiniz.

Böylelikle dosya tanımlayıcıları ve verilerin yönlendirilmesi için gereken temel altyapıyı edindik. 

Yönlendirmeler konusunda özellikle bash kabuk programlama sırasında ihtiyaç duyabileceğiniz birkaç farklı detay daha var ama ben konu kapsamını çok genişletmek istemediğim için bu eğitimde diğer detayları pas geçiyorum. GNU bash dokümanlarına yönlendirmeler için göz atarsanız, benim bahsetmediğim diğer açıklamalara da ulaşabilirsiniz.

Şimdi dosyalar üzerinde çalışırken bize yardımcı olan temel araçları öğrenebiliriz. 

# cat Komutu

Şimdiye kadar cat komutunu zaten pek çok kez kullandık, yani aslında gayet iyi tanıyoruz. Yine de ayrıca ele alınacak öneme sahip olduğu için kısaca tekrar bahsetmek istiyorum. Zaten kullanımı oldukça kolay, gelin açıklayalım. cat komutunun ismi "bağlamak, birleştirmek veya sıralamak" anlamlarında olan İngilizce "concatenate" kelimesinden geliyor. Komutun ismi de tam olarak görevini açıklıyor.

cat komutunun en temel işlevi kendisine argüman olarak verilen dosyaların içeriklerini standart çıktıdan konsola yönlendirerek bastırmaktır. Yani aslında dosyaların içeriklerini konsol üzerinden okuyabilmemize olanak tanıyan basit bir komuttur. Var olan bir dosyayı okumak için tek yapmamız gereken, cat komutunun ardından dosyanın ismini girmektir. Ben örnekler sırasında kullanmak için mevcut bulunduğum dizindeki dosya ve klasör isimlerini bir dosyaya kaydetmek istiyorum. Bunun için ls > liste komutunu girebilirim. Buradaki büyüktür yönlendirme operatörü sayesinde ls komutunun standart çıktıları “liste” dosyasına yönlendirilmiş olacak. Bir de ls /usr > liste2 komutu ile usr dizini altındakileri de liste2 dosyasına kaydedelim. Örneğin oluşturduğumuz ikinci dosyanın içeriğini konsola bastırmak istersek cat liste2 şeklinde komutumuzu girebiliriz. Bakın dosyanın içeriği konsola bastırıldı.  Dilersek, aynı anda birden fazla dosyayı da okuyabiliriz. Denemek için diğer dosyanın ismini de giriyorum.

Bakın komutta soldan sağa doğru verdiğim tüm dosyaların içerikleri, sırasıyla yukarıdan aşağıya doğru konsola bastırılmış oldu. Yani aslında isminde olduğu şekilde birden fazla dosyayı birleştirmiş ve konsola bastırmış olduk. Bu şekilde istediğimiz kadar dosyanın birleştirilmesini sağlayabiliyoruz. 

Birden fazla dosya içeriğinin cat komutu aracılığı ile sıralı şekilde birleştirilebiliyor olması size bir fikir verdi mi ? 

Evet, pek çok kişinin tahmin ettiği gibi, eğer istersek birden fazla dosyanın içeriğini tek bir dosyaya yönlendirebiliriz. Yani birden fazla dosyayı tek bir dosyada birleştirebiliriz. Ben liste ve liste2 dosyasını birleştirip nihai-liste isimli bir dosya oluşturmak istiyorum. Bunun için cat liste liste2 > nihai-liste şeklinde komutumu girmem yeterli. Oluşturulan nihai-dosya içeriğini cat komutu ile bastıralım. Bakın iki dosyanın içeriği, tam olarak komutta belirttiğim sıralama ile yani ilk olarak liste dosyası daha sonra liste2 dosyası olacak şekilde birleştirip tek bir dosya haline gelmiş oldu.

Bu örnek cat komutu ve yönlendirme operatörleri ile yapabileceklerimize dair çok basit bir örnek.

Bahsettiğimiz basit kullanım dışında dilersek cat komutunun -n seçeneğini kullanarak bastırılan çıktıların kaç satırdan oluştuğunu da öğrenebiliriz. Buradaki n seçeneği ingilizce number ifadesinin kısaltmasından geliyor. Zaten bu seçeneğin uzun yazılışı da —number şeklinde. Teyit etmek için cat —help şeklinde yazıp yardım bilgilerini görüntüleyebiliriz. Bakın seçeneğin kısa veya istersek uzun halini kullanabileceğimizi buradan teyit edebiliyoruz. Ben genelde kısa seçenekleri tercih ettiğim için zorunda kalmadıkça seçeneklerin uzun hallerini kullanmam. Sadece seçeneklerin uzun hallerini de kullanabileceğimize bir kez daha dikkat çekmek istedim. Neyse, neticede yardım sayfasından da teyit edebildiğimiz üzere -n seçeneği ile tüm satırları numaralandırılmış şekilde bastırabiliyoruz. 

Ben örnek olarak ilk önce liste dosyasının içeriğini okumak istiyorum.

Gördüğünüz gibi satır numaraları ile birlikte tüm içerik bastırıldı. Ayrıca eğer istersek, birden fazla dosya ismini argüman olarak verip, tek seferde tüm dosya içeriklerinin toplam satır sayısını da buradan görebiliriz. Ben denemek için bu kez liste2 dosyasının ismini de ekliyorum.

Bakın girdiğim komut sayesinde dosya içerikleri peş peşe sırlandığı için, satır numaraları da tek bir dosya içeriği gibi sıralı ve kesintisiz şekilde bastırılmış oldu. Neticede dosya içeriklerini sırasına uygun şekilde birleştirmiş ve numaralandırmış olduk. Zaten cat komutunun "concatenate" açılımının "bağlamak, birleştirmek veya sıralamak" anlamına geldiğinden bahsetmiştik, bu çıktılar da bu durumu kanıtlıyor. İstersek bu çıktıları da tek bir dosyaya yönlendirebiliriz. Mesela cat liste liste2 > sıralı-liste komutu ile aktarabiliriz. Dosya içeriğini cat komutu ile teyit ettiğimizde, gördüğünüz gibi numaralandırılmış çıktıların dosyaya kayıt olduğunu görebiliyoruz. Zaten cat komutu bu çıktıları üretip konsola yönlendiriyordu. Biz sadece cat komutunun standart çıktılarını, konsol yerine bir dosyaya yönlendirdik. Numaralandırmaya ihtiyaç duyduğumuzda da işte cat komutunun n seçeneğini kullanabiliyoruz. Ayrıca numaralandırma işlemi sırasında, boş satırların görmezden gelinmesini de sağlayabiliriz. 

Benim örnekler sırasında kullandığım dosyalarda boş satırlar bulunmuyordu. Eğer dosya içeriğinde boş satırlar bulunuyorsa, cat komutu bu satırları da numaralandırmaya dahil ediyor. Eğer boş satırların numaralandırılmasını istemezsek "blank" yani "boşluk" ifadesinin kısaltmasından gelen "b" seçeneğini kullanabiliyoruz. Teyit etmek için öncelikle içerisinde boş satırları olan bir dosya oluşturmamız lazım. Ben dosya oluşturmak için yine cat komutunu kullanacağım. Dosya içeriğinde birkaç kelime ve belirgin şekilde birkaç boş satır yeterli olacaktır. Tamamdır Ctrl + D ile veri girişini sonlandırıyorum. Yeni oluşturduğumuz dosyayı cat komutu ile bastırarak boş satırların da bastırıldığını teyit edebiliriz. Bakın dosya içeriğine nasıl eklediysem aynen boş satırlar da bastırıldı. Dosya satırlarını numaralandıracak olursak da aynı durum geçerli olacak. Bakın boş olan satırların da numaralandırıldığını görebiliyoruz. Eğer n seçeneği yerine yalnızca b seçeneğini kullanırsak, görebildiğiniz gibi boş olan satırlar atlanıp, yalnızca içerisi dolu olan satırlar numaralandırılmış oluyor. 

İşte cat komutunun en temel ve sık kullanılan özellikleri bunlar. Zaten daha önce yönlendirmeleri kullanarak yeni dosyalar oluşturup içerisine nasıl veri ekleyebileceğimizden defaatle uygulamalı olarak söz ettiğimiz için cat komutu ile söyleyeceğim ek bir detay bulunmuyor. 

cat komutu en sık kullanacağımız komutların başında geliyor, nitekim şu ana kadar da pek çok kez kullandık. cat komutunu kullanarak ihtiyaçlarınıza uygun çözümler üretmek tamamen sizin yönlendirmeleri ve cat komutunun çalışma yapısını ne kadar iyi anladığınıza bağlı. Daha iyi anlamak adına birkaç örnek yapabiliriz. 

Örneğin bir dosya içeriğini kopyalamak istersek cat kopyalanacak_dosya > dosyanın_kopyası şeklinde komut girerek dosya içeriğinin birebir kopyalanmasını sağlayabiliriz. Üretilen dosyanın içeriğini cat komutu ile okuyarak Bu komut sayesinde cat aracı kopyalanacak dosyanın içeriğini açıp okuyor ve standart çıktıya yönlendiriyor. Normalde standart çıktı bizim konsolumuza bağlı olduğu için biz bu çıktıları konsolda görüyoruz. Ama ben burada standart çıktıyı büyüktür operatörü ile dosyanın kopyası olacak olan diğer dosyaya yönlendirdiğim için çıktılar bu dosyaya aktarılıyor. 

Elbette benim ele aldığım temel kullanımı dışında cat komutunun da birçok seçeneği mevcut. Bu seçeneklere göz atmak için tekrar cat —help şeklinde komutumuzu girebiliriz. Doğrusunu söylemek gerekirse ben n ve b seçeneği dışında buradaki hiç bir seçeneği kullandığımı hatırlamıyorum. Muhtemelen ya ihtiyacım olmamıştır, ya da daha etkili veya benim kullanımına alışık olduğum alternatif araçları tercih etmişimdir. Sizlerin de ihtiyacı olacak elzem seçenekler olduklarını düşünmediğim için geri kalan seçeneklerden bahsetmeyeceğim. Ancak dilerseniz buradaki açıklamalı okuyup, tüm seçenekleri test edebilirsiniz. Buradaki help çıktısındaki açıklamalar yeterince açık gelmezse, internet üzerindeki rehber anlatımlara da kolaylıkla ulaşabilirsiniz. Zaten tüm eğitim boyunca tekrar edeceğim gibi, bu eğitimdeki amacım temel kavramlardan bahsedip daha fazlasını nasıl öğrenebileceğimiz üzerinde durmak. Dolayısıyla tüm konulardan, tüm araçlardan veya araçların tüm seçeneklerinden bahsetmemi bekliyorsanız, üzgünüm bu gerçekleşmeyecek. Nitekim anlatan tarafta olmama karşın benim de henüz bilmediğim, hiç kullanmadığım için unuttuğum veya hiç karşılaşmadığım pek çok konu, kavram, araç ve seçenek bulunuyor. Ancak temel kavramların farkında olduğumuzda ve yeni bilgileri nasıl araştırıp bulabileceğimizi bildikten sonra zaten zaman içinde bilmemiz gereken tüm bilgi birikimini adım adım inşa edebiliyoruz. Yani özetle önemli olan iyi bir temel ve bu temele dayandırılan araştırma yetkinliği kazanabilmek. Anlatımlarımıza gelin cat komutunu tersi şekilde çıktılar sunabilen tac aracından bahsederek devam edelim.

# tac Komutu

Hatırlıyorsanız, ls komutunu ele alırken tüm çıktıları tersine çevirecek reverse yani r seçeneğinden bahsetmiştik. Bu seçenek sayesinde ihtiyacımız olduğunda, listelerin ve sıralamaların tam tersi şekilde bastırılması mümkün oluyordu. İşte cat komutu ile okuduğumuz dosya içerikleri için de benzer bir ihtiyacımız olabilir. Örneğin cat komutu ile okuduğumuz bir dosya içindeki alfabetik olarak sıralanmış satırlara, ters alfabetik olarak ihtiyaç duyabiliriz. Bu durumda, cat komutunun ismen de tersi olan tac komutunu kullanabiliyoruz. 

tac komutunu test edebilmek için öncelikle yeni bir dosya oluşturalım. Ben bulunduğum dizindeki tüm içerikleri ayrıntılarıyla birlikte büyükten küçüğe doğru okunaklı şekilde sıralayıp, çıktıları liste.txt isimli bir dosyaya aktarmak istiyorum. Bunun için ls -lhS > liste.txt şeklinde komutumu giriyorum. Çıktıların dosyaya aktarıldığını teyit etmek için cat komutu ile dosya içeriğini okuyabiliriz. Bakın dosya ve dizinlerin büyükten küçüğe doğru sıralanmış listesini görebiliyoruz. Eğer aynı dosyayı tac komutu ile okursak listenin tam tersi şekilde olması gerekiyor. Hemen deneyelim. Bakın tam olarak beklediğimiz gibi tüm çıktılar tam tersi şekilde oldu. Yani tüm satırları ters sıralama ile görüntüleyebildik. Böylelikle tac komutunun satırları tersten sıraladığını teyit etmiş olduk.

Belki bu örnekte kullandığımız ls komutunun zaten kendine ait terse çevirme işlevi yani -r seçeneği olduğu için, tac komutunun kullanımı size çok gerekli gibi gelmemiş olabilir ancak lütfen buradaki ls komutuna takılmayın. ls sadece kolay gözlemlenebilir dosya içeriği oluşturmak için kullandığımız basit bir örnek. Komut satırını kullanırken, sürekli metinsel veriler üzerinde çalıştığımız için, herhangi bir dosyadaki verilerin tersten sıralamasına ihtiyaç duyacağımız durumlar ile karşılaşmamız kaçınılmazdır. Her şey bir bayt akışıdır sözünü unutmayın lütfen. Dosya içeriklerinden veya çeşitli araçlardan gelen verileri yani üzerinde çalıştığımız baytları istediğimiz doğrultuda manipüle edebildiğimiz sürece komut satırının gücünden faydalanabiliriz. Verileri manipüle etmenin önemini ileride daha iyi anlayacaksınız. Çünkü eğitimin devamında, pipe mekanizmasını kullanarak bir aracın ürettiği çıktıları başka bir araca yönlendirerek kompleks sorunlara basit çözümler sağlamış olacağız. Araçların bir arada çalışabilmesi için de gerektiğine akış halindeki verilerin bir sonraki araca uygun şekilde değiştirilerek aktarılması gerekecek. Her neyse dediğim gibi verileri istediğimiz şekilde değiştirebiliyor olmanın önemini ileride daha net anlayacaksınız. 

Ayrıca ben tek bir dosya ile örnek yaptım ama cat komutunda olduğu gibi tac komutuyla da birden fazla dosyayı aynı anda ters sıralama ile okuyabiliriz. Ben örnek olarak sıralı harfler ve sayılar içeren iki dosya oluşturmak istiyorum. Kolayca oluşturmak için daha önce öğrendiğimiz süslü parantez genişletmesini kullanabiliriz. A dan z ye kadar olan karakterleri `echo -e "\n"{a..z} > harf.txt` komutu ile harf.txt dosyasına kaydedebiliriz. Buradaki echo komutu ile kullandığımız -e seçeneği tırnak içinde yazdığımız "yeni satıra geçeme" yani \n ifadesinin çalışmasını sağlıyor. Bu sayede a dan z ye kadar her satıra bir karakter basılıyor. Merak etmeyin echo komutunu kullanırken bu konudan tekrar bahsedeceğiz. Şimdilik ihtiyacımız olan dosyayı oluşturmak için kullanabiliriz. Benzer şekilde 1 den 30 a kadar olan sayıları satır satır sıralamak için de komutumuzu `echo -e "\n"{1..30} > sayi.txt` şeklinde düzenleyip girebiliriz. Evet neticede içinde istediğimiz türde veriler bulunan iki dosyamızı kolayca oluşturabildik. İçeriklerini görüntülemek için aynı anda iki dosyayı da cat komutu ile açabiliriz.

Bakın, verdiğim dosya sırlamasına uygun şekilde tek seferde dosya içerikleri sıralı şekilde bastırıldı. Aynı dosyaları tac komutu ile de bastırabiliriz. Bakın yine verdiğim dosya sırlamasına uygun ancak bu kez dosya içerikleri tersten sıralanmış şekilde bastırıldı. Böylelikle tac komutunun, satırları tersten bastırdığını birden fazla dosya üzerinde aynı anda uygulayarak da tekrar teyit etmiş olduk.

Neticede tac komutu cat komutu kadar kolay hatırlanabilir basit bir komut. tac komutunun tersten yazılmış hali olması zaten işlevi hakkında unutulmaz bir hatırlatıcı. Hazır terslikten bahsetmişken bir sonraki derste rev komutundan da kısaca bahsedebiliriz.

# rev Komutu

Eğer satıların sırlamasını değil de doğrudan satırdaki karakterleri tersine çevirmek istersek rev komutunu kullanabiliyoruz. rev komutunun ismi ingilizce "reverse" yani "ters" ifadesinin kısaltmasından geliyor. Kullanımı son derece kolay, rev komutunun ardından satırlarındaki karakterlerini tersine çevirmek istediğiniz dosyayı yazmanız yeterli oluyor.

Nasıl bir etkisi olduğunu test etmek için daha önce oluşturmuş olduğumuz liste.txt dosyasını kullanabiliriz. Dosyayı tekrar cat komutu ile okuyalım. Bakın dosyanın standart hali bu şekilde. Şimdi aynı dosyayı bir de rev komutu ile tekrar okumayı deneyelim. Bakın bu kez tüm satırlardaki karakterler tersine dönmüş oldu. Yani sondaki karakter başa, baştaki de sona gidecek şekilde bir terslik elde edebildik. Neticede pek alışılmadık ama gerektiğinde lazım olabilecek bir çıktı elde etmiş olduk. Bu çıktıyı istediğiniz bir dosyaya veya araca yönlendirip, elinizdeki verilerin satır satır tersten iletilmesini sağlayabilirsiniz.

Esasen rev komutu tac komutu kadar sık kullanılmasa da ismi dolayısıyla hatırlaması en kolay komutlardan. Satırlardaki karakterleri terse çevirmeye nadiren ihtiyacımız olur. Yine de söz konusu verilerin manipülasyonu olduğunda bize kolaylık sunan bir diğer araç. Ve ne zaman ihtiyacımız olacağı hiç belli olmaz. Neticede artık bu komutun varlığından ve işlevinden haberdarsınız. İhtiyaç duyduğunuzda kısa sürede hatırlayıp kullanabilirsiniz.

# echo Komutu

Daha önce örneklerimizde echo komutunu sıklıkla kullandık. echo ifadesi türkçe olarak "yankılanmak, yansıtmak" anlamındadır. Günlük hayatta ses yankılandığında eko yaptığını söylüyoruz ya işte bu komutta buna ithafen bu şekilde isimlendirilmiş. Zaten komutun işlevi de tam olarak budur. Kendisine argüman olarak verilenleri konsola veya yönlendirildiği yere yansıtır. En basit haliyle echo komutundan sonra yazacağımız tüm ifadeler, echo tarafından konsola bastırılır. Ben örnek olarak echo merhabalar yazıyorum. Gördüğünüz gibi merhabalar çıktısı konsola basıldı. Dilersek konsola bastırmak yerine herhangi bir dosyaya da yönlendirebiliriz. Örneğin echo "hello" > hello.txt komutunu girersem, hello ifadesi hello.txt dosyasına yazılmış olacak. Zaten daha önce de echo komutunu bu şekilde kullanmıştık.

Ayrıca echo komutunu yalnızca tek satırlık ifadeler için kullanmak zorunda da değiliz. Eğer yazacaklarımız birden fazla satır tutacaksa, tırnak işaretini kapatmadan satır satır yazmak istediklerimizi yazabiliriz. Ben örnek olarak echo "deneme yazıp enter ile bir alt satıra geçiyorum. Normalde tırnağı kapatmış olsaydım "deneme" ifadesi konsola basılacaktı. Tırnağı kapatmadığım için echo komutu hala girecek verilerim olduğunu biliyor ve ben tırnağı kapatana kadar bekliyor. Ben alt alta yeni ifadeler ekliyorum. Son olarak eğer bu veriler konsola basılsın istersem, tırnağı kapatıp enter tuşuna basabilirim. Eğer konsola bastırmak yerine bu yazdıklarımı bir dosyaya yönlendirmek istersem tırnağı kapattıktan sonra yönlendirme operatörü ile ilgili dosyayı belirtip enter ile işlemi onaylayabilirim. Ben sonuc.txt isimli bir dosyaya yönlendiriyorum. Echo komutuyla alt alta yazmış olduğum tüm satırlar artık sonuc.txt dosyasının içerisinde. Bakın cat komutu ile dosya içeriğini okuyarak, girdiğim verilerin satır satır dosyaya yönlendirilmiş olduğunu teyit edebiliyorum.

Echo komutunun çıktılarını bir dosyaya sorunsuzca yönlendirebildik ancak echo komutunun standart girdiden veri okumadığına dikkatinizi çekmek istiyorum. Hemen deneyerek bizzat teyit edelim. Örneğin biraz önce echo komutu ile içine satırlar eklediğimiz sonuc.txt dosyasını echo komutu aracılığı ile konsola bastırmak üzere echo < sonuc.txt şeklinde komutumuzu girebiliriz. Normalde buradaki yönlendirme operatörü sayesinde sonux.txt dosyasının içindeki veriler echo komutunun standart girdisine yönlendiriliyor olacak. Hemen komutumuz onaylayıp sonucu gözlemeyelim. Bakın, gördüğünüz gibi konsola herhangi bir çıktı basılmadı. Çünkü echo komutu standart girdiden veri okumuyor. Biz göndersek de echo komutu standart girdiden veri kabul etmediği için echo komutuna aslında yankılayabileceği hiç bir şey vermemiş olduk. Dolayısıyla konsola hiç bir şey bastırılmadı. echo komutu çalışma yapısı gereği yalnızca kendisine argüman olarak verilmiş olan ifadeleri konsola yankılıyor yani bastırıyor. 

Zaten help echo komutu ile yardım sayfasına göz attığımızda, echo komutunun argümanları standart çıktıya yazdırdığı sayfanın en başında yazıyor. Standart girdiden veri kabuk ettiğine dair bir açıklama da bulunmuyor. Burada kast edilen argüman yapısının ne olduğunu da zaten biliyorsunuz. Özetle echo yalnızca argüman olarak ne varsa onu bastırmakla mükellef. Eğer hatırlıyorsanız, ben yönlendirmelerden bahsederken kimi araçların standart girdiden veri almayabileceğinden de bahsetmiştim. İşte echo aracı da bahsi geçen bu araçlardan biri. Kimi araçlar yalnızca argümanları işlemek için tasarlandıklarından, standart girdiden veri kabul etmiyorlar. 

Hatta echo komutunun argümanları yankıladığına dair basit bir örnek vermek gerekirse echo * komutunu kullanabiliriz. Biliyorsunuz buradaki yıldız işareti kabuk için tüm dosya ve dizin isimleriyle eşleşen bir joker karakterdir. Yani bu karakterin olduğu yere uygun olan tüm karakterler getirilebilir. Kabuk echo komutunu gördüğünde konsola çıktı basılması gerektiğini anlıyor, daha sonra yıldız simgesini görüyor. Kabuk yapısı gereği, yıldız işaretini gördüğünde, yıldız işaretini mevcut dizinde bulunan dosya ve klasörlerin isimlerine genişletir. Yani yıldız işretinin yerini, mevcut dizindeki dosya ve klasörlerin isimleri alır. Dolayısıyla echo komutuna argüman olarak dosya ve dizinlerin isimleri verilmiş oluyor. echo komutu da argümanlarını konsola çıktı olarak yansıtıyor yani standart çıktılarını konsola yönlendiriyor. 

İşte sizlerin de görebildiği gibi, kabuğun çalışma yapısını ve temel özelliklerini bildiğimizde, bu örnekte olduğu gibi komut verme konusunda inanılmaz esnekliğe sahip olabiliyoruz. Ben sadece dikkat çekici bir örnek olması için bu örneği ele aldım. 

Hazır esneklikten bahsetmişken echo komutu ile aslında dosyaları okunmanın bir yolu olduğunu söylesem ? Biliyorum echo komutunun standart girdiden veri almadığı için dosyaları okuyamayacağını söyledim, hatta bizzat test ettik. Evet echo komutu standart girdiden veri almıyor ama kendisine argüman olarak verilen ifadeleri bastırabiliyor. Biz de dosyanın tüm içeriğini argüman haline getirirsek echo komutu dosyanın içeriğini bastırabilir. Hatırlıyorsanız kabuk genişletmelerinden bahsederken komut ikamesi kavramından söz etmiştik. Komut ikamesini kullandığımızda komut çalıştırılıp sonucu komutun bulunduğu yere yazılıyordu. İşte komut ikamesini kullanarak bir dosyanın içeriğini argüman haline getirebiliriz.

Denemek için öncelikle echo komutunu giriyorum. Daha sonra komut ikamesi için dolar işaretinin yanına parantez açıyorum. Şimdi bu parantez içine öyle bir şey yazmalıyız ki dosyanın içeriği çıktı olarak bastırılsın. En basit şekilde eğer cat dosya ismi şeklinde yazarsam cat komutu dosya içeriğini çıktı olarak bastıracak dolayısı ile komut ikamesi de çıktıları echo komutuna argüman olarak verecek böylelikle echo komutu ile dosya içeriğini bastırmış olacağız. Ancak bu pek de anlamlı değil. Çünkü zaten yalnızca dosya içeriğini okunmak istiyorsak ve cat komutunu kullanabiliyorsak echo komutu ile uğraşmamız gerekmez. 

Bunun yerine eğer bu dosyanın içeriğini küçüktür operatörü yönlendirirsem dosyanın içeriği standart girdiye aktarılacak oradan da komut ikamesi olduğu için bu veriler buradaki ifadenin yerini alacak. Böylece echo komutuna dosyanın tüm içeriğini argüman olarak vermiş olacağız. Bu yöntemle görebildiğiniz gibi echo komutu ile de dosya içeriğini okuyabiliyoruz. İşte kabuğun ve araçların temelde nasıl çalıştığını bildiğimizde görebildiğiniz gibi sorunlara kendimiz çözümler getirebiliyoruz. Bu da bize inanılmaz esneklik sağlıyor.

Tıpkı bu örnekte olduğu gibi echo komutu da dahil tüm komutların pek çok esnek kullanım imkanları var. Yeter ki biz temelde nasıl çalıştıklarını bilelim.

Ayrıca şu ana kadar ele aldığımız kullanımlar dışında echo komutun pek çok ek seçeneği bulunuyor. Bunları görmek için help echo komutunu kullanabiliriz.

Bakın burada pek çok özel karakter bulunuyor. Hepsine tek tek değinmemize gerek yok. Ama kısaca bir göz atalım.

Normalde echo komutunun ardından yazdığımız ifade konsola bu şekilde basılıyor. Burada dikkat etmemiz gereken detay, aslında bizim girdiğimiz ifadeden sonra echo komutunun otomatik olarak yeni satıra geçme karakteri gizlice kullanıyor olmasıdır. Bu durumu teyit etmek için otomatik olarak yeni satıra geçme özelliğini kapatmak üzere -n seçeneğini kullanabiliriz. 

Bakın -n seçeneğini kullandığımız için bir alt satıra geçilmedi, dolayısıyla prompt hemen aynı satırda bizden komut beklemeye başladı. Böylelikle echo komutunun aslında, gizli yeni satır eklediğini öğrenmiş olduk. Tekrar yardım sayfasını görüntüleyecek olursak, bakın burada pek çok biçimlendirme özelliği bulunuyor. Yani echo komutu buradaki ters slash ile başlayan ifadeleri gördüğünde onların özel anlamlarına göre çıktıyı biçimlendiriyor. Fakat bu ifadeleri doğrudan kullanamıyoruz. Bu biçimlendirme ifadelerini kullanırken echo komutunun -e seçeneğini kullanarak, echo komutuna bu karakterlere özel anlamlarına göre muamele yapması gerektiğini belirtmemiz lazım. Aksi halde buradaki ifadeleri kullansak bile bunlar echo komutu için sıradan karakterlerden ibaret olacak. Hemen deneyelim. Ben yeni satıra geçmeyi sağlayan \n ifadesini kullanacağım. Komutumu echo "merhaba \n dünya" şeklinde giriyorum.  

Bakın \n ifadesi de olduğu gibi duruyor ve yeni bir satıra da geçilmemiş. Aynı örneğini bu kez -e seçeneği varken tekrar deneyebiliriz. Bakın bu kez \n ifadesi echo komutu tarafından dikkate alındı ve ikinci kelimemiz bir satırda bastırıldı. Dikkat ettiyseniz tırnak içinde yazdım. Çünkü biçimlendirme özelliklerinin doğru şekilde çalışması için tırnak içinde yazmamız gerekiyor. Daha önce tek ve çift tırnak kullanımı arasındaki farklardan bahsetmiştik. Bu doğrultuda tek veya çift parantez kullanma seçimi size ait.

Ayrıca hatırlıyorsanız daha önce echo komutunu ve süslü parantez genişletmelerini kullanarak sıralı karakterleri alt alta olacak şekilde biçimlendirmiştik. Şimdi tekrar aynı komutu kullanıp sonuçlarına bakabiliriz. `echo -e "\n"{a..z}` Bakın bu komutta da echo komutunun -e seçeneğinden ve \n yeni satır biçimlendirme özelliğinden faydalanıyoruz. Burada yeni satıra geçeme yani \n biçimlendirme karakteri olmasa gördüğünüz gibi tüm karakterler tek sırada basılıyor. Bu örnek bu biçimlendirme karakterlerinin gerektiğinde oldukça kullanışlı olabildiğini gösteren basit bir örnek. 

İşte sizler de yardım sayfasında yer alan diğer tüm biçimlendirme özelliklerini -e seçeneği ile birlikte echo komutu üzerinden kullanabilirsiniz. 

Elbette buradaki seçeneklerin hepsini ezberlemek zorunda değilsiniz. Hatta hiç birini ezberlemeyin. Çünkü ezberlemeniz gerekmiyor, kullandıkça bu ifadeleri zaten hatırlıyor olacaksınız. Hatırlayamadığınız zaman yardım sayfasından kısa sürede tekrar bakabilirsiniz. Zaten kısaltmaların, temsil ettiği biçimlendirme özellikleri ile uyumlu olduğunu da göz önünde bulundurduğumuzda, pratik yaptıkça sık kullandığınız seçeneklerin hemen aklınıza geldiğini sizler de fark edeceksiniz. Ayrıca buradaki biçimlendirme ifadeleri, çoğu araçta benzer şekilde olduğundan bir kez öğrendiğinizde sistem üzerindeki metin biçimlendirme araçların pek çoğunda aynı ifadeleri kullanabiliyor olacaksınız.

Yani özetle benim bahsetmediğim diğer seçeneklerin açıklamasına bakarak, tam olarak nasıl bir biçimlendirme uyguladığını bizzat test etmeniz yeterli. Hem bu sayede pratik yapmış olursunuz. 

Örneğin bakın burada dikey tab biçimlendirmesi var. Acaba nasıl bir çıktı verecek ? Hemen deneyelim. echo -e "linux \v dersleri" şeklinde komutumu giriyorum. Bakın dikey tab bu şekilde bir biçimlendirme uyguluyormuş. Bahsetmediklerimizi de keşfetmek için artık tek yapmanız gereken geri kalan biçimlendirme özellikleri üzerinden pratik yapmak.

Şimdilik bahsetmiş olduğumuz bu temel bilgiler eğitime devam edebilmemiz için yeterli. Ancak bu dersi sonlandırmadan önce echo komutunun kara gün dostu olduğunu bilmenizi isterim. Echo komutu bash kabuğunun yerleşik bir komutu olduğu için bash kabuğunun bulunduğu her ortamda echo komutunu kullanabiliriz. Yani gerektiğinde yeni dosyalar oluşturup, içerisine veri eklemek için veya dosya içeriklerini okumak için dahi kullanabileceğimiz yegane araç olabiliyor. 

Özellikle kara gün dostu dedim, çünkü sistemi kurtarmamız gerektiğinde dosya içeriklerini okuma değiştirme ve yeni dosyalar oluşturmak için echo komutuna ihtiyaç duyabiliyoruz. Özetle, echo komutu göründüğünden daha önemli olabilir. Lütfen echo komutu için azami özeni gösterin. Basit bir komuttur ama tabii ki bu önemsiz olduğu anlamına gelmiyor.

Anlatımlarımıza sort komutu ile devam edebiliriz.

# sort Komutu

sort ifadesinin Türkçe karşılığı "sınıflandırmak" olarak çevirebiliriz. İsminden de anlaşılabileceği gibi  sort aracı, elimizdeki düzensiz verileri, belirli özelliklere göre sıralamak için kullandığımız işlevsel bir araçtır. 

sort komutunun sıralama için kullanılabilecek pek çok özelliği olmasına karşın, herhangi bir seçenek belirtilmeden kullanıldığında sıralama için izlediği standart bir düzeni bulunuyor. Yani sort komutuna ek bir seçenek belirtmeden yalnızca sıralaması gereken satırlar verirsek, bu satırları

Öncelikle sayısal olarak sıralar. Daha sonra alfabetik olarak sıralar. En son da aynı harfle başlayan satırlar, büyük harfle başlayanlar başta olacak şekilde sıralanır. Ama dikkat etmeniz gereken öncelikle yalnızca tüm satırlardaki ilk karakterlere göre sıralama yaptığıdır. Daha sonra ilk karakteri aynı olan satırların da ikinci karakterlerin bakarak tekrar sıralama yapar. Bu şekilde tüm satırlarda yer alan tüm karakterleri baştan sonra kendi standart kuralı dahilinde sıralamış olur.

Uygulamalı olarak daha net anlaşılacağı için hemen bir dosya üzerinde test edelim. Ben örnek olarak içerisinde küçük büyük harfler ve rakamlar bulunan bir şablon kullanacağım. Bakın benim kullanacağım şablon bu. Bu şablon üzerinden biraz önce bahsettiğimiz sıralama kurallarını net biçimde görebiliriz. 

3b2
bAc
23a
1C1
b3C
2cB
Ac1
CCC
B3a
c21
Caa
31C
abc
Aa3
A3c
2BB
Ca3
1CC
Aab
a21
bAb
a23
3Aa
A31
C13

Görebildiğiniz gibi kullanacağımız bu şablon, içerisinde küçük büyük harfler ve rakamlar bulunan son derece düzensiz bir içeriğe sahip. Şimdi sort komutunu girip düzenli bir listenin nasıl göründüğüne bakalım. Evet dosyanın içindeki tüm satırlar uygun şekilde sıralandı.

Aldığımız çıktıyı inceleyecek olursak. Gördüğünüz gibi öncelikle ilk karakterlere göre, rakamlar, büyük harfliler ve küçük harfliler olacak şekilde liste sıralanmış. İlk karakteri birebir aynı olan satırlar ise kendi içinde, ikinci karakterlerine göre yine aynı kurallar dahilinde yani rakamlar, büyük harfler ve küçük harfler olacak şekilde sıralanmış. Bu şekilde tüm veriler standart sıralama kuralları dahilinde sıralanmış gördüğünüz gibi. Ben standart sıralama kurallarının kolay anlaşılabilmesi için şablonda anlamlı kelimeler kullanmadım, nitekim bu şablon üzerinden standart sıralama kurallarını net bir biçimde görebiliyoruz. Şablona ders kaynaklarından siz de erişebilirsiniz. Ya da kendiniz için daha farklı bir şablon da oluşturabilirsiniz. Elbette sizle daha basit gelecekse, şehir ya da insan isimleri yaşları gibi listeler üzerinden de sırlama çalışmaları yapabilirsiniz.

İlk örnekte tek bir dosyadaki satırları sıraladık ancak dilerseniz birden fazla dosyayı da tek seferde sort komutu ile sıralayabilirsiniz.

Ben sayi diye bir dosya oluşturuyorum, içerisine de düzensiz şekilde tek ve çift basamaklı sayılar ekliyorum. Tamamdır, şimdi bir de harf diye bir dosya oluşturalım içerisine de yine küçük büyük harfleri düzensiz şekilde ekleyelim. 

```jsx
a
g
F
z
D
g
O
p
l
k
S
C
E
n
M
h
t
N
```

Bu da tamam. Öncelikle dosyalarımızı ayrı ayrı sıralayalım. sort harf şeklinde komutumu giriyorum. Bakın büyük harfler başta olacak şekilde tüm dosya içeriği alfabetik olarak sıralandı. Şimdi bir de sayıları sıralayalım. Sayılar da sıralandı. Ama sanki aldığımız çıktı biraz tuhaf gibi. Normalde sayıların sıralanması deyince insanın aklına iki basamaklıklar da dahil tüm hepsinin küçükten büyüğe doğru sıralanması gerektiği geliyor. Ama önceki açıklamalarımıza dikkat ettiyseniz sort komutu her bir satırın yalnızca tek bir karakterini sıralıyor. Dolayısıyla sıralama yapılırken aslında sayılar değil 0 dan 9 a kadar olan rakamlar arasında sıralama yapılıyor. Bakın buradaki ilk karakter olan yani ilk basamakta yer alan tüm rakamlar küçükten büyüğe doğru sıralanmış. İlk karakterler sıralandıktan sonra da ilk karakteri yani ilk basamağı aynı olan rakamların da ikinci basamakları kendi içlerinde tekrar sıralanmış. 

Yani bizzat örnek üzerinden gördüğümüz gibi sort komutu tam olarak bu şekilde çalışıyor. Yani aldığımız çıktıda herhangi bir problem yok. Sort komutu buradaki sayıların bütüncül matematiksel büyüklüğüne bakmıyor, tek tek her bir satırdaki karakterlere bakıp ona göre sıralıyor. 

Eğer dosya içeriğinin matematiksel büyüklüğü dikkate alınarak sıralansın istersek bunu numerical yani sayısal ifadesin kısaltması olan -n seçeneği ile özellikle belirtmemiz gerekiyor. Şimdi sayi dosyasını -n seçeneğini de kullanarak tekrar sıralayalım. Bakın bu kez dosya içeriğindeki veriler matematiksel büyüklüklerine göre sıralandı. Yani eğer sayısal sıralama yapacaksınız n seçeneğini kullanmanız gerektiğini unutmayın lütfen. Ya da unutun, tekrar yardım sayfasına bakıp hatırlayabilirsiniz zaten. Sadece yeri gelmişken bahsetmek istedim. Her neyse, neticede dosyalarımızı ayrı ayrı sıralamayı başardık. 

Şimdi tek seferde iki dosyayı birden sıralamayı deneyebiliriz. Bunun için komutumu dosyaların isimlerini belirterek yani `sort harf sayi` şeklinde giriyorum.

Bakın, öncelikle rakamlar, daha sonra alfabetik olarak büyük harfler ve küçük harfler olacak şekilde iki farklı dosya tek bir dosyaymışçasına sıralanmış oldu. Böylelikle gördüğünüz gibi birden fazla dosya içeriğini tek seferde kolayca sıralayabiliyoruz. Bir de bu arada sort komutuna verdiğimiz dosyaların isimlerinin sıralamasının bir önemi yok. Çünkü zaten hepsini aynı sıralama kuralına tabii olduğu için ilk veya son dosya olması bir şeyi değiştirmiyor. Sort komutu tüm içeriği tarayıp en son sıralama yapıyor. Dilerseniz dosya isimlerinin sıralamasını değiştirip komutumuzu tekrar girebiliriz. Bakın yine aynı sıralamayı elde ettik. Bu sıralanmış verileri de istersek yönlendirme operatörü ile başka bir dosyaya kaydedebiliriz. Ben komutumu bu kez sort rakam harf > siralama.txt şeklinde giriyorum. Bu sayede birden fazla dosyadan veri alıp sıralanmış hallerini tek bir dosyaya yani siralama.txt dosyasın kaydetmiş oldum. Bakın dosya içeriğinde sıralanmış olan tüm veriler bulunuyor.

## Sıralamayı Tersine Çevirmek

Eğer sort komutunun sıraladığı satırları tersine çevirmek istersek, "reverse" yani "ters" ifadesinin kısaltması olan "r" seçeneğini kullanabiliyoruz.

Rahatça kıyaslayabilmek için öncelikle seçenek olmadan sort komutunu kullanalım. Ben yine şablon dosya içeriğini sıralamak istiyorum. Bakın standart sort komutunun kuralları dahilinde dosya içeriği sıralandı.

Şimdi de -r seçeneğini ekleyip tersten sıralayalım. Bakın iki çıktıyı kıyasladığımızda, satırların tam tersi şekilde sıralandığını görebiliyoruz. Sizde bu seçenek sayesinde elinizdeki verileri ters alfabetik ya da ters numerik şekilde sıralayabilirsiniz. 

## Sütunlar Özel Sıralama

Biliyorsunuz, sort komutu en baştan başlayıp tüm satırlardaki karakterleri tek tek sıralıyor. Fakat biz her zaman satırların en başındaki karaktere bakılmasını istemeyebiliriz. Yalnızca her satırın en başındaki karaktere göre sıralama yapmak yerine eğer mevcutsa, diğer sütunlara göre sıralama yapılmasını da sağlayabiliriz.

Örnek olarak şehirler ve plakaları olan bir şablon kullanabiliriz. Bakın dosya içeriği bu şekilde birkaç şehri ve ikinci sütunda şehirlerin plakalarını içeriyor.

istanbul 34

Kocaeli 41

İzmir 35

erzincan 24

Edirne 22

Eğer seçenek kullanmadan yalnızca sort komutunu kullanırsak, en baştaki karakterlere göre sıralanacak. Hemen deneyelim. Bakın çıktılar ilk sütundaki ilk karakterlere göre sıralandı.

Şimdi sort komutuna yalnızca 2 sütuna bakarak sıralama yapmasını söyleyelim. Bunun için -k seçeneğini kullanabiliyoruz. Hangi sütuna göre sıralanacağını belirtmek için -k seçeneğinden sonra sütun sayısını girmemiz gerekiyor. Ben 2. sütuna göre sıralanmasını ve matematiksel büyüklüğe göre sıralanmasını istediğim için komutumu sort -nk 2 dosya adı şeklinde giriyorum. Buradaki n seçeneğinin sayısal sıralama yaptığını zaten daha önce bizzat deneyimlemiştik. 

Gördüğünüz gibi girmiş olduğum -k seçeneği sayesinde bu kez 2. sütuna yani plaka sayılarına göre sıralama yapıldı. İşte sizler de içerisinde birden fazla sütun bulunan bu gibi dosyaların, hangi sütunlarına göre sıralanması gerektiğini -k seçeneği ile özellikle belirtebilirsiniz.

### Yalnızca Benzersiz Olanları Bastırmak

Eğer sort komutuna verilen girdide birbirini tekrar eden satırlar varsa bunları tek bir satır olarak bastırabiliriz. sort komutunda bu filtrelemeyi uygulamak için ingilizce unique yani benzersiz ifadesinin kısaltması olan u seçeneğini kullanabiliyoruz.

Ben denemek için basit bir isim soyisim dosyası kullanacağım.

Bakın burada isim kısmı aynı olan satırlar ve isim soy isim aynı olan satırlar var. sort -u komutunu çalıştırıp nasıl bir çıktı elde edeceğimize bakalım.

Bakın isimler kısmı aynı olmasına rağmen satırlar basıldı. Fakat birebir aynı olan satırlar yani isim ve soy isimin aynı olduğu satırlardan yalnızca bir tanesi basıldı. Yani gördüğünüz gibi bu şekilde birebir tekrar eden satırları -u seçeneği ile tek bir satır basılacak şekilde sıralayabiliyoruz.

Benzersiz satırları bastırdık bu harika fakat burada ek bir detay var o da küçük büyük harf farklılığı. Benim kullandığım dosya içeriğinde büyük harf yok, ama eğer dosya içeriğinde aynı satırların büyük harfleri farklı olan aynı ifadeler varsa u yani uniq seçeneği bunları filtrelemez. Ne demek istediğimi uygulama üzerinden daha net anlayabiliriz. Şimdi ben dosyamın sonuna cat >> komutu ile yeni veriler ekleyeceğim. Ben bu sondaki ifadenin birebir aynısını büyük harfler ile yazıyorum. Bir de başlangıç harfi büyük olacak şekilde yazıyorum ve verileri ctrl d ile kaydediyorum. Şimdi dosya içeriğini tekrar bir cat komutu ile inceleyelim. Bakın sondaki satılar birebir aynı yalnızca küçük büyük harfleri farklı. Hadi şimdi sort -u komutunu kullanıp filtrelemenin nasıl olacağına bakalım. Bakın birebir aynı ifade olmasına karşın küçük büyük harfleri farklı olduğu için bunlar da bastırıldı. Eğer küçük büyük harf duyarlılığını kaldırmak istersek bunun için -f seçeneğini kullanabiliriz. Nasıl bir etkisi olacağını görmek için komutumuzu -f seçeneğini de ekleyerek sort -uf şeklinde girelim.

Bakın bu kez küçük büyük harfleri farklı olsa da tekrar eden ilgili ifadeler ayrı ayrı basılmadı. İşte sizler de bu şekilde gerektiğinde küçük büyük harfe duyarlı veya duyarsız şekilde satıların benzersiz olanlarını listeleyebilirsiniz. Özellikle büyük verileri işlerken tekrar eden satırların görmezden gelinmesi çok işinize yarayabilir.

Komutu nasıl kullanacağınız tamamen sizin o anki ihtiyaçlarına bağlı olacağı için temel seçeneklerden haberdar olmanız çok önemli. Yani örneğin küçük büyük harf duyarlılığının kaldırılması için -f seçeneğinin kullanıldığını unutursanız böyle bir seçeneğin var olduğundan haberdar olduğunuz için yardım sayfasını açıp tekrar bu seçeneği hangi karakterle kullanabileceğinizi hatırlayabilirsiniz. Yani eğer araçların birden fazla seçeneğini ele aldığımızda hatırlama veya öğrenme konusunda kaygı yaşıyorsanız, bu yersiz bir kaygı. Komutun temelde nasıl çalıştığı ve yetenekleri yani yapabilecekleri hakkında anımsama düzeyinde bilgi sahibi olduğunuzda yardım sayfasından komutu tekrar kolayca hatırlayabilirsiniz. Zaten merak etmeyin sık kullandığınız komutları hatırlamak gibi bir kaygınız da olmayacak. Bu sebeple çeşitli araçları anlatırken, hepsini olmasa da mümkün oldukça işimize yarayacak olan seçenekleri ele alıyor olacağım. 

Örneğin sort komutunun tüm seçenekleri benim bahsettiklerimle sınırlı da değil. Burada ele aldıklarımız dışında sort komutunun birkaç özelliği daha bulunuyor. Ancak ben geri kalan özelliklerden, başka araçları kullanarak da faydalanabileceğimizi bildiğim için sort komutunu için bu kadarlık bilginin yeterli olduğunu düşünüyorum. Merak ediyorsanız sort —help komutunun çıktılarına göz atabilirsiniz.

# Dosya Kopyalama - Taşıma - Silme İşlemleri

Şimdiye kadar dosya oluşturma ve düzenlemeye dair pek çok araçtan söz etmiş olduk. Anlatımın devamında pek çok araçtan daha bahsediyor olacağız. Fakat diğer araçlardan bahsetmeden önce belki de en temel işlevler olan kopyalama taşıma ve silme işlevlerini yerine getirebileceğimiz araçlarından bahsetmeden istiyorum.

# cp Komutu

Komut satırı üzerinden dosya veya dizinleri kopyalamak istediğimizde cp aracını kullanabiliyoruz. Zaten cp aracının ismi de, copy yani kopyalama ifadesinin kısaltmasından geliyor. Aracın kullanımı çok kolay.

Ben denemek için öncelikle “orijinal” isminde bir dosya oluşturup, içerisine "ben dosyayım" yazıp kaydediyorum. Bakın dosyam sorunsuzca kaydedildi. 

Eğer bu dosyayı bulunduğum dizine farklı bir isimle kopyalamak istersem cp orijinal dosya dosyanın_kopyası şeklinde komut girebilirim. Dosyaları listeleyelim bakın orijinal dosya ve onun kopyası listede bulunuyor. Her iki dosyayı da cat komutu ile okumamak için yan yan isimlerini girelim. Bakın orijinal dosya ile kopyalamış olduğum dosyanın içeriği birebir aynı. Tek fark dosyanın ismi benim istediğim şekilde olması. cp komutunun en temel kullanımı bu şekilde. 

Eğer mevcut bulunduğumuz dizine değil de istediğimiz farklı bir dizine dosya veya dizin kopyalamak istersek tek yapmamız gereken kopyanın tam olarak hangi dizine hangi isimle kaydolacağını belirtmek. Ben ojinal dosyasını, kendi ev dizimindeki Documents klasörünün altına aynı isimde kopyalamak istiyorum. Bunun için cp ojinal ~/Documents şeklinde yazabiliriz. Bakın burada ilk olarak orijinal dosyanın yani kopyalanacak dosyanın ismini girip, daha sonra kopyanın tam olarak nereye kaydolması gerektiğini belirtebiliyoruz. Burada klasör isminden sonra özellikle bir dosya ismi belirtmediğim için orijinal dosyanın ismi de birebir kopyalanıp bu dizine kaydolmuş olacak. Komutumuzu onaylayıp sonuç üzerine konuşalım. Teyit etmek için cat ~/Documents/orijinal komutu ile kopya dosyanın içeriğini okumayı deneyebiliriz. Ayrıca ls ~/Documents/ komutu ile klasörün içeriğini de listeyebilirim. Neticede bakın dosyamın aynı isimle, benim hedef gösterdiğim dizine kaydedilmiş olduğunu buradaki çıktılarından kesin olarak görebiliyoruz. Eğer dosyayı farklı bir isimle kopyalamak isteseydim, dizin adresinden sonra dosyanın ismini belirtebilirdim. Örneğin cp orijinal ~/Documents/kopya şeklinde komut girebilirim. Yine cat komutunu kullanarak dosyamın istediğim isimle kopyalanmış olduğunu teyit edebilirim. Bakın istediğim dizine tam olarak istediğim isimde dosyamı sorunsuzca kopyalayabildim. Tabi ki ben yalnızca mevcut bulunduğum dizindeki bir dosyayı başka bir dizine kopyalamak üzere örnekler gösterdim ama yetkiniz olduğu sürece istediğiniz dizindeki dosyayı istediğiniz başka bir konuma kopyalayabilirsiniz. Örneğin ben cp ~/Documents/orijinal  /tmp/ komutu ile Documents dizini altındaki orijinal dosyasını /tmp dizini altında koplayalabiliyorum. cat /tmp/orjinal komutu ile kontrol edelim, bakın dosyam sorunsuzca kopyalanmış. 

Ayrıca ben hep tek bir dosayı kopyalamayı ele aldım ama aslında birden fazla dosyayı da aynı anda kopyalayabiliriz. Örnek olması için öncelikle `touch a b c d` komutu ile a b c ve d isimli dosyalar oluşturmak istiyorum. Bu dosyalarımı tek seferde Document klasörüne kopyalamak istersem komutumu `cp a b c d ~/Documents/` şeklinde girmem yeterli. `ls ~/Documents/` komutu ile dizin içeriğini kontrol edelim. Bakın birden fazla dosyanın kopyalamış olduğunu görebiliyoruz.

Bu çoklu kopyalama işleminden sonra muhtemelen cp aracının girdiğimiz argümanlardan hangilerinin kopyalanacak dosyalar, hangisinin dosyaların kopyalanacağı dizin olduğunu nasıl anladığını merak etmiş olabilirsiniz. Aslında çok basit, birden fazla dosya ismi belirtildiği durumda en sondaki argümanın bu dosyaların kopyalanacağı adres olması zorunlu. Yani cp aracı bu beklenti ile komutumuzu okuyor. Dolayısıyla girdiğimiz komuttaki en son argüman cp aracı için, bu argümandan önceki tüm dosyaların kopyalanacağı dizini temsil ediyor.

Dosyaları tek seferde başarılı şekilde kopyalamayı başardık, bu harika fakat bazen kopyalama işlemini kontrollü şekilde gerçekleştirmek de isteyebiliriz. Çünkü özellikle çoklu şekilde dosyaları bir yerden başka bir yere kopyalarken, hedef gösterdiğimiz dizinde bizim kopyaladığımı dosyaları ile aynı isimde dosyalar bulunabiliyor. Eğer özellikle önlem almazsak, kopyalama emri verdiğimiz için kopyaladığımız dosyalar aynı isimli dosyaların üzerine yazılıyor. Yani ilgili dizindeki aynı isimli dosyaların içerikleri tahrip ediliyor. Dediğim gibi özellikle çoklu şekilde dosyaları kopyalarken bu durumun farkında olamayabiliyoruz. Bu duruma çözüm olarak, üzerine yazılma durumu varsa cp aracının bizi uyarıp bizden izin istemesini talep edebiliriz. Bunun için -i seçeneğini kullanmamız yeterli.

Örneğin daha önce Documents dizinine kopyaladığım dosyalar ile aynı isimli yeni dosyaları yine aynı dizine kopyalamak istersem, yeni kopyalanan dosyalar eskilerinin üzerine yazılacak. Denemek için ben öncelikle cat > yeni-dosya komutu ile yeni bir dosya oluşturup içerisine de “bu bir dosyadır” yazıp ctrl d ile dosyamı kaydediliyorum. Şimdi cp -i a b c yeni-dosya şeklinde komutumuzu girelim. Bakın hedef gösterdiğimiz dizinde a dosyası ile aynı isimde dosya bulunduğu için üzerine yazmaya karşı cp aracı bizi uyarıyor. Eğer üzerine yazma işlemini onaylamak istiyorsak y yazıp enter ile devam edebiliyor ya da reddetmek için n ile üzerine yazmayı iptal edebiliriz. Bakın sırasıyla Documents dizininde aynı isimde bulunan a b ve c dosyaları için tek tek bu sorular bana soruldu, ama bu dizinde bulunmayan yeni-dosya isimli dosya için böyle bir soru sorulmadı. Çünkü bu isimde daha önce bir dosya yoktu, dolayısıyla üzerine yazma gibi işlem hakkında da uyarıya gerek kalmadı.

Dediğim gibi özellikle çoklu şekilde dosyaları kopyalarken, olası üzerine yazma risklerine karşı tek tek bize sorulmasını istersek i seçeneğini kullanabiliyoruz. Aslında bu seçeneğin dışında topluca tüm üzerine yazma işlemlerini redden -n seçeneği de bulunuyor. Ancak biz kimi zaman bazı dosyaların üzerine yazılmasını, bazılarının da üzerine yazılmamasını isteyebiliriz. Bu durumda -i seçeneğini kullanarak tek tek seçim yapmak mantıklı. Eğer tek tek seçim yerine toptan tüm üzerine yazma işlemlerinden korunmak isterseniz komutunuza -n seçeneğini de ekleyebilirsiniz.

Denemek için içerisinde veri bulunan yeni-dosya isimli dosyayı tekrar aynı konuma kopyalamayı deneyebiliriz. Öncelikle Documents dizini altındaki dosyanın içeriğini görmek için cat ~/Documents/yeni-dosya komutu ile dosyanın içeriğini konsola bastıralım. Bakın dosyada “bu bir dosyadır” yazıyor. Şimdi cat > yeni-dosya komutunu girip “bu yeni dosya” ifadesini yazalım ve ctlr d ile dosyayı kaydedlim. 

Eğer ben bu dosyayı tekrar documents dizinine kopyalarsam, documents dizinindeki aynı isimli dosyanın üzerine yazılacak yani o dosyadaki veriler silinmiş olacak. Bu durumu önlemek için -n seçeneğini kullanabiliriz. Komutumuzu öncelikle -n seçeneği ile kullanalım daha sonra -n seçeneği olmadan kullandığımızda ne olacağını da bakarız. Ben cp -n yeni-dosya ~/Documents/ komutu ile dosyamı kopyalamak üzere komutumu giriyorum. Herhangi bir çıktı almadık. Şimdi cat ~/Documents/yeni-dosya komutu ile ilgili dosyanın içeriğini kontrol edelim. Bakın dosyanın içeriğinde herhangi bir değişiklik olmamış. Şimdi bir de -n seçeneği olmadan komutumuzu girelim. Yani aynı isimli dosyanın üzerine yazılmasına izin verelim. cat komutu ile tekrar dosyamızı okuyup kontrol edebilirz. Bakın -n seçeneği olmadığı için aynı isimli dosyanın üzerine yazılmış.

İşte bizzat teyit ettiğimiz gibi üzerine kopyalama sonucu ortaya çıkan dosyaların, hedef dizindeki dosyaların üzerine yazılma ihtimallerini önlemek için -n seçeneği kullanabiliyoruz. Eğer tek tek seçim yapıp hangisinin üzerine yazılıp hangisinin yazılmayacağına karar vermek istiyorsanız -i seçeneğini de kullanabileceğinizi zaten biliyorsunuz.

Şimdiye kadar hep dosyalar üzerinde çalıştık ancak dilersek dizinleri de kopyalayabiliyoruz. Fakat dizinler kendi içlerinde alt dizinler ve dosyalar barındırabileceği için bir dizini kopyalarken alt dizinlerin de kopyalanması için recursive yani özyinelemeli kopyalama seçeneğini de komutumuzu eklememiz gerekiyor. Buradaki özyineleme ifadesi, dizin altındaki tüm alt dizinlere teker teker bakıp, tüm dosya ve klasörlerin otomatik olarak seçilip kopyalanabilmesini sağlıyor. Zaten linux üzerinde dizinlerle çalışırken içi dolu olan dizinler üzerinde işlem yapmak için istisnalar hariç hep recursive yani özyineleme seçeneğini özellikle aktifleştirmemiz gerekiyor. İleride farklı araçlar üzerinde de recursive seçeneğinin bulunduğunu beraber deneyimleyeceğiz. Şimdi tekrar cp aracına dönecek olursak, öncelikle herhangi bir seçenek belirtmeden bir dizini kopyalamayı deneyebiliriz. Ben denemek için kendi ev dizinmdeki masaüstü dizinini yine ev dizinim altındaki documents klasörünün içine kopyalamak istiyorum. Bunun için cp ~/Desktop ~/Documents/ şeklinde komutumu girmeyi deneyebilirim.

Bakın komut hata verdi ve hata çıktısında -r seçeneğini kullanmadığım için Desktop dizinin kopyalanamadığı belirtilmiş. Şimdi aynı komuta bu kez -r seçeneğini de ekleyip tekrar deneyelim.

Herhangi bir hata almadık. Kopyalama işlemini teyit etmek için ls ~/Documents/Desktop/ şeklinde komutumuzu da girelim. Bakın Desktop dizinin tüm içeriği olduğu gibi Documents dizini altında listelenmiş. Hatta emin olmak isterseniz ls ~/Desktop/ komutunun çıktıları ile de kıyaslayabiliriz. Bakın birebir aynı içerikler kopyalanmış. Bizzat gördüğünüz gibi recursive yani özyineleme seçeneği, dizinlerin tüm içerikleriyle birlikte taşınması için şart.

Hazır dizin kopyalama işleminden bahsetmişken isteyebileceğiniz bir diğer duruma da değinmek istiyorum. Bazen kopyaladığımız dizinin ana klasörü hariç dizin içindekileri kopyalamak isteriz. Yani örneğin ben yalnızca Desktop klasörünün içindekileri kopyalayıp Desktop klasörünü hariç tutmak isteyebilirim. Bunun için büyük T seçeneğini kullanmamız yeterli. Tabii dizin içindekileri de kopyalacağımız için recursive seçeneği de dahil ederek komut girmemiz gerekiyor. Ben denemek için yalnızca masaüstü dizindeki içerikleri picture klasörüne kopyalamak istiyorum. Bunun için cp -rT ~/Desktop ~/Pictures şeklinde komutumuzu girebiliriz. Tamamdır şimdi ls ~/Picture komutu ile dizin içeriğini listeleyelim. Bakın Desktop klasörü bulunmuyor ancak Desktop klasörünün içeriği buraya kopyalanmış durumda. Bu yaklaşıma ihtiyacınız olursa, büyük T seçeneğini doğrudan hatırlamasanız bile cp —help komutu ile yardım bilgilerini listeleyip, listenden bu seçeneğe bakarak kolaylıkla hatırlayabilirsiniz.

Ayrıca yardım çıktılarından da görebildiğiniz gibi, cp aracının benim ele almadığım daha pek çok özelliği bulunuyor. Benim bahsettiklerim en temel kullanım için bilmemiz gerekenler. Geri kalan seçenekler için yardım sayfasına göz atabilirsiniz. 

# mv Komutu

Dosya veya dizinleri kopyalamak yerine taşımak yani yerini değiştirmek istediğimizde ingilizce move yani taşıma ifadesinin kısaltmasından gelen mv aracını kullanabiliyoruz. mv aracının kullanımı da tıpkı cp aracı gibi oldukça kolay. Zaten her iki aracın da hemen hemen pek çok seçeneği ortak kısaltmalar ile tanımlandığı için rahatlıkla kullanabiliyoruz. Gelin örnekler üzerinden temel kullanımını ele alalım.

Taşımak istediğimiz dosyayı mv dosya_adı tanışanacağı_yeni_konum şeklinde belirtmemiz yeterli oluyor. Ben örnek olarak kullanabilmek için touch tasinacak komutu ile  “tasinacak” isimli bir dosya oluşturmak istiyorum. Ayrıca klasör taşımayı da ele alacağımız için mkdir tasinacak-klasor komutu ile yeni bir klasör oluşturalım. Bakın dosya ve klasör oluşturuldu. Şimdi ben yeni oluşturduğum bu dosyayı, yeni oluşturduğum klasörün içine taşımak istiyorum.  Bunun için `mv tasinacak tasinacak-klasor` şeklinde komutumu girebilirim. Tamamdır, dosyamın şimdi taşınmış olması gerekiyor. Teyit etmek için öncelikle mevcut dizinimizi tekrar ls komutu ile listeleyebiliriz. Bakın tasinacak isimli bir dosya yok. Şimdi bir de klasörün içeriğini listelemek için ls tasinacak-klasor şeklinde komutumuzu girelim. Bakın dosyam tam da benim istediğim gibi bu klasöre taşınmış. 

Dosya yerine dilersek aynı şekilde klasörleri de taşıyabiliriz. Klasör taşırken içerisinin dolu olup olmaması önemli değil. Tek yapmamız gereken, hangi klasörü nereye taşıyacağımızı belirtmek. Ben örnek olması için bu yeni oluşturduğum ve içinde dosya bulunan tasinacak-klasor klasörünü masaüstüne taşımak istiyorum. Bunun için mv tasinacak-klasor ~/Desktop şeklinde komut girmem yeterli. ls komutu ile mevcut dizini listeleyelim. Bakın bu klasör artık burada değil. Bir de ls ~/Desktop komutu ile masaüstü dizinini listeleyelim. Gördüğünüz gibi ls komutunun neticesinde klasörün sorunsuzca taşındığını teyit edebiliyoruz. 

Benzer şekilde istersek aynı anda birden fazla klasörü veya dosyayı da taşıyabiliriz. Ben denemek için birkaç tane yeni dosya ve klasör oluşturmak istiyorum. Daha önceden a b c d dosyaları mevcuttu birde birkaç tane klasör oluşturalım. Tamamdır. Şimdi test etmek için yine masaüstündeki tasinacak-klasör isimli klasöre bu dosya ve klasörlerin hepsinin aynı anda taşınması için komutumuzu girmeyi deneyelim. Bunun için tek yapmamız gereken taşınacak dosya ve klasörlerin isimlerini yazıp, son olarak hangi dizine taşınacağını belirtmek. Komutumuzu onaylayalım. Şimdi ls ile mevcut dizinimizi listeleyecek olursak, bakın ilgili dosya ve klasörler burada gözükmüyor. Bir de taşıdığımız dizinine bakalım. Bakın görebildiğiniz gibi dosya ve klasörlerimi kolayca tek seferde istediğim dizine taşımış oldum. İşte mv aracının kullanımı bu kadar kolay.

Ben örnekler sırasında dosya veya klasörlerin isimlerini değiştirmek istemediğim için yalnızca taşınacakları adresleri belirttim. Bunun yerine taşındıkları konumda hangi isimle kaydedilmeleri gerektiğini de spesifik olarak belirtebiliyoruz aslında. Örnek olması için touch test komutu ile test isminde bir dosya oluşturalım. Şimdi bu dosyanın örneğin masaüstü dizinine yeni-test ismiyle kaydolmasını istersem komutumu mv test ~/Desktop/yeni-test şeklinde girebilirim. Bakın masaüstü dizininde bu isimde bir klasör olmadığı için taşımak istediğim “test” isimli dosya doğrudan masaüstüne “yeni-test” ismiyle taşınmış olacak. Sonucu görmek için masaüstü dizinini ls komutu ile listeleyebiliriz. Bakın yeni-test isimli dosya burada bulunuyor. İsim değiştirebilme özelliği süper ama isim değiştirmek için mv komutunu kullanırken, o dizinde daha önceden yeni tanımladığınız isimde bir klasör olmamasına mutlaka dikkat edin. Aksi halde mv komutu isim değiştirmek yerine, var olan klasöre klasörünüzü taşır.

Yani örneğin ben komutumu mv test ~/Desktop/yeni-test ifadesi yerine mv test ~/Desktop/tasinacak-klasor şeklinde girmiş olsaydım tabii ki mv komutu benim test dosyasının ismini değiştirme yerine bu dosyayı bu klasör altına taşımak istediğimi düşünecekti. Zaten bu durumu tahmin etmek zor değil ancak, yine de dikkat etmeniz için özellikle vurgulamak istedim.

Ayrıca tahmin edebileceğiniz gibi dosya ve klasörleri başka bir dizine taşırken isimlerini değiştirebiliyorsak, mevcut dizinde yalnızca isimlerini de değiştirebiliriz. Yani mv aracını doğrudan dosya veya klasörlerin isimlerini değiştirmek için de kullanabiliyoruz.

Ben yine örnek olması için touch test komutu ile test isminde bir dosya oluşturmak istiyorum. Şimdi bu dosyanın ismini güncellemek istersek tek yapmamız gereken, mv komutu ile bu dosyayı mevcut bulunduğu dizine yeni ismiyle taşımak. Yani ben dosyanın ismini yeni-test yapmak istersem komutumu mv test yeni-test şeklinde girmem yeterli. ls komutu ile mevcut dizini listeleyelim. Bakın dosyamın ismi yeni-test olarak değişmiş. İşte isim değiştirme işlemi bu kadar kolay.

Benzer şekilde aynı işlemi klasör isimlerini değiştirmek için de kullanabiliriz. Örnek olması için ben daha önce masaüstüne taşıdığımda klasörün ismini değiştirmek istiyorum. Örneğin bu klasörün ismi tasinacak-klasor, ben yeni isim olarak yalnızca klasor ifadesi olmasını istiyorum. Bunun için mv ~/Dekstop/tasinacak-klasor ~/Desktop/klasor şeklinde komutumu girmem yeterli. ls komutu ile desktop dizinini listeleyelim. Bakın klasör ismini de sorunsuzca değiştirmeyi başardık. İşte mv aracının en temel kullanım özellikleri bu şekilde. 

Ayrıca olası veri kayıplarını önlemek adına daha önce cp aracını ele alırken de bahsetmiş olduğum üzerine yazma durumlarından da kısaca bahsetmek istiyorum. Örneğin çoklu şekilde dosya veya klasörleri taşıyorsak daha önce cp komutunda olduğu gibi her adımda bizden onay alınmasını talep edebiliriz. Hemen basit bir örnek olması için mkdir test komutu ile yeni bir klasör oluşturalım. Şimdi bir de touch a b c komutu ile üç yeni dosyayı oluşturalım. Tamamdır. Bu dosyaları test klasörüne taşımak istersek bildiğiniz gibi mv a b c test/ şeklinde komutumuzu girmemiz yeterli. ls test/ komutu ile dizin içeriğini listeleyip kontrol edelim. Bakın dosyalar bu dizine taşınmış. Şimdi ben tekrar aynı isimlerde dosya oluşturup bu dosyaları yine aynı klasöre taşımak istersem ne olur ? Görmek için touch a  b c komutu ile dosyaları oluşturalım. Ve mv a b c test/ komutu ile tekrar klasörün içine taşıyalım. Bakın ls komutu ile teyit ettiğimizde dosyaların mevcut konumda bulunmadığını görebiliyoruz, yani taşınmışlar. Ama dikkat ettiyseniz taşıdığımız dizindeki aynı isimde tutulan dosyaların üzerine yazılacağına dair herhangi bir uyarı almadan bu dosyalar da taşınmış oldu. Yani dosyalar üzerine yazılmış oldular. Bu durumu önlemek için özellikle topluca taşıma yaparken -i seçeneğini kullanıp taşınacak dosya veya klasörlerden hangilerinin hedefteki dizinlerin üzerine yazılacağına dair bilgi edinip seçim yapabiliriz. Ben denemek için touch a b c d e komutu ile 5 yeni dosya oluşturuyorum. Şimdi a b c dosyaları ile aynı isimde dosyalar test klasörü içinde mevcut bulunuyor ama d v e isimli dosyalar yok. -i seçeneğinin nasıl çalışacağını görmek için komutumuzu mv -i a b c d e test/ şeklinde girelim. Bakın bana a dosyasının test klasörü alında mevcut olduğunu, dolayısıyla yeni dosyanın eskisinin üzerine yazılacağını belirten bir çıktı aldım. Eğer üzerine yazma işlemini onaylıyorsak y, onaylamıyorsak da n yazıp enter ile bir sonrakine geçiş yapabiliriz. Bu şekilde bakın sırasıyla üzerine yazılacak tüm dosyalar hakkında bizden izin istendi ama gördüğünüz gibi test klasöründe olmayan d ve e dosyaları yani yeni dosyalar hakkında herhangi bir izin istenmedi. İşte bu şekilde üzerine yazma ihtimalinden korunmak için gerektiğinde kritik dosya ve klasörler için -i seçeneğini de komutunuza dahil edebilirsiniz.

Özellikle toplu şekilde taşıma yapıyorken bazı dosyaların üzerine yazılmasını diğerlerin korunmasını istediğimiz durumda -i seçeneği tam olarak istediğimiz çözüm. Fakat her zaman tek tek belirtmek de istemeyebiliriz. Örneğin bir yerdeki dosyaları başka bir yere taşırken, eğer aynı isimde dosya varsa üzerine yazma demek için doğrudan -n seçeneğini de kullanabiliyoruz. Hatırlıyorsanız aynı seçenek cp komutunda da mevcuttu. Biz n seçeneğini kullandığımızda bize sorulmadan, eğer o dizinde aynı isimde dosyalar varsa bu dosyalar kesinlikle ilgili dizine taşınmıyor oldukları yerde kalıyorlar. Hemen denemek için touch a b 1 2 komutu ile a b 1 ve 2 dosyalarını oluşturalım. 

Şimdi, ls test/ komutu ile de teyit edebileceğimiz gibi test dizininde a ve b isimli dosyalar bulunuyor fakat 1 ve 2 isimli dosyalar bulunmuyor. Ben yalnızca benzersiz olan dosyaların test klasörüne taşınmasını istersem komutumu mv -n a b 1 2 test/ şeklinde girebilirim. Burada belirttiğim -n seçeneği sayesinde birden fazla dosyayı taşıyor olsam da yalnızca benzersiz olanlar test dizinine taşınacak. Komutumuzu onaylayalım. Şimdi mevcut bulunduğumuz dizini listeleyebiliriz. Bakın burada yalnızca a ve b dosyaları duruyor çünkü taşımak istediğimiz dizinde bu dosyalar ile aynı isimli dosyalar zaten mevcuttu. Dolayısıyla bunlar taşınmadan oldukları yerde kaldılar. Şimdi ls test/ komutu ile test klasörünün içeriğine de göz atalım. Bakın 1 ve 2 isimli dosyaların buraya taşınmış olduğunu görebiliyoruz. Böylelikle, -n seçeneği sayesinde yalnızca benzersiz olan dosyaların taşınmasının sağlandığını bizzat teyit etmiş olduk. Eğer taşıdığınız dosyaların, aynı isimli eski dosyaların üzerine yazılarak verileri yok etmesini istemiyorsanız -n seçeneğini kullanabilirsiniz.

Ben hızlıca örnek vermek için içi boş dosyalar kullandım ancak dilerseniz içi dolu olan dosyaları kullanarak, mv aracının taşıma işlemi yaparken aynı isimde dosyaların üzerine yazma işlemi yaptığını görebilirsiniz. Örnek olması için cat > test/a komutunu girip bu dosyanın içine de “ben ilk dosyayım” yazıp ctrl d ile dosya içeriğini kaydediyorum. 

Şimdi aynı isimde ama farklı içeriğine sahip bir dosya daha oluşturmak için cat > a şeklinde komutumuzu girip, içine de “ben ikinci dosyayım” şeklinde yazabiliriz. Tamamdır. Eğer ben mv komutuna -i veya -n gibi bir seçenek ekleyip üzerine yazmaya engel olacak bir önlem almazsam, buradaki “a” dosyasını test dizinine taşıdığımda, test dizini altındaki a dosyasının içeriği yok olacak. 

Denemek için mv a test/a şeklinde komutumuzu girebiliriz. Tamamdır. Şimdi test dizindeki a dosyasını cat komutu ile okuyup son durumu görelim. Bakın a dosyasının içeriği yeni taşıdığımız dosyanınkiyle değiştirilmiş. Yani yeni taşıdığımız aynı isimdeki dosya eski dosyanın üzerine yazılmış.

Bence mv komutu hakkında temelde bilmemiz gerekenler bunlar. Biraz daha kurcalarsanız ne kadar kolay kullanılabilir olduğunu bizzat deneyimleyebilirsiniz. Ben kendimi tekrar etmek istemediğim için çok fazla örnek vermedim ama siz kendi kendinize hem dosya hem de dizinleri taşıyarak kendi kendinize alıştırmalara yapıp mv aracının kullanımını iyi biçimde kavrayın. Ayrıca her zaman olduğu gibi elbette daha fazlası için mv —help komutu ile diğer seçenekleri ve özellikleri görüntüleyebilirsiniz.

# rm Komutu

Kopyalama ve taşıma araçlarından ve bunların temel kullanımlarından bahsettik. Şimdi bir diğer teme işlev olan silme işlevinden de bahsetmek istiyorum. Mevcut dosya ve klasörleri komut satırı üzerinden silmek istediğimizde rm aracını kullanabiliyoruz. rm aracının ismi ingilizce "remove" yani "silme/kaldırma" ifadesinin kısaltmasından geliyor. Tıpkı cp ve mv aracında olduğu gibi rm aracının kullanımı da son derece kolay.

İstersek tek bir dosyayı istersek de aynı anda birden fazla dosyayı silmek için tek yapmamız gereken, silmek istediğimiz dosyaların isimlerini rm komutundan sonra yazmak. Test amaçlı silinecek dosyalar oluşturmak için touch a b c d e komutu ile birden fazla dosya oluşturabiliriz. Tamamdır. 

Ben öncelikle denemek için tek bir dosya silmek istiyorum. Örneğin a isimli dosyayı silmek için rm a şeklinde komutumu girebilirim. Mevcut dizinimizi listeleyelim. Bakın a isimli dosya artık bulunmuyor. 

Eğer birden fazla dosyayı silmek istersem isimlerin peş peşe yazmam yeterli. rm komutundan sonra diğer dosyaların isimlerini de yazarak deneyebiliriz. Tekrar ls komutu ile mevcut dizini listeleyelim.

Bakın biraz önce oluşturduğum tüm dosaları rm aracı yardımıyla kolaylıkla silebildim. Ben bulunduğum konumdaki dosyaları sildim. Ancak elbette sistem üzerinde yetkinizin bulunduğu tüm dosyaları tam dizin adreslerini belirterek de silebilirsiniz. Örneğin ben test isimli dosyanın içine bazı dosyaları taşımıştım. Bunları silmek için rm test/ dosya ismi şeklinde spesifik olarak silinecek dosyanın konumunu ve adını belirtebilirim. Ben a isimli dosyayı silmek üzere komutumu giriyorum. Tamamdır, şimdi ls test/ komutu ile dosya ismini listeleyelim. Bakın ismini girmiş olduğum dosya silinmiş. İşte dosyaları tekil veya çoklu şekilde silmek bu kadar kolay. Tek yapmanız gereken silmek istediğiniz dosyanın tam olarak konumunu belirtmek.

Ayrıca fark ettiyseniz toplu şekilde dosya silerken bizden ekstra bir onay alınmadan tek seferde tüm dosyalar silindi. Bu durum kimi zaman istenmeyen sonuçlara yol açabilir. Eğer istersek silmeden önce her dosya için bizden onay istenmesini sağlayabiliriz. Bu sayede toplu silme işlemlerinde yanlış dosyaları silmekten de  kaçınmış oluruz. Örnek senaryomuzda, bir dizin içinde tüm dosyaları silmek üzere konsola rm * komutunu girdiğimizi farz edelim. Bu durumda kabuk yıldız işareti sayesinde bulunduğumuz dizindeki tüm dosyaları kapsayacağı için tüm dosyaların silinmesi emrini vermiş oluyoruz. 

Örneğin daha önce oluşturduğum test dizini altındaki dosyaları toplu şekilde silmek için rm test/* şeklinde komutumu girebilirim. Fakat ben tüm dosyaları silmek istemiyorum, bazılarını eleyip geri kalanları silmek istiyorum. Bunun için cp ve mv komutuyla da kullandığımız -i seçeneğini kullanabiliriz. Denemek için komutumuza -i seçeneğini de ekleyip girelim. 

Gördüğünüz gibi her bir dosya için tek tek onay isteniyor. Onaylamak için yes ifadesinin kısalması olan y, reddetmek için no ifadesinin kısalması olan n karakterini kullanmalıyız. Elbette kullandığınız işletim sisteminin diline göre onay ifadeleri de değişebilir. Örneğin türkçe için evet in e si hayır ın h si kullanılıyor. Ancak kursun başında da belirtiğim şekilde sistem dilini varsayılan yani ingilizce olarak kullanmanızı tavsiye ettiğim için ben ingilizce olduğunu varsayarak anlatıma devam edeceğim. 

Dosyalardan birine silinmesi için onay vermiyorum. Şimdi tekrar listeleyelim. Gördüğünüz gibi onay vermediğim dosya silinmemiş, geri kalan tüm dosyalar benim onaylımla silinmiş oldu.

Neticede i seçeneği sayesinde tüm silme işleminin adım adım bizden onay alınarak gerçekleştirilmesini sağlamış olduk. Ayrıca tek tek sorulması yerine ğer toplu şekilde silinmeden önce son bir kez onay alınsın isterseniz büyük I seçeneğini de kullanabiliriz. Hemen denemek için touch a b c d e komutu ile yine sıralı dosyalarımı oluşturalım. Şimdi bu dosyaları silmek için rm {a..e} şeklinde komutumu girebilirim. Bu komut sayesinde a dan e ye kadar olan karakterler ile eşleşen dosyaların tamamı silinecek. Ben silmeden önce son kez bana sorulmasını da istediğim için büyük -I seçeneğini de ekleyip komutumu bu şekilde çalıştırıyorum.

Bakın, silineceklerin adeti belirtilerek silmeden önce son bir kez emin olmamız için soruluyor. Onay verirsem yani y yazarsam hepsi silinecek. Onay veriyorum. ls komutu ile mevcut dizinimizi listeleyelim, gördüğünüz gibi dosyalar benden onay alınarak silinmiş oldu.

Tamamdır bence dosyaları silmekle ilgili tüm temel bilgilerden bahsettik. Şimdi klasörleri nasıl silebileceğimizi örnekler üzerinden ele alalım.

## Klasörlerin Silinmesi

Normalde rm komutunu ekstra bir seçenek belirtmeden kullandığımızda rm aracı yalnızca kendisine argüman olarak verilmiş olan dosyaları siliyor. Yani aynı isimle eşleşen klasörleri silmiyor. Klasörleri silmesi için silinecek şeyin özellikle klasör olduğunu ingilizce directory yani klasör ifadesinin kısaltmasından gelen -d seçeneği ile belirtmemiz gerekiyor.

Hemen deneyelim. Ben test etmek için mkdir sil-beni komutu ile yeni klasör oluşturuyorum. Şimdi rm komutu ile oluşturduğumuz bu dosyayı silmeyi deneyebiliriz. Bakın aldığımız çıktıda, klasör olduğu için silinemediği konusunda uyarıldık. Eğer directory yani klasör ifadesinin kısaltması olan d seçeneğini kullanırsak silebileceğiz. Hemen deneyelim.

Gördüğünüz gibi d seçeneği sayesinde klasörüm sorunsuzca silinmiş oldu. 

Dosyalara benzer şekilde klasörleri de çoklu şekilde silebiliriz. Denemek için hemen mkdir x y z komutu ile yeni birkaç klasör oluşturalım. Silmek üzere klasör isimlerini peş peşe girmemiz yeterli. Eğer silinmeden önce  bizden tek tek onay alınsın istersek elbette i seçeneği de kullanabiliriz. Gördüğünüz gibi klasörlerin silinmesi için tek tek bizden onay bekleniyor. Ben hepsine onay vereceğim. ls komutu ile silinip silinmediklerini kontrol edelim. Bakın klasörleri toplu şekilde silebildik.

Şu ana kadar klasörleri silerken hiç bir problem yaşamadık, çünkü klasör içerikleri boştu. Eğer klasörlerin içinde başka dosyalar ve klasörler bulunuyorsa, rm -d komutu ile silmemiz mümkün değil. Hemen deneyelim. 

Mesela teyit etmek için daha önceden oluşturduğum documents dizini altındaki klasörümü silmeyi deneyebilirim. Silmek için rm -d ~/Documents/klasor şeklinde komutumuzu girelim. Gördüğünüz gibi dizin boş olmadığı için silinemediği konusunda uyarıldık. İçerisi dolu dizinleri silmek için -r seçeneğini kullanmamız gerekiyor. Buradaki r seçeneği ingilizce recursive yani özyinelemeli ifadesinin kısaltmasından geliyor.

 Bu seçenek sayesinde klasörün içinde iç içe birden fazla klasör ve dosya olsa da tüm dosyaların ve klasörlerin silinebilmesi mümkün oluyor. Hatırlıyorsanız klasör içeriklerini kopyalarken de bu şekilde recursive seçeneğini eklemiştik. En alt dizine kadar bakılıp silmesi özyineleme özelliğini temsil ediyor yani. Hatta recurisve yani özyineleme seçeneğini yalnızca klasörler üzerinde kullandığımız için aslında rm aracına ek olarak -d seçeneğini de girmemiz gerekimiyor. Yani rm -r silinecek-klasör ismi şeklinde komutumuzu girdiğimizde, belirttiğimiz dizin tüm içeriğiyle birlikte siliniyorum. Hemen komutumuzu onaylayalım. Bakın yalnızca -r seçeneğini kullanarak içi dolu klasörü silmeyi başardım.

Ben kullanmadım ancak özellikle iç içe klasörler ve dosyalar barındıran klasörleri silerken, i seçeneğini ekleyerek yanlış bir dosyayı veya klasörü silmediğinizden emin olmanızı önerebilirim. Yine de klasörden tek seferde kurtulmak istediğinize eminseniz elbette i seçeneğini kullanmak zorunda değilsiniz.

Ayrıca hatırlıyorsanız, boş dizinleri silmek için daha önce rmdir aracını kullanmıştık. İşte rm -d komutu rmdir aracı ile aynı işlevi görüyor. İçerisi dolu olan dizinleri silmek için de rm -r komutunu kullanıyoruz. Dolayısıyla emin olmadığınız sürece rm -r komutunu kullanmanız önermem. Yine de elbette klasörü içeriğiyle birlikte silmek istediğinizden eminseniz kullanabilirsiniz.

Son olarak eğer, tüm silme adımlarının ayrıntılarını da takip etmek isterseniz verbose yani ayrıntılı ifadesinin kısaltması olan v seçeneğini de kullanabilirsiniz. Toplu şekilde klasör silerek kullanımı teyit edebiliriz. Önce klasörlerimizi oluşturalım. Şimdi de toplu şekilde silmek için rm -dv komutunun arından klasör isimlerini girelim. Gördüğünüz gibi tüm bilgiler konsola basılmış oldu. Neticede rm komutu hakkında bilmemiz gereken tüm temel yaklaşımlardan bahsettik. Diğer seçenekleri görmek için yardım sayfasına göz atabilirsiniz. Ben bir sonraki bölümde dosyaları nasıl geri döndürülemez şekilde yani kalıcı olarak silebileceğimizden bahsetmek istiyorum.

# shred Komutu | Dosyaları Geri Döndürülemez Şekilde Silmek

Geri döndürülemez yani kalıcı silme kavramından bahsetmeden önce silme işlemlerinin temelde nasıl işlediğinden bahsetmek istiyorum. Bu sayede kalıcı silmeden kastın ne olduğu daha net anlaşılabilir. 

Eğer herhangi bir dosyayı sildiğinizde o dosyanın tamamen yok olduğunu düşünüyorsanız kesinlikle yanılıyorsunuz. Bu durumun nedenini eğitimin devamında disk yönetimi ve inode kavramlarını ele aldıktan sonra çok daha net anlamış olacağız. Ancak şimdilik kısaca özetlemek gerekirse işletim sistemleri dosya silme emri aldığında o dosyayı gerçekten diskten silmek yerine, dosyaya ulaşmanızı sağlayan yolun bilgisini silerler. Yani aslında dosya hala disk üzerinde mevcut olmasına rağmen, sadece dosyaya giden bağlantı siliniyor. Bu yöntemin kullanılma nedeni dosyayı gerçekten silmeye oranla çok daha hızlı sonuç vermesidir. Peki ama gerçek silme işleminden kastımız tam olarak ne ?

Gerçek silme işlemi dediğimiz kavram; disk üzerinde yer kaplayan her türlü verinin ancak üzerine yeni veriler yazılması ile ortadan kaldırılabilecek olmasını temsil ediyor. Çünkü üstüne yeni veri yazılarak tahrip edilmeyen her türlü verinin tekrar kurtarılma ihtimali var. Adli bilişim alanında bu iş için kullanılan pek çok yazılımsal ve harici olarak fiziksel kurtarma yöntemi bulunuyor.

İşin özü eğer bir dosyadan geri döndürülemez şekilde kurtulmak istiyorsak o dosyayı silerken üzerine birden fazla kez rastgele veri yazılmasını sağlamamız gerekiyor. Pek çok işletim sisteminde bu üzerine yazma işlemi için harici yazılımlar yükleyip kullanmamız gerekebiliyor. Ancak söz konusu Linux olduğunda pek çok dağıtımda varsayılan olarak yüklü gelen shred isimli aracı kullanabilme kolaylığa sahibiz. 

Zaten shred ifadesi Türkçe olarak "parçalamak" anlamına geliyor. Eğer herhangi bir arama motoruna yazarsanız, karşınıza parçalanmış kağıt görselleri çıkacaktır. Bu aracı kullanarak, dosyaların üzerine veriler yazılarak tahrip edilmesini sağlayabiliyoruz. Bu araç dosya içeriğini geri döndürülemez şekilde tahrip etmek için kullanılıyor. Dosya içeriği tahrip olduktan sonra da dosyayı güvenle sıradan şekilde silebiliyoruz çünkü dosya geri getirilse bile orijinali tahrip edildiği için gerçek içeriğine ulaşılamıyor.

Silme mekanizmalarından bence yeterince bahsettik. Şimdi lafı daha fazla uzatmadan shred komutunun kullanımından bahsederek devam edelim.

shred komutunu herhangi bir ek seçenek belirtmeden kullandığımızda varsayılan olarak kendisine argüman olarak verilmiş olan dosyanın üzerine 3 kez rastgele bitler yazılmasını sağlıyor. Eğer daha fazla kez yazılmasını istersek, -n seçeneğini kullanıp kaç kez yazılması gerektiğini özellikle de belirtebiliyoruz.. Ayrıca -v seçeneğini ekleyerek verbose yani ayrıntılı çıktı vermesini de sağlayabiliriz. Bu sayede tüm adımları konsoldan takip edebiliriz.

Ben denemek için yeni bir dosya oluşturmak istiyorum. Bunun için cat > oku-beni komutunu giriyorum, ve “bu bir dosyadır” ifadesini ekleyip ctrl d ile dosyanın içeriğini kaydediyorum. Öncelikle dosya içeriğimin okunaklı olduğunu cat komutu ile teyit edelim. Bakın içeriği sorunsuzca okuyabiliyoruz. Şimdi shred aracını kullanarak dosya içeriğine rastgele bitler yazılmasını sağlayabiliriz. Ben varsayılan şekilde yani 3 kez rastgele bitler yazılması için shred aracına özellikle bir sayı vermek istemiyorum ama işlem adımlarını takip etmek için verbose yani ayrıntılı çıktı seçeneğini ekleyeceğim. Komutumu shred -v oku-beni şeklinde giriyorum. Bakın 3 kez rasgele verilerin bu dosya üzerinden geçirildiğine dair çıktılarımızı aldık. Dosya içeriğini görmek için cat komutu ile dosyamızı okuyalım. Bakın dosyanın içeriği tamamen okunamaz halde. Artık bu dosyayı rm komutu ile gönül rahatlığıyla silebiliriz çünkü dosya geri getirilse bile içeriğindeki verilere ulaşılması pek olası değil. Çünkü içerisine 3 kez rastgele veriler yazıldı.

İşte shred aracının kullanımı bu kadar kolay. 

Ayrıca daha önce de bahsettiğim şekilde istersek kaç kez rastgele veri yazılacağını da -n seçeneğinin ardından özellikle belirtebiliyoruz. Örneğin ben 5 kez rastgele veri yazılmasını istersem shred -n 5 dosya-adı şeklinde komutumu girebilirim. Hatta sayıyı belirtmeye ek olarak rastgele yazma işleminden hemen sonra bu dosyanın silinmesini de sağlayabiliriz. Dosyanın silinmesi için de -u seçeneğini eklememiz yeterli oluyor. 

Ben denemek için bu oku-beni dosyasının üzerine 5 kez rastgele veri yazılıp daha sonra silinmesini için komutumu girmek istiyorum. Tabii tüm işlem adımlarını takip edebilmek için bir de -v seçeneği ile ayrıntıların da bastırılmasını istiyorum. Bunun için shred -uvn 5 oku-beni şeklinde komutumu giriyorum. Bakın öncelikle dosya içeriğine rastgele 5 kez veriler yazılmış, daha sonra dosya silinmiş ve son olarak dosyanın isminin de silinmesi için dosya ismi de adım adım sıfırlar ile doldurularak yok edilmiş. Bu yaklaşım sayesinde dosyanın isminin dahi disk üzerinden kurtarılması pek olası değil.

Hatta teyit etmek için ls komutu ile mevcut dizinimizi listeleyebiliriz. Bakın gördüğünüz gibi dosyamız işlem sonunda otomatik olarak silinmiş.

Ayrıca benim örnekler üzerinde kullandığım dosyanın içeriği çok küçük olduğu için tüm işlem çok kısa sürede tamamlandı ancak bu durum her zaman böyle olmayabilir. Yani üzerine yazma işlemi, üzerine yazılacak olan dosyanın boyutuna göre biraz uzun sürebilir, sabırla işlem tamamlanana kadar beklemelisiniz. Benim dosya boyutum çok küçük olduğu için işlem çok kısa sürede tamamlandı. 

Neticede sizler de kalıcı olarak istediğiniz dosyalarınızı bu yaklaşım sayesinde güvenli şekilde silebilirsiniz. Hazır silme işlemlerinden bahsetmişken bir sonraki bölümde Linux sistemlerinde geri dönüşüm kutusu hakkında da çok kısaca bilgi vermek istiyorum.

# Linux geri dönüşüm kutusu ?

Komut satırı üzerinden bir dosyayı sildiğimizde, normalde grafiksel arayüzde olduğu gibi sildiğimiz dosya çöp kutusuna gönderilmiyor. Yani çöp kutusu olarak geçen dizin yalnızca grafiksel arayüzdeki dosya silme işlemlerinde kullanılan sembolik bir dosya yolu.

Denemek için grafiksel arayüzdeyken bir dosyanın üzerine tıklayıp delete tuşu ile dosyayı silebiliriz. Bakın dosyam silindi. Şimdi masaüstünde bulunan çok kutusu olarak temsil edilen bu dizini açıp bakalım. Bakın silmiş olduğumuz dosya burada bulunuyor. Şimdi denemek için touch deneme komutu ile yeni bir dosya oluşturalım. Ve bu dosyayı rm komutu ile silelim. Bakın komut satırı üzerinden silme işlemi gerçekleştirdiğimiz için çöp kutusuna herhangi bir dosya eklenmedi. Zaten komut satırı üzerinden sildiğimizde buradaki çöp kutusuna geliyor olsaydı önceki silme işlemlerinin kalıntılarını burada görüyor olmamız gerekiyordu. 

Komut satırından silinen dosyaların burada gözükmüyor olmasına ek olarak windoows sisteminden de aşina olduğumuz gibi grafiksel arayüzdeyken shft delete tuşlaması ile bir dosya veya klasörü sildiğimizde bu dosya veya klasör bu çöp dizinine gelmeden komut satırında olduğu şekilde siliniyor. Tabii ki shift delete tuşlaması bizim shred komutu ile sildiğimiz gibi silmiyor ancak en azından çöp dizinine de taşımış olmuyoruz. 

Komut satırından veya shfit delete ile grafiksel arayüzden sildiğiniz dosyaları geri getirmek isterseniz de testdisk gibi harici disk kurtarma yazılımları ile ilgili dosyalarınızı kurtarabilirsiniz. Tabii ki daha önce de belirttiğim şekilde eğer shred aracı ile dosya içeriklerini tahrip ettiyseniz yani kalıcı olarak sildiyseniz kurtarma yazılımları ile ilgili dosyaları kurtarmanız pek olası değil. 

İşte tüm bahsetmiş olduğumuz silme yaklaşımlarının bilincinde olarak silme ve geri kurtarma planlarınızı bilgileriniz dahilinde yerine getirebilirsiniz.