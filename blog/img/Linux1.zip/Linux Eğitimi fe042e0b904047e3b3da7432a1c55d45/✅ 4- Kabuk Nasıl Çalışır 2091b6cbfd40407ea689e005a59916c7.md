# ✅ 4- Kabuk Nasıl Çalışır?

Bu bölümde kabuğun nasıl çalıştığından bahsediyor olacağız. Ancak şimdiden üstüne basarak söylüyorum elbette tüm detayları ile kabuğun nasıl çalıştığına değinmeyeceğiz. Ben bazı konuları ve ek detayları atlayıp anlatımı sadeleştirmek için doğrudan en genel mekanizmasından bahsediyor olacağım. Çünkü temel sistem yönetimi için tüm detayları bilmenize gerek yok. Bu eğitimi bitirip gereken temel altyapıya sahip olduktan sonra harici olarak kabuk programlama gibi çeşitli eğitimler içerisinde daha fazla detayı keşfetmeniz mümkün olabilir. Hatta sizin bu eğitimi takip ettiğiniz dönemde, eğer ben uygun şartları sağlayabildiysem bir kabuk programlama eğitimi hazırlamış da olabilirim. Kabuk programlama eğitimi içerisinde de kabuğun nasıl çalıştığından daha detaylıca bahsetmiş oluruz mutlaka.

Henüz bölümün en başında tüm detaylardan bahsetmeyeceğim dememin sizin üzerinde oluşturabileceği eksiklik algısının da farkındayım ancak lütfen bana güvenin. Bu eğitimde bizi yormayacak ve en temelde edinmemiz gereken bilgileri ele alıyor olacağız. Yani ne eksik ne fazla. Eğer bu eğitimi tamamlarsanız zaten daha fazla detayı araştırırken rastlayacağınız bilgileri çok daha net ve kolay kavrayabileceksiniz. 

Ben bu eğitimde kabuğun çalışma yapısının bazı detaylarını atlıyor olacağım çünkü bazı konulardan kabuk programlama eğitimi yerine bu eğitimde bahsetsek bile henüz Linux sistemini yani tanımaya başladığımız için yani gereken altyapıya henüz sahip olmadığımız için ek detaylar anlaşılır olmayacak. Bu doğrultuda odak noktamızı yani Linux sistem yönetiminin temellerini öğrenme hedefimizi şaşırmadan devam etmeye çalışalım. Eğitime devam ettikçe zaten kabukla ilgili pek çok yeni bilgiyi parça parça öğreniyor olacağız. Yani öğrenmek için acele edip konuları sıkıştırmanın bir anlamı yok. Böyle yaparsak çok fazla bilgi edinelim derken hiç bir şey öğrenemeyiz. Gerekli olan temel bilgi altyapısı için biz tüm konuları sindire sindire ilerlemeye çalışalım.

Anlatımlarımıza öncelikle kabuğun bizim girdiğimiz komutları nasıl algıladığından bahsederek başlayabiliriz. Bu konuyla başlıyoruz çünkü kabuğun bizi nasıl anladığını bilmek, kabuğa anlayacağı türden komutlar girebilmemiz için çok önemli. 

Ben kabuğun bizim girdiğimiz komutları nasıl algıladığını açıklayabilmek için örnek olarak dosya ve dizinlerde araştırma yapabilmemizi sağlayan find aracını çalıştırmak üzere komut gireceğim. Biliyorum henüz bu aracın kullanımından özellikle bahsetmedim ancak merak etmeyin çünkü aslında burada kullanılan aracın esasen hiç bir önemi yok. Sadece kabuğa girdiğimiz komutların kabuk tarafından nasıl anlaşıldığını kolay açıklayabileceğimiz basit bir örnek olması için bu aracı kullanıyor olacağız. Eğitimin devamında da bu aracın kullanımından zaten ayrıca bahsedeceğiz.

Örnek olarak kullanacağımız araç, dosya ve dizinleri arayıp bulma işlevinde olduğu için öncelikle araştırma sırasında kullanılacak örnek dosyalarımızı oluşturabiliriz. Ben öncelikle kendi masaüstü dizinimde test isimli bir klasör oluşturmak istiyorum. Klasör oluşturma işlemleri için komut satırını da kullanabiliriz ancak henüz bahsetmediğim başka komutlar ile dikkatinizi dağıtmak istemediğim için doğrudan masaüstüme sağ tıklayıp yeni klasör oluşturma seçeneğine tıklıyorum. Ben klasörümün ismini test olarak belirliyorum. Tamamdır bakın klasörüm oluşturuldu. Şimdi örnek olması için bu kez biraz daha farklı bir dizin altında yeni bir klasör daha oluşturabiliriz. Ben bu kez kendi ev dizinimde bulunan documents klasörünün içinde oluşturmak istiyorum. Aynı şekilde bu dizindeyken de asğ tıklayıp istediğimiz isimde klasör oluşturabiliriz. Ben yine ismini test olarak ayarlıyorum. Tamamdır, bu dizinim de sorunsuzca oluşturuldu.

Örnek için gerekli klasörlerimizi oluşturduğumuza göre şimdi farklı dizinlerde yer alan test klasörlerinin find aracı ile bulunması için komutumuzu girebiliriz. Ben klasörleri kendi ev dizinim altında oluşturmuştum. Bu sebeple dosya sistemi hiyerarşisinde benim ev dizinimi de barındıran /home dizini altında araştırma yapmamız yeterli olacak. Yani benim ev dizinim bu /home klasörü altında tutuluyor, o yüzden araştırmaya bu dizinden başlayabiliriz. 

Tamamdır, lafı daha fazla uzatmadan öncelikle komutumuzu girelim zaten daha sonra hangi ifadeyi neden yazdığımı tek tek açıklayacağım.

```jsx
└─$ find /home -type d -name test
/home/kali/Documents/test
/home/kali/test
```

Bakın hem masüastündeki hem documents dizinineki test isimli klasörler find aracı tarafından girmiş olduğum komut sayesinde bulunup bize çıktı olarak söylenmiş oldu. 

Buraya girmiş olduğumuz komutun anlamına gelecek olursak: Buradaki ifade ile `find` aracına, araştırması gereken dizinin `/home` dizini olduğunu özellikle belirttim. Bu sayede find aracı tüm sisteme bakmak yerine yalnızca bu dizin altındaki dosya ve klasörler üzerinde araştırma yapması gerektiğini öğrenmiş oldu. 

Buradaki -type d ifadesi ile de, yalnızca home dizini altındaki klasörlere bakması gerektiğini söylemiş oldum. Buradaki `d` "directory" yani "dizin/klasor" ifadesinin kısaltmasından geliyor. 

Son olarak da dizinler içinden yalnızca isminde "test" geçenleri bulması için "`-name`" ifadesinin ardından "test" şeklinde yazdım. Neticede `find` komutu, /home dizini altında bulunan ve ismi test olan klasörlerin adresini çıktı olarak bize verdi. İşte girmiş olduğumuz komutun açıklaması bu. Ben tam olarak istediğim görevi kabuğa yazılı şekilde ifade ettim, kabuk da find aracına bu emirleri uygun şekilde aktardı. Find aracı da bu sayede tam olarak ne yapması gerektiğini bilip, görevini sorunsuzca yerine getirdi. 

Neticede emrim yerine getirildi yani komutum sorunsuzca çalıştı. Ancak benim burada değinmek istediğim asıl nokta, girmiş olduğum komutun kabuk tarafından nasıl doğru şekilde algılanıp find aracına iletildiği. Yani örneğin kabuk benim yazmış olduğum find ifadesine bakarak find aracını bulup nasıl çalıştırdı ve daha ilginci burada find ifadesinden sonra yazdıklarımın hangilerinin find aracına iletileceğine nasıl karar verdi ? 

Gelin şimdi kısaca bizim kabuğa girdiğimiz bu komutun kabuk tarafından nasıl algılandığına değinmeye çalışalım. Bunun için öncelikle genel olarak kabuğun bizim girdiğimiz herhangi bir komutu nasıl algıladığından bahsedip, daha sonra bu bahsettiklerimizi buradaki komut üzerinden adım adım açıklayabiliriz. Öncelikle kabuğun komutları nasıl algıladığına değinecek olursak:

Kabuk ilk olarak, kendisine verilmiş olan komuta bakıp aralarında boşluk karakteri bulunan tüm ifadeleri birbirinden ayırıp bunların her birine ayrı bir argüman gözüyle bakıyor. Yani arasında boşluk bulunan ifadelerin her birini kabuk için birer argümandır. Kabuk girilen ifadeleri tek tek argümanlara ayırdıktan sonra bu argümanlar içerisinde, kabuk için özel anlam ifade eden karakterler var mı diye tek tek kontrol ediyor. Eğer kabuk için özel anlamı olan karakter varsa da buna göre davranıyor. Örneğin girdiğimiz komutta aynı anda iki farklı aracı çalıştırabilmemizi sağlayan özel bir karakter kullandıysak kabuk bu argümanlar içinde o özel karakteri gördüğünde bizim iki farklı aracı kullanmak istediğimizi anlayıp girdiğimiz diğer argümanları da buna göre değerlendiriyor. 

Öte yandan eğer kabuk için özel anlam ifade eden bir karakter yoksa kabuk buradaki argümanların tek bir aracı kullanmak için girilmiş olan argümanlar olduğunu anlıyor. Dolayısıyla ilgili aracı bulup buradaki argümanları o araca ileterek aracın verilen görevi doğru şekilde yerine getirmesini sağlıyor. 

Benzer şekilde örneğin iki farklı aracı çalıştırmak için tek satıra komutumuzu girmiş olsaydık, kabuk iki aracın ayırt edilebilmesini sağlayan özel karakterin bulunduğu pozisyona göre, argüman gruplarını yalnızca ilgili araca aktarıyor olacaktı. 

Ne demek istediğimi daha iyi anlamak için gelin hemen somut bir örnek yapalım. Öncelikle echo ilk deneme echo ikinci deneme şeklinde komutumuzu girelim. 

Bakın benim girmiş olduğum komut ilk olarak boşluklarından argümanlara ayrıldı ve kabuk tarafından özel bir anlamı olan karakter var mı diye kontrol edildi. Özel anlamı olan bir karakter olmadığı için kabuk, ilk argümanı çalıştırılması gereken araç olarak kabul edip geri kalan argümanları da bu araca argüman olarak aktardı. 

İlk komuttan sonrakiler ilk komutun argümanı olarak araca iletildiği için burada tıpkı en baştaki gibi echo ifadesi yer almasına karşın, bu ifade de yalnızca konsola çıktı olarak bastırıldı. Yani kabuk buradaki ikinci echo ifadesine bakarak echo aracının tekrar çalıştırılıp buradan sonraki argümanları ayrı olarak bastırılmasını sağlayamadı. Çünkü biz böyle bir ayrım belirtmedik.  

Bu kez aynı örneğini kabuk için iki farklı komutu temsil eden noktalı virgül karakterini de kullanarak tekrar deneyebiliriz. Ben denemek için bu kez komutumu echo ilk deneme ; echo ikinci deneme şeklinde giriyorum. Bakın kabuk buradaki özel karakteri gördüğü için bu karakterden önceki argümanları bu ilk araca aktarırken, bu karakterden sonraki argümanları 2. argümandan başlayarak buradaki araca iletti. Dolayısıyla “ilk deneme” ve “ikinci deneme” ifadelerini ayrı ayrı konsolda görebildik. Dikkat ettiyseniz buradaki echo ifadesi de ilk örneğimizdekinin aksine kabuk tarafından çalıştırılması gereken bir araç olarak algılandığı için bu çıktıyı elde edebildik. 

Bence bu basit örnek üzerinden kabuğun bizim girdiğimiz komutları nasıl işlediği çok basit düzeyde de olsa görebildik. Yine de yapıyı daha iyi anlamak için birkaç detaydan daha bahsetmek istiyorum.

Örneğin kabuğun çalıştırılacak araçları nasıl bulup çalıştırdığından bahsetmemiz gerekirse ilk argüman, kabuk için çalıştırılması gereken dosyanın ismi olarak algılanıyor. Kabuk öncelikle bu ilk kelime ile eşleşen yerleşik bir bash komutu var mı diye bakıyor, eğer varsa bu komutu çalıştırıyor. Eğer ilk argüman herhangi bir yerleşik komutla eşleşmediyse, PATH olarak geçen bazı dizinler üzerinde bu isimle eşleşen çalıştırılabilir bir dosya var mı diye bakıyor, varsa da çalıştırıyor. 

Tüm bunlar dışında eğer ilk argüman yerleşik bir komut değilse ve PATH yolu olarak geçen dizinler içinde bu isimde çalıştırılabilir bir dosya da yoksa, kabuk tarafından komut yok hatası veriliyor. Çünkü kabuk hangi aracın çalıştırılmak istendiğini anlayamıyor.

İşte bizler kabuğa komut girdiğimizde, kabuk burada bahsettiğimiz şekilde girdiğimiz komutları ayrıştırıp kontrol ediyor ve mümkünse çalıştırılması gereken aracı bulup çalıştırıyor. Ve elbette ilk argümandan sonra yazılmış olan argümanların bash kabuğu için özel bir anlamı yoksa, bu argümanların hepsi çalıştırılan araca argüman olarak iletiliyor. Bu noktadan sonrası artık çalıştırılan aracın bu argümanları nasıl ele alıp işleyeceğiyle ilgili. Çünkü kabuk ilgili aracı bulup gerekli argümanlarla çalıştırılmasını sağlayarak görevini tamamladı. Bundan sonrası ilgili aracın bu argümanlarla ne yapacağıyla ilgili.

Heh işte söz konusu araçlara iletilen argümanlar olduğunda da bu noktada “seçenek” ve “parametre” olarak geçen iki kavramdan bahsetmemiz gerekiyor.

Öncelikle seçenek kavramının ne anlama geldiğinden bahsedecek olursak: Sizlerin de bildiği gibi araçların çeşitli görevleri yerine getirebilmek için çeşitli özellikleri bulunuyor. İşte bizler de komut satırından bu farklı özellikleri kullanabilmek için bu özellikleri temsil eden seçenek ifadelerini kullanmamız gerekiyor. Araçların geliştiricileri, aracın özelliklerinin kullanılabilmesi için bazı anahtar kelimeleri ve kısaltmaları zaten aracın özel olarak seçenekleri olarak tanımlıyor. Biz komut girerken girdiğimiz argümanın aslında aracın bir seçeneği olduğunu belirtmek için de tek veya çift kısa çizgi karakteri başta olacak şekilde yazıyoruz. 

Örneğin ben konsola yalnızca ls ifadesini yazarsam ls komutu bulunup çalıştırılıyor ve detaysız şekilde mevcut bulunduğum dizindeki tüm dosya ve klasörler konsola bastırılıyor gördüğünüz gibi. 

Ben ls aracının bu çıktıları detaylı şekilde sunma özelliğini kullanmak istediğim için bu özelliği temsil eden “l” seçeneğini ls -l şeklinde yazabilirim. Bakın ls aracı -l argümanını aldığında bunun bir özelliği belirten seçenek olduğunu anlıyor ve “l” seçeneğinin karşılığı olan detaylı listeleme özelliğinin çalıştırılmasını sağlıyor. Neticede ben ls aracının hangi özelliğini kullanmak istediğimi buradaki seçenek sayesinde belirtebiliyorum gördüğünüz gibi. Yani seçenek olarak bahsettiğimiz kavram işte tam olarak bu örnekte gördüğünüz argümandır. Bu argümanın araç için özel anlamı var.

Argüman ve seçenek kavramlarının ne olduğunu öğrendiğimize göre son olarak “parametre” kavramından da bahsedebiliriz. Parametreler, araçlara ya da araçların özelliklerini kullanabilmemizi sağlayan seçeneklerine bilgi sağlayan argümanlardır. Biliyorum bu tanım, örnek üzerinden anlatmadığım için pek anlaşılır olmadı. Ancak merak etmeyin çünkü aslında anlaması çok kolay. Hadi gelin daha iyi anlamak için şu ana kadar bahsettiğimiz tüm kavramların kabuğa verdiğimiz ilk komuttaki karşılığına tekrar bakalım.

![argüman-parametre-seçenek.png](%E2%9C%85%204-%20Kabuk%20Nas%C4%B1l%20C%CC%A7al%C4%B1s%CC%A7%C4%B1r%202091b6cbfd40407ea689e005a59916c7/argman-parametre-seenek.png)

Kabuğa buradaki komutumuzu girdik. Kabuk öncelikle arasında boşluk bulunan tüm ifadeleri argümanlar olarak ayırdı. İlk girilen komut yani ilk argüman find olduğu için kabuk "find" ifadesini çalıştırılacak araç olarak kabul ediliyor. Ve bu aracı çalıştırmak için de öncelikle bu isimle ile eşleşen yerleşik bir araç var mı diye bakıyor. find aracı bash kabuğunda yerleşik bir araç olmadığı için elbette herhangi bir eşleşme olmuyor. Kabuk bu kez PATH olarak geçen birtakım dizinlerin içinde find ismiyle eşleşen çalıştırabilir bir dosya var mı diye bakıyor. Ve neticede bu dizinlerin birinde find aracının dosyası bulunduğu için bu dosya kabuk tarafından çalıştırıyor. 

Çalıştırılacak araç bulunduktan sonra burada yer alan ilk argümandan sonraki argümanlar, istisnai durumlar dışında çalıştırılan araca verilecek argümanlar olarak kabul ediliyor. Dolayısıyla find komutunun ardından yazılmış olan argümanlar find komutunun çalışma şeklini tanımlamak için bulunuyor. Örneğin ikinci argüman find komutunun nerede araştırma yapması yani nereye bakması gerektiğini belirten bir parametredir. Buradaki argümana parametre diyorum çünkü bu argüman find komutunun spesifik olarak nereye bakması gerektiğini haber veren bir bilgi bulunduruyor. Buradaki /home dizini yerine başka herhangi bir dizin de belirtilebilir. Yani buradaki argüman aslında çalıştırılan araç için bir parametre. 

Üçüncü argüman ise find komutuna hangi tipte veri araması gerektiğini belirtmemizi sağlayan seçenektir. Seçenekler yazılırken tıpkı bu komutumuzda da olduğu gibi genellikle başında tek ya da çift kısa çizgi bulunduruyor. Tek ya da çift kısa çizgi olması tamamen kullandığınız aracın seçenekleri nasıl kabul ettiğine bağlı. Çünkü seçenekler aslında zaten araç geliştiricileri tarafından aracın çeşitli özelliklerinin kullanılabilmesi için önceden tanımlamış bazı özel ifadelerdir. İleride farklı araçları ele aldığımızda seçeneklerin başında tek veya çift kısa çizgi bulunabildiğini bizzat görmüş olacaksınız zaten. 

Burada -type seçeneğinin ardından girdiğimiz argüman da type seçeneğine dosya mı yoksa klasörler üzerinde mi arama yapılacağını belirten parametredir. Neticede find komutuna aradığı verilerin tiplerine dikkat etmesi gerektiğini -type seçeneğinin arından parametre vererek özellikle belirtiyoruz. Örneğin bu komutumuzda hangi türde veri aranacağını -type seçeneği ardından d parametresi ile belirtmiş oluyoruz. Böylelikle find komutu yalnızca tipi klasör olan içerikleri araştırıyor. Sonraki -name seçeneği de aynı şekilde "test" parametresi sayesinde yalnızca ismi "test" olan klasörlerin aranmasını sağlıyor. Bu örneğimizdeki gibi parametre alarak çalışan seçenekleri kullanırken parametre kısmını da boş bırakamayız. Çünkü bazı seçenekler tıpkı ls -l komutunda olduğu gibi tek başına belirli bir özelliği temsil ediyorken, kimi seçenekeler de bu örneğimizde olduğu gibi parametre alarak doğru şekilde çalışabiliyor. 

En nihayetinde doğru şekilde kullandığımız tüm seçenek ve parametrelerle birlikte find aracına istediğimiz görevi yazılı şekilde iletip, işin yerine getirilmesini sağlayabiliyoruz.

Tekrar özetleyecek olursak: kabuk find aracını bulup çalıştırdı ona buradaki argümanları iletti, find aracı da aldığı argümanları kendisine göre yorumlayıp görevini yerine getirdi. Tüm işleyişin özeti bu.

Elbette kullanılan araca göre seçeneklerin veya parametrelerin çeşidi ve sıralaması farklı olabilir. Çünkü her aracın kendisine verilen argümanları ele alış biçimi farklıdır. Yani aracın yapısına göre girilmesi gereken seçenek ve parametrelerin sıralaması değişebileceği için benim ele aldığım örnekteki sıralamanın ve seçeneklerin doğrudan bir önemi yok, burada önemli olan kavramlardır. Argüman ne demek, seçenek ne demek, parametre ne demek bunları bilmeniz önemli. Çünkü tüm eğitim boyunca bu kavramları kullanarak açıklama yapıyor olacağım. Dolayısıyla benim söylemek istediklerimi doğru şekilde anlayabilmek için bu temel kavramları da biliyor olmanız gerekiyor.

Temel kavramlardan da bahsettiğimize göre anlatım sırasında bahsi geçen PATH dizini kavramından bahsederek devam edebiliriz. PATH olarak geçen yol aslında kabuk tarafından bulunup çalıştırılmasını istediğimiz türden dosyaları barındırdığımız bazı dizin adreslerini tanımlayan ifadedir. Kabuk bir aracı araştırırken PATH yolu üzerinde belirtilmiş olan dizinlere sırasıyla bakıyor, eğer ilgili aracı bu dizinlerden birinde buluyorsa çalıştırıyor. Peki ama PATH yolu tam olarak hangi dizinleri kapsıyor diyecek olursanız? Gelin PATH yolu kavramına daha yakından bakalım.

## PATH Yolu

PATH esasen sistem üzerinde tanımlı olan bir değişkendir. Bu değişken, kabuğun çalıştırılacak dosyaları araması gereken dizin adreslerini tutuyor. Bu adresleri öğrenmek için daha önce varsayılan kabuğumuzu öğrenirken sorguladığımız SHELL değişkinine benzer şekilde kabuğa `echo $PATH` şeklinde komutumuzu girebiliriz. Buradaki dolar işareti echo aracının, PATH isimli değişkenin değerini konsola bastırmasını sağlıyor. Bu durumdan daha sonra ayrıca detaylı şekilde bahsedeceğiz. Şimdi aldığımız çıktıya odaklanacak olursak:

```jsx
└─$ echo $PATH
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games
```

Bakın sıralı şekilde bazı dizin adresleri çıktı olarak bastırıldı. Burada gördüğümüz iki nokta işareti ile ayrılmış olan her bir dizin adresi, kabuğun bir aracın çalıştırılabilir dosyasını ararken soldan sağa doğru sırasıyla bakacağı dizinlerin adresidir. İşte sırasıyla bakılan bu dizinlere de PATH yolu deniyor. Kabuk, harici bir komutu ararken nerelerde bakması gerektiğini bu PATH değişkinine bakarak öğreniyor. Dolayısıyla eğer kabuk üzerinden bir aracı çalıştırmak istiyorsanız, aracın çalıştırılabilir dosyası mutlaka PATH değişkeninde tanımlı olan dizinlerden birinin içinde olmalı. Ayrıca dilerseniz, PATH değişkenine yeni dizin adresleri ekleyerek, kabuğun bakması gereken dizinleri de çoğaltabilirsiniz. Neticede kabuk çalıştırılabilir dosyaları nerelerde araması gerektiğini PATH değişkeninden öğreniyor. 

Kabuğa bir komut girdiğimizde, kabuğun bu komut ile eşleşen dosyayı PATH yolunda aradığını ve bulabilirse çalıştırdığını kanıtlamak için hemen basit bir test yapabiliriz. 

Test edebilmek için daha önce PATH yolundaki herhangi bir dizinde bulunmayan ve çalıştırıldığını bize kanıtlayabilecek bir programa ihtiyacımız var.

Bunun için bence en basit şekilde, kabuğa konsol aracılığı ile verebileceğimiz komutları bir dosyaya kaydedip komutların bu dosyadan çalıştırılmasını sağlayan bir betik dosyası yani basit bir program oluşturabiliriz. Zaten kabuğun programlanabilir olduğundan daha önce de çok kısaca bahsetmiştim hatırlıyorsanız. Kabuk aynı zamanda programlanabilir olduğu için, komutları dosya içine yerleştirip kendi amaçlarımıza uygun betik dosyaları oluşturabiliyoruz. Hemen canlı örneğini görmek için kendimize bir kabuk programı yapalım.

Ben, çalıştığında konsola "Program Çalıştı!" ifadesini basacak çok basit bir betik dosyası oluşturmak istiyorum. Tüm işlemleri de komut satırı üzerinden yapacağım. Ancak merak etmeyin burada kullandığım tüm komutları ileride ayrıca ele alıyor olacağız. Sizin şimdilik sadece beni takip etmeniz yeterli. 

Öncelikle içerisinde komutları girebileceğim bir betik dosyası oluşturmak istiyorum. Bunun için konsol cat > [betik.sh](http://betik.sh) şeklinde yazıp komutumuzu girebiliriz. 

Buradaki `cat` komutunun ardından kullandığım `>` operatörü ile [betik.sh](http://betik.sh) isimli bir dosya oluşturulmasını ve bu dosyaya konsoldan yeni veriler gireceğimi belirtmiş oldum. Bakın konsol da bir alt satıra geçip benden dosyaya yazılacak verileri beklemeye başladı. 

Şimdi buraya ne yazarsam bu dosyanın içerisine kaydetme imkanım var. Yani bir nevi komut satırı üzerinden not defteri özelliği gibi düşünebilirsiniz. Ben çalıştırıldığı zaman konsola “Program Çalıştı” ifadesini bastıracak bir kabuk programı oluşturmak istiyorum. Bunun için de buraya echo “Program Çalıştı” şeklinde komutumu ekliyorum. Bu komut sayesinde echo aracı kendisinden sonra girilen “Program Çalıştı” argümanını konsola çıktı olarak bastıracak. Bu sayede [betik.sh](http://betik.sh) dosyası çalıştığında konsola "Program Çalıştı" ifadesini bastırabilecek.

Şimdi artık buraya yazdığım komutun bu dosyaya kaydolması için, yazdıklarımın bittiğini haber vermem gerekiyor. Bunun için de Ctrl + D tuşlaması yapmam yeterli.

Bakın bu sayede `cat` komutu veri girişinin tamamlandığını anlayıp, [betik.sh](http://betik.sh) isimli dosyaya girdiğim verileri kaydediyor. Hatta kontrol etmek için cat betik.sh komutu ile oluşturduğum dosyanın içeriğini konsola bastırabilirim. Bakın yazmış olduğum komut bu dosyaya kaydedilmiş.

Böylelikle istediğim amaca uygun bir betik dosyası oluşturmuş oldum. Bu dosyanın çalıştırılabilmesi için son olarak çalıştırma yetkisini de vermemiz gerekiyor. Eğer dosyanın çalıştırma yetkisi yoksa dosya bulunsa dahi çalıştırılamaz. Bu durumu teyit etmek için `./betik.sh` komutu ile betik dosyasını çalıştırmayı deneyebiliriz.

```jsx
└─$ ./betik
bash: ./betik: Permission denied
```

Bakın gördüğünüz gibi yetki hatası aldık çünkü bu dosyanın henüz çalıştırılma yetkisi yok. Şimdi bu sorunu aşmak için dosyamıza `chmod +x [betik.sh](http://betik.sh)` komutu ile çalıştırma yetkisi verelim. Buradaki `chmod` komutu okuma yazma ve çalıştırma gibi yetkilerin yönetimi için kullandığımız bir araç. Daha sonra bu araçtan da detaylıca bahsedeceğiz. 

Neticede bu komutumuzla birlikte artık [betik.sh](http://betik.sh) dosyasına çalıştırma yetkisini de kazandırmış olduk.

Şimdi teyit etmek için tekrar `./betik.sh` şeklinde komutumuzu girelim.

```jsx
└─$ ./betik.sh 
Program Çalıştı !
```

Gördüğünüz gibi bu kez betik dosyası sorunsuzca çalıştı ve konsola “Program Çalıştı” ifadesini bastırdı. Artık çalıştırılabilir bir program dosyamız olduğuna göre ve çalıştığını da bizzat teyit ettiğimize göre PATH yolunun amacını uygulamalı olarak test edebiliriz.

Ayrıca burada benim dosyayı çalıştırmak için kullandığım ./[betik.sh](http://betik.sh) komutunu merak etmiş olabilirsiniz. Kabuğa çalıştırılacak dosyayı tam konumu ile verdiğinizde kabuk o dosyanın uygun ortamda çalıştırılmasını sağlıyor.  Normalde benim girdiğim ./betik.sh komutu, çalıştırılacak dosyanın tam konumunu belirtiyor. Betik dosyasını şu an kabuğun çalışmakta olduğu dizinde oluşturduğum için, bulunduğum dizini . nokta ile belirtip / slash işaretinin ardından dosyanın ismini yazdığımda kabuk benim betik.sh dosyasını çalıştırmak istediğimi anlıyor ve çalıştırıyor. Yani harici olarak PATH yoluna bakmasına gerek kalmıyor çünkü biz doğrudan çalıştırılacak dosyanın konumunu kabuğa bildirmiş oluyoruz. 

Teyit etmek için grafiksel arayüzden dosya yöneticisini açabiliriz. Bakın burası benim ev dizinim ve [betik.sh](http://betik.sh) dosyası da burada bulunuyor. Kabuğumuz da varsayılan olarak bizim ev dizinimizde çalışmaya başladığı için bizim komutları girdiğimiz kabuğumuz da aslında bu dizinde çalışıyor. Bu durumda betik dosyasını çalıştırmak üzere ./[betik.sh](http://betik.sh) komutunu girdiğimde kabuk zaten bu dizinde çalıştığı için betik dosyasını çalıştırıyor. Buradaki nokta mevcut dizini temsil ediyor.

Konu bağlamından uzaklaşmamak için dizinler hakkında şimdilik bu kadarlık bilgi yeterli. İleride dizin yapısından detaylıca bahsettiğimde burada söylediklerimi çok net bir biçimde kavramış olacaksınız. 

Neticede kabuğun bir dosyayı çalıştırabilmesi için o dosyanın tam konumunu biliyor olması gerekiyor. Eğer bu dosya kabuğun çalışmakta olduğu mevcut dizinde değilse dosyanın tam dizin adresini uzun uzadıya yazmamız gerekir. Bu durumu gözlemlemek için ben grafiksel arayüzden dosya yöneticisini kullanarak [betik.sh](http://betik.sh) dosyamı Downloads klasörü içerisine taşımak istiyorum. Artık konsoldan bu dosyaya ulaşmak için ./Downloads/betik.sh şeklinde komut girmem gerekecek. Çünkü betik dosyası kabuğun bulunduğu ev dizini altındaki Downloads klasörü içinde yer alıyor. Grafiksel arayüzle de bu işlemi takip edelim. Kabuğum şu anda ev dizinimde yani burada çalışıyor. Nokta yazdığımda bulunduğum dizini kast etmiş oluyorum. Daha sonra slash koyup Downloads yazdığımda bulunduğum dizindeki Downloads klasörüne geçiş yapılmasını sağlıyorum. Ve son olarak da bu klasör içindeki betik.sh dosyasını çalıştırmak için slashten sonra dosyanın tam ismini yazıyorum. Bakın bu sayede betik dosyam sorunsuzca çalışmış oldu. Ve tüm işlemi grafiksel arayüzden de takip ettiğimiz için yazdığım komutun neyi kast ettiğini bizzat görmüş olduk.

Elbette sizlerin de tahmin edebileceği gibi her seferinde dosyaların konumunu hatırlamak ve bu şekilde uzun uzadıya yazmak pek de verimli değil. Çünkü sık kullandığımız bunun gibi pek çok farklı konumda dosyamız olabilir. Bunun yerine çalıştırılacak dosyayı PATH yolu üzerinde yer alan bir dizin altına taşırsak, kabuğa yalnızca dosyanın adını vererek istediğimiz konumdan dosyayı çalıştırabiliriz. 

Ben bu durumu teyit etmek için PATH değişkeninde tanımlı olan dizinlerden birine betik dosyamı taşımak istiyorum. PATH değişkeninde tanımlı olan herhangi bir dizin içine taşıyabiliriz. Ben örnek olarak /usr/local/bin dizini altına taşımak istiyorum. Taşımak işlemini komut satırından yapmak istersek İngilizce "move" yani "taşınma" ifadesinin kısaltması olan `mv` komutunu kullanabiliriz. 

Ancak taşıma işlemi sırasında dikkat etmeniz gereken detay, PATH yolu üzerinde yer alan dizinler kabuk tarafından taranıp buradaki dosyalar çalıştırıldığı için yetkisi olmayan kullanıcılar buraya yeni dosya ekleyemezler. Sadece yetkisi olan kullanıcılar buraya yeni dosya ekleyebilir. Denemek için `mv ./Downloads/betik.sh /usr/local/bin` komutunu girebiliriz. Dosyayı taşımak için mv komutundan sonra taşımak istediğimiz dosyanın tam adresini ve nereye taşımak istediğimizi belirtiyoruz. [Betik.sh](http://betik.sh) dosyasını Downloads klasörüne taşıdığım için ilk olarak betik dosyasının adresini bu şekilde yazdım. Daha sonra dosyanın taşınmasını istediğim dizini de ikinci argüman olarak girdim.

```jsx
└─$ mv betik.sh /usr/local/bin/                                               
mv: cannot move 'betik.sh' to '/usr/local/bin/betik.sh': Permission denied
```

Neticede gördüğünüz gibi girmiş olduğumuz komut doğru olsa da yetki hatası aldık. Çünkü taşıma işlemini yapmak için yetkili olduğumuzu kanıtlamadık.

Yetkili olduğumuzu kanıtlamak için komutun başına `sudo` eklememiz ve mevcut hesabımızın parolasını girmemiz gerekiyor. Komutumuzu bu şekilde düzenleyip tekrar girelim. Bakın benden parola girmemi istiyor, hesabımın parolasını girip onaylıyorum.

```jsx
└─$ sudo mv betik.sh /usr/local/bin/
[sudo] password for kali:
```

Bakın bu kez komutumuzu yetkili şekilde çalıştırdığımız için betik dosyamız ilgili konuma taşınmış oldu. Artık kabuk hangi konumda çalışıyor olursa olsun [betik.sh](http://betik.sh) komutunu girdiğimizde, betik dosyamız çalışacak. Çünkü biz kabuğa betik.sh ifadesini girdiğimizde kabuk öncelikle yerleşik komutlara bakacak ve burda olmadığını fark edince PATH dizinindeki tüm klasörlere sırasıyla bakarak bu isimle eşleşen dosyayı arayacak. Neticede bizim eklemiş olduğumuz dosyayı bulacak ve çalıştıracak. Yani artık özellikle dosyanın konumunu belirtmemiz gerekmiyor. Hadi hemen denemek için konsola betik.sh şeklinde yazalım. 

```jsx
└─$ betik.sh 
Program Çalıştı !
```

Bakın betik dosyası şu an kabuğun çalıştığı dizinde bulunmuyor olmasına rağmen yalnızca ismini girerek dosyanın çalıştırılmasını sağlayabildik. Hatta dilersek daha somut bir teyit olması için grafiksel arayüzden başka bir dizine gidip burada sağ tıklayıp yeni bir bir konsol açabiliriz. Şimdi konsol bu dizinden çalışıyor. Buradayken de [betik.sh](http://betik.sh) komutunu girelim. Bakın dosya yine sorunsuzca çalıştı. 

İşte bizzat teyit ettiğimiz gibi bu örnek, kabuğun harici bir programı çalıştırmak için PATH olarak geçen dizinlere baktığını kanıtlıyor. Sizler de bu şekilde, kabuk üzerinden ismiyle çağırıp çalıştırmak istediğiniz programlarınızı PATH dizinlerinden birine taşıyabilirsiniz.

Ayrıca bu noktada değinmek istediğim ek bir detay daha var. Bunun için öncelikle tekrar echo $PATH komutu ile PATH dizinini bastıralım. Eğer hatırlıyorsanız PATH adreslerine soldan sağa doğru bakıldığından, yani öncelikle soldaki dizinlerde, ilgili programın araştırıldığından bahsetmiştim. 

Yani örneğin kabuk tarafından bir dosya aranırken öncelikle /usr/local/sbin e bakılıyor daha sonra /usr/local/bin e bakılıyor daha sonra /usr/sbin e ve bu şekilde ilgili dosya ismi ile ilk eşleşen dosya bulunana kadar PATH dizininde tanımlı olan dizinlere sırasıyla tek tek bakılıyor.

```jsx
└─$ echo $PATH                                                                 
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games
```

Bu durumu teyit etmek için [betik.sh](http://betik.sh) ismi ile aynı isimli yeni bir kabuk programını bu kez daha ilerideki PATH dizinlerinden birine kaydedip çalıştırmayı deneyebiliriz. 

Ben denemek için benim sistemimde daha ileriki sırada olan /usr/bin dizini altında yine [betik.sh](http://betik.sh) isimli bir dosya daha oluşturmak istiyorum. 

Hemen daha önce de yaptığımız şekilde hızlıca aynı isimli bir betik dosyası daha oluşturalım. Ben bunun için öncelikle cat > [betik.sh](http://betik.sh) komutu ile betik.sh dosyasını açıp, içerisine echo "Ben ikinci programım" şeklinde yazıyorum ve dosyayı ctrl + D ile kaydedip kapatıyorum.  Birde dosyanın çalıştırılabilmesi için chmod +x betik.sh komutu ile dosyamıza çalıştırma yetkisi verelim. Tamam artık çalıştırılabilir ikinci programım hazır. Test etmek için ./betik.sh komutunu girebiliriz. Bakın aynı isimli betik dosyam sorunsuzca çalıştı.

```jsx
└─$ cat > betik.sh   
echo "Ben ikinci programım"
└─$ chmod +x betik.sh
```

Şimdi PATH dizinindeki sıralamanın geçerli olup olmadığını test edebilmek için bu betik dosyasını da daha ilerideki PATH dizini olan `/usr/bin` dizini içerisine taşıyabiliriz mesela. Taşımak için sudo mv betik.sh /usr/bin/ şeklinde komutumu giriyorum. 

```jsx
sudo mv betik.sh /usr/local/bin/
```

Tamamdır, aynı isimli betik.sh dosyamızı bu kez daha ileride yer alan yani daha sonra bakılacak olan bir PATH dizinine taşımış olduk. Şimdi PATH dizininin öncelik sıralamasını test etmek için konsola [betik.sh](http://betik.sh) komutunu girelim.

```jsx
└─$ betik.sh 
Program Çalıştı !
```

Bakın ne oldu, yine PATH sıralamasında önde olan ilk betik dosyası çalıştırıldı. Çünkü kabuk ilk PATH dizininde [betik.sh](http://betik.sh) isminde bir dosyaya rast geldiği için bu dosyayı çalıştırdı ve geri kalan PATH dizinlerine bakmadı. Çünkü dosyayı çalıştırdığı için geri kalan PATH dizinlerine bakmasına gerek kalmıyor. Şimdi kesin olarak teyit etmek için ilk betik dosyasının ismini değiştirebiliriz. Bu sayede kabuk ilk dizinde isim eşleşmesi olan bir dosya bulamayacağı için diğer PATH dizinlerine sırasıyla bakmaya devam edecek. Dosyanın ismini değiştirmek için de mv komutunu kullanabiliriz. İsim değiştirmek için ilk dizindeki betik dosyasının tam dizin adresini ve ismini girip, yine aynı dizinde bu kez "betik2.sh" ismiyle kaydolması için dizini aynı şekilde belirtip ismini değiştirerek komutumuzu girelim.

```jsx
sudo mv /usr/local/bin/betik.sh /usr/local/bin/betik2.sh
```

Tamamdır ilk PATH dizinindeki [betik.sh](http://betik.sh) isimli programın dosya adı değişti. Şimdi test etmek için betik.sh ifadesini girmeyi deneyebiliriz ancak bundan önce bash komutunu yazıp yeni bir kabuk başlatalım. Çünkü daha önce betik.sh dosyası kabuk tarafından bulunup çalıştırdığı için tekrar PATH dizinine bakarak vakit kaybetmemek adına eski dizin adresi kabuk tarafından önbelleğe alındı. Dolayısıyla biz betik.sh yazdığımızda görebildiğiniz gibi betik.sh ifadesi yine eski path dizininde arandığı için hata alıyoruz. Bunun yerine bash komutunu girip yeni bir kabuk başlatalım. Tamamdır şimdi tekrar [bash.sh](http://bash.sh) komutunu girmeyi deneyebilirz. Bakın bu kez daha ilerideki PATH dizininde yer alan betik.sh dosyası çalıştırıldı çünkü önceki PATH dizinlerinde bu ifade ile eşleşen bir dosya bulunmadı. Hatta önceki betik dosyasının isminin değiştiğini teyit etmek istersek, değiştirdiğimiz ismi kullanarak yani  [betik2.sh](http://betik2.sh) şeklinde komut girerek öncelikli PATH dizinindeki kabuk programının çalıştırılmasını da sağlayabiliriz. Bakın bu dosyam da değiştirildiği isimle çağırılınca sorunsuzca çalıştı.

En nihayetinde bizzat test ettiğimiz bu durum, kabuğun PATH dizin adreslerine soldan sağa doğru sırasıyla baktığını net biçimde kanıtlıyor. Kabuk komutla eşleşen dosyayı bulduğunda, PATH yolundaki diğer dizinlere bakmıyor. Dolayısıyla PATH yoluna eklediğiniz aynı isimli dosyalarınız varsa bu detaya dikkat etmeniz gerekiyor. Hatta aynı nedenle bazı araçların farklı sürümleri farklı dizinlerde olabildiği için kimi zaman kabuk üzerinden aynı isimli aracın farklı bir sürümünü kullanmak için spesifik olarak o aracın tam dosya konumunu belirtmeniz de gerekecek. Bu durumu ileride kendiniz fark edeceksiniz zaten.

Ayrıca ben şimdiye kadar hep varsayılan PATH dizinlerinin kullanıldığından bahsettim ancak yalnızca varsayılan olarak tanımlanmış olan PATH dizinleri ile sınırlı değilsiniz. Dilerseniz kendiniz de PATH üzerine yeni dizin adresleri ekleyebilirsiniz. Yine de yeni PATH dizini eklemek sistemin güvenliği için pek doğru bir tercih olmayabilir. Her ne kadar bu durum güvenlik gerekçeleri ile tavsiye edilmese de ben ihtiyaç halinde kullanabilmeniz için kısaca PATH dizinine yeni dizin eklemekten de bahsetmek istiyorum.

## PATH Üzerine Yeni Dizin Eklemek

Bu yöntem, sistemin güvenliğini riske edebilir. Çünkü yeni eklediğiniz dizin adresi için gereken yetkilendirme ve sıkılaştırma önlemlerini almamış, unutmuş olabilirsiniz. Varsayılan olarak tanımlı olan PATH adreslerinde ise zaten yetkilendirme ayarları yapılmış oluyor. Hatırlarsanız betik dosyamızı taşımak için sudo komutu ile yetkili olduğumuzu kanıtlamamız gerekmişti. Yani varsayılan PATH dizinlerinin yalnızca yetkili kişilerce düzenlenebilecek şekilde sıkılaştırıldığını bizzat deneyimledik zaten. Dolayısıyla varsayılan olarak tanımlı olan PATH adreslerini kullanmanız çok daha doğru ve güvenli bir yaklaşımdır. Yine de ihtiyaç duymanız halinde kullanabilmeniz, ve kabuğun çalışma yapısını daha iyi kavrayabilmeniz için kısaca PATH yoluna nasıl yeni dizin ekleyebileceğimize de değinmek istiyorum.

Bildiğiniz gibi PATH yolu üzerindeki dizinlerin hangileri olduğunu öğrenmek için `echo $PATH` komutunu kullanıyoruz. Hatta kullandığımız bu komutun anlamını özellikle çok kısaca da olsa açıklamıştık hatırlıyorsanız. `echo` komutu, kendisine argüman olarak verilen değerleri çıktı olarak bastırıyor. Buradaki $PATH ifadesi ise bir değişkendir. Eğer programlama geçmişiniz varsa zaten değişkenlerin ne olduğunu mutlaka biliyorsunuzdur. Değişkenler, tanımlı olan değerlere tekrar tekrar tek bir değişken ismi üzerinden ulaşılabilmesini sağlayan yapılardır. Bash kabuğunda da bizzat daha önce de gördüğümüz SHELL ve PATH gibi değişkenler olduğunu zaten biliyoruz. Eğer biz PATH yolunu değiştirmek istiyorsak, PATH değişkeninde tanımlı olan dizinleri yani PATH değişkenin değerini yeniden düzenleyebiliriz. Ancak yeni bir PATH dizini eklemeden önce bash kabuğunda değişkenlerin nasıl çalıştığına temel olarak değinmek istiyorum. Bu sayede gerçekleştireceğimiz işlemleri çok daha bilinçli şekilde yerine getiriyor olacağız.

### Değişkenler

Örneğin sistemde PATH isimli bir değişken tanımlanıp bu değişken değeri olarak PATH dizinlerinin tam adresleri tanımlandığında, PATH dizinlerinin hangileri olduğunu öğrenmek isteyen herkes PATH değişkeni üzerinden kolayca bu bilgiye ulaşabiliyor. Böylelikle herkesin ihtiyacı olabilecek bilgiler tek bir değişken isim üzerinden ulaşılabiliyor. 

Daha anlaşılır bir örnek olması açısından HOME değişkenini de ele alabiliriz. Biz daha önce bahsetmedik ancak sistem üzerinde tıpkı PATH gibi varsayılan olarak tanımlı olan pek çok farklı değişken var. Örneğin mevcut kullanıcının ev dizinin hangisi olduğunun bilgisini tutan HOME isimli bir değişken daha bulunuyor. Sistem üzerinde birden fazla kullanıcı hesabı olabildiği için, her kullanıcının kendisine ait bir ev dizini var. Dosya yöneticisini açıp grafiksel arayüzden de bu durumu teyit edebiliriz. Öncelikle dosya sisteminin kaynağı kök dizine geçiş yapalım. Burası tüm sistem dosyalarını hiyerarşik şekilde barındıran ana dizin. Kullanıcıların ev dizinleri de istisnalar hariç /home dizini altında kullanıcının kendi ismindeki dizin oluyor. home klasörüne girip baktığımızda burada kullanıcı hesaplarına ait dizinleri görebiliriz. Örneğin ben taylan kullanıcısı olduğum için benim ev dizinim home dizini altındaki taylan klasörüdür. Bakın dizinin içine girdiğimde benim ev dizinim olduğunu teyit edebiliyorum. Eğer sistemde ali diye bir kullanıcı olsa onun ev dizini de /home/ dizini altında ali klasörü olacaktı. Neticede sistem üzerinde tıpkı kullanıcıların ev dizini gibi çeşitli bilgilerin farklı koşullara göre değişme ihtimali olduğu için HOME gibi sabit tek bir değişken ismi ile sürekli değişebilen ilişkili değerlere ulaşabilmek büyük bir kolaylık. Bu bağlamda değişkenlerin neden önemli olduğunu kavrayabilmek için örnek bir durum senaryosu da oluşturabiliriz.

Örnek senaryoda sisteme yeni yüklenen bir programın, kullanıcının masaüstünde kısayol oluşturmak istediğini varsayalım. Bu durumda programın, mevcut kullanıcının masaüstünün tam dizin adresini bilebilmesi için kullanıcının ev adresini de bilmesi gerekiyor. Çünkü masaüstü, kullanıcıların ev dizini altındaki bir klasördür aslında. Hatta bu durumu teyit etmek için dosya yöneticisini açabiliriz. Bakın burası benim ev dizinim ve buradaki Desktop klasörü aslında grafiksel arayüzde de gördüğüm bu masaüstünü temsil ediyor. Örneğin burada yeni bir klasör oluşturursam, görebildiğiniz gibi bu klasör masaüstünde de beliriyor.

İşte bizzat dosya yönetici ile de teyit edebileceğimiz üzere, masaüstü klasörü kullanıcının ev dizini altında tutuluyor. Her bir kullanıcının ismi farklı olacağı için, ev dizini de farklı olacaktır elbette. Örneğin benim için /home/taylan olan dizin sizde /home/ayşe ya da /home/ahmet olabilir. Hatta istisnai durumlarda /home dizini altında bile olmayabilir. Dolayısıyla masaüstüne kısayol oluşturmak isteyen program tam olarak nereye kısayol oluşturması gerektiğini bilemez. Çünkü kullanıcıya özel olan masaüstü dizinini kendi başına bulamaz. Ama eğer program HOME değişkenine bakarsa, mevcut kullanıcının ev dizini nerede olursa olsun, bu değişken üzerinden bu bilgiyi kolayca öğrenebilir. Çünkü HOME değişkeni her zaman mevcut kullanıcının ev dizinin karşılığını verir. Bu HOME değişkeni sistem tarafından bu amaçla sağlanan bir değişkendir çünkü. Biz kendi hesabımızda oturum açtığımızda, sistem de HOME değişkenin değeri olarak bizim oturum açtığımız kullanıcın ev dizini tanımlıyor. Bu sayede tüm sistem üzerindeki tüm yapılar ve araçlar, HOME değişkeni üzerinden mevcut kullanıcını doğru ev dizini öğrenebiliyor. Bu basit örnek senaryodan da kolayca anlaşıldığı üzere, değişkenler sistemin işleyişi için oldukça önemli yapılardır. 

Elbette bizler de gerektiğinde yeni değişkenler tanımlayabiliyor ya da var olan değişkenlerin değerlerini istediğimiz gibi düzenleyip değiştirebiliyoruz. 

Zaten değişkenlerin kullanımı son derece kolay olduğu için tanımlanması ve değerlerinin değiştirilmesi çok basit. Hatta ben değişken tanımlayama basit bir örnek olması için isim değişkenine kendi adımı tanımlamak istiyorum. Bunun için isim=taylan komutunu girmem yeterli. 

```jsx
└─$ isim=taylan                                                
└─$ echo $isim                                                 
taylan
```

Değişkenimi tanımladım. Değişken değerini bastırmak için daha önce de yaptığımız şekilde `echo $`değişkenin adı şeklinde komutumuzu girebiliriz. Ben isim adında bir değişken tanımladığım için echo $isim şeklinde komutumuz giriyorum.

Bakın isim değişkeni üzerinden, tanımlamış olduğum değere kolayca tekrar erişebildim. Değişken tanımlama ve değerini öğrenmek çok basit fakat dikkat etmeniz gereken detay bu değişkenin şu an kalıcı bir değişken olmadığı. Çalışmakta olduğum kabuktan başka hiç bir kabuk üzerinden bu değişkenin değerine ulaşamam. Denemek için yeni bir kabuk başlatalım. Bunun için konsola bash komutunu giriyorum. Bu sayede yeni bir kabuk başlatıldı. Şimdi `echo $isim` komutu ile tanımladım değişkeni tekrar bastırmayı deniyorum.

Bakın herhangi bir çıktı almadık. Çünkü benim tanımladığım isim değişkeni aslında lokal bir değişkendi. Lokal olduğu için de yalnızca tanımlandığı kabuk üzerinde geçerli. Değişken lokal olduğu için mevcut kabuk, değişkeni kendisinin başlattığı yeni işlemlere aktarmıyor. Bu sayede değişken lokal olarak kalabiliyor. Eğer mevcut kabuğun başlattığı tüm işlemlere bu değişkenin aktarılmasını istersek `export` komutunu kullanabiliriz. 

Ben denemek için export komutu başta olacak şekilde soyisim değişkenine "bildik" değerini tanımlıyorum. Bu sayede soyisim değişkeni mevcut kabuk tarafından başlatılacak olan işlemlere de otomatik olarak aktarılacak. Hemen öncelikle mevcut kabukta bu değişkenin değerini sorgulayalım. Bakın mevcut kabukta soyisim değişkeninin değerine ulaşabiliyorum. 

```jsx
export soyisim=bildik

echo $soyisim

bildik
```

Şimdi bir de yeni bir bash kabuğu başlatmak için bash komutunu girelim. Bu komut mevcut kabuğun yeni bir bash kabuğu başlatmasını sağlıyor. Şimdi bu yeni kabuk üzerinde echo $soyisim komutu ile değişkeni bastırmayı deneyelim.

```jsx
bash

echo $soyisim

bildik
```

Bakın bu kez mevcut kabuğun atlında başlatılan kabuk üzerinden de değişken değerine ulaşabildim.  Yani tanımlamış olduğum değişken export komutu sayesinde, mevcut kabuğun çalıştırdığı yeni kabuğa da aktarılmış oldu. Çünkü export komutu lokal olan değişkenleri global hale getirerek, mevcut kabuğun başlattığı tüm işlemler ile bu değişkenlerin paylaşılmasını sağlıyor.

Ben değişkeni tanımlarken komutun başında export kullandım. Ancak sizler dilerseniz, daha önce tanımlamış olduğunuz bir değişkeni de export komutu ile aynı şekilde global hale getirebilirsiniz.

Örneğin ben lokal bir değişken tanımlıyorum, ve bu değişkenin lokal olduğunu yeni bir kabuk çalıştırıp test ediyorum.

```jsx
└─$ sehir=istanbul                                             
└─$ echo $sehir                                                
istanbul
└─$ bash                                                       
└─$ echo $sehir
```

Bakın bu yeni kabukta ilgili değişken tanımlı değil. Teste devam etmek için yeni başlattığım kabuktan `exit` komutu ile çıkıyorum. `exit` komutu mevcut kabuğun kapatılmasını sağlayan bir komut. Kabuk kapanıp, değişkeni tanımladığım kabuğa geri döndüğümde  `export` değişken_adı şeklinde komut girerek önceki lokal değişkenimi bu kez global hale getiriyorum.

```jsx
└─$ exit                                                       
exit
└─$ export sehir                                               
└─$ bash                                                       
└─$ echo $sehir                                                
istanbul
```

Şimdi bu değişkenin global olup olmadığını denemek için yine bash komutu ile yeni kabuk başlatalım ve bu kabuktan değişkeni tekrar sorgulayalım. Bakın öncelikle lokal olarak tanımlanmış daha sonra export edilmiş değişkene, mevcut kabuk altında başlatılan kabuk işlemi üzerinden de sorunsuzca erişebiliyoruz. Yani lokal değişkenleri de dilediğimiz zaman global hale getirebiliyoruz.

İşte temelde lokal ve global değişkenler bu şekilde çalışıyor. 

İyi güzel ama, ya yeni bir konsol açarsam, yani mevcut kabuk altında yeni bir kabuk başlatmaktansa yeni bir bağımsız konsoldaki kabuğu kullanırsam ne olur ? Hemen deneyelim.

Öncelikle yeni bir konsol penceresi açıyorum. Şimid bu konsoldan, daha önce global hale getirdiğim sehir değişkenini bastırmayı deneyebilirim.

Bakın gibi hiç bir çıktı alamadım. Şimdi bir de bu konsol üzerinden PATH değişkenini bastırmayı deneyelim.

Gördüğünüz gibi sorunsuzca PATH değişken değeri basıldı. Peki ama nasıl oluyor da bizim export komutu ile global hale getirdiğimiz değişkene başka bir konsoldan ulaşamıyorken, PATH değişkenine tüm konsollardan ulaşabiliyoruz ? 

Bu durumun sebebi miras yapısıdır. Mevcut kabuk yalnızca kendisinin başlatmış olduğu yeni işlemlere değişken gibi değerleri miras bırakabiliyor. Biz yeni bir konsol penceresi açtığımızda, halihazırda çalışmakta olan kabuklardan bağımsız yeni bir kabuk bu konsolda başlatılıyor. Dolayısıyla bağımsız bir kabuk tarafından export edilen değişken, bir diğer bağımsız kabuk tarafından miras alınamıyor. Çünkü arasında değişken aktarımını gerektirecek bir mirasa bağı bulunmuyor. Mevcut kabuk üzerinden bash komutu ile yeni kabuk başlattığımızdaysa, mevcut kabuk bu işlemi kendisi başlattığı için değişkenlerini yeni kabuğa miras olarak aktarabiliyor. Tüm meselenin özeti aslında bu.

Peki ama PATH değişkenine nasıl tüm konsollardan yani tüm bağımsız kabuklardan ortak olarak ulaşabiliyoruz ? Bu durumun sebebi, PATH değişkeninin kabuk başlatılırken kabuk tarafından okunan konfigürasyon dosyalarından birinde tanımlanmış olması. 

Eğer biz de değişkenlerimizi kabuk tarafından okunan bu konfigürasyon dosyalarından birine eklersek, değişkenimiz her yeni başlatılan kabuk tarafından okunacağı için tüm kabuklardan bu değişkene ortak şekilde erişebileceğiz. Peki bu konfigürasyon dosyaları hangi dosyalar diye soracak olursanız: 

Bash kabuğu konfigürasyonlar için temelde iki tür dosyayı okuyor. Bunlar; sistem genelinde tüm kullanıcılar için geçerli olan ve spesifik kullanıcıya özel olan iki farklı türdeki konfigürasyon dosyalarıdır. 

Anlatımın devamında konfigürasyon dosyalarını ele alacağız ancak bundan önce ilerleyiş biçimimiz hakkında da çok kısaca konuşmak istiyorum. Biliyorum henüz hiç bir komutu doğru dürüst ele almadık. Ayrıca sistemin doğrudan temel çalışma yapısına odaklanmaya çalıştığımız için, belki yeni başlayanlara göre biraz detaylı bir anlatımda bulunmuş olabiliriz. Ancak aslında buradaki anlatımlar, gereksiz ve kavraması zor değil. Eğer buradaki kavramları doğru şekilde anlarsanız, tüm eğitim boyunca tekrar tekrar üzerinde duracağımız pek çok konunun temelini öğrenmiş olacaksınız. Yani eğitimde ilerledikçe buradaki temel bilgiler zaten kendiliğinden yerli yerine oturmuş olacak. Çünkü yeri geldikçe burada bahsettiklerimize tekrar tekrar atıfta bulunuyor olacağız. Lütfen henüz eğitimin başındayken sıkıcı veya zor olduğunu önyargısına kapılmayın. Tüm anlatımlar birbiri ile ilişkili olduğu için sırasıyla ilerliyoruz. 

Bu noktada sizlerden ricam sabırlı olmanız ve dikkatinizi toplamanız. Eğitim içerisindeki anlatımları sadece dinlemeyip, aktif olarak neyi neden söylediğimi üzerine düşünmenizi rica ediyorum. Ayrıca lütfen mümkün mertebe sizler de bizzat uygulama yaparak takip edin. Bu sayede eğitime aktif katılım gösterip, tüm kavramlardaki sebep sonuç ilişkisinin farkında olarak etkili ve kalıcı şekilde tüm anlatılarını öğrenebilirsiniz. Dikkatinizi verir ve uygulama yaparsanız öğrenemeyeceğiniz hiç bir konu yok. Size güveniyorum.

Lafı daha fazla uzatmadan anlatımlarımıza, bash kabuğu için kullanılan konfigürasyon dosyalarından bahsederek devam edebiliriz. 

### Sistem Geneli İçin Yapılandırma

Linux çok kullanıcılı bir işletim sistemi olduğu için tüm kullanıcılar üzerinde geçerli olabilecek toplu yapılandırma kuralları tanımlayabilmek adına sistem genelinde kullanılan yapılandırma dosyalarında düzenlemeler yapabiliriz. 

### Kullanıcı Bazlı Yapılandırma

Ayrıca eğer yapmak istediğimiz değişikliklerin tüm kullanıcıları değil de özel olarak tek bir kullanıcıyı etkilemesini istersek, kullanıcının kendi ev dizininde bulunan yapılandırma dosyalarında da düzenlemeler yapabiliriz.

İşte ihtiyaçlarımıza göre hangi kapsamda değişiklik yapmak istiyorsak ona uygun dosyalarda düzenleme yapmamız gerekiyor. Bash kabuğu da sistem geneli için "/etc/profile" , "/etc/bashrc" veya "/etc/bash.bashrc" dosyalarına bakarken, kullanıcı bazlı değişim için kullanıcıların kendi ev dizinlerinin içinde bulunan "~/.bash_profile", "~/.bashrc", "~/.bash_login" ve "~/.profile" gibi konfigürasyon dosyalarını dikkate alıyor. 

Ben hepsini saydım ancak tabii ki tüm sistemlerde saydığım tüm bu dosyalar varsayılan olarak bulunmuyor olabilir. Eğer yoksa ve ihtiyaç duyuyorsanız kendiniz elle de bu dosyaları oluşturabilirsiniz. Dosyayı uygun şekilde oluşturduğunuzda zaten bash kabuğu bu dosyaları okuyor olacak. Örneğin Debian İle CentOS sistemlerinde aynı iş için farklı dosyalar kullanılabiliyor. Mesela tüm kullanıcıları etkileyecek değişiklik için debian sisteminde /etc/bash.bashrc dosyasını kullanabiliyorken, centos da /etc/bashrc dosyasını kullanıyoruz. Benzer şekilde kullanıcı bazlı konfigürasyonlar için debian da .profile dosyası kullanılırken centos da .bash_profile dosyası kullanılıyor. Ancak merak etmeyin farklılıkların doğrudan bir önemi yok. Sizin kullanmakta olduğunuz sistemde hangi yapılandırma dosyası mevcutsa onu düzenleyip kullanabilirsiniz. Zaten muhtemelen kullandığınız dağıtımda benim bahsettiğim dosyalardan biri yoksa diğeri mutlaka vardır. Biraz göz atarsanız hangisini kullanmanız gerektiğini kolayca fark edebilirsiniz.

Tamam her şey gayet güzel ama neden sistem genelinde veya kullanıcı bazında değişiklik için birden fazla konfigürasyon dosyası bulunuyor ? Yani sistem geneli ve tekil olarak kullanıcıları etkileyecek birer tane konfigürasyon dosyası olsa yeterli olmaz mıydı ?

Olmazdı çünkü kabukların farklı kullanım modları bulunuyor, bu ek dosyalar da bu modlardaki kabukları konfigure edebilmemiz için var. Peki burda bahsi geçen kabuk modları nelerdir diyecek olursanız. Temelde kabuğun "etkileşimli" ve "oturum açma" olarak isimlendirilen iki modu bulunuyor. Aslında bundan daha fazla modu var ama temelde biz şimdilik bu iki modu dikkate alabiliriz.

Ben şimdi çok kısaca hem oturum açma kabuğunu hem de etkileşimli kabuğu açıklamaya çalışacağım. Merak etmeyin fazla detaya girip kafanızı karıştırmak istemiyorum yine de temel işleyişten haberdar olabilmemiz için birkaç ufak detaydan bahsetmeden geçmeyeceğiz. 

![login.png](%E2%9C%85%204-%20Kabuk%20Nas%C4%B1l%20C%CC%A7al%C4%B1s%CC%A7%C4%B1r%202091b6cbfd40407ea689e005a59916c7/login.png)

Eğer buradaki şemaya bakacak olursanız aslında komut satırı arayüzünde hangi kabuğun nasıl başlayıp hangi konfigürasyonları okuduğuna dair genel bilgi sahibi olabilirsiniz. Ama yine de biz bu şemadan tüm detayları ile bahsetmeyeceğiz çünkü temel bilgiler yeterli olacak. 

Ben öncelikle iki farklı açıdan bizim oturum açma durumuzu ele alıp daha sonra kabuk modlarını açıklayacağım. İlk olarak komut satırı arayüzünden bahsetmek için tty konsollarından birine geçiş yapalım. Örneğin ctrl alt f5 ile 5. tty konsoluna geçiş yapabiliriz. Tamamdır.

Bakın bu tty konsolu şu anda bizden oturum açmamızı bekliyor. Eğer doğru kullanıcı adı ve parola kullanarak oturum açmazsak, komutlarımızı iletebileceğimiz bir kabuğa ulaşamayacağız. Zaten buradaki oturum açma zorunluluğu, komut satırı arayüzündeki güvenlik için var. Bu yapı sayesinde her önüne gelen elbette kabuğa erişip istediği komutu giremez. 

Biraz daha temelden alacak olursak, burada bize giriş bilgisi soran yapı aslında getty isimli bir program. Biz kullanıcı adımızı ve parolamızı doğru şekilde girdiğimizde getty, daha önce kabuğumuzu değiştirirken de bahsettiğimiz /etc/passwd dosyasını kontrol edip kullanıcı adımız ev dizinimiz ve kabuğumuz gibi bilgileri alıyor. Eğer /etc/passwd dosyasının içeriğini hatırlamıyorsanız tekrar bu dosya içeriğini gözümüzün önüne getirecek olursak, örneğin bakın taylan satırında kullanıcı adım ev dizinim ve varsayılan kabuğum açıkça belirtiliyor. Biz oturum açarken buradaki bilgilerden faydalanılıyor zaten. Ayrıca parolamızın kontrolü için başka dosya ve yapılar da kullanılıyor ancak bunlar şimdilik önemsiz. 

Biz kullanıcı adımızı ve parolamızı doğru girdiğimizde /etc/passwd dosyasında bizim girdiğimiz kullanıcı adı ile eşleşen satırdaki ev dizini ve varsayılan kabuk bilgisi dahilinde bize hemen kendi ev dizinimizde çalışmaya başlayan bir kabuk tahsis ediliyor. Ben durumu durumu gözlemlemek için hemen giriş yapıyorum. Bakın artık komut girebileceğim bir konsola erişmiş oldum. Üstelik bu konsol /etc/passwd dosyasında benim kullanıcı adımının bulunduğu satırda belirttiğim konsol. Teyit etmek için echo $0 komutunu girebiliriz. Buradaki 0 değişkeni, girilen bu komutun ne üzerinden çalıştırıldığını veren özel bir değişken. Biz bu komutu bash kabuğuna girdiğimiz için bu çıktıyı aldık.

Detaylarını merak ediyorsanız ek olarak araştırabilirsiniz ancak ben kafanız karışmasın diye ekstra bahsetmeyeceğim. Aldığımız çıktıya dönecek olursak bakın konsola -bash ifadesi bastırılmış. Bu çıktı şu an çalışmakta olduğum kabuğun bash kabuğu olduğunu belirtiyor. Üstelik bash ifadesinin başındaki tire işareti de bu kabuğun bir giriş kabuğu olduğunu söylüyor. Peki bu giriş kabuğu ne anlama geliyor diyecek olursanız:

Tıpkı burda bizim yaptığımız gibi lokal olarak tty konsollarından ya da uzaktaki bir bilgisayara bağlanmak için ssh üzerinden oturumumuzu açtığımızda /etc/passwd dosyasına bakılıp oturum açan kullanıcı için tanımlı olan kabuk öğreniliyor ve oturum açma işleminin hemen ardından bu kullanıcı için ilgili kabuk başlatılıyor. İşte bu sebeple oturum açtıktan hemen sonra bizim oturum açtığımız kullanıcı için başlatılan ilk kabuk işlemi oturum açma kabuğu yani login shell olarak geçiyor. 

Başlatılan kabuk giriş kabuğu olduğu için de elbette giriş kabuğuna özel olan konfigürasyon dosyaları bu kabuk tarafından okunup geçerli kılınıyor.  Zaten kabuğun farklı türlere ayrılmasının yani farklı modlarının olmasının nedeni farklı ortamlara farklı amaçlarla kullanılabilecek kabuk ortamlarının sağlanabilmesi için. Bu doğrultuda da elbette tüm kabuk türleri aynı konfigürasyon dosyalarını okumuyor. Anlatımın devamında hangi konfigürasyon dosyasının ne zaman okunduğundan ayrıca bahsedeceğiz. Şimdi bize tahsis edilen bu kabuktan biraz daha bahsedecek olursak oturum açtıktan sonra aldığımız bu kabuk aslında aynı zamanda etkileşimli olan bir kabuk.

Bir kabuğu etkileşimli yapan şey, o kabuğa bizzat bizim tek tek komutlar girip sonuçlarını yine konsol üzerinden takip edebiliyor olmamız. Yani aslında biz aktif şekilde kabuk ile etkileşim kurduğumuz için bu kabuğa etkileşimli kabuk deniyor. Örneğin kabuğa kendimiz echo merhaba şeklinde komutumuzu girersek, kabuğun yanıtını konsol üzerinden anında görebiliyoruz. Yani kabuk ile birebir etkileşimimiz var. Bu sebeple komut satırı arayüzünde oturum açtıktan sonra bize verilen bu kabuk hem oturum açma hem de etkileşimli kabuk sınıfında yer alıyor. 

Peki etkileşimli olmayan kabuk nasıl oluyor diyecek olursanız: Etkileşimli olamayan kabuğa örnek olarak da daha önce hazırladığımız kabuk programını örnek gösterebiliriz. Bu betik dosyasının içinde yine bash kabuğunun çalıştıracağı komutlar bulunuyor ancak bu komutların çalıştırılması için kabuğun tekrar tekrar kullanıcılardan komut bekleyip sonuçlarını kullanıcılara geri iletmesi gerekmiyor. Yani bu kabuk dosyası aslında yine bash kabuğu tarafından yorumlanıp çalıştırılacak ancak doğrudan bizim bir etkileşimimize ihtiyaç duymuyor. İşte bu gibi görevleri yerine getirmek için kullanılan kabuklar da etkileşimli olmayan kabuklardır.

Eğer fark ettiyseniz anlatımlar sırasında pek çok kavramı aslında üstünkörü geçiyorum çünkü bağlantılı çok fazla kavram var ve fazla detaylara girerek konu bağlamından çok uzaklaşmak istemiyorum, umarım yine de söylediklerim anlaşılıyordur. Buradaki kabuk türlerine dair açıklamaları daha sonra bahsedeceğimiz farklı konfigürasyon dosyalarının neden var olduğunun anlaşılabilmesi için yapıyorum. Zaten uygulamalı olarak bu konfigürasyon dosyalarında düzenlemeler yaparken burada bahsettiğimiz tüm konuları tek çatı altında toparlayıp bizzat uygulamalar yaparak pekiştiriyor olacağız. 

Anlatımlara devam edecek olursak, ben örnekler sırasında komut satırı arayüzünü kullandığım için oturum açma kabuğunu ve etkileşimli kabuğu tty konsolu üzerinden açıkladım ancak bu kabuk türleri ile yalnızca komut satırı arayüzünde karşılaşmıyoruz. Örneğin grafiksel arayüzde oturum açtıktan sonra yeni bir konsol penceresi açıp komut girdiğimizde de aslında etkileşimli kabuğa komut girmiş oluyoruz. 

Ancak bununla birlikte, grafiksel arayüzde oturum açtıktan sonra, komut satırında olduğu gibi yalnızca kabuk kullanmak zorunda olmadığımız için hemen bir oturum açma kabuğu başlatılmıyor. Bunun yerine grafiksel arayüz ortamı için gereken masaüstü ortamı, pencere yöneticisi gibi yapılar başlatılıyor. Zaten bu durumdan daha önce de uzun uzadıya bahsettik. Grafiksel arayüzü kullanırken her ne kadar bize hemen bir oturum açma kabuğu sunulmuyor olsa da merak etmeyin, oturum açma kabuğu tarafından okunması gereken konfigürasyon dosyaları biz grafiksel arayüzde oturum açtıktan sonra da okunup geçerli oluyor. Örneğin oturum açtıktan sonra yapılması gereken bir işlem varsa, konfigürasyon dosyasında belirtildiği sürece komut satırı veya grafiksel arayüz olması fark etmeksizin o görev kullanıcı oturumunu açtıktan sonra yerine getiriliyor.

Lafı daha fazla uzatmadan bizzat teyit etmek istersek öncelikle grafiksel arayüzdeki konsolların yalnızca etkileşimli kabuklar olduğunu teyit etmek için yeni bir konsol açıp daha önce de kullandığımız echo $0 komutunu girebiliriz. Ben yeni bir konsol açıyorum ve komutumu giriyorum. Bakın bu kez doğrudan bash çıktısını aldık. Gördüğünüz gibi bash ifadesinin başında tire bulunmuyor çünkü şu an komut girdiğimiz bu kabuk yalnızca etkileşimli kabuk, oturum açma kabuğu değil. Tire işareti bash kabuğunun oturum açma kabuğu olup olmadığının ayırt edilebilmesi için önemli bir detay. Bu işaret olmadığında mevcut kabuğun oturum açma kabuğu olmadığını anlayabilirsiniz.

Eğer biraz kafanız karıştıysa hiç sorun yok, birazdan konfigürasyon dosyalarını ele aldığımız örneklerle bu kabuk türlerinin neden önemli olduğunu net biçimde kavramış olacaksınız.

Neticede kabuğun modları ile ilgili temelde bilmemiz gerekenler bunlar. Artık farklı kabuk modlarının varlığından da haberdar olduğumuza göre hangi durumda hangi konfigürasyon dosyaların okuduğuna daha yakında bakabiliriz. 

Kabuk modlarına göre okunan konfigürasyon dosyalarının değiştiği gibi bir de daha önce de bahsettiğimiz şekilde sistem genelinde veya tekil olarak kullanıcı özelinde geçerli olan konfigürasyonlar da var. Örneğin oturum açan tüm kullanıcıların kabuklarında geçerli olacak bir değişiklik istiyorsam buna göre bir tanımlama yapabiliyorken, eğer istersem spesifik olarak yalnızca benim kullanıcı hesabımda oturum açılırsa geçerli olacak değişiklikleri de uygun konfigürasyon dosyasında tanımlayabilirim. 

Ben öncelikle sistem genelindeki yani tüm kullanıcıları ortak olarak etkileyen bash yapılandırma dosyalarından bahsederek devam etmek istiyorum.

## Sistem Geneli İçin Yapılandırma

Sistem genelinde tüm kullanıcıları etkileyen değişiklikler genellikle /etc/ dizini altındaki dosyalarda tanımlanıyor. Bu durum bash kabuğu için de böyle.

Tüm kullanıcıların oturum açma kabuğunda geçerli olacak konfigürasyonlar için /etc dizini altındaki profile dosyasında değişiklik yapmamız gerekiyor. Eğer tüm kullanıcıların etkileşimli kabuklarında geçerli olacak bir değişiklik yapacaksak da bunu yine /etc dizini altındaki bash.bashrc dosyasında yapmamız gerekiyor. 

Ben öncelikle tüm kullanıcıların oturum açma kabuğunu etkileyecek değişikliği yapmak için /etc/profile dosyasını açmak istiyorum. Dosya içeriğini düzenlemek için ileride ayrıca değineceğimiz nano metin editörünü kullanabiliriz. Ancak önemli bir konfigürasyon dosyası olduğu için yani dosyayı düzenlemek için yetki gerektiğinden bu dosyayı sudo komutu ile açmamız gerekiyor. Dosyayı açmak üzere sudo nano /etc/profile şeklinde komutumuzu girelim.

Bakın konfigürasyon dosyamız açıldı. şimdi ben bu konfigürasyon dosyasının kabuk tarafından okunduğunu teyit edebilmemiz için bu dosyaya iki komut eklemek istiyorum. Öncelikle, bu dosya okunduğunda mümkünse konsola çıktı bastırabilmesi için echo "/etc/profile dosyası okundu!" şeklinde komutumu giriyorum. Tamamadır, artık bu dosya okunduğunda bu dosyayı okuyan kabuğun çalıştığı mevcut konsola bu çıktı bastırılacak. Ancak tabi grafikse arayüzden oturum açtıysak bu dosya okunsa bile komut satırında çalışmadığımız için doğrudan herhangi bir çıktı görmeyeceğiz. Bu sebeple, bu komuta ek olarak, grafiksel arayüzden de teyit edilebilir somut bir kanıt olması için bu dosya okunduğunda benim masaüsütü dizinime yeni bir dosya oluşturulmasını için de bir komut daha eklemek istiyorum.

Ben kendi kullanıcı hesabımda oturum açacağım yani kendi masaüstümü görüntüleyeceğim için komutumu touch ~/Desktop/etc-profile-okundu şeklinde yazıyorum. Bu komut sayesinde, etc dizini altındaki profile dosyası okunduğunda, benim kendi ev dizinim altındaki masaüstü dizinde  profile-okundu isminde bir dosya oluşturulacak. Buradaki tilde işareti benim kendi ev dizinimi temsil eden bir kısayol. Bu işareti oluşturmak için türkçe klavyenizden alt gr ü tuşunu kullanabiliriz. Kabuk bu işareti gördüğünde, otomatik olarak mevcut kullanıcının ev dizinini buraya eklenmiş olacak. Daha sonra bu konudan da ayrıca bahsedeceğiz, şimdilik test için bu işareti benim yazdığım şekilde kullanmanız yeterli. Bu da tamamdır. Şimdi değişiklikleri test etmek için öncelikle yaptığımız değişiklikleri kaydedelim.

Dosyamı kaydedip kapatmak için ctrl + x tuşlamasını yapıyorum, bakın dosya kaydedilsin mi diye soruyor y tuşuna basarak yes diyorum ve enter ile onaylıyorum. Tamamdır böylelikle dosyadaki değişiklik kaydoldu. 

Ben teste geçmeden önce bir de aynı şekilde yalnızca etkileşimli kabuk tarafından okunan /etc/bash.bashrc dosyasında da değişiklik yapmak istiyorum. Bu dosyada değişiklik yaptığımızda, sistem üzerinde etkileşimli bash kabuğunu başlatan tüm kullanıcılarda buradaki değişiklikler geçerli olacak. Dosyamızı açmak için yine sudo nano /etc/bash.bashrc şeklinde komutumuzu girebiliriz.

Öncelikle bu konfigürasyon dosyasının okunduğunun konsol üzerinden görülebilmesi için echo "/etc/bash.bashrc dosyası okundu! şeklinde yazalım. Tamamdır. Şimdi bir de dosya okunduğunda yine masaüstünde yeni bir dosya oluşturulması için de touch ~/Desktop/etc-bashrc-okundu şeklinde komutumuzu yazalım. Bu dosya okunup bu komut çalıştığında benim ev dizinimde etc-bashrc-okundu isminde bir dosya oluşturulmuş olacak. Evet, artık yavaş yavaş testlerimize geçmek için bu dosyadaki değişiklikleri de kaydedebiliriz. Ctrl + X ile dosyayı kapatıp değişiklikleri yes ile onaylayarak kaydedelim. 

Tamamdır artık iki dosya üzerindeki değişikliğin kabuklar üzerindeki etkisini kolayca gözlemeyebiliriz. Ben öncelikle grafiksel arayüzdeki değişimleri gözlemlemek istediğim için oturumu kapatıp tekrar grafiksel arayüzde oturum açmak istiyorum. Bakın şu anda masaüstümde konfigürasyon dosyasında belirttiğim isimde dosyalar yok. Eğer konfigürasyon dosyaları okunursa bu dosyalar da otomatik olarak oluşturulacak. Hadi hemen denemek için oturumumuzu kapatalım. Tamamdır, oturum kapatıldı. Şimdi tekrar burdan grafiksel arayüzde oturumumuzu açalım. 

Evet oturumum açıldı bakın, masaüstünde /etc/profile dosyasının okunduğunu kanıtlayan etc-profile-okundu dosyasını görebiliyoruz. Eğer biz grafiksel arayüzde oturum açarken /etc/profile dosyası okunmuyor olsaydı bu dosyası da burada göremeyecektik ama görebildiğiniz gibi dosya karşımızda duruyor. Bu dosya dışında eğer dikkatinizi çektiyse henüz /etc/ dizini altındaki bash.bashrc dosyası okunmamış çünkü bu dosya okunduğunda da masaüstüne etc-bashrc-okundu isimli bir dosya oluşturulacaktı. Oluşmadığına göre bu konfigürasyon dosyası henüz okunmamış. 

Bu konfigürasyon dosyası henüz okunmadı çünkü biz henüz yeni bir konsol açmadık. Eğer yeni bir konsol açarsak etkileşimli kabuk da başlatılacağı için bu konfigürasyon dosyası da okunacak. Hemen teyit etmek için yeni bir konsol açalım. Bakın biz konsolu açar açmaz masaüstünde bashrc-okundu isimli dosya da oluşturuldu ve ayrıca bakın konsolun en üstünde, konfigürasyon dosyasına eklemiş olduğumuz etc-bashrc. dosyası okundu ifadesi de bastırılmış. 

Neticede işte bizzat teyit edebildiğimiz gibi biz grafiksel arayüzde oturum açtığımızda, etc dizini altındaki profile dosyası okunuyor. Eğer biz grafiksel arayüzde yeni bir konsol açarsak da bu kez etc dizini altındaki bash.bashrc dosyası okunuyor. Çünkü bu konsollar etkileşimli kabuğu çağırıyor. 

Hazır grafiksel arayüzde konsolu açmışken burada dikkatinizi çekmek istediğim ek detay, fark ettiyseniz bu konsolda etc profile dosyasına eklediğimiz echo komutunu çıktısını göremedik. Bu çıktıyı göremedik çünkü grafiksel arayüzde başlattığımız bu konsollar yalnızca etkileşimli kabukları çağırıyor. Oturum açma kabukları olmadıkları için biz her konsol açtığımızda etc dizini atlındaki profile dosyası okunmuyor, bash.bashrc dosyası okunuyor. Profile dosyası yalnızca oturum açma kabuğu tarafından okunuyor. İnanmıyorsanız yeni konsollar da açmayı deneyebilirsiniz. Bakın hiç birinde etc profile dosyasındaki komutun çıktısını göremiyoruz. Hatta isterseniz bash komutunu kullanarak yeni bir etkileşimli kabuk da başlatabiliriz. Bakın yeni kabuk da etkileşimli olduğu için yalnızca etc dizini atlındaki bash.bashrc dosyasının okunduğunu haber veriyor. 

Ben değişikliklerin sonuçlarını grafiksel arayüzden gösterdim ancak aynı şekilde bu değişiklikler komut satırı üzerinde de geçerli.

Tüm bu söylediklerimizi teyit etmek için istersek hemen komut satırı arayüzüne geçip tty konsolu üzerinde oturum açabiliriz. Zaten oturum açtıktan sonra bize etkileşimli oturum açma kabuğu verileceği için her iki konfigürasyon dosyasının da okunduğuna dair çıktıyı konsolda görebileceğiz. Ben denemek için ctrl alt f6 ile 6. tty konsoluna geçiş yapıyorum. Bakın benden oturum açmam isteniyor. Hemen oturum açalım. veee bakın. Hem /etc/profile hem de /etc/bash.bashrc dosyasının okunduğuna dair çıktı aldık. Çünkü şu an bize tahsis edilen bu kabuk etkileşimli bir oturum açma kabuğu. Dolayısıyla bu kabuk başlatılırken her iki konfigürasyon dosyasını da okuyor. Çünkü daha önce de bahsettiğimiz şekilde komut satırı arayüzünde oturum açtıktan sonra bize verilen kabuk hem etkileşimli hem de oturum açma kabuğu statüsünde. 

Emin olmak isterseniz burada da bash komutunu girerek, yeni bir etkileşimli kabuk başlatmayı deneyebilirsiniz. Bakın bash komutu ile yalnızca etkileşimli bir kabuk başlattığımız için yalnızca etc dizini altındaki bash.bashrc dosyası okundu. Eğer yeni bir etkileşimli oturum açma kabuğu başlatmak istersek de bash -l komutu ile oturum açma kabuğunu çağırabiliriz. Bakın yine etkileşimli bir oturum açma kabuğu başladığı için her iki konfigürasyon dosyasının da okunduğuna dair çıktıları görebiliyoruz. İşte bu çıktılara bakarak bile hangi konfigürasyon dosyasının ne zaman çalıştırıldığını net bir biçimde görebiliyoruz.

Ayrıca ben anlatımlar sırasında yalnızca kendi hesabımı kullandım ancak bu değişiklikleri etc dizi altındaki dosyalarda yaptığımız için aslında hangi kullanıcı oturum açarsa açtın tüm kullanıcılarda bu değişiklikler aynen geçerli olacak. Çünkü etc dizini atlındaki profile dosyası tüm kullanıcıların oturum açma kabuğunu etkilerken, etc dizini atlındaki bash.bashrc dosyası da tüm kullanıcıların etkileşimli kabuklarını etkiliyor.

Ancak bundan önce bu dosyalardaki konfigurasyonların yalnızca kullanıcı hesabına özel olduğunu da teyit edebilmek için sisteme yeni bir kullanıcı ekleyip bu kullanıcı üzerinden de test edebiliriz. İleride yeni kullanıcı oluşturma işleminin ayrıntılarına değiniyor olacağım. Şimdi testimizi gerçekleştirebilmek için hemen hızlıca bir tane oluşturalım. Ben ali isminde yeni bir kullanıcı oluşturmak istiyorum. Bunun için sudo adduser ali şeklinde komutumu giriyorum. Yeni kullanıcı oluşturma işlemi yetki gerektirdiği için mevcut kullanıcı hesabımızın parolasını girip komutun çalıştırılmasını sağlayalım. Şimdi oluşturduğumuz yeni kullanıcı hesabı için bir parola belirleyelim, parolayı yeniden yazıp onaylayalım. Buradaki diğer bilgileri de enter ile doğrudan geçebiliriz. Tamamdır yeni kullanıcı hesabını oluşturduk. Artık kullanıcıya özel olan tanımlamalı bu kullanıcı üzerinden test edebiliriz. 

Tamamdır. Şimdi test etmek için 3. tty konsoluna geçiş yapabiliriz. Bakın benden yine oturum açmam isteniyor. Ben bu kez ali kullanıcısı olarak oturum açmak için kullanıcı adı olarak ali yazıyorum ve biraz önce tanımladığım parolamı da giriyorum. Ve bakın, tıpkı taylan kullanıcısında olduğu gibi ali kullanıcısı oturum açtığında da bu konfigürasyon dosyaları okunarak ali kullanıcısına tahsis edilen etkileşimli oturum açma kabuğunda da geçerli oldu. ali kullanıcısının henüz bir ev dizininde Desktop klasörü olmadığı için gerekli dosyanın oluşturulamadığına dair uyarı aldık. Desktop gibi klasörler grafiksel arayüzde oturum açtıktan sonra oluşturuldukları için yeni oluşturduğumuz kullanıcının ev dizini içinde bu klasörler yok ancak bunlar önemli değil. Buradaki çıktılar, etc dizini atlındaki konfigürasyon dosyaların tüm kullanıcılar üzerinde geçerli olduğunu zaten kanıtlıyor.

Hatta dilersek emin olmak için bash komutunu girip, yalnızca etkileşimli kabuktaki durama da bakabiliriz. Bakın, bu kabuk da aynı şekilde etc dizini atlındaki bash.bashrc dosyasının okuduğunu haber veriyor.

Bence en nihayetinde bu örneğimizle de birlikte etc dizini altındaki bu konfigürasyon dosyalarının tüm kullanıcılar üzerinde ortak olarak geçerli olduğunu da kanıtlamış olduk. 

Sizler de yapılandırma ayarlarınızın hangi kabuk türünde geçerli olmasını istiyorsanız ilgili kabuğun türüne uygun olan konfigürasyon dosyalarında gerekli düzenlemeleri yapabilirsiniz.

Bunlar sistem genelinde tüm kullanıcılarda geçerli olacak konfigürasyon dosyalarıydı. Şimdi kullanıcılara özel olan yapılandırma dosyalarından da kısaca bahsedebiliriz. Daha sonra bu konfigürasyon dosyalarından istediğimiz bir tanesine PATH dizini için yeni değişken tanımlayıp, tüm sistem genelinde veya kullanıcıya özel olarak nasıl yeni PATH dizinleri ekleyebileceğimizi öğrenmiş olacağız. Yani merak etmeyin tüm bu konuları anlatmamızı gerektiren asıl konuya yani PATH yoluna yeni dizin eklemeye anlatımın sonunda ayrıca değineceğiz. Şimdi kullanıcılara özel olan konfigürasyon dosyalarından bahsederek devam edelim.

## Kullanıcı Bazlı Yapılandırma

Söz konusu kullanıcıya özel konfigürasyon tanımlaması olduğunda tek fark, konfigürasyon dosyalarının ilgili kullanıcıların kendi ev dizinlerinde bulunuyor olması. /etc dizini altındaki dosyalar tüm kullanıcıları etkiliyorken, her bir kullanıcının kendi ev dizinindeki konfigürasyon dosyaları da yalnızca o kullanıcıyı etkiliyor.

Örneğin kullanıcının oturum açma kabuğuna özel tanımlama yapmak için yapılandırma bilgilerinin kullanıcının ev dizininde bulunan .profile isimli dosyaya eklenmesi gerekiyor. Tıpkı benim kullandığım Ubuntu dağıtımı gibi debian tabanlı dağıtımlarda .profile dosyası varsayılan olarak kullanıcıların ev dizinlerinde bulunuyor. Yine de kullanıcıların ev dizininde .profile dosyasının olmadığı durumlarda bash kabuğu .bash_login ya da .bash_profile isimli dosyalar var mı diye ek olarak kontrol ediyor. Dolayısıyla sizin kullandığınız kullanıcının ev dizininde .profile isimli bir dosya yoksa .bash_login ya da .bash.profile dosyalarına da göz atabilirsiniz. 

Tüm bunlar dışında eğer kullanıcının etkileşimli kabuğuna özel tanımlama yapmak istiyorsak değişiklikleri kullanıcının ev dizininde bulunan .bashrc dosyasında yapmamız gerekiyor.

Kullanıcıların ev dizinlerinde bulunan tüm konfigürasyon dosyaları yalnızca bu kullanıcıya özel olan tanımlamaları içeriyor. Yani bu konfigürasyon dosyaları yalnızca bu kullanıcı tarafından kullanılıyor.

Ben şu an kullanmakta olduğum ali kullanıcısının konfigürasyon dosyalarını görmek istediğim için konsola ls -a /home/ali/ şeklinde komutumu giriyorum. Bakın çeşitli konfigürasyon dosyaları listelendi.

Eğer dikkatinizi çektiyse buradaki konfigürasyon dosyalarının başında hep nokta işareti bulunuyor. Yani örneğin .profile .bash_profile gibi. Dosya isimlerinin başındaki nokta karakteri, o dosyanın gizli dosya olmasını sağlıyor. Kullanıcıların ev dizininde bu tür konfigürasyon dosyalarının gizlenmiş olmasının nedeni de, bu önemli dosyaların yanlışlıkla silinmesini önlemektir. Neticede kullanıcılar kendi ev dizinlerinde kendilerine ait dosyaları barındırıp gerektiğinde sildiği için önemli konfigürasyon dosyalarını gizlemek silinmelerine karşı mantıklı bir önlem. Zaten ben bu dosyalar gizli olduğu için ls komutuna gizli dosyaları da listelemesi için -a seçeneği de ekledim. Eğer yalnızca ls komutunu kullanırsak, bakın başında nokta olan gizli dosyalar gözükmüyor.

Tamamdır, artık ben kendi kullanıcı hesabımdaki konfigürasyon dosyalarını da listelediğime göre uygulamalı şekilde bu konfigürasyonlardaki değişiklikleri teyit edebiliriz. Ben değişiklikleri şu an kullandığım ali kullanıcısının ev dizinindeki konfigürasyonlarda yapıp sonuçlarını gördükten sonra, bir de harici kullanıcı olan taylan kullanıcısı olarak oturum açıp değişiklikten etkilenip etkilenmediğini de teyit edeceğim.

Ben tıpkı daha önce olduğu gibi yine benzer şekilde okunan dosyanın bilgisini konsola ve masaüstündeki yeni dosyaya aktaracak komutları yazacağım. 

Değişikliklerin mevcut kullanıcı hesabındaki etkileşimli kabuklarda geçerli olması için ev dizinindeki .bashrc dosyasını düzenlemem gerekiyor. Bunun için nano ~/ali-bashrc komutuyla ali kullanıcısının ev dizinindeki bashrc dosyasını açıyorum.

Şimdi öncelikle bu dosya okunduğunda konsola çıktı bastırması için echo “/home/ali/.bashrc dosyası okundu” yazıyorum. Şimdi bir de yeni bir dosya oluşturulması için touch ~/ali-bashrc-okundu şeklinde komutumuzu girelim. Tamamdır.

Dosyamı ctrl x ile kaydedip kapatıyorum. 

Şimdi bir de oturum açma kabuğunda etkili olacak değişiklikler için yine ali kullanıcısının ev dizinindeki .profile dosyasına benzeri şekilde eklememizi yapalım. Bunun için yine nano ~/.profile şeklinde komutumu giriyorum. Daha önce de söylediğim gibi eğer sizde .profile dosyası yoksa .bash_login ya da .bash_profile dosyalarından hangisi varsa o dosya üzerinde burada yaptığımız şekilde düzenlemede bulunabilirsiniz. Şimdi teyit için gerekli komutları bu dosyama da eklemek istiyorum. Öncelikle konsola çıktı bastıracak komutumuzu girelim. Tamamdır şimdi bir de dosya oluşturacak komutumuzu da girelim. Tamam. Artık testlere geçmek için dosyamızı kaydedip kapatabiliriz.

Şimdi sonuçları gözlemlemek için tekrar grafiksel arayüzde geçiş yapıp ali kullanıcısı olarak oturum açabiliriz. Ancak şimdiden belirteyim biz ali kullanıcısı olarak ilk defa grafiksel arayüzde oturum açacağımız için daha önceden ali kullanıcısı için desktop documents ve benzeri diğer klasörler oluşturulmamıştı. Bu klasörler grafiksel arayüzde standart kullanıcıların kişisel dosyalarını grafiksel arayüz üzerinden rahatlıkla düzenleyebilmesi için kullanıldığından grafiksel arayüzde oturum açmadığımız sürece bu klasörler de doğal olarak oluşturulmuyor. Şimdi ilk oturumda, ben ali kullanıcısı olarak grafiksel arayüzde oturum açtığımda öncelikle bu klasörler oluşturulacağı için konfigürasyon dosyalarında belirttiğimiz şekilde masaüstünde yeni dosyalar oluşturulamayacak çünkü bu konfigürasyon dosyaları okunduğu sırada henüz Desktop klasörü ali kullanıcısı için oluşturulmayacak. Bu sebeple hemen hızlıca grafiksel arayüze girip çıkalım ve tekrar girelim. Ben şimdi ali kullanıcısı olarak girişimi yapıyorum. Bakın tıpkı kurulum aşamasında olduğu gibi yeni bir kullanıcı olarak oturum açtığımız için bizi hazırlık penceresi karşılıyor. Bu pencereyi hızlıca atalayabiliriz. Tamamdır. Şimdi oturumuzu kapatıp tekrar açabiliriz. Ben buradan oturumu kapatıyorum. Şimdi tekrar ali kullanıcısı olarak giriş yapacağım. Ve işte bakın grafiksel arayüzde oturum açtığımda, artık desktop klasörü olduğu için ali kullanıcısının ev dizinindeki profile dosyasının okunduğunu kanıtlayan yeni dosyanın masaüstün olduğunu görebiliyoruz. Profile dosyası oturum mevcut kullanıcının oturum açma kabuğunda etkili olduğu için şu an yalnızca bu dosya üretildi. 

Şimdi bir de yeni bir konsol penceresi açalım. Bakın yeni konsolla birlikte etkileşimli bir kabuk başlatıldığı için ilk olarak tüm kullanıcıların etkileşimli kabukları tarafından okunan etc bash.bashrc dosyasının okunduğuna dair çıktı basılmış, daha sonra ise mevcut kullanıcıya özel olan bashrc dosyasının okunduğunu kanıtlayan çıktı da bastırılmış. Ayrıca bakın masaüstünde tüm kullanıcılar için oluşturulacak olan dosyanın yanında bir de yalnızca ali kullanıcısının ev dizinindeki bashrc dosyası okunduğunda oluşturulacak olan dosyanın oluşturulduğunu görebiliyoruz. Eğer konsola bash yazarsak, bakın ev ali kullanıcısının ev dizinindeki .bashrc dosyasının okdunuğunu bildiren çıktıyı alıyoruz. Benzer şekilde etkileşimli bir oturum açma kabuğu başlatmak için bash -l şeklinde komutumuzu da girebiliriz. Bakın bu kez hem etkileşimli hem de oturum açma kabuğu başlatıldığı için ali kullanıcısının ev dizininde profile ve bashrc dosyalarının okunduğunu bildiren çıktıları aldık. 

Neticede konfigürasyon dosyalarındaki değişikliklerin ali kullanıcısı üzerinde sorunsuzca çalıştığını bizzat teyit ettik. 

Şimdi son olarak bu değişikliklerin yalnızca benim tanımladığım şekilde yalnızca ali kullanıcısı için geçerli olduğunu teyit etmek için bu kez taylan hesabında oturum açmayı deneyebiliriz. Ben oturum açmak için mevcut oturumumu kapatıyorum. Şimdi taylan kullanıcısı olarak oturum açalım. Grafiksel arayüzün kendine gelmesi biraz zaman alabilir biraz bekleyelim. Bakın masaüstünde, tüm kullanıcılar için geçerli olan etc dizinindeki profile dosyasının okunduğunu kanıtlayan dosya var ancak ali  kullanıcısı için oluşturulan özel dosya yok. Hemen yeni bir konsol penceresi açıp etkileşimli kabuktaki durumu da gözlemleyelim. Bakın etkileşimli kabukta da yalnızca tüm kullanıcılar için geçerli olan etc dizini atlındaki bash.bashrc dosyasının okunduğuna dair çıktıyı görebiliyoruz. Ve ayrıca masaüstünde de yalnızca bu dosyanın okunduğunu kanıtlayan dosyanın üretildiğini görebiliyoruz.

Böylelikle kullanıcıların ev dizinlerinde konfigürasyon dosyalarının yalnızca ilgili kullanıcıyı etkilediğini de bizzat test etmiş olduk. En nihayetinde artık bash kabuğunun yapılandırmasını hangi kapsamda yapmak istiyorsanız tam olarak ona uygun düzenlemeleri hangi dosyada yapmanız gerektiğini biliyorsunuz.

Özetlemek gerekirse, eğer tüm kullanıcıları ortak olarak etkileyecek bir değişiklik yapacaksanız /etc dizini altındaki konfigürasyonları kullanırken, kullanıcı özelindeki değişimleri de kullanıcıların kendi ev dizinindeki konfigürasyonlarda gerçekleştirmeniz gerekiyor.

Ayrıca söz konusu değişiklikler etkileşimli kabuk üzerinde geçerli olacak bir değişiklik ise, dosya isminde bashrc gibi bir ifade geçiyorken, oturum açma kabuğu için profile veya login ismi geçen konfigürasyon dosyalarını kullanmanız gerekiyor. 

Bu özeti hatırlarsanız, zaten ne zaman hangi dosyada değişiklik yapmanız gerektiğini kolayca keşfedebilirsiniz. Ayrıca burada söylediklerim dışında elbette konfigürasyon dosyalarını açıp, yorum satırlarında belirtilen yazıları da okuyabilirsiniz. Zaten dosyaların en başında bu dosyanın hangi amaçla kullanıldığı açıklandığı için doğru konfigürasyon dosyasını öğrenmek için dosya içeriklerini kontrol etmeniz yeterli. Farklı dağıtımlar farklı dosyaları kullanabileceği için en mantıklısı dosya içeriğini açıp okumak. 

Son olarak bazılarınızın da anlatımlar sırasında fark ettiğini düşündüğüm gibi bu konfigürasyon dosyalarının okunma sıralaması olduğuna da dikkatinizi çekmek istiyorum. 

Çok kısaca açıklamamız gerekirse, eğer başlatılan kabuk etkileşimli oturum açma kabuğu ise sırasıyla /etc/profile ve kullanıcın kendi ev dizininde .bash_profile dosyası okunuyor. 

Eğer .bashrc_profile dosyası yoksa sırasıyla .bash_login ve .profile dosyasına göz atıp ilk hangi dosyayı bulursa o dosyayı okuyup diğer dosyaları görmezden geliyor.

Oturum açma kabuğu için olan sistem genelindeki ve kullanıcı özelindeki dosyalar okunduktan sonra etkileşimli kabuk için sistem genelinde geçerli olan /etc/bash.bashrc dosyası okunuyor. Daha sonra kullanıcının ev dizininde .bashrc dosyası okunuyor.

Eğer başlatılan kabuk etkileşimli oturum açma kabuğu değil de yalnızca etkileşimli kabuk ise elbette öncelikle etc dizini altındaki bash.bashr dosyası okunup daha sonra kullanıcının kendi ev dizinindeki .bashrc dosyası okunuyor.

Buradaki diagram hangi dosyanın hangi durumda okunduğunu alma konusunda çok yardımcı olabilir. Ayrıca diagram üzerinde görebileceğiniz gibi farklı kabuk türlerinde de benzeri şekilde kabuğa özgü olan farklı türlerdeki konfigürasyon dosyaları okunuyor. 

Zaten sıralamaların bu şekilde olduğunu özellikle ali kullanıcısı için aldığımız çıktılarda da bizzat görmüştük. 

Hangi konfigürasyon dosyasının hangi sıralamada okunduğunun farkında olursanız, bir konfigürasyon dosyasında girdiğiniz tanımlamanın daha sonra okunacak olan konfigürasyon dosyasında devredışı bırakılması veya değiştirilmesi gibi işlemlerin de farkında olabilirsiniz. Temelde konfigürasyon dosyasının işlevleri ve çalıştırılma sıralamaları hakkında bilmemiz gerekeneler bunlar.

Ayrıca testler sırasında eklemiş olduğumuz tüm echo ve touch komutu ile başlayan ifadeleri ilgili dosyalardan silip kaydederseniz, her kabuk açtığınızda bu ifadeleri görmekten ve dosya oluşturulmasından da kurtulmuş olursunuz. Neticede biz bu komutları, konfigürasyon dosyalarının çalışma şartlarını test etmek için ekledik, artık gerekmiyorlar. 

Kabuğun yapılandırılmasıyla ilgili temel bilgiyi öğrendiğimize göre artık nihayet PATH dizinlerine kendi istediğimiz yeni bir dizin adresini ekleyebiliriz. Biliyorum yalnızca PATH yoluna yeni bir dizin eklemek için bu kadar kavramdan bahsetmem özellikle yeni başlayan kullanıcıların gözünü biraz korkutmuş olabilir ancak endişelenmeyin. Tüm anlatımları temellendirerek açıklamaya çalıştığımız için tüm kavramlar zaman içinde bütüncül olarak sizlere mantıklı gelmeye başlayacak. Neticede zor, sıkıcı veya karmaşık olduğunu düşünmeden konular arasındaki genel neden sonuç ilişkisini görebiliyor olacaksınız.

Her neyse, bence çok iyi gidiyoruz. Gelin kendi hesabımız için yeni bir PATH dizini nasıl tanımlayabileceğimizi öğrenerek devam edelim.

# PATH Yoluna Yeni Dizin Ekleme

Ben path yoluna yeni dizin ekleme işlemi için tekrar kendi kullanıcı hesabıma yani taylan kullanıcısına geri döndüm. 

Şimdi örneğin ben yalnızca mevcut kullanıcı hesabımda geçerli olmasını istediğim için ev dizinimde bulunan .bashrc dosyasına yeni PATH adresi ekleyebilirim.

Öncelikle yeni ekleyeceğimiz dizini oluşturalım. Ben örnek olarak masaüstüme bir dizin oluşturup bu dizini PATH yoluna eklemek istiyorum. Klasörü komut satırından da oluşturabiliriz ancak üst üste çok fazla komuttan bahsetmek istemediğim için grafiksel arayüzden masaüstüme sağ tıklayıp yeni bir klasör oluşturuyorum. Bu klasörümü PATH dizinine eklemeyi deneyeceğim.

Yeni adres eklemek için .bashrc dosyasını `nano ~/.bashrc` komutu ile açabiliriz. Buradaki tilde işareti benim kullanmakta olduğum mevcut kullanıcı hesabının ev dizini temsil ediyor. Bunun yerine doğrudan ev dizini adresimi /home/taylan/ şeklinde de girebilirdim. Ancak tilde işareti doğrudan benim ev dizinimi işaret eden işlevsel bir kısayol. Tilde işaretini üretmek için klavyenizden "Alt Gr + Ü" tuşuna basmanız yeterliydi biliyorsunuz. Komutumuzu onaylayalım. Tamamdır, artık dosya içeriğinde değişiklik yapabiliriz.

Önceki dizin adreslerini bozmamak için dosyanın en altına gelip, var olan değişkene ekleme yapacağız. Öncelikle export PATH= yazıyorum ve tırnak işaretini açıyorum. Buradaki export komutu bu değişkenin tüm kabuklara miras olarak aktarılmasını sağlayacak. Ben yeni ekleyeceğim dizinin PATH yolunda ilk sırada olmasını istediğim için öncelikle dizin adresini yazacağım. Benim ekleyeceğim yeni dizin masaüstümde bulunduğu için /home/taylan/Desktop/yeni_dizin/ şeklinde yazıyorum. Dizin adresini yazdıktan sonra iki nokta üst üste işaretini de ekleyip $PATH ifadesini de yazıp tırnağı kapatıyorum. Buradaki $PATH eski değişkenin değerini yeni tanımladığım değişkene aktaracak. Bu sayede eski PATH yolunun en başına burada belirttiğim dizin de eklenmiş olacak.

Burada ben PATH yolunun başına yeni dizini ekledim. Eğer PATH yolunun sonuna eklemek isteseydim komutumu `export PATH="$PATH:/home/taylan/Desktop/yeni_dizin/"` şeklinde de girebilirdim. Eklenen dizinin başta veya sonra olması, ilgili dizine kabuk tarafından bakılma sıralamasını değiştirdiği için kendi önceliklerinize göre hangi sıralamada yazmak istediğinize kendiniz karar verebilirsiniz. Zaten bu sıralamanın nasıl çalıştığınız bizzat test etmiştik hatırlıyorsanız. İlk önce sizin eklediğiniz dizine bakılsın istiyorsanız en başa, eğer son son sizin dizine bakılsın istiyorsanız da en sonra yeni dizini ekleyebilirsiniz.

Neticede PATH değişkeni, eklediğim yeni dizin adresiyle birlikte yeniden tanımlanmış oldu. Artık mevcut kullanıcı hesabı yani taylan kullanıcısı her yeni kabuk çalıştırdığında bu PATH değişkeni de değiştirdiğim şekliyle geçerli olacak. .bashrc dosyasındaki değişikliği kaydedip dosyayı kapatmak için Ctrl + X kısayolunu kullanabiliriz. Dosya kaydedilsin mi diye soruyor, yes diyelim ve onaylayalım. Evet böylelikle yaptığımız değişiklik konfigürasyon dosyasına kaydedilmiş oldu.

Şimdi değişikliğin geçerli olup olmadığını test etmek için yeni bir konsol ekranı açabiliriz. Yeni konsolla birlikte yeni bir bir etkileşimli bir kabuk başlatılacağı için, etkileşimli kabuk ev dizinimdeki .bashrc dosyasını okuyacak. Ben değişikliği teyit etmek için echo $PATH şeklinde komutumu giriyorum.

Bakın PATH dizinin en başına benim eklediğim masaüstü dizinindeki klasör de eklenmiş. Dilersek bu klasör içerisine yeni bir betik dosyası ekleyip bu klasörün kabuk tarafından dikkate alınıp alınmadığını da test edebiliriz. Ben test etmek için cat > ~/Desktop/yeni-dizin/betik3.sh komutu ile yeni-dizin klasöründe yeni bir betik dosyası oluşturuyorum. Buradaki tilde işaretinin benim ev dizini temsil ettiğini zaten biliyoruz. Kısaca yazmak için bu işareti kullandım. Betik dosyasının içine de echo "merhaba ben betik3" şeklinde komutumu ekleyip ctrl d ile dosyayı kaydediyorum. Son olarak dosyama çalıştırma yetkisi vermek için chmod +x ~/Desktop/yeni-dizin/[betik.sh](http://betik.sh) şeklinde komutumu giriyorum. Tamamdır artık her şey hazır. Eğer bash kabuğu benim PATH yoluna yeni eklediğim bu klasöre bakıyorsa dosyamı konsoldan ismiyle çağırıp çalıştırabilirim. Denemek için betik3.sh şeklinde komutumu giriyorum. Harika! Bakın betik dosyamız sorunsuzca çalıştı. Bu çıktı, bizim PATH yoluna istediğimiz yeni dizini başarıyla ekleyebildiğimizi kanıtlıyor.

Ben örnek olması için yalnızca kendi hesabımda geçerli olacak şekilde PATH yoluna yeni bir dizin ekledim. Yani diğer kullanıcılarda bu değişiklik geçerli olmayacak. Test etmek isterseniz daha önce oluşturduğunuz ek kullanıcı hesabına geçiş yapıp PATH adresini kontrol edebilirsiniz.

Eğer sizler eklediğiniz dizinin tüm kullanıcı hesaplarında geçerli olmasını istiyorsanız, daha önce uzun uzadıya nedenleriyle açıkladığımız şekilde /etc/profile /etc/bashrc ya da /etc/bash.bashrc dosyalarından birinin içine aynen bizim örnekte yaptığımız şekilde yeni dizin adresi tanımlayabilirsiniz.

Ancak anlatımın başında da söylediğim gibi, PATH yoluna yeni dizin adresi eklemenizi kesinlikle önermiyorum. Çünkü bu dizinlerin erişim yetkileri uygun şekilde kısıtlanmazsa sistemin güvenliğini açıkça riske edebilir. Örneğin bu dizinlere yetkisiz kullanıcılar tehlikeli araçları taşıyıp kabuk üzerinden çalıştırılmalarını sağlayabilirler. Bu sebeple zorunda kalmadıkça veya ne yaptığınızın farkında olmadığınız sürece PATH yoluna yeni dizin adresi tanımlamanızı kesinlikle önermiyorum.

Tüm bunlar dışında eğer konfigürasyon dosyalarında yapmış olduğunuz değişiklikleri geri almak istiyorsanız, ilgili dosyalara eklediğiniz tanımlamaları silmeniz yeterli. 

Ayrıca son olarak size pratik bir bilgi daha vermek istiyorum. Eğer konfigürasyon dosyalarının dilediğiniz kabuk tarafından okunmasını, yani ilgili konfigürasyon dosyasının mevcut kabuğunuzda da geçerli olmasını istiyorsanız source ya da . nokta komutlarını kullanabilirsiniz. Normalde sizin de bildiğiniz gibi konfigürasyon dosyaları yalnızca ilişkili oldukları kabuk başlatılırken okunuyor. Ancak aslında konfigürasyonların geçerli olması için yeni kabuk başlatılana kadar beklemek zorunda da değilsiniz. Eğer mevcut kullanmakta olduğunuz kabuk için kabuğu kapatmadan yeni konfigürasyon ayarlarının geçerli olmasını isterseniz, source ya da nokta komutu ile ilgili konfigürasyon dosyasının hemen okunup uygulanmasını sağlayabilirsiniz.

Ben denemek için mevcut kabuğumda ~/.bashrc dosyasını düzenleyeceğim ve yeni bir kabuk açmadan mevcut kabuk üzerinden değişimi gözlemleyeceğim. Dosyayı açmak için sudo nano ~/.bashrc komutunu giriyorum. Şimdi yeni bir değişken tanımlayacağım ve bu değişkenin mevcut kabukta da geçerli olmasını sağlayacağım. test1="ben en son eklenen değişken" şeklinde yazıyorum. Ve dosyayı kaydedip kapatıyorum. Şimdi eğer yeni bir konsol açarsam yeni bir etkileşimli kabuk başlatılacağı için bu konfigürasyon dosyası okunacaktır. Dolayısıyla yeni açtığım konsol üzerinden test1 değişkeninin değerini bastırabilirim. Hemen deneyelim. Yeni bir konsol açıyorum. Değişkeni bastırmak üzere echo $test1 şeklinde komutumu giriyorum. Bakın yeni kabuk başlatılırken dosya okunduğu için değişkenin değerini bastırabildim. Şimdi aynı değişkeni daha önce açık olan kabukta tekrar bastırmayı deneyelim. Bakın herhangi bir çıktı almadık, çünkü bu kabuk konfigürasyon dosyası düzenlenmeden önce açılmıştı zaten. Yani konfigürasyon dosyasındaki değişiklikleri tekrar okumadığı için etkilenmedi. Eğer biz dosyayı tekrar okumasını istersek source ya da nokta komutu ile mevcut kabuğun ilgili konfigürasyon dosyasını okumasını sağlayabiliriz. Ben ev dizinimdeki bashrc dosyasında değişiklik yaptığım için, bu dosyanın mevcut kabuk tarafından okunması için source ~/.bashrc şeklinde komutumu giriyorum. Bunun yerine istersem . ~/.bashrc komutunu da kullanabilirim. İkisi de aynı görevi yerine getiriyor. Neticede konfigürasyon dosyası mevcut kabuk tarafından okunmuş oldu. Hemen teyit etmek için değişkenimi tekrar bastırmayı deniyorum. Bakın değişkenin değeri sorunsuzca bastırılmış oldu. İşte sizler de bu şekilde istediğiniz konfigürasyon dosyasının mevcut kabuk tarafından okunup, yapılandırma ayarlarının geçerli olmasını sağlayabilirsiniz. 

Örneğin ben denemek için yine .bashrc dosyasında değişiklik yapmak istiyorum. nano ~/.bashrc komutu ile tekrar dosyamızı açalım. Şimdi ben test etmek için test=”denem” şeklinde yeni bir değişken tanımlıyorum. Dosyamızı kaydedip kapatalım . Normalde bashrc dosyası mevcut kullanıcı yeni bir etkileşimli kabuk başlatırken okunuyor. Hatta bu durumu teyit etmek için biraz önce konfigürasyon dosyasında tanımladığım test değişkenini echo $test komutu ile bastırmayı deneyebiliriz. Bakın herhangi bir çıktı alamadık. Şimdi konfigürasyon dosyasınuın mevcut kabukta da geçerli olması için source ~/.bashrc ya da . ~/.bashrc şeklinde okunmasını istediğimiz konfigürasyon dosyasnını belirtelim. Tamamdır, konfigürasyonlar okundu ve artık mevcut kabuk üzerinde de geçerli. Bu durumu teyit etmek için tekrar echo $test komutunu girebiliriz. Bakın tanımadlığım değişken artk mevcut kabuk üzerinden de ulaşılabiliyor çünkü source ya da nokta komutu sayesinde ilgili konfigürasyon dosyasının hemen okunup geçerli olmasını sağladım. İşte sizler de source ya da nokta komutu ile konfigürasyon dosyalarının anında mevcut kabuk üzerinde geçerli olmasını sağlayabilirsiniz.

Size son olarak konfigürasyon dosyalarında değişiklik yaparken dikkatli olmanız gerektiğini söylemek istiyorum. Eğer değişiklik yapmanız gerekiyorsa, konfigürasyon dosyalarınızın var olan yapısını bozmadan neler eklediğinizin de farkında olarak değişiklik yapın. Ve değişiklik yapmadan önce mutlaka mevcut dosyanın yedeğini alın. Bu sayede hatalı konfigürasyonlardan kolayca eskisine dönüş yapabilirsiniz. Özellikle zamanla içerisine pek çok ekstra konfigürasyon tanımlaması eklenmiş dosyaların yeni eklemelerden önce mutlaka yedeklerinin alınması gerekiyor. Aksi halde kabuğun doğru şekilde çalışmamasına ve sistem güvenliğinin ihlaline sebep olabilirsiniz.

Böylelikle konsola bir komut girdiğimizde, temelde neler olduğunu öğrenmiş olduk. Aslında daha çok nasılını ve nedenini sorguladık ve ihtiyacımız olan temel bilgiyi edindik. Eğitimin devamında burada edindiğimiz temel üzerine yeni bilgilerimizi ekliyor olacağız.

# Sorular

1-) Aşağıdaki şıklardan hangisinde ls -la /home komutu hakkında yanlış bir ifade vardır.

- Çalıştırılacak araç ls aracıdır.
- -la olarak yazılmış ifade ls aracının seçeneği olarak girilmiştir.
- /home seçeneği bu ls aracının listelemesi gereken dizin içeriğini belirten parametredir.
- Bash kabuğuna göre bu komutta yalnızca ls ifadesi argümandır. (Yanlış, bash kabuğu girilen komutları boşluklarından argümanlara ayırdığı için bu komuttaki her bir ifade ayrı bir argümandır.)

2-) Kabuk tarafından bir araç çalıştırılacağı zaman, aşağıdaki değişkenlerden hangisinin verdiği dizin adresleri kontrol edilir ?

- HOME
- USER
- PATH -Doğru
- PWD

3-) Bash kabuğu yalnızca aracın ismi belirtilmiş bir komut gördüğünde bu aracı çalıştırmak için aracı ilk olarak nerede arar ?

- PATH dizinine
- Yerleşik komutlara - Doğru
- Mevcut dizindeki dosyalara

4-) Mevcut dizinimde bulunan ve çalıştırılma yetkisi mevcut olan [betik.sh](http://betik.sh) isimli bir betik dosyasını çalıştırmak için aşağıdaki komutlardan hangisini girebiliriz?

- betik.sh
- /betik.sh
- .betik.sh
- ./betik.sh - Doğru

5-) Yalnızca mevcut kullanıcı hesabının etkileşimli kabuğunda geçerli olacak bir değişiklik için hangi konfigürasyon dosyası kullanılmalı ?

- /etc/bash.bashrc
- ~/.bashrc -Doğru
- /etc/profile
- ~/.profile

6-) Tüm kullanıcıların oturum açma kabuğunda etkili olacak değişiklikleri hangi konfigürasyon dosyasında yaparsınız ?

- /etc/bash.bashrc
- ~/.bashrc
- /etc/profile -Doğru
- ~/.profile

7-) Yalnızca mevcut kullanıcı hesabının oturum açma kabuğunda geçerli olacak bir değişiklik için hangi konfigürasyon dosyası kullanılmalı ?

- /etc/bash.bashrc
- ~/.bashrc
- /etc/profile
- ~/.profile - Doğru

8-) Tüm kullanıcıların etkileşimli kabuğunda etkili olacak değişiklikleri hangi konfigürasyon dosyasında yaparsınız ?

- /etc/bash.bashrc - Doğru
- ~/.bashrc
- /etc/profile
- ~/.profile

9-) Aşağıdaki dosyalardan hangisi daha önce okunur ?

- /etc/bash.bashrc
- ~/.bashrc
- /etc/profile - Doğru
- ~/.profile

10-) Aşağıdaki dosyalardan hangisi kabuk tarafından en son okunur ?

- /etc/bash.bashrc
- ~/.bashrc - Doğru
- /etc/profile
- ~/.profile

11-) Aşağıdaki dosyalardan hangisi oturum açma kabuğuyla ilgili olmayan konfigürasyon dosyasıdır ?

- ~/.bash_profile
- ~/.bashrc - DOĞRU
- ~/.bash_login
- /etc/profile

Hatırlıyorsanız, etkileşimli kabuk için dosya isminde bashrc gibi bir ifade yer alması gerekirken, oturum açma kabuklarıyla ilgili olan konfigürasyon dosyalarında login ya da profile gibi ifadeler yer aldığını belirtmiştik. 

12-) Tüm alt kabuklara miras bırakılacak yani global olacak yeni bir değişken tanımlamak için aşağıdaki komutlardan hangisi doğru komuttur ?

- degisken=degeri
- export degisken - Bu seçenek değil çünkü bu komut halihazırda var olan lokal bir değişkeni global hale getirir. Soruda hangi komutun yeni bir global değişken tanımladığı soruluyor.
- export degisken=degeri -DOĞRU
- degisken=”değeri”

13-) Path Yolu buradaki gibi olan “/usr/sbin:/usr/bin:/sbin:/bin:” sistemde çalıştırılacak araç ilk olarak hangi path dizini üzerinde aranır ?

- /usr/sbin - DOĞRU çünkü PATH yolundaki dizinler soldan sağa doğru kontrol ediliyor.
- /usr/bin
- /sbin
- /bin

14-) Eğer PATH yoluna yeni bir dizin adresi eklemek istersek ilgili konfigürasyon dosyasına hangi komutu girersek tüm alt kabuklarda da dahil ilk olarak bizim yeni eklediğimiz dizine bakılır? 

- export PATH=”$PATH:yeni/dizin”
- PATH=”$PATH:yeni/dizin”
- $PATH=”yeni/dizin:$PATH”
- export PATH=”yeni/dizin:$PATH” - PATH değişkeninin en başına yeni dizinimizi ekleyip bu değişkeni de export ettiğimiz için alt kabuklar da dahil tüm kabuklar ilk olarak bizim yeni eklediğimiz dizine bakıyor olacak.

15-) Örneğin ~/.bashrc dosyasındaki değişikliklerin anında mevcut kabuğumuzda geçerli olması için aşağıdaki yöntemlerden hangisi işe yaramaz ?

- source ~/.bashrc
- . ~/.bashrc
- export ~/.bashrc - DOĞRU Çünkü export komutu yalnızca lokal değişkenleri global hale getirmek için var.

# Pratikler

- Denemek için konsola basit merhaba dünya ifadesini bastıran bir betik dosyası oluşturun ve bu dosyaya çalıştırma yetkisi verip herhangi bir path dizinine taşıyın. Tüm işlemlerin arından konsol üzerinden betik dosyasını yalnızca ismiyle çalıştırıp çalıştırmadığınızı test edin. Bu pratikteki amaç, çalıştırılabilir herhangi bir dosyanın PATH yolundaki dizinlerinden birine taşınıp, kabuk tarafından kolayca bulunabilir kısınmasıdır. Özellikle sistem bazı araçlar kurduğunuzda, kimi araçlar sizden aracın çalıştırılabilir bazı dosyalarını PATH üzerindeki bir dizine eklemenizi talep edeceklerdir. Bu durum windows üzerinde de bulunuyor. Yani bu pratikteki amacımız PATH in çalıştırılabilir dosyalar için bakılan dizinleri temsil ettiğini kavramaktır.
- PATH yolu üzerindeki dizinlerin önceliklerini kavrayabilmek için dilerseniz, daha önce oluşturduğunuz betik dosyası ile aynı isimli yeni bir betik dosyası daha oluşturup daha sonra bakılan path dizinlerinden birine taşıyıp kabuk üzerinden betik dosyanızı çağırmayı deneyebilirsiniz. Eğer adımları doğru uygularsanız, yalnızca PATH yolu üzerindeki ilk betik dosyasının çalıştırıldığına şahit olacaksınız çünkü kabuk aradığı aracı bulduğunda PATH üzerindeki sonraki dizinlere bakmıyor.
- Kendi isminizi veren “ad” isimli bir değişken oluşturup bu değişkeni tüm kullanıcıların etkileşimli kabukları ve hatta alt kabukları tarafından da ulaşılabilecek şekilde uygun konfigürasyon dosyasına ekleyin. Burada doğru konfigürasyon dosyasında düzenleme yapmak ve alt kabuklar da geçerli olması için değişkeni global hale getirmek önemli detaylardır.
- PATH yolunun sonuna yalnızca sizin kullanıcı hesabınızdaki etkileşimli kabuklarda geçerli olacak şekilde yeni bir dizin ekleyin. Ve bu değişikliğin mevcut kabuğunuz üzerinde etkili olması için ilgili konfigürasyon dosyasının hemen okunmasını sağlayacak komutu girin.
- Komut satırı arayüzünde oturum açtıktan sonra sizi selamlayacak bir mesaj yazmak için, mevcut kullanıcı hesabınız oturum açtığında okunan konfigürasyon dosyasına gerekli düzenlemeyi yapın. Eğer kendi kullanıcı adınızı konsola otomatik olarak bastırmak istiyorsanız USER değişkenini kullanabilirsiniz. Yapdığınız değişiklik sayesinde tty konsollarından birinde oturum açtığınızda kabuk ilk olarak sizi selamlıyor olacak.
- Son olarak eğer yaptığınız değişikliklerden memnun değilseniz, düzenlediğiniz dosyaları eski hallerine getirip kaydederek konfigürasyonların eksisi gibi kalmasını sağlayabilirsiniz.