# 20- Servislerin Yönetimi

[https://www.google.com/search?q=systemd+golinuxcloud.com&ei=DtDzYe2CB-GXxc8P6oyV8AQ&ved=0ahUKEwjtwa3LqNT1AhXhS_EDHWpGBU4Q4dUDCA4&uact=5&oq=systemd+golinuxcloud.com&gs_lcp=Cgdnd3Mtd2l6EAM6BQgAEM0CSgQIQRgBSgQIRhgAUM8FWIAmYMIqaAFwAHgAgAHwAYgB2AaSAQUwLjQuMZgBAKABAcABAQ&sclient=gws-wiz](https://www.google.com/search?q=systemd+golinuxcloud.com&ei=DtDzYe2CB-GXxc8P6oyV8AQ&ved=0ahUKEwjtwa3LqNT1AhXhS_EDHWpGBU4Q4dUDCA4&uact=5&oq=systemd+golinuxcloud.com&gs_lcp=Cgdnd3Mtd2l6EAM6BQgAEM0CSgQIQRgBSgQIRhgAUM8FWIAmYMIqaAFwAHgAgAHwAYgB2AaSAQUwLjQuMZgBAKABAcABAQ&sclient=gws-wiz)

systemctl show komutu ilgili birimin hangi seçenekleri alabileceğini gösteriyor. systemctl show vsftpd.service kullanıyorsanız, bu belirli birime uygulanabilecek uzun bir parametre listesi gösteriyor. Ve gördüğünüz gibi, birçok şey mümkün. Ve bu farklı seçenekleri ayarlayarak, bu birimin çalışması gereken ortamı tam olarak çok dikkatli bir şekilde şekillendirebilirsiniz ve bu, belirli zaman aşımları ve başlangıç parametreleri ayarlayabileceğiniz anlamına gelebilir, ancak aynı zamanda kaynak tahsisine sınırlamalar da getirebilirsiniz. Bu, bu kursta öğrenmemiz gereken şey için çok ileri gidiyor, ancak burada gördüğünüz seçeneklerle çok ileri gidebileceğinizi bilmenizi istiyorum.

Her zaman olduğu gibi öncelikle temel kavramları açıklayarak başlayalım. Bu sayede anlatımın devamında ele alacağımız konular çok daha anlaşılır olacaktır. 

Eğer daha önce Linux ile ilgilendiyseniz muhtemelen servisleri ve belki de daemon kavramını duymuşsunuzdur. Öncelikle daemon kavramından kısaca bahsedecek olursak;

En genel tanımla daemon kavramı; otomatik başlatılan, arka planda çalışıp kullanıcı ile doğrudan interaktif iletişimde bulunmasına gerek olmayan, sürekli çalışan programlardır. Daemonlar genelde bir olayı beklerler ve o olay olduğunda ona cevap olarak çeşitli görevleri yerine getirirler. Bu sebeple sürekli çalışır ve kullanıcıların doğrudan etkileşimine ihtiyaç duymazlar. Yani burada daemon olarak geçen işlemler doğrudan kullanıcıların etkileşimine ihtiyaç duymadan arkaplanda çalışıp sistemi sürekli olarak izleyerek sistemin işleyişi için gerekli olan görevlerini yerine getirirler. Esasen daemon kavramı bu genellemenin dışında çok daha ayrıntılı bir konu ancak bizim için bu detay seviyesi şu anlık yeterli.

Tek bilmemiz gereken daemonların yönetimi için kullanıcıların terminal üzerinden müdahalesine ihtiyaç duymadan tanımlı oldukları doğrultuda kendi işlerine baktıklarıdır. 

Daemonların başlatılması için doğrudan konsol üzerinden kullanıcıların etkileşimine ihtiyaç yoktur. Doğru şekilde ayarlandığında sistem başlangıcında otomatik olarak başlatılır ve sistem kapanana kadar sürekli olarak çalışarak görevlerini yerine getirirler. Sistem başlangıcında sistem için gerekli olan çeşitli işlemlerin başlatılmasından da init yazılımı sorumludur. Günümüze kadar pek çok farklı init yazılımı geliştirilmiştir ancak günümüzde en yaygın kabul gören init yazılımı "systemd" dir.

Deamon yazılımlarının konsol etkileşimine ihtiyaç duymadığını kanıtlamak için dilersek herahngi bir deamon ın işlem numarası üzerinden dosya tanımlayıcı tablosuna göz atabiliriz. Örneğin systemd yazılımı da çekirdek tarafından başlatılan bir daemondur. İşlem numarası da 1 dir. ls -l /proc/1/fd komutu ile bu daemonunun dosya tanımlaycıı tablosunu listediğimizde stdin stdout ve stderr çıktılarının bir yere bağlı olmadığını görebiliriz. Bağlı değil çünkü bu bir daemon yani konsoldan bağımsız şekilde çalışabildiği standart girdilerini veya çıktılarını konsola bağlaması gerekmiyor. 

Systemd yalnzıca basit bir örnek. 

Systemd yazılımı sistemin başlatılmasını sağlamasının yanında ayrıca sistemi ve servisleri kolayca yönetebileceğimiz çeşitli araçları da sağlıyor. İlk başlatılan işlemin systemd olduğunu teyit edebilmek için pstree komutunu kullanabiliriz. Bakın systemd ilk başlatılan işlem ve onun altında diğer işlemler başlatılmış. 

Durumu özetlemek gerekise, çekirdek ilk işlem olan init i yani bizim durumuzda systemd yazılımını daemon olarak başlatıyor. Daha sonra diğer işlemler systemd nin çatallanıp çalıştırılması ile oluşturuluyor. Neticede sistemin açılması ve daha sonra doğru şekilde çalışması için gerekli olan çeşitli yapılar systemd tarafından otomatik olarak başlatılıyor. Ayrıca systemd başlatılacak işlemleri konfigüre etmemiz ve başlatıldıktan sonra da ihtiyaçlar doğrultusunda yönetebilmemize de imkan sağlıyor. Yani sistemin doğru şekilde başlatılması ve daha sonrasında yönetilebilmesi noktasında bize çözümler sunuyor. 

Bu açıklamaların ardından neden birden fazla init yazılımı olduğu ve yeni dağıtımların neden systemd yi tercih ettiğini merak etmiş olabilirsiniz. 

Bu soruya yanıt vermek için diğer init yazılımlarından da kısaca bahsetmemiz gerekiyor.

Söz konusu init işlemi olduğunda tarihi sırasıyla sysVinit upstart ve systemd yazılımları yaygın olarak pek çok dağıtımda kullanılmışlardır. Şimdi neden daha yeni init yazılımlara ihtiyaç duyulduğunu anlamak için bu yazılımları tanıyarak aralarındaki farklardan bahsedelim. Tarihi sıraya uyarak sysvinit ile başlayabiliriz.

## sysVinit

sysVinit yazılımı 1980'lerin başında Unix sisteminin bir sürümü olan 'UNIX System V' için oluşturulmuş bir başlatma yazılımıdır. Daha sonraları birtakım özelleştirmeler neticesinde Linux üzerinde de kullanılmaya başlanmıştır. Geçmişte pek çok dağıtım oldukça uzun bir süre başlatma işlemleri için bu yazılımı kullanmıştır. 

Bu yazılım, kullanıcıların ihtiyaçlarına yönelik olarak başlatılacak servislerin ve işlemlerin gruplanmabilmesini sağlayan runlevel yani çalışma seviyesi yaklaşımını sunmuştur. Bu sayede sistem hangi amaçla kullanılacaksa o amaca yönelik gerekli servislerin başlatılması sağlanarak kaynakların verimli şekilde yönetilebilmesi mümkün olmuştur. 

Örneğin grafiksel arayüze ihtiyacımız yoksa grafiksel arayüz için gerekli olan servislerin ve işlemlerin başlatılmasına da gerek yoktur. Bu doğrultuda grafiksel arayüzün olmadığı yani grafiksel arayüz için gereken servis ve işlemlerin otomatik olarak başlatılmadığı çalışma seviyesini seçebiliriz. İşte bu ve bunun gibin farklı durumlar için servisler çalışma seviyeleri adı altında gruplanmıştır. Bizler duruma göre ihtiyacımıza uygun olan çalışma seviyesini seçerek ilgili seviyedeki servislerin otomatik olarak başlatılmasını sağlayabiliyoruz.

Sistemin uygun şekilde istenilen çalışma seviyesinde açılmasını sağladığı için sysVinit gerçekten oldukça kullanışlıdır. Ancak maalesef bu yazılım statik bir ortamda çalışmak üzere tasarlanmıştır. Yani örneğin sistem çalışırken USB flash diskinizi bilgisayara takarsanız bu disk bu init yazılımı tarafından tanınmaz. Dolayısıyla usb aygıtı ile ilişki bir servis varsa bu servis çalıştırılamaz. Çünkü bu init yazılımı tüm servisleri önceden tanımlanmış oldukları sırasına uygun şekilde sistem başlangıcında başlatır. Sistem başlangıcında usb diski takmadığınız için bu aygıt daha sonra takıldığında tanınmaz. 

Ayrıca başlatma işlemi sırasında başlatılacak servisler için yürütülen komut dosyalarının hepsi sırasıyla tek tek çalıştırıldığı için bir tanesi hata verirse veya herhangi bir nedenle duraklarsa sonraki çalıştırılacak tüm komut dosyaları da bu işlem sona erene ya da zaman aşımına uğrayana kadar bekletilir. Elbette bu yaklaşım dolayısıyla sistemi başlatma işlemi günümüzdeki init yazılımlarına oranla kesinlikle çok daha verimsiz ve yavaştır. 

SysVinit başlatma yazılımı kullanıldığı döneme göre faydalı olsa da zaman içinde yerine alacak daha kullanışlı bir yazılıma da ihtiyaç duyulmuştur. Çözüm olarak da upstart yazılımı geliştirilmiştir. Şimdi anlatımlarımıza upstart yazılımından bahsederek devam edebiliriz.

## Upstart

Upstart yazılımı sysVinit in sahip olduğu dezavantajları gidermek adına statik ortamda çalışmak yerine dinamik ortamda çalışabilecek yapıda tasarlanmıştır. Upstart yazılımın avantajı, olay tabanlı hizmet yönetimi ve çöken hizmetlerin otomatik olarak yeniden başlatılması gibi özellikleridir.

Kısaca açıklamamız gerekirse, olay tabanlı hizmet yönetimi demek yalnızca sistem başlangıcında kullanılan çalışma seviyesindeki servislere bağlı kalmadan mevcut sistem üzerindeki olayların değişikliğinin takip ediliyor olmasıdır. Yani upstart yazılımı dinamik olarak sistem üzerindeki değişikliklere göre hizmetleri durdurup yeni hizmetleri başlatabiliyor. Daha önceki örneğimizden devam edecek olursak upstart yazılımının çalıştığı sistemde usb flash diskinizi sisteminize bağlarsanız diskiniz tanınıyor olacak. Çünkü upstart, sistem üzerindeki bu aygıt değişikliği doğrultusunda ilgili servisin başlatılarak usb aygıtın tanınmasını sağlayacaktır. İşte bahsi geçen olay tabanlı yaklaşım bu örnekte olduğu gibi sistem üzerindeki değişikliklere göre hareket etme yani dinamik olma durumunu tanımlıyor. Bir örnek daha vermemiz gerekirse; örneğin bir servis beklenmedik şekilde kapanırsa olay takibi yapıldığı için otomatik olarak ilgili servisin yeniden başlatılması da sağlanır mutlaka. 

Elbette tüm özelliklerin bahsetmedik ancak, özellikleri bakımından ele alındığında aslında upstart yazılımının sysVinit yazılımının dezavantajlarını kapatan bir alternatif olduğu söylenebilir. Yani aslında başlı başına modern bir init yazılımı değildir çünkü ekstra özellik sunma konusunda bir atılım yapmamıştır. Elbette daha yeni bir çözüm sunulana kadar sysVinit yerine yaygın olarak pek çok dağıtımda upstart yazılımı uzunca bir süre kullanıldı. Çünkü kesinlikle daha işlevseldi. Günümüzde ise yaygın kullanıma sahip dağıtımlar, upstart yazılımını daha yeni çözümler ve yaklaşımlar sunan systemd yazılımıyla değiştirmiştir. Şimdi anlatımlarımıza systemd yazılımından bahsederek devam edebiliriz.

# systemd

Anlatımlara başlamadan önce, bu eğitimde systemd yi tüm yönleriyle ele almamın mümkün olmadığını belirtmem gerekiyor. Eğer tüm yönleriyle ele almaya çalışırsak hem temel seviye eğitimin dışına çıkmış olacağız hem de en az tüm bu eğitim uzunluğunda ek bir anlatım daha gerçekleştirmemiz gerekecek. Ayrıca systemd durmaksızın geliştirilen yeni özellikleriyle kapsamını genişlemeye devam ettiği için temel konseptler dışındaki tüm ek özellikleri bizzat kendimizin takip edip öğrenmesi gerekiyor. Eğer manuel sayfalarındaki systemd ya da systemd.unit gibi dokümanlara göz atacak olursak aslında ne kadar kapsamlı bir araç olduğunu kendimiz de birinci elden deneyimleyebiliriz. Örneğin man systemd.unit komutunu girip bir manuel sayfalarına göz atalım. Bakın space ile sayfalar arasında atlayarak dokümanın uzunluğuna bizzat tanık oluyoruz. Ayrıca buradaki pek çok anlatım aslında özet halinde. Yani buradaki kavramların doğru şekilde anlaşılabilmesi için ilgili konularla ilişkili olan gerekli altyapıya da sahip olmak gerekiyor. Ancak merak etmeyin temel seviyede tanıdıktan sonra daha derinlemesine öğrenmek için başlangıç noktasına sahip olacaksınız. Yani ben çok temel düzeyden bahsedeceğim ancak sizler sahip olduğunuz temel bilgiler üzerinden yola çıkarak zaman içinde daha derinlemesine bilgi edinebiliyor olacaksınız. Eğer istemeden de olsa gözünüzü korkuttuysam hiç endişelenmeyin. Systemd yi temele düzeyde anlamak ve yönetmek son derece kolay. Eğer sırasına uygun şekilde ilerlersek temel düzeyde işleyiş hakkında bilgi sahibi olabiliriz. Temelin dışındaki konular ve özellikler de spesifik durumlar kullanıldığı için ihtiyaç halinde araştırıp kullanabileceğiniz türden bilgilerdir. Lafı daha fazla uzatmandan devam edelim.

[https://www.section.io/engineering-education/understanding-systemd/](https://www.section.io/engineering-education/understanding-systemd/)

Daha önce kısaca bahsettiğimiz init yazılımlarına oranla systemd yazılımı kısaca bahsedemeyeceğimiz kadar çok şeyle meşgul oluyor. Systemd yazılımı önceki alternatif init yazımlarından farklı olarak servisleri paralel olarak başlatılmaya zorladığı için çok daha hızlı bir sistem açılışı sağlıyor. Belki standart kullanıcılar için sistem açılışındaki servisinlerin paralel olarak başlatılması çok önemli bir özellik gibi gelmeyebilir. Ancak bu durum özellikle sistem açılışında çok sayıda servisi başlatan büyük sistemler için hız açısında büyük bir avantaj sağlıyor. Systemd üzerindeki paralelliğin nasıl çalıştığının teknik detayları şu an için önemsiz.

[https://uace.github.io/learning/init-vs-systemd-what-is-an-init-daemon](https://uace.github.io/learning/init-vs-systemd-what-is-an-init-daemon)

En genel tanımıyla systemd, servis ve sistem yöneticisidir. Servislerden, sisteme bağlı bulunan aygıtlara ve log kayıtlarına kadar sistemin birçok farklı bileşenini yönetmek için kullanıyor. Faydalı bulunduğu için sahip olduğu yaygınlıkla birlikte, her işle ilgilenmeye çalışması unix felsefesiyle ters düştüğü için systemd topluluk tarafından pek hoş karşılanmamıştır aslında.

Unix felsefesi gereği bir aracın mümkünse tek bir işi en iyi şekilde yerine getirmesi ve her iş için ayrı ayrı tekil araçlar bulunması gerekiyor. Bu sayede hiç kimse ihtiyacı olmayan özellikleri barındıran araçların gereksiz yükü ile uğraşmak zorunda kalmıyor. Bu felsefeden daha önce de bahsettik. Söz konusu GNU/Linux'un sağladığı özgürlük olduğunda bu felsefeye bağlı kalmayan araçların tartışmalara sebep olması çok doğal.

Ayrıca önceki alternatif init yazılımları kabuk dosyaları üzerinden kullanırken systemd doğrudan müdahalenin mümkün olmadığı binary yani ikili dosyaları kullanıyor. Yalnızca bazı konfigürasyonların kullanıcı tarafından yapılabilmesine imkan tanıyor. Yani hem her şeyle ilgilenmeye çalışması hem de ikili dosyalarla kısıtlanan müdahale özgürlüğünden dolayı systemd yi sevmeyen ve kullanımını reddeden pek çok kullanıcı var. Yine de verimli şekilde çalıştığı için pek çok dağıtımda varsayılan servis yöneticisi olarak artık systemd kullanılıyor. Bu bağlamda bizler de pragmatik olabilmek adına tartışmaları bir kenara bırakarak temel olarak bilmemiz gerekenlerden bahsediyor olacağız. Eğer systemd hakkındaki tartışmaları merak ediyorsanız, kısa bir araştırma ile internet üzerinde pek çok kıyaslama ve tartışmaya kolaylıkla ulaşabilirsiniz. 

Biz şimdi en genel haliyle fikir sahibi olmak adına buradaki diyagrama göz atabiliriz. Bakın buradaki diyagram systemd yapısının özeti. Biliyorum şuanda buradaki görsel yani aslında bu yapılar sizin için hiç bir anlam ifade etmiyor. Ancak merak etmeyin bölüm sonunda bu diyagram hepimiz için çok daha anlamlı bir hale bürünmüş olacak. 

![Untitled](20-%20Servislerin%20Yo%CC%88netimi%2026d53a1004af4dd3af2c22533b9977a5/Untitled.png)

Ben öncelikle bu diyagramdaki yapıları kısaca özetlemek, daha sonra sırasıyla biraz daha ayrıntılı ve uygulamalı şekilde ele almak istiyorum. Bu sayede bütünleşik olarak systemd yapısını çok daha net kavrayabileceğiz.

Systemd daemons olarak geçen kısım, farklı görevlerdeki çeşitli servislerin temsil edildiği bölümdür. Buradaki daemonların yönetilebilmesi için de buradaki utilites olarak geçen yardımcı programlar kullanılıyor. Örneğin systemd daemonunu yönetmek için systemctl yardımcı aracını kullanıyorken, log tutan journald servisi için journalctl yardımcı aracını kullanabiliyoruz. Yani bu yardımcı araçlar ilgili servislerin kullanıcılar tarafından yönetilebilmesine olanak tanıyan araçlardır.

Burada targets olarak geçen bölüm ise, daha önce açıkladığımız çalışma seviyeleri ile benzer bir yapıdır. Target yapısı sayesinde çeşitli servisler gruplanarak, farklı ihtiyaçlara çözüm sunan bir çalışma ortamı sağlanabiliyor. Örneğin grafiksel arayüzlü bir çalışma ortamı istiyorsanız, sisteminizi bu ortamı sağlayacak olan servislerin ortak olarak sunulduğu grafiksel arayüz target ında başlatmanız yeterlidir. 

Core olarak geçen kısım ise, systemd yazılımının yönettiği çeşitli birimleri temsil ediyor. Systemd sistem üzerindeki pek çok yapının yönetimine müdahil olduğu için görebildiğiniz gibi pek çok birim var. Örneğin servisler, aygıtların bağlantısı, oturum açmayla ilgili servisler loglar ve benzeri pek çok birim systemd kontrolü altındadır. Bunlar systemd daemonu kapsamında olduğu için de bu yapıları da systemctl yardımcı aracı ile kontrol edebiliyoruz.

Kütüphane ve çekirdek kısmi ise, systemd nin çalışması ve çekirdek ile iletişim kurması için gerekli olan kütüphane dosyaları ve kullanılan çekirdek özelliklerini temsil ediyor. 

Biliyorum şu an için bu kısa açıklamalar hala pek bir anlam ifade etmiyor, ancak merak etmeyin yeri geldikçe biraz daha ayrıntılı şekilde bahsediyor olacağız. Bu kısa açıklamaların ardından, bence systemd nin çalışma biçimini daha net anlayabilmek adına öncelikle unit kavramı üzerinde durmamız gerekiyor. 

İngilizcede unit ifadesi birim anlamına geliyor. Systemd yazılımı da kontrol ettiği çeşitli nesneleri birim yani unit olarak isimlendiriyor. Burada nesne diyorum çünkü birim yani unit kavramı systemd altındaki çeşitli hizmetleri ortak olarak temsil ediyor. Farklı görevleri olan hizmetlerin hepsini yönetmek için onlara ortak olarak nesne gibi bakarak hizmetlerin hepsini tek bir noktadan yani systemd üzerinden unit adı altında yönetiyor. 

Buradaki tabloda da aşağı yukarı gözüktüğü gibi farklı türdeki birimler zaten farklı gruplar halinde ayrıştırılmıştır. Bu durumdan bahsedeceğiz. Belki buradaki systemd ve unit kavramları şu an için pek anlaşılır olmayabilir. Ancak endişelenmeyin. Aslında temelde systemd pek çok farklı görevi yerine getirmek için unit olarak anılan farklı birimleri kullanıyor. Bu birim tiplerinden bahsederek devam edebiliriz. Ben şimdi genel bir liste şeklinde birimlerin tiplerinden bahsetmeye çalışacağım ancak bu tablodaki tüm birim tipleri tüm sistemlerde bulunmuyor olabilir. Öncelikle birim tiplerinden bahsedelim daha sonra mevcut sistemimizde hangilerinin kullanılabilir olduğunu konsol üzerinden kontrol ederiz.

Aslında birimlerin isimleri birimlerin işlevleri hakkında doğrudan bilgi sunuyor. Ancak biz yine de kısaca açıklayacak olursak:

**Service:** Servis olarak geçen birim, bir veya birden fazla daemon yani arkaplan işleminin aynı ortak amaçla kullanılmasıdır. Servis, özel bir hizmeti yerine getirmek için kullanılan bir birimdir yani.

Socket: Soketler kısaca bir servisin veya işlemin yerel veya uzak sistemde çalışan servis veya işlemler ile iletişim kurmak için kullandığı iletişim kanalıdır. 

Device: İsminden de anlaşılabileceği gibi aygıtlarla ilgili olan birimdir.

Mount: ve Automount: Systemd tarafından kontrol edilen dosyas sistemlerinin bağlantı noktalarına ait bilgileri tutan birimlerdir. 

Swap: Bu birim, sistemdeki takas bölümleri hakkında bilgi içerir.

Path: Bu birim, dosyaları/dizinleri izler ve belirtilen dosya veya dizine erişilirse belirtilmiş olan bir hizmeti etkinleştirir veya devre dışı bırakır.

Timer: Zamana bağlı olarak ayarlanmış olan servisleri etkinleştirir veya devredışı bırakır. Eğer daha önce zamanlanmış görevler için cron kullanıdıysanız, timer da cron un yerine alması için systemd tarafından sunulan çözümdür.

Snapshot: Çalışmakta olan mevcut birimlerin durumunu kaydedip daha sonra geri yüklenerek aynen kullanılmaya devam edebilmelerini sağlıyor. Ancak yalnızca mevcut oturumdaki kayıtlardan geri dönüş sağlanabilir. Snapshot mantığını sanallaştırma yazılımlarından da mutlaka duymuşsunuzdur. Buradaki snapshot yalnızca mevcut oturumda çalışan birimleri kapsayan geçici bir kayıttır.

Slice: CPU ve bellek gibi sistem kaynaklarını yöneten birimdir. 

Scope: Harici olarak oluşturulan sistem işlem kümelerini yönetmek için kullanılan birimdir.

Bu genel tanımlamaların ardından mevcut sistemimizde bulunan tüm aktif birimleri listelemek için systemctl list-units —all şeklinde komut girebiliriz. Buradaki systemctl aracı systemd yi yönetmek için kullandığımız yardımcı bir araçtır. Bu aracın genel kullanımı systemctl komutunun ardından kullanılacak özellik ve özelliğin parametresi şeklindedir. Ben list-units ile mevcut sistemdeki aktif birimlerin listelenmesini söylüyorum. —all seçeneği ile de herhangi bir filtreleme yapılmadan tüm birimlerin listelenmesi gerektiğini belirtmiş oluyorum.

Evet birimlerin listesi karşımıza geldi. Bakın burada birimlerin isimleri ve isimlerinin sonunda da ilgili birimi temsil eden uzantısı bulunuyor. Örneğin device birimlerinin isimlerinin hepsinin sonunda .device ifadesi yer alıyor. Hepsi konsol ekranına sığmadığı için diğer birimlere de göz atmak üzere space tuşu ile diğer sayfalara geçiş yapabiliriz. Bakın listeyi kaydırdıkça mount path scope ve servis gibi uzantıları yani aslında birim türlerini görebiliyoruz.

Bizzat listeye bakarak teyit edebildiğimiz gibi systemd, yönetim için pek çok farklı birime sahip. Systemd bu birimleri yönetirken de aslında bu birimlerle ilişkili olan dosyalara bakarak ne yapması gerektiğini öğreniyor. Bu doğrultuda birimlerin nasıl çalışacağını bizler ilgili dosyalar üzerinden konfigüre edebiliyoruz. Birim dosyalarından tekrar bahsedeceğiz. Şimdi kısaca aldığımız çıktıdaki sütunları ele alalım. Ben çıktıların sadeleştirilmesi için ve anlatımlar sırasında servislere odaklanmak istediğim için yalnızca servisleri listelemek üzere en son girdiğim komuta ek olarak —type=service ifadesini ekleyerek birimleri yalnızca servisler olacak şekilde filtreliyorum. 

Aldığımız çıktılardaki ilk sütun elbette ilgili birimin ismidir. İkinci sütun bu birimin konfigürasyon dosyasının durumunu belirtiyor. Bakın bazıları loaded iken bazıları not-found şeklinde gözüküyor. Eğer ilgili birimin konfigürasyon dosyası systemd tarafından sorunsuzca okunduysa ve işleme alındıysa loaded şeklinde gözüküyorken, bulunmadığında veya okunamadığında not-found şeklinde gözüküyor. Üçüncü sütun ise ilgili birimin aktif veya pasif olma durumunu belirtiyor. Dördüncü sütunda ise bu birimin alt durumu hakkında bilgi alabiliyoruz. Görebildiğiniz gibi aktif olan birimlerin birbirinden farklı alt durumları bulunuyor. Bunlar spesifik olarak ilgili birimin en son durumu hakkında bilgi sunuyor. Tüm durumlar şu anda çıktılarda gözükmüyor ancak karşılaşabileceğimiz durum çıktılarını kısaca açıklayabiliriz.

Örneğin birim aktif ve running yani çalışma durumunda ise; ilgili birimin konfigürasyonu başarıla çalıştırılmış ve halihazırda bu birimle ilişkili olan bir veya birden fazla aktif işlemin de çalışmakta olduğunu belirtiliyor.

Eğer waiting durumunda ise; ilgili birimin konfigürasyonu başarıla çalıştırılmış ve birimin şu anda bir olayın gerçekleşmesi için beklediği anlamına gelir.

Birim exited durumunda ise; ilgili birimin konfigürasyonu başarıla çalıştırılmış ve işini bitirmiş demek oluyor. Yani bu durum, halihazırda aktif olarak bir işlem çalıştırılmıyor ya da bir olay beklenmiyor anlamına geliyor.

Bunun dışında eğer birim dead durumunda ise birimin konfigürasyonunun yürütülemediği veya henüz yürütülmediği anlamına geliyor. Yani ilgili birim aktifleştirilirken bir sorun çıkmış da olabilir ya da ilgili birim zaten aktifleştirilmemiş de olabilir. Neticede birimin çalıştırılmadığını ve aktif olmadığını belirten durumdur. Bir birim çalışıp işini tamamladığında zaten exited alt durumu çıktılarda gözüküyor.

Servislerin durum açıklamaları bu kadar. Burada dikkat etmenizi istediğim detay elbette buradaki durum açıklamalarının servis birimleri özelindeki açıklamalar olduğudur. Farklı birim tiplerinde bu durumlar da farklı şekillerde olacaktır. Örneğin servisler yerine —type=device komutunu girip aygıtlar ile ilgili olan birimleri filtreleyerek çıktılara bakabiliriz . Servis birimlerinden farklı olarak burada aygıt birimleri için plugged şeklinde bir durum belirtilmiş gördüğünüz gibi. Device birimi aygıtlar ile ilgili olduğu için bu doğrultuda durum çıktıları gösteriliyor. Diğer tüm birim türleri de kendi içlerinde özel durum ifadelerine sahip. Ben servisler üzerinden ilerleyeceğim için tüm birimlerin açıklamalarını tek tek ele almayacağım. Zaten söylediğim gibi her birimin kendine has durum çıktıları olduğunu bilmeniz yeterli. Eğer farklı birimlerin durum çıktılarının ne anlama geldiğini bilmiyorsanız kısaca internet üzerinde araştırma yapabilir ya da resmi doküman kaynağına göz atabilirsiniz. 

Tüm bu durum çıktıları dışında sondaki sütun ise ilgili birimin kısa açıklamasını içeriyor. Eğer konsol ekranınız küçük ise bu son sütun tam olarak gözükmüyor olabilir. Konsol penceresini genişletebilir yada komut satırı çıktılarını küçültüp çıktılara göz atabilirsiniz. Buradan birimlerin işlevi hakkında kısaca bilgi edinebiliyoruz. Herhangi bir birimin işlevini hatırlamakta güçlük çektiğimizde buradaki kısa bilgilendirme sütunu oldukça kullanışlı olabiliyor. 

Biz bu çıktılarla birlikte birimlerin aktif ve pasif olma durumları hakkında bilgi aldık. Ancak aslında bu çıktılara tüm birimler yer almıyor olabilir. Çünkü bu çıktılar yalnızca systemd nin okuduğu veya okumaya çalıştığı birim dosyaları neticesindeki sonuçları listeliyor. Eğer systemd nin okuyup okumamış olmasına bakılmaksızın sistem üzerindeki tüm birim dosyalarını listelemek istersek systemctl komutundan sonra list-unit-files komutunu kullanabiliriz. Bu komut ile birimlerin konfigürasyon dosyalarının bulunduğu dizinlerin hepsine bakılıp dosya isimleri ve sistem başlangıcında otomatik olarak başlatılma durumları da listelenecek.

Bakın tüm birim dosyaları ve bu dosyaların sistem önyüklenirken tanımlı olan başlatılma durumları da konsola sırasıyla bastırıldı. Yine listeler arasında space tuşu ile sayfa sayfa ya da aşağı yukarı yön tuşları ile satır satır gezinebiliriz. 

Durumlar sütununda enabled disabled static ve masked şeklinde çeşitli durum tanımları bulunuyor. Buradaki çıktılar ilgili servisin sistem başlangıcındaki başlatılma durumunu temsil ediyor. Kısaca bu durumları izah etmemiz gerekirse;

Eğer bir birim enabled yani etkin haldeyse sistem başlangıcında bu birim dosyası okunarak gerekli işlemler başlatılır. 

Eğer disabled yani deaktif durumda ise o birimin konfigürasyon dosyası sistem başlangıcında okunmaz, dolayısıyla birim dosyasındaki ilgili konfigürasyonun işaret ettiği işlemler de uygulanmaz. Ancak bir birim sistem başlangıcında otomatik olarak başlatılmıyor olsa da yani disabled durumunda olsa da bizler sistem açıldıktan sonra ilgili birimi çalıştırabiliriz. Ya da başka bir birimin bağımlılığı ise, gerektiğinde o birim tarafından da otomatik olarak başlatılabilir.

Static durumu ise, ilgili birimin konfigürasyon dosyasında bu dosyanın yükleneceği şartı belirten bölümün olmadığı anlamına geliyor. Normalde tüm birimlerin konfigürasyon dosyalarının içinde mevcut birimin hangi durumda yüklenip hangisinde yüklenmeyeceği gibi bilgiler özellikle belirtiliyor. İşte belirtilmediğinde de bu birim dosyası için sistem başlangıcında bir işlem uygulanmıyor. Bu tür birim dosyaları yalnızca başka birim dosyalarının bağımlılığı olarak kullanılan birim dosyalarıdır. Yani başka bir birim dosyası bu birimin çalışması için atıfta bulunduğunda bu birim otomatik olarak çalıştırılıyor. Biliyorum şu an ne demek istediğim net anlaşılmadı. Çünkü henüz bir konfigürasyon dosyasının içeriğinin neye benzediğinden bahsetmedik. Dosya içeriklerinden bahsederken tekrar bu konu üzerinde duracağız merak etmeyin.

Masked durumu ise ilgili birimin sistem başlangıcında veya başlatıldıktan sonra manuel olarak başlatılamayacağı anlamına geliyor. Belki disabled ile masked durumu birbirine yakın olduğu için karıştırılabilir. O yüzden kısaca tekrar etmemiz gerekirse;

Normalde biraz önce belirttiğimiz şekilde disabled durumu, ilgili birimin sistem başlangıcında başlatılmayacağı ancak sistem açıldıktan sonra kullanıcı isteği doğrultusunda başlatılabileceği anlamına geliyor. Mask durumu ise ilgili birimin mask durumu ortadan kalkmadıkça başlatılamamasına sebep oluyor. 

Buradaki tanımların daha net anlaşılabilmesi için birim konfigürasyon dosyalarından bahsetmemiz gerekiyor. 

## Konfigürasyon Dosyaları

Systemd nin birimler üzerinden yönetim sağladığından, birimlerin de çeşitli konfigürasyon dosyaları ile tanımlandıklarından bahsettik. Birim dosyalarının hangilerinin geçerli olacağı belirlenirken öncelik sıralamasına göre bakılan üç dizin vardır. Örneğin ilk olarak özel bir konfigürasyon tanımlanmış mı diye bakılır, eğer özel konfigürasyon dosyası yoksa sistem çalışırken oluşturulmuş olan konfigürasyon dosyalarına bakılır, eğer onlar da ilgili dizinde yoksa en sonra varsayılan olarak yüklenmiş olan standart birim dosyalarının bulunduğu dizine bakılır. Kısaca bu üç dizinin işlevini açıklamamız gerekirse;

Sistemde varsayılan olarak yüklü bulunan veya harici olarak yeni yüklenmiş olan paketlerle birlikte gelen birim konfigürasyon dosyaları /lib/systemd/system dizini içinde tutuluyor. Hemen dizin içeriğini detaylıca listeleyebilmek adına ls -l /lib/systemd/system/ şeklinde komutumuzu girelim. Bakın pek çok konfigürasyon dosyası listelendi. Ve dosyalarının sonunda da ilgili birimlerin uzantıları yer alıyor. Dosya içeriklerine daha sonra göz atacağız. Burada dikkatinizi çekmek istediğim detay bu dizinin birim dosyalarının varsayılan konfigürasyon dosyalarının bulunduğu yegane dizin olduğudur. Bu dizin sayesinde gerektiğinde bozduğumuz konfigürasyon dosyalarının ilk hallerine kolayca ulaşabiliyoruz. Zaten varsayılan dizin olduğu için buradaki dizinde çok fazla birim dosyası yer alıyor.

Buradaki birim dosyaları varsayılan dosyalar olduğu için gerekmedikçe bu dizindeki dosyalar üzerinde değişiklik yapmamamız gerekiyor. Buradaki dosyaları referans olarak kullanıp biraz sonra bahsedeceğimiz diğer dizinlere kopyaladıktan sonra düzenleyip kullanmak çok daha mantıklıdır. Zaten bu dizine en son bakıldığı için gerekli değişiklikleri diğer dizinler üzerinden gerçekleştirmek çok daha doğru olacaktır. 

Varsayılan dizine bakılmadan önce sistem çalışırken geçici olarak oluşturulan ve kullanılan birim dosyaların bulunduğu /run/systemd/system dizininde bakılıyor. Bu sayede varsayılan konfigürasyonlardan daha farklı bir konfigürasyon tanımlı ise bu dizinde yer alan dosyalar sayesinde fark edilebiliyor. Hemen yine içeriğini ls -l /run/systemd/system/ komutu ile listeleyelim. Bakın burada bir önceki varsayılan dizinde olduğu kadar çok dosya bulunmuyor. Çünkü burası sistem çalışırken oluşturulan geçici konfigürasyon dosyalarının dizini. Bu dizinde yer alan bir konfigürasyon dosyası olduğunda varsayılan dizin olan /lib/systemd/system/ dizinin ilgili birim için tekrar araştırma yapılmıyor. Bu dizindeki dosyalar mevcut sistem çalışırken oluşturulan geçici konfigürasyon dosyaları olduğu için bu dizindeki dosyalar sistem yeniden başlatıldığında sıfırlanıyor. Dolayısıyla eğer bizler varsayılan konfigürasyonlardan farklı bir konfigürasyon tanımlamak istiyorsak bunları kalıcı ve ilk olarak bakılan bir dizinde gerçekleştirmemiz gerekiyor. İşte bu dizin de /etc/systemd/system/ dizinidir. Bu dizin altındaki tüm dosyalar daha önce bahsettiğimiz dizinlerden önce okunur dolayısıyla eğer bu dizinde bir birimin konfigürasyon dosyası bulunuyorsa bu konfigürasyon geçerli olur. Bu dizine de sisteme özgü yani özellştirilmiş konfigürasyonların dizini diyebiliriz. Bu dizin içeriğini de hemen listeleyelim. Bakın varsayılan dizin kadar olmasa da bu dizinde de birçok konfigürasyon dosyası bulunuyor.

İşte bizler de gerektiğinde yeni birim dosyaları oluşturmak için veya var olan birim dosyalarını yeniden konfigüre etmek için bu dizini kullanıyor olacağız. 

Buradaki konfigürsayon dosyalarının kullanımında yalnızca öncelikli olan konfigürasyon dosyası mevcut değilse bir sonraki önceliğe sahip konfigürasyon dosyasına geçiliyor. Örneğin, bir birimin üç yapılandırma dosyasının tümü mevcutsa, yalnızca sisteme özgü birim yapılandırma dosyası kullanılır.

Bu kural sayesinde kullanıcılar kendi ihtiyaçlarına göre uygun konfigürasyon dosyasında değiliklik yapabiliyor.

Söz konusu bir birim konfigürasyon dosyasını değiştirmek olduğunda eğer varsayılan dizindeki konfigürasyon dosyasını düzenlerseniz, yedeğini almadığınız durumlarda varsayılan konfigürasyonun bozulmasına sebep olabilirsiniz. Ayrıca bu dizindeki değişiklikler paketler güncellendikçe yeniden üzerine yazılabilecek yapıda oldukları için önceden yaptığınız değişikliklerin yok olma ihtimali de vardır. Kısacası varsayılan dizini yalnızca referans alınacak ve hiç bir değişiklik yapmak istemediğimizde kullanılacak birim dosyaların bulunduğu bir dizin olarak kabul etmemiz gerekiyor. Eğer herhangi bir birim dosyasında değişiklik yapmak istiyorsak en kolay şekilde bu dizindeki dosyayı kopyalayıp etc dizini altındaki özelleştirilebilir olan dizine yapıştırabilir ve buradan düzenleme yapabiliriz. Bu sayede varsayılan olan dizin yerine ilk olarak bu etc dizine bakılacak ve yaptığımız değişiklikler geçerli olacaktır. Üstelik varsayılan birim dosyası da zarar görmeden yedekte beklemeye devam edecek. Eğer aklınıza run dizini altındaki konfigürasyon dosyası takıldıysa, bu dizindeki değişiklikler sistem yeniden başlatıldığında yok olduğu için uzun vadeli kullanım için tercih edeceğimiz bir dizin değildir. Dolayısıyla kalıcı olmasını istediğimiz değişiklikler olduğunda bu dizinde bir işimiz yok. Eğer geçici olacak bir konfigürasyon istiyorsanız, etc dizini altında bulunmayan birim dosyasını buraya ekleyip düzenleyebilirsiniz. Eğer aynı isimli bir birim konfigürasyon dosyası varsa bu run dizini altındakinin okunmayacağını unutmayın lütfen.

Systemd öncelikle etc daha sonra run daha en ise lib dizini altında ilgili birim dosyasını aratşrıyor ve bulduğu ilk dizindekini kullanıp diğerlerini görmezden geliyor. Bu doğrultuda ihtiyaçlarınıza yönelik olarak konfigürasyon dosyalarınızı düzenleyebilirsiniz.

Anlaşılır olması gayreti ile sanırım lafı biraz uzattım. Şimdi sıradan bir servis birim dosyasının içeriğine göz atarak servis konfigürasyonlarını daha yakından tanımaya çalışalım.

## systemd birim yapılandırma dosyalarının biçimi

Bir systemd birim yapılandırma dosyası, o birimi kontrol etmek için gerekli olan tüm bilgileri içermelidir. Örneğin birimi başlatan dosyanın yolu, birimden önce ve sonra başlaması gereken birimlerin adı, dokümantasyon konumu, bağımlılık bilgileri, çakışma bilgileri ve benzeri pek çok bilgiyi içermelidir. 

Somut bir örnek üzerinden yani var olan bir konfigürasyon dosyası üzerinden ortalama bir konfigürasyon dosyasının içeriği hakkında konuşabiliriz. Ben örnek olması için network-manager servisinin birim dosyasını ele almak istiyorum. Hangi dizindeki birim dosyasının bu servis için kullanıldığınız bilmiyor olabiliriz. Öğrenmek için birimlerin durumları hakkında bilgi sunan systemctl status komutunun ardından ilgili birimin ismini girmemiz yeterli. Systemd yazılımı yalnızca birimleri başlatmak veya kapatmak gibi temel görevlerden sorumlu değil. Aynı zamanda birimlerin durumunu da takip ederek bize birimlerin anlık durumları hakkında bilgi sunup gerektiğinde ilgili birimler üzerinde çeşitli işlemler yapıyor. Sürekli izleme yaptığı için de örneğin kapanan bir servis birimi systemd tarafından otomatik olarak başlatılabiliyor. Her neyse neticede birimlerin durumlarını systemctl status komutu ile kontrol edebiliyoruz. Buradaki status argümanı kendisinden sonra belirtilen birim dosyasının durumunu konsola bastırabilmemizi sağlıyor. 

Öncelikle bu servisin durumunu öğrenmek için systemclt status network-manager.service şeklinde komutumuzu girelim. Bakın aldığımız çıktıda bu birimin çalışma durumu ve diğer durum bilgileri de konsola bastırıldı. Ayrıca bakın burada bu birimin hangi konfigürasyon dosyası üzerinden yüklenmiş olduğu açıkça belirtiliyor. Systemd bu birimin konfigürasyon dosyasını bu dizindeki bu dosya üzerinden yüklemiş. Bu dizinin varsayılan birim dosyalarının bulunduğu dizin olduğunu biliyoruz. Yani aslında bu çıktıdan hem birim dosyasının tam dizini ve dosya adını öğrenirken hem de bu birimin varsayılan konfigürasyon ayarlarının kullanıldığını da görmüş olduk. Şimdi yeni bir konsol açalım ve bu dosyanın içeriğine de göz atalım. Ayrıca merak etmeyin buradaki durum çıktılarını da ele alıp açıklayacağız. Şimdi birim dosyasının içeriğine göz atmak için yeni açılan konsola nano /dizin adresi şeklinde komutumuzu girelim.

Evet dosyamız açıldı. Birim konfigürasyon dosyaları görebildiğiniz gibi ilk olarak “birim hakkında bilgi içeren unit bölümü” daha sonra birimin türü ve işlevlerinin tanımlandığı bölüm ve son olarak hangi durumda bu birimin otomatik olarak çalıştırılacağının tanımlandığı kurulum bölümü olmak üzere üç ana bölümden oluşuyor.

Üç bölümden oluşan bu genel şema dışında buradaki tüm ifadeler ilgili birimin konfigürasyon gereksinimlerine göre farklılık gösterebileceği için ben yalnızca servislerin genel konfigürasyonlarından bahsediyor olacağım.

Zaten konfigürasyon dosyaları ilgili birimi konfigüre etmek için tanımlandığından hepsinin aynı olmasını beklemek çok mantıksız. İlgili birimin neye ihtiyacı varsa ona özel konfigürasyon tanımlamaları olmak zorunda. Ancak temelde konfigürasyon dosyasının bir kullanım şeması bulunuyor. Açmış olduğumuz birim dosyasının hangi birime ait olduğu description tanımıyla belirtilmiş. Biz network manager servisinin birim dosyasını açtığımız için burada network manager yazıyor. Zaten daha önceki status komutunun çıktılara tekrar dönüp bakacak olursak, burada da ilgili servis birimin açıklaması olarak bu tanımın kullanıldığını görebiliyoruz.

Documentation tanımı ise isminden de anlaşılabileceği gibi mevcut birimin dokümantasyonuna işaret ediyor. Tekrar durum çıktılara dönüp bakarak dokümantasyon bilgisinin buradaki ile aynı olduğunu da görebiliyoruz.

Öncelikle birim yani unit bölümüne bakacak olursak. Burada mevcut birim hakkında temel bilgiler yer alıyor.

Install seçeneği de ilgili birimin çalıştıracağı target hakkında bilgi sunan kısımdır.

Kısaca buradaki konfigürasyonlardan bahsedebiliriz. Bakın birim bölümünde bu dosyanın hangi birimin konfigürasyonu olduğuna dair açıklama bulunuyor. Ben network manager servisine göz attığım için burada bu şekilde yazıyor. Zaten systemclt status komutunun çıktısında da bu açıklama görülebiliyor. Benzer şekilde bu birim hakkında dokümantasyon için nereye bakmamız gerektiği de documentatition satırında açıkça belirtilmiş. Ve bu konfigürasyon dosyasında belirtilen ifade aynen status komutunun çıktısında da görülebiliyor. Buradaki ifadeler zaten hangi amaçla tanımlama yapıldığı konusunda gayet açık. Burada asıl önemli olan wants after ve before gibi tanımların ne anlama geldiğinin farkında olmak. Elbette tüm temel tanımlamalar buradakilerden ibaret değil ancak şimdi buradakileri sırasıyla açıklayarak başlayabiliriz.

Wants ifadesinin karşında tanımlanmış olan birim veya birimler, mevcut birim çalıştırılırken başlatılmaya çalışılır. Eğer buradaki birimler başlatılamazsa mevcut birim yine de başlatılarak çalıştırılır. Buradaki birimlerin başlatılma işlemi mevcut birimin başlatılmasıyla aynı anda parelel olarak gerçekleştirilir. 

Buradaki yok ancak requires seçeneği kullanıldığında ise, wants seçeneğine benzer ancak çok daha katı bir şart belirtilmiş olur. Zaten wants ifadesi istemek anlamına geliyorken reqires çok daha katı olan gereklilik anlamına geliyor. Requires ifadesinin karşısında belirtilmiş olan birim veya birimler, mevcut birim ile aynı anda başlatılmaya çalışılır. Eğer başlatılmaya çalışılan birimlerden herhangi birisi hata verir veya başlamaz ise mevcut birim de başlatılamaz. Çünkü buradaki birimler reqires yani gereklilik diğer bir deyişle olmazsa olmaz olarak tanımlanmışlardır. Wants ve requires tanımlamaları mevcut birimin doğru şekilde çalışabilmesi için gerekli olan harici birimlerin de aktifleştirilmesinden yani aslında mevcut birimin bağımlılıklarından sorumlu tanımlamaları içeriyor. Genellikle şart olmadıkça requires seçeneği çok katı davrandığı için wants ile bağımlılıklar tanımlanıyor. Bu sayede bağımlılık olan bir birim başlatılamazsa dahi mevcut birim başlatılabilir. Mevcut birim dosyasında da gördüğümüz gibi zaten birimlerin bağımlılıkları genellikle wants ile tanımlanıyor.

Ayrıca BindsTo olarak geçen bir tanımlama daha bulunuyor. Bu tanımlama bağlı olan anlamına geliyor ve tıpkı requires gibi davranıp requires tanımından farklı olarak bağımlılık olarak tanımlanmış olan birim sona erdiğinde mevcut birimin de durmasına neden olur. Yani bağımlılıklar sorunsuzca başlatılmışsa, biri kapandığında mevcut birimin de sonlandırılmasına neden olur. Çünkü mevcut birimimizi bu bağımlılığı olan birime bağlamış oluyoruz. 

Benzer şekilde PartOf tanımlaması ile de karşılaşabilirsiniz. Bu tanımama parçası anlamına geliyor. Tıpkı requires gibi davranır. Ancak requires den farklı olarak burada belirten birim durduğunda veya yeniden başlatıldığında bu etkinin mevcut birimin üzerinde de uygulanmasını sağlar. Ancak buradaki partof olarak belirtilen servis mevcut servis başladığında otomatik olarak başlatılmıyor. Yalnızca durdurma veya yeniden başlatma sırasında etkili oluyor.

PartOf ile bindsto arasındaki fark, partof kullanılırken x servisinin başlatılması parof ile belirtilmiş olan y servisinin başlatılmasına neden olmuyor. Eğer y servisi bindsto ile belirtilmişse x servisi başladığında y servisi de başlatılıyor. 

Conflicts yani Türkçe olarak çatışmalar tanımı da bulunuyor. Bu tanım, mevcut birim ile aynı anda çalışması sorun oluşturan birimlerin belirtilmesini sağlıyor. Bu sayede ilgili birimler aynı anda çalıştırılarak yaşanabilecek problemlerin önüne geçilmiş oluyor. Bu seçeneğin tanımlı olduğu birim  başlatıldığında, mümkünse çatışmaya sebep olan birimler durdurulur.

[https://www.freedesktop.org/software/systemd/man/systemd.unit.html#PartOf=](https://www.freedesktop.org/software/systemd/man/systemd.unit.html#PartOf=)

Ayrıca sıklıkla karşılaşacağımız before ve after tanımları da bulunuyor. Bazen bu iki tanımın görevi karıştırılabiliyor o yüzden açıklamaları dikkatlice takip edin lütfen. Son derece kolay.

Mevcut birim, buradaki after ifadesinden sonra belirtilmiş olan birimlerden sonra başlatılır. Buradaki after ifadesi “sonrasında” anlamına geliyor. Mevcut birim dosyasında bu tanım kullanılıp karşılına birimler yazıldığında, mevcut birimin buradaki birimlerden sonra başlatılması gerektiğini söylemiş oluyoruz.  Yani örneğin mevcut konfigürasyon dosyasında bu netwokrmanager servis birimi buradaki [netwokpre.target](http://netwokpre.target) ve dbus.servis birimlerinin başlatıldıktan sonra başlatılacak şekilde tanımlanmış.

Eğer before tanımı kullanıldıysa bu tanımın karşında belirtilmiş olan birimlerden önce başlatılması sağlanır. Aslında buradaki kural katı bir kural değildir. Eğer mevcut birim ve before tanımının karşısındaki birimler aynı anda etkinleştirilirlerse, buradaki birimler mevcut birim başlatıldı olarak işaretlenene kadar başlatılmayacaktır.

After ve before bir bağımlılık değildir. Yani mevcut birimin çalışıtılması için buradaki servislerin başlatılması şart olmayabilir. Burada yalnızca eğer bu servisler aynı anda etkinleştirilecekse, bunun hangi sıralamada olması gerektiğini tanımlamış oluyoruz. Burada önce veya sonra başlatılmak üzere tanımlanmış olan birimlerden biri veya birkaçı olmasa bile mevcut birim başlatılabilir. Eğer katı bir kural belirtileyip mevcut birimin çalışması için gerekli olan bağımlılıkları tanımlamak istiyorsanız daha önce bahsettiğimiz tanımlama seçeneklerini kullanabilirsiniz.

Birim bölümündeki sık karşılaşılan tanımlamalardan bahsettik. Şimdi de birime özel olarak tanımlanan bir sonraki bölüm hakkında konulaşlım.

Benim örnek olarak açtığım birim dosyası servis türünde olduğu için buradaki başlık da service ismine sahip. Ve bu doğrultada başlık altında tanımlamalar yapılmış. Eğer farklı türde, örneğin device mount veya diğer türlerden birinin birim dosyasını açarsanız buradaki başlığın da ilgili türe göre belirtildiğini görebilirsiniz. 

Esasen buradaki tanımlamalar ilgili birimin davranışlarının konfigüre edilmesini sağladığı için farklı birim dosyaları üzerinde pek çok farklı tanımlama ile karşılaşabilirsiniz. Çünkü ilgili birimin istendiği şekilde çalışması için spesifik olarak pek çok farklı tanımlayamaya ihtiyacı olabilir. Bu gibi durumlarda zaten burada da olduğu şekilde genellikle ilgili tanımlamanın hangi işlevde olduğuna dair yorum satırları da geliştiriciler tarafından eklenmiş oluyor. Spesifik olarak tanımlanmış tüm tanımlara elbette değinemeyiz ancak de ben temelde en sık karşılaşacağımız birkaç standart tanımlamadan ve bunların işlevlerinden bahsetmek istiyorum.

İlk tanımlama olan type tanımlaması, işlem başlatma şeklini tanımlayan konfigürasyondur.

Örneğin benim açtığım mevcut servis dosyasındaki ilk tanıma baktığımızda type yani bu birimin tipinin dbus olduğu belirtiliyor. Ve bu tanımlaya ek olarak dbus için busname tanımlaması da yapılmış. Dbus en yalın haliyle işlemler arası iletişimi mümkün kılan yapıdır. Bu yapı sayesinde paralel olarak çalışmakta olan işlemlerin birbiri ile iletişime geçmesi mümkün oluyor. Buradaki busname tanımı ise mevcut birimin veriyolu üzerindeki ismini belirtiyor. Bu isim üzerinden iletişim verileri doğru işleme aktarılabiliyor. Bu konunun ayrıntılarına giremeyeceğim ancak neticede buradaki type tanımının mevcut birimin nasıl davranacağını belirleyen tanım olduğunu bilmemiz yeterli. Eğer dbus hakkında daha fazla bilgi almak istiyorsanız kısa bir araştırma ile pek çok bilgiye kolayca ulaşabilirsiniz.

![Untitled](20-%20Servislerin%20Yo%CC%88netimi%2026d53a1004af4dd3af2c22533b9977a5/Untitled%201.png)

Burada dbus tanımlanmış ancak dbus dışında simple, forking, oneshot, notify ve idle olmak üzere çeşitli servis tipleri de bulunuyor.

[https://manpages.ubuntu.com/manpages/impish/man5/systemd.service.5.html](https://manpages.ubuntu.com/manpages/impish/man5/systemd.service.5.html)

[https://en.wikipedia.org/wiki/D-Bus](https://en.wikipedia.org/wiki/D-Bus)

Burada en genel tanımlamalar olan exec reload exec start ve restart tanımlamlarından bahsedebiliriz. 

Execstart bu birimin başlatılması sağlayan komutun belirtildiği satırdır.

ExecReload ise bu birimin gerektiğinde yeniden yüklenebilmesi için gereken komutun tanımlandığı satırdır.

Burada yok ancak benzer şekilde execstop tanımı da olabiliyor. Mevcut birimin durdurulurkenki davranışının tanımlanabileceği komuttur. Örneğin bakın [multi.user.target](http://multi.user.target) belirtilmiş. Eğer bu target birimi seçilirse mevcut network-manager servis birimi otomatik olarak başlatılacağı anlamına geliyor.

Install bölümünde ise target birimleri hakkında bilgi bulunur. 

WantedBY seçeneğinden sonra belirtilen target birimleri mevcut birimin otomatik olarak başlatılacağı olan birimleri temsil eder.

Bir servisin durumu görmek için systemctl status servis adı şeklinde komut girebiliriz. 

[https://fedoramagazine.org/systemd-masking-units/](https://fedoramagazine.org/systemd-masking-units/)

Genel olarak birimlerden bahsettik ve listeledik. Şimdi de servis yönetimini ele alabiliriz. Ben örnek olması için network manager servisinin mevcut durumunu sorgulamak istiyorum. Birimlerin durumunu sorgulamak için systemctl status komutunun ardından hakkında bilgi almak istediğimiz birim adını belirtmemiz gerekiyor. Ben network-manager servisini kontrol etmek istediğim için komutumu systemctl status network-manager.service şeklinde belirtiyorum. Fark ettiyseniz birimin türünü belirtmek için mutlaka uzantısını eklememiz gerekiyor. Ben servis birimini kast ettiğim için sonunu .service ile belittim. Bakın ağ yöneticisi servisi şu anda aktif ve çalışıyor. Ayrıca buradan görebildiğimiz gibi sistem başlangıcında otomatik olarak başlatılacak şekilde de tanımlı bulunuyor. Buradaki enabled ifadesi bu servisin sistem başlatılacağını belirtiyor. Eğer disabled şeklinde gözüküyor olsaydı bu servis sistem başlangıcında başlatılmayacaktı. Buradaki çıktılara dikkat edin çünkü genellikle aktiflik durumu ile sistem başlangıcında otomatik olarak başlatılma durumu karıştırılabiliyor. Ne demek istediğimi daha net görebilmek adına gelin bu servisi durdurup durum çıktılarına tekrar göz atalım. Servis durumundan çıkmak için q tuşunu kullanabiliyoruz. Şimdi ben servisi durdurmak istediğim için systemctl stop network-manager.service şeklinde komutumu giriyorum. Benden parola onayı istiyor onayı da veriyorum. Evet servisin durdurulmuş olması gerek. systemctl status network-manager.service komutu ile kontrol edelim. Bakın şu anda servisin inaktiv ve ölmüş olduğu belirtiliyor. Servis durdurulmuş olmasına rağmen bakın hala buradak enabled ifadesi yer alıyor. Çünkü daha önce de söylediğim gibi buradaki ifade aslında bu servisin sistem başlangıcınında başlatılıp başlatılmamamsı gerektiğini temsil ediyor.

Dilersek sistem başlangıcında başlatılma durumunu da değiştirebiliriz. Ben enabled yani sistem başlangıcında aktifleştiriliecek olan işlemi deaktif hale getirmek istiyorum. Bunun için systemctl disable network-manager.service şeklinde komutumu giriyorum. Şimdi tekrar servisin durumunu kontrol edelim.

## Çalışma Seviyeleri | Sistem Durumu

Şimdiye kadar hep birimlerden bahsettik. Pek çok farklı amaca hizmet eden birimler tek başlarına pek bir anlam ifade etmeseler de bir arada uyumlu şekilde belirli amaçlar için çalıştıklarında sistem yönetimi için bizlere kolaylıklar sağlarlar. Örneğin ben sistemi grafiksel arayüzde kullanmak istiyorsam ve internet  bağlantısı da olsun istiyorsam, bu görevlerden sorumlu olan birimleri bir grupa alıp bu gruptaki birimlerin tek bir grup üzerinden başlatılabilmesini sağlayabilirim. Yani ayrı ayrı pek çok farklı amaca hizmet eden birimleri kendi ihtiyaçlarım doğrultusunda çeşitli gruplara ayırıp kullanmam mümkün. Bu sayede ihtiyacım olmayan hiç bir birimin başlatılması ve gereksiz yere çalışması gerekmez. İşte bu birimlerin gruplanması da target isimli bir birim sayesinde oluyor. Birden fazla birimi tek bir target biriminde belirtip bu target üzerinden hepsine kolayca ulaşabiliyoruz. Zaten birimin isminin target yani hedef amaç gibi anlamlara gelmesi, birden fazla birimin belirli bir hedef veya amaç için bir araya toplanmasını temsilen kullanılmıştır. Belirli bir amaç için birden fazla birimi bir target biriminde toplayıp kullanabilmek son derece yararlı olmakla birlikte, daha önceki init yazılımlarının kullandığı çalışma seviyesi yaklaşımından biraz daha esnektir.

Önceleri çalışma seviyesi olarak geçen runlevel yaklaşımı systemd üzerinde çeşitli durumlara özel tasarlanmış olan hedef birim dosyaları üzerinden çok daha esnek bir çalışma ortamı sağlamayı amaçlıyor.

SysVinit de mevcut bulunan çalışma seviyeleri yaklaşımı sayesinde sistemimizi çalışmak istediğimiz duruma özel olan ortam için gerekli olan servisler ile başlatılmasını sağlayabiliyoruz.

Sysvinit üzerinde çalışma seviyeleri 7 düzey olarak tasarlanmıştır. Örneğin ben grafiksel arayüzü kullanmak istemiyorsam sistemimi 3 çalışma seviyesinde başlarak grafiksel arayüz olmadan kullanabilirim. Ya da grafiksel arayüzlü bir çalışma ortamı istiyorsam 5. çalışma seviyesinde başlatılmasını da sağlayabilirim. Çalışma seviyeleri belirli bir amaca özel olarak çeşitli servislerin başlatılmasını sağlayan yani servisleri gruplayıp yalnızca ilgili görev için gerekli olan servislerin başlatılmasını sağlayan bir yaklaşımdır. İşte systemd de bu yaklaşımı daha ileri taşıyarak daha esnek bir servis tanımlaması imkanı sunarken, geçmişe dönük uyumluluk için de bu önceki çalışma seviyelerinde tanımlı olan konfigürasyonların da geçerli olmasını sağlıyor.

Önceki yaklaşım ile tanımlı bulunan çalışma seviyeleri tablodaki gibidir.

1. 0. seviye tüm servislerin kapalı olduğu dolayısıyla sistemin kapalı olduğu seviyedir. 
2. 1. seviye tek kullanıcılı kurtarma modudur. Sistem bu seviyede başladığında yalnızca root hesabi ile oturum açılabilir ve ağ bağlantısı bu modda etkin değildir.
3. 2. Seviye ağ bağlantısının olmadığı çok kullanıcılı seviyedir.
4. 3. seviye grafiksel arayüzün bulunmadığı çok kullanıcılı ve ağ bağlantısı bulunan komut satırı arayüzü ile çalışılan seviyedir.
5. 4. seviye varsayılan olarak tanımlı değildir. Kullanıcının özel ihtiyacına göre sonra bu seviye için tanımlama yapılabilir.
6. 5. seviye. Grafiksel arayüzün olduğu çok kullanıcılı ve ağ bağlantısının bulunduğu seviyedir. Normalde varsayılan olarak pek çok işletim sistemi bu seviyede başlar. Bildiğiniz grafiksel arayüz üzerinden sistemi yönetebildiğimiz ortamı sağlayan seviyedir.
7. 6. seviye ise tüm servislerin yeniden başlatılmasını sağlayan çalışma seviyesidir. Örneğin sistemin varsayılan açılış seviyesini bu 6. seviye olarak ayarlarsanız sistem sürekli kendini yeniden başlatacaktır.

Elbette buradaki çalışma seviyeleri daha önce de söylediğim şekilde sysvinit ile gelmiş olan yaklaşımdır. Systemd bu seviyeler için geriye dönük uyumluluk sağlamak için yani hala bu seviyelerin kullanıldığı durumlar için bu seviyelerin karşılığı olarak target birimleri tanımlamıştır. 

Sırasıyla göz atacak olursak; 

0. seviye [poweroff.target](http://poweroff.target) 

1. seviye rescure.target

2. 3. ve 4. seviye multi-user.target

1. seviye graphical.target

birimleri ile geriye dönük uyumlu şekilde çalıştırılmaya devam ediyor.

Elbette bu seviyeler hakkında detaylardan bahsetmeyeceğim. Çünkü artık systemd kullandığımız için systemd üzerindeki target yapısına odaklanmamız gerek.

Varsayılan olarak birim dosyaları /lib/systemd/system dizininde tutuluyor. Buradaki dosyalar en temel dosyalar olduğu için ne yaptığınızı bilmediğiniz sürece buradaki dosyaları düzenlememelisiniz. Bunun yerine, gerekirse, bu konumdaki dosyanın yerini alacak başka bir birim dosya konumu kullanarak dosyayı geçersiz kılmalısınız.

Bir birimin çalışma şeklini değiştirmek isterseniz, bunu yapmak için en iyi yer /etc/systemd/system dizini içindedir. Bu dizin konumunda bulunan birim dosyaları, dosya sistemindeki diğer konumların herhangi birine göre önceliklidir. Bir birim dosyasının sistem kopyasını değiştirmeniz gerekiyorsa, bu dizine yenisini koymak, bunu yapmanın en güvenli ve en esnek yoludur.

Ayrıca /run/systemd/system konumunda çalışma zamanı birimi tanımları için bir konum vardır. Bu dizinde bulunan birim dosyaları, /etc/systemd/system ve /lib/systemd/system içindekiler arasında önceliğe sahiptir. Systemd işleminin kendisi, çalışma zamanında oluşturulan dinamik olarak oluşturulmuş birim dosyaları için bu konumu kullanır. Bu dizin, oturum süresince sistemin birim davranışını değiştirmek için kullanılabilir. Bu dizinde yapılan tüm değişiklikler, sunucu yeniden başlatıldığında kaybolacaktır.

Bu dizinler içindeki birim dosyalarına baktığımızda hepsinin ilişkili olduğu birim türünün uzantısı ile bittiğini görebiliyoruz. Örneğin servisler için .service uzantısı kullanılıyorken, target için .target uzantılı dosyalar bulunuyor.

Elbette biz anlatımlar sırasında temel sistem yönetimi bilgisi için daha çok service birimi üzerinden ilerliyor olacağız.

Vendor preset olarak geçen kısım ilgili servisin sistem başlangıcında otomatik olarak başlatılma durumunun ilgili servisin sağlayıcısı tarafından ne şekilde tanımlandığını belirtiyor. Örneğin X servisinin servis geliştiricisi tarafından sistem başlangıcında otomatik olarak başlatılması öneriliyorsa burada enabled olur. Tam tersi şekilde eğer servis sağlayıcısı sistem başlangıcında başlatılması yerine gerektiğinde manuel olarak başlatılmasını tavsiye ediyorsa da disable şeklinde gözükür. Elbette bu bir kısıtlama değil daha çok öntanımlı ayardır. Eğer biz bir servisin sistem başlangıcında otomatik olarak başlatılmasını istiyorsak systemclt enabled servis_adı şeklinde komut girmemiz yeterli. Bu komutun ardından ilgili servis öntanımlı olarak sistem başlangıcında başlatılmıyor olsa bile biz aktifleştirdiğimiz için başlatılacaktır.

Kısaca birim tiplerini açıkladık. Şimdi de mevcut sistemimizdeki tipleri konsola bastıralım. Bunun için systemctl -t help şeklinde komutumuzu girebiliriz. Buradaki systemctl komutu unitleri kontrol etmemizi sağlayan yardımcı bir araçtır. Ben bu komut sayesinde unit tiplerinin konsola bastırılmasını sağladım. 

## Unutulan root parolasını sıfırlama

Şimdiye kadar öğrendiğimiz bilgiler ışığında, unutmamız halinde nasıl root parolasını sıfırlayabileceğimizden bahsedeceğim.

Sistemimizi yeniden başlatıyoruz. Grub menüsünde yani çekirdek seçim ekranındayken, seçili kernel üstündeyken “**e**” tuşuna basarak edit yani düzenleme moduna geçmemiz gerekiyor.

Bakın burada init yani çekirdeğin ilk başlatacağı işlemin karşında init dosyasının konumu yer alıyor. Bizim root parolasını değiştirebilmek için bir kabuğa ihtiyacımız var, bu sebeple buraya kabuk programının dosya konumunu init=/bin/bash şeklinde yazmalıyız. Bu sayede herhangi bir yetki mekanizması başlatılmadan çekirdek yalnızca kabuğu başlatacak. Değişikliği kaydetmek için ctrl x e basabiliriz.

Bash kabuğu başlatıldığında, kök dizini okunabilir ve yazılabilir modda yeniden bağlamamız gerekiyor. Bu sayede kök dizin altındaki dosyalara yazma yetkimiz olacak. Bunun için **mount -o remount, rw / şeklinde komutumuzu girebiliriz. Artık kök dizine yazma yetkimiz olduğuna göre root için yeni parola da belirleyebiliriz.**

**passwd root** komutuyla yeni parola belirliyorum. Artık sistemin normal şekilde başlatılması için sistemi yeniden başlatabiliriz. Hatta yeniden başlatmamıza da gerek yok aslında, init işlemini başlatmak için **exec sbin/init** komutunu vermeniz yeterlidir.

Böylelikle neyi neden yaptığımızın farkında olarak root parolasını sıfırlamış olduk. Gördüğünüz gibi yaptığımız işlemlerde daha önce bahsetmediğimiz yani bilmediğimiz hiç bir şey yoktu. Bu işlemi tamamen temel bilgilerimizi kullanarak gerçekleştirdik. Sistemi temel olarak tanımak ve yönetmek için bu eğitimin bir başlangıç noktası olması amacımıza ulaşıyor gibiyiz ne dersiniz ?

Elbette tüm servislerin kullanımını tek tek ele almayacağız. Yalnızca bir sonraki bölümde zamanlanmış görevler tanımlamamızı sağlayan cron servisinden ve ayrıca loglardan bahsederken journalclt servisinden bahsetmek istiyorum. Konu bütünlüğünü sağlamak adına bu servislerden ayrı bir bölümde bahsetmek daha makul geldiği için bu bölümde servislerin kullanımlarına elbette girmeyeceğim. Zaten tüm servislerin kullanım şekilde farklı olacağı için ben tek tek hepsine değinemem.

# Bağımlılıklar

Daha önce paket yönetimde ve bu bölüm içinde sık sık bağımlılık kavramları üzerinde durdur. Çeşitli birimler sağlıklı şekilde çalışabilmek için çoğu zaman ek birimlere ihtiyaç duyuyor. Bu duruma da bağımlılık deniyor. Söz konusu pek çok birimin bir arada sorunsuzca çalışması olduğunda da aynı anda çalışması sorun oluşturan veya çalışma sıralamasının farklı olması gereken birimlerin bağımlılıklarının doğru şekilde yönetilmesi çok önemlidir. Aksi halde sistem stabil şekilde işleyemez. İşte bu bağımlılıkların yönetilmesi noktasında anlatım sırasında bahsettiğimiz before after requires ve benzeri pek çok tanımlama systemd tarafından dikkate alınıyor. Üstelik systemd tek bir birim için değil, tüm birimlerin ortak şekilde tanımlı oldukları bağımlılıklar kapsamında yönetilmesini sağlıyor. Bizler kullanıcılara olarak arkaplanda karmaşıklaşan bağımlıklıklardan doğrudan haberdar olmayız. Bu bağımlılıklar çoğu durumda zaten ilgili yazılımların geliştiricileri tarafından ilgili birimin konfigürasyon dosyasında uygun şekilde tanımlanmıştır. Bizlere yalnızca sistemde varsayılan olarak yüklü gelen veya daha sonra yüklediğimiz paketlerle birlikte gelmiş olan birim dosyasını yönetmek kalır. Ancak her zaman mevcut birimleri yönetmemiz gerekmeyebilir. Kimi zaman ilgili birim dosyasının içini açıp düzenleme yapmak veya yeni bir birim dosyası tanımlamak gerekebilir. Yani sistem yöneticisi olarak spesifik bir soruna çözüm için birim dosyalarının içeriğini iyi biçimde anlamış olmamız gerekiyor. 

Anlatımın başında da belirttiğim şekilde systemd esasen oldukça kapsamlı bir yapıdır. Ben yalnızca anlatımlarımın sizlerin için başlangıç noktası olabilmesi adına en temel bilgilere değinmeye çalıştım. Ancak özellikle spesifik konfigürasyonların gerçekleştirilmesi ve birimlerin bağımlılıkların doğru şekilde yapılandırılması için daha fazla araştırmaya ihtiyaç duyabilirsiniz. Yani aslında şimdiye kadar bahsettiklerimizle var olan birimleri temel düzeyde kolayca yönetebilirsiniz. Ya da ihtiyaçlarınız doğrultusunda çok temel düzeyde yeni birim dosyaları da oluşturabilirsiniz. Ancak çok daha spesifik durumlar için gerekli olan tanımlamaları gerçekleştirebilmek için bu eğitimde değindiğimden biraz daha fazlasını bilmeniz gerekebilir. Özellikle yazılımların sağlıklı şekilde çalışması için gerekli olan birim dosyalarını geliştiriciler sağladığı için herkesin sıfırdan spesifik sorunlara çözüm sunan birim dosyaları konfigüre etmesi de elbette gerekmeyebilir. Neticede yaygın kullanıma sahip systemd yapısı hakkında başlangıç seviyesinde de olsa bilgi edinebildiğimizi ve var olan birimleri ihtiyaçlarımız doğrultusunda yönetebilecek yetkinliği kazandığımızı düşünüyorum.

# Notlar:

Eğer belirli bir isim altında bir servis isteniyor ancak birim konfigürasyon dosyası bulunamıyorsa, systemd, aynı ada sahip bir SysV servis betiği arar, eğer bu isimle eşleşen bir betik varsa bunu dinamik olarak servis birim dosyasına dönüştürür. Bu sayede sysVinit ile geri dönük uyumluluk sağlanmış olur. Yani sysV için tanımlanmış olan servis betikleri, systemd üzerinden de yürütülebilir. Bu geriye dönük uyumluluk pek çok betiğin sorunsuzca dönüştürülmesi ile sonuçlansa da yine de bu uyumlululuğun %100 çalışmayabileceğiniz de unutmayın. 

[Service] bölümünde iligli servisin özelliklerini tanımlayabiliyoruz. Ve tanımlayabileceğimiz çok sayıfa spesifikasyon bulunuyor. Bunlara göz atmak adına öncelikle systemd.exec manuel sayfalasına göz atabiliriz. Bu manuel sayfası yürütme ortamının konfigürasyonları hakkında bilgi sunduğu için pek çok tanımın açıklamasını görebiliyoruz. Elbette benim hepsine tek tek değinmem imkansız. Nitekim ben de hepsini bilmiyorum. İhtiyacım oldukça manuel sayfasından yardım alıyorum. Ayrıca buradakiler dışında manuel sayfasının en altındaki harici kaynaklar üzerinden de tanımlamalar sırasında kullanabileceğimiz ekstra seçenekleri görebiliriz. Örneğin systemd.kill veya systemd.resource-control manuel sayfalarında da göz atıp ekstra bilgi edinebiliriz. Systed.kill manuel sayfasına göz atalım. Bakın burada işlemlerin öldürülmesiyle ilgili çeşitli seçenekler açıklanmış. Bunun dışında systemd.resource.control sayfasına da göz atabiliriz.

Burada da kaynakların yönetimi için kullanılan çeşitli tanımlamalar bulunuyor. Elbette tüm tanımlamalar ilgili birime göre de değişiklik gösteriyor. Örneğin servis birimine özel tanımlamalara göz atmak istersek systemd.service manuel sayfalarına göz atabiliriz. Bakın burada servis birimi için tanımlanabilecek olan tüm spesifikasyonlar sırasıyla kısaca açıklanmış. Ben de servis birimine odaklanacağım için burada yer alan en temel tanımlamalardan bahsetmek istiyorum. Benim bahsettiklerim dışındaki tüm tanımlamalar için elbette bu manuel sayfasını okuyabilirsiniz. Hepsinden bahsetmek için spefisik olarak ilgili servisi tanımlamak ve uzun uzadıya hangi tanımın neden kullanıldığına değinmek gerekiyor. Ben yalnızca en sık karşılacağımız ve işleyişin temelini anlamamızı sağlayacak olan tanımlamalardan bahsediyor olacağım. İleride yeni bir tanımla karşılaştığınızda tek yapmanız gereken manuel sayfaların bu tanımı araştırmak ve çıkan dokümanları okumaktır.

Systemd birimleri ve çeşitli konfigürasyonları ile ilgili olan manuel sayfalarını listemelek için man systemd. komutunu yazdıktan sonra tab tuşuna basarak kaç tane maneul sayfası olduğunu görebilirsiniz. Örneğin servisler hakkında bilgi almak için systemd.service sayfasına bakabilir ya da mount birimi hakkında bilgi istiyorsanız da systemd.mount manuel sayfasına bakmanız yeterlidir. Bu şekilde tüm birimler ve standart tanımlamaları hakkında bilgilere kolayca ulaşabilirsiniz. Ayrıca karşışaştığınız bir tanımlamanın anlamını kavrayamadıysanız muhtemelen standart olmaayan özel bir tanımlamadır. Bu durumda satır aralarındaki yorumları dikkatlice okuyabilir veya ilgili birim dosyasının geliştiricilerinin dokümanlarına ayrıca bakabilirsiniz. İnternet üzerinden araştırmak da pek çok tanımlamamnın esas anlamının kavranması noktasında faydalı kaynaklar sunacaktır.  

Neyse lafı çok uzattım, hadi artık servis birimi için temel tanımlamalardan bahsedelim.

En temel tanınmlamalardan biri de type olarak geçen tanımdır. Bu tanımlama servisleri, işlem oluşturma davranışlarına göre sınıflandırmayı sağlar. Systemd servisleri nasıl doğru şekilde yönetebileceği ve durumlarını gözlemleyebileceğini bu değere bakarak öğrenebiliyor. 

- Yalnızca kill komutunu kullanmak yerine systemd kill komutunu kullanarak ilgili servisin ilişkili tüm işlemlerini sonlandırabiliriz.
- Konfigürasyon dosyalalarının içerikleri hakkında bilgi almak için ilgili konfigürasyon dosyasının maneul sayfalarına göz atabilirisiniz. İstisnalar hariç sistemde mevcut bulunan pek çok konfigürasyon dosyası hakkında manuel sayfaları bulunuyor. Çünkü geliştiriciler bu sayfalar hakkında daha fazla bilgiye ihtiyaç duyduğumuzda bakabilmemiz için bu maneul sayfalarını sağlıyorlar. Örneğin man systemd-system.con komutunu kullanarak bilgi edinebilirsiniz.
- Önceki init e ait olan bir script dosyası ile sıradan bir konfigürasyon dosyasını kıyaslayarak konfigürasyon dosyalarının çoğu durumda çok daha sade olduğuna vurgu yapabiliriz.

- Spesifik bir işlemin işlem numarasından hangi servisin işlemi olduğunu öğrenmemiz de mümkündür. Bunun için tek yapmamız gereken ilgili işlemin işlem numarasını belirtmek. Örneğin hakkında bilgi almak için systemctl status pid şeklinde komut girdiğimizde ilgili işlemin hangi servisle ilişkili olduğunu öğrenebiliyoruz. Örneğin bir işlem var diyelim ve bu işlem çok fazla ram tükettiği için hangi servise ait olduğunu araştırmak öğrenmek istiyorsunuz. Bu ve bunun gibi keşif ve sorgulama yani sorun tespiti aşamasında işlem numarası üzerinden mevcut işlemin ilişkili olduğu sevisi öğrenmek işlerini çok kolaylaştıracaktır.

Benim açıklamadım ve henüz farkında olmadığım o pek çok özelliği olduğu için aslında bunun gibi pratiklikleri tek tek ele almamız mümkün değil. Bu gibi pratik bilgiler aslınra herhangi bir sorun yaşayıp o soruna çözüm için araştırma yaptığımızda karşımıza çıkabilecek türden tüyolar. Yani eğer karşılaştığınız sorunlar için çözümler arama alışkanlığınız varsa zaten zamanla bu gibi pek çok pratik kullanım bilgisine de sahip olursunuz. Yani ezberlenecek değil keşfedilecek bilgiler aslında. 

# SELinux VE cgroups Kavramlarını Açıkla

Belki bu kavramlar orta seviye eğitim için kullanılabilir.

# Kaynaklar

[https://trstringer.com/tags/systemd/](https://trstringer.com/tags/systemd/)

[https://manpages.ubuntu.com/manpages/jammy/man5/systemd.service.5.html](https://manpages.ubuntu.com/manpages/jammy/man5/systemd.service.5.html)

[https://www.freedesktop.org/software/systemd/man/systemd.service.html](https://www.freedesktop.org/software/systemd/man/systemd.service.html)

[https://wiki.archlinux.org/title/systemd](https://wiki.archlinux.org/title/systemd)

[https://kerteriz.net/linux-systemd-detaylari-ve-sunucuda-servis-yazmak/](https://kerteriz.net/linux-systemd-detaylari-ve-sunucuda-servis-yazmak/)

[https://www.syslogs.org/systemd-ile-sistem-ve-servis-yonetimi/](https://www.syslogs.org/systemd-ile-sistem-ve-servis-yonetimi/)

[https://books.google.com.tr/books?id=NDlUEAAAQBAJ&pg=PR18&lpg=PR18&dq=Linux+Service+Management+Made+Easy+with+systemd+pdf&source=bl&ots=NsZTAkjsku&sig=ACfU3U1LpvoTx0hKGXnMV4qCOTyJgENz0A&hl=tr&sa=X&ved=2ahUKEwiD4L62zYv1AhWURPEDHZELDV8Q6AF6BAgTEAM#v=onepage&q=Linux Service Management Made Easy with systemd pdf&f=false](https://books.google.com.tr/books?id=NDlUEAAAQBAJ&pg=PR18&lpg=PR18&dq=Linux+Service+Management+Made+Easy+with+systemd+pdf&source=bl&ots=NsZTAkjsku&sig=ACfU3U1LpvoTx0hKGXnMV4qCOTyJgENz0A&hl=tr&sa=X&ved=2ahUKEwiD4L62zYv1AhWURPEDHZELDV8Q6AF6BAgTEAM#v=onepage&q=Linux%20Service%20Management%20Made%20Easy%20with%20systemd%20pdf&f=false)

[NOT 1 : ****[Understanding The Need For Systemd](https://learning.oreilly.com/library/view/linux-service-management/9781801811644/B17491_01_Final_NM_ePub.xhtml)****](20-%20Servislerin%20Yo%CC%88netimi%2026d53a1004af4dd3af2c22533b9977a5/NOT%201%20Understanding%20The%20Need%20For%20Systemd%20ca094d56d6774f80b2263e2782097fb0.md)

[Not 2 : ****[Understanding Systemd Directories And Files](https://learning.oreilly.com/library/view/linux-service-management/9781801811644/B17491_02_Final_NM_ePub.xhtml)****](20-%20Servislerin%20Yo%CC%88netimi%2026d53a1004af4dd3af2c22533b9977a5/Not%202%20Understanding%20Systemd%20Directories%20And%20Files%20ff398873ae684b26924a3fe688419dcb.md)