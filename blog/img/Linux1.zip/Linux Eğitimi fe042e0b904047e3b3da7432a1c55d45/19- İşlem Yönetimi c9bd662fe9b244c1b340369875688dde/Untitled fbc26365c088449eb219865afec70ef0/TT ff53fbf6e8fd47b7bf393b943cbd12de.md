# TT

Anlamı: Terminal