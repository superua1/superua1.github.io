# PGID

Anlamı: Proses Grup Kimliği (Process Group ID)