# Ubuntu Server Kurulumu ve Konfigürasyonu

Daha önce sözünü verdiğim şekilde Ubuntu server kurulumundan ve bu dağıtımdaki çalışma ortamını düzenlemekle ilgili birkaç konudan bu bölümde bahsetmek istiyorum. 

# Ubuntu Server Kurulumu

Kurulum işlemleri aslında daha önce ele aldığımız Desktop kurulumu ile çok benzer. Ben zaten desktop kurulumunu takip ettiğinizi varsayarak daha önce kurulum videosunda bahsetmiş olduğum sanal makineyle ilgili olan detaylardan bu videoda tekrar bahsetmeyeceğim. Yani kurulum işlemi uzun sürmeyecek. Lafı daha fazla uzatmadan kuruluma geçecek olursak kurulum için elbette öncelikle ubuntunun websitesini ziyaret edip, ubuntu server dağıtımını indirmemiz gerekiyor. Hemen indirme sekmesinden “Server” a tıklayalım. Bakın burada 3 farklı seçeneğimiz olduğu belirtilmiş. Biz kendi sanal makinemize kurulum yapacağımız için buradan ikinci seçenek olan manual server seçeneği ile devam edeceğiz. Bakın tıpkı desktop sürümünde olduğu gibi LTS ve daha güncel sürüm olmak üzere iki alternatif versiyon bulunuyor. Biz elbette LTS sürümünü indireceğiz. İndirme işlemi bittiğinde anlatıma devam edebiliriz.

Evet, indirme işlemi sonlandı. Şimdi tek yapmamız gereken indirmiş olduğumuz kalıp için yeni bir sanal makine oluşturmak. Virtulabox aracına gelip buradan makine sekmesinden yeniye tıklayalım. 

Ben ubuntu server olarak isimlendiriyorum ve devam ediyorum. Bellek kapasitesi olarak da 4 GB kadar belirliyorum. Sanal diske kurulum yapacağımız için elbette yeni bir sanal diskin oluşturması gerekiyor. Bu seçenekle devam edelim. Buradan disk tipini de değiştirmeden devam edelim. Eğer performanslı şekilde çalışmasını istiyorsanız buradan sabit disk boyutu ile devam edebilirsiniz. Ben değişken seçeneği ile devam ediyorum. Buradan diski de değiştirmeden devam edelim. Tamamdır. Şimdi buradan disk kapasitesini de belirlememiz gerekiyor. Ben örnek olarak 20 GB kadar disk bölümü ayırmak istiyorum. Elbette siz ihtiyaç duyacaksanız disk alanını daha büyük olarak ayarlayabilirsiniz. Disk boyutunu da ayarladıktan sonra oluştur butonuna basarak sanal makinemizin oluşturulmasını sağlayabiliriz. Evet bakın sanal makinem listeye sorunuzca eklendi. Şimdi tek yapmamız gereken, indirmiş olduğumuz imaj dosyasının bu sanal makine başlatıldığında boot edilmesi. Bunun için de ayarlarını açalım. Şimdi buradaki depolama sekmesinden, imaj dosyamızı buradaki boş dvd aygıtına ekleyelim. Tamamdır. Artık kurulum yapmak için sanal makinemizi çalıştırmamız yeterli. Hadi çalıştıralım. 

Kurulum adımlarına ulaşmamız çok kısa sürecek. Biraz bekleyelim. Ve işte ilk olarak dil seçimi yapmamız gereken adımla karşılaştık. Buradan istediğiniz bir dili seçebilirsiniz ancak benim önerim ingilizce dilini tercih etmenizdir. Bu sayede çok daha standart bir sistem dili ile her yerden aynı kolaylıkla sistemi yönetebilirsiniz. Ben ingilizce ile devam ediyorum.

Şimdi buradan klavye dilimizi değiştirmemiz gerekiyor. Ben Türkçe klavye kullandığım yön tuşları ile layout satırının üzerine gelip enter ile listeyi açıyorum. Bakın burada pek çok farklı klavye dili seçeneği bulunuyor. Aşağı doğru kaydırarak türkçeyi bulalım. Ben turkish seçip onaylıyorum. Şimdi son olark klavye biçimimizi yani q veya f gibi kullandığımız klavye tipini buradaki varyant satırından bulup seçmemiz gerekiyor. Aslında buradaki turkish seçeneği varsayılan olarak q klavye için geçerli olan tanımlama yani bu şekilde de bıraksam türkçe q klavyemi kullanmaya devam edebillirim. Ancak bunun dışında istersem buradan turkish alt q seçeneğini de seçebilirim. Eğer siz f klavye kullanıyorsanız buradan f klavye için uygun olan seçimi yapabilirsiniz. Ayrıca bu seçim konusunda emin değilseniz buradan klayvenizin tipini tanımlamak için bu seçeneği de kullanabilirsiniz. Şimdi bize bazı karakterler soracak ve girdiğimiz tuşlara göre hangi klavye düzenine sahip olduğumuzu belirleyip bize söyleyecek. Ben ok ile devam ediyorum. Şimdi burada gözüken karakterleri tek tek girelim. Bakın anında hangi klavye olduğunu zaten tahmin etti. Ben kendim için Turkish klavye uygun olduğu için bu klavye ile devam edeceğim. Buradan done seçeneğinin üstüne gelip kuruluma devam edebiliriz.

Bakın şimdi de ağ ayarlarını tanımlamamız isteniyor. Zaten şu anda makinemde bu ağ kartı geçerli olduğu için buradaki ayarı değiştirmeden devam edicem. Yine eğer gerekiyorsa buradan ilgili arayüzün üstüne gelip bilgi alabilir, ya da istediğiniz gibi düzenleme yapabilirsiniz. Ben dediğim gibi bir sorun olmadığı için aynen bu şekilde bırakıp devam ediyorum.

Eğer proxy bağlantısı kulanacaksanız buradan gerekli adresi ekleyebilirsiniz. Ben tanımlamadan devam ediyorum.

Bakın resmi repolardaki paketlerin alınması konusunda gecikme olmaması için burada tr.archive.ubuntu adresi bulunuyor. Bu adres üzerinden çok daha hızlı şekilde repolara erişebiliyor olacağız. Eğer gerekiyorsa farklı bir adres da tanımlayabilirsiniz. Yine de gerekmedikçe bulunduğunuz ülkedeki resmi adresin kalması en mantıklısı. 

Evet, şimdi nihayet diske kurulum için disk yapılandırma ayarlarına gelebildik. Bakın burada daha önce oluşturmuş olduğumuz sanal disk aygıtı bulunuyor. Eğer siz birden fazla sanal disk eklediyseniz burada daha fazla disk de gözüküebilir. Görebildiğiniz gibi buradan tüm diskin kullanılması ile disk bölümlerinin düzenlemesi gibi iki alternatifimiz bulunuyor. Eğer devam edersek, buradaki diskin tamamı linux için kullanılmak üzere otomatik olarak bölümlendirilecek. Ancak biz daha önce de olduğu gibi disk bölümlerini kendimiz ayarlamak istediğimiz için buradan custom storage layout seçeneğini seçip devam edelim.  

# Komut Satırı Arayüzünde Daha Rahat Çalışmak

Normalde yalnızca komut satırı arayüzünde çalışmak pek kolay değildir. Çünkü grafiksel arayüzden alıştığımız gibi araç çubuğunu kullanarak önceki çıktılara geri dönmek veya kopya yapıştır gibi işlemleri yapmak grafiksel arayüze oranla nispeten zahmetlidir. 

Esasen pek çok durumda grafiksel arayüzdeki konsolları kullanma imkanına sahip olacaksınız ancak ben yine de saf komut satırını kullanacaklar için bazı konulardan bahsetmek istiyorum.

Yani kısaca tty konsolları üzerinde çalışırken işlerinizi kolaylaştıracak birkaç basit özellikten bahsetmek istiyorum.

Örneğin öncelikle birden fazla konsol açıp kolayca geçiş yapabileceğimiz tmux screen terminator gibi araçlardan bahsederek başalayabiliriz. Özellikle ssh bağlantısı koptuğunda konsolun aniden kapsanmasını önleme gibi faydaları dolayısıyla sıradan tty kullanmak yerine tmux gibi araçları kullanmak gerçekten işlevseldir.

# Ubuntu Server ve Grafiksel Ortam Arayüz Kurulumu

Komut satırı arayüzünde nasıl rahat çalışabileceğinizden bahsettik. Şimdi de grafiksel arayüz ortamı bulunmayan sisteme nasıl grafiksel arayüz kazandıranileceğimizi ele almak istiyorum.

Kullanılmadığında grafiksel arayüzün kapatılarak kaynak tüketmesinden bahset.

Screen aracı

Komut satırında kopyalama kaydırma gibi işlemlerden bahset.