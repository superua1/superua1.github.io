# chroot

Unix ve Unix benzeri işletim sistemlerinde bir chroot, mevcut çalışan işlem ve alt öğeleri için görünen kök dizini değiştiren bir işlemdir. Bu şekilde değiştirilmiş bir ortamda çalıştırılan bir program, belirlenmiş dizin ağacının dışındaki dosyaları adlandıramaz (ve dolayısıyla normalde erişemez). "Chroot" terimi, chroot(2) sistem çağrısına veya chroot(8) sarmalayıcı programına atıfta bulunabilir. Değiştirilen ortama chroot hapishanesi denir.

Yani bildiğiniz hapisane içine alıp, harici olarak hiç bir dosyaya erişememesi için sahte root dizini göstermek gibi düşünebiliriz.