# 18- Temel Ağ Komutları

ip yapılandırması için manuel ve dinamik konfigürsayon seçenekleri var. Manuel bildiğimiz elle düzenleme. Dynamic host configuration protochol olarak geçen DHCP ise dinamik olarak sahip olduğu ip havuzunda göre tanımlama yapan protokoldür. 

Giriş seviyesi için yeterli olacak düzeyde temel network yani ağ bilgisini ele almaya çalışacağız. 

Mevcut video çevrimdışı izlemediğiniz varsayacak olursam, şu anda aşağı yukarı bu şemadaki yolculuk sayesinde bu videoyu izleyebiliyorsunuz. 

[https://github.com/wasny0ps/Network-Notes](https://github.com/wasny0ps/Network-Notes)

btk akademiye de göz at

lpic-1 e göre:

[https://www.lpi.org/our-certifications/exam-102-objectives#networking-fundamentals](https://www.lpi.org/our-certifications/exam-102-objectives#networking-fundamentals)

![Untitled](18-%20Temel%20Ag%CC%86%20Komutlar%C4%B1%20740d476626e641acbe82a04bac1d0575/Untitled.png)

DHCP ya da mail server kurulumu gibi konulardan bahsedilecek mi ?

Sanallaştırma yazılımlarındaki ağ açıklamaları üzerinden de networkten bahsedebilirsin: [https://www.youtube.com/watch?v=HY15AQt4XWI](https://www.youtube.com/watch?v=HY15AQt4XWI)

Uygulamayı çalıştırdığınız port başka bir process tarafından kullanılıyorsa bunu tespit edip kapatmak için "lsof" komutu kullanılabilir. (Linux'ta)

Örnek: 3000 portundaki process'in id'sini "lsof" ile tespit ediyoruz, sonra "kill" komutu ile sonlandırıyoruz.

The static host name is the traditional hostname , which can be chosen by the user, and is stored in the /etc/hostname file. **The “transient” hostname is a dynamic host name mhaintained by the kernel**
. It is initialized to the static host name by default, whose value defaults to “localhost”

# Types of hostnames

The hostname can be configured as follows

1. Static host name assigned by sysadmin. For example, “server1”, “wwwbox2”, or “server42.cyberciti.biz”.
2. Transient/dynamic host name assigned by DHCP or mDNS server at run time.
3. Pretty host name assigned by sysadmin/end-users and it is a free-form UTF8 host name for presentation to the user. For example, “Vivek’s netbook”.

[Acikkaynak Network](18-%20Temel%20Ag%CC%86%20Komutlar%C4%B1%20740d476626e641acbe82a04bac1d0575/Acikkaynak%20Network%2037c7d16bc25e4d6ca26720751f858f61.md)

Sıra geldi ağ hakkında konuşmaya. Ebette ağ konusu başlı başına bir uzmanlık alanı olduğu için biz yalnızca giriş seviyesinde en temel bilgilerden bahsediyor olacağız. Eğer ağ konusunda uzmanlık gibi bir hedefiniz varsa CCNA sertifikasına göz atabilirsiniz. Giriş seviyesinde temel bilgileri ele almak bile diğer bölümlere nispeten uzunca bir anlatımı gerektiriyor. Ben asgari düzeyde bilmemiz gereken kavramlardan sırasıyla bahsetmeye çalışacağım.

[https://learning.edx.org/course/course-v1:LinuxFoundationX+LFS101x+2T2021/block-v1:LinuxFoundationX+LFS101x+2T2021+type@sequential+block@7079eecfff7642b7857d4c3d5ae010a5/block-v1:LinuxFoundationX+LFS101x+2T2021+type@vertical+block@375daaa548e147628ca7f0f687982ed4](https://learning.edx.org/course/course-v1:LinuxFoundationX+LFS101x+2T2021/block-v1:LinuxFoundationX+LFS101x+2T2021+type@sequential+block@7079eecfff7642b7857d4c3d5ae010a5/block-v1:LinuxFoundationX+LFS101x+2T2021+type@vertical+block@375daaa548e147628ca7f0f687982ed4)

[https://linuxjourney.com/lesson/arp-command](https://linuxjourney.com/lesson/arp-command)

Network ve diğer konularda bu rehber kullanılabilir:[https://learning.oreilly.com/library/view/linux-shell-scripting/9781785881985/5ba784d5-fa8b-4840-b4c5-cac906e484f9.xhtml](https://learning.oreilly.com/library/view/linux-shell-scripting/9781785881985/5ba784d5-fa8b-4840-b4c5-cac906e484f9.xhtml)

[https://learning.oreilly.com/library/view/mastering-linux-administration/9781789954272/B13196_07_Final_NM_ePub.xhtml](https://learning.oreilly.com/library/view/mastering-linux-administration/9781789954272/B13196_07_Final_NM_ePub.xhtml)

ip adresi paketlerin iletilebilmesi için iletişim adrestir.

kendi networkümüzü oluşturup bu network içindeki cihazlara çeşitli ip ler tanımlarız

ip adreslerini kolay hatırlayabilmek için de hostname tanımlarız

bu networkün diğer networkdekiler ile iletişim kurabilmesi için yani internette bulunabilir olması için de bu networke domain name gerekir.

böylelikle örneğin kendi ev networkümdeki taylan hostnameli makineye hostname.domain yani taylan.domain şeklinde internetten erişmek mümkün olur. domain name çözümlemesini dns yapar.