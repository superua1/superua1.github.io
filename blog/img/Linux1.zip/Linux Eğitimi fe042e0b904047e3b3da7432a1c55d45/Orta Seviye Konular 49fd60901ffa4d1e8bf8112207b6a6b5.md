# Orta Seviye Konular

Giriş seviyesi için uygun olmadığını düşündüğüm diğer konuları bu eğitim altında toplamak istedim. Eğitime 2. seviye ya da orta seviye dedim ancak seviyenin tanımı ve kapsamı oldukça muğlak. Yani buradaki eğitim Linux üzerindeki tüm orta seviye konuları kapsamıyor. Sistem yönetimi için temelde ihtiyaç duyabileceğimiz ama bana göre orta seviye dahilinde olan konular kapsamında anlatım gerçekleştiriyor olacağız. İlk eğitimde olduğu gibi bu eğitim de herhangi bir sertifikasyon sınavına hedeflemiyor, yalnızca daha fazlasını araştırmanıza ön ayak olacak kadar bazı konulardan bahsediyor olacağız. 

Eğitim içerisinde mühendislik detaylarına girmeden mümkün oldukça olayların iç yüzü hakkında teorik bilgilerden de bahsediyor olacağız. Derinlemesine detayları merak ediyorsanız gömülü linux hakkında bilgi sunan kaynaklara bakabilirsiniz. Biz daha çok sistem yönetiminde bilmemizin yararlı olacağı bilgilerden bahsediyor olacağız. Bu sayede ilk eğitimde olduğu gibi gerçekleştirdiğimiz işlemler bizlere çok daha anlamlı gelecek. Ancak tekrar belirteyim, derinlemesine teorik anlatımlarda bulunmayacağız. Dolayısıyla ele aldığımız konularım tüm yönlerinin de bahsedemeyeceğiz. Yani aradığınız-beklediğiniz tüm konular bu eğitimde bulunmayabilir. Yine de zaten eğitime katılmadan önce müfredatı incelediğiniz yani müfredatın farkında olarak bu eğitime katıldığınız için beklentiler anlamında sorun yaşayacağınızı düşünmüyorum. 

Ayrıca bu eğitimi, sistem yönetimine giriş eğitimini aldığınızı veya o eğitimde bahsedilenleri bildiğinizi varsayarak ele alıyor olacağım. Önceki eğitime kayıt olmadıysanız veya olmak istemiyorsanız müfredatına göz atıp hangi konuları ele aldığımızdan haberdar olabilirsiniz. Eğitime kayıt olmak için de bu eğitimin en son dersinde bulunan bağlantıyı kullanabilirsiniz. 

Tamamdır lafı yine çok uzattım hadi anlatımlara geçelim.

Kaynak: [https://learning.oreilly.com/videos/linux-under-the/9780134663500/](https://learning.oreilly.com/videos/linux-under-the/9780134663500/)

- **Understanding memory management:** [https://www.golinuxcloud.com/tutorial-linux-memory-management-overview/](https://www.golinuxcloud.com/tutorial-linux-memory-management-overview/)
- **Security**
- **Hardware initialization**
- **Looking closer at the kernel**
- **Performance optimization**
- **The future of Linux**

Çekirdeğin güncellenmesi.

GRUP düzenlenmesi

PAM

chroot

Uygulamayı çalıştırdığınız port başka bir process tarafından kullanılıyorsa bunu tespit edip kapatmak için "lsof" komutu kullanılabilir. (Linux'ta)

Örnek: 3000 portundaki process'in id'sini "lsof" ile tespit ediyoruz, sonra "kill" komutu ile sonlandırıyoruz.