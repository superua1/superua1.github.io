# NOT 1 : Understanding The Need For Systemd

Önceki init yazılımları sysvinit ve systemd kabuk dosyaları ile yani betikler ile konfigüre edildiği için daha karmaşıktır. 

Systemd ise basit konfigürsyon dosyaları barındırıyor. Aynı iş için kullanılan konfigürasyon dosyalarını kıyaslarsak aralarındaki farkı görebiliriz zaten.

### tutarlılık

diğer init yazılımların dağıtıma ve göreve göre değişiklik gösteren pek çok komutu kullanmamız gerekiyor. ancak systemd aracının ve bu aracın altındaki diğer yardımcı araçların kullanımı tüm dağıtımlar ortak olduğu için sistem yöneticisi olarak işimizi kolaylaştırarak tutarlılık sunuyor.

### systemd performans

paralel olarak başlatır

systemd ile süreçleri öldürmek için çok daha temiz bir yolumuz var. Örneğin, bir SysV makinesinde Apache web sunucusu hizmetini zorla sonlandırmak için kill komutunu kullanmanız gerekirse, yalnızca Apache işleminin kendisini sonlandırmış olursunuz. Örneğin, web sunucusu işlemi, çalışan CGI betikleri nedeniyle herhangi bir alt işlem üretmiş olsaydı, bu işlemler bir süre daha zombi işlemler olarak devam edecekti. Ancak bir hizmeti systemd ile kapattığınızda, o hizmetle ilişkili tüm işlemler de sonlandırılır.

### güvenlik

Belirli dizinlere veya dizinlerden erişimi kısıtlayabilen veya yalnızca belirli ağ adreslerine erişebilen veya bu adreslerden erişilebilen bir systemd hizmeti oluşturabilirsiniz. Ad alanlarını kullanarak, hizmetleri sistemin geri kalanından etkili bir şekilde yalıtabilirsiniz. Bu ayrıca Docker'ı çalıştırmak zorunda kalmadan kapsayıcılar oluşturmanıza da olanak tanır. Kaynak kullanımını sınırlamak için grup gruplarını kullanabilirsiniz. Bu, belirli hizmet reddi saldırı türlerinin önlenmesine yardımcı olabilir. Bir hizmetin hangi kök düzeyinde çekirdek yeteneklerine sahip olmasına izin verildiğini belirtebilirsiniz. Tüm bunlarla, systemd'nin SELinux veya AppArmor gibi zorunlu bir erişim kontrol sistemini bir şekilde taklit etmesini sağlayabilirsiniz. Her yönden, systemd, kendisinden önce gelen herhangi bir init sisteminden çok daha iyidir. Ama herkesi mutlu etmedi.

### itirazlar

Systemd hakkında dile getirilen temel itirazlar:

- Çok fazla şey yapmaya çalışarak systemd, Unix'in her bir yardımcı programın yalnızca bir şey yapmasına, ancak bunu iyi yapmasına ilişkin kavramını ihlal eder.
- Büyük bir şirket (Red Hat) tarafından kontrol ediliyor.
- Bu bir güvenlik sorunu.
- Günlük bileşeni, sistem günlüklerini, bazı kişilerin rsyslog'un oluşturduğu düz metin dosyalarından daha kolay bozulduğuna inandığı ikili bir biçimde kaydeder.

Bu karşıt görüşlerin de basit çözümleri mevcut:

- Evet, systemd ekosistemi yalnızca init sisteminden fazlasını içerir. Ayrıca ağ, önyükleyici, günlük kaydı ve oturum açma bileşenlerini içerir. Ancak bu bileşenlerin tümü isteğe bağlıdır ve tüm Linux dağıtımları bunları varsayılan kurulumda kullanmaz.
- Öncelikle Red Hat tarafından oluşturulmuştur ve proje lideri bir Red Hat çalışanıdır. Ancak Red Hat, bunu konuşmada ücretsiz bir yazılım lisansı altında yayınladı, bu da hiçbir şirketin onun tam kontrolünü ele geçiremeyeceği anlamına geliyor. Red Hat aniden systemd'nin gelecekteki sürümlerinin tescilli olacağına karar verse bile, ücretsiz kod hala orada ve birileri onu yeni bir ücretsiz sürüme çatallayacaktır.
- Evet, systemd'de bazı güvenlik hataları oldu. Ancak bu aynı zamanda OpenSSL, Bash kabuğu ve hatta Linux çekirdeğinin kendisi için de geçerlidir. Systemd'nin güvenliğinden şikayet etmek, yalnızca hatalar düzeltilmeseydi geçerli olurdu.
- Journald bileşeni, ikili biçimde günlük dosyaları oluşturur. Ancak rsyslog'u systemd dağıtımlarında çalıştırmak hala mümkündür ve çoğu bunu yapar. Red Hat Enterprise Linux 8 ailesi gibi bazı dağıtımlar, sistem bilgilerini toplamak için Journald'ı kullanır ve ardından normal metin dosyaları oluşturmak için yalnızca Journald'in bilgileri rsyslog'a geçirmesini sağlar. Böylece, RHEL 8 ile her iki dünyanın da en iyisine sahibiz.

Evet tüm bu söylediklerime karşı argümanlar da üretebilir ve ele aldığım çözümleri de beğenmemiş olabilirsiniz. Ancak benim bu eğitimdeki amacım pragmatik olmaktır. Özellikle işletmeleri hedefleyen büyük dağıtım geliştirici tüm bu artıları ve eksileri dikkate alarak systemd aracını kullanma kararı aldığı için ve bizler de günümüz şartlarının en verimli ve sık tercih edilen konseplerini öğrenmek istediğimiz için systemd öğrenimine pragmatik olarak yaklaşıp öğrenmemiz gerekenleri öğrenip yolumuza bakacağız.

[https://learning.oreilly.com/library/view/linux-service-management/9781801811644/B17491_01_Final_NM_ePub.xhtml#_idParaDest-29](https://learning.oreilly.com/library/view/linux-service-management/9781801811644/B17491_01_Final_NM_ePub.xhtml#_idParaDest-29)