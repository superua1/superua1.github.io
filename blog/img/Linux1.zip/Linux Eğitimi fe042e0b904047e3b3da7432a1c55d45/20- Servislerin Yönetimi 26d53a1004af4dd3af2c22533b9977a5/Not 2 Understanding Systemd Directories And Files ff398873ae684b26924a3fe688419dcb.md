# Not 2 : Understanding Systemd Directories And Files

Bu bölümde, systemd'nin çeşitli bileşenlerinin nasıl çalıştığını kontrol eden yapılandırma dosyalarına bakacağız. Kendi VM'nizle birlikte takip etmek istiyorsanız, hangi dağıtıma sahip olduğunuzun pek bir önemi olmayacak çünkü her şey sistemd-etkin dağıtımlarda çoğunlukla aynı olacaktır.

Daha önce tutuarlılıktan bahsederken systemd nin tüm sistemlerde aynı olduğundan bahsetmiştim. 

Bu söylediğim çelişkili değil. Çünkü tüm dağıtımlar systemd nin tüm bileşenlerini kullanmıyor olabilir. Aynı işi yapan farklı araçların kullanıldığı pek çok dağıtım var. Dolayısıyla sistemde systemd yüklü diye systemd nin sunduğu tüm bileşenlerin ve servislerin kullanıldığı anlamına gelmiyor.

Çünkü pek çok dağıtım hitap ettiği kitle dolayısıyla özelleştiği farklı yaklaşımları oluyor. Daha önce de belirttiğim şekilde systemd tüm özelliklerini kullanmayı dayatmadığı için kullanılan dağıtım istediği özelliği açıp istediğini devredışı bırakabiliyor. Bu durumdan eğitimde bahsediyor olacağız. Özetle systemd kullanımını bildiğinizde dilediğiniz dağıtım üzerinden mevcut özellikleri yönetebiliyor olacaksınız.

Örneğin systemd nin konfigürasyon dosyası için system.conf doyasına bakabiliriz. Dosyayı açtığımızda pek çok tanımlamanın bulunduğunu görebiliyoruz. Fakat bunların hepsini tek tek ele almayacağız elbette. Zaten istisnalar hariç buradaki konfigürasyonları değişrmeniz gerekmeyecektir. Dolayısıyla buradaki tüm özellikleri aklınızda tutmanız pek mümkün ve mantılı değil. Bunun yerine ihtiyacınız olduğunda ilgili dosya hakkında manuel yani kılavuz safyalarına göz atıp ilgili özelliğin açıklamasını okuyabilirsiniz. Doğru manuel sayfasını bulmak için systemd- ifadesinden sonra konfigürasyon dosyasının ismini yazmanız çoğu zaman yeterli. Örneğin system.conf dosyası için man systemd-system.conf komutunu kullanabilirsiniz.

Ayrıca apropos gibi araçlar yardımıyla da man sayfaları üzerinde araştırma yapabilirsiniz. Zaten bu konulardan bahsettik.

Ayrıca, tüm bu yapılandırma dosyalarında her satırın yorumlandığını fark etmiş olabilirsiniz. Bu, o satırların hiçbir etkisi olmadığı anlamına gelmez. Bunun yerine, bunların derlenen varsayılan parametreler olduğu anlamına gelir. Bir şeyi değiştirmek için, istenen parametre satırının yorumunu kaldırır ve değerini değiştirirsiniz. Zaten yorum satırılarından bahsettik. Tek yapmanız gereken diyez # işaretini kaldırmak.

Eğer konfigürasyon dosyaları içindeki tüm yönergeler hakkında bilgi almak istersek systemd.directives manuel sayfasına da göz atabiliriz. Burada konfigürasyon dosyalarında kullanılabilecek tüm varsayılan tanımlamaların listesini görebiliyoruz. Bu liste üzerinden ilgili tanımlamanın hangi manuel sayfasında açıklandığını öğrenebiliyoruz. Ve görebileceğiniz gibi bu liste gerçekten de çok uzun. Ben üstünkörü geçiyorum ancak burada farklı kategorilere ayrılmış şekilde pek çok özellik bulunuyor. Belki bu liste gözünüzü korkutmuş dahi olabilir. Ancak endişelenmeyin çünkü daha önce de söylediğim gibi bu manuel sayfaları ihtiyaç duyduğunuzda bakabilmeniz için var. Buradaki tüm bilgiye sahip olmak zorunda değilsiniz. Gerektiğinde kılavuz sayfaları bir komut uzağınızda olacak.