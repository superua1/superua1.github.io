# Sanallaştırma ve Kısaca Docker ?

KVM Proxmox Docker Kubernetes