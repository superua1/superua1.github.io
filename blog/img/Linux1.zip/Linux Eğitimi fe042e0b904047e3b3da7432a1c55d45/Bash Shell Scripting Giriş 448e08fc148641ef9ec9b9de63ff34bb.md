# Bash Shell Scripting Giriş

Anlatımlara başlamadan belirteyim, ben yalnızca komut satırı kullanımında çok temel düzeyde işlerinizi kolaylaştırabilecek birkaç kabuk programlama detayından bahsedeceğim. Yani benim burada ele alacağım kabuk programlama anlatımları kabuk programlamanın yüzde biri bile değil. Sadece sık ihtiyaç duyabileceğimiz birkaç yapıdan bahsedip kabuk programlamadan haberdar olalım istiyorum. Bu bölümün eğitimin geri kalanına kıyasla nispeten daha kısa olmasını bekliyorum. Belki uzun da olabilir ancak neticede bash kabuk programlamayı ele almak için her halükarda kısa olacak. Zaten kabuk programlama, daha önce komut satırı kullanımına uzun uzadıya değindiğimiz için yani bash kabuğu üzerinde gerekli olan temel altyapıya sahip olduğumuz için bizlere kolay gelecek. Yani komut satırı üzerinden işlerimizi nasıl yapabileceğimizi zaten biliyoruz, şimdi bu işleri nasıl programlayabileceğimize kısaca değiniyor olacağız. 

Koşullar

; && & || () [] {}  for if while function 

Evet neticede bash kabuk programlama için giriş düzeyinde temel bilgi sahibi olduk. Belki anlatımla çok kısa sürmedi ama yine de anlatımın başında da söylediğim gibi kabuk programlamanın belki yüzde birini bile ele alamadım. Ancak buradaki bilgiler kabuk programlamadan haberdar olmanız ve günlük işlerinizi kabuğu programlayarak daha verimli hale getirmeniz için bence yeterli. Zaten aslında kabuk programlama komut satırı üzerinden yürütebileceğimiz işleri programlayabilmemizi sağladığı için kabuk programlama yeteneğiniz aslında komut satırını ne kadar bildiğiniz ve etkili olarak kullandığınıza bağlı. Temel yapıları bildikten sonra geri kalanı tamamen sizin gayretiyle gelişebilecek kazanımlardır. 

Daha fazlası için öğrenmiş olduğunuz temel bilgilerden yola çıkarak araştırma yapabilir ve kendinizi kabuk programlamada ilerletebilirsiniz. Özellikle bash kabuğunun dokümantasyonu ve ileri seviye bash kabuk programlama dokümanları gerekli olan bilgileri sizlere sağlayacaktır.