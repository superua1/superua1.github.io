# Linux Modülleri ve Sürücüleri

Modül ne demek ?

Sürücü ile modül arasındaki fark nedir ?

Linux headers nedir ?

Sistem çekirdeği tam olarak hangi dosyada

Aktif olarak kullanılmayan modüller sistemi yavaşlatır mı yok ihtiyaç olduğunda ram e yüklenerek mi kullanılır. Yani modülleri silerek sistemi hızlandırmamız mümkün müdür ?

Neden tek bir çekirdek altında bu kadar çok modül var ve windows da mı böyle bir yaklaşım kullanıyor ?

Sürücü nasıl kurulur ?