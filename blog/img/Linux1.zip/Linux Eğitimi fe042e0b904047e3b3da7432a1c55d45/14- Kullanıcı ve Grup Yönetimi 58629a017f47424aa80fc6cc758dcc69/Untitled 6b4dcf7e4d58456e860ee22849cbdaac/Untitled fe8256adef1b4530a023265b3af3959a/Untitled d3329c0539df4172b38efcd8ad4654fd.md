# Untitled

#: w
diğer kullanıcılar: 2
dosyanın sahibi: 2
sahibiyle aynı gruptakiler: 2