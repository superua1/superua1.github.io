# Untitled

# Yetkileri Anlamak

# Kullanıcı İşlemleri

# Kullanıcı ve Grup Kavramları Üzerine

Her bir kullanıcının kullanıcı adı ve grup numarası olduğunu biliyoruz. Peki ama neden yalnızca kullanıcı adı yeterli gelmiyor da hem grup hem de kullanıcı numaraları tanımlanıyor ?

En yalın cevap bir kullanıcının veya grubun hangi sistem kaynaklarına erişebileceğini belirlemek için kullanılır.

Kullanıcı numarası user identifier yani kısaca UID ile temsil ediliyor. Bu numara, kullanıcıyı sisteme tanıtmak ve kullanıcının hangi sistem kaynaklarına erişebileceğini belirlemek için kullanılır.

0 root kullanıcısının kullanıcı numarasıdır 1000 ve üzeri numaralar da standart kullanıcılar tarafından kullanılır.

Grupların kullanılmasının nedeni ise gruba dahil olan kullanıcıların yetkilerini grup üzerinden yönetebilmektir. Grup yapısının faydalarını daha iyi anlayabilmek için öncelikle erişim yetkileri kavramından bahsetmemiz gerekiyor.

### Erişim Yetkileri

Sistem üzerinde her kullanıcının yalnızca kendi yetkisi olan işleri yapabileceğini daha önce sıklıkla dile getirdik. Örneğin ben sıradan bir kullanıcı olarak /root dizinindeki dosyaları görüntüleyemem çünkü yetkim yoktur. Denediğimde yetkilendirme hatası alırım. Yetkilendirme yapısı çok kullanıcılı sistemlerin güvenli şekilde yönetilebilmesi için elzemdir. 

Kullanıcıların dosya veya dizinler ile ilgili yapabileceği üç eylem bulunmaktadır. Bunlar;

**okuma(r):** Klasör listesini ve dosya içeriğini görüntüleme.

**yazma(w):** Dosya veya klasör üzerinde değişiklik yapma.

**çalıştırma(x):** Hedef dosyayı çalıştırma veya klasör içerisine erişme.

Ben somut örnekler üzerinden ilerleyebilmek için ls -l komutu ile bulunduğum dizindeki dosya ve klasörleri detaylıca listeliyorum. İşte bakın buradaki çıktıların yetkileri temsil ettiğini ls komutunu ele alırken öğrenmiştik. Şimdi ne anlam ifade ettiğini açıklayalım. En baştaki karakerin dosyanın türünü belirttiğini söylemiştik. En baştaki kararker hariç, yetkiler üçerli şekilde üçlü harf kümesinden oluşur. İlk küme dosya sahibinin izinlerini, ikinci küme kullanıcı ile aynı grupta olan kullanıcıların izinlerini son küme ise ilk iki grupta yer almayan geriye kalan herkesi temsil eder.

Buna göre çıktılarda bulunan izinleri açıklayacak olursak;

**r :** read yani okuma yetkisini temsil eder

**w :** write yani yazma yetkisi temsil eder

**x :** execute yani çalıştırma yetkisi temsil eder

Örneğin ilk küme **rwx ise :** dosyanın sahibi olan kullanıcı; dosyayı okuyabilir, içerisine yeni veri yazabilir ve dosyayı çalıştırabilir.

İkinci küme ise rw ise : dosya sahibi ile aynı grupta olan kullanıcılar; dosyayı okuyabilir, içerisine yeni veri yazabilir ancak çalıştırmazlar

Son küme rx ise: dosyanın sahibi olmayan ve dosyanın sahibi ile aynı grupta bulunmayan tüm diğer kullanıcılar dosyayı okuyup çalıştırabilir.

Ayrıca ilgili dosyanın kimin dosyası olduğu burada belirtilirken, bu dosya sahibinin grubu da burada açıkça belirtiliyor. Yani ilk yetki kümesi buradaki dosya sahibini etkiliyorken, ikinci küme de buradaki gruba dahil olan kullanıcıları etkiler. Gerektiğinde yetkilerini düzenleyebilmemiz için bu bilgiler de bastırılmış oldu.

İşte gayet net anlaşılabildiği gibi buradaki karakterler okuma yazma ve çalıştırma izinlerini temsil ediyor. Bu bilgiye bakarak sistem kimlerin hangi dosyalarda nelere yapabileceğine karar veriyor.

Elbette dosya ve klasörler sonsuza kadar sabit yetkilerle kalmazlar. Yetkili olan kullanıcı dosya veya klasörlerin erişim izinlerini istediği gibi düzenleyebilir. İzinleri düzenleme noktasında da bizlere daha önce de kullandığımız chmod komutu yardımcı olur.

## **Yetkilerin Değişimi(chmod)**

Erişim yetkisini değiştirme işlemini, ancak en yetkili kişi olan root yapabilir. Bu değişim işlemi; daha öncede de kullandığımız `chmod` komutu sayesinde gerçekleştirilir. chmod dosya ve klasörlerin erişim izinlerinin değiştirilmesini sağlar.

`chmod` komutunun parametrelerini tanıyarak örnek verme işlemine geçelim.

**u :** Dosya-dizinin sahibi

**g :** Dosya-dizinin sahibi ile aynı grupta bulunan kullanıcılar

**o :** Diğer kullanıcılar

**a :** Herkese açık.

**= :** Yetki eşitleme

**+ :** Yetki ekleme

- **:** Yetki çıkarma

Genel parametreleri gördüğümüze göre gelin birkaç örnek yapalım.

Örnek göstermek adına anlatımı, içerisindeki dosyaların hiç birinde yetkinin bulunmadığı bir klasör üzerinden gerçekleştireceğim.

İlk olarak klasörde yer alan dosyaların herhangi bir yetkiye sahip olmadıklarını teyit etmek için ayrıntılı çıktı almak üzere `ls -l` komutunu kullandık.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/3.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/3.png)

Daha sonra klasörde yer alan tüm dosyalara `*` joker karakteri ile ulaştık ve `chmod +w *` komutumuzu kullanarak **herkese açık** olacak şekilde **yazma(w)** yetkisi verdik.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/4.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/4.png)

**Aynı grupta bulunan kullanıcılar** için, yine konumumuzda bulunan tüm dosyaları `*` sayesinde kapsayacak şekilde `g+rx *` komutumuzu verdik.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/5.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/5.png)

Gruptaki kullanıcılara(g), okuma-yazma-çalıştırma yetkisi (rwx), kullanıcıya(u) yazma yetkisi(r), diğer kullanıcılara ise yalnızca çalıştırma yetkisi(x) verdik.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/6.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/6.png)

Ve en son yine bulunduğumuz konumdaki tüm dosyaların yetkilerini kaldırdık.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/7.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/7.png)

Bu kullanımların dışında yetkilendirme işlemleri daha önceden de rastladığımız ve fark etmeden de olsa kullanmış olduğumuz sayısal şekilde de ifade edilebiliyor.

Bu durumu yetkilerin sayısal karşılığını vererek anlatmaya devam edelim.

Yetki kalıplarının sayısal karşılıkları.

[Untitled](Untitled%206b4dcf7e4d58456e860ee22849cbdaac/Untitled%20fe8256adef1b4530a023265b3af3959a.md)

Yetkilerin sayısal değerlerini kullanarak bir örnek yapalım.

Örneğin biz sadece dosyanın sahibine bütün yetkileri vermek istiyoruz diyelim. Bunun için ilk başta yetki kalıplarının numara karşılıklarını toplamalıyız. Yani bütün yetkileri vereceğimiz için r=4+w=2 +x=1=toplam sayı 7 etti. Bizler de sadece dosya sahibine bu yetkiyi vermek istediğimizden normalde vereceğimiz `chmod rwx- -----` komutumuzu diğer kullanıcılara yetki vermek istemediğimiz için o alanları 0 bırakarak komutu `chmod 700 dosya` şeklinde veriyoruz. Böylelikle sadece dosyanın sahibi tüm yetkilere sahip olmuş oluyor.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/8.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/8.png)

Daha net anlaşılması adına bir örnek daha yapalım. Şimdi de; dosyanın sahibine tüm yetkileri, ortak gruptakilere yalnızca yazma yetkisini, diğer kullanıcılara da sadece okuma yetkisini verelim.

Dosya sahibi kullanıcıya verilecek tüm yetkiler için `r(4)+w(2)+x(1)=7` sayısını kullanacağız.

Dosya sahibi ile ortak gruptaki kullanıcılar için vereceğimiz yazma yetkisi için **yazma(w)** karakterinin sayısal karşılığı olan `2` sayısını kullanacağız.

Diğer kullanıcılar için vereceğimiz yalnız okuma yetkisi için ise **okuma(r)** karakterinin sayısal karşılığı olan `4` sayısını kullanacağız.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/9.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/9.png)

Çıktıdan da anlaşılacağı üzere sayısal karşılıklar istediğimiz yetkilendirme işlemini gerçekleştirdi.

Son bir ayrıntı daha verelim. Eğer verdiğimiz izinlerin o dizinle beraber alt klasörlerinde de etkili olmasını istersek komutumuzu `-R` parametresi ile birlikte kullanmalıyız.

Örneğin bulunduğum konumdaki "**metin**" isimli klasörün erişim yetkilerini listeledim. Sonuç olarak hiçbir yetkinin bulunmadığını belirten --------- şeklinde bir çıktı geldi.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/10.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/10.png)

Daha sonra "**metin**" isimli klasörün içerisine girerek oradaki dosya ve dizinlerin erişim izinlerini sorguladım. Sonuç olarak rwxrwxrwx şeklinde bütün yetkilere sahip dosya ve dizinlerin olduğunu gördüm.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/11.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/11.png)

Daha sonra bir üst dizine dönerek ekleyeceğim erişim izinlerinin tüm alt dosyalarda dahil olmak üzere, geçerli olması için komutuma ek olarak `-R` parametresini kulladım ve komutumu `chmod -R 422 metin` şeklinde yazdım.

![https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/12.png](https://raw.githubusercontent.com/taylanbildik/Linux_Dersleri/master/img/8-%20Eri%C5%9Fim%20Yetkileri/12.png)

Sonuç olarak bütün dosya ve dizinlerde ve alt klasörlerde dahil olmak üzere tüm dosyaların vermiş olduğum yetki erişim izinleri **422** ifadesine karşılık gelen; dosya sahibi için okuma(**r**) , dosya sahibi ile aynı gruptaki kullanıcılar için yazma(**w**) ve diğer kullanıcılar için de yazma(**w**) yetkisi şeklinde yetkilendirildiğini görmüş oldum.

Eğer örneklere ve açıklamalara rağmen yine de anlamadıysanız ister konuyu tekrar okuyup kendiniz de alıştırmalar yapın isterseniz de bu konuyu şimdilik geçin ihtiyacınız olduğunda burada olduğunu bilerek tekrar göz atın. Seçim sizlere kalmış.

### Klasörlerin İzinleri hakkında

r: klasörün içindeki dosya ve dizinleri görüntülemeye izin verir

w: yeni dosya ve klasör oluşturmaya izin verir.

x: dosyayı açıp içine girmeye yani dizine giriş izni verir. bir klasörün okunma yetkisi var ancak çalıştırma yoksa içeriğini görüntüleyebilirsiniz ancak cd gibi bir komutla dizine geçiş yapamazsınız.

# Grup Yönetimi

Artık erişim yetkilerinden de haberdar olduğumuza göre grupların esas amacını rahatlıkla kavrayabiliriz. 

Yeni bir kullanıcı hesabı oluştururken gözlemlediğimiz gibi, sisteme her yeni kullanıcı hesabı eklendiğinde, tek üyesi bu kullanıcı olan ve kullanıcı adıyla aynı ada sahip bir grup oluşturulur. Diğer kullanıcılar daha sonra gruba eklenebilir. Bu sayede erişim yetkilerini açıklarken söylediğimiz kullanıcı ile aynı grupta bulunan kullanıcılar ortaya çıkmış olur. 

Grupların amaçlarından biri, bu kaynaklar üzerinde doğru izinleri ayarlayarak dosyalara ve diğer sistem kaynaklarına basit bir erişim denetimi uygulamaktır. Bir gruba birden fazla kullanıcı eklersek, tek seferde gruptaki tüm kullanıcıların erişim yetkilerini etkileyecek değişiklikler yapabiliriz. Zaten gruplar bunun için var.

Ben bu durumu test etmek için hemen üç yeni kullanıcı oluşturacağım. Kullanıcıların isimlerini de kullanici1 kullanici2 ve kullanici3 şeklinde ayarlayacağım.

Kullanıcı hesaplarını oluşturdum. Şimdi de bir dosya üzerinden grup mekanizmasının nasıl çalıştığını görmek için cat > [komut.sh](http://komut.sh) yazıp içerisine echo "ben çalıştım" şeklinde yazıyorum. Bu oluşturmuş olduğum dosya basit bir betik dosyası. Çalıştırdığımda konsola ben çalıştım şeklinde çıktı basacak. Bu dosya üzerinden tüm yetkileri test edebiliriz. Bu dosyayı ben oluşturduğum için dosyanın yetkilerini istediğim şekilde değiştirebilirim. Ben dosyanın sahibine yani kendime tüm yetkileri veriyorum. Benimle aynı gruptaki kullanıcılara okuma ve çalıştırma yetkisi veriyorum. Diğer kullanıcılara ise yalnızca okuma yetkisi veriyorum. ls -l komutu ile atadığım yetkileri de teyit ediyorum. Şimdi kullanici1 ve kullanici2 yi kendi hesabının grubuna ekleyip kullanici3 için herahngi bir değişiklik yapmayacağım. 

Gruba ekleme işlemi için daha önce gördüğümüz usermod aracını kullanacağız. Bu araç ile kullanıcıları kendi grubuma dahil edeceğim. Usermod aracının -a seçeneği append yani ekleme işlevindedir. büyük G ise grupları temsil eder. Kullanici 1 ve kullanici2 yi eklemek için usermod -a -G komutunun ardından eklemek istediğim grubu yazmam gerekiyor. Kendi kullanıcı hesabımının grup adını giriyorum. Zaten benim kullanıcı adım ile aynı. Daha sonra eklemek istediğim kullaniciları virgülle ayırarak yazıyorum. Neticede kullanıcıları gruba ekledim. /etc/group dosyasına bakarak da bu durumu teyit edebilirim. Bakın kendi grubunun sonunda eklediğim kullanıcı isimleri de bulunuyor. Bu son kolon zaten gruba dahil edilen kullaniciları temsil ediyor.

Gruba eklemeyi başardığımıza göre artık yetkileri ve yetkilerin gruplar üzerindeki etkisini test edebiliriz. Ben test emek için öncelikle kullanici 1 hesabına geçiş yapıyorum. Komut dosyası benim ev dizinimde olduğu için öncelikle yetkilerini tekrar görmek adına ls -l /home/taylan/[komut.sh](http://komut.sh) şeklinde dosyamın bilgilerini konsola bastırıyorum. Bakın sahibi tüm yetkilere sahipken sahibiyle aynı gruptakiler yani örneğin şu an geçiş yaptığım kullanıcı yalnıza okuyup çalıştırabiliyor, dosya içeriğini değiştirmeye yetkisi bulunmuyor. Teyit etmek için öncelike dosya içeriğini cat komutu ile okumayı deneyelim. Bakın sorunsuzca okuyabildim. Şimdi bir de çalıştırmayı deneyelim. Bakın sorunsuzca çalıştırabildim. Son olarak dosyaya echo "ekleme" >> komut.sh şeklinde komut girerek dosyaya yazma yetkim olup oladığını teyit etmek istiyorum. Bakın erişim reddedildi. Böylelikle kullanıcı ile aynı gruba dahil olan hesaba tanımladığımız erişim yetkilerinin doğru şekilde çalıştığını bizzat test etmiş olduk. İsterseniz aynı gruba dahil ettiğimiz kullanıcı2 için de aynı testleri yapıp gruplara eklenen kullanıcıların bu dosyada tanımlı olan ortak yetkilere sahip olduğunu teyit edebiliriz. Hemen denemek için geçiş yapıyorum. Öncelikle dosyamı okumayı deneyeceğim. bakın içeriği görüntüleyebiliyorum. şimdi çalıştırmayı deneyelim. çalıştırırken de yetkim olduğu için sorun yaşamadım son olarak üzerine yeni veri eklemeyi yani içeriğine veri yazmayı deneyelim. bakın tıpkı kullanici1 de olduğu gibi erişim hatası aldım. çünkü her iki kullanıcı hesabı da ortak grupta ve bu grubun bu dosya üzerindeki yetkileri de dosyada değişiklik yapmalarına müsade etmiyor. Bakın tek bir grup üzerinden birden fazla kullanıcının yetkileri kolayca kontrol edebildik. Testi nihayete erdirmek için üçüncü küme yani dosya sahibi olmayan veya dosya sahibi ile aynı grupta bulunmayan diğer kullanıcı üzerinden dosya üzerindeki erişim yetkilere göz atabiliriz.

Diğer kullanıcıların yalnızca dosyayı okuma yetkisi bulunuyor. Ben öncelikle okumayı denyiyorum. Bakın sorunsuzca okuyabildim. Şimdi içeriğine veri eklemeyi yani yazma yetkisini test edelim. Gördüğünüz gibi erişim reddeildi. Çünkü buna yetkim yok. SOn olarak da dosyayı çalıştırmayı deneyip testimizi nihayete erdirelim. Bakın çalıştırma girişimim de reddedildi çünkü diğer kullanıcıların çalıştırma yetkisi de bulunmuyor. 

Ben örnek olarak dosya kullandım ancak elbette aynı durum klasörler üzerinde de geçerli. Dosya veya klasörün durumuna göre hangi kullanıcıların bu dosya üzerinde ne gibi yetkileri olacağını ayarlayabilirsiniz. 

# Grup Oluşturmak

Yalnızca kullanıcıların gruplarını kullanmak yeterli olamayabilir. Eğer belirli kişilere belirli dosya ve klasörler üzerinde yetki tanımlamak istiyorsanız ihtiyacınıza göre yeni grup da oluşturabilirsiniz. Yeni grup oluşturmak için groupadd komutunu kullanıyoruz.

Uygulamalı şekilde örnek yapabilmek için öncelikle TEST isimli bir klasör oluşturuyorum. Bu klasöre kimlerin erişebileceğini belirleyerek güzel bir pratik yapabiliriz. 

Ben örnek olarak iki yeni grup oluşturmak istiyorum. OKU ve DUZENLE isimli iki grup oluşturabilirim. Okuyucu grubundaki kullanıcılar yalnızca okuyup çalıştırabilecek. Düzenleyici grubundakiler ise tüm yetkilere sahip olacak. 

Öncelikle groupadd OKU ve daha sonra groupadd DUZENLE komutları ile yeni iki grubunu oluşturuyorum.

Şimdi benim şu an kullanmakta olduğum hesap dışında sistemimde daha önceden oluşturduğum üç kullanıcı hesabı daha bulunuyor. Ben yalnızca okuma ve çalıştırma yetkisine sahip olmalarını istediğim iki kullanıcıyı OKU guruba ekleyeceğim. Diğerini de tüm yetkileri vermek için DUZENLE guruba ekleyeceğim.

Gruba ekleme için daha önce de kullandığım usermod komutunu kullanabilirim.

Gruba ekleme yapacağım için öncelikle append yani ekleme seçeneğini yazıyorum. Ve grubu belirtmek için büyük G seçeneğini yazıp hemen ardından grubun ismini giriyorum. Gruba eklemek istediğim kullanıcıları da virgülle ayırarak yazıyorum. Böylelikle kullanici1 ve kullanici2 yi OKU guruba eklemiş oldum. Şimdi de kullanici3 ü DUZENLE gurubuna ekleyelim. usermod -a -G DUZENLE kullanici3. Böylelikle kullanıcıları istediğimiz gruplara ekledik. Şimdi başta oluşturduğum TEST klasörüne grup tanımlamamız gerek.

groupadd [options] [group_name]

Grubu Düzenlemek

groupmod [options] groupname

Bir kullanıcıyı birden fazla gruba eklemek

useradd -G group1,group2,group3 [username]

Giving groups permissions to directories

[https://www.linux.com/topic/desktop/how-manage-users-groups-linux/](https://www.linux.com/topic/desktop/how-manage-users-groups-linux/)

chown

Grubu Düzenlemek

Using access control lists

Grubu Silmek

groupdel groupname

# chattr

Linux'taki chattr komutu, bir dizindeki bir dosyanın özniteliklerini değiştirmek için kullanılan bir dosya sistemi komutudur. Linux'ta dosya öznitelikleri, dosyanın davranışını tanımlayan meta-veri özellikleridir. Zaten bu pek çok dile getirdik. Dilersek dosyaların özniteliklerinden bazılarını istediğimiz şekilde değiştirebiliriz. chattr komutu da change attributes yani öznitelikleri değiştirmenin kısaltmasıdır. 

[https://linuxize.com/post/chattr-command-in-linux/](https://linuxize.com/post/chattr-command-in-linux/)

# PAM (Pluggable Authentication Modules)

[https://www.tecmint.com/manage-users-and-groups-in-linux/comment-page-2/#comments](https://www.tecmint.com/manage-users-and-groups-in-linux/comment-page-2/#comments)