# ✅ 7- Dizinlerde Gezinti

# Dizinler Hakkında

Linux işletim sisteminde bütün programlar, aygıtlar, dosyalar ve genel olarak sistemin tüm ögeleri, hiyerarşik bir düzen içerisinde çeşitli klasörlerde tutuluyor. Normalde eğer grafiksel arayüzdeyken dizinlerde gezinti yapacaksak, dosya yöneticisi aracını kullanarak istediğimiz dizinlerde gezinti yapıp dizinlerin içeriğini görüntüleyebiliyor ya da gerektiğinde düzenleyebiliyoruz. Örneğin ben kendi masaüstümde bir klasör oluşturmak için dosya yöneticisinden masaüstü klasörüne gelip sağ tıklayıp istediğim isimde bir klasör oluşturabilirim. Bakın dosya yöneticisinde hem de masaüstü arayüzünde yeni oluşturduğum klasör gözüküyor. Neticede gördüğünüz gibi grafiksel arayüzdeyken dosya yöneticisi sayesinde dizinlerde gezinip istediğim düzenlemeyi kolayca gerçekleştirebiliyorum.

Grafiksel arayüze benzer şekilde söz konusu komut satırı üzerinden sistemi yönetmek olduğunda da tabiki işlerimizi tek bir dizin altında yürütmeyeceğimiz için komut satırındayken de dizinler arasında rahatlıkla gezinebiliyor olmamız gerekiyor. İşte bu bölümde, dizinlerde rahatlıkla gezinme ve görüntüleme için gerekli komutlara tek tek değiniyor olacağız. Yani bölümün sonunda, komut satırı üzerinden tüm sistemdeki dizin hiyerarşisi içinde rahatlıkla gezinebiliyor olacaksınız. Anlatımlarımıza öncelikle hangi dizinde olduğumuzu nasıl öğrenebileceğimizle başlayabiliriz.

# pwd Komutu

Hani bir yeri ziyaret ettiğimizde karşımıza çıkan haritalarda şu an buradasınız şeklinde yazar ya işte bunun komut satırı  arayüzündeki karşılığı da tam olarak pwd komutu.

![Untitled](%E2%9C%85%207-%20Dizinlerde%20Gezinti%20b3e238d1bcd74b82a0861d9745815209/Untitled.png)

Bu komut sayesinde mevcut bulunduğumuz dizinin tam adresini öğrenebiliyoruz. pwd komutu, İngilizce "**p**rint **w**orking **d**irectory" yani "çalışma dizini yazdır" ifadesinin kısaltmasından geliyor. Özellikle komutun açılımından ve ingilizce karşılığından da bahsettim çünkü komutların açılımlarını ve İngilizce karşılıklarını bilirsek, daha sonra ilgili komutları çok daha kolay hatırlayabiliyoruz. Çünkü genellikle komutların açılımları görevleri ile ilişkili oluyor. Bu sebeple ben de eğitim boyunca mümkün oldukça komutların ingilizce açılımlarından ve Türkçe karşılıklarından da söz etmeye çalışacağım.

Komutumuzu test etmek için öncelikle komut satırımızı açalım. Komut satırımız ilk açıldığına kabuk varsayılan olarak bizim mevcut kullanıcı hesabımızın ev dizinimizde çalışmaya başlıyor.

Bu durumu teyit edebilmek için hemen komutumuzu girelim.

```jsx
pwd
/home/taylan
```

Bakın hemen bir dizin adresi çıktı olarak bastırıldı. Bu dizin benim şu an komut satırı arayüzünde bulunduğum dizini temsil ediyor. Kısaca aldığım çıktının anlamını açıklamam gerekirse, bu çıktı benim şu anda kullanmakta olduğum kullanıcının ev dizininde çalışmakta olduğumu belirtiyor. Daha net görebilmek adına grafiksel arayüz üzerinden de bizzat kontrol edebiliriz. Bunun için hemen dosya yöneticisini açalım. Zaten bakın, dosya yöneticim de varsayılan olarak benim kendi ev dizinimde açılıyor. Burada benim biraz önce de yeni klasör oluştururken gördüğümüz gibi masaüastü dizinimi temsil eden klasör var, dokümanlarımı ya da indirilen dosyaları saklayabileceğim kişisel klasörlerin de var. İşte burası şu anda kullandığım taylan kullanıcısına ait olan ev dizinidir.

Bu dizinin benim ev dizinim olduğunu ve aldığımız çıktının anlamını iyi kavrayabilmemiz için ben öncelikle hemen dosya sistemi hiyeraşisinin en tepe noktasına geçiş yapıp oradan tekrar bu dizine kadar gelerek size bizzat göstermek istiyorum. Bunun için buradan diğer lokasyonlar kısmına tıklayalım. Burdan da dosya sistemi hiyeraşisinin başlangıç noktasına ulaşmak için bilgisayar kısmına tıklayalım. Bakın şu an gördüğümüz tüm bu klasörler, mevcut işletim sistemini oluşturan dosyaları barındıran klasörler. Burada bulunduğum dizin işletim sisteminin dosyalarını barındıran tüm dosya ve klasörlerin en tepe noktası. Hemen burada sağ tıklayıp, özelliklerine bi göz atalım. Bakın bulunduğumuz dizinin ismi slash karakteri olarak gözüküyor. Komut satırı arayüzünde aldığımız çıktıya da dönecek olursak bakın çıktının en başında slash işareti bulunuyor. Heh, işte bu slash işareti tam olarak şu anda dosya yöneticisi üzerinden görüntülediğimiz bu dizini temsil ediyor. Zaten ismi de burada görebildiğiniz gibi slash olarak geçiyor. Bu slash dizini tüm işletim sistemini oluşturan dosyaları barındıran en tepedeki dizin. Diğer tüm dosya ve klasörler bu dizin altındaki diğer klasörlerin altında bulunuyor. Çıktıda en baştaki slash karakterinden sonra gözüken home dizini de bakın bu ana dizin altındaki home klasörü aslında. Bu klasör isminden de anlaşılabileceği gibi tüm standart kullanıcıların ev dizinlerini barındıran klasör, hemen giriş yapıp içine bakalım. Bakın burda benim şu an kullandığım taylan kullanıcısı ve daha önce örnek için oluşturduğum ali kullanıcısı adına iki farklı klasör bulunuyor. Benim aldığım çıktıda ben taylan kullanıcısı olduğum için ev dizinim taylan klasörü altında bulunuyordu. Hemen görmek adına bu klasöre girelim. Bakın dosya yöneticisini ilk açtığımda karşıma çıkan dizin içeriğine yine ulaşmış oldum. Hatta teyit etmek için yeni bi dosya yöneticisi penceresi de açabiliriz. Bakın, ben şu anda taylan kullanıcısının ev dizininde bulunuyorum. İşte konsol üzerinden aldığımız çıktı, tıpkı bizim grafiksel arayüzden de adım adım takip ettiğimiz gibi benim ev dizinimi temsil ediyor. Yani ben taylan kullanıcısı olarak konsolumu ilk açtığımda tıpkı dosya yöneticisinde de olduğu gibi kendi ev dizinimden çalışamaya başlıyorum.

Neticede konsolun ilk açıldığında kullanıcının ev dizininden çalışmaya başladığını ve pwd komutunun da kabuğun o anda çalışmakta olduğu dizinin bilgisini verdiğini bizzat teyit etmiş olduk. Hatta bu aldığımız çıktının grafikel arayüzdeki dizinin tam karşılığı olduğuna kesin olarak ikna olmak isterseniz buradan sağ tıklayıp yeni bir konsol başlatıp yine pwd komutunu girebiliriz. Bakın konsol burada başlatıldığı için yine aynı çıktıyı aldık.

Aslında çok basit bir yapı. Üstelik ileride dosya sistemi hiyerarşisini ayrıca ele aldığımızdaki buradaki anlatımları çok daha net kavramış olacaksınız. Hatta dilerseniz farklı bir dizine geçip, konsolu burada açarak pwd komutunu tekrar test edebiliriz. Denemek için yeni bir dizine geçiyorum ve konsolu burada açıyorum. Şu an bulunduğum dizini grafiksel arayüz sayesinde zaten biliyorum. Bir de pwd komutu ile teyit edeyim. Bakın yine bulunduğumuz dizini yani ev dizinimizin adresini konsola bastırmış olduk.

Bence artık pwd komutunun işlevi tam olarak anlaşılmıştır. Komut satırı arayüzündeyken hangi dizinde çalıştığınızı merak ediyorsanız pwd komutunu kullanmanız yeterli.

Ayrıca pwd komutu dışında eğer dikkatinizi çektiyse hangi dizinde çalıştığım aslında ismimden sonra konsolda prompt olarak isimlendirilen bölgede de gözüküyor zaten. Yani pwd komutunu kullanmadan da buraya bakarak, hangi dizinde olduğumu kolaylıkla öğrenebiliyorum. Hatta bakın ilk açtığım konsolda ev dizinde çalıştığım için ev dizinim tilde işareti ile temsil ediliyor. Zaten hatırlıyorsanız daha önce de Linux'ta kullanıcıların kendi ev dizinlerinin tilde işareti ile temsil edildiğinden bahsettik. Bu sebeple burada ben uzun uzadıya /home/taylan/ dizini yerine bu dizinle aynı anlama gelen tilde işaretini görüyorum. 

İleride farklı dizinlerde çalışırken bu dizinlerin promt alanında belirtiğini görücez ama ben yine de hemen teyit etmek için dosya yöneticisinden masaüstü klasörüne girip buradan da sağ tıklayıp konsolumu burada açmak istiyorum. Bakın açılan konsol benim şu anda ev dizinim altındaki Desktop klasöründe çalıştığımı promt bölümünde açıkça belirtiyor. Hatta ek olarak teyit etmek istersek pwd komutunu da kullanabiliriz. Bakın /home/taylan/Desktop çıktısını aldım. Eğer promt alanındaki bilgi ile karşılaştıracak olursak buradaki tilde işareti benim ev dizinimi yani home taylan dizini temsil ediyor, Desktop da zaten mevcut konsolu başlattığım masaüstü dizinim. Yani pwd komutu ile de teyit ettiğimiz gibi promt alanına bakarak, o an hangi dizinde çalıştığımız hakkında kolayca bilgi sahibi olabiliyoruz.

Aslında tıpkı çalışmakta olduğumuz dizini öğrenebildiğimiz gibi promt olarak geçen bu bölümden başka bazı bilgiler de edinebiliyoruz. Ancak konumuzdan çok fazla uzaklaşmamak adına yeri geldiğinde ayrıca değinmek üzere prompt konusunu şimdilik noktalayalım. Ama aklınızda bulunsun prompt gerçekten önemli bir yapı. Tıpkı burada bahsettiğimiz gibi gerektiğinde epey bilgi verici olabiliyor. 

Konumuza dönecek olursak promt üzerinde gözüken bu dosya bilgisi her ne kadar kullanışlı olsa da her zaman buradan bilgi edinemeyeceğiniz birkaç istisnai durum var. Öncelikle bu özellik her sistemde promt için konfigure edilmemiş olabilir. Yani sizin kullanmakta olduğunuz sistemdeki konfigürasyonlar gereği bulunduğunuz dizinin bilgisi bu şekilde size promtda sunulmuyor olabilir. Bunun haricinde çalıştığınız dizin adresi çok uzun olduğu için komut satırında doğru şekilde görüntülenemiyor da olabilir. 

Dolayısıyla her ne kadar promtta yer alan, çalışmakta olduğumuz dizinin bilgisi faydalı olsa da, çalıştığımız dizin hakkında en okunaklı bilgiyi çoğunlukla yine pwd komutu sayesinde ediniyoruz. Zaten sizler de sıklıkla pwd komutunu kullanıyor olacaksınız. 

Mevcut bulunduğumuz dizin hakkında yeterince bilgi sahibi olabildiysek bence artık yavaş yavaş komut satırı üzerinden dizinlerde nasıl gezinebileceğimizden bahsederek devam edebiliriz. 

Giriş dersi olduğu için anlatım yaparken, daha anlaşılır ve adımların kolay takip edilebilir olması için grafiksel arayüzdeki dosya yöneticisini kullandık. Fakat tabii ki bu durum, dizinlerde gezinmek için her zaman grafiksel arayüzü kullanacağımız anlamına gelmiyor. Esasen sizin de fark edebileceğiniz gibi grafiksel arayüzü kullanmak pek de verimli değil. Çünkü gitmek istediğimiz dizine ulaşmak için grafiksel arayüzde adım adım klasör isimlerini bulup üzerine tıklayıp geçiş yapmamız gerekiyor. Yani hiç de verimli bir yol değil. Eğer sistemi konsol üzerinden yönetebilmek istiyorsak, konsol üzerinden istediğimiz dizinlerde gezinebilmeli ve dizin içeriklerini görüntüleyebilmeliyiz. Gelin şimdi konsol üzerinden sistemde nasıl gezinebileceğimizi öğrenerek devam edelim.

# cd Komutu

Dizinlerde gezinmek için İngilizce "change directory" yani "dizini değiştirme" ifadesinin kısaltmasından gelen cd komutunu kullanıyoruz. Sistemi yönetirken sıklıkla dizinlerde gezinmemiz gerekeceği için cd komutu belki de en sık kullanacağımız komutların başında geliyor. Dizin değiştirmek için tek yapmamız gereken cd komutundan sonra gitmek istediğimiz dizinin tam adresini belirtmek. Komut satırı ile dizinlerde gezinmekten bahsedeceğiz ancak tüm işlemleri kolayca takip edebilmek adına yine grafiksel arayüz üzerinden yani dosya yöneticisi üzerinden de adımları bire bir takip edebiliriz. Örneğin ben bulunduğum dizini bastırıyorum. Görebildiğiniz gibi ben şu anda kendi ev dizinimde bulunuyorum. Dosya yöneticisinde de aynı şekilde ev dizinimdeyim.

Eğer komut satırında çalışıyorken ev dizinimde yer alan Desktop dizinine geçiş yapmak istersem `cd Desktop` şeklinde komutumu girebilirim. Tekrar pwd komutunu kullanarak veya doğrudan promt üzerindeki bilgi ile de teyit edebildiğimiz üzere bakın şu an Desktop dizinine geçiş yapmış bulunuyorum. İşte dizinler arası geçiş için kullandığımız cd komutunun en temel kullanımı bu şekilde. Grafiksel arayüzdeyken de Desktop dizinine geçiş için buradan klasörün üzerine tıklamam da yeterli oluyor.

Komut satırındayken dizin değiştirmek için girdiğimiz komutta, grafiksel arayüzden de teyit edebildiğimiz gibi mevcut bulunduğumuz dizindeki bir klasörlere geçiş yapmak için yalnızca ilgili klasörün ismini yazmamız yeterli oldu. Yani ben ev dizinimdeydim, ev dizinimde de desktop klasörü bulunuyordu. Bu sebeple yalnızca cd Desktop komutu ile desktop klasörüne kolayca geçiş yapabildim. Yani yalnızca klasörün ismini yazarak geçiş yapmak için zaten halihazırda o klasörün bulunduğu dizinde olmak gerekiyor. Aksi halde kabuk benim hangi dizine gitmek istediğimi zaten bilemez. 

Ben bu örnekte bulunduğum dizinde yani ev dizinimde yer alan Desktop klasörüne geçiş yaptığım için yalnızca klasör ismini yazmam yeterli oldu. Heh işte bu kullanıma releative path yani göreli yol deniyor. Peki göreli yol ne demek diyecek olursanız: Göreli yol yalnızca bulunduğunuz dizinden itibaren geçerli olan yolu tasvir ediyor.

Ne demek istediğimi bir örnekle açıklamam gerekirse.

Örneğin geçiş yapmak istediğim klasör mevcut çalışmakta olduğum dizin içinde bulunmuyorsa, bu klasörün dosya sistemi hiyerarşisindeki tam dizin adresini belirtmek zorundayım. Örneğin ben ana dizindeki etc dizini altında yer alan apt klasörüne gitmek istiyorsam cd komutunun ardından /etc/apt komutunu girmem gerekiyor. Burada ilk girdiğim slash kök dizinini yani ana dizini temsil ederken, etc ile apt arasında yer alan ikinci slash işareti ise etc dizini atlındaki apt klasörüne geçiş yapılması gerektiğini belirtiyor. Yani ben belirttiğim bu dizin adresi ile, öncelikle kök dizinine yani ana dizinine gidilmesi gerektiğini oradan da etc dizinine geçiş yapılması gerektiğini son olarak da apt isimli klasöre geçiş yapılması gerektiğini belirtmiş oluyorum. İlk slash işaretinden sonraki slash işaretleri, dizin isimlerini birbirinden ayırmak için kullandığımız bir sembol. Hemen geçiş yapmak için komutumuzu girelim. Bakın promt üzerinde geçiş yaptığımız gözüküyor. Ayrıca pwd komutu ile de teyit edebiliriz. Bakın ben şu anda etc dizini altındaki apt klasöründe bulunuyorum. Peki bu dizine bir anda nasıl atlayabildik ? Tabii ki ilgili dizinin tam dosya yolunu belirterek. 

İlgili dizinin tam adresini verdiğim için kabuk tek seferde sorunsuzca ilgili dizini bulup geçiş yapabildi. Buradaki tam adresten kastım, sistem üzerindeki tüm dizinler kök dizininden başladığı için kök dizini de dahil ederek ilgili dizine giden yolun tüm bilgisini adım adım sunmak. 

Bu durumu grafiksel arayüz üzerinden de teyit edebiliriz. Öncelikle kök dizine yani tüm dosya sistemi hiyeraşisinin başlangıcı olan ana dizine geçelim. Tamamdır. Şimdi adım adım ilerleyecek olursak: Bizim girdiğimiz komutta, öncelikle tüm dizinlerin başlangıç noktası olan ana dizine git, oradan etc dizinine geçiş yap buradan da apt klasörünün içine gir demiş olduk. Bakın ben tüm dizinlerin başlangıç noktası olan ana dizinden itibaren bu yolu takip ettiğimide gitmek istediğim dizine sorunsuzca ulaşabiliyorum. Bu şekilde belirtilen dizin adreslerine de absolute path yani kesin yol deniyor. 

Göreli yol bulunduğumuz dizinden itibaren geçerli olan adresin tarif edilmesiyken, kesin yol ilgili adresin dosya sistemi hiyeraşisinin en tepe noktasından başlanarak eksiksizce tarif edilmesiyle oluyor. 

İşte dizinler arasında gezinirken en çok dikkat etmeniz gereken detay bu göreli yol ve kesin yol kavramları. Zaten anlaşılması sön derece kolay. Hadi emin olmak için benzer örneği yanlış şekilde tekrar ele alalım ve grafiksel arayüzden de takip ederek bizzat tüm adımları teyit edelim. Daha önce ben kendi ev dizinimde olduğum için yalnızca cd Desktop komutunu girerek kendi masaüstü klasörüme geçiş yapmıştım. Şimdi aynı komutu girip yine masaüstüme geçiş yapmayı deneyebilirim. 

Bakın böyle bir dosya veya klasör bulunmuyor diye hata aldık çünkü gerçekten de bulunduğumuz apt klasörü içinde Desktop isminde bir klasör bulunmuyor. Ben bu etc dizini atlındaki apt klasöründeyken göreli şekilde yani cd Desktop şeklinde komutumu girdiğimde, kabuk mevcut dizindeki Desktop isimli klasöre geçiş yapmak istediğimi düşünüyor ancak bu dizinde bu isimde bir klasör bulunmadığı için doğal olarak hata verdi. Hatta grafiksel arayüzden de kontrol edebiliriz. Bakın apt klasörü içinde Desktop isimli bir klasör bulunmuyor. Şimdi aynı komutu bu kez kendi ev dizinimdeki Desktop klasörünün tam dizin adresini belirtecek şekilde yani kesin yolunu belirtecek şekilde de girmeyi deneyebilirim. Öncelikle bu yola grafiksel arayüzden bakalım. Ben bunun için kök dizine geri dönüyorum. Şimdi buradan kullanıcıların ev dizinlerini barındıran home dizinine geçiş yapalım. Ben burdan kendi kullanıcım için geçerli olan taylan dizinine geçiş yapıyorum. Bakın burası benim ev dizinim ve Desktop klasörü de burada yer alıyor. Artık  tek yapmam gereken bu dizine geçiş yapmak. En nihayetinde bakın kök dizinden itibaren adım adım Desktop dizinine ulaşmamızı sağlayan kesin yolu takip etmemiz yeterli oldu. Şimdi aynı örneğimi komut satırında yapacak olursak, öncelikle kök dizini temsil etmesi için komutumun en başına slash işaretini eklememiz gerekiyor. Daha sonra sırasıyla home dizini buradan da taylan dizini ve son olarak da desktop dizinini aralarında slash işareti ile ayırarak belirtmemiz yeterli olacak. Komutumuzu onaylayalım. Bakın kesin yolu belirterek gitmek istediğim Desktop dizinine komut satırı üzerinden de sorunsuzca erişebildim. 

Bakın bizzat örnekler üzerinden de teyit ettiğimiz gibi eğer geçiş yapmak istediğiniz klasör çalışmakta olduğunuz mevcut dizinde bulunmuyorsa, ilgili klasörün **tam dizin adresini** yani kesin yolunu belirtmeniz gerekiyor. Tüm dizinler kök dizin atlında olduğu için yani tüm dizinler kök dizininden başladığı için de tam dizin adresini belirtirken en kolay yöntem kök dizinden başlayarak ilgili dizini temsil eden tam dizin yolunu eksiksiz olarak belirtmektir. Eğer geçiş yapacağınız klasör zaten kabuğun halihazırda çalışmakta olduğu dizinin içinde veya altında bulunuyorsa o zaman göreli konumu kullanabilirsiniz. Göreli konum belirtirken dizin adresinin en başına slash işaretini eklememiz gerekmiyor çünkü en baştaki slash işareti kök dizine gidilmesi oradan diğer dizinlere geçiş yapılması gerektiği anlamına geliyor. 

Örneğin ben tekrar ev dizinime dönmek için /home/taylan/ şeklinde komutumu girebilirim. Ancak ev dizinindeyken örneğin Desktop isimli klasöre geçiş yapmak için cd /Desktop şeklinde komut girersem bakın yine böyle bir dosya veya dizin yok şeklinde hata alıyoruz çünkü bu komutumuzla, öncelikle kök dizine gitmemiz gerektiğini oradan da Desktop isimli klasöre geçiş yapılması gerektiğini belirtimiş. Oluyoruz ancak bakın grafiksel arayüzden de teyit edebildiğimiz gibi kök dizin altında Desktop isimli bir klasör bulunmuyor. Bunun yerine mevcut bulunduğumuz dizin altındaki Desktop klasörüne geçmek için yalnızca komutumuzu en başta slash olmadan yani cd Desktop şeklinde girmemiz gerekiyor. Bakın, olay tamamen o anda hangi dizinde olduğunuz ve hangi dizine geçiş yapmak istediğinizle ilgili. Kabuk sihirli bir biçimde bizim gitmek istediğimiz dizini kendi kendine bilemeyeceği için bizim o anda bulunduğumuz ve gitmek istediğimiz dizinlere göre uygun şekilde komut girmemiz gerekiyor.

Bu açıklamaları yapıp göreli ve kesin yol üzerinde özellikle duruyorum çünkü yeni başlayan çoğu kullanıcı tam dizin adresi belirtirken kök dizinini temsil eden en baştaki slash işaretini unutabiliyor. Ya da tersi şekilde mevcut bulunduğu dizin altındaki bir klasöre geçiş için en başta slash ekleyip ilgili dizinin kök dizini altında olmamasına rağmen kök dizinde aranmasına sebep olabiliyor. Neticede kabuğa doğru adres tarif edilmezse, kabuk da doğru dizini bulup geçiş yapamıyor. Gerçek dünyadaki yol tarifleri gibi düşünün, yanlış yol tarifiyle doğru adrese gitmemiz mümkün değil. Lütfen bu detaya dikkat edin. Benim anlatımlarımla sınırlı kalmayın mutlaka bu konuda pratik yapın. Zaten pratik yaptığınızda kesin yol ve göreli yol kavramını net biçimde kavrayacaksınız çünkü benim anlattığımdan çok daha kolay bir konu aslında. Yani uygulamak, anlatmaktan çok daha kolay. Tek ihtiyacınız bizzat pratik yapıp işleyişi kavramak.

Neticede komut satırı üzerinden dizinlerde gezinmek için cd komutunu kullanabildiğimizi öğrendik. Ancak söz konusu komut satırı üzerinde rahatlıkla gezinebilmek olduğu için cd komutunun bize pek çok kolaylıkla sağlayan esnek özellikleri de bulunuyor.

Gelin şimdi de bunlardan bahsederek komut satırı üzerindeki hakimiyetimizi arttırmaya devam edelim.

### Üst Dizine Geçiş

Öncelikle bir üst dizine nasıl kolayca dönebileceğimizden bahsederek devam edebiliriz.

Örneğin ben ev dizinimdeyken cd Desktop komutunu kullandığım için benim ev dizinimde bulunan bir alt klasör olan Desktop klasörüne geçiş yapmış oldum. Bu durumda benim ev dizinim yani taylan klasörü bir üst dizin oluyor, çünkü Desktop dizini taylan dizinin içinde. Eğer ben bir üst dizine yani taylan dizinine dönmek istersem `cd ..` komutunu kullanabilirim. Bakın pwd komutu ile de teyit edebildiğimiz gibi bir üstteki dizine yani taylan dizinine kolayca dönmüş oldum.

Kabuk için tek nokta mevcut dizini temsil ederken iki nokta işareti ise bir üst dizini temsil ediyor. Yani iki nokta kullandığınızda kabuk bir üst dizini kast ettiğinizi biliyor.

Bu komut yerine bir üst dizine dönmek için `cd /home/taylan/` komutunu da kullanabildim ancak gördüğünüz gibi bu kadar zahmete hiç gerek yok. İki nokta sayesinde bir üst dizini otomatik olarak belirtebiliyorum zaten.

Hatta bakın tekrar cd .. komutunu kullanırsam, bu kez de bir üst dizin olan ev dizinlerini barındıran home dizinine geçiş yapabiliyorum. Bu şekilde istediğim kadar üst dizine geçiş yapabilirim. Üstelik tek tek `cd ..` komutunu kullanmak yerine tek seferde, gidilecek daha üst dizinleri de belirtebiliriz. Denemek için ben tekrar `cd /home/taylan/Desktop` komutu ile ev dizinimdeki Desktop klasörüne geçiş yapıyorum. Şimdi tek seferde birden fazla dizin atlamak için kök dizine kadar atlayabileceğim cd ../../../ komutunu giriyorum. Peşi sıra dizin atlamak için elbette dizinleri slash işareti ile ayırmak gerek yoksa cd komutu ne demek istediğimiz anlayamaz. Bakın en üsteki dizin olan ana dizine tek seferde dönmüş oldum. pwd komutu ile de bu durumu teyit edebiliriz. 

Buradaki ilk iki nokta beni Desktop dizininden çıkardı, ikinci iki nokta, taylan dizininden çıkardı, üçüncü iki nokta ise home dizininden çıkardı. Neticede kök dizine ulaşmış oldum. Tıpkı iç içe olan dizinlere geçiş yaparken olduğu gibi tek yapmamız gereken peşi sıra iki nokta karakterini kullanırken üst dizinlere geçiş yapmak istediğimizin anlaşılması için bu iki nokta karakteri arasında slash işaretini belirtmek

Ayrıca bir üst dizine gidip, başka bir dizine geçiş de yapabilirsiniz. Örnek gösterebilmek için tekrar masaüstü dizinine geçiş yapabiliriz. Örneğin ben /home/taylan/Desktop dizininden doğrudan `/home/taylan/Downloads` dizinine geçiş yapmak istersem normalde bunu uzun uzun `cd /home/taylan/Downloads` şeklinde belirtmem gerekiyor. Ancak aslında bunun yerine cd ../Downloads komutu ile bir üst dizine dönüp Downloads klasörüne geçiş yapabilirim. Bu komutla kabuğa, bir önceki dizine dön oradan da Downloads klasörüne geçiş yap demiş oluyoruz. Bakın aslında bu da göreli bir yol. Neticede bir üst dizinde Downloads klasörünün yer aldığını bildiğimiz için mevcut bulunduğumuz konumdan iki nokta işareti ile bir üst dizine döndük, daha sonra slash işaretinin ardından yazdığımız için Downloads isimli klasöre de geçiş yapabildik. Grafiksel arayüzden de bakacak olursak bakın, masaüstü dizinindeyken ben size bulunduğun dizinden bir üst klasöre dön oradan da Downloads klasörüne geçiş yap dersem aynen komutumuzda olduğu gibi bulunduğumuz konuma göre hareket ediyoruz.

Zaten komutlarınızı girerken de dosya sistemindeki dizinlerin iç içe klasörlerden oluştuğunun bilincinde olduğunuz sürece üst veya alt dizinde olma duruma göre uygun komutu kolaylıkla verebilirsiniz. 

Dizinler arası geçiş biçimi tamamen sizin ihtiyaçlarınıza göre şekillenecektir. Tek yamanız gereken bildiklerinizi harmanlayıp kullanmak. Bu noktada elbette kesin yol ve göreli yol kavramını iyi bir biçimde anlamış olmanız gerekiyor. Eğer anladıysanız zaten dizinler arasında son derece esnek yöntemlerle gezinebilirsiniz.

Göreli yol kavramını ve klasörlerin iç içe olma durumunu iyi anlayıp anlamadığınızı test etmek için size basit bir soru sormak istiyorum. Örneğin bakın ben şu anda kendi ev dizinim altındaki Downloads klasörü içindeyim. Eğer şimdi konsola /../ komutunu girersem ne olur ? Yani hangi dizine geçiş yaparım ? Dikkat edin soru ilk bakışta şaşırtıcı olabilir. Hadi komutumuzu onaylayalım. Şimdi bir de bulunduğumuz dizini pwd ile bastıralım. Bakın bir anda /home/taylan/Downloads dizininden kök dizine geçiş yapmışız. Siz de böyle olacağını tahmin etmiş miydiniz. Eğer ettiyseniz tebrik ederim, şimdiye kadar bahsettiğim tüm kavramları net biçimde anlamış olmakla birlikte gayet dikkatlisiniz de. Girdiğimiz komuta tekrar dönecek olursak aslında bakın ben en başta kök dizinini temsil eden kök dizine gidilmesi gerektiğini oradan da bir önceki dizine dönülmesi gerektiğini belirten bir komut girmiştim. Kabuk da önce kök dizine gidip oradan da bir önceki dizine dönmeyi denedi ancak kök dizinden önceki dizin diye bir yer olmadığı için tekrar kök dizinde kaldı. Yani aslında benim girdiğim komuttaki iki nokta karakteri en baştaki slash işareti dolayısıyla önemini yitirdi çünkü slash dizinine geçiş yaptıktan sonra bir üst dizin diye bir şey de yok. Umarım bu son örnek kafanızı karıştırmamıştır. Ben sadece cd komutuna girdiğimiz ilk slash karakterinin her koşulda kök dizini temsil ettiğini kavrayabilmemiz için dikkat çekici bir örnek vermek istedim.

Neticede bir üst dizine geçiş yapmayı da öğrendiğimize göre sıklıkla kullanacağımız bir önceki adrese hızlı geçiş kısayolundan bahsederek devam edebiliriz.

### Bir Önceki Dizine Dönüş

Komut satırı üzerinden işlerimizi hallerken kimi zaman birbirinden çok uzak dizinler arasında hızlıca geçiş yapmak isteyebiliriz. Bu durumda en son bulunduğumuz bir önceki dizine doğrudan atlamak için cd komutunun ardından yalnızca tire işaretini yani kısa çizgiyi kullanmamız yeterli oluyor.

Ne demek istediğimi örnek üzerinden çok net biçimde anlayacaksınız. Ben denemek için öncelikle `cd /etc/apt` komutu ile etc dizini altındaki apt dizinine geçiş yapıyorum. Siz dilediğiniz bir dizine geçiş yapabilirsiniz. Ben şu anda /etc/apt dizinindeyim. Test etmek için kullanıcımın Desktop dizinine `cd /home/taylan/Desktop` komutu ile geçiş yapıyorum. Şu anda da Dekstop dizinindeyim gördüğünüz gibi. Eğer bir önceki bulunduğum dizine yani /etc/apt dizinine dönmek istersem tekrar `cd /etc/apt` komutu ile dönebilirim. Ama buna şu an gerek yok. Çünkü yalnızca `cd -` komutunu kullanarak da, bir önceki dizine otomatik olarak geçiş yapabiliyorum. 

Bakın bir önceki çalıştığım dizine tek seferde geçiş yaptım ve geçiş yaptığım dizin de konsola basıldı. Bu sayede hangi dizine dönmüş olduğumun farkına varabiliyorum. Aynı işlemi tekrar uygulayarak bir önceki dizine yani Desktop dizinine de dönebiliriz. Bakın kısacık bir komut ile bir önceki dizin adresine anında atlayabiliyorum ve atlama işlemini kolay takip edebilmem için geçiş yaptığım dizin konsola da bastırılıyor. Bence müthiş bir kolaylık.

Kabuk her zaman bir önceki dizinin adres bilgisini tuttuğu için bu şekilde bir önceki çalışmakta olduğumuz dizine `cd -` komutu ile hızlıca geçiş yapabiliyoruz. Bu komut özellikle, iki dizin arasında gidip geliyorken işlerimizi inanılmaz kolaylaştırıyor. Neticede uzun uzadıya önceki çalıştığımız dizini yazmamıza gerek kalmıyor. Bu özellik grafiksel arayüz kullanımından bile çok daha pratik bir gezinti deneyimi sağlıyor, haksız mıyım ?

Hazır daha iyi bir gezinti deneyi ve pratiklikten bashetmişken tabii ki otomatik tamamlama nimetlerinden  bahsetmesek olmaz.

### Otomatik Tamamlamadan Faydalanmak

Daha önce kısayollar bölümünde bahsettiğimiz otomatik tamamlama özelliği sayesinde geçiş yapabileceğimiz dizin isimlerinin otomatik olarak tamamlanmasını da sağlayabiliriz. Zaten kısayollar bölümünde bu duruma da değinmiştik. Şimdi tekrar deneyebiliriz. Örneğin ben cd /home/taylan/ komutunu yazdıktan sonra iki kez tab tuşuna basarsam, bakın taylan dizininde yer alan gidebileceğim olası dizinler karşıma listeleniyor. Gitmek istediğim dizinin birazını yazıp örneğin Des yazıp tekrar tab tuşuna basarsam bakın klasör ismi otomatik olarak Desktop a tamamlanıyor. Benzer şekilde örneğin cd /home/ yazıp iki kez tab tuşuna basarsam bakın yine home dizini altında bulunan gidilebilecek olası dizinler yani ali ve taylan klasörleri listeleniyor. Zaten bizzat gördüğümüz gibi tab ile tamamlama işlevi, yalnızca ilgili dizinin içinde bulunan diğer dizinleri karşımıza getiriyor. Zaten mantıken de olması gereken bu. Örneğin siz /home/taylan/ dizinlerine geçiş yaptıktan sonra bir anda etc dizinine geçiş yapmak istemeyeceğiniz için taylan klasörü altındaki klasörlerden birine mi geçmek istiyorsunuz diye kabuk size öneri sunuyor. Dolayısıyla bulunduğunuz dizine göre, size sunulacak tamamlama önerileri de otomatik olarak değişiyor tabii ki.

Örneğin ben otomatik tamamlanmanın ne kadar hayat kolaylaştırıcı olduğunu denemek için cd yazıyorum ve slash h karakterinden sonra tab tuşuna basıyorum bakın home dizini otomatik tamamlandı. Şimdi de t yazıp tab a basıyorum bakın şimdi de taylan dizini otomatik tamamlandı bir de büyük M yazıp tab tuşuna basıyorum bakın Music klasörünün ismi de tamamlandır. Neticede çok az komut ile otomatik tamamlama özelliği sayesinde kolayca istediğim dizine geçiş yapabildim. Otomatik tamamlama özelliğinin komutların tamamını yazmamıza gereke bırakmıyor olması harika ayrıca dikkat edecek olursanız aslında tab otomatik tamamlama önerileri bize her zaman sahip olduğumuz opsiyonlar hakkında da fikir veriyor. Örneğin daha önce mevcut dizindeki dosya ve klasörleri listelemek için özellikle ls komutunu kullanmıştık. Ancak bunun yerine dilersek tab tuşu ile de olası seçeneklerimizi anında görebilme kolaylığına sahibiz. Tabii ki anlatımın devamında da ayrıca ele alacağımız gibi ls komutunun listeleme konusundaki yetenekler çok daha fazla ancak ben yine de otomatik tamamlama sayesinde en azından pratik şekilde komut satırı arayüzünde önümüzü görebilmemizin mümkün olduğuna vurgu yapmak istedim. Yani gerektiğinde tabii ki ls komutunu kullanıyor olacağız. Ancak bunun dışında tab ile de genel önerilere ulaşabiliyoruz.

Yani özetle otomatik tamamlama özelliği sayesinde seçeneklerimizi görebiliyor ve gerektiğinde uzun uzadıya yazmadan otomatik olarak tamamlanmasını sağlayabiliyoruz. Gerçekten harika bir özellik. Kullanımına alıştıktan sonra zaten sürekli kullanıyor olacaksınız ve çalışma veriminizi kesinlikle arttıracak. 

Şimdi cd komutuyla birlikte kullanabileceğimiz bir diğer kısayoldan bahsederek devam edecek olursak, ev dizinimizi temsil eden tilde işaretinin kullanımına da kısaca tekrar değinebiliriz. 

### Ev Dizini Kısayolu

Hatırlıyorsanız daha önce de tilde işaretinin mevcut kullanıcının ev dizinini temsil ettiğini söylemiştik. Şimdi bu durumu uygulamalı olarak tekrar cd komut üzerinden de teyit edebiliriz. Örneğin ben kendi ev dizinime geçiş yapmak istediğimde cd /home/kullanııc adım yani /home/taylan/ şeklinde komut girmem gerekiyor. Ancak aslında bu şekilde uzun uzadıya kendi ev dizinimi belirtmem de şart değil.  Bunun yerine yalnızca cd ~ komutunu kullandığımda zaten buradaki tilde işareti otomatik olarak benim ev dizin adresimin yerine geçiyor olacak. Eğer tilde işaretini nasıl oluşturabileceğinizi hatırlamıyorsanız tilde işaretini oluşturmak için klavyenizden AltGR ve Ü tuşlarına aynı anda basmanız yeterli. Bakın kolayca tilde işaretini oluşturabiliyorum.

Ben teyit edebilmek için öncelikle cd /etc/ komutu ile etc dizine geçmek istiyorum. Şu an ben etc dizinindeydim. Buradan kendi ev dizinime dönmek için tek yapmam gereken cd komutundan sonra tilde işaretini ekleyip komutumu onaylamak. Bakın kendi ev dizinime doğrudan geçiş yaptım, peki bunu nerden anlıyorsun diyecek olursanız bakın prompt bölümünde benim ev dizinimi temsil eden tilde işareti bulunuyor. Hatta ek olarak pwd komutu ile da teyit edebiliriz, bakın ev dizinimin çıktısını aldım yani kendi ev dizinime tilde işareti ile kolayca geçiş yapılabildiğini bizzat teyit ettik. 

Ayrıca ben burada tilde işaretini tek başına kullandım ama aslında tilde işaretini tek başına kullanıp yalnızca ev dizinine geçiş için kullanmak zorunda da değiliz. Ev dizinimiz altında yer alan dizinlere kolayca geçiş yapmak için de tilde işaretini kullanabiliyoruz. Örneğin ben kendi ev dizinimdeki Dekstop klasörüne geçiş yapmak istersem cd ~/Desktop komutunu kullanmam yeterli oluyor. Bu komutu nerede kullanırsam kullanayım, tilde işareti benim ev dizinimin adresine genişletileceği için otomatik olarak kendi kullanıcı hesabımın ev dizini altındaki Desktop klasörüne geçiş yapabiliyorum. 

Hatta başka kullanıcıların ev dizinlerine ulaşmak için komutumuzu cd ~kullanıcı-adı şeklinde kullanma imkanımız da var. Örneğin ben ali kullanıcısının ev dizinine geçiş yapmak istersem komutumu cd ~ali şeklinde girmem yeterli. Bakın anında ali kullanıcısının ev dizine kolayca geçiş yapabildim. Yani sizler de gerektiğinde yalnızca tilde işaretini kullanarak kendi ev adresinize ulaşabileceğiniz gibi tıpkı bu örnekte de olduğu gibi farklı kullanıcıların ev dizinlerine ulaşmak için de tilde işaretini kullanabilirsiniz. Oldukça kullanışlı olduğu için zaten tilde işaretini sıklıkla kullanıyor olacağız. 

Bir de hazır yeri gelmişken tilde işareti haricinde kendi ev dizinimize hızlıca geçiş yapmak için yalnızca cd komutunu kullanabileceğimizi de belirtmek istiyorum. Bakın ben şu anda ali kullanıcısının ev dizinindeyim. Kendi hızlıca kendi ev dizinime dönmek için cd komutunu kullanmam yeterli. Bakın hangi dizinde olursak olalım, cd komutunu tek başına kullandığımızda kendi ev dizinimize kolayca geçiş yapabiliyoruz. Bu da sıklıkla kullanacağımız bir kısayol.

Belki şu an öğrendiklerinizin etkisi çok büyük gibi gelmiyor olabilir ancak aslında burada öğrendiğiniz bilgiler ile yetkiniz olduğu sürece tüm dosya sisteminde rahatlıkla gezinebilirsiniz. Yani öğrendikleriniz aslında komut satırı üzerindeki hakimiyetiniz için çok değerli bilgiler. Neticede şimdiye kadar temelde cd komutu hakkında bilmemiz gerekenlerden bahsettik ancak ben yine de son olarak cd komutunu kullanırken dikkat etmeniz gereken birkaç detaydan daha bahsetmek istiyorum. Çünkü yeni öğrenen kişiler tarafından cd komutu kullanılırken bu hatalar sıklıkla yapılabiliyor.

Dikkat etmenizi istediğim ilk ve bence en sık yapılan hatalardan biri kesin yol belirtirken kök dizini belirtmek için kullandığımız en baştaki slash işareti. Daha önce en baştaki slash işaretinin kök dizini temsil ettiğini ve bu sebeple tam dizin adresi belirtilirken unutmamanız gerektiğini birden fazla kez söylemiştim. Bu önemli bir detay olduğu için tekrar hatırlatmak istiyorum.

![Untitled](%E2%9C%85%207-%20Dizinlerde%20Gezinti%20b3e238d1bcd74b82a0861d9745815209/Untitled%201.png)

İleride ayrıca ele alacağımız bu hiyerarşik dosya sistemine bir bakacak olursak zaten sistemi oluşturan tüm klasörlerin kök dizinden başladığını görebiliyoruz. Ayrıca alt dizin ve üst dizin yaklaşımını da net biçimde görebiliyoruz. Örneğin bakın ali kullanıcısının ev dizini kök dizini altındaki home klasöründe yer alan ali isimli klasörde bulunuyor. Home dizininde olan birisi için ali klasörü alt dizinken, kök dizin ise bir üst dizini temsil ediyor. Komutlarımızı da bu doğrultuda girmemiz gerekiyor. Hatırlatacak olursak, mevcut bulunduğumuz dizin tek nokta işareti ile temsil ediliyorken, bir üst dizin iki nokta işareti ile temsil ediliyor. Yani örneğin home dizini içindeyken bir üst dizine dönmek için cd .. şeklinde komutumuzu kullandığımızda kök dizine dönmüş oluyoruz. Bunun dışında home dizini içinde bulunan herhangi bir klasöre yani alt klasöre geçiş için de ilgili klasörün ismini girmemiz yeterli oluyor. Örneğin cd ali komutu ile alttaki ali klasörüne kolayca geçiş yapabiliyoruz. Heh işte buradaki durum göreli yola örnek. Home dizininde yer alan birine göre ali klasörü bir alttaki dizindir dolayısıyla yalnızca cd ali komutu ile bu dizine geçiş yapılabilir. Ya da benzeri şekilde ali dizini içinde olan birisi için cd .. göreli komutu bir üst dizini yani home dizinini temsil ediyorken, home dizinindeki birisi cd .. komutunu girdiğimde bir üstündeki kök dizini temsil etmiş oluyor. İşte zaten kök dizinden başlayan kesin bir yol rotası belirtmeden girdiğimiz komutların hepsi mevcut bulunduğumuz dizine göre, gitmek istediğimiz dizinin nerede olduğuyla ilgili. Bu sebeple bu yola göreli yol diyoruz.

Ayrıca alt dizin ve üst dizine geçişler dışında yani göreli yol dışında, dosya sistemi üzerinde o anda hangi dizinde olduğumuz fark etmeksizin kök dizini kullanarak kesin dizin yolunu belirtip çok farklı konumlardaki dizinlere ulaşmamız da mümkün. Örneğin ben ali kullanıcısının ev dizinindeyken etc dizini atlındaki apt klasörüne geçiş yapmak istersem cd /etc/apt dosyas komutu ile kesin yolunu belirterek, öncelikle kök dizine gidilmesi oradan etc dizinine geçilmesi ve son olarak da apt klasörüne geçilmesi gerektiğini kolayca ifade edebilirim. Eğer komut girerken en baştaki slash işaretini atlarsam, kök dizini belirtmeyeceğim için mevcut bulunduğum dizinde etc isimli bir klasöre oradan da apt isimli klasöre geçmek istediğimi belirtmiş olacağım için geçiş işlemi yapılamaz. Çünkü mevcut bulunduğum dizin ile gerçekte gitmek istediğim etc apt dizini aynı dizin kesişimine sahip değil. Mevcut bulunduğum dizinin altında bu isimde klasörler bulunmuyor, dolayısıyla geçiş de yapılamıyor.

Neticede buradaki basit hiyerarşik şemaya bakarak bile, hiyerarşik dosya yapısına uygun olmayan yani gerçekte var olmayan dizin adresleri belirttiğimizde ilgili dizine geçiş yapamayacağımızı açıkça görebiliyoruz. Doğru komutlar girebilmek için kesin yol ve göreli yol kavramını anlayana kadar kendi kendinize alıştırmalar yapın lütfen.

Göreli ve kesin yol kavramları dışında değinmek istediğim bir diğer husus dizin isimlerindeki boşluklar ve özel karakterlerin varlığı. Daha önce kabuğun nasıl çalıştığından bahsederken, kabuğun girilen komuttaki boşluk karakterlerinden komutu ayrı ayrı argümanlara ayırdığından ve kabuk için özel anlam ifade eden karakteri de özel olarak ele aldığından bahsetmiştik. İşte eğer biz komut girerken bir dosya veya klasör isminde boşluk karakteri veya kabuk için özel anlam ifade eden bir karakter varsa kabuk bizim girdiğimiz komutu yanlış anlayabiliyor. 

Bu sebeple isminde özel karakterler veya boşluklar içeren klasörlerin doğru algılanabilmesi için klasör isimlerini tırnak içinde yazmamız gerekiyor. Ben basit bir örnek olması için isminde boşluk bulunan bir klasör oluşturacağım. Klasör oluşturmak için ileride ayrıca ele alacağımız mkdir komutunu kullanabiliriz. mkdir komutunun ardından tırnak içinde klasörün adını "yeni klasor" şeklinde yazıyorum. Eğer komutumuzu tırnak içinde yazmazsak mkdir aracına yeni ve klasör olmak üzere iki ayrı argüman verilecek dolayısıyla iki farklı klasör oluşturacak. Ben ismi tam olarak “yeni klasor” olan bir klasör oluşturmak istediğim için tırnak içinde yazıyorum ve komutumu onaylıyorum. Bu komut sayesinde ismi yeni klasör olan klasörüm oluşturuldu. Teyit etmek için ls komutunu kullanabiliriz. Bakın gerçekten de “yeni klasör” isimli klasörün oluşturuduğunu ls komutunu çıktılarından da teyit edebiliyoruz. Hatta bakın çıktılardaki klasörün tek bir klasörün ismini temsil ettiğini anlayabilmemiz için klasör ismi bu çıktılarda da tırnak içinde gösteriliyor. Zaten bu şekilde gösterilmese yeni ve klasor isimli iki ayrı klasör mü yoksa ismi yeni klasör olan ek bir klasör mü olduğunu buradaki çıktılar bakarak anlamamız mümkün olmaz. En nihayetinde tırnak içinde yazdığım için içerisinde boşluk karakteri bulunan klasör isimini dahi kullanabildim.

Burada dikkat etmeniz gereken detay tek tırnak kullanmanızdır. Aslında bu örnek için çift tırnak kullansak da sorun yaşamazdık ancak size önerim içerisinde boşluk veya özel karakter barından komutlarınızda bu komutların özel anlamının tamamen görmezden gelinmesi için tek tırnak içinde yazmanızdır. 

Buradaki tek ve çift tırnak konusunu çok kısaca teyit etmek istersek hemen denemek için echo $SHELL şeklinde komutumuzu girebiliriz. Bakın girdiğim komut neticesinde kabuk $SHELL ifadesini gördüğünde bu SHELL değişkeninin değerini yani mevcut kabuğun hangisi olduğu bilgisini konsol bastırıyor. Şimdi sırasıyla bu değişkeni çift ve tek tırnak içinde yazıp sonuçları kıyaslayabiliriz. Ben öncelikle çift tırnağı teyit etmek için echo “$SHELL” şeklinde çift tırnak içinde komutumu giriyorum. Bakın kabuk yine buradaki değişkeni gördüğünde bu değişkenin değerini konsola bastırdı çünkü bu değişken çift tırnak içinde yazılmıştı. Şimdi aynı komutu bu kez tek tırnak içinde tekrar yazalım. Bakın bu kez değişken değerine genişletilmedi çünkü buradaki $SHELL ifadesi tek tırnak içinde olduğu için kabuk tarafından bu tek tırnak içindeki ifadelerin hepsi sıradan tek bir argüman olarak değerlendirildi. Yani dolar işareti sembolünün kabuk üzerindeki özel anlamı da görmezden gelindi. 

İşte zaten ben de bu sebeple eğer içinde özel sembol veya boşluk bulunan bir argümanın kabuk tarafından sıradan tek bir argüman olarak değerlendirilmesini istiyorsanız, tek tırnak kullanın diyorum.

Tek ve çift tırnağın anlamına kısaca değindik ve daha sonra bu durumun öneminden ayrıca tekrar bahsedeceğiz. Örneğimize dönecek olursak neticede içinde isminde boşluk bulunan klasörüm çalışmakta olduğum dizinde oluşturuldu. Eğer ben bu klasöre geçiş yapmak için `cd yeni klasor` şeklinde komut girersem, gördüğünüz gibi kabuk çok fazla argüman şeklinde bir hata döndürüyor. Kabuğun kendisine verilen komutları aralarındaki boşluklar sayesinde ayrı ayrı argümanlar olarak gördüğünü ve işleme aldığını biliyoruz. İşte biz `cd` komutundan sonra `yeni klasor` komutunu girdiğimizde kabuğa hem "yeni" hem de "klasor" olarak iki ayrı argüman iletiliyor. Yani cd aracına hem yeni hem de klasör isimli dizinlere geçiş yapmasını söylemiş oluyoruz. En nihayetinde uygulanması mümkün olmayan bir komut girdiğimiz için de komutumuz elbette başarısız oluyor. İşte kabuğun bizi doğru anlayabilmesi için tıpkı klasörü oluştururken olduğu gibi geçiş yapmak için de klasör ismini tek tırnak içinde yazarak tek bir argüman olarak görülmesini sağlayabiliriz. Hemen deneyelim.

```jsx
cd 'yeni klasor'
```

Bakın isminde boşluk olan dizine geçiş yapabildik. Kullandığımız tırnaklar sayesinde girdiğimiz "yeni klasor" ifadesi kabuk tarafından tek bir argüman olarak algılanıp ilgili klasöre başarılı şekilde geçiş yapıldı. Bu örneğimizle birlikte kabuğun çalışma yapısını tekrar hatırlayıp, içinde boşluk ya da kabuk tarafından farklı algılanabilecek özel karakterler olan klasörlerin tırnak içinde tek bir argüman olarak yazılması gerektiğini de öğrenmiş olduk.

Boşluk karakterine örnek verdik bir de özel karaktere örnek verecek olursak, mesela değişken çağırırken kullandığımız dolar işaretini kullanabiliriz. Normalde sizin de bildiğiniz gibi kabuk dolar işaretini gördüğünde bu işaretin yanındaki ifadeyi değişken olarak kabul ediyor. Yani dosya isminde dolar işareti olursa kabuk dosya ismini doğru şekilde algılayamayabilir. Ben denemek için mkdir  tek tırnak içinde 'ben$klasor' şeklinde komutumu giriyorum. Burada tek tırnak kullanmak önemli. Eğer çift tırnak kullanırsak, daha önceki örneğimizde de bizzat gördüğümüz gibi kabuk dolar işaretinin özel anlamını dikkate almaya devam edecek. Tek tırnak içinde yazdığımızda kabuğun bu tırnak içindeki tüm ifadelerin özel anlamlarını görmezden gelmesini sağlamış oluruz. Ls komutu ile mevcut dizindeki dosya ve klasörleri listeleyelim. Bakın tam olarak tek tırnak içinde belirttiğim isimde yeni klasörüm oluşturulmuş.

Şimdi test etmek için içerisinde özel karakter olan bu klasöre geçiş yapmak üzere ismini olduğu gibi yazmayı deneyebiliriz.

Bakın yanıt olarak böyle bir dosya ya da dizin olmadığı konusunda uyarıldık. Hata aldık çünkü kabuk buradaki dolar işaretinin, klasör isminin bir parçası olduğunu bilmiyor. Dolar işaretini gördüğü için dolar işaretinden sonraki kısmı değişken olarak dikkate alıyor. 

İşte bizim bu noktada klasörün isminin kabuk tarafından sıradan bir argüman olarak anlaşılabilmesi için tek tırnak kullanmamız gerekiyor. Yani aslında tek tırnak ile bu argümanı kabuk için sıradan hale getirmemiz gerekiyor. Eğer çift tırnağın işe yarayacağını düşünüyorsanız klasör ismini çift tırnak içinde de belirtebilirsiniz. Ancak gördüğünüz gibi çift tırnak işe yaramadı. Çünkü daha önce de teyit ettiğimiz gibi kabuk çift tırnağın içindeki özel sembolleri de dikkate alıyor. Son olarak tek tırnak ile klasörün ismini belirtmeyi deneyebiliriz. Bakın klasöre sorunsuzca geçiş yapabildik. Çünkü tek tırnak işareti sayesinde kabuk, dolar işaretinin özel anlamını görmezden gelerek dolar işaretini yalnızca klasörün isminde geçen standart bir karakter olarak gördü. Dolayısıyla kabuk buradaki argümana herhangi bir müdahalede bulunmadan olduğu gibi cd komutuna aktardı. cd aracı da aldığı argüman doğrultusunda bu dizine geçiş yapabilmemizi sağladı.

Bizzat birkaç kez teyit ettiğimiz gibi tek tırnak işareti bizim sorumuzu gayet iyi çözüyor ancak belki tek tırnak kullanımı size o kadar da konforlu gelmemiş olabilir. Bu durumda tüm ifadeyi tırnak içinde yazmak yerine kabuk için özel olan herhangi bir karakterin kabuk tarafından görmezden gelinmesi için ilgili özel karakterden hemen önce ters slash işaretini de kullanabiliriz. Ters slash işareti bash için kaçış karakteri anlamına geliyor ve dolayısıyla bash kabuğu bu karakteri gördüğünde bu karakterden sonraki karakterin özel anlamını görmezden geliyor. Yani örneğin ben cd ~/yeni\ klasor şeklinde komutumuzu girersem, kabuk ters slash işaretinden sonraki boşluk karakterini görmezden geliyor. Normalde sizin de bildiğiniz gibi kabuk için boşluk karakteri argümanları ayırmayı sağlıyor yani özel bir anlam ifade ediyor. Fakat girdiğim komutta boşluk karakterinden hemen önce ters slash işareti kullanıldığı için kabuk, boşluk karakterinin özel anlamını görmezden gelip, onu standart bir karakter olarak ele aldı. Bu sayede içinde boşluk karakteri bulunan klasöre sorunsuzca geçiş yaptık. Aynı yöntemi dolar işaretli klasör üzerinde de aynen deneyebiliriz. Bakın ters slash yani kaçış karakteri sayesinde dolar işaretinin özel anlamı kabuk tarafından görmezden gelindi ve neticede sorunsuzca bu dizine de geçiş yapabildik.

Görebildiğiniz gibi tek bir karakterin görmezden gelinmesi gerekiyorsa kolayca ters slash işaretini kullanabiliyoruz. Ben örnekler sırasında tek bir noktada bu karakteri kullandım ancak gerekiyorsa, görmezden gelinmesi gereken tüm karakterlerden önce bu ters slash işaretini tekrar tekrar kullanmanız gerekiyor. Örneğin ben bu bir deneme metnidir isminde bir klasör oluşturmak istersem komutumu mkdir bu\ bir\ deneme\ metnidir şeklinde girmem gerekiyor. Bakın burada kabuk tarafından görmezden gelinmesini istediğim tüm karakterden önce ters slash işaretini belirtmem gerekti. Normalde bir veya iki karakter için ters slash kullanmak çok büyük bir zorluk olmasa da daha fazlasını yazarken komutun okunaklılığı kaybolacağı için hatalı komut girme ihtimaliniz de aratabilir. Yeni oluşturduğum bu dizine geçiş yapmak için ben cd komutunda sonra bu yazıp tab ile otomatik olarak klasör isminin tamamlanmasını sağlıyorum. Bakın burada da otomatik olarak boşluk karakterlerinden önce ters slash karakteri ile öneri sunuldu. Komutumu onayladığımda ilgili dizine geçiş yapabiliyorum.

Yine de örnekler üzerinden de gördüğünüz gibi ters slash kullanışlı olsa de genelde pek okunaklı bir komut görünümü sunmadığı için genelde tırnak içine alma daha sık tercih ediliyor. Yine de artık her iki kullanım yönteminden de haberiniz var. Örneğin ters slash karakterini kullanmayı tercih etmeseniz bile isminde boşluk geçen bir klasöre geçiş yapacakken tab önerisinde sunulan isimdeki ters slash işaretlerinin ne anlama geldiğini artık biliyorsunuz. Neyse dediğim gibi artık yöntemlerden haberiniz var, duruma göre iistediğinizi kullanmakta özgürsünüz. 

Hazır kabuk üzerindeki karakterlerden bahsetmişken dikkat etmemiz gereken bir diğer husus da, Linux sisteminin küçük büyük harf duyarlılığının olduğu gerçeği. Küçük büyük harf duyarlılığı ile tam olarak neyi kast ediyorum ? Hemen bir örnek üzerinden açıklayalım. 

Örnek olması için ben kendi ev dizinimde dosya yöneticisi üzerinden tüm harfleri büyük "HELLO" isimli bir klasör oluşturuyorum. Daha sonra yalnızca baş harfi büyük "Hello" isimli bir klasör daha oluşturuyorum. Son olarak tüm harfleri küçük olan "hello" isimli klasörü de oluşturuyorum. Neticede hello isminde birbirinden bağımsız üç farklı klasörüm oldu.

Aynı işlemi windows sisteminde de deneyebiliriz. Öncelikle windows sistemine geçiş yapalım. Windowsta küçük büyük harf duyarlılığı olmadığı için büyük küçük harfler farklı da olsa aynı isimde bir ikinci klasör oluşturamayız. Hadi deneyelim. Ben tamamı küçük olan "hello" isimli yeni bir klasör oluşturuyorum. Bu tamam, şimdi bir de tamamı büyük harflerle yazılmış "HELLO" isimli bir klasör daha oluşturmayı deneyelim. Bakın ismini onayladığımda gördüğünüz gibi aynı isimde başka bir klasör olduğu konusunda uyarıldım. Uyarıldım çünkü windows üzerinde küçük büyük harf duyarlılığı bulunmadığı için, küçük büyük harfleri farklı da olsa her ikisi de aynı klasör olarak kabul ediliyor. Yani tamamı büyük HELLO ile tamamı küçük harflerden oluşmuş hello windows üzerinde aynı kabul ediliyor.

İşte bakın windows üzerinden ele aldığımız bu örnek, linux sisteminin sahip olduğu küçük büyük harf duyarlılığını kanıtlıyor. Çünkü biraz önce Linux'ta küçük büyük harflerı farklı olan aynı isimli birden fazla klasörü sorunsuzca oluşturabildik. Linux için klasör isimleri içerdikleri küçük büyük harf farkları dolayısıyla benzersiz birer klasördür. İşte harf duyarlılığı olduğu için oluşturma aşamasında olduğu gibi klasöre geçiş aşamasında da elbette klasörün küçük büyük harfli karakterlerine dikkat ederek doğru adını girmemiz gerekiyor. Örneğin ben tamamı büyük harflerle yazılmış olan HELLO klasörüne gitmek istersem cd ~/HELLO yazmam gerekiyor. Bakın tamamı küçük harfli olan hello ve yalnızca başlangıç karakteri büyük olan Hello klasörlerine değil doğrudan tamamı büyük harflerden oluşan HELLO isimli klasöre sorunsuzca geçiş yapabildim. Bizzat bu örnek üzerinden de teyit edebildiğimiz gibi Linux üzerindeki küçük büyük harf duyarlılığı sebebiyle kabuğa komutlar girerken girdiğimiz tüm komutlarda küçük büyük harf duyarlılığa dikkat etmemiz gerekiyor. 

Örneğin cd ~/desktop yazarsam, ev dizinimde küçük harfle başlayan desktop isimli bir klasör olmadığı için ilgili dizine geçiş yapamıyorum. Aynı komutu küçük büyük harflere dikkat ederek yani cd ~/Desktop şeklinde yazdığımda ise gördüğünüz gibi Desktop dizinine sorunsuzca geçiş yapabiliyorum. 

Dizinlerde gezinirken yeni başlayan kullanıcılar sıklıkla küçük büyük harf duyarlılığına dikkat etmediği için bu detaydan da özel olarak bahsetmek istedim. Ayrıca elbette küçük büyük harf duyarlılığı yalnızca klasör isimleri için değil, tüm sistem geneli için geçerlidir. İleride ele alacağımız komutlarda ve bu komutlara vereceğimiz seçenek ve argümanlarda da küçük büyük harf duyarlılığa dikkat ederek komut giriyor olacağız. Aksi halde doğru komutları girmemiş oluruz. Örneğin ev dizinimdeki Documents klasörüne geçiş yapmak için CD komutunu büyük yazıp CD ~/Documents şeklinde komut girmeyi deneyebilirim. Bakın böyle bir komut bulunamdığı konsunda uyarıldık. Çünkü gerçekten de bash yerleşik kabuklarında veya PATH dizini üzerindeki herhangi bir dizinde tamamı büyük harflerden oluşan bir aracın ismi geçmiyor. Aynı örneğin cd ~/Documents şeklinde tekrar deneybilriz. Bakın bu kez sorunsuzca geçiş yapabildik. Neticede bakın Linux üzerinde çalışıyorken her zaman küçük büyük harflere dikkat etmemiz gerekiyor.

Tamamdır bence dizinlerde gezinmek için bilmemiz gereken tüm detaylardan bahsettik. Artık böylelikle sistem üzerinde yetkinizin bulunduğu tüm dizinlerde rahatlıkla gezinebilirsiniz. Üstelik konsol kullanımına alıştığınızda grafiksel arayüze oranla çok daha hızlı gezinebildiğinizi kendiniz de bizzat fark edeceksiniz zaten. Sizlerden tek ricam dizinlerde gezinerek bol bol pratik yapmanız. Pratik yaptığınızda konsol üzerinden dizinlerde gezinmenin ne kadar kolay olduğunu bizzat deneyimleyeceksiniz.

Ben şimdi daha önce de defaatle kullanmış olduğumuz ve kullanacak olduğumuz dosya ve dizinleri listelememizi sağlayan ls komutunda bahsederek devam etmek istiyorum. Gelin ls komutunu tanıyarak devam edelim.

# ls Komutu

Şimdiye kadar yaptığımız örneklerde mümkün olduğunda grafiksel arayüzü de kullanarak bulunduğumuz dizindeki dosyaları ve klasörleri görüntüledik. Ancak ben bir süre sonra grafiksel arayüzü de bir kenara bırakıp birkaç gez ls komutunu ile mevcut bulunduğum dizinin içeriğini de listeledim çünkü grafiksel arayüzden ziyade komut satırın takip etmek çok daha kolay geliyor. 

Yani daha önce de birkaç kez bizzat deneyimlediğimiz gibi komut satırı üzerinden, dizin içeriklerini listelemek için için ls komutunu kullanabiliyoruz. ls komutu İngilizce "list" yani "liste-listelemek" ifadesinin kısaltmasından geliyor. Zaten görevi de dizin içerisindeki dosya ve klasörlerin komut satırına listelenmesini sağlamak. Komut satırı üzerinden çalışırken de sıklıkla ls aracına ihtiyacımız olacak. Üstelik ls aracının bizim işlerimizi kolaylaştıran bir çok seçeneği var. Biz önce en yalın hali ile kullanıp sırasıyla ihtiyaç duyacağımız seçeneklerinden de bahsetmeye çalışalım. Ben şu anda kendi ev dizinimde bulunuyorum. Bu dizindeki dosya ve klasörleri listelemek için yalnızca ls yazmam yeterli.

Bakın bulunduğum dizindeki tüm dosya ve klasörler ls komutu sayesinde konsola bastırdı. ls komutunu tek başına kullanmak yalnızca mevcut dizindeki dosya ve klasörlerin isimlerini öğrenmek istediğimizde faydalı. Ancak bizim dosya veya klasörler ile ilgili daha detaylı bilgilere ihtiyacımız da olabilir. Şimdi istediğimiz detay seviyesinde bilgi alabilmek için ls komutunun diğer seçenekleri ile neler yapabileceğimizden bahsederek devam edebiliriz. 

## Ayrıntılı Liste Almak

Eğer aldığımız çıktıda dosyanın veya klasörün türü, yetkileri, dosyanın sahibi ve dosyanın oluşturulma tarihi gibi ekstra detayları yani uzun çıktıları da istiyorsak ingilizce long yani uzun ifadesinin kısaltmasından gelen  `-l` seçeneğini kullanabiliriz. Komutumuzu -l seçeneğiyle birlikte girip sonuç üzerinden açıklamaya devam edelim.

Bakın önceki ls komutu ile kıyasladığımızda aldığımız çıktıdaki detay farkı çok net. Neticede ls komutunun l seçeneği sayesinde detaylı bir liste elde ettik. 

Aldığımız çıktıdaki sütunları ve bunların anlamlarını kısaca ele alacak olursam; en baştaki ilk karakter listelenen içeriğin tipini ifade ediyor. Örneğin en başında d olanlar görebildiğiniz gibi klasörleri temsil ediyor. Buradaki d karakteri İngilizce "directory" yani "dizin" ifadesinin kısaltmasından geliyor. Başında - işareti olanlar ise standart dosyaları temsil ediyor. Hemen bu ilk karakterin yanında bulunan rwx gibi karakterleri barındıran üçlü grup ise ilgili dosya veya klasörün yetkilerini temsil ediyor. Bu konudan daha sonra detaylıca bahsedeceğiz zaten. Yetkilerin hemen yanındaki rakamlar ise, ilgili dizinin içinde kaç hardlink yani katı linki bulunduğunu belirtiyor. Hard link kavramını da henüz öğrenmedik, şimdilik bu sütunun hard link sayısını gösterdiği konusunda kulağınızı kabartmanız yeterli. Bu sütundaki isimlerse dosya ya da klasörün sahibini, onun yanındaki ise grubunu belirtiyor. Dosyanın sahibi olan veya burada belirtilen grupta bulunan tüm kullanıcılar dosya veya klasör üzerinde burada belirtilen bazı yetkilere sahip oluyor. Bu kavramdan da ileride ayrıca bahsedeceğiz. Grubun hemen yanındaki sütun ise listelenen ögenin boyutunu bayt olarak ifade ediyor. Buradaki tarih bilgisi de ilgili dosya veya klasörün en son değiştirildiği tarihi veriyor. Ve elbette en son bölüm de klasör veya dosyanın ismini gösteriyor.

Biliyorum şimdi kısaca açıklamış olsam da buradaki çıktılar sizin için çok da anlamlı gelmedi. Ancak merak etmeyin eğitimin devamında buradaki tüm çıktılar sizin için de anlam ifade ediyor olacak. O halde hadi devam edelim.

## Gizli Dosyaları Listelemek

`-l` seçeneği ile tüm ekstra detayları listelemiş olsak da, bu listede gizli dosyalar yer almıyordu. Daha önce de kısaca bahsettiğimiz gibi Linux sisteminde, başında nokta bulunan dosya veya klasörler gizli statüsüne oluyor. Dolayısıyla biz özellikle belirtmediğimiz sürece gizli dosyalar listelenmiyor. Zaten dosyaların gizli olmasının nedeni o dosyaların özellikle hedef gösterilmedikleri sürece gizli tutulup çeşitli işlemlerden de muaf kalmalarını sağlamak. Gizleme özelliği sayesinde istemsizce silinmesi sorun oluşturabilecek çeşitli dosya ve klasörler bilinçsiz veya hatalı işlemlerden korumuş oluyor. 

Neticede her ne zaman gizli olan dosya ve klasörler üzerinde işlem yapmak istiyorsak o zaman özellikle gizli dosya ve klasörler üzerinde çalışmak istediğimizi belirtmemiz gerekiyor. İşte bu durum listeleme işlemi için de aynen geçerli. Eğer standart olanlarla birlikte gizli içerikleri de listelemek -a seçeneği kullanabiliriz. Bu seçenek all yani hepsi ifadesinin kısalmasından geliyor. Zaten biz de standart gizli demeden hepsini listelemek istediğimiz için all seçeneğini kullanıyoruz. 

Gizli dosyaları da listeleyebildiğimizi daha net gözlemleyebilmek için öncelikle ls daha sonra ls -a komutunu kullanıp, çıktıları kıyaslayabiliriz. Ben öncelikle ls komutunu giriyorum. Bakın standart olan dosya ve klasörler listelendi. Şimdi komutumuzu ls -a şeklinde tekrar girelim. 

Bakın bu kez standart dosya ve klasörlerle birlikte isminin başında nokta bulunan dosya ve klasörler de listelenmiş oldu. Yani aslında bu dosya ve klasörler hep buradaydı ancak biz özellikle belirtmediğimiz için daha önce görememiştik. Tam da bu noktada ben hazır gizli içeriklerden bahsetmişken, gizli içeriğin daha net anlaşılabilmesi için kendim de yeni bir gizli dosya ve klasör oluşturmak istiyorum. 

Yeni dosya ve klasörleri oluşturmak için yine konsolu kullanabiliriz. Ben öncelikle gizli bir klasör oluşturmak için mkdir .gizli-klasor şeklinde komutumu giriyorum. Tamamdır klasörüm oluşturuldu. Şimdi bir de dosya oluşturmak için touch .gizli-dosya şeklinde komutumuzu girelim. Tamamdır dosyam da oluşturuldu.

Bu yeni oluşturdum dosya ve klasörün gizli olduğunu teyit etmek için öncelikle ls komutunu kullanarak listelemeyi deneyebilirim. Bakın standart çıktıların içinde yeni oluşturduğum dosya veya klasörün ismi geçmiyor. Şimdi bi de ls -a komutu ile listeleylim. Bakın tüm diğer gizli içerikler gibi benim isminin başına nokta koyduğum dosya ve klasör de listelendi. 

Hatta gizliliği teyit etmek için dosya yöneticisini açıp ev dizinimizi de kontrol edebilliriz. Hemen açalım. Bakın ev dizinimde standart olanlar hariç yeni oluşturduğum dosya veya klasör gözükmüyor. Grafiksel arayüzde gizli dosyalar gözükmüyor çünkü dosya yöneticileri de tıpkı konsol üzerinde olduğu gibi varsayılan olarak gizli dosyaları açığa çıkarmama eğiliminde oluyor. Çünkü bir dosya veya klasör gizleniyorsa mutlaka mantıklı bir nedeni vardır. Durduk yere kullanıcı bilinçli şekilde gizli olan içerikleri de görüntülemek istemediği sürece, varasyılan olarak gizli olanların grafiksel arayüz üzerinde de gösterilmemesi gibi doğru bir yaklaşım var.

Tamam iyi güzel ama, benim tam da bu noktada aklıma biz soru geliyor.  Konsol üzerinden gizli dosya ve klasörleri görmek için ls komutunun a seçeneğini kullanabiliyoruz. Peki ama grafiksel arayüz üzerinden görmek istersek ne yapmamız gerekiyor? Bu işlem de son derece basit. Her ne kadar sistemde yüklü bulunan dosya yöneticisi aracına göre ufak tefek farklılıklar olsa da kullanmakta olduğunuz dosya yöneticisinin ayarlarını kurcalayarak gizli içeriklerin görünmesini sağlayabilirsiniz. Ben öncelikle buradaki üç çizgiye tıklayıp seçeneklerimi görmek istiyorum. Bakın burada gizli dosyaları gösterme kutucuğu boş gözüküyor. Eğer aktifleştirmek istiyorsak tek yapmamız gereken bu kutucuğu işaretlemek. Bakın işaretler işaretlemez hemen grafiksel arayüzden de gizli olan içerikleri görebilir hale geldik. İşte sizler de eğer gerekiyorsa benim yaptığım gibi kendi sisteminizde yüklü olan dosya yöneticisi aracını kurcalayarak kısa sürede gizli dosyaları gösterme özelliğini aktifleştirebilirsiniz. Bizlerin temel amacı komut satırını kullanabilmek ancak, olası durumda ihtiyaç duymanız halinde kullanabilmeniz için eğitim boyunca mümkün oldukça bu gibi grafiksel arayüzdeki bazı detaylardan da bahsediyor olacağız.

Şimdi tekrar komut satırına, ls komutuna geri dönecek olursak: dilersek aynı anda birden fazla seçeneği kullanabileceğimizi de belirtmek istiyorum. Örneğin ben hem ayrıntılı, hem de gizli dosyaların yer aldığı bir liste istersem komutumu ls -la şeklinde kullanabilirim. 

Görebildiğiniz gibi gizli dosya ve klasörlerin yer aldığı ayrıntılı görünümde liste karşımıza gelmiş oldu. Bakın bu komutumuzla birlikte komut satırı arayüzündeki esneklik imkanlarını da yavaş yavaş deneyimliyoruz. Bakın ls komutu üzerinden aslında aynı anda birden fazla seçeneği kullanabildiğimiz de teyit etmiş olduk. Üstelik yalnızca benim yazdığım şekilde komut girmek zorunda da değilsiniz. Örneğin seçeneklerin sırasını değiştirebilirsiniz.

ls -al

Gördüğünüz gibi yine aynı çıktıyı elde ettik.

Esneklikten bahsetmeye devam edecek olursak seçenekleri birlikte yazmak soruna bile değiliz aslında. Örneğin aynı sonucu ls -l -a şeklinde seçenekleri ayrı ayrı yazarak da elde edebiliyoruz. Hatta komut girerken seçeneklerin uzun isimlerini dahi kullanabiliriz. Uzun seçenekleri kullanmak için öncelikle seçenkleri öğrenmek üzere ls —help yardımıyla yardım sayfasına bi göz atalım. Bakın -a yani gizli dosyaları bastıran seçenek —all seklinde de uzun haliyle kullanılabiliyormuş mesela. Hemen denemek için ls -l -all şeklinde komutumuzu girebiliriz.

Bakın uzun seçeneği kullanmış olmamıza rağmen yine birebir istediğimiz çıktıyı aldık. Yani özetle aslında komut girme ve bir aracın çoklu özelliklerini aynı anda kullanabilme konusunda son derece esnekliğe sahibiz. Üstelik bu durum yalnızca ls komutuna özgü de değil. İstisnalar hariç pek çok komutun seçeneklerini belirtirken bu gibi esnekliklere sahibiz zaten. Yani nasıl rahat edecekseniz komutunuzu o şekilde girebilirsiniz. Yeter ki eksiksiz ve doğru şekilde girin. Elbette doğru özellikleri ve seçenekleri kullanmak için de komutların yardım sayfalarına da mutlaka göz atın. Örneğin kimi komut seçeneklerinin hiç uzun seçenek alternatifleri yokken kimi komutların seçenekleri çok fazla olduğu için kısa harfle kullanılamayan yalnızca uzun olarak yazılması gereken seçenekleri var. Neyse neticede seçenekleri girme konusunda esnek olduğumuzu ls komutu üzerinden uygulamalı şekilde teyit etmiş olduk. Şimdi ls komutunun diğer seçenekleri ile devam edelim.

## Boyutların Okunaklı Çıktılarını Alma

Yeni seçeneği açıklamadan önce konsolumuzu ctrl l ile veya clear komutu ile bi temizleyelim önce. Tamamdır. Şimdi ben aldığımız çıktılardaki büyüklük birimlerini nasıl daha okunaklı şekilde elde edebileceğimizden bahsetmek istiyorum. Bunun için öncelikle normalde aldığımız büyüklük cinsini görmek için ls -l şeklinde komutumuzu girelim. Bakın aldığımız çıktılarında hep bayt cinsinden boyut bilgisi bastırıldı. Bakın buradaki boyutlar hep bayt cinsinden. Eğer çıktıların daha okunaklı olmasını istersek h seçeneğini kullanabiliyoruz. Bu seçenek "human readable" yani "insan tarafından okunabilir" ifadesinin kısaltmasından geliyor. Buradaki okunaklıdan kastımız da dosya boyutunu KB, MB, GB türünden büyüklük olarak görülebilesi zaten. Yoksa özellikle büyük boyutlu dosyaların bizim alıştığımız kb mb gb büyüklüklerindeki karşlıklarını bayt üzerinden idrat etmemiz pek kolay olmuyor. Zaten büyüklükler bayt cinsinden ifade edildiğinde, dosyaların boyutlarını kıyaslarken bile çok basamaklı olduğu için büyüklük algımızı kaydedebiliyoruz. Bu durumu kıyaslayarak teyit edebilmek için şimdi bir de h seçeneğini ekleyip ls -lh komutunu girelim. Aldığımız çıktılara bakacak olursak, dha doğrusu çıktıları kıyasladığınızda görebileceğiniz gibi  h seçeneği sayesinde dosyaların toplam boyutu ve bireysel boyutları çok daha kolay okunur şekilde basılmış oldu. Bu seçenek özellikle büyük boyutlu dosya ve klasörlerin boyutlarını öğrenmek için oldukça kullanışlı. Bayt cinsinden olduğu için çok basamaklı sayıların büyüklük hesaplarını yapmakla uğraşmamıza gerek kalmıyor böylece. Unutmayın, insan olarak rahat okumak istiyorsanız human readable ifadesinin kısaltmasından gelen h seçeneğini kullanmanız yeterli.

Büyüklük biriminden de bahsettiğimize göre şimdi de öncelikle boyut sıralaması ile başlayıp çeşitli sıralama işlevlerine de kısaca değinelim. Neticede ls komutu ile bir liste alıyoruz. Bu listeyi farklı durumlarına göre sıralamaya her zaman ihtiyacımız olabiliyor. 

## Boyutlarına Göre Sıralamak

Eğer çıktıları büyükten küçüğe olacak şekilde boyutlarına göre sıralamak istersek, büyük S seçeneğini kullanabiliyoruz. Bu “S” seçeneği muhtemelen tahmin ettiğiniz gibi ingilizce "Size" yani "boyut" ifadesinin kısaltmasından geliyor. Büyük S kullanıldığında tıpkı karakterindeki büyüklük gibi büyükten küçüğe doğru olacak şekilde listenin sıralanmasını sağlamış oluyoruz. 

Ben daha net görülebilmesi için ben /boot dizinine geçiş yapmak istiyorum. Şimdi buradaki dosyaları ls -l ile listeleyelim. Bakın aldığımız çıktıda dosya ve klasörler yukarıdan aşağıya doğru alfabetik şekilde sıralanmış halde karşımıza geldi. Şimdi bir de büyük S seçeneğini de ekleyip tekrar listeleyelim. Bakın bu kez aldığımız çıktılar ilk listeden farklı olarak büyükten küçüğe sıralanmış oldu. Hatta emin olmak için dilersem h seçeneğini de ekleyip daha okunaklı bir çıktı elde edebilirim. Bakın büyük karakterli size seçeneği yani S seçeneği, ls komutunun çıktılarını büyükten küçüğe doğru kolayca sıralayabilmemizi sağlıyor.

Neticede boyutları kıyaslama ve görebilme açısında oldukça okunaklı bir listeye sahip olabiliyoruz. Bu noktada hazır S seçeneğini yani büyük harfli bir seçeneği kullanmışken, Linux sistemindeki küçük büyük harf duyarlılığına da tekrar değinmek istiyorum.

Biz dosya ve klasörleri büyükten küçüğe sıralamak için büyük S seçeneğini kullandık. Eğer büyük S yerine küçük s seçeneğini kullansaydık aynı sonucu alamayacaktık. Çünkü her ikisi de başka işlevleri olan ayrı seçeneklerdir. Küçük s seçeneği tıpkı temsil ettiği karakter gibi içerikleri küçükten büyüye doğru sıralama görevinde. Teyit etmek için şimdi bir de küçük s ile komutumuzu girelim. Bakın aldığımız çıktılar aynı olmadı, çünkü linux sistemi küçük büyük harf duyarlılığına sahip olduğu için benim girdiğim küçük s seçeneği sayesinde içerik bu kez küçükten büyüğe doğru sıralandı. Küçük s küçükten büyüğe sıralarken, büyük S büyükten küçüğe doğru sıralıyor. Dolayısıyla hangi işleve ihtiyacımız varsa o işlev için tanımlı olan seçeneği eksiksiz olarak yazmamız gerekiyor.

Sizler de bu durumun farkında olarak, komutlarda ve komutların seçeneklerinde bulunan küçük büyük harflere dikkat edin. İlk başlarda size aynı gelebilir, ama Linux için küçük karakter ile büyük karakter aynı şey değildir.

Bu durumu da teyit ettiğimize göre anlatıma bu kez tarihlere göre sıralama seçenekleriyle devam edebiliriz.

## Değiştirilme Tarihlerine Göre Sıralama

Dosya ve klasörleri değiştirilme tarihlerine göre en yeniden eskiye doğru sıralamak istersek t seçeneğini kullanabiliyoruz. Buradaki “t” seçeneği ingilizce "time" yani "zaman" ifadesinin kısaltmasından geliyor. Ben örnek olarak bulunduğum dizindeki dosya ve klasörleri ls -lt komutu ile listeliyorum.

Bakın listenin en üstünde yer alan içerikler, diğerlerine göre en yeni düzenlemiş olan içerikler. 

Çıktılara bakarak tarihi olarak yeniden eskiye göre sıralandığını teyit edebiliyoruz. Peki ya en eskiden yeniye doğru sıralamak isteseydik bunun için bir seçeneğe sahip miyiz ? Aslında hayır sahip değiliz hatta inanmıyorsanız tekrar ls —help komutu ile seçeneklere bir daha bakalım. Bakın burada küçük t seçeneğinin yeniden eskiye doğru tarihi sıralama yaptığı belirtilmiş. Ancak eskiden yeniye doğru sıralama için herhangi bir seçeneğin bulunduğunu görebiliyoruz. Bakın büyük T seçeneği de başka bir işlev için tanımlanmış.

Peki bu durumda biz çaresiz miyiz ? Yani yalnızca içerikleri yeniden eskiye doğru mu sıralayabiliyoruz gerçekten ? 

Doğrudan herhangi bir seçenek sunulmamış olsa da yine komut satırı kullanımının esnekliği sayesinde aldığımız bu sıralı çıktıları tersine çevirme imkanına sahibiz aslında. Örneğin bizim aldığımız yeniden eskiye olan bu çıktıyı tam tersine çevirisek ne olur ? Tabii ki eskiden yeniye doğru sırlanmış olur. E hadi gelin listeyi tersine çevirelim.

## Çıktıları Tersine Çevirmek

Fark ettiyseniz şu ana kadar ele aldığımız seçeneklerde hep tek yönlü listeleme mevcuttu. Örneğin boyutları sıralarken büyükten küçüğe, tarihleri de yeniden eskiye doğru sıralamıştık. Eğer ls çıktılarının normalde sunduğu herhangi bir çıktıyı tersten sıralamak istersek ingilizce "reverse" yani "ters" ifadesinin kısaltması olan r seçeneğini kullanmamız yeterli oluyor. Hemen bildiğimiz seçenekler üzerinden deneyelim.

Örneğin ls komutunun dosya ve klasör isimlerini alfabetik olarak sıraladığını belirtmiştim hatırlıyorsanız. Hatta ls -l komutu ile tekrar teyit edelim. Bakın ben harici bir sırlama kıstası için seçenek belirtmediğinden dolayı hepsi alfabetik olarak sıralandı. Şimdi aynı listeyi tersten sıralamak için r seçeneğini de komutumuza ekleyebiliriz. 

Bakın bu kez aldığımız çıktılar önceki listenin tam tersi yani alfabetik olarak tersten sıralanmış oldu.

Dosya ve klasörleri küçükten büyüğe sıralamak için de kullanabiliriz. Örneğin dosyaları küçükten büyüğe sırlayan ls -ls komutu nu girdiğimizde bakın küçükten büyüğe sıralanmış bir liste aldık. Terse çevirmek mi istiyoruz tekrar aynı komutumuza bu kez “r” seçeneğini de ekleyelim.

Bakın şimdi de dosyalar büyükten küçüğe doğru sıralandı. Benzer şekilde tarihleri eskiden yeniye doğru da sıralayabiliriz. Normalde ls -lt seçeneği yeniden eskiye doğru sıralıyordu gördüğünüz gibi. Gelin r seçeneğini ekleyip tekrar deneyelim. 

Ve bakın, bu kez tam tersi şekilde eskiden yeni tarihe doğru bir liste elde etmeyi başardık. Komut satırının ne kadar esnek olduğunu siz de yavaş yavaş hissediyorsunuzdur umarım.

Neticede tekrar tekrar teyit edebildiğimiz üzere r seçeneği çıktıları tersine çevirmek için kullanılan işlevsel bir özellik. 

Temel sırlama gibi işlevlerden de bahsettiğimize göre ben artık kendi bulunduğumuz dizini listelemek yerine dilediğimiz bir dizin içeriğini nasıl listeleyebileceğimizden de bahsetmek istiyorum. Yani söz konusu içerikleri listelemek olduğunda mevcut dizinimizle sınırlı falan değiliz kesinlikle. 

## Dizin Adresini Belirterek İçeriğini Listelemek

Eğer mevcut bulunduğumuz dizini değil de başka bir dizindeki içerikleri listelemek istersek, ilgili dizininin tam adresini tıpkı cd komutunda olduğu gibi ls komutunun ardından yazmamız yeterli.

Örneğin ben şu anda /boot dizini altında çalışıyorum. Buradayken ls komutunu kullanırsam, mevcut dizindeki içerikler karşıma geliyor. Ama ben /etc dizini altındaki apt klasörünün içeriğini listelemek istiyorum. Bunun için tek yapmam gereken ls /etc/apt komutu ile içeriğini listelemek istediğim dizinin adresini açıkça belirtmek. Yani listelenmesini istediğim dizini ls komutuna argüman olarak verirsem, ls komutu mevcut dizin yerine bu argümandaki dizinin içeriğini listeleyecek. Komutumuzu onayalım bakalım.

Bakın hangi konumda çalışmakta olduğumdan bağımsız olarak, apt dizinin içeriği anında konsola listelendi.

İşte bu şekilde o konumda değilken, yetkimiz olan dizinlerin içeriklerini görüntüleyebiliyoruz. Hazır yetki kavramına da değinmişken yetkimiz olmayan dizinlerin içeriklerini görüntüleyemeyeceğimizi örneğin/root dizininin içeriğini sorgulayarak teyit edebiliriz. Normalde root kullanıcısı sistem üzerindeki en yetkili kullanıcı olduğu için bizim gibi standart kullanıcı hesapları root kullanıcısının ev dizinini temsil eden /root klasörünü üzerinde yetkiye sahip değil. Dolayısıyla içeriğini görüntüleme gibi işlevleri de bu dizinde uygulayabiliyoruz tabii ki.

Hemen denemek için konsola ls /root komutunu girebiliriz. Bakın gördüğünüz gibi doğrudan yetki hatası aldım. Yetkilendirme işlemlerinden bahsederken, nasıl yetki kısıtlaması yapabileceğimizden ve yetki kısıtlaması olan dosyaları kimlerin nasıl ulaşabileceğinden de ayrıca söz edeceğiz. Şimdilik tıpkı bu root klasöründe olduğu gibi yetkimiz olmayan dizinlere erişemeyeceğimizi bilmemiz yeterli.

Dizin adreslerini belirterek dizin içeriklerini listeleyebilme özelliği dosya taşıma kopyalama veya içerikleri teyit etme noktasında inanılmaz kolaylık sunuyor. Çünkü cd komutu ile ilgili dizine gidip ls komutunu yazmaktansa ls komutuna doğrudan içeriğinin listelenemsini istediğimiz dizini argüman olarak vermek çok daha kolay.

Ayrıca farklı dizinlerin içeriğini listelemekten bahsetmişken, spesifik olarak tek bir klasörün özellikleri hakkında bilgi almak için yalnızca o klasörü de listeleyebiliriz. 

## Dosya veya Dizinin Kendisini Listelemek

Doğrudan bizim istediğimiz bir veya birden fazla dosya veya klasörlerin özelliklerini görebilmek için dosyanın tam dosya dizin adresin ls komutundan sonra yazmamız yeterli. Örneğin ben kendi ev dizinimde bulunan .bashrc dosyasının özelliklerini listelemek istersem ls -l ~/.bashrc şeklinde komutumu girmem yeterli. Bakın yalnızca bashrc dosyasının özellikleri konsola basılmış oldu. Benzer şekilde yalnızca tek bir klasörün özelliklerini de listeleyebiliriz. Normalde örneğin ls -l /home/ komutunu girdiğimizde gördüğünüz gibi home dizini içindeki tüm dosya ve klasörler listeleniyor. Biz dizin içeriğinin değil de doğrudan home dizinin özelliklerine bakmak istersek, ls komutuna directory yani dizin ifadesinin kısalmasında gelen d seçeneğini eklememiz yeterli. Komutumu bu kez ls -ld /home/ şeklinde giriyorum. 

Bakın yalnızca /home/ klasörünün bilgileri listelenmiş oldu. Elbette tek tek girmek zorunda da değilsiniz. İsterseniz peşi sıra birden fazla dosya ya da klasör ismini girip, özelliklerini konsola bastırabilirsiniz. Örneğin ben başka bir dizinde olan /var/tmp klasörünü de ekleyip peşi sıra özelliklerin listelenmesini sağlayabilirim. Bakın iki farklı konumdaki klasörlerin tam dizin adreslerini yazıp, özelliklerini kolayca listeleyebildim. Benzer şekilde elbette listelemek istediğiniz dosya veya klasörlerin da tam adını belirttiğiniz sürece sistemdeki farklı dizinlerde bulunan dosya ve dizinleri tek seferde bastırabilirsiniz. Örneğin ben komutun sonuna ~/.bashrc dosyasını da listelemek için ekliyorum. Bakın ls -ld komutunun sonuna eklediğim klasörler ve dosyalar tek tek bastırıldı.

Özetle ls komutunun görevi kendisine argüman olarak verilmiş olan dosya veya dizinleri listelemek. Bu sebeple tam dizin adresini belirttiğimiz ve yetkimiz olduğu sürece tek seferde pek çok farklı dizindeki dosya ve klasörleri kolayca listeleyebiliyoruz.

Ben ls komutuyla ilgili son olarak alt alta olan tüm dizin içeriklerinin nasıl bastırılabileceğinden de bahsedip ls komutuna şimdilik noktayı koymak istiyorum.

### Alt Dizinler de Dahil Tüm İçerikleri Listelemek

Eğer herhangi bir dizin atlında yer alan tüm dizinlerin içeriklerini listelemek istersek recursive yani özyineleme ifadesinin kısalmasından gelen büyük R seçeneğini kullanma imkanına sahibiz. Bu seçeneği kullandığımızda tüm alt klasörler de dahil mevcut dizin altındaki tüm dosya ve klasörlerin içerikleri bizim için kademe kademe listeleniyor. Zaten iç içe olan dizinlerin içeriğini bulup bize listelediği için bu seçeneğin adı özyineleme olarak geçiyor. Örnek üzerinden çok daha net anlaşılacağı için hemen basit bir örnek yapalım.

Ben örnek olması için kendi ev dizinim altındaki tüm içeriği listelemek üzere ls -R ~ şeklinde komutumu giriyorum. Tilde işareti sayesinde benim ev dizinim altındaki içerikleri listeliyor olacağım.

Bakın tek tek hangi dizin altındaki hangi içerikler bulunduğu ve daha alt dizinlerde de aynı şekilde hangi içeriklerin bulunduğu tek tek konsola bastırıldı. 

Çıktıları incelediğimde ev dizinim altındaki tüm içeriklerin özyinelemeli olarak listelenmiş olduğunu görebiliyorum. İşte sizler de alt dizinlerler de dahil tüm içeriği görmek istediğinizde sizler de bu şekilde büyük R seçeneğini kullanabilirsiniz.

Özyineleme özelliğinden de bahsettiğimize göre benim ls komutu hakkında aktarmak istediğim bilgilerin şimdilik sonuna gelmiş olduk.

Elbette ls komutunun bütün özellikleri benim anlattıklarım ile sınırlı değil. ls —help komutu ile ls aracının sahip olduğu özellikler hakkında her zaman ek bilgi alabilirsiniz. Her ne kadar tüm seçeneklerini ele almayacak olsak da zaten henüz daha fazla seçenekten bahsetmek için de çok erken. Yani şu anda bahsetsem bile bazı kavramlardan henüz bahsetmediğimiz için pek bir anlamı olmayacak. Eğitimin devamında yeri geldikçe diğer özelliklerinden de bahsediyor olacağız. Şimdilik benim anlattıklarım eğitime devam etmek için yeterli. 

# Dizin Oluşturma ve Silme

## Dizin Oluşturma | mkdir Komutu

Şu ana kadar bulunduğumuz dizini öğrendik, dizinlerde gezindik ve dizinlerin içeriklerini listeledik ama konsol üzerinden dizin oluşturmaya dair özellikle bir anlatımda bulunmadık. Tabii ki şu ana kadar dizin oluşturmamızı sağlayan mkdir aracını defaatle kullandık ama, özellikle bu aracın üzerinde durmak henüz.. Sizin de bildiğiniz ve birken fazla kez deneyimlediğiniz gibi konsol üzerinden dizin oluşturmak için ingilizce "make directory" yani "dizin oluştur" ifadesinin kısaltması olan mkdir komutunu kullanabiliyoruz. En temel kullanımı mkdir klasor_adı şeklinde. Bu kullanım ile mevcut çalışmakta olduğumuz dizinde bizim belirttiğimiz isimde bir klasör oluşturuluyor. Zaten eğitimin başından beri örnek vermek için ara da bu komutu bu şekilde kullandık. Yani hiç de yabancı değiliz. Yine de ele almamız gereken birkaç detayı daha bulunuyor.  

Ben öncelikle standart kullanımını tekrar ele almak için bulunduğum dizine folder1 isimli bir klasör oluşturmak üzere mkdir folder1 komutunu giriyorum.

ls komutu ile içerikleri listelediğimde, bakın klasörümün oluşturulduğunu görebiliyorum.

Bakın mkdir komutunun en temel kullanım biçimiyle yeni klasör bulunduğumuz dizin altında oluşturuldu. Bulunduğumuz dizin dışında tam dizin adresi belirtirsek, eğer yetkimiz de varsa istediğimiz konumda istediğimiz isimde bir dizin de oluşturabiliriz.

Örneğin ben mkdir ~/Documents/belgeler komutu ile kendi ev dizinimdeki Documents klasörünün içinde belgeler isimli yeni bir klasör oluşturabilirim. Komutumu giriyorum. Şimdi ls ~/Documents/ komutu ile kontrol edelim. Bakın çalışmakta olduğum dizinden bağımsız olarak istediğim bir konumda yeni klasörün oluşturulması da sağlamış olduk. Biz bu şekilde komut girdiğimizde mkdir aracı belirttiğimiz dizini kontrol ediyor, örneğin benim girdiğim komutta documents dizini kontrol edildi ve burada belirtilen belgeler isimli bir klasör olmadığı için mkdir aracı bu isimde yeni bir klasör oluşturdu. Zaten bu sayede yetkimiz dahilinde olduğu sürece istediğimiz adreste istediğimiz klasörü oluşturabilme esnekliğine sahip oluyoruz. 

Daha önce yetkimiz olmayan /root dizininin içeriğini listelemeye çalışmış ve yetki hatası almıştık hatırlarsanız. Aynı durum klasör oluştururken de geçerli. Yetkimiz olmayan dizinlerin içine yeni klasörler ekleyemeyiz. Denemek için /root dizini altında "yetkisiz" isimli bir klasör oluşturmayı deneyelim. Bunun için komutumu mkdir /root/yetkisiz şeklinde giriyorum.

Gördüğünüz gibi yetkim olmadığı için bu dizinde yeni klasör oluşturamadım. Zaten her önüne gelenin yani yetkisi olmayan kullanıcının her istediğini yapabildiği bir sistemde güvenlikten söz edemeyiz. Erişim yetkilerinin kısıtlanması ile sistemin güvenliği sağlanabiliyor. Zaten ileride bundan ayrıca söz edeceğiz.

Tekrar örneklerimize dönecek olursak, ben örneklerde hep tek bir klasör oluşturdum. Ancak dilersek klasör isimlerini peş peşe yazarak tek seferde birden fazla klasör de oluşturabiliriz. Ben test etmek için üç yeni klasör oluşturmak için komutumu .

mkdir folder2 folder3 folder4

şeklinde giriyorum. Bu şekilde kaç tane klasör oluşturulmasını istiyorsam o kadar çok argüman girebilirim. 

Bakın tek seferde birden fazla klasörü oluşturabildim. İşlemin hızlıca sonuçlanması harika ama kimi zaman işlemi konsol üzerinden de takip etmek isteyebiliriz. 

Eğer çoklu klasör oluştururken klasör oluşturma işlemini daha kolay takip etmek istersek, ingilizce verbose yani "ayrıntılı" ifadesinin kısaltması olan v seçeneğini de kullanabiliyoruz. 

Örneğin ben biraz önce çoklu dosya oluşturduğumda dosyaların oluşturulduğuna dair herhangi bir çıktı almadım.

Eğer mkdir komutunun -v seçeneğini kullanırsak tüm oluşturma işlemleri konsola basılacaktır. Örneğin komutumu mkdir -v a b c d şeklinde girdiğimde, her bir klasörün oluşturulmasına dair adım adım bilgi edinebiliyorum gördüğünüz gibi. mkdir komutunun verbose seçeneği özellikle farklı konumlarda çoklu dosya oluşturma gibi işlemlerde, oluşturma işlemlerinin takibi konusunda çok kullanışlı olabiliyor. Zaten verbose ifadesini tüm eğitim boyunca komutların buradaki gibi işlem adımlarına dair ayrıntılı çıktılara vermesi için kullanacağımız için şimdiden mkdir komutu üzerinden yavaş yavaş verbose özelliğini de tanıtmak istedim.

Şimdiye kadar hep derinliği olmayan tekil klasörler oluşturduk. Yani normalde bildiğiniz gibi klasörlerin içinde ve üstünde dizinler yer alıyor. Yani iç içe bir yapı söz konusu. İşte kimi zaman tekil bir klasör oluşturmamız gerekiyorken kimi zaman da tek seferde iç içe birden fazla klasör oluşturmamız da gerekebiliyor.

### İç içe Dizin Oluşturma

Eğer tek seferde iç içe birden fazla klasörü oluşturmak istersek mkdir komutunun p seçeneğini kullanabiliyoruz. Buradaki p seçeneği ingilizcedeki "parrent" yani "ebeveyn" ifadesinin kısalmasından geliyor. Aslında bu ifade üst dizin alt dizin kavramıyla ilişkili. Örneğin ben bir klasörün içine yeni bir klasör oluşturursam, bir üst klasör alttaki klasörün parrent ı yani ebeveyni olarak kabul ediliyor. Bu seçenek de buradan aklınızda kalabilir. 

Hemen uygulamalı olarak -p seçeneğinin etkisini gözlemleyelim. Ben mkdir -p buyukanne/anne/cocuk şeklinde komutumu girmek istiyorum.  Tamamdır, şimdi teyit etmek için ls -R buyukanne şeklinde komut girebiliriz. Bakın buyukanne klasörünün içinde anne onun da içinde cocuk isimli klasörler alt alta tek seferde p seçeneği sayesinde oluşturulmuşlar. Bizde ls -R özyinelemeli komutla bu durumu teyit edebildik.

Gördüğünüz gibi p seçeneği sayesinde tek seferde iç içe birden fazla klasör oluşturmayı oluşturabiliyoruz. Eğer p seçeneğini kullanmasaydık, kabuk gerçekte var olmayan bir dizin adresinde yeni klasör oluşturmaya çalıştığımız düşünecekti. Yani bizim iç içe oluştulması için verdiğimiz klasör isimlerini sanki halihazırda var olan bir dizin yolumuş da en sonraki klasör oluşturulacak klasör ismiymiş gibi algılaycaktı. Hemen denemek için p seçeneği olmadan mkdir x/y/z komutunu girelim.

Bakın gördüğünüz gibi konsol bize böyle bir dosya ya da dizin olmadığı uyarısını döndürdü, haklı da. Gerçekten böyle bir dizin yok. Çünkü biz bu komutu girdiğimizde mkdir aracı x dizinine geçip oradan y dizinine geçecek, y dizini altında da x klasörünü oluşturacaktı. Çünkü p seçeneği olmadan bizim girdiğimiz bu komut bunu ifade ediyor. Elbette bu dizinler var olmadığı için komutumuz bu haliyle doğal olarak hata verdi. Zaten bizim amacımız da bu dizinin oluşturulması, bunun için özellikle p seçeneği ile bu durumu belirtmemiz gerekiyor.

Bakın p seçeneğini kullandığımda bu kez dizinler iç içe sorunsuzca oluşturuldu.

`mkdir` komutunun bir de yeni oluşturulan klasörlerin yetki ayarlarını düzenlememizi sağlayan m seçeneği bulunuyor. Ancak henüz yetki ayarlarından bahsetmemişken bu seçenekten bahsetmenin pek anlamlı olacağını düşünmediğim için şimdilik pass geliyorum. Yetki konusunu ele alırken tekrar hatırlatma yaparız.

Biz şimdi var olan dizinleri nasıl silebileceğimizden bahsederek devam edelim.

## Dizin Silme | rmdir Komutu

Her zaman yeni klasör oluşturmayacağımız için kimi zaman var olan dizinleri silmek de isteyebiliriz. Söz konusu komut satırı üzerinden klasörleri silmek olduğunda da rmdir ve rm olmak üzere ihtiyacımıza göre kullanabileceğimiz iki alternatif aracımız var. Ben bu bölümde yalnızca rmdir aracına odaklanacağım. Ancak merak etmeyin daha sonra eğitim içerinde rm aracından da ayrıca bahsedeceğiz zaten. O zaman rm aracı üzerinden nasıl klasörleri silebileceğimize de değiniriz. Şimdilik rmdir aracı ile devam edecek olursak:

Biliyorsunuz klasörler, içerisindeki dosya ve klasörleri organize şekilde bir arada tutmak için tasarlanmış olan harika bir çözüm. Yeterince alana sahip olduğumuz sürece bir klasör içerisine istediğimiz kadar dosyayı barındırayabiliyoruz. Bu durum da tıpkı gerçek dünyada olduğu gibi işleletim sistemleri üzerinde de bize hiyeraşik bir düzen sağlıyor. Klasörlerin içerisinde dosya barındırabilmesi her ne kadar işlevsel olsa da, bu durum aynı zamanda klasörleri riskli hale de getiriyor. Eğer yanlışlıkla içerisinde kritik dosyaların bulunduğu bir klasörü silersek, tek seferde içerisindeki tüm alt dosya ve klasörler de silineceği için bu durum epey başımızı ağrıtabilir. Bu sebeple klasör silme işlemi Linux üzerinde ciddiye alınıyor ve zaten son derece dikkatle yapılması da gerekiyor. Klasörü silmek tek bir dosyayı silmeye benzemez. Tek seferde büyük bir yıkıma sebep olabiliriz. Zaten bu tehlike göz önünde bulundurularak klasör silmek için spesifik olarak güvenli bir araç olan rmdir aracı geliştirilmiştir.

rmdir aracı yalnızca içeriği boş olan klasörleri silmemizi sağlıyor. Bu sayede, içeriği dolu olan klasörlerin yanlışlıkla silinmesinin de önüne geçilmiş oluyor. Sunucu yönetiminde özellikle toplu klasör silmek için sıklıkla rmdir aracını kullanıyor olacağız zaten. 

Aracın kullanımına geçecek olursak en temel kullanımı `rmdir silinecek klasör ismi` şeklinde. Ben örnek olması açısından daha önce oluşturduğum ve içerisi boş olan bir klasörü silmek istiyorum. Örneğin folder1 klasörünü silmek için rmdir folder1 şeklinde komutumuzu girebiliriz. 

ls komutu ile de teyit ettiğimde, klasörün içerisin boş olduğu için sorunsuzca silindiğini görebiliyorum. Şimdi rmdir aracının davranışlarını gözlemleyebilmek için içerisinde başka bir klasör bulunan x klasörünü silmeyi de deneyebiliriz. Biliyorsunuz x klasörü içinde y onun da içinde z klasörü yer alıyor, çünkü biz daha önce p seçeneği sayesinde iç içe oluşturduk. Şimdi rmdir x komutu ile x klasörünü silmek üzere komutumuzu girelim.. Bakın klasörün içi boş olmadığı için silme işlemi anında reddedildi. Bunun yerine iç içe olan klasörlerin tam isimlerini girmeyi de deneyebiliriz. Silme işlemini rahat gözlemleyebilmek için rmdir aracında da mevcut olan verbose yani "ayrıntılı" çıktı sağlayan v seçeneğini de komutumuza ekleyelim. Komutumu rmdir -v x/y/z/ şeklinde giriyorum.

Komut neticesinde en son klasör olan z klasörünün silindiğini öğrendik. Çünkü z klasörünün içeriği tamamen boştu ve biz z klasörünün tam dizin adresini rmdir aracına iletmiş olduk. Dolayısıyla yalnızca z klasörü rmdir aracı tarafından içeriği boş olduğu için kolayca silindi. Bu durumda x ve y klasörlerinin hala silinmediğini teyit etmek için ls -R x/ komutu ile dizin içeriğini listeleyebiliriz. Bakın gördüğünüz gibi x/y dizini hala mevcut.

Eğer tek seferde içerisi boş olan tüm iç içe dizinleri silmek istersek tıpkı dizinleri oluştururken kullandığımız gibi silerken de -p seçeneğini kullanabiliriz. Daha önce mkdir aracı ile iç içe dizin oluşturmak için kullandığımız p seçeneğini, iç içe olan dizinleri tek seferde silmek için de kullanabiliyoruz. Ben işlemleri de takip edebilmek için rmdir -vp x/y şeklinde komutumu giriyorum. Çıktılardan da takip edebildiğimiz üzere x ve y klasörleri eklemiş olduğumuz p seçeneği sayesinde silinmiş oldu. Kesin emin olmak adına mevut dizini listeleyebiliriz. Hatta cd komutu ile x/y dizinine geçiş yapamaya da çalışabiliriz. Bakın klasörler silindiği için ne ls çıktısında ne de cd komutu neticesinde klasörlere ulaşamadık gördüğünüz gibi.

Lütfen unutmayın, biz burada iç içe olan boş klasörleri sildik. Eğer herhangi bir klasörün içerinde dosya bulunuyor olsaydı bu işlem tabii ki başarısız olacaktı. Test etmek için, eğitimin başında yaptığımız gibi cat aracı sayesinde yeni bir metin dosyası oluşturabiliriz.

Ben denemek için öncelikle mkdir -p x/y/z/ komutu ile iç içe yeni klasörler oluşturmak istiyorum. Klasörleri oluşturduktan sonra şimdi herhangi bir klasörün içerisine metin dosyası kaydedebiliriz. Ben en sondaki klasöre "metin.txt" isminde bir dosya kaydetmek için cat > x/y/z/metin.txt şeklinde komutumu giriyorum. Dosya içerisine de merhaba yazıp Ctrl + D ile dosyamı kaydedip kapatıyorum. Tamamdır, artık iç içe klasörlerin en alt dizininde benim oluşturduğum metin.txt dosyası yer alıyor. Teyit etmek için ls a/b/c/ komutunu kullanabiliriz. Bakın metin.txt dosyam burada yer alıyor.

Şimdi tekrar rmdir -vp a/ komutu ile iç içe olan klasörleri silmeyi deneyebiliriz. Fakat bakın, en sonraki klasörün içeriği boş olmadığı için silinemediği belirtiliyor. Zaten burada özellikle hangi klasörün dolu olduğu yani hangi klasörden dolayı silme işleminin reddedildiği açıkça belirtiliyor. Örneğin metin dosyasını bir üst dizine ile taşıyıp silme işlemini tekrar deneyebiliriz. 

Ben dosyayı taşımak için mv a/b/c/metin.txt a/b/ komutunu kullanıyorum. mv komutunun ingilizce "move" yani "taşıma " anlamına geldiğinden daha önce de bahsetmiştim. Zaten daha önce de bu komutu kullanmıştık ve kullanımı oldukça kolay sadece ilk argümanda taşınacak dosyanın tam adresini belirtip ikinci argümana da hangi dizine taşınmasını gerektiğini belirtiyoruz. Neticede metin dosyamızı bir üst dizin olan b klasörüne taşımış olduk. Şimdi tekrar rmdir -vp a/ komutu ile silmeyi deneyelim.

Bakın tekrar hata aldık ve bu sefer, b klasörünün boş olmadığı konusunda uyarıldık. İşte sizler de yalnızca içerisi boş olan klasörleri güvenli şekilde silmek istediğinizde rmdir komutunu kullanabilirsiniz. İçeriği dolu olan bir klasör ile karşılaştığınızda zaten çıktılarda burada da olduğu şekilde hangi klasörün dolu olduğu açıkça belirtiliyor. Yine de silme işlemine devam etmek istiyorsanız, ilgili klasörün içeriğini temizleyip silme işleminin devam etmesini sağlayabilirsiniz.

Ayrıca kimi zaman çerisi dolu olan klasörleri rmdir aracını kullanmadan doğrudan silmek de isteyebilirsiniz. Tam olarak bu işlem için de zaten rm komutunu kullanabiliyoruz. Bu aracın kullanımından ileride ayrıca bahsedeceğiz. Ancak temelde bilmeniz gereken, içerisindeki her şey ile birlikte klasörleri silmek istediğimizde rm -dr komutunu kullanabiliyor olmamızdır. Buradaki r seçeneği recursive yani özyineleme anlamına geliyor. Bu seçenek sayesinde dizinin sonuna kadar tüm içeriklerin otomatik olarak silinmesini sağlanıyor. Burdaki d seçeneği de directory yani dizin ifadesinin kısaltmasından geliyor. Burada özellikle d seçeneği ile dizin silmek istediğimizi belirtmemiz gerekiyor çünkü normalde rm aracı yalnızca dosyaları silmek için kullanılıyor. 

rm -dr komutunu biraz önce içerisinde dosya bulunduğu için silemediğimiz klasörün tamamını silmek için kullanabiliriz. Bunun için rm -dr x/ şeklinde komutumu giriyorum. ls komutu ile a klasörünün içeriğini listelemeyi deneyelim. Bakın a klasörünün silinmiş olduğunu ls sayesinde teyit edebiliyorum. İşte bizzat uygulayarak teyit ettiğimiz gibi içeriği dolu olan dizinleri de bu şekilde rm aracının d v r seçenekler sayesinde kolayca silebiliyoruz. 

Zaten ileride dosyalardan bahsederken dosyaları nasıl silebileceğimizden de bahsetmemiz gerekecek.  Dolayısıyla rm komutunun detaylarında da ayrıca bahsedeceğiz. Şimdilik bu kadarlık bilgi yeterli. Dizinler hakkında yeterince şeyden bahsettik. Bir sonraki bölümde bash kabuğunun sahip olduğu genişletme özelliklerinden bahsederek devam ediyor olacağız. 

# Sorular

1- Çalışmakta olduğunuz mevcut dizini listelemek için hangi komutu kullanmanız gerekir ?

- whereis
- where
- ls
- pwd

2- Kendi ev dizinimdeyken(/home/taylan/) /home/ahmet/ dizinine geçiş yapmak için aşağıdaki komutlardan hangisi girmem doğru olmaz ?

- cd ../ahmet
- cd /home/ahmet
- cd home/ahmet

3- Yalnızca cd komutunu girdiğimizde ne olur ?

- Kök dizine (/) geçiş yaparız.
- Hiç bir etkisi olmaz.
- Kendi kullanıcı hesabımızın ev dizinine geçiş yaparız.

4- Çalışmakta olduğum mevcut dizinde bulunan Desktop isimli klasöre geçiş yapmak için hangi komutu kullanmamız doğru olur ?

- cd ../Desktop
- cd /Desktop
- cd .Desktop
- cd Desktop

5- Bir önceki çalıştığım dizine hızlıca atlamak için hangi komutu kullanmalıyım ?

- cd
- cd ..
- cd -
- cd ~
- cd .

6- Bir üst dizine geçiş yapmak için hangi komutu kullanmalıyız ?

- cd
- cd ..
- cd -
- cd ~
- cd .

7- cd ~ yani cd aracına argüman olarak verdiğimiz tilde işareti nasıl bir etki gösterir ?

- kök dizine(/) dönmemizi sağlar.
- bir önceki dizine geçiş yapmamızı sağlar.
- mevcut kullanıcının ev dizinine dönülür. -D

8- Geçiş yapmak istediğimiz klasör isminde boşluk karakteri bulunuyorsa komutumuzu nasıl girebiliriz ?

- cd yeni klasor
- cd yeni$klasor
- cd ‘yeni klasor’ bu kullanım dışında dilerseniz cd yeni\ klasör komutuyla da klasör isminde boşluk bulunan dizine geçiş yapabilirsiniz. Buradaki ters slash karakteri buradaki boşluk karakterinin görmezden gelinmesini sağladığı için komutumuz yeni ve klasör şeklinde argümanlara ayrılmadan tek parça cd aracına iletiliyor.

9- cd komutu ile CD komutu aynı işlevi mi sağlar ?

- Evet cd ve CD komutu aynıdır.
- Hayır cd ve CD komutu aynı değildir. Küçük büyük harf duyarlılığı olduğu için cd ile CD komutu kesinlikle aynı aracı temsil eden komutlar değil. Dolayısıyla aynı işlevi yerine getirmiyorlar.

10- Mevcut bulunduğumuz dizindeki içerikleri ayrıntılı şekilde listelemek için komutumuzu nasıl girmemiz gerekiyor ?

- ls
- ls -a
- ls -l

11- Gizli dosyaları da listelemek için ls komutunun hangi seçeneğini kullanmamız gerekiyor?

- l
- s
- a
- d

12- ls komutunun çıktılarını büyükten küçüğe doğru daha okunaklı boyut bilgileri ile bastırmak için komutumuzu nasıl girmemiz gerekiyor ?

- ls -Sl
- ls -sa
- ls -sh
- ls -Sh

13- ls komutunun çıktılarını alfabetik olarak ters bastırmak için hangi seçeneği kullanmamız gerekiyor ?

- r
- R
- t
- T

14- Spesifik bir dizin içerisindeki tüm alt dizinler de dahil bütün(gizliler de dahil) içeriği özyinelemeli olarak bastırmak için komutumuzu nasıl girmemiz gerekiyor ?

- ls -la dizin/
- ls -lsa dizin/
- ls -ra dizin/
- ls -Ra dizin/

15- Mevcut dizinimizdeki içerikleri eskiden yeniye doğru listelemek için hangi komutu kullanabiliriz ?

- ls -sla
- ls -tr  Normalde ls komutunun -t seçeneği içerikleri yeniden eskiye doğru sıralıyor. Biz ayrıca r seçeneğini eklediğimiz için bu çıktıyı tersine çevirip eskiden yeniye doğru sıralamış oluyoruz.
- ls -t  Bu t seçeneği yalnızca yeniden eskiye doğru sıralama yapar. Soruda tersi isteniyor.
- ls -tal

16- ls aracı üzerinden yalnızca /etc/ dizini hakkında ayrıntılı bilgi almak için komutumuzu nasıl girebiliriz ?

- ls -la /etc/
- ls -l /etc/
- ls -ld /etc/
- ls -la /etc

17- Yeni bir dizin oluşturmak için hangi aracı kullanabiliriz ?

- rmdir
- touch
- echo
- mkdir

18- mkdir aracı ile iç içe yeni dizinler oluşturmak için komutumuzu nasıl girebiliriz ?

- mkdir ilk/orta/son
- mkdir -d ilk/orta/son
- mkdir -p ilk/orta/son
- mkdir -r ilk/orta/son
- mkdir -R ilk/orta/son

19- Alt dizinleri de dahil tamamı boş olan klasörleri nasıl silebiliriz ?

- rmdir -r klasör
- rmdir klasör
- rmdir -R klasör
- rmdir -p klasör - Buradaki p seçeneği sayesinde içi boş olduğu sürece tüm alt dizinlerle birlikte istediğimiz klasörü silebiliyoruz. p seçeneği olmadan alt dizinleri bulunan klasörleri silmemiz mümkün olmuyor.

20- İçerisinde dosyalar bulunan bir klasörü nasıl silebiliriz ?

- rmdir klasör
- rmdir -p klasör
- rmdir -r klasör
- rmdir aracı ile dolu klasörleri silemeyiz. - Doğru rmdir aracı yalnızca boş dizinleri silmek için kullanılan bir araç.